// Respiratory: mechanics of breathing & lung volumes — the ribcage lifts, the
// diaphragm domes and flattens, lungs inflate; a spirometer bar fills with
// tidal volume, IRV, ERV and residual volume.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "rate", label: "Breathing rate", kind: "slider", min: 4, max: 30, step: 1, default: 14, unit: "/min" },
  { key: "tv", label: "Tidal volume", kind: "slider", min: 0.2, max: 1.5, step: 0.1, default: 0.5, unit: "L" },
];

export const UNIQUE_META = {
  title: "Respiratory: Mechanics of Breathing",
  blurb: "Ribs lift, the diaphragm flattens, lungs inflate — and the spirometer bar shows each lung volume.",
};

function Animator({
  ribs, diaphragm, lungs, airIn, spiromBar, elapsed, rate, tv,
}: {
  ribs: React.RefObject<THREE.Group>;
  diaphragm: React.RefObject<THREE.Mesh>;
  lungs: React.RefObject<THREE.Group>;
  airIn: React.RefObject<THREE.Group>;
  spiromBar: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  rate: number;
  tv: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const breath = 0.5 + 0.5 * Math.sin(t * (rate / 60) * Math.PI * 2); // 0=exhale,1=inhale
    const amp = 0.4 + tv * 0.9;
    if (ribs.current) {
      ribs.current.children.forEach((m, i) => {
        m.rotation.x = -0.12 * breath * amp - i * 0.012;
        m.position.y = 3.4 - i * 0.55 + breath * 0.22 * amp;
      });
    }
    if (diaphragm.current) {
      diaphragm.current.scale.y = 1 - 0.55 * breath * amp;
      diaphragm.current.position.y = 0.9 + breath * 0.5 * amp;
    }
    if (lungs.current) {
      const s = 1 + 0.22 * breath * amp;
      lungs.current.scale.set(s, 1 + 0.28 * breath * amp, s);
    }
    if (airIn.current) {
      airIn.current.children.forEach((m, i) => {
        const ph = ((t * (rate / 60) + i / 8) % 1 + 1) % 1;
        m.position.y = 6.2 - ph * 3.4;
        const mat = (m as THREE.Mesh).material as THREE.MeshBasicMaterial;
        mat.opacity = breath > 0.5 ? 0.55 : 0.12;
      });
    }
    if (spiromBar.current) {
      spiromBar.current.scale.y = Math.max(0.02, breath * amp * 1.4);
      spiromBar.current.position.y = 0.6 + (breath * amp * 1.4 * 2.2) / 2;
    }
  });
  return null;
}

export function Topic10040Sim(props: SimProps) {
  const rate = Number(props.rate ?? 14);
  const tv = Number(props.tv ?? 0.5);
  const ribs = useRef<THREE.Group>(null!);
  const diaphragm = useRef<THREE.Mesh>(null!);
  const lungs = useRef<THREE.Group>(null!);
  const airIn = useRef<THREE.Group>(null!);
  const spiromBar = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const ribIdx = useMemo(() => Array.from({ length: 6 }).map((_, i) => i), []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Minute ventilation", `${(rate * tv).toFixed(1)} L/min`],
          ["Phase", "watch the diaphragm dome/flatten"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* trachea */}
        <mesh position={[-2.5, 5.6, 0]} castShadow>
          <cylinderGeometry args={[0.35, 0.35, 2.2, 14]} />
          <meshStandardMaterial color="#c084fc" roughness={0.5} />
        </mesh>
        {[-0.7, -0.2, 0.3, 0.8].map((dy, i) => (
          <mesh key={i} position={[-2.5, 5.6 + dy, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.36, 0.06, 8, 16]} />
            <meshStandardMaterial color="#a855f7" roughness={0.5} />
          </mesh>
        ))}
        {/* bronchi */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[-2.5 + s * 0.5, 4.2, 0]} rotation={[0, 0, s * 0.6]} castShadow>
            <cylinderGeometry args={[0.2, 0.2, 1.4, 10]} />
            <meshStandardMaterial color="#c084fc" roughness={0.5} />
          </mesh>
        ))}
        {/* inhaled air sparkles */}
        <group ref={airIn}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[-2.5, 6.2, 0]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshBasicMaterial color="#bae6fd" transparent opacity={0.5} />
            </mesh>
          ))}
        </group>

        {/* lungs */}
        <group ref={lungs} position={[-2.5, 2.9, 0]}>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 0.95, 0, 0]} castShadow scale={[1, 1.45, 0.9]}>
              <sphereGeometry args={[0.95, 20, 20]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.45} />
            </mesh>
          ))}
        </group>
        {/* ribcage */}
        <group ref={ribs} position={[-2.5, 0, 0]}>
          {ribIdx.map((i) => (
            <mesh key={i} position={[0, 3.4 - i * 0.55, 0]} rotation={[-0.12, 0, 0]}>
              <torusGeometry args={[2.1 - i * 0.12, 0.09, 8, 28, Math.PI * 1.35]} />
              <meshStandardMaterial color="#e7e5e4" roughness={0.5} />
            </mesh>
          ))}
        </group>
        {/* diaphragm */}
        <mesh ref={diaphragm} position={[-2.5, 0.9, 0]} castShadow>
          <sphereGeometry args={[1.9, 20, 12, 0, Math.PI * 2, 0, Math.PI * 0.45]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.5} side={THREE.DoubleSide} />
        </mesh>
        <Label text="ribs lift up & out" position={[-5.6, 3.4, 0]} size={0.3} color="#e7e5e4" />
        <Label text="diaphragm contracts → flattens" position={[-2.5, -0.35, 0]} size={0.32} color="#fca5a5" />
        <Label text="lungs inflate" position={[-0.6, 4.6, 0]} size={0.32} color="#f9a8d4" />

        {/* spirometer: lung volume compartments */}
        <group position={[4.6, 0, 0]}>
          <mesh position={[0, 2.4, 0]} castShadow>
            <boxGeometry args={[1.6, 4.8, 1.0]} />
            <meshStandardMaterial color="#1e293b" transparent opacity={0.7} roughness={0.4} />
          </mesh>
          {/* residual volume (always present) */}
          <mesh position={[0, 0.85, 0]}>
            <boxGeometry args={[1.3, 0.5, 1.05]} />
            <meshStandardMaterial color="#64748b" roughness={0.5} />
          </mesh>
          {/* tidal breath bar */}
          <mesh ref={spiromBar} position={[0, 0.6, 0]}>
            <boxGeometry args={[1.3, 2.2, 1.05]} />
            <meshStandardMaterial color="#38bdf8" emissive="#0369a1" emissiveIntensity={0.4} roughness={0.4} />
          </mesh>
          <Label text="RV" position={[1.35, 0.85, 0]} size={0.3} color="#94a3b8" />
          <Label text="TV" position={[1.35, 2.1, 0]} size={0.3} color="#7dd3fc" />
          <Label text="spirometer" position={[0, 5.25, 0]} size={0.38} color="#f8fafc" />
          <Label text="IRV + ERV + RV = TLC" position={[0, -0.5, 0]} size={0.28} color="#94a3b8" />
        </group>

        <Animator ribs={ribs} diaphragm={diaphragm} lungs={lungs} airIn={airIn}
          spiromBar={spiromBar} elapsed={elapsed} rate={rate} tv={tv} />
      </SimCanvas>
    </div>
  );
}
