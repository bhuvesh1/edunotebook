"use client";
// Ear: anatomy and physiology of hearing and balance.
// A big ear cross-section: outer ear funnels sound waves down the canal,
// the eardrum vibrates, three tiny ossicles dance, and the cochlea glows.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "sound", label: "Sound", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
  { key: "part", label: "Highlight part", kind: "select", min: 0, max: 0, step: 1, default: "all", options: ["all", "outer", "middle", "inner"] },
];

export const UNIQUE_META = {
  title: "The Ear: How Hearing & Balance Work",
  blurb: "Follow a sound wave from the outer ear, through the vibrating eardrum and dancing ear bones, into the glowing cochlea.",
};

function Animator({ waves, drum, ossicles, elapsed, sound }: { waves: React.RefObject<THREE.Group>; drum: React.RefObject<THREE.Mesh>; ossicles: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; sound: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const on = sound === "on";
    if (waves.current) {
      waves.current.visible = on;
      waves.current.children.forEach((w, i) => {
        const ph = (elapsed.current * 0.9 + i * 0.25) % 1;
        w.position.x = -6.5 + ph * 5;
        const s = 0.4 + ph * 1.3;
        w.scale.set(s, s, s);
        (w as THREE.Mesh).material = (w as THREE.Mesh).material;
      });
    }
    if (drum.current) {
      drum.current.position.x = on ? Math.sin(elapsed.current * 18) * 0.09 : 0;
    }
    if (ossicles.current) {
      ossicles.current.children.forEach((o, i) => {
        o.rotation.z = on ? Math.sin(elapsed.current * 14 + i * 1.2) * 0.28 : 0;
      });
    }
  });
  return null;
}

export function Topic10184Sim(props: SimProps) {
  const sound = String(props.sound ?? "on");
  const part = String(props.part ?? "all");
  const waves = useRef<THREE.Group>(null!);
  const drum = useRef<THREE.Mesh>(null!);
  const ossicles = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const hl = (k: string) => part === "all" || part === k;

  const waveMeshes = useMemo(
    () =>
      Array.from({ length: 4 }, (_, i) => (
        <mesh key={i} position={[-6.5 + i * 1.25, 3, 0]}>
          <torusGeometry args={[0.5, 0.07, 8, 24]} />
          <meshStandardMaterial color="#7dd3fc" emissive="#38bdf8" emissiveIntensity={0.9} transparent opacity={0.85} />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Sound", sound], ["Path", "outer → middle → inner ear"]]} />
      <SimCanvas cameraPosition={[0, 3.2, 13]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={waves}>{waveMeshes}</group>
        {/* outer ear (pinna) */}
        <group position={[-5.2, 3, 0]} scale={hl("outer") ? [1, 1, 1] : [0.85, 0.85, 0.85]}>
          <mesh castShadow>
            <torusGeometry args={[1.1, 0.42, 12, 24]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.65} emissive={hl("outer") ? "#f59e0b" : "#000000"} emissiveIntensity={hl("outer") ? 0.25 : 0} />
          </mesh>
          <mesh position={[0.3, -0.2, 0]}>
            <sphereGeometry args={[0.55, 14, 14]} />
            <meshStandardMaterial color="#f5c9a0" roughness={0.65} />
          </mesh>
          <Label text="OUTER EAR" position={[0, 2, 0]} size={0.55} color="#fcd9b8" />
        </group>
        {/* ear canal */}
        <mesh position={[-3.2, 3, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.5, 0.5, 2.4, 14, 1, true]} />
          <meshStandardMaterial color="#e8b58e" transparent opacity={0.5} roughness={0.6} side={THREE.DoubleSide} />
        </mesh>
        <Label text="CANAL" position={[-3.2, 4, 0]} size={0.45} color="#e8b58e" />
        {/* eardrum */}
        <mesh ref={drum} position={[-1.9, 3, 0]} rotation={[0, Math.PI / 2, 0]}>
          <circleGeometry args={[0.52, 20]} />
          <meshStandardMaterial color={hl("middle") ? "#fda4af" : "#9ca3af"} emissive={hl("middle") ? "#f43f5e" : "#000000"} emissiveIntensity={hl("middle") ? 0.4 : 0} side={THREE.DoubleSide} />
        </mesh>
        <Label text="EARDRUM" position={[-1.9, 4, 0]} size={0.5} color="#fda4af" />
        {/* ossicles: malleus, incus, stapes */}
        <group ref={ossicles} position={[-0.6, 3, 0]}>
          {[[-0.5, "malleus"], [0, "incus"], [0.5, "stapes"]].map(([x, n], i) => (
            <mesh key={n as string} position={[x as number, 0, 0]} rotation={[0, 0, 0.4 - i * 0.4]} castShadow>
              <capsuleGeometry args={[0.13, 0.4 - i * 0.06, 4, 8]} />
              <meshStandardMaterial color="#fef3c7" roughness={0.5} emissive={hl("middle") ? "#f59e0b" : "#000000"} emissiveIntensity={hl("middle") ? 0.3 : 0} />
            </mesh>
          ))}
          <Label text="3 EAR BONES" position={[0, 1.1, 0]} size={0.5} color="#fef3c7" />
        </group>
        {/* cochlea: spiral */}
        <group position={[1.6, 3, 0]}>
          {[0, 1, 2, 3].map((i) => (
            <mesh key={i} rotation={[Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
              <torusGeometry args={[0.75 - i * 0.16, 0.13, 8, 24]} />
              <meshStandardMaterial color="#c4b5fd" emissive={hl("inner") ? "#8b5cf6" : "#000000"} emissiveIntensity={hl("inner") ? 0.7 : 0.1} roughness={0.45} />
            </mesh>
          ))}
          <Label text="COCHLEA (hearing)" position={[0, 1.4, 0]} size={0.5} color="#c4b5fd" />
        </group>
        {/* semicircular canals: balance */}
        <group position={[1.6, 5, 0]}>
          {[0, 1, 2].map((i) => (
            <mesh key={i} rotation={[i * 0.6, 0.4, 0]}>
              <torusGeometry args={[0.5, 0.1, 8, 20, Math.PI * 1.5]} />
              <meshStandardMaterial color="#6ee7b7" emissive={hl("inner") ? "#10b981" : "#000000"} emissiveIntensity={hl("inner") ? 0.6 : 0.1} roughness={0.45} />
            </mesh>
          ))}
          <Label text="BALANCE CANALS" position={[0, 1.1, 0]} size={0.5} color="#6ee7b7" />
        </group>
        <Animator waves={waves} drum={drum} ossicles={ossicles} elapsed={elapsed} sound={sound} />
      </SimCanvas>
    </div>
  );
}
