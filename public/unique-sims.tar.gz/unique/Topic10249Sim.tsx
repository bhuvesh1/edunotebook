// Pancreatic surgery: pancreatitis vs pancreatic tumor.
// A 3D pancreas (leaf-shaped) nestled against the stomach, with the duodenum
// curving around its head. Switch conditions to see inflammation or a tumor.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "pancreatitis", options: ["healthy", "pancreatitis", "tumor"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Pancreas: Pancreatitis vs Tumor",
  blurb: "See a healthy pancreas beside the stomach, then watch it inflame (pancreatitis) or grow a tumor.",
};

function Animator({
  group, tumor, inflame, elapsed, speed, condition,
}: {
  group: React.RefObject<THREE.Group>;
  tumor: React.RefObject<THREE.Mesh>;
  inflame: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.35;
    const pulse = 0.5 + 0.5 * Math.sin(t * 3.2);
    if (inflame.current) {
      inflame.current.visible = condition === "pancreatitis";
      const s = 1 + pulse * 0.06;
      inflame.current.scale.set(s, s, s);
      (inflame.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.35 + pulse * 0.5;
    }
    if (tumor.current) {
      tumor.current.visible = condition === "tumor";
      const s = 1 + pulse * 0.12;
      tumor.current.scale.set(s, s * 0.9, s);
    }
  });
  return null;
}

export function Topic10249Sim(props: SimProps) {
  const condition = String(props.condition ?? "pancreatitis");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const tumor = useRef<THREE.Mesh>(null!);
  const inflame = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const condLabel =
    condition === "healthy" ? "Healthy pancreas" :
    condition === "tumor" ? "Pancreatic tumor (head)" : "Acute pancreatitis";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", condLabel], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.6, 9.5]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* stomach: J-shaped pouch left of pancreas */}
          <mesh position={[-2.6, 2.2, 0]} rotation={[0, 0, -0.5]} castShadow>
            <torusGeometry args={[1.05, 0.62, 20, 32, Math.PI * 1.35]} />
            <meshStandardMaterial color="#fda4af" roughness={0.55} />
          </mesh>
          {/* duodenum: C-loop hugging the pancreatic head */}
          <mesh position={[1.9, 1.1, 0.1]} rotation={[0, 0, 0.4]} castShadow>
            <torusGeometry args={[1.0, 0.34, 16, 32, Math.PI * 1.5]} />
            <meshStandardMaterial color="#fcd34d" roughness={0.55} />
          </mesh>
          {/* pancreas: long leaf from head (right) to tail (left) */}
          <group position={[0.2, 1.1, 0.4]}>
            <mesh position={[1.1, 0, 0]} scale={[1.25, 0.75, 0.62]} castShadow ref={inflame}>
              <sphereGeometry args={[0.62, 28, 20]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.5} emissive="#dc2626" emissiveIntensity={0.5} />
            </mesh>
            <mesh position={[-0.5, 0.05, 0]} rotation={[0, 0, 0.18]} scale={[1.5, 0.52, 0.45]} castShadow>
              <sphereGeometry args={[0.62, 28, 20]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.5} emissive="#dc2626" emissiveIntensity={0.3} />
            </mesh>
            <mesh position={[-2.05, 0.28, 0]} rotation={[0, 0, 0.35]} castShadow>
              <coneGeometry args={[0.3, 0.9, 20]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
            </mesh>
          </group>
          {/* tumor on the pancreatic head */}
          <mesh ref={tumor} position={[1.6, 1.35, 0.75]} castShadow visible={false}>
            <icosahedronGeometry args={[0.42, 1]} />
            <meshStandardMaterial color="#991b1b" roughness={0.35} emissive="#7f1d1d" emissiveIntensity={0.4} flatShading />
          </mesh>
          <Label text="Stomach" position={[-3.1, 3.6, 0]} size={0.55} color="#fecdd3" />
          <Label text="Duodenum" position={[3.2, 2.1, 0.1]} size={0.55} color="#fde68a" />
          <Label text="Pancreas" position={[0.1, 0.1, 0.6]} size={0.55} color="#fbcfe8" />
          {condition === "tumor" && <Label text="⚠ Tumor" position={[1.6, 2.15, 0.75]} size={0.55} color="#fca5a5" />}
          {condition === "pancreatitis" && <Label text="🔥 Inflamed" position={[0.3, 2.15, 0.5]} size={0.55} color="#fdba74" />}
        </group>
        <Animator group={group} tumor={tumor} inflame={inflame} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
