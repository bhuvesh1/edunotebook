// CVS: cardiac cycle, heart sounds, ECG — a four-chamber heart beating in
// sequence (atria then ventricles), valves snapping, S1/S2 flashes, and a
// scrolling ECG trace with P-QRS-T waves.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "hr", label: "Heart rate", kind: "slider", min: 30, max: 160, step: 5, default: 72, unit: "bpm" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "CVS: Cardiac Cycle & ECG",
  blurb: "Atria squeeze, then ventricles — valves snap shut (S1, S2) while the ECG draws its P-QRS-T waves.",
};

function Animator({
  atria, ventricles, s1, s2, ecgPen, elapsed, hr, speed,
}: {
  atria: React.RefObject<THREE.Group>;
  ventricles: React.RefObject<THREE.Group>;
  s1: React.RefObject<THREE.Mesh>;
  s2: React.RefObject<THREE.Mesh>;
  ecgPen: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  hr: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const cyc = (t * (hr / 60)) % 1; // 0..1 per beat
    // atria contract early (0.0-0.2), ventricles mid (0.2-0.5)
    const aBeat = Math.max(0, Math.sin(cyc * Math.PI * 5)) * (cyc < 0.25 ? 1 : 0);
    const vBeat = Math.max(0, Math.sin((cyc - 0.25) * Math.PI * 3.4)) * (cyc > 0.2 && cyc < 0.6 ? 1 : 0);
    if (atria.current) atria.current.scale.setScalar(1 - 0.18 * aBeat);
    if (ventricles.current) ventricles.current.scale.setScalar(1 - 0.14 * vBeat);
    // S1 at ventricular systole start, S2 at its end
    if (s1.current) {
      const on = cyc > 0.22 && cyc < 0.32;
      s1.current.visible = on;
      if (on) s1.current.scale.setScalar(1 + 0.5 * Math.sin(t * 25));
    }
    if (s2.current) {
      const on = cyc > 0.55 && cyc < 0.65;
      s2.current.visible = on;
      if (on) s2.current.scale.setScalar(1 + 0.5 * Math.sin(t * 25));
    }
    // ECG pen sweeps the trace in time with the beat
    if (ecgPen.current) {
      const px = -5 + cyc * 10;
      ecgPen.current.position.x = px;
      ecgPen.current.position.y = 1 + ecgWave(cyc) * 1.1;
    }
  });
  return null;
}

// ECG waveform over one beat cycle (P, QRS, T)
function ecgWave(cyc: number) {
  const g = (c: number, w: number) => Math.exp(-((cyc - c) * (cyc - c)) / (2 * w * w));
  return 0.25 * g(0.16, 0.03) - 0.15 * g(0.3, 0.012) + 1.0 * g(0.32, 0.016)
    - 0.3 * g(0.345, 0.012) + 0.35 * g(0.62, 0.045);
}

export function Topic10037Sim(props: SimProps) {
  const hr = Number(props.hr ?? 72);
  const speed = Number(props.speed ?? 1);
  const atria = useRef<THREE.Group>(null!);
  const ventricles = useRef<THREE.Group>(null!);
  const s1 = useRef<THREE.Mesh>(null!);
  const s2 = useRef<THREE.Mesh>(null!);
  const ecgPen = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const ecgGeo = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 120; i++) {
      const cyc = i / 120;
      pts.push(new THREE.Vector3(-5 + cyc * 10, 1 + ecgWave(cyc) * 1.1, 0));
    }
    return new THREE.BufferGeometry().setFromPoints(pts);
  }, []);

  const ecgLineObj = useMemo(
    () => new THREE.Line(ecgGeo, new THREE.LineBasicMaterial({ color: "#4ade80" })),
    [ecgGeo]
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Heart rate", `${hr} bpm`],
          ["Cycle", "atrial systole → ventricular systole"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 6, 16]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* four-chamber heart (stylised) */}
        <group position={[-3.5, 0, 0]}>
          <group ref={atria}>
            {/* right + left atria */}
            <mesh position={[-0.75, 3.3, 0]} castShadow>
              <sphereGeometry args={[0.72, 18, 18]} />
              <meshStandardMaterial color="#fda4af" roughness={0.45} />
            </mesh>
            <mesh position={[0.75, 3.3, 0]} castShadow>
              <sphereGeometry args={[0.72, 18, 18]} />
              <meshStandardMaterial color="#fda4af" roughness={0.45} />
            </mesh>
          </group>
          <group ref={ventricles}>
            {/* right + left ventricles (LV thicker) */}
            <mesh position={[-0.62, 1.75, 0]} castShadow scale={[1, 1.25, 1]}>
              <sphereGeometry args={[0.85, 18, 18]} />
              <meshStandardMaterial color="#ef4444" roughness={0.45} />
            </mesh>
            <mesh position={[0.68, 1.7, 0]} castShadow scale={[1.15, 1.35, 1.05]}>
              <sphereGeometry args={[0.95, 18, 18]} />
              <meshStandardMaterial color="#dc2626" roughness={0.45} />
            </mesh>
          </group>
          {/* aorta + pulmonary trunk */}
          <mesh position={[0.4, 4.3, 0]} rotation={[0, 0, -0.35]} castShadow>
            <cylinderGeometry args={[0.3, 0.3, 1.8, 12]} />
            <meshStandardMaterial color="#ef4444" roughness={0.4} />
          </mesh>
          <mesh position={[-0.6, 4.2, 0]} rotation={[0, 0, 0.5]} castShadow>
            <cylinderGeometry args={[0.28, 0.28, 1.6, 12]} />
            <meshStandardMaterial color="#3b82f6" roughness={0.4} />
          </mesh>
          {/* AV valves (flash at S1) */}
          <mesh ref={s1} position={[0, 2.55, 0]} visible={false}>
            <sphereGeometry args={[0.5, 12, 12]} />
            <meshBasicMaterial color="#fef08a" transparent opacity={0.7} />
          </mesh>
          {/* semilunar valves (flash at S2) */}
          <mesh ref={s2} position={[0, 3.9, 0]} visible={false}>
            <sphereGeometry args={[0.45, 12, 12]} />
            <meshBasicMaterial color="#bae6fd" transparent opacity={0.7} />
          </mesh>
        </group>
        <Label text="right atrium" position={[-5.3, 3.9, 0]} size={0.3} color="#fda4af" />
        <Label text="left atrium" position={[-1.7, 3.9, 0]} size={0.3} color="#fda4af" />
        <Label text="right ventricle" position={[-5.2, 1.3, 0]} size={0.3} color="#fca5a5" />
        <Label text="left ventricle (thicker)" position={[-1.6, 0.9, 0]} size={0.3} color="#fca5a5" />
        <Label text="S1: AV valves snap shut" position={[-3.5, 5.5, 0]} size={0.32} color="#fef08a" />
        <Label text="S2: semilunar valves snap" position={[2.2, 5.5, 0]} size={0.32} color="#bae6fd" />

        {/* ECG trace */}
        <group position={[3.2, 0, 0]}>
          <mesh position={[0, 1, -0.05]} receiveShadow>
            <planeGeometry args={[10.6, 3.4]} />
            <meshStandardMaterial color="#052e16" roughness={0.9} />
          </mesh>
          {/* grid */}
          {[-0.75, 0, 0.75].map((y, i) => (
            <mesh key={i} position={[0, 1 + y, 0]}>
              <planeGeometry args={[10.4, 0.02]} />
              <meshBasicMaterial color="#166534" transparent opacity={0.5} />
            </mesh>
          ))}
          <primitive object={ecgLineObj} />
          <mesh ref={ecgPen}>
            <sphereGeometry args={[0.09, 8, 8]} />
            <meshBasicMaterial color="#bbf7d0" />
          </mesh>
        </group>
        <Label text="ECG: P — QRS — T" position={[3.2, 3.3, 0]} size={0.36} color="#86efac" />

        <Animator atria={atria} ventricles={ventricles} s1={s1} s2={s2}
          ecgPen={ecgPen} elapsed={elapsed} hr={hr} speed={speed} />
      </SimCanvas>
    </div>
  );
}
