// Respiratory: gas exchange & oxygen transport — an alveolus wrapped in a
// capillary: O2 (blue) diffuses into blood, CO2 (grey) diffuses out; the Hb
// saturation dial follows alveolar PO2.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "po2", label: "Alveolar PO₂", kind: "slider", min: 40, max: 120, step: 5, default: 100, unit: "mmHg" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Respiratory: Gas Exchange",
  blurb: "O₂ diffuses from alveolus to blood, CO₂ the other way — watch hemoglobin saturation follow PO₂.",
};

function Animator({
  o2, co2, alv, satNeedle, elapsed, sat, speed,
}: {
  o2: React.RefObject<THREE.Group>;
  co2: React.RefObject<THREE.Group>;
  alv: React.RefObject<THREE.Mesh>;
  satNeedle: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  sat: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const breath = 0.5 + 0.5 * Math.sin(t * 1.8);
    if (alv.current) alv.current.scale.setScalar(1 + 0.1 * breath);
    // O2: alveolus -> blood (down); CO2: blood -> alveolus (up)
    if (o2.current) {
      o2.current.children.forEach((m, i) => {
        const ph = ((t * 0.35 + i / 10) % 1 + 1) % 1;
        m.position.y = 3.3 - ph * 2.2;
        m.position.x = Math.sin(i * 2.7) * 0.8;
      });
    }
    if (co2.current) {
      co2.current.children.forEach((m, i) => {
        const ph = ((t * 0.3 + i / 8) % 1 + 1) % 1;
        m.position.y = 1.1 + ph * 2.2;
        m.position.x = Math.cos(i * 2.2) * 0.8;
      });
    }
    if (satNeedle.current) {
      const target = sat / 100;
      const cur = satNeedle.current.userData.v ?? target;
      const nv = cur + (target - cur) * Math.min(1, delta * 3);
      satNeedle.current.userData.v = nv;
      satNeedle.current.rotation.z = Math.PI * 0.75 - nv * Math.PI * 1.5;
    }
  });
  return null;
}

export function Topic10041Sim(props: SimProps) {
  const po2 = Number(props.po2 ?? 100);
  const speed = Number(props.speed ?? 1);
  const o2 = useRef<THREE.Group>(null!);
  const co2 = useRef<THREE.Group>(null!);
  const alv = useRef<THREE.Mesh>(null!);
  const satNeedle = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  // oxygen–hemoglobin dissociation (approx Hill curve)
  const sat = Math.round((100 * Math.pow(po2, 2.8)) / (Math.pow(26, 2.8) + Math.pow(po2, 2.8)));
  const satColor = sat >= 90 ? "#86efac" : sat >= 75 ? "#fde68a" : "#fca5a5";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Alveolar PO₂", `${po2} mmHg`],
          ["Hb saturation", `${sat}%`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 14]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* alveolus */}
        <mesh ref={alv} position={[0, 3.6, 0]} castShadow>
          <sphereGeometry args={[1.3, 24, 24]} />
          <meshStandardMaterial color="#f9a8d4" transparent opacity={0.65} roughness={0.35} />
        </mesh>
        <Label text="alveolus (air)" position={[0, 5.3, 0]} size={0.4} color="#f8fafc" />

        {/* capillary wrapped around */}
        <mesh position={[0, 1.6, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <torusGeometry args={[1.45, 0.35, 12, 32]} />
          <meshStandardMaterial color="#dc2626" roughness={0.45} />
        </mesh>
        {/* RBCs inside capillary */}
        {[-0.9, -0.2, 0.6].map((a, i) => (
          <mesh key={i} position={[Math.cos(a) * 1.45, 1.6, Math.sin(a) * 1.45]} scale={[1, 0.42, 1]}>
            <sphereGeometry args={[0.24, 12, 12]} />
            <meshStandardMaterial color="#ef4444" roughness={0.4} />
          </mesh>
        ))}
        <Label text="pulmonary capillary (blood)" position={[0, 0.35, 0]} size={0.36} color="#fca5a5" />

        {/* diffusing gases */}
        <group ref={o2}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i} position={[0, 3.3, 0]}>
              <sphereGeometry args={[0.12, 8, 8]} />
              <meshBasicMaterial color="#38bdf8" />
            </mesh>
          ))}
        </group>
        <group ref={co2}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[0, 1.1, 0]}>
              <sphereGeometry args={[0.12, 8, 8]} />
              <meshBasicMaterial color="#9ca3af" />
            </mesh>
          ))}
        </group>
        <Arrow from={[2.3, 3.4, 0]} to={[2.3, 1.4, 0]} color="#38bdf8" radius={0.06} />
        <Label text="O₂ in" position={[2.9, 2.4, 0]} size={0.32} color="#7dd3fc" />
        <Arrow from={[-2.3, 1.4, 0]} to={[-2.3, 3.4, 0]} color="#9ca3af" radius={0.06} />
        <Label text="CO₂ out" position={[-2.95, 2.4, 0]} size={0.32} color="#d1d5db" />
        <Label text="diffusion down partial-pressure gradients" position={[0, -0.5, 0]} size={0.3} color="#94a3b8" />

        {/* Hb saturation dial */}
        <group position={[6.8, 2.4, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[1.3, 1.3, 0.3, 28]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.35} />
          </mesh>
          <mesh position={[0, 0, 0.16]}>
            <circleGeometry args={[1.1, 28]} />
            <meshStandardMaterial color="#0f172a" roughness={0.6} />
          </mesh>
          {Array.from({ length: 11 }).map((_, i) => {
            const a = Math.PI * 0.75 - (i / 10) * Math.PI * 1.5;
            return (
              <mesh key={i} position={[Math.cos(a) * 0.9, Math.sin(a) * 0.9, 0.17]} rotation={[0, 0, a - Math.PI / 2]}>
                <boxGeometry args={[0.04, 0.16, 0.02]} />
                <meshBasicMaterial color="#94a3b8" />
              </mesh>
            );
          })}
          <mesh ref={satNeedle} position={[0, 0, 0.19]}>
            <boxGeometry args={[0.06, 0.9, 0.02]} />
            <meshBasicMaterial color="#4ade80" />
          </mesh>
        </group>
        <Label text="hemoglobin saturation" position={[6.8, 4.3, 0]} size={0.36} color="#f8fafc" />
        <Label text={`${sat}%`} position={[6.8, 1.0, 0]} size={0.5} color={satColor} />

        <Animator o2={o2} co2={co2} alv={alv} satNeedle={satNeedle} elapsed={elapsed} sat={sat} speed={speed} />
      </SimCanvas>
    </div>
  );
}
