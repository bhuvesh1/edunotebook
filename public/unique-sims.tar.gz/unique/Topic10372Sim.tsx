"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Development stage", kind: "slider", min: 1, max: 3, step: 1, default: 2, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Tooth development: bud, cap, bell stages",
  blurb: "A tooth bud grows into a cap, then a bell — watch enamel and dentin layers appear as the crown shape is decided.",
};

const STAGES = ["Bud stage", "Cap stage", "Bell stage"];
const SUB = [
  "epithelium thickens into a bud",
  "bud cups the dental papilla",
  "bell shapes the crown; enamel + dentin form",
];

function ToothGerm({ stage, speed, showLabels }: { stage: number; speed: number; showLabels: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) g.current.rotation.y = elapsed.current * 0.4;
  });

  return (
    <group ref={g}>
      {/* dental papilla (future pulp) */}
      <mesh position={[0, -0.9, 0]} castShadow>
        <sphereGeometry args={[stage === 1 ? 0.001 : 1.0, 22, 16]} />
        <meshStandardMaterial color="#f87171" roughness={0.5} />
      </mesh>
      {/* dental follicle sac */}
      <mesh position={[0, -0.2, 0]} castShadow>
        <sphereGeometry args={[2.15, 28, 20]} />
        <meshPhysicalMaterial color="#fdba74" transparent opacity={0.18} roughness={0.2} side={THREE.DoubleSide} />
      </mesh>

      {stage === 1 && (
        /* BUD: simple epithelial sphere budding off the dental lamina */
        <group>
          <mesh position={[-2.6, 1.6, 0]} rotation={[0, 0, 0.5]}>
            <boxGeometry args={[3.4, 0.35, 1.6]} />
            <meshStandardMaterial color="#93c5fd" roughness={0.5} />
          </mesh>
          <mesh position={[0, 0.9, 0]} castShadow>
            <sphereGeometry args={[1.05, 24, 18]} />
            <meshStandardMaterial color="#60a5fa" roughness={0.4} />
          </mesh>
          {showLabels && <Text position={[0, 2.9, 0]} fontSize={0.42} color="#93c5fd">Enamel organ — bud</Text>}
        </group>
      )}

      {stage === 2 && (
        /* CAP: epithelium cups downward over the papilla */
        <group>
          <mesh position={[-2.9, 1.9, 0]} rotation={[0, 0, 0.5]}>
            <boxGeometry args={[3.2, 0.35, 1.6]} />
            <meshStandardMaterial color="#93c5fd" roughness={0.5} />
          </mesh>
          {/* cap = hemisphere shell + side walls */}
          <mesh position={[0, 0.7, 0]} castShadow>
            <sphereGeometry args={[1.5, 28, 16, 0, Math.PI * 2, 0, Math.PI * 0.62]} />
            <meshStandardMaterial color="#60a5fa" roughness={0.4} side={THREE.DoubleSide} />
          </mesh>
          {/* inner enamel epithelium lining */}
          <mesh position={[0, 0.62, 0]}>
            <sphereGeometry args={[1.32, 28, 16, 0, Math.PI * 2, 0, Math.PI * 0.62]} />
            <meshStandardMaterial color="#3b82f6" roughness={0.4} side={THREE.DoubleSide} />
          </mesh>
          {showLabels && (
            <>
              <Text position={[0, 3.1, 0]} fontSize={0.42} color="#93c5fd">Cap cups the papilla</Text>
              <Text position={[3.2, -0.9, 0]} fontSize={0.38} color="#fca5a5">Dental papilla → pulp</Text>
            </>
          )}
        </group>
      )}

      {stage === 3 && (
        /* BELL: crown shape defined; enamel (outer) + dentin (inner) layers */
        <group>
          {/* outer enamel layer */}
          <mesh position={[0, 0.75, 0]} castShadow>
            <sphereGeometry args={[1.55, 28, 18, 0, Math.PI * 2, 0, Math.PI * 0.58]} />
            <meshStandardMaterial color="#fef9c3" roughness={0.25} side={THREE.DoubleSide} />
          </mesh>
          {/* dentin under enamel */}
          <mesh position={[0, 0.68, 0]}>
            <sphereGeometry args={[1.28, 28, 18, 0, Math.PI * 2, 0, Math.PI * 0.58]} />
            <meshStandardMaterial color="#fde68a" roughness={0.35} side={THREE.DoubleSide} />
          </mesh>
          {/* ameloblast layer (blue rim) */}
          <mesh position={[0, 0.71, 0]}>
            <torusGeometry args={[1.42, 0.07, 8, 32, Math.PI]} />
            <meshBasicMaterial color="#3b82f6" />
          </mesh>
          {/* stratum intermedium + stellate reticulum hint */}
          <mesh position={[0, 1.9, 0]}>
            <sphereGeometry args={[0.75, 18, 12]} />
            <meshStandardMaterial color="#bfdbfe" transparent opacity={0.5} roughness={0.4} />
          </mesh>
          {showLabels && (
            <>
              <Text position={[-3.6, 1.8, 0]} fontSize={0.4} color="#fef9c3">Enamel (ameloblasts)</Text>
              <Text position={[3.6, 0.6, 0]} fontSize={0.4} color="#fde68a">Dentin (odontoblasts)</Text>
              <Text position={[0, 3.3, 0]} fontSize={0.42} color="#93c5fd">Bell — crown shape decided</Text>
            </>
          )}
        </group>
      )}

      {showLabels && (
        <Text position={[0, -3.4, 0]} fontSize={0.44} color="#fef3c7" maxWidth={10}>{SUB[stage - 1]}</Text>
      )}
    </group>
  );
}

export function Topic10372Sim(props: SimProps) {
  const stage = Math.round(Number(props.stage ?? 2));
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", STAGES[stage - 1]],
          ["Enamel organ", stage === 1 ? "bud" : stage === 2 ? "cap" : "bell"],
          ["Hard tissues", stage === 3 ? "forming ✓" : "not yet"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.5, 11]} target={[0, 0.3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -4.2, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <ToothGerm stage={stage} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
