// Strabismus, amblyopia & nystagmus — two eyes: one looks straight, the
// other turns inward (esotropia). Deviation slider turns it further;
// nystagmus toggle makes both eyes jiggle side to side.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "deviation", label: "Eye turn (deviation)", kind: "slider", min: 0, max: 60, step: 2, default: 32, unit: "°" },
  { key: "nystagmus", label: "Nystagmus", kind: "select", min: 0, max: 0, step: 1, default: "off", options: ["off", "on"] },
];

export const UNIQUE_META = {
  title: "Strabismus & Nystagmus",
  blurb: "One eye turns inward while the other looks straight — the brain ignores it (amblyopia). Add nystagmus to make both eyes dance.",
};

function Animator({ eyes, elapsed, deviation, nystagmus }: {
  eyes: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  deviation: number;
  nystagmus: boolean;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const jiggle = nystagmus ? Math.sin(t * 9) * 0.28 : 0;
    const dev = (deviation * Math.PI) / 180;
    if (eyes.current) {
      const [left, right] = eyes.current.children;
      // left eye stays on target (plus nystagmus), right eye turns inward
      left.rotation.y = jiggle * 0.5;
      right.rotation.y = -dev + jiggle * 0.5;
    }
  });
  return null;
}

function EyeBall({ x, pupilColor = "#0ea5e9" }: { x: number; pupilColor?: string }) {
  return (
    <group position={[x, 1.6, 0]}>
      <mesh castShadow>
        <sphereGeometry args={[1.15, 32, 24]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.35} />
      </mesh>
      <group position={[0, 0, 1.05]}>
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.42, 0.2, 12, 28]} />
          <meshStandardMaterial color={pupilColor} roughness={0.4} />
        </mesh>
        <mesh position={[0, 0, 0.12]}>
          <circleGeometry args={[0.24, 20]} />
          <meshStandardMaterial color="#020617" roughness={0.9} />
        </mesh>
        {/* glint */}
        <mesh position={[0.12, 0.14, 0.2]}>
          <sphereGeometry args={[0.05, 8, 8]} />
          <meshBasicMaterial color="#ffffff" />
        </mesh>
      </group>
    </group>
  );
}

export function Topic10209Sim(props: SimProps) {
  const deviation = Number(props.deviation ?? 32);
  const nystagmus = String(props.nystagmus ?? "off") === "on";
  const eyes = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Right eye turn", `${deviation}° inward`], ["Nystagmus", nystagmus ? "ON — eyes jiggling" : "off"], ["Risk", deviation > 20 ? "amblyopia (lazy eye)" : "mild"]]} />
      <SimCanvas cameraPosition={[0, 2, 10]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* face frame */}
        <mesh position={[0, 1.6, -1.6]} castShadow>
          <boxGeometry args={[6.4, 4.6, 1.2]} />
          <meshStandardMaterial color="#f5d0b8" roughness={0.65} />
        </mesh>
        <group ref={eyes}>
          <EyeBall x={-1.55} />
          <EyeBall x={1.55} pupilColor="#8b5cf6" />
        </group>

        {/* gaze lines: where each eye looks */}
        <mesh position={[-1.55, 1.6, 4.5]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.04, 0.04, 7, 6]} />
          <meshBasicMaterial color="#22c55e" transparent opacity={0.7} />
        </mesh>
        <group position={[1.55, 1.6, 1.0]} rotation={[0, -(deviation * Math.PI) / 180, 0]}>
          <mesh position={[0, 0, 3.5]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.04, 0.04, 7, 6]} />
            <meshBasicMaterial color="#ef4444" transparent opacity={0.7} />
          </mesh>
        </group>

        <Label text="Straight eye ✓" position={[-1.55, 3.6, 0]} size={0.5} color="#86efac" />
        <Label text={`Turned eye (${deviation}°)`} position={[1.55, 3.6, 0]} size={0.5} color="#fca5a5" />
        <Label text="Brain ignores the turned eye → it goes 'lazy' (amblyopia)" position={[0, -1.6, 0]} size={0.44} color="#fde047" />
        {nystagmus && <Label text="Nystagmus: rhythmic jiggling ⚠" position={[0, 4.5, 0]} size={0.5} color="#fca5a5" />}
        <Animator eyes={eyes} elapsed={elapsed} deviation={deviation} nystagmus={nystagmus} />
      </SimCanvas>
    </div>
  );
}
