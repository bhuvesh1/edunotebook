"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "abscess", options: ["pulpitis", "abscess", "granuloma"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Diseases of pulp and periapical tissues",
  blurb: "When the pulp dies, trouble brews at the root tip — throbbing pulpitis, a swelling abscess, or a quiet periapical granuloma.",
};

const INFO: Record<string, { name: string; apex: string; swell: number; note: string; pain: string }> = {
  pulpitis: { name: "Irreversible pulpitis", apex: "normal", swell: 0, note: "pulp inflamed but alive — hot/cold lingers", pain: "lingering pain ⚡" },
  abscess: { name: "Periapical abscess", apex: "radiolucent + swelling", swell: 1, note: "pus at the root tip — face swells", pain: "throbbing, severe ⚡⚡" },
  granuloma: { name: "Periapical granuloma", apex: "round radiolucency", swell: 0.25, note: "chronic low-grade — often painless", pain: "usually painless" },
};

function PeriapicalScene({ condition, speed, showLabels }: { condition: string; speed: number; showLabels: boolean }) {
  const lesion = useRef<THREE.Mesh>(null!);
  const swelling = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const info = INFO[condition] ?? INFO.abscess;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (lesion.current) {
      const pulse = 1 + Math.sin(elapsed.current * (condition === "pulpitis" ? 5 : 2.5)) * 0.1;
      const base = condition === "pulpitis" ? 0.35 : condition === "abscess" ? 1.15 : 0.8;
      lesion.current.scale.setScalar(base * pulse);
      (lesion.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.4 + Math.sin(elapsed.current * 4) * 0.2;
    }
    if (swelling.current) {
      const s = info.swell * (1 + Math.sin(elapsed.current * 2) * 0.06);
      swelling.current.scale.setScalar(Math.max(s, 0.001));
      swelling.current.visible = s > 0.05;
    }
  });

  return (
    <group>
      {/* jaw bone around root */}
      <mesh position={[0, -1.8, 0]} castShadow receiveShadow>
        <boxGeometry args={[6.8, 3.4, 3.6]} />
        <meshStandardMaterial color="#e7e5e4" roughness={0.8} />
      </mesh>
      {/* gum */}
      <mesh position={[0, 0.15, 0]} castShadow>
        <boxGeometry args={[6.8, 0.7, 3.6]} />
        <meshStandardMaterial color="#e88ca0" roughness={0.6} />
      </mesh>
      {/* tooth crown */}
      <mesh position={[0, 1.6, 0]} castShadow>
        <boxGeometry args={[2.4, 1.8, 2.2]} />
        <meshStandardMaterial color={condition === "pulpitis" ? "#fef9c3" : "#d9cfae"} roughness={0.3} />
      </mesh>
      {/* root */}
      <mesh position={[0, -1.4, 0]} castShadow>
        <cylinderGeometry args={[1.05, 0.3, 4.6, 16]} />
        <meshStandardMaterial color="#fde68a" roughness={0.4} />
      </mesh>
      {/* dead/inflamed pulp canal */}
      <mesh position={[0, -0.6, 0]}>
        <cylinderGeometry args={[0.4, 0.12, 4.4, 12]} />
        <meshStandardMaterial color={condition === "pulpitis" ? "#ef4444" : "#7f1d1d"} roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.6} />
      </mesh>
      {/* periapical lesion halo at apex */}
      <mesh ref={lesion} position={[0, -3.7, 0]}>
        <sphereGeometry args={[1, 20, 14]} />
        <meshStandardMaterial color={condition === "abscess" ? "#facc15" : "#fb923c"} transparent opacity={0.75} roughness={0.3} emissive={condition === "abscess" ? "#a16207" : "#7c2d12"} emissiveIntensity={0.4} />
      </mesh>
      {/* pus pocket core for abscess */}
      {condition === "abscess" && (
        <mesh position={[0, -3.7, 0]}>
          <sphereGeometry args={[0.5, 14, 10]} />
          <meshStandardMaterial color="#fefce8" roughness={0.4} emissive="#a16207" emissiveIntensity={0.3} />
        </mesh>
      )}
      {/* cheek swelling */}
      <mesh ref={swelling} position={[2.6, 0.6, 1.2]} scale={[0.001, 0.001, 0.001]} visible={false} castShadow>
        <sphereGeometry args={[1.3, 20, 14]} />
        <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.9} />
      </mesh>
      {/* pain bolts */}
      {(condition === "pulpitis" || condition === "abscess") &&
        [-0.8, 0.8].map((x, i) => (
          <mesh key={i} position={[x, 2.2 + (i % 2) * 0.8, 1.4]} rotation={[0, 0, 0.3]}>
            <coneGeometry args={[0.15, 0.75, 6]} />
            <meshBasicMaterial color="#facc15" />
          </mesh>
        ))}

      {showLabels && (
        <>
          <Text position={[0, 4.4, 0]} fontSize={0.46} color={condition === "abscess" ? "#fca5a5" : "#fbbf24"}>{info.name}</Text>
          <Text position={[-4.6, -3.7, 0]} fontSize={0.4} color="#fdba74" maxWidth={4}>Lesion at root apex: {info.apex}</Text>
          <Text position={[0, -6.2, 0]} fontSize={0.42} color="#fef3c7" maxWidth={10}>{info.note}</Text>
        </>
      )}
    </group>
  );
}

export function Topic10402Sim(props: SimProps) {
  const condition = String(props.condition ?? "abscess");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const info = INFO[condition] ?? INFO.abscess;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", info.name],
          ["Apex", info.apex],
          ["Pain", info.pain],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 13]} target={[0, -1, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -4.2, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <PeriapicalScene condition={condition} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
