// app/components/sims/unique/_dental.tsx
// Shared stylized dental building blocks for the dental unique sims.
// No external assets — pure three.js primitives.

"use client";

import { useMemo } from "react";
import * as THREE from "three";

type V3 = [number, number, number];

export function Tooth({
  position = [0, 0, 0] as V3,
  scale = 1,
  enamel = "#f1e9d2",
  showCanal = false,
  infected = false,
  tilt = 0,
  name = "",
}: {
  position?: V3;
  scale?: number;
  enamel?: string;
  showCanal?: boolean;
  infected?: boolean;
  tilt?: number;
  name?: string;
}) {
  const rootColor = infected ? "#caa06b" : "#e6dabd";
  const canalColor = infected ? "#ef4444" : "#f06292";
  const eMat = { color: enamel, roughness: 0.35 };
  return (
    <group position={position} rotation={[0, 0, tilt]} scale={scale} name={name}>
      {/* roots */}
      {[-0.28, 0.28].map((x, i) => (
        <mesh key={i} position={[x, -0.62, 0]} rotation={[Math.PI, 0, 0]}>
          <coneGeometry args={[0.2, 1.05, 12]} />
          <meshStandardMaterial
            color={rootColor}
            roughness={0.6}
            transparent={showCanal}
            opacity={showCanal ? 0.4 : 1}
          />
        </mesh>
      ))}
      {/* crown */}
      <mesh position={[0, 0.14, 0]} name={name ? `${name}-crownMesh` : "crownMesh"}>
        <cylinderGeometry args={[0.6, 0.48, 0.78, 16]} />
        <meshStandardMaterial
          {...eMat}
          transparent={showCanal}
          opacity={showCanal ? 0.4 : 1}
        />
      </mesh>
      {/* cusps */}
      {[
        [-0.28, -0.2],
        [0.28, -0.2],
        [-0.28, 0.2],
        [0.28, 0.2],
      ].map((p, i) => (
        <mesh key={i} position={[p[0], 0.58, p[1]]}>
          <sphereGeometry args={[0.19, 12, 12]} />
          <meshStandardMaterial
            {...eMat}
            transparent={showCanal}
            opacity={showCanal ? 0.4 : 1}
          />
        </mesh>
      ))}
      {/* canal / pulp */}
      {showCanal && (
        <group>
          <mesh position={[0, -0.35, 0]}>
            <cylinderGeometry args={[0.075, 0.06, 1.9, 8]} />
            <meshStandardMaterial
              color={canalColor}
              emissive={canalColor}
              emissiveIntensity={0.7}
              roughness={0.4}
            />
          </mesh>
          <mesh position={[0, 0.14, 0]}>
            <sphereGeometry args={[0.17, 12, 12]} />
            <meshStandardMaterial
              color={canalColor}
              emissive={canalColor}
              emissiveIntensity={0.7}
              roughness={0.4}
            />
          </mesh>
        </group>
      )}
    </group>
  );
}

/** Pink gum slab (a ridge the teeth sit in). */
export function GumSlab({
  position = [0, 0, 0] as V3,
  scale = 1,
  color = "#e0808f",
  name = "",
}: {
  position?: V3;
  scale?: number;
  color?: string;
  name?: string;
}) {
  return (
    <mesh position={position} scale={scale} name={name} castShadow receiveShadow>
      <boxGeometry args={[7, 0.9, 2.4]} />
      <meshStandardMaterial color={color} roughness={0.7} />
    </mesh>
  );
}

/** Tan alveolar bone block. */
export function BoneBlock({
  position = [0, 0, 0] as V3,
  scale = 1,
  color = "#cbb894",
  name = "",
}: {
  position?: V3;
  scale?: number;
  color?: string;
  name?: string;
}) {
  return (
    <mesh position={position} scale={scale} name={name} castShadow receiveShadow>
      <boxGeometry args={[7, 2.2, 2]} />
      <meshStandardMaterial color={color} roughness={0.9} />
    </mesh>
  );
}

/** Curved tube through 3D points — archwires, nerves, splints. */
export function Wire({
  points,
  color = "#cbd5e1",
  radius = 0.045,
  name = "",
}: {
  points: V3[];
  color?: string;
  radius?: number;
  name?: string;
}) {
  const geo = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(
      points.map((p) => new THREE.Vector3(p[0], p[1], p[2]))
    );
    return new THREE.TubeGeometry(curve, 40, radius, 8, false);
  }, [points, radius]);
  return (
    <mesh geometry={geo} name={name}>
      <meshStandardMaterial color={color} metalness={0.85} roughness={0.3} />
    </mesh>
  );
}
