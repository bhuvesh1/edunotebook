"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Rotation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 0.6, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Pelvis: pelvic viscera, perineum, urogenital diaphragm",
  blurb: "The bony pelvic bowl cradling the bladder — the ring that carries the body's weight into the legs.",
};

function Pelvis({ speed }: { speed: number }) {
  const g = useRef<THREE.Group>(null!);
  const bladder = useRef<THREE.Mesh>(null!);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d * speed;
    if (g.current) g.current.rotation.y = t.current * 0.5;
    if (bladder.current) bladder.current.scale.setScalar(1 + Math.sin(t.current * 1.8) * 0.08);
  });
  const bone = { color: "#f5f0e6", roughness: 0.55 };
  return (
    <group ref={g} position={[0, 0.8, 0]}>
      {/* two hip bones (ilia): curved blades */}
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * 1.5, 3.6, 0]} rotation={[0, s * 0.5, s * -0.35]} castShadow>
            <boxGeometry args={[0.4, 2.4, 2.0]} />
            <meshStandardMaterial {...bone} />
          </mesh>
          <mesh position={[s * 0.9, 2.3, 0.6]} rotation={[0, 0, s * -0.5]} castShadow>
            <boxGeometry args={[1.4, 0.45, 0.5]} />
            <meshStandardMaterial {...bone} />
          </mesh>
        </group>
      ))}
      {/* sacrum at the back */}
      <mesh position={[0, 3.2, -1.15]} rotation={[0.25, 0, 0]} castShadow>
        <boxGeometry args={[0.9, 2.2, 0.5]} />
        <meshStandardMaterial color="#e7e5e4" roughness={0.6} />
      </mesh>
      {/* pubic symphysis front */}
      <mesh position={[0, 2.1, 1.25]} castShadow>
        <boxGeometry args={[0.7, 0.6, 0.4]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      {/* obturator foramina hint */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 1.05, 2.9, 0.35]} rotation={[0, s * 0.4, 0]}>
          <torusGeometry args={[0.4, 0.12, 10, 20]} />
          <meshStandardMaterial {...bone} />
        </mesh>
      ))}
      {/* bladder inside the bowl */}
      <mesh ref={bladder} position={[0, 2.6, 0.2]} castShadow>
        <sphereGeometry args={[0.62, 20, 20]} />
        <meshStandardMaterial color="#fde047" roughness={0.4} transparent opacity={0.85} emissive="#a16207" emissiveIntensity={0.3} />
      </mesh>
      {/* urethra */}
      <mesh position={[0, 1.7, 0.2]} castShadow>
        <cylinderGeometry args={[0.1, 0.1, 0.7, 10]} />
        <meshStandardMaterial color="#facc15" roughness={0.5} />
      </mesh>
    </group>
  );
}

export function Topic10007Sim(props: SimProps) {
  const speed = Number(props.speed ?? 0.6);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Bones", "2 hip + sacrum"], ["Viscus", "bladder"], ["Joint", "pubic symphysis"]]} />
      <SimCanvas cameraPosition={[6.5, 4.5, 10]} target={[0, 2.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Pelvis speed={speed} />
        {showLabels && (
          <>
            <Label text="Hip bone (ilium)" position={[-3.4, 4.8, 0]} color="#fef3c7" size={0.5} />
            <Label text="Bladder" position={[2.6, 3.4, 0]} color="#fde047" size={0.5} />
            <Label text="Sacrum" position={[2.2, 4.6, -1.4]} color="#e7e5e4" size={0.45} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
