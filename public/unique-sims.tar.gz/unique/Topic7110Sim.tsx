// app/components/sims/unique/Topic7110Sim.tsx
// Angular displacement, velocity and acceleration: a spinning wheel.
// The yellow arc shows the angle θ swept since the last reset, the
// curved arrow shows the angular velocity ω, and the readouts track
// θ, ω (α = 0 at constant spin).

"use client";

import { useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "omega", label: "Angular velocity ω", kind: "slider", min: 0.2, max: 3, step: 0.1, default: 1.2, unit: "rad/s" },
];

export const UNIQUE_META = {
  title: "Angular Displacement, Velocity and Acceleration",
  blurb: "A spinning wheel: the yellow arc is the swept angle θ, the curved arrow is ω.",
};

const WR = 2.6;

function Animator({
  wheel, arcLine, arcGeo, omega, theta, bump,
}: {
  wheel: RefObject<THREE.Group>;
  arcLine: RefObject<THREE.Line>;
  arcGeo: THREE.BufferGeometry;
  omega: number;
  theta: RefObject<number>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const th = (t.current * omega) % (Math.PI * 2);
    theta.current = th;
    if (wheel.current) wheel.current.rotation.z = -t.current * omega;
    // Redraw the swept-angle arc from 0 to th.
    const pos = arcGeo.attributes.position as THREE.BufferAttribute;
    const AN = 48;
    for (let i = 0; i < AN; i++) {
      const a = (i / (AN - 1)) * th;
      pos.setXYZ(i, Math.cos(a) * (WR + 0.55), Math.sin(a) * (WR + 0.55), 0);
    }
    pos.needsUpdate = true;
    if (arcLine.current) arcLine.current.geometry.setDrawRange(0, AN);
    if (++n.current % 20 === 0) bump();
  });
  return null;
}

export function Topic7110Sim(props: SimProps) {
  const omega = Number(props.omega ?? 1.2);
  const wheel = useRef<THREE.Group>(null!);
  const arcLine = useRef<THREE.Line>(null!);
  const theta = useRef(0);
  const [, bump] = useState(0);

  const arcGeo = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(48 * 3), 3));
    return geo;
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["θ swept", `${theta.current.toFixed(2)} rad`],
          ["ω", `${omega.toFixed(1)} rad/s`],
          ["α", "0 (constant spin)"],
          ["🟡 Arc", "angular displacement"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.5, 11]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* stand */}
        <mesh position={[0, 1.1, -0.5]} castShadow>
          <boxGeometry args={[0.5, 2.2, 0.5]} />
          <meshStandardMaterial color="#475569" roughness={0.6} metalness={0.4} />
        </mesh>
        <mesh position={[0, 0.15, -0.5]}>
          <boxGeometry args={[2.2, 0.3, 1.6]} />
          <meshStandardMaterial color="#334155" roughness={0.7} />
        </mesh>

        <group position={[0, 2.6, 0]}>
          {/* hub */}
          <mesh castShadow>
            <cylinderGeometry args={[0.35, 0.35, 0.5, 20]} />
            <meshStandardMaterial color="#94a3b8" roughness={0.4} metalness={0.6} />
          </mesh>
          {/* spinning wheel */}
          <group ref={wheel}>
            <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
              <torusGeometry args={[WR, 0.28, 14, 48]} />
              <meshStandardMaterial color="#38bdf8" roughness={0.4} metalness={0.3} />
            </mesh>
            {[0, Math.PI / 2].map((a) => (
              <mesh key={a} rotation={[0, 0, a]}>
                <boxGeometry args={[0.22, WR * 2 - 0.4, 0.22]} />
                <meshStandardMaterial color="#0ea5e9" roughness={0.45} />
              </mesh>
            ))}
            {/* marker dot on rim */}
            <mesh position={[WR, 0, 0.3]}>
              <sphereGeometry args={[0.22, 16, 16]} />
              <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.8} />
            </mesh>
          </group>
          {/* swept-angle arc */}
          <primitive object={new THREE.Line(arcGeo, new THREE.LineBasicMaterial({ color: "#fbbf24" }))} ref={arcLine} />
          {/* curved ω arrow */}
          <mesh position={[0, WR + 1.15, 0]} rotation={[0, 0, -Math.PI / 2]}>
            <torusGeometry args={[0.55, 0.09, 10, 24, Math.PI * 1.2]} />
            <meshStandardMaterial color="#22c55e" emissive="#15803d" emissiveIntensity={0.6} roughness={0.4} />
          </mesh>
        </group>

        <Animator wheel={wheel} arcLine={arcLine} arcGeo={arcGeo} omega={omega} theta={theta} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
