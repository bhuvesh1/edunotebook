"use client";
// Gingival Diseases: Plaque vs Non-Plaque — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "type", label: "Show", kind: "select", min: 0, max: 0, step: 1, default: "Plaque-induced", options: ["Plaque-induced", "Non-plaque (viral)"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Gingival Diseases: Plaque vs Non-Plaque",
  blurb: "Two sore gums, two causes: one from plaque buildup, one from a virus — spot the difference.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const pl: any = g("plaqueside");
    const np: any = g("nonplaqueside");
    const focusP = p.type === "Plaque-induced";
    if (pl) pl.scale.setScalar(focusP ? 1.08 : 0.95);
    if (np) np.scale.setScalar(focusP ? 0.95 : 1.08);
    const blist: any = g("blisters");
    if (blist) blist.visible = true;
    group.current.rotation.y = Math.sin(t * 0.2) * 0.15;
  });
  return null;
}

export function Topic10481Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const type = String(props.type ?? "Plaque-induced");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, type };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Plaque-induced", "Bacterial biofilm cause"],
          ["Non-plaque", "Viral / systemic cause"],
          ["Focused", type],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <group name="plaqueside" position={[-2.4, 1.2, 0]}>
            <Tooth scale={1.2} />
            <mesh position={[0, 0.9, 0]}>
              <boxGeometry args={[2.6, 0.7, 1.8]} />
              <meshStandardMaterial color="#d96a7a" roughness={0.6} />
            </mesh>
            {[0, 1, 2, 3].map((i) => (
              <mesh key={i} position={[-0.6 + i * 0.4, 1.35, 0.7]}>
                <sphereGeometry args={[0.12, 8, 8]} />
                <meshStandardMaterial color="#65a30d" roughness={0.9} />
              </mesh>
            ))}
            <Label text="Plaque-induced" position={[0, 2.9, 0]} size={0.42} color="#84cc16" />
          </group>
          <group name="nonplaqueside" position={[2.4, 1.2, 0]}>
            <Tooth scale={1.2} />
            <mesh position={[0, 0.9, 0]}>
              <boxGeometry args={[2.6, 0.7, 1.8]} />
              <meshStandardMaterial color="#c94f5e" roughness={0.6} />
            </mesh>
            <group name="blisters">
              {[0, 1, 2].map((i) => (
                <mesh key={i} position={[-0.5 + i * 0.5, 1.3, 0.75]}>
                  <sphereGeometry args={[0.16, 10, 10]} />
                  <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.5} roughness={0.3} />
                </mesh>
              ))}
            </group>
            <Label text="Non-plaque (viral)" position={[0, 2.9, 0]} size={0.42} color="#ef4444" />
          </group>
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
