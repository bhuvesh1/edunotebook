"use client";
// Periodontitis: Chronic, Aggressive, Necrotizing — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "type", label: "Type", kind: "select", min: 0, max: 0, step: 1, default: "Chronic", options: ["Chronic", "Aggressive", "Necrotizing"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Periodontitis: Chronic, Aggressive, Necrotizing",
  blurb: "Three teeth, three destruction patterns — even bone loss, a deep angular crater, or punched-out dead gum.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const names = ["chronicG", "aggrG", "necroG"];
    const sel = p.type === "Chronic" ? 0 : p.type === "Aggressive" ? 1 : 2;
    names.forEach((nm, i) => {
      const m: any = g(nm);
      if (m) m.scale.setScalar(i === sel ? 1.07 + 0.02 * Math.sin(t * 3) : 0.96);
    });
    group.current.rotation.y = Math.sin(t * 0.2) * 0.15;
  });
  return null;
}

export function Topic10483Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const type = String(props.type ?? "Chronic");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, type };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Chronic", "Horizontal bone loss"],
          ["Aggressive", "Vertical angular defect"],
          ["Necrotizing", "Dead papilla, pain"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <group name="chronicG" position={[-3.4, 1, 0]}>
            <Tooth scale={1.2} />
            <mesh position={[0, 0.1, 0]}>
              <boxGeometry args={[2.8, 1.1, 1.6]} />
              <meshStandardMaterial color="#cbb894" roughness={0.9} />
            </mesh>
            <Label text="Chronic: even loss" position={[0, 2.9, 0]} size={0.4} />
          </group>
          <group name="aggrG" position={[0, 1, 0]}>
            <Tooth scale={1.2} />
            <mesh position={[-0.7, 0.35, 0]}>
              <boxGeometry args={[1.4, 1.6, 1.6]} />
              <meshStandardMaterial color="#cbb894" roughness={0.9} />
            </mesh>
            <mesh position={[0.75, -0.15, 0]}>
              <boxGeometry args={[1.3, 0.6, 1.6]} />
              <meshStandardMaterial color="#8a6f4d" roughness={0.9} />
            </mesh>
            <Label text="Aggressive: angular crater" position={[0, 2.9, 0]} size={0.4} color="#ef4444" />
          </group>
          <group name="necroG" position={[3.4, 1, 0]}>
            <Tooth scale={1.2} infected />
            <mesh position={[0, 1.15, 0]}>
              <boxGeometry args={[2.4, 0.7, 1.6]} />
              <meshStandardMaterial color="#5b2b16" roughness={0.8} />
            </mesh>
            <mesh position={[0, 0.1, 0]}>
              <boxGeometry args={[2.8, 1.1, 1.6]} />
              <meshStandardMaterial color="#cbb894" roughness={0.9} />
            </mesh>
            <Label text="Necrotizing: dead gum" position={[0, 2.9, 0]} size={0.4} color="#7c2d12" />
          </group>
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
