"use client";

// Salivary gland disorders: xerostomia, sialadenitis, sialolithiasis.
// A stylized head shows the parotid and submandibular glands.
// A stone can block the duct; infection swells the parotid;
// xerostomia leaves the mouth dry.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Disorder", kind: "select", min: 0, max: 0, step: 1, default: "normal", options: ["normal", "sialolithiasis", "sialadenitis", "xerostomia"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Salivary Gland Disorders",
  blurb: "A stone blocking the duct (sialolithiasis), a swollen infected parotid (sialadenitis), or a dry mouth (xerostomia).",
};

type P = [number, number, number];
type Ref = { current: THREE.Group | null };

const DUCT_A: P = [0.72, 1.05, 0.45];
const DUCT_B: P = [1.35, 1.6, 0.75];

function lerpP(a: P, b: P, t: number): P {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
}

function Animator({ parotid, stone, drops, elapsed, speed, condition }: { parotid: Ref; stone: Ref; drops: Ref; elapsed: { current: number }; speed: number; condition: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const e = elapsed.current;
    if (parotid.current) {
      const inflamed = condition === "sialadenitis";
      const s = inflamed ? 1.18 + 0.14 * Math.sin(e * 4) : 1;
      parotid.current.scale.set(s, s * 0.75, s * 0.6);
    }
    if (stone.current) {
      const t = (Math.sin(e * 0.9) + 1) / 2;
      const p = lerpP(DUCT_A, DUCT_B, 0.25 + t * 0.5);
      stone.current.position.set(p[0], p[1], p[2]);
      stone.current.visible = condition === "sialolithiasis";
    }
    if (drops.current) {
      const blocked = condition === "sialolithiasis";
      const dry = condition === "xerostomia";
      drops.current.visible = !dry;
      drops.current.children.forEach((m, i) => {
        const t = blocked ? 0.12 + (i / 6) * 0.1 : (e * 0.5 + i / 6) % 1;
        const p = lerpP(DUCT_A, DUCT_B, t);
        m.position.set(p[0], p[1], p[2]);
      });
    }
  });
  return null;
}

export function Topic10520Sim(props: SimProps) {
  const condition = String(props.condition ?? "normal");
  const speed = Number(props.speed ?? 1);

  const parotid = useRef<THREE.Group>(null!);
  const stone = useRef<THREE.Group>(null!);
  const drops = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const facts: Record<string, string> = {
    normal: "Saliva keeps the mouth moist and starts digestion.",
    sialolithiasis: "A stone (sialolith) blocks the duct — pain swells at mealtimes.",
    sialadenitis: "Infected parotid: hot, red, swollen, tender.",
    xerostomia: "Dry mouth: too little saliva — caries risk rises.",
  };
  const names: Record<string, string> = {
    normal: "Normal",
    sialolithiasis: "Sialolithiasis",
    sialadenitis: "Sialadenitis",
    xerostomia: "Xerostomia",
  };

  const ductMid = useMemo(() => lerpP(DUCT_A, DUCT_B, 0.5), []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Disorder", names[condition]],
          ["Key fact", facts[condition]],
        ]}
      />
      <SimCanvas cameraPosition={[5.5, 3, 9]} target={[0.4, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* head */}
        <mesh position={[0, 2.3, -0.2]} castShadow>
          <sphereGeometry args={[1.55, 28, 28]} />
          <meshStandardMaterial color="#eab88f" roughness={0.7} />
        </mesh>
        {/* ear */}
        <mesh position={[1.42, 2.55, -0.2]}>
          <sphereGeometry args={[0.42, 16, 16]} />
          <meshStandardMaterial color="#eab88f" roughness={0.7} />
        </mesh>
        {/* jaw hint */}
        <mesh position={[0.72, 1.32, 0.15]} rotation={[0, 0, -0.18]}>
          <boxGeometry args={[1.5, 0.24, 0.9]} />
          <meshStandardMaterial color="#dfa878" roughness={0.7} />
        </mesh>

        {/* parotid gland (near ear / jaw angle) */}
        <group ref={parotid} position={[1.0, 2.42, 0.18]}>
          <mesh castShadow>
            <sphereGeometry args={[0.5, 20, 20]} />
            <meshStandardMaterial color={condition === "sialadenitis" ? "#ef4444" : "#f9a8d4"} roughness={0.5} />
          </mesh>
        </group>

        {/* submandibular gland (under jaw) */}
        <mesh position={[0.72, 1.0, 0.28]} castShadow>
          <sphereGeometry args={[0.32, 18, 18]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
        </mesh>

        {/* Wharton duct */}
        <mesh position={ductMid} rotation={[0.35, 0, -1.05]}>
          <cylinderGeometry args={[0.05, 0.05, 1.05, 8]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.4} />
        </mesh>

        {/* sialolith stone travelling the duct */}
        <group ref={stone}>
          <mesh castShadow>
            <sphereGeometry args={[0.17, 14, 14]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.3} />
          </mesh>
        </group>

        {/* saliva droplets */}
        <group ref={drops}>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i}>
              <sphereGeometry args={[0.07, 8, 8]} />
              <meshStandardMaterial color="#38bdf8" emissive="#0ea5e9" emissiveIntensity={0.7} />
            </mesh>
          ))}
        </group>

        {/* dry tongue for xerostomia */}
        {condition === "xerostomia" && (
          <mesh position={[1.52, 1.55, 0.72]} rotation={[0, 0.3, 0]}>
            <boxGeometry args={[0.5, 0.12, 0.34]} />
            <meshStandardMaterial color="#d98c8c" roughness={1} />
          </mesh>
        )}

        <Label text="Parotid gland" position={[1.0, 3.35, 0.2]} size={0.45} color="#f9a8d4" />
        <Label text="Submandibular gland" position={[0.72, 0.35, 0.3]} size={0.42} color="#f9a8d4" />
        {condition === "sialolithiasis" && (
          <Label text="Stone blocks the duct!" position={[1.05, 0.6, 1.3]} size={0.5} color="#fbbf24" />
        )}
        {condition === "sialadenitis" && (
          <Label text="Swollen, painful parotid" position={[1.0, 3.35, 0.2]} size={0.45} color="#ef4444" />
        )}
        {condition === "xerostomia" && (
          <Label text="Dry mouth — no saliva" position={[1.55, 2.2, 0.9]} size={0.48} color="#fbbf24" />
        )}
        <Animator parotid={parotid} stone={stone} drops={drops} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
