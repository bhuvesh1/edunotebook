// app/components/sims/unique/Topic7111Sim.tsx
// Aristotle's fallacy vs Galileo's insight: from the Leaning Tower of
// Pisa a heavy iron ball and a light wooden ball are dropped together.
// Aristotle said the heavy one lands first — both hit the ground at the
// same instant. Galileo was right.

"use client";

import { useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Fall speed", kind: "slider", min: 0.5, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Aristotle's Fallacy and Galileo's Insight",
  blurb: "Heavy vs light ball dropped from the Leaning Tower — they land together. Galileo wins.",
};

const H = 6.6;
const G = 9.8;

function Animator({
  heavy, light, speed, state, bump,
}: {
  heavy: RefObject<THREE.Mesh>;
  light: RefObject<THREE.Mesh>;
  speed: number;
  state: RefObject<{ t: number; landed: boolean }>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta * speed;
    const fallT = Math.sqrt((2 * H) / G);
    const cycle = fallT + 1.6;
    const T = t.current % cycle;
    const s = T <= fallT ? 0.5 * G * T * T : H;
    state.current = { t: Math.min(T, fallT), landed: T > fallT };
    const y = 0.45 + H - s;
    if (heavy.current) heavy.current.position.y = y;
    if (light.current) light.current.position.y = y;
    if (++n.current % 15 === 0) bump();
  });
  return null;
}

export function Topic7111Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const heavy = useRef<THREE.Mesh>(null!);
  const light = useRef<THREE.Mesh>(null!);
  const state = useRef({ t: 0, landed: false });
  const [, bump] = useState(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Heavy ball time", `${state.current.t.toFixed(2)} s`],
          ["Light ball time", `${state.current.t.toFixed(2)} s`],
          ["Result", state.current.landed ? "tied — Galileo ✓" : "falling…"],
        ]}
      />
      <SimCanvas cameraPosition={[2, 5, 14]} target={[0, 3.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* Leaning Tower of Pisa: stacked, shrinking, tilted cylinders */}
        <group position={[-3.2, 0, 0]} rotation={[0, 0, 0.14]}>
          {[2.2, 1.95, 1.7, 1.45, 1.2].map((r, i) => (
            <mesh key={i} position={[0, 0.7 + i * 1.35, 0]} castShadow>
              <cylinderGeometry args={[r, r + 0.12, 1.3, 20]} />
              <meshStandardMaterial color={i % 2 ? "#e7e5e4" : "#d6d3d1"} roughness={0.8} />
            </mesh>
          ))}
          <mesh position={[0, 0.7 + 5 * 1.35, 0]} castShadow>
            <cylinderGeometry args={[1.5, 1.5, 0.35, 20]} />
            <meshStandardMaterial color="#a8a29e" roughness={0.8} />
          </mesh>
        </group>

        {/* drop platform extending from the tower top */}
        <mesh position={[0.6, H + 0.75, 0]} castShadow>
          <boxGeometry args={[4.6, 0.3, 1.8]} />
          <meshStandardMaterial color="#78716c" roughness={0.8} />
        </mesh>

        {/* heavy iron ball */}
        <mesh ref={heavy} position={[-0.5, 0.45 + H, 0]} castShadow>
          <sphereGeometry args={[0.45, 28, 28]} />
          <meshStandardMaterial color="#1f2937" roughness={0.3} metalness={0.6} />
        </mesh>
        {/* light wooden ball */}
        <mesh ref={light} position={[1.3, 0.45 + H, 0]} castShadow>
          <sphereGeometry args={[0.32, 24, 24]} />
          <meshStandardMaterial color="#fde68a" roughness={0.7} />
        </mesh>

        {/* landing pads */}
        {[-0.5, 1.3].map((x) => (
          <mesh key={x} position={[x, 0.08, 0]}>
            <cylinderGeometry args={[0.55, 0.55, 0.16, 20]} />
            <meshStandardMaterial color="#22c55e" roughness={0.6} />
          </mesh>
        ))}

        <Animator heavy={heavy} light={light} speed={speed} state={state} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
