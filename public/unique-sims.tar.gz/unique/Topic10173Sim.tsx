"use client";
// Nutrition: assessment, deficiency disorders, food fortification.
// A dinner plate split into food groups spins gently; pick a group to
// see which deficiency it prevents, plus a growth chart for assessment.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "group", label: "Food group", kind: "select", min: 0, max: 0, step: 1, default: "grains", options: ["grains", "protein", "veggies", "dairy"] },
  { key: "speed", label: "Spin speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Nutrition: The Balanced Plate",
  blurb: "Spin the balanced plate and tap each food group to learn which deficiency disease it keeps away.",
};

const GROUPS: Record<string, { color: string; emoji: string; prevents: string }> = {
  grains: { color: "#fbbf24", emoji: "🌾", prevents: "Energy — prevents weakness" },
  protein: { color: "#f87171", emoji: "🫘", prevents: "Protein — prevents kwashiorkor" },
  veggies: { color: "#4ade80", emoji: "🥬", prevents: "Vitamin A — prevents night blindness" },
  dairy: { color: "#e0f2fe", emoji: "🥛", prevents: "Calcium — prevents rickets" },
};
const ORDER = ["grains", "protein", "veggies", "dairy"];

function Animator({ plate, elapsed, speed }: { plate: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (plate.current) plate.current.rotation.y = elapsed.current * 0.5;
  });
  return null;
}

export function Topic10173Sim(props: SimProps) {
  const group = String(props.group ?? "grains");
  const speed = Number(props.speed ?? 1);
  const plate = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = GROUPS[group] ?? GROUPS.grains;
  const activeIdx = ORDER.indexOf(group);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Food group", `${info.emoji} ${group}`], ["Prevents", info.prevents]]} />
      <SimCanvas cameraPosition={[0, 5, 12]} target={[0, 1, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* table */}
        <mesh position={[0, 0.4, 0]} receiveShadow>
          <cylinderGeometry args={[5.4, 5.4, 0.8, 28]} />
          <meshStandardMaterial color="#5b3a1e" roughness={0.85} />
        </mesh>
        {/* plate with 4 food wedges */}
        <group position={[0, 1.4, 0]}>
          <mesh receiveShadow>
            <cylinderGeometry args={[3.4, 3, 0.35, 28]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <group ref={plate} position={[0, 0.25, 0]}>
            {ORDER.map((g, i) => (
              <mesh key={g} position={[0, 0.12, 0]} rotation={[0, (i / 4) * Math.PI * 2, 0]}>
                <cylinderGeometry args={[2.5, 2.5, 0.28, 12, 1, false, -Math.PI / 4, Math.PI / 2]} />
                <meshStandardMaterial
                  color={GROUPS[g].color}
                  roughness={0.6}
                  emissive={i === activeIdx ? GROUPS[g].color : "#000000"}
                  emissiveIntensity={i === activeIdx ? 0.55 : 0}
                />
              </mesh>
            ))}
          </group>
          <Label text="BALANCED PLATE" position={[0, 2.6, 0]} size={0.65} color="#fbbf24" />
        </group>
        {/* growth chart */}
        <group position={[6.4, 0, -1]}>
          <mesh position={[0, 2.2, 0]} castShadow>
            <boxGeometry args={[2.6, 4.4, 0.15]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.8} />
          </mesh>
          {[0.8, 1.9, 3.0].map((y, i) => (
            <mesh key={y} position={[-0.9 + i * 0.5, y, 0.1]} rotation={[0, 0, -0.5]}>
              <boxGeometry args={[0.9, 0.09, 0.04]} />
              <meshStandardMaterial color={i === 2 ? "#22c55e" : "#94a3b8"} roughness={0.6} />
            </mesh>
          ))}
          <Label text="GROWTH CHART" position={[0, 4.9, 0]} size={0.55} color="#4ade80" />
          <Label text="assessment" position={[0, -0.4, 0]} size={0.5} color="#94a3b8" />
        </group>
        {/* fortification: salt with + */}
        <group position={[-6.4, 0, -1]}>
          <mesh position={[0, 1.1, 0]} castShadow>
            <cylinderGeometry args={[0.7, 0.7, 1.4, 14]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.6} />
          </mesh>
          <mesh position={[0, 2, 0]}>
            <cylinderGeometry args={[0.75, 0.75, 0.2, 14]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.6} />
          </mesh>
          <Label text="+ IODINE" position={[0, 2.6, 0]} size={0.55} color="#7dd3fc" />
          <Label text="fortified salt" position={[0, 0.2, 0]} size={0.5} color="#94a3b8" />
        </group>
        <Animator plate={plate} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
