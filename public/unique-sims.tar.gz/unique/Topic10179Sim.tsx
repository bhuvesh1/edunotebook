"use client";
// National programs: RCH, adolescent health, NCD program.
// A family — mother, teenager, child — with pulsing care rings;
// pick the program to light up who it protects.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "program", label: "Program", kind: "select", min: 0, max: 0, step: 1, default: "rch", options: ["rch", "adolescent", "ncd"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "RCH, Adolescent Health & NCD Program",
  blurb: "One family, three programs: mothers and babies, teenagers, and adults fighting lifestyle disease — each with its own care ring.",
};

const PROG_TXT: Record<string, string> = {
  rch: "RCH: safe mothers, healthy babies",
  adolescent: "Adolescent health: nutrition & counselling (RKSK)",
  ncd: "NCD program: screen adults for BP, sugar, cancer",
};
const PROG_WHO: Record<string, number[]> = { rch: [0, 2], adolescent: [1], ncd: [0] };

function Animator({ rings, elapsed, speed, program }: { rings: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number; program: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (rings.current) {
      rings.current.children.forEach((r, i) => {
        const on = (PROG_WHO[program] ?? []).includes(i);
        const s = 1 + Math.sin(elapsed.current * 2.2 + i) * 0.08;
        r.scale.set(s, s, s);
        (r as THREE.Mesh).visible = on;
      });
    }
  });
  return null;
}

function Person({ x, h, color, label, labelColor }: { x: number; h: number; color: string; label: string; labelColor: string }) {
  return (
    <group position={[x, 0, 0]}>
      <mesh position={[0, h * 0.42, 0]} castShadow>
        <capsuleGeometry args={[h * 0.2, h * 0.45, 6, 12]} />
        <meshStandardMaterial color={color} roughness={0.7} />
      </mesh>
      <mesh position={[0, h * 0.88, 0]} castShadow>
        <sphereGeometry args={[h * 0.16, 16, 16]} />
        <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
      </mesh>
      <Label text={label} position={[0, h * 1.15, 0]} size={0.55} color={labelColor} />
    </group>
  );
}

export function Topic10179Sim(props: SimProps) {
  const program = String(props.program ?? "rch");
  const speed = Number(props.speed ?? 1);
  const rings = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Program", program.toUpperCase()], ["Protects", PROG_TXT[program] ?? ""]]} />
      <SimCanvas cameraPosition={[0, 3.2, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Person x={-3.6} h={2.6} color="#f9a8d4" label="MOTHER" labelColor="#f9a8d4" />
        <Person x={0} h={2.2} color="#7dd3fc" label="TEENAGER" labelColor="#7dd3fc" />
        <Person x={3.6} h={1.4} color="#fde68a" label="CHILD" labelColor="#fde68a" />
        {/* care rings */}
        <group ref={rings}>
          {[-3.6, 0, 3.6].map((x, i) => (
            <mesh key={x} position={[x, 0.12, 0]} rotation={[-Math.PI / 2, 0, 0]}>
              <ringGeometry args={[1.25, 1.5, 32]} />
              <meshStandardMaterial color={["#f472b6", "#38bdf8", "#fbbf24"][i]} emissive={["#ec4899", "#0ea5e9", "#f59e0b"][i]} emissiveIntensity={0.8} transparent opacity={0.85} side={THREE.DoubleSide} />
            </mesh>
          ))}
        </group>
        {/* program badge */}
        <group position={[0, 5.2, -2]}>
          <mesh castShadow>
            <cylinderGeometry args={[1, 1, 0.25, 6]} />
            <meshStandardMaterial color="#8b5cf6" metalness={0.5} roughness={0.35} />
          </mesh>
          <Label text={program.toUpperCase()} position={[0, 0, 0.2]} size={0.55} color="#ffffff" />
        </group>
        <Animator rings={rings} elapsed={elapsed} speed={speed} program={program} />
      </SimCanvas>
    </div>
  );
}
