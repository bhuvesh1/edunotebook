// Spirochetes, rickettsiae, chlamydiae, mycoplasma: a corkscrew spirochete
// drills forward while tiny rickettsiae dot the field and wall-less mycoplasma
// wobbles into ever-changing shapes.
"use client";

import { useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Spirochetes, rickettsiae & co.",
  blurb: "A corkscrew spirochete drills forward; wall-less mycoplasma wobbles shape beside tiny rickettsiae.",
};

function Animator({ spiro, myco, rick, elapsed, speed, setTick }: {
  spiro: React.RefObject<THREE.Group>;
  myco: React.RefObject<THREE.Mesh>;
  rick: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  speed: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (spiro.current) {
      // corkscrew rotation + forward drill
      spiro.current.rotation.x = t * 6;
      spiro.current.position.x = -3.4 + ((t * 0.7) % 2.4);
      spiro.current.position.y = 2.4 + Math.sin(t * 2) * 0.15;
    }
    if (myco.current) {
      // pleomorphic wobble — no cell wall, shape keeps changing
      myco.current.scale.set(
        1 + Math.sin(t * 2.3) * 0.22,
        1 + Math.sin(t * 3.1 + 1) * 0.28,
        1 + Math.cos(t * 1.7) * 0.22
      );
      myco.current.rotation.y = t * 0.6;
    }
    rick.current.forEach((r, i) => {
      if (!r) return;
      r.position.y = 1.1 + Math.sin(t * 2.6 + i * 2.2) * 0.14;
      r.position.x += Math.sin(t * 0.8 + i) * 0.003;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(t * 10)); }
  });
  return null;
}

export function Topic10135Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const spiro = useRef<THREE.Group>(null!);
  const myco = useRef<THREE.Mesh>(null!);
  const rick = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const helix = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 80; i++) {
      const a = (i / 80) * Math.PI * 10;
      pts.push(new THREE.Vector3((i / 80 - 0.5) * 4.4, Math.cos(a) * 0.4, Math.sin(a) * 0.4));
    }
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 96, 0.11, 8);
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Spirochete", "corkscrew — Treponema"],
          ["Rickettsiae", "tiny, tick-borne"],
          ["Mycoplasma", "no cell wall — wobbly"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* spirochete corkscrew */}
        <group ref={spiro} position={[-3.4, 2.4, 0]}>
          <mesh geometry={helix} castShadow>
            <meshStandardMaterial color="#f472b6" emissive="#be185d" emissiveIntensity={0.6} roughness={0.4} />
          </mesh>
        </group>
        {showLabels && <Label text="spirochete — corkscrew" position={[-2.4, 3.6, 0]} color="#f9a8d4" />}

        {/* rickettsiae: tiny red dots */}
        {Array.from({ length: 10 }).map((_, i) => (
          <mesh
            key={i}
            ref={(m) => { rick.current[i] = m; }}
            position={[-1 + (i % 5) * 0.55, 1.1, Math.floor(i / 5) * 0.7 - 0.35]}
          >
            <sphereGeometry args={[0.12, 10, 8]} />
            <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={0.8} />
          </mesh>
        ))}
        {showLabels && <Label text="rickettsiae — tiny dots" position={[0.1, 2.1, 0]} size={0.45} color="#fca5a5" />}

        {/* chlamydiae: elementary bodies ring */}
        {Array.from({ length: 7 }).map((_, i) => {
          const a = (i / 7) * Math.PI * 2;
          return (
            <mesh key={`c${i}`} position={[0.1 + Math.cos(a) * 0.9, 0.45, Math.sin(a) * 0.5]}>
              <sphereGeometry args={[0.14, 10, 8]} />
              <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.7} />
            </mesh>
          );
        })}
        {showLabels && <Label text="chlamydiae" position={[0.1, -0.25, 0]} size={0.4} color="#fde047" />}

        {/* mycoplasma: wall-less wobbling blob */}
        <mesh ref={myco} position={[3.4, 1.4, 0]} castShadow>
          <sphereGeometry args={[0.8, 20, 14]} />
          <meshStandardMaterial color="#a78bfa" roughness={0.35} transparent opacity={0.9} />
        </mesh>
        {showLabels && <Label text="mycoplasma — no wall!" position={[3.4, 2.8, 0]} color="#c4b5fd" />}

        <Animator spiro={spiro} myco={myco} rick={rick} elapsed={elapsed} speed={speed} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
