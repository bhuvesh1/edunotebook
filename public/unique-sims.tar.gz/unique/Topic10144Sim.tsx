// Helminths: a roundworm wriggles, a tapeworm's flat segments ripple in a chain,
// and a leaf-shaped fluke pulses — the three great worm families side by side.
"use client";

import { useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Helminths: worms",
  blurb: "A roundworm wriggles, a tapeworm's segments ripple, a leaf-shaped fluke pulses — side by side.",
};

function Animator({ round, tape, fluke, elapsed, speed, setTick }: {
  round: React.RefObject<THREE.Group>;
  tape: React.RefObject<(THREE.Mesh | null)[]>;
  fluke: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (round.current) {
      round.current.rotation.z = Math.sin(t * 2.2) * 0.3;
      round.current.rotation.x = Math.sin(t * 1.5) * 0.2;
      round.current.position.y = 1.4 + Math.sin(t * 3) * 0.12;
    }
    tape.current.forEach((s, i) => {
      if (!s) return;
      // peristaltic ripple down the segment chain
      s.position.y = 1.5 + Math.sin(t * 3 - i * 0.55) * 0.22;
      s.rotation.y = Math.sin(t * 2 - i * 0.4) * 0.3;
    });
    if (fluke.current) {
      const p = 1 + Math.sin(t * 4) * 0.12;
      fluke.current.scale.set(p, 1, 2 - p > 0 ? 1 / p : 1);
      fluke.current.rotation.y = Math.sin(t * 1.2) * 0.4;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(t * 10)); }
  });
  return null;
}

export function Topic10144Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const round = useRef<THREE.Group>(null!);
  const tape = useRef<(THREE.Mesh | null)[]>([]);
  const fluke = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const roundGeo = useMemo(() => {
    const pts = [
      new THREE.Vector3(-1.8, 0, 0),
      new THREE.Vector3(-0.9, 0.45, 0.25),
      new THREE.Vector3(0, -0.35, -0.2),
      new THREE.Vector3(0.9, 0.4, 0.2),
      new THREE.Vector3(1.8, -0.1, 0),
    ];
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 40, 0.2, 10);
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Nematode", "roundworm — cylindrical"],
          ["Cestode", "tapeworm — segments"],
          ["Trematode", "fluke — leaf-shaped"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 13]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* intestine backdrop */}
        <mesh position={[0, 1.3, -2]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[2.2, 2.2, 14, 20, 1, true]} />
          <meshStandardMaterial color="#d4a373" transparent opacity={0.25} side={THREE.DoubleSide} />
        </mesh>

        {/* roundworm (nematode) */}
        <group ref={round} position={[-4.2, 1.4, 0.4]}>
          <mesh geometry={roundGeo} castShadow>
            <meshStandardMaterial color="#f5d0a9" roughness={0.5} />
          </mesh>
          <mesh position={[-1.8, 0.12, 0]}>
            <sphereGeometry args={[0.2, 10, 8]} />
            <meshStandardMaterial color="#e8b48c" roughness={0.5} />
          </mesh>
        </group>
        {showLabels && <Label text="roundworm (Ascaris)" position={[-4.2, 2.9, 0.4]} color="#f5d0a9" />}

        {/* tapeworm (cestode): scolex + segment chain */}
        <group position={[0.4, 0, 0.3]}>
          <mesh position={[-2.6, 1.5, 0]} castShadow>
            <sphereGeometry args={[0.3, 14, 10]} />
            <meshStandardMaterial color="#fef3c7" roughness={0.5} />
          </mesh>
          {[-0.35, 0.35].map((z, i) => (
            <mesh key={i} position={[-2.6, 1.5, z]} rotation={[z > 0 ? -0.5 : 0.5, 0, 0]}>
              <coneGeometry args={[0.1, 0.3, 8]} />
              <meshStandardMaterial color="#fde68a" roughness={0.5} />
            </mesh>
          ))}
          {showLabels && <Label text="scolex — hooks" position={[-2.6, 2.3, 0]} size={0.4} color="#fde047" />}
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh
              key={i}
              ref={(m) => { tape.current[i] = m; }}
              position={[-2.1 + i * 0.5, 1.5, 0]}
              castShadow
            >
              <boxGeometry args={[0.44, 0.5 - i * 0.012, 0.16]} />
              <meshStandardMaterial color={i % 2 ? "#fde68a" : "#fcd34d"} roughness={0.55} />
            </mesh>
          ))}
        </group>
        {showLabels && <Label text="tapeworm — proglottid segments" position={[0.4, 2.7, 0.3]} color="#fde047" />}

        {/* fluke (trematode): leaf shape */}
        <mesh ref={fluke} position={[4.6, 1.5, 0.2]} scale={[1, 1.4, 0.25]} castShadow>
          <sphereGeometry args={[0.7, 18, 14]} />
          <meshStandardMaterial color="#fda4af" roughness={0.5} />
        </mesh>
        {showLabels && <Label text="fluke — leaf-shaped" position={[4.6, 2.9, 0.2]} color="#fda4af" />}

        <Animator round={round} tape={tape} fluke={fluke} elapsed={elapsed} speed={speed} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
