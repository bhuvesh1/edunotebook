// app/components/sims/unique/Topic10517Sim.tsx
// Oral cancer: clinical features and staging. An ulcer with raised,
// rolled edges on the tongue grows through stages I–IV; involved lymph
// nodes appear in the neck at later stages.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Cancer stage", kind: "slider", min: 1, max: 4, step: 1, default: 2, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Oral Cancer: Features & Staging",
  blurb: "A non-healing ulcer with rolled edges grows across stages — nodes appear in the neck at stage III–IV.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ ulcer, rim, elapsed, speed, stage }: {
  ulcer: RefObject<THREE.Mesh>; rim: RefObject<THREE.Mesh>;
  elapsed: RefObject<number>; speed: number; stage: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const pulse = 1 + 0.08 * Math.sin(elapsed.current * 3);
    const s = (0.35 + stage * 0.3) * pulse;
    if (ulcer.current) ulcer.current.scale.setScalar(Math.max(s, 0.001));
    if (rim.current) {
      rim.current.scale.setScalar(Math.max(s, 0.001));
      const mat = rim.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = 0.5 + 0.25 * Math.sin(elapsed.current * 3);
    }
  });
  return null;
}

const STAGE_INFO = [
  "",
  "Stage I: ≤2 cm, no nodes",
  "Stage II: 2–4 cm, no nodes",
  "Stage III: >4 cm or single node",
  "Stage IV: invades deep / nodes both sides",
];

export function Topic10517Sim(props: SimProps) {
  const stage = Math.round(Number(props.stage ?? 2));
  const speed = Number(props.speed ?? 1);
  const ulcer = useRef<THREE.Mesh>(null!);
  const rim = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["TNM stage", STAGE_INFO[stage]],
          ["Ulcer", "non-healing, rolled edges, indurated"],
          ["Nodes", stage >= 3 ? "palpable neck nodes ⚠" : "no palpable nodes"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.4, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* face + neck */}
        <mesh position={[0, 2.6, -0.8]} castShadow>
          <sphereGeometry args={[2.6, 32, 32]} />
          <meshStandardMaterial color="#f0b98d" roughness={0.7} />
        </mesh>
        <mesh position={[0, 0.4, -0.6]} castShadow>
          <cylinderGeometry args={[1.1, 1.3, 1.8, 20]} />
          <meshStandardMaterial color="#f0b98d" roughness={0.7} />
        </mesh>
        {/* open mouth */}
        <mesh position={[0, 2.4, 1.2]}>
          <sphereGeometry args={[1.35, 24, 24]} />
          <meshStandardMaterial color="#5b1a1a" roughness={0.9} />
        </mesh>
        <mesh position={[0, 2.4, 1.55]} scale={[1.35, 0.85, 0.6]} castShadow>
          <torusGeometry args={[1.05, 0.28, 14, 32]} />
          <meshStandardMaterial color="#e0788a" roughness={0.55} />
        </mesh>
        {/* tongue */}
        <mesh position={[0, 1.85, 1.5]} scale={[1, 0.45, 1.15]} castShadow>
          <sphereGeometry args={[0.85, 24, 24]} />
          <meshStandardMaterial color="#e0607a" roughness={0.55} />
        </mesh>

        {/* malignant ulcer: necrotic center + raised rolled rim */}
        <mesh ref={ulcer} position={[-0.35, 2.15, 2.05]} rotation={[-0.4, 0, 0]}>
          <circleGeometry args={[0.42, 24]} />
          <meshStandardMaterial color="#7c2d12" emissive="#7c2d12" emissiveIntensity={0.4} roughness={0.9} side={THREE.DoubleSide} />
        </mesh>
        <mesh ref={rim} position={[-0.35, 2.15, 2.06]} rotation={[-0.4, 0, 0]}>
          <torusGeometry args={[0.42, 0.12, 12, 28]} />
          <meshStandardMaterial color="#fca5a5" emissive="#ef4444" emissiveIntensity={0.6} roughness={0.6} />
        </mesh>

        {/* involved lymph nodes in the neck (stage III+) */}
        {stage >= 3 && (
          <group>
            {[
              [-1.15, 0.7, 0.6, 0.3],
              [-1.3, 0.25, 0.5, 0.22],
              ...(stage >= 4 ? [[1.15, 0.7, 0.6, 0.3] as const] : []),
            ].map((p, i) => (
              <mesh key={i} position={[p[0], p[1], p[2]]} castShadow>
                <sphereGeometry args={[p[3], 16, 16]} />
                <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.7} roughness={0.4} />
              </mesh>
            ))}
            <Label p={[-2.2, 0.5, 0.8]} size={0.3} color="#fca5a5">metastatic nodes</Label>
          </group>
        )}

        <Label p={[2.5, 2.15, 1.8]} size={0.3} color="#fca5a5">ulcer, raised edges</Label>
        <Label p={[0, 5.2, 0.5]} size={0.34} color="#e2e8f0">early detection saves lives — biopsy any ulcer &gt; 2 weeks</Label>

        <Animator ulcer={ulcer} rim={rim} elapsed={elapsed} speed={speed} stage={stage} />
      </SimCanvas>
    </div>
  );
}
