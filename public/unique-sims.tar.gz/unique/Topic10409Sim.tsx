"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "tumor", label: "Tumour", kind: "select", min: 0, max: 0, step: 1, default: "giantcell", options: ["giantcell", "ossifying", "hemangioma"] },
  { key: "size", label: "Tumour size", kind: "slider", min: 0.5, max: 1.6, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Non-odontogenic tumors of jaws",
  blurb: "Three non-tooth-origin jaw tumours inside the mandible — giant cell granuloma, ossifying fibroma and vascular hemangioma.",
};

const INFO: Record<string, { name: string; pos: [number, number, number]; color: string; note: string }> = {
  giantcell: { name: "Central giant cell granuloma", pos: [-1.6, 0.1, 0.5], color: "#b45309", note: "Reddish-brown, bleeds on touch" },
  ossifying: { name: "Ossifying fibroma", pos: [0.2, -0.1, 0.5], color: "#f8fafc", note: "Well-defined, bony hard mass" },
  hemangioma: { name: "Hemangioma of jaw", pos: [1.9, 0.1, 0.5], color: "#dc2626", note: "Vascular — thrills and bleeds" },
};

function Scene({ tumor, size }: { tumor: string; size: number }) {
  const group = useRef<THREE.Group>(null!);
  const active = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const info = INFO[tumor] ?? INFO.giantcell;

  useFrame((_, delta) => {
    t.current += delta;
    if (active.current) {
      const s = size * (1 + Math.sin(t.current * 2.2) * 0.05);
      active.current.scale.setScalar(s);
    }
    if (group.current) group.current.rotation.y = Math.sin(t.current * 0.25) * 0.4;
  });

  return (
    <group ref={group}>
      {/* mandible block */}
      <mesh position={[0, -0.5, 0]} receiveShadow>
        <boxGeometry args={[6.4, 2.2, 2.6]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>
      {/* gum */}
      <mesh position={[0, 0.75, 0]}>
        <boxGeometry args={[6.4, 0.4, 2.8]} />
        <meshStandardMaterial color="#e0788a" roughness={0.6} />
      </mesh>
      {/* teeth */}
      {[-2.4, -1.2, 1.2, 2.4].map((x, i) => (
        <mesh key={i} position={[x, 1.25, 0]}>
          <cylinderGeometry args={[0.24, 0.3, 0.65, 10]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.3} />
        </mesh>
      ))}

      {Object.entries(INFO).map(([key, m]) => (
        <group key={key} position={m.pos}>
          {key === tumor ? (
            <group ref={active}>
              <mesh>
                <sphereGeometry args={[0.7, 20, 20]} />
                <meshStandardMaterial color={m.color} roughness={0.5} />
              </mesh>
              {key === "hemangioma" && (
                <mesh>
                  <torusGeometry args={[0.7, 0.06, 8, 24]} />
                  <meshStandardMaterial color="#7f1d1d" roughness={0.4} />
                </mesh>
              )}
              {key === "ossifying" && (
                <mesh scale={1.06}>
                  <sphereGeometry args={[0.7, 16, 16]} />
                  <meshStandardMaterial color="#e3cfae" wireframe transparent opacity={0.5} />
                </mesh>
              )}
            </group>
          ) : (
            <mesh scale={0.55}>
              <sphereGeometry args={[0.7, 16, 16]} />
              <meshStandardMaterial color={m.color} transparent opacity={0.45} roughness={0.6} />
            </mesh>
          )}
          {key === tumor && <Label text={m.name} position={[0, 1.35, 0]} size={0.55} color={m.color} />}
        </group>
      ))}
      <Label text={info.note} position={[0, -2.4, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10409Sim(props: SimProps) {
  const tumor = String(props.tumor ?? "giantcell");
  const size = Number(props.size ?? 1);
  const info = INFO[tumor] ?? INFO.giantcell;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Tumour", info.name], ["Origin", "Non-odontogenic"], ["Note", info.note]]} />
      <SimCanvas cameraPosition={[0, 3, 10]} target={[0, 0, 0]}>
        <Scene tumor={tumor} size={size} />
      </SimCanvas>
    </div>
  );
}
