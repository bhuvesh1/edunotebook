"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "load", label: "Cyclic load", kind: "slider", min: 0, max: 100, step: 1, default: 55, unit: " N" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Mechanical properties: strength, elasticity, fatigue, creep",
  blurb: "Bend a beam over and over — each cycle adds fatigue cracks, while a steady load makes it slowly creep. Count cycles to failure.",
};

function BeamScene({ load, speed, showLabels }: { load: number; speed: number; showLabels: boolean }) {
  const beam = useRef<THREE.Group>(null!);
  const crack = useRef<THREE.Mesh>(null!);
  const creepRef = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const cycles = useRef(0);
  const lastPhase = useRef(0);

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const amp = (load / 100) * 0.9;
    const bend = Math.abs(Math.sin(t * 2.4)) * amp; // cyclic bending
    const phase = Math.floor(t * 2.4 / Math.PI);
    if (phase !== lastPhase.current) {
      lastPhase.current = phase;
      cycles.current += 0.5;
    }
    if (beam.current) beam.current.rotation.z = -bend * 0.35;
    // fatigue crack grows with cycles × load
    const fatigue = Math.min(1, (cycles.current * load) / 9000);
    if (crack.current) {
      crack.current.visible = fatigue > 0.08;
      crack.current.scale.set(0.3 + fatigue, 0.3 + fatigue * 1.6, 1);
      (crack.current.material as THREE.MeshBasicMaterial).opacity = 0.35 + fatigue * 0.6;
    }
    // creep: slow permanent sag under the steady component of load
    if (creepRef.current) {
      const creep = Math.min(0.5, (t * load) / 6000);
      creepRef.current.position.y = 0.6 - creep;
    }
  });

  const est = Math.max(1, Math.round(9000 / Math.max(load, 5)));

  return (
    <group>
      {/* wall mount */}
      <mesh position={[-4.4, 0.6, 0]} castShadow>
        <boxGeometry args={[1, 5.4, 2.4]} />
        <meshStandardMaterial color="#475569" metalness={0.6} roughness={0.4} />
      </mesh>
      {/* cantilever beam */}
      <group position={[-3.9, 1.4, 0]}>
        <group ref={beam}>
          <mesh position={[3.4, 0, 0]} castShadow>
            <boxGeometry args={[6.8, 0.55, 1.4]} />
            <meshStandardMaterial color="#38bdf8" metalness={0.5} roughness={0.35} />
          </mesh>
          {/* fatigue crack at the fixed end (high stress) */}
          <mesh ref={crack} position={[0.9, -0.28, 0.72]} visible={false}>
            <planeGeometry args={[1, 1]} />
            <meshBasicMaterial color="#ef4444" transparent opacity={0.5} side={THREE.DoubleSide} />
          </mesh>
          {/* load weight hanging at tip */}
          <group position={[6.6, -1.2, 0]}>
            <mesh castShadow>
              <cylinderGeometry args={[0.06, 0.06, 1.6, 8]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.7} roughness={0.4} />
            </mesh>
            <mesh ref={creepRef} position={[0, -0.9, 0]} castShadow>
              <boxGeometry args={[1.3, 1.3, 1.3]} />
              <meshStandardMaterial color="#f97316" roughness={0.5} />
            </mesh>
            <Text position={[0, -2.4, 0]} fontSize={0.42} color="#fdba74">{load} N</Text>
          </group>
        </group>
      </group>
      {/* cycle counter board */}
      <CycleBoard cycles={cycles} />
      {showLabels && (
        <>
          <Text position={[2.5, 3.4, 0]} fontSize={0.42} color="#7dd3fc">Cantilever beam — bending</Text>
          <Text position={[-2.6, -1.4, 0]} fontSize={0.4} color="#fca5a5">Crack starts at max stress</Text>
          <Text position={[3.4, -3.4, 0]} fontSize={0.4} color="#fdba74">Steady load → slow creep sag</Text>
          <Text position={[0, 4.8, 0]} fontSize={0.44} color="#fef3c7">Fatigue: small bends, repeated, still break it</Text>
        </>
      )}
    </group>
  );
}

function CycleBoard({ cycles }: { cycles: React.MutableRefObject<number> }) {
  const txt = useRef<any>(null);
  useFrame(() => {
    if (txt.current) txt.current.text = `cycles: ${Math.floor(cycles.current)}`;
  });
  return (
    <group position={[5.6, 3.6, -2]}>
      <mesh>
        <boxGeometry args={[4.4, 1.6, 0.3]} />
        <meshStandardMaterial color="#1e293b" roughness={0.5} />
      </mesh>
      <Text ref={txt} position={[0, 0, 0.2]} fontSize={0.5} color="#4ade80">cycles: 0</Text>
    </group>
  );
}

export function Topic10386Sim(props: SimProps) {
  const load = Number(props.load ?? 55);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const est = Math.max(1, Math.round(9000 / Math.max(load, 5)));

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Load", `${load} N`],
          ["Fatigue life", `~${est} cycles`],
          ["Creep", "slow sag under steady load"],
        ]}
      />
      <SimCanvas cameraPosition={[2, 3.5, 13]} target={[1, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.6, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <BeamScene load={load} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
