"use client";
// Maintenance: Supportive Periodontal Care — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "interval", label: "Recall interval", kind: "slider", min: 4, max: 12, step: 1, default: 8, unit: " s" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Maintenance: Supportive Periodontal Care",
  blurb: "Plaque always tries to come back — regular recall cleanings sweep it away before it hardens.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const T = p.interval;
    const ph = (t % T) / T;
    const n = 12;
    const count = Math.floor(ph * n);
    for (let i = 0; i < n; i++) {
      const d: any = g("mplq" + i);
      if (d) d.visible = i < count && ph < 0.92;
    }
    const brush: any = g("brush");
    if (brush) {
      brush.visible = ph > 0.85;
      brush.position.x = -3 + ((ph - 0.85) / 0.15) * 6;
    }
    const spark: any = g("sparkle");
    if (spark) {
      spark.visible = ph > 0.85;
      spark.scale.setScalar(0.5 + 0.4 * Math.sin(t * 12));
    }
  });
  return null;
}

export function Topic10493Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const interval = Number(props.interval ?? 8);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, interval };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Recall", `Every ${interval}s (demo)`],
          ["Real world", "Every 3–6 months"],
          ["Goal", "Plaque index near 0"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1.2, 0]} scale={1.6} />
          <GumSlab position={[0, 0.2, 0]} scale={1.2} />
          {[
            [-0.5, 2, 0.55], [0.4, 2.2, 0.5], [0.1, 1.7, 0.62], [-0.2, 2.4, 0.35],
            [0.55, 1.85, 0.4], [-0.65, 1.6, 0.45], [0.25, 2.55, 0.3], [-0.35, 1.45, 0.55],
            [0.6, 2.3, 0.25], [-0.05, 2.1, 0.6], [0.35, 1.5, 0.5], [-0.55, 2.25, 0.3],
          ].map((pt, i) => (
            <mesh key={i} name={"mplq" + i} position={[pt[0], pt[1], pt[2]]} visible={false}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshStandardMaterial color="#65a30d" roughness={0.9} />
            </mesh>
          ))}
          <group name="brush" position={[-3, 2, 0.8]} visible={false}>
            <mesh rotation={[0, 0, 1.2]}>
              <boxGeometry args={[1.6, 0.18, 0.18]} />
              <meshStandardMaterial color="#38bdf8" roughness={0.5} />
            </mesh>
            <mesh position={[0.5, 0.35, 0]}>
              <boxGeometry args={[0.5, 0.3, 0.4]} />
              <meshStandardMaterial color="#e0f2fe" roughness={0.6} />
            </mesh>
          </group>
          <mesh name="sparkle" position={[0, 2.2, 0.8]} visible={false}>
            <sphereGeometry args={[1, 12, 12]} />
            <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.9} transparent opacity={0.5} />
          </mesh>
          <Label text="Plaque creeps back…" position={[-2.8, 3.1, 0]} size={0.42} color="#84cc16" />
          <Label text="Recall cleaning sweeps it away" position={[0, -0.6, 0]} size={0.42} color="#38bdf8" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
