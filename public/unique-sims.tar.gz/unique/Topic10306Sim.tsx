// Amputations and prosthetics basics, clubfoot management.
// A below-knee prosthesis — pylon, foot, and socket — takes steps on loop.
// Switch to see an above-knee prosthesis with its knee joint, or a clubfoot
// in its corrective cast.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "level", label: "Level", kind: "select", min: 0, max: 0, step: 1, default: "below_knee", options: ["below_knee", "above_knee", "clubfoot_cast"] },
  { key: "walk", label: "Walk speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Prosthetic Leg Walking",
  blurb: "A prosthetic leg takes steps — below-knee pylon, above-knee with a hinge knee, or a clubfoot in its cast.",
};

function Animator({
  group, prosthesis, kneeJoint, elapsed, walk, level,
}: {
  group: React.RefObject<THREE.Group>;
  prosthesis: React.RefObject<THREE.Group>;
  kneeJoint: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  walk: number;
  level: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * walk;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.15) * 0.15;
    // walking gait: prosthesis swings forward and back
    if (prosthesis.current && level !== "clubfoot_cast") {
      const swing = Math.sin(t * 3.2);
      prosthesis.current.rotation.x = swing * 0.45;
      prosthesis.current.position.y = Math.max(0, Math.sin(t * 3.2 + Math.PI)) * 0.25;
    }
    if (kneeJoint.current && level === "above_knee") {
      // prosthetic knee bends during swing phase
      const bend = Math.max(0, Math.sin(t * 3.2 + 0.6)) * 0.9;
      kneeJoint.current.rotation.x = -bend;
    }
  });
  return null;
}

export function Topic10306Sim(props: SimProps) {
  const level = String(props.level ?? "below_knee");
  const walk = Number(props.walk ?? 1);
  const group = useRef<THREE.Group>(null!);
  const prosthesis = useRef<THREE.Group>(null!);
  const kneeJoint = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    below_knee: "Below-knee prosthesis", above_knee: "Above-knee prosthesis", clubfoot_cast: "Clubfoot in cast",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Level", names[level] ?? level], ["Walk", `${walk.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* person: torso + head + one natural leg */}
          <mesh position={[-0.6, 3.2, 0]} scale={[0.9, 1.2, 0.7]} castShadow>
            <sphereGeometry args={[0.65, 20, 14]} />
            <meshStandardMaterial color="#3b82f6" roughness={0.6} />
          </mesh>
          <mesh position={[-0.6, 4.4, 0]} castShadow>
            <sphereGeometry args={[0.4, 18, 14]} />
            <meshStandardMaterial color="#f5c396" roughness={0.6} />
          </mesh>
          <mesh position={[-0.9, 1.6, 0]} castShadow>
            <capsuleGeometry args={[0.2, 1.8, 8, 12]} />
            <meshStandardMaterial color="#1e293b" roughness={0.6} />
          </mesh>
          <mesh position={[-0.9, 0.35, 0.15]} castShadow>
            <boxGeometry args={[0.35, 0.25, 0.7]} />
            <meshStandardMaterial color="#0f172a" roughness={0.6} />
          </mesh>

          {level === "below_knee" && (
            <group ref={prosthesis} position={[0.35, 2.4, 0]}>
              {/* residual limb */}
              <mesh position={[0, 0.5, 0]} castShadow>
                <capsuleGeometry args={[0.24, 0.6, 8, 12]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              {/* socket */}
              <mesh position={[0, -0.15, 0]} castShadow>
                <cylinderGeometry args={[0.3, 0.26, 0.5, 16]} />
                <meshStandardMaterial color="#f59e0b" roughness={0.5} />
              </mesh>
              {/* pylon */}
              <mesh position={[0, -0.9, 0]} castShadow>
                <cylinderGeometry args={[0.07, 0.07, 1.1, 10]} />
                <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
              </mesh>
              {/* prosthetic foot */}
              <mesh position={[0, -1.55, 0.18]} castShadow>
                <boxGeometry args={[0.28, 0.2, 0.75]} />
                <meshStandardMaterial color="#1e293b" roughness={0.5} />
              </mesh>
            </group>
          )}
          {level === "above_knee" && (
            <group ref={prosthesis} position={[0.35, 3.1, 0]}>
              {/* thigh socket */}
              <mesh position={[0, 0.15, 0]} castShadow>
                <cylinderGeometry args={[0.34, 0.3, 0.7, 16]} />
                <meshStandardMaterial color="#f59e0b" roughness={0.5} />
              </mesh>
              {/* prosthetic knee hinge */}
              <mesh ref={kneeJoint} position={[0, -0.35, 0]} castShadow>
                <sphereGeometry args={[0.18, 14, 10]} />
                <meshStandardMaterial color="#64748b" metalness={0.8} roughness={0.3} />
              </mesh>
              <mesh position={[0, -1.1, 0]} castShadow>
                <cylinderGeometry args={[0.08, 0.08, 1.2, 10]} />
                <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
              </mesh>
              <mesh position={[0, -1.85, 0.18]} castShadow>
                <boxGeometry args={[0.28, 0.2, 0.75]} />
                <meshStandardMaterial color="#1e293b" roughness={0.5} />
              </mesh>
            </group>
          )}
          {level === "clubfoot_cast" && (
            <group position={[0.35, 1.9, 0]}>
              <mesh castShadow>
                <capsuleGeometry args={[0.5, 1.4, 8, 14]} />
                <meshStandardMaterial color="#fef3c7" roughness={0.8} />
              </mesh>
              <mesh position={[0, -0.9, 0.3]} rotation={[0, 0.5, 0]} castShadow>
                <boxGeometry args={[0.5, 0.35, 0.9]} />
                <meshStandardMaterial color="#fef3c7" roughness={0.8} />
              </mesh>
            </group>
          )}
          {/* walking path dots */}
          {[-1.5, -0.5, 0.5, 1.5].map((x, i) => (
            <mesh key={i} position={[x, 0.06, 1.6]}>
              <circleGeometry args={[0.12, 12]} />
              <meshBasicMaterial color="#38bdf8" transparent opacity={0.5} />
            </mesh>
          ))}
          <Label text="Socket (fits stump)" position={[2.0, level === "above_knee" ? 3.2 : 2.2, 0]} size={0.5} color="#fde68a" />
          <Label text="Pylon" position={[2.0, 1.4, 0]} size={0.5} color="#cbd5e1" />
          <Label text="Prosthetic foot" position={[2.0, 0.6, 0.2]} size={0.5} color="#94a3b8" />
          {level === "above_knee" && <Label text="Hinge knee bends!" position={[2.0, 2.6, 0]} size={0.5} color="#86efac" />}
          {level === "clubfoot_cast" && <Label text="Cast holds foot straight" position={[2.0, 1.9, 0]} size={0.5} color="#fef3c7" />}
        </group>
        <Animator group={group} prosthesis={prosthesis} kneeJoint={kneeJoint} elapsed={elapsed} walk={walk} level={level} />
      </SimCanvas>
    </div>
  );
}
