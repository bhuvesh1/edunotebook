// Bleeding & clotting disorders — a cut vessel spurts blood; platelets rush
// to the cut and weave a fibrin plug. The clotting-factor slider decides:
// too low = endless bleeding (hemophilia), normal = tidy plug, too high =
// a dangerous thrombus blocking the vessel.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "factor", label: "Clotting factor level", kind: "slider", min: 0, max: 150, step: 5, default: 80, unit: "%" },
  { key: "labels", label: "Labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Bleeding & Clotting",
  blurb: "Platelets race to a cut vessel and weave a plug — set clotting factor too low for hemophilia bleeding, too high for a blocking thrombus.",
};

function Animator({ spurt, platelets, elapsed, factor }: {
  spurt: React.RefObject<THREE.Group>;
  platelets: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  factor: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const plugStrength = Math.min(1, factor / 80);
    if (spurt.current) {
      spurt.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * 2.2 + i * 0.13) % 1);
        // blood arcs out of the cut; weaker as the plug forms
        m.position.x = -1.2 + ph * 2.6;
        m.position.y = 1.9 + Math.sin(ph * Math.PI) * 1.1;
        m.visible = ph < 1.05 - plugStrength * 0.85;
      });
    }
    if (platelets.current) {
      platelets.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = Math.min(1, (t * 0.5 + i * 0.06) % 1.4);
        // platelets swarm from upstream to the cut
        m.position.x = -5 + ph * 3.8;
        m.position.y = 1.9 + Math.sin(ph * 9 + i) * 0.25 * (1 - ph);
        m.visible = i < Math.round((factor / 150) * platelets.current!.children.length * 1.4);
      });
    }
  });
  return null;
}

export function Topic10235Sim(props: SimProps) {
  const factor = Number(props.factor ?? 80);
  const showLabels = String(props.labels ?? "on") === "on";
  const spurt = useRef<THREE.Group>(null!);
  const platelets = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const plugSize = Math.min(1, factor / 90);
  const thrombus = factor > 115;
  const hemophilia = factor < 30;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Factor level", `${factor}%`], ["Bleeding", hemophilia ? "won't stop ⚠" : factor < 80 ? "slow to stop" : "stops"], ["Clot risk", thrombus ? "THROMBOSIS ⚠" : "normal"]]} />
      <SimCanvas cameraPosition={[0, 2.2, 11.5]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* vessel with a cut on top */}
        <mesh position={[0, 1.2, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.9, 0.9, 13, 20, 1, true]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.55} side={THREE.DoubleSide} />
        </mesh>
        {/* the cut */}
        <mesh position={[-1.2, 2.05, 0]} rotation={[0, 0, 0.4]}>
          <boxGeometry args={[0.7, 0.18, 0.5]} />
          <meshStandardMaterial color="#450a0a" roughness={0.9} />
        </mesh>

        {/* spurting blood */}
        <group ref={spurt}>
          {Array.from({ length: 14 }).map((_, i) => (
            <mesh key={i} position={[-1.2, 1.9, 0]}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshBasicMaterial color="#ef4444" />
            </mesh>
          ))}
        </group>
        {/* platelet swarm */}
        <group ref={platelets}>
          {Array.from({ length: 22 }).map((_, i) => (
            <mesh key={i} position={[-5, 1.9, 0]}>
              <sphereGeometry args={[0.13, 8, 8]} />
              <meshStandardMaterial color="#fde68a" roughness={0.4} emissive="#a16207" emissiveIntensity={0.4} />
            </mesh>
          ))}
        </group>
        {/* the fibrin plug / thrombus */}
        <mesh position={[-1.2, 2.0, 0]} scale={[1 + plugSize * 0.6, 0.7 + plugSize * 0.9, 1]} visible={plugSize > 0.05}>
          <sphereGeometry args={[0.5, 14, 12]} />
          <meshStandardMaterial color={thrombus ? "#7f1d1d" : "#fca5a5"} roughness={0.7} emissive={thrombus ? "#450a0a" : "#000"} emissiveIntensity={0.4} />
        </mesh>
        {thrombus && <Label text="Thrombus blocking the vessel! ⚠" position={[-1.2, 3.6, 0]} size={0.52} color="#fca5a5" />}

        {showLabels && (
          <>
            <Label text="Cut vessel" position={[-3.8, 2.9, 0]} size={0.48} color="#e2e8f0" />
            <Label text="Platelets → fibrin plug" position={[2.8, 2.9, 0]} size={0.48} color="#fde68a" />
            <Label text={hemophilia ? "Hemophilia: missing factor → bleeds won't stop" : thrombus ? "Too much clotting → stroke/heart attack risk" : "Just right: plug forms, bleeding stops ✓"} position={[0, -1.4, 0]} size={0.46} color="#fde047" />
          </>
        )}
        <Animator spurt={spurt} platelets={platelets} elapsed={elapsed} factor={factor} />
      </SimCanvas>
    </div>
  );
}
