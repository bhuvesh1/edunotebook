"use client";

// Basic surgical principles: asepsis, suturing, wound healing.
// A curved needle weaves the suture thread across the wound on a
// sterile drape. Slide the healing stage to watch the wound close.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Healing stage", kind: "slider", min: 1, max: 4, step: 1, default: 1, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Suturing & Wound Healing",
  blurb: "A needle weaves sutures across the wound on a sterile field — then slide through the four stages of healing.",
};

type Ref = { current: THREE.Group | null };

const STAGE_NAMES = ["", "Inflammatory — open wound", "Proliferative — edges closing", "Remodeling — new tissue", "Mature scar"];
const STAGE_COLORS = ["", "#dc2626", "#f87171", "#fca5a5", "#e7c39b"];

function Animator({ needle, thread, elapsed, speed, gap }: {
  needle: Ref; thread: { current: THREE.Mesh | null }; elapsed: { current: number }; speed: number; gap: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const e = elapsed.current;
    const prog = (e * 0.22) % 1; // needle sweep along the wound
    if (needle.current) {
      const x = -1.7 + prog * 3.4;
      const side = Math.floor(prog * 6) % 2 === 0 ? 1 : -1;
      needle.current.position.set(x, 0.62 + Math.abs(Math.sin(e * 6)) * 0.18, side * (0.42 + gap / 2));
      needle.current.rotation.set(0.4, 0, 1.2 + Math.sin(e * 6) * 0.35);
    }
    const mesh = thread.current;
    if (mesh) {
      const total = (mesh.userData.total as number) ?? 1;
      const frac = (e * 0.22) % 1.15;
      mesh.geometry.setDrawRange(0, Math.floor(total * Math.min(1, frac)));
    }
  });
  return null;
}

export function Topic10569Sim(props: SimProps) {
  const stage = Math.round(Number(props.stage ?? 1));
  const speed = Number(props.speed ?? 1);
  const gap = 0.55 - ((stage - 1) / 3) * 0.5;
  const woundColor = STAGE_COLORS[stage];

  const needle = useRef<THREE.Group>(null!);
  const thread = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const threadCurve = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 12; i++) {
      const x = -1.6 + (i / 12) * 3.2;
      const z = (i % 2 === 0 ? -1 : 1) * 0.55;
      pts.push(new THREE.Vector3(x, 0.52, z));
    }
    return new THREE.CatmullRomCurve3(pts);
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", STAGE_NAMES[stage]],
          ["Asepsis", "sterile drape + sterile instruments"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.2, 7.5]} target={[0, 0.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* sterile drape */}
        <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[6.2, 3.6]} />
          <meshStandardMaterial color="#1d4ed8" roughness={0.95} />
        </mesh>

        {/* skin blocks with wound gap */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * (1.2 + gap / 2), 0.26, 0]} castShadow>
            <boxGeometry args={[2.4, 0.48, 1.8]} />
            <meshStandardMaterial color="#f2c09b" roughness={0.8} />
          </mesh>
        ))}
        {/* wound bed */}
        <mesh position={[0, 0.26, 0]}>
          <boxGeometry args={[Math.max(0.06, gap + 0.04), 0.5, 0.55]} />
          <meshStandardMaterial color={woundColor} roughness={0.6} />
        </mesh>

        {/* suture thread (draws as the needle weaves) */}
        <mesh
          ref={thread}
          onUpdate={(m) => {
            const geo = new THREE.TubeGeometry(threadCurve, 48, 0.032, 6, false);
            m.geometry.dispose();
            m.geometry = geo;
            m.userData.total = geo.index ? geo.index.count : 0;
          }}
        >
          <meshStandardMaterial color="#f8fafc" roughness={0.4} />
        </mesh>

        {/* curved needle */}
        <group ref={needle} position={[-1.7, 0.62, 0.7]}>
          <mesh castShadow>
            <torusGeometry args={[0.26, 0.038, 8, 20, 3.6]} />
            <meshStandardMaterial color="#cbd5e1" roughness={0.25} metalness={0.85} />
          </mesh>
        </group>

        <Label text={STAGE_NAMES[stage]} position={[0, 2.0, 0]} size={0.5} color="#fbbf24" />
        <Label text="sterile drape" position={[2.5, 0.5, 1.4]} size={0.4} color="#93c5fd" />
        <Label text="suture thread" position={[-2.4, 1.1, -0.6]} size={0.4} color="#e2e8f0" />
        <Label text="curved needle" position={[-1.7, 1.5, 0.7]} size={0.4} color="#cbd5e1" />
        <Animator needle={needle} thread={thread} elapsed={elapsed} speed={speed} gap={gap} />
      </SimCanvas>
    </div>
  );
}
