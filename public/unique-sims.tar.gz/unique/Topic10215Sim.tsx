// Heart failure & cardiomyopathies — the heart balloons out (dilated), its
// squeeze weakens, blood backs up into the lungs (crackle dots). EF slider:
// lower ejection fraction = weaker squeeze, more backup.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ef", label: "Ejection fraction", kind: "slider", min: 10, max: 65, step: 1, default: 30, unit: "%" },
  { key: "type", label: "Cardiomyopathy", kind: "select", min: 0, max: 0, step: 1, default: "dilated", options: ["dilated", "hypertrophic", "restrictive"] },
];

export const UNIQUE_META = {
  title: "Heart Failure",
  blurb: "A failing heart balloons and barely squeezes — blood backs up into the lungs. Lower the EF and watch the backup grow.",
};

function Animator({ heart, backup, elapsed, ef }: {
  heart: React.RefObject<THREE.Group>;
  backup: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  ef: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const strength = ef / 65; // 1 = normal
    if (heart.current) {
      const beat = Math.pow(Math.max(0, Math.sin(t * 2.2 * Math.PI * 0.5)), 2);
      const s = 1 + beat * 0.05 * strength;
      heart.current.scale.set(s, 1 - beat * 0.035 * strength, s);
    }
    if (backup.current) {
      backup.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = (1 - strength) * (0.5 + 0.4 * Math.sin(t * 3 + i * 2));
        m.visible = ef < 50;
      });
    }
  });
  return null;
}

export function Topic10215Sim(props: SimProps) {
  const ef = Number(props.ef ?? 30);
  const type = String(props.type ?? "dilated");
  const heart = useRef<THREE.Group>(null!);
  const backup = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const dilated = type === "dilated";
  const hypertrophic = type === "hypertrophic";
  const heartScale: [number, number, number] = dilated
    ? [1.35, 1.15, 1.25]
    : hypertrophic
      ? [1.05, 1.2, 1.0]
      : [1.1, 1.1, 1.05];
  const nyha = ef < 25 ? "severe — breathless at rest" : ef < 40 ? "moderate — breathless on effort" : "mild";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["EF", `${ef}% (normal 55–70%)`], ["Type", type], ["Symptoms", nyha]]} />
      <SimCanvas cameraPosition={[0, 2.8, 12]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={heart} scale={heartScale}>
          <mesh position={[-1.6, 2.1, 0]} scale={[1, 1.25, 0.95]} castShadow>
            <sphereGeometry args={[1.7, 32, 26]} />
            <meshStandardMaterial color="#b91c1c" roughness={0.5} />
          </mesh>
          {/* thick wall (hypertrophic) */}
          {hypertrophic && (
            <mesh position={[-1.6, 2.1, 0]} scale={[0.82, 1.05, 0.78]}>
              <sphereGeometry args={[1.7, 28, 22]} />
              <meshStandardMaterial color="#7f1d1d" roughness={0.6} />
            </mesh>
          )}
          {/* aorta + pulmonary trunk */}
          <mesh position={[-1.9, 3.9, 0]} rotation={[0, 0, 0.25]}>
            <cylinderGeometry args={[0.42, 0.5, 1.6, 16]} />
            <meshStandardMaterial color="#ef4444" roughness={0.5} />
          </mesh>
          <mesh position={[-0.9, 3.8, 0]} rotation={[0, 0, -0.3]}>
            <cylinderGeometry args={[0.36, 0.44, 1.5, 16]} />
            <meshStandardMaterial color="#3b82f6" roughness={0.5} />
          </mesh>
        </group>

        {/* lungs with backup congestion */}
        {[-1, 1].map((s) => (
          <group key={s} position={[s * 4.6, 2.6, -0.5]}>
            <mesh scale={[1, 1.5, 0.7]} castShadow>
              <sphereGeometry args={[1.1, 24, 18]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
            </mesh>
            <group ref={s === 1 ? backup : undefined}>
              {s === 1 &&
                Array.from({ length: 12 }).map((_, i) => (
                  <mesh key={i} position={[((i * 0.53) % 1.4) - 0.7, ((i * 0.77) % 2.4) - 1.2, 0.5]}>
                    <sphereGeometry args={[0.14, 10, 8]} />
                    <meshStandardMaterial color="#38bdf8" roughness={0.4} emissive="#0c4a6e" emissiveIntensity={0.6} />
                  </mesh>
                ))}
            </group>
          </group>
        ))}

        <Label text={dilated ? "Dilated — ballooned, weak squeeze" : hypertrophic ? "Hypertrophic — walls too thick" : "Restrictive — stiff, can't fill"} position={[-1.6, 5.4, 0]} size={0.5} color="#fca5a5" />
        <Label text="Fluid backs up into lungs (crackles, breathlessness)" position={[4.6, 4.9, -0.5]} size={0.46} color="#7dd3fc" />
        <Label text="EF = % of blood pumped out each beat" position={[0, -1.3, 0]} size={0.44} color="#94a3b8" />
        <Animator heart={heart} backup={backup} elapsed={elapsed} ef={ef} />
      </SimCanvas>
    </div>
  );
}
