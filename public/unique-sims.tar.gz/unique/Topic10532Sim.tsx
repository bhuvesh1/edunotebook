// app/components/sims/unique/Topic10532Sim.tsx
// Growth and development: dental age and chronology of dentitions. A dental
// arch erupts teeth in sequence as the age slider moves from birth to 21 —
// primary teeth first, then permanent teeth replace them.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "age", label: "Age", kind: "slider", min: 0, max: 21, step: 0.5, default: 9, unit: " yr" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Growth & Development: Dental Age",
  blurb: "Drag the age slider and watch teeth erupt in order — baby teeth first, then the permanent set takes over.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ arch, elapsed, speed }: {
  arch: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (arch.current) arch.current.rotation.y = Math.sin(elapsed.current * 0.25) * 0.3;
  });
  return null;
}

// 10 teeth per arch side layout (upper), with eruption ages (years)
// primary teeth marked P (erupt 0.5–2.5y, shed 6–12y)
const TEETH: { x: number; z: number; erupt: number; shed: number; name: string; primary: boolean }[] = [];
const NAMES = ["central incisor", "lateral incisor", "canine", "1st molar", "2nd molar", "1st premolar", "2nd premolar", "1st molar", "2nd molar", "3rd molar"];
const ERUPT = [0.6, 0.9, 1.5, 1.3, 2.1, 10, 11, 6.2, 12, 18];
const SHED = [6.5, 7.5, 11, 10, 11.5, 99, 99, 99, 99, 99];
for (let side = -1; side <= 1; side += 2) {
  for (let i = 0; i < 5; i++) {
    const a = (i / 4) * 1.1 + 0.25;
    TEETH.push({
      x: side * Math.sin(a) * 2.2,
      z: Math.cos(a) * 2.2,
      erupt: ERUPT[i],
      shed: SHED[i],
      name: NAMES[i],
      primary: true,
    });
  }
  for (let i = 5; i < 10; i++) {
    const a = ((i - 5) / 4) * 1.1 + 0.25;
    TEETH.push({
      x: side * Math.sin(a) * 2.35,
      z: Math.cos(a) * 2.35,
      erupt: ERUPT[i],
      shed: SHED[i],
      name: NAMES[i],
      primary: false,
    });
  }
}

export function Topic10532Sim(props: SimProps) {
  const age = Number(props.age ?? 9);
  const speed = Number(props.speed ?? 1);
  const arch = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const erupted = TEETH.filter((t) => age >= t.erupt && age < t.shed);
  const primaryCount = erupted.filter((t) => t.primary).length;
  const permCount = erupted.filter((t) => !t.primary).length;
  const dentition = primaryCount > 0 && permCount > 0 ? "mixed dentition" : primaryCount > 0 ? "primary dentition" : permCount > 0 ? "permanent dentition" : "edentulous (pre-eruption)";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Age", `${age.toFixed(1)} years`],
          ["Dentition", dentition],
          ["Teeth present", `${erupted.length} (${primaryCount} primary, ${permCount} permanent)`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 6.5, 10]} target={[0, 0.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={arch}>
          {/* gum arch: gum balls following the same curve as the teeth */}
          {[-1, 1].map((side) =>
            [...Array(12)].map((_, j) => {
              const a = 0.15 + (j / 11) * 1.3;
              return (
                <mesh key={`${side}-${j}`} position={[side * Math.sin(a) * 2.25, 0.7, Math.cos(a) * 2.25]} castShadow>
                  <sphereGeometry args={[0.5, 14, 14]} />
                  <meshStandardMaterial color="#e0607a" roughness={0.6} />
                </mesh>
              );
            })
          )}
          {TEETH.map((t, i) => {
            const visible = age >= t.erupt && age < t.shed;
            if (!visible) return null;
            return (
              <group key={i} position={[t.x, 1.35, t.z]}>
                <mesh castShadow>
                  <boxGeometry args={[0.42, t.primary ? 0.55 : 0.75, 0.42]} />
                  <meshStandardMaterial color={t.primary ? "#fef9c3" : "#ffffff"} roughness={0.3} />
                </mesh>
                {t.primary && (
                  <mesh position={[0, 0.42, 0]}>
                    <boxGeometry args={[0.3, 0.1, 0.3]} />
                    <meshStandardMaterial color="#fde68a" roughness={0.4} />
                  </mesh>
                )}
              </group>
            );
          })}
        </group>

        <Label p={[0, 3.2, 2.8]} size={0.32} color="#fef9c3">■ primary teeth</Label>
        <Label p={[0, 2.6, 2.8]} size={0.32} color="#ffffff">■ permanent teeth</Label>
        <Label p={[0, -1.8, 3.2]} size={0.34} color="#e2e8f0">
          {age < 6 ? "first tooth ~6 months" : age < 12 ? "mixed dentition: teeth are swapping" : "permanent dentition forming"}
        </Label>

        <Animator arch={arch} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
