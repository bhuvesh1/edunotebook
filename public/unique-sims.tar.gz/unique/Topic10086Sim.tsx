"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "day", label: "Healing day", kind: "slider", min: 0, max: 14, step: 1, default: 6, unit: " days" },
];

export const UNIQUE_META = {
  title: "Wound Healing",
  blurb: "Drag the healing timeline: clot, granulation, collagen and scar close the wound gap day by day.",
};

function Animator({ root, fibro, elapsed, day }: { root: RefObject<THREE.Group>; fibro: RefObject<THREE.Group>; elapsed: RefObject<number>; day: number }) {
  useFrame((_, delta) => {
    elapsed.current += 0.016;
    const t = elapsed.current;
    if (fibro.current) {
      fibro.current.children.forEach((m, i) => {
        const q = (t * 0.5 + i / 8) % 1;
        m.position.set((i % 2 === 0 ? -1 : 1) * (3 - q * 2.6), 1.7 + Math.sin(i * 2) * 0.5, 0.4);
        m.visible = day >= 2 && day <= 12;
      });
    }
  });
  return null;
}

export function Topic10086Sim(props: SimProps) {
  const day = Number(props.day ?? 6);
  const gap = Math.max(0.15, 2.4 * (1 - day / 14));
  const stage = day < 3 ? "hemostasis: clot" : day < 7 ? "proliferation: granulation" : day < 11 ? "collagen deposition" : "remodeling: scar";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const fibro = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Day", `${day}`],
          ["Stage", stage],
          ["Gap", `${gap.toFixed(1)} units`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 11]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[-2.2 - gap / 2, 1.8, 0]} castShadow>
            <boxGeometry args={[3.4, 1.6, 2.4]} /><meshStandardMaterial color="#f4a7b9" roughness={0.65} />
          </mesh>
          <mesh position={[2.2 + gap / 2, 1.8, 0]} castShadow>
            <boxGeometry args={[3.4, 1.6, 2.4]} /><meshStandardMaterial color="#f4a7b9" roughness={0.65} />
          </mesh>
          {day < 3 && (
            <mesh position={[0, 1.8, 0]}><boxGeometry args={[gap + 0.4, 1.2, 2]} /><meshStandardMaterial color="#7f1d1d" roughness={0.8} /></mesh>
          )}
          {day >= 3 && day < 11 && (
            <mesh position={[0, 1.8, 0]}><boxGeometry args={[gap + 0.4, 1.3, 2]} /><meshStandardMaterial color="#fb7185" roughness={0.7} /></mesh>
          )}
          {day >= 5 && Array.from({ length: 7 }).map((_, i) => (
            <mesh key={i} position={[(i - 3) * gap * 0.22, 1.55 + (i % 2) * 0.5, 0.9]} rotation={[0, 0, 0.5]}>
              <boxGeometry args={[0.1, 1.1, 0.08]} /><meshStandardMaterial color="#fef3c7" roughness={0.6} />
            </mesh>
          ))}
          {day >= 11 && (
            <mesh position={[0, 1.8, 0]}><boxGeometry args={[gap + 0.5, 1.35, 2.1]} /><meshStandardMaterial color="#e7d3b7" roughness={0.75} /></mesh>
          )}
          <group ref={fibro}>
            {Array.from({ length: 8 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.16, 10, 10]} /><meshStandardMaterial color="#fbbf24" emissive="#d97706" emissiveIntensity={0.5} /></mesh>
            ))}
          </group>
          <Label text="fibroblasts migrating" position={[0, 3.4, 0.6]} size={0.4} color="#fbbf24" />
          <Label text={`day ${day}: ${stage}`} position={[0, 4.3, 0]} size={0.48} color="#f8fafc" />
          <Label text="wound edges" position={[-4.6, 2.8, 0]} size={0.4} color="#f4a7b9" />
        </group>
        <Animator root={root} fibro={fibro} elapsed={elapsed} day={day} />
      </SimCanvas>
    </div>
  );
}
