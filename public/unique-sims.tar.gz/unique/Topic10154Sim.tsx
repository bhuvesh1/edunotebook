"use client";
// Injuries: mechanical injuries, weapons, regional injuries.
// A body chart with pulsing injury markers; pick the injury type and the
// weapon icons (blunt, sharp, pointed) to see what each one causes.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "injury", label: "Injury type", kind: "select", min: 0, max: 0, step: 1, default: "bruise", options: ["abrasion", "bruise", "laceration"] },
  { key: "speed", label: "Pulse speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Injuries: Mechanical Injuries, Weapons, Regional Injuries",
  blurb: "A body chart marks where each mechanical injury appears — and which weapon causes it.",
};

const INJURY_INFO: Record<string, { color: string; desc: string; weapon: string }> = {
  abrasion: { color: "#f59e0b", desc: "Scratch: skin scraped off", weapon: "rough surface" },
  bruise: { color: "#7c3aed", desc: "Bleeding under skin", weapon: "blunt weapon" },
  laceration: { color: "#ef4444", desc: "Torn skin, ragged edges", weapon: "blunt / sharp edge" },
};

const MARKS: [number, number][] = [[-1.5, 3.4], [1.2, 2.6], [-0.6, 1.6], [1.8, 1.2], [-1.2, 0.4]];

function Animator({ marks, elapsed, speed }: { marks: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (marks.current) {
      marks.current.children.forEach((m, i) => {
        const s = 1 + Math.sin(elapsed.current * 3 + i * 1.3) * 0.25;
        m.scale.set(s, s, s);
      });
    }
  });
  return null;
}

export function Topic10154Sim(props: SimProps) {
  const injury = String(props.injury ?? "bruise");
  const speed = Number(props.speed ?? 1);
  const marks = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = INJURY_INFO[injury] ?? INJURY_INFO.bruise;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Injury", injury], ["Looks like", info.desc], ["Caused by", info.weapon]]} />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* body chart silhouette */}
        <group position={[-2.2, 0, 0]}>
          <mesh position={[0, 4.1, 0]} castShadow>
            <sphereGeometry args={[0.55, 20, 20]} />
            <meshStandardMaterial color="#cbd5e1" roughness={0.8} />
          </mesh>
          <mesh position={[0, 2.7, 0]} castShadow>
            <capsuleGeometry args={[0.75, 1.4, 6, 16]} />
            <meshStandardMaterial color="#cbd5e1" roughness={0.8} />
          </mesh>
          {[[-1.05, 2.9], [1.05, 2.9]].map(([x, y]) => (
            <mesh key={x} position={[x, y, 0]} rotation={[0, 0, x > 0 ? -0.25 : 0.25]} castShadow>
              <capsuleGeometry args={[0.22, 1.3, 4, 10]} />
              <meshStandardMaterial color="#cbd5e1" roughness={0.8} />
            </mesh>
          ))}
          {[[-0.35, 0.7], [0.35, 0.7]].map(([x, y]) => (
            <mesh key={x} position={[x, y, 0]} castShadow>
              <capsuleGeometry args={[0.26, 1.2, 4, 10]} />
              <meshStandardMaterial color="#cbd5e1" roughness={0.8} />
            </mesh>
          ))}
          <group ref={marks}>
            {MARKS.map(([x, y], i) => (
              <mesh key={i} position={[x, y, 0.55]}>
                <sphereGeometry args={[0.28, 14, 14]} />
                <meshStandardMaterial color={info.color} emissive={info.color} emissiveIntensity={0.8} />
              </mesh>
            ))}
          </group>
          <Label text="BODY CHART" position={[0, 5.3, 0]} size={0.6} color="#fbbf24" />
        </group>
        {/* weapon icons */}
        <group position={[3.6, 0, 0]}>
          {/* blunt: club */}
          <group position={[-1.4, 1.6, 0]} rotation={[0, 0, 0.5]}>
            <mesh castShadow>
              <cylinderGeometry args={[0.16, 0.24, 1.8, 10]} />
              <meshStandardMaterial color="#92400e" roughness={0.7} />
            </mesh>
          </group>
          <Label text="BLUNT" position={[-1.4, 0.5, 0]} size={0.5} />
          {/* sharp: knife */}
          <group position={[0.2, 1.7, 0]} rotation={[0, 0, -0.4]}>
            <mesh position={[0, 0.55, 0]} castShadow>
              <boxGeometry args={[0.16, 1.1, 0.05]} />
              <meshStandardMaterial color="#e2e8f0" metalness={0.85} roughness={0.25} />
            </mesh>
            <mesh position={[0, -0.35, 0]}>
              <boxGeometry args={[0.24, 0.7, 0.12]} />
              <meshStandardMaterial color="#1e293b" roughness={0.7} />
            </mesh>
          </group>
          <Label text="SHARP" position={[0.2, 0.5, 0]} size={0.5} />
          {/* pointed: spike */}
          <group position={[1.7, 1.7, 0]}>
            <mesh castShadow>
              <coneGeometry args={[0.2, 1.9, 10]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.7} roughness={0.35} />
            </mesh>
          </group>
          <Label text="POINTED" position={[1.7, 0.5, 0]} size={0.5} />
          <Label text="WEAPONS" position={[0.2, 3.4, 0]} size={0.65} color="#fbbf24" />
        </group>
        <Animator marks={marks} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
