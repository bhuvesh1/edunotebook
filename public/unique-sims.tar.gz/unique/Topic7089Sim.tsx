// app/components/sims/unique/Topic7089Sim.tsx
// Distance vs displacement: a walker follows a long zigzag path (blue =
// distance travelled) while the red arrow shows the straight-line
// displacement from start to finish. The numbers prove they differ.

"use client";

import { useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Walking speed", kind: "slider", min: 0.5, max: 3, step: 0.1, default: 1.4, unit: "m/s" },
];

export const UNIQUE_META = {
  title: "Distance and Displacement",
  blurb: "A walker takes the long zigzag way home — compare the path length with the straight-line displacement.",
};

// Waypoints of the walker's zigzag path (x, z).
const WAY: [number, number][] = [
  [-4.5, 0],
  [-2.5, 3],
  [1.5, 3],
  [1.5, -2.5],
  [4.5, -2.5],
];

function segLens() {
  const lens: number[] = [];
  for (let i = 0; i < WAY.length - 1; i++) {
    const dx = WAY[i + 1][0] - WAY[i][0];
    const dz = WAY[i + 1][1] - WAY[i][1];
    lens.push(Math.hypot(dx, dz));
  }
  return lens;
}
const LENS = segLens();
const TOTAL = LENS.reduce((a, b) => a + b, 0);
const DISP = Math.hypot(WAY[WAY.length - 1][0] - WAY[0][0], WAY[WAY.length - 1][1] - WAY[0][1]);

function pointAt(d: number): { x: number; z: number; ang: number } {
  let dd = ((d % TOTAL) + TOTAL) % TOTAL;
  for (let i = 0; i < LENS.length; i++) {
    if (dd <= LENS[i] || i === LENS.length - 1) {
      const f = LENS[i] === 0 ? 0 : dd / LENS[i];
      const x = WAY[i][0] + (WAY[i + 1][0] - WAY[i][0]) * f;
      const z = WAY[i][1] + (WAY[i + 1][1] - WAY[i][1]) * f;
      const ang = Math.atan2(WAY[i + 1][0] - WAY[i][0], WAY[i + 1][1] - WAY[i][1]);
      return { x, z, ang };
    }
    dd -= LENS[i];
  }
  return { x: WAY[0][0], z: WAY[0][1], ang: 0 };
}

function Animator({
  walker,
  speed,
  dist,
  bump,
}: {
  walker: RefObject<THREE.Group>;
  speed: number;
  dist: RefObject<number>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    // Walk the path, pause 1.5 s at the end, then loop.
    const cycle = TOTAL / speed + 1.5;
    const ct = t.current % cycle;
    const d = Math.min(ct * speed, TOTAL);
    dist.current = d;
    const p = pointAt(d);
    if (walker.current) {
      walker.current.position.set(p.x, 0, p.z);
      walker.current.rotation.y = p.ang;
      // Bob while walking.
      walker.current.position.y = d >= TOTAL ? 0 : Math.abs(Math.sin(t.current * 10)) * 0.08;
    }
    if (++n.current % 20 === 0) bump();
  });
  return null;
}

export function Topic7089Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1.4);
  const walker = useRef<THREE.Group>(null!);
  const dist = useRef(0);
  const [, bump] = useState(0);

  const pathLine = useMemo(
    () =>
      new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(WAY.map(([x, z]) => new THREE.Vector3(x, 0.06, z))),
        new THREE.LineBasicMaterial({ color: "#38bdf8" })
      ),
    []
  );

  // Displacement arrow from start to finish (red).
  const dispArrow = useMemo(() => {
    const [x0, z0] = WAY[0];
    const [x1, z1] = WAY[WAY.length - 1];
    const dir = new THREE.Vector3(x1 - x0, 0, z1 - z0);
    const len = dir.length();
    const g = new THREE.Group();
    const shaft = new THREE.Mesh(
      new THREE.CylinderGeometry(0.07, 0.07, len - 0.5, 10),
      new THREE.MeshStandardMaterial({ color: "#ef4444", roughness: 0.5 })
    );
    shaft.position.y = (len - 0.5) / 2;
    const head = new THREE.Mesh(
      new THREE.ConeGeometry(0.22, 0.5, 14),
      new THREE.MeshStandardMaterial({ color: "#ef4444", roughness: 0.5 })
    );
    head.position.y = len - 0.25;
    g.add(shaft, head);
    g.position.set(x0, 0.1, z0);
    g.rotation.y = Math.atan2(dir.x, dir.z);
    g.rotation.x = Math.PI / 2;
    // Lay the +Y-built arrow along the ground direction.
    g.rotation.set(0, 0, 0);
    g.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
    return g;
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Distance walked", `${dist.current.toFixed(1)} / ${TOTAL.toFixed(1)} m`],
          ["Displacement", `${DISP.toFixed(1)} m`],
          ["● Blue path", "distance"],
          ["● Red arrow", "displacement"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 9, 11]} target={[0, 0, 0.5]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <primitive object={pathLine} />
        <primitive object={dispArrow} />
        {/* start / finish markers */}
        <mesh position={[WAY[0][0], 0.1, WAY[0][1]]}>
          <cylinderGeometry args={[0.35, 0.35, 0.2, 20]} />
          <meshStandardMaterial color="#22c55e" roughness={0.5} />
        </mesh>
        <mesh position={[WAY[WAY.length - 1][0], 0.1, WAY[WAY.length - 1][1]]}>
          <cylinderGeometry args={[0.35, 0.35, 0.2, 20]} />
          <meshStandardMaterial color="#ef4444" roughness={0.5} />
        </mesh>

        {/* the walker */}
        <group ref={walker}>
          <mesh position={[0, 0.95, 0]} castShadow>
            <capsuleGeometry args={[0.28, 0.7, 8, 16]} />
            <meshStandardMaterial color="#f59e0b" roughness={0.5} />
          </mesh>
          <mesh position={[0, 1.75, 0]} castShadow>
            <sphereGeometry args={[0.26, 20, 20]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.5} />
          </mesh>
        </group>

        <Animator walker={walker} speed={speed} dist={dist} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
