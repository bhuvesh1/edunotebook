// Liver abscess, portal hypertension & liver tumors — the portal vein backs
// up (pressure slider): esophageal varices swell like worms, the spleen
// enlarges, ascites fills the belly; plus an abscess pocket and a tumor
// nodule selectable on the liver.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "portal", label: "Portal pressure", kind: "slider", min: 5, max: 30, step: 1, default: 18, unit: " mmHg" },
  { key: "lesion", label: "Liver lesion", kind: "select", min: 0, max: 0, step: 1, default: "none", options: ["none", "abscess", "tumor"] },
];

export const UNIQUE_META = {
  title: "Portal Hypertension",
  blurb: "Scarred liver chokes the portal vein — varices swell in the food pipe, the spleen balloons, and the belly fills with fluid.",
};

function Animator({ varices, elapsed, portal }: {
  varices: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  portal: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (varices.current) {
      // varices throb dangerously with pressure
      varices.current.children.forEach((c, i) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = ((portal - 5) / 25) * (0.4 + 0.35 * Math.sin(t * 5 + i * 1.7));
      });
    }
  });
  return null;
}

export function Topic10248Sim(props: SimProps) {
  const portal = Number(props.portal ?? 18);
  const lesion = String(props.lesion ?? "none");
  const varices = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const p = (portal - 5) / 25; // 0..1
  const varixR = 0.1 + p * 0.22;
  const spleenScale = 1 + p * 0.8;

  const varixStrands = useMemo(() => {
    return Array.from({ length: 7 }).map((_, i) => ({
      x: -3.9 + (i % 3) * 0.35 - 0.3,
      z: 0.3 + ((i * 0.4) % 0.5),
      h: 2.6 + ((i * 0.53) % 0.8),
    }));
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Portal pressure", `${portal} mmHg (normal < 12)`], ["Varices", portal > 12 ? "present — bleed risk ⚠" : "none"], ["Spleen", p > 0.4 ? "enlarged" : "normal"], ["Lesion", lesion]]} />
      <SimCanvas cameraPosition={[0, 3.2, 13.5]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* cirrhotic liver */}
        <group position={[0.8, 3.4, 0]}>
          <mesh scale={[1.7, 1.0, 1.0]} castShadow>
            <sphereGeometry args={[1.25, 28, 20]} />
            <meshStandardMaterial color="#92400e" roughness={0.95} />
          </mesh>
          {Array.from({ length: 12 }).map((_, i) => (
            <mesh key={i} position={[((i * 0.83) % 3.4) - 1.7, ((i * 0.57) % 1.5) - 0.4, 0.9]}>
              <sphereGeometry args={[0.13 + ((i * 0.17) % 0.1), 10, 8]} />
              <meshStandardMaterial color="#d6a05c" roughness={0.9} />
            </mesh>
          ))}
          {/* abscess pocket */}
          {lesion === "abscess" && (
            <mesh position={[1.2, 0.3, 0.6]}>
              <sphereGeometry args={[0.55, 16, 12]} />
              <meshStandardMaterial color="#facc15" roughness={0.35} emissive="#a16207" emissiveIntensity={0.5} transparent opacity={0.9} />
            </mesh>
          )}
          {/* tumor nodule */}
          {lesion === "tumor" && (
            <mesh position={[-1.0, 0.4, 0.6]}>
              <dodecahedronGeometry args={[0.5, 1]} />
              <meshStandardMaterial color="#7f1d1d" roughness={0.6} emissive="#dc2626" emissiveIntensity={0.4} flatShading />
            </mesh>
          )}
          {lesion !== "none" && <Label text={lesion === "abscess" ? "Amoebic abscess — anchovy-sauce pus" : "Liver tumor"} position={[0.8, 5.4, 0]} size={0.5} color="#fca5a5" />}
        </group>

        {/* portal vein, engorged */}
        <mesh position={[0.8, 1.9, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.28 + p * 0.25, 0.28 + p * 0.25, 3.2, 14]} />
          <meshStandardMaterial color="#7c3aed" roughness={0.5} />
        </mesh>
        <Label text="Portal vein — backed up" position={[0.8, 1.1, 0]} size={0.46} color="#c4b5fd" />

        {/* esophageal varices */}
        <mesh position={[-3.9, 3.6, 0.3]} castShadow>
          <cylinderGeometry args={[0.4, 0.45, 3.6, 14, 1, true]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.55} side={THREE.DoubleSide} />
        </mesh>
        <group ref={varices}>
          {varixStrands.map((v, i) => (
            <mesh key={i} position={[v.x, v.h, v.z]}>
              <capsuleGeometry args={[varixR, 1.8, 6, 10]} />
              <meshStandardMaterial color="#dc2626" roughness={0.45} emissive="#7f1d1d" emissiveIntensity={0.4} />
            </mesh>
          ))}
        </group>
        <Label text={portal > 12 ? "Varices — can burst & bleed ⚠" : "Esophagus"} position={[-3.9, 5.9, 0.3]} size={0.5} color={portal > 12 ? "#fca5a5" : "#e2e8f0"} />

        {/* enlarged spleen */}
        <mesh position={[3.9, 2.8, 0]} scale={[spleenScale, spleenScale * 1.3, spleenScale * 0.8]} castShadow>
          <sphereGeometry args={[0.7, 20, 16]} />
          <meshStandardMaterial color="#7c3aed" roughness={0.55} />
        </mesh>
        <Label text={`Spleen ${p > 0.4 ? "enlarged" : ""}`} position={[3.9, 4.6, 0]} size={0.46} color="#c4b5fd" />

        {/* ascites */}
        {p > 0.35 && (
          <mesh position={[0, -0.7, 0]}>
            <cylinderGeometry args={[4.2, 4.6, 1.8, 28]} />
            <meshStandardMaterial color="#38bdf8" transparent opacity={0.2 + p * 0.3} roughness={0.2} />
          </mesh>
        )}

        <Label text="Blood finds detours → varices, spleen, belly fluid" position={[0, -2.2, 0]} size={0.44} color="#94a3b8" />
        <Animator varices={varices} elapsed={elapsed} portal={portal} />
      </SimCanvas>
    </div>
  );
}
