"use client";
// Cleaning & Shaping: Hand and Rotary Instrumentation — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "instrument", label: "Instrument", kind: "select", min: 0, max: 0, step: 1, default: "Rotary NiTi", options: ["Rotary NiTi", "Hand K-file"] },
];

export const UNIQUE_META = {
  title: "Cleaning & Shaping: Hand and Rotary Instrumentation",
  blurb: "A file spins inside the root canal, scrubbing debris out — rotary spins fast, hand files use quarter-turns.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const rotary = p.instrument === "Rotary NiTi";
    const file: any = g("file");
    if (file) {
      const peck = 0.5 + 0.5 * Math.sin(t * 3.2);
      file.position.y = 3.1 - peck * 0.55;
      file.rotation.y = rotary ? t * 14 : Math.sin(t * 2.2) * 0.9;
    }
    for (let i = 0; i < 6; i++) {
      const d: any = g("deb" + i);
      if (d) {
        const ph = (t * 0.9 + i / 6) % 1;
        const a = t * 2 + (i * Math.PI) / 3;
        d.position.set(Math.cos(a) * (0.3 + ph * 0.9), 2.9 + ph * 1.4, Math.sin(a) * (0.3 + ph * 0.9));
        const s = Math.max(0.001, 1 - ph);
        d.scale.setScalar(s * 0.09);
      }
    }
    group.current.rotation.y = Math.sin(t * 0.25) * 0.25;
  });
  return null;
}

export function Topic10451Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const instrument = String(props.instrument ?? "Rotary NiTi");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, instrument };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Instrument", instrument],
          ["Motion", instrument === "Rotary NiTi" ? "Continuous rotation" : "Quarter-turn pull"],
          ["Speed", `${speed.toFixed(1)}×`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1, 0]} scale={1.5} showCanal name="endo" />
          <GumSlab position={[0, 0.1, 0]} scale={1.2} />
          <group name="file" position={[0, 3.1, 0]}>
            <mesh>
              <cylinderGeometry args={[0.05, 0.035, 2.2, 10]} />
              <meshStandardMaterial color="#e2e8f0" metalness={0.9} roughness={0.25} />
            </mesh>
            <mesh position={[0, 1.25, 0]}>
              <boxGeometry args={[0.16, 0.35, 0.16]} />
              <meshStandardMaterial color="#38bdf8" roughness={0.5} />
            </mesh>
          </group>
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <mesh key={i} name={"deb" + i}>
              <sphereGeometry args={[1, 8, 8]} />
              <meshStandardMaterial color="#a16207" roughness={0.9} />
            </mesh>
          ))}
          <Label text="Rotary NiTi file" position={[2.1, 3.6, 0]} size={0.42} />
          <Label text="Root canal" position={[-2.2, 1.4, 0]} size={0.42} />
          <Label text="Debris flushed out" position={[2.3, 2.2, 0]} size={0.42} color="#fbbf24" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
