// Ocular trauma — a metal foreign body flies in and embeds in the cornea
// (penetration slider); chemical splash option burns the surface red;
// globe rupture option cracks the eyeball open.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "depth", label: "Foreign-body depth", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "injury", label: "Injury type", kind: "select", min: 0, max: 0, step: 1, default: "foreign body", options: ["foreign body", "chemical burn", "globe rupture"] },
];

export const UNIQUE_META = {
  title: "Ocular Trauma",
  blurb: "A metal shard embeds in the cornea, acid splashes the surface, or the globe ruptures — penetration depth is on a slider.",
};

function Animator({ shard, elapsed, injury }: {
  shard: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  injury: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (shard.current) {
      // the shard vibrates as it strikes; then sits embedded
      const strike = Math.max(0, 1 - (t % 5) / 1.2);
      shard.current.position.z = Math.sin(t * 60) * 0.03 * strike;
      shard.current.visible = injury === "foreign body";
    }
  });
  return null;
}

export function Topic10210Sim(props: SimProps) {
  const depth = Number(props.depth ?? 55);
  const injury = String(props.injury ?? "foreign body");
  const shard = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  // shard tip goes from surface (x=2.1) into the eye
  const shardX = 2.55 - (depth / 100) * 1.6;
  const ruptured = injury === "globe rupture";
  const chemBurn = injury === "chemical burn";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Injury", injury], injury === "foreign body" ? ["Penetration", `${depth}%`] : ["Urgency", ruptured ? "EMERGENCY — shield, no pressure" : "irrigate 20+ min"]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10.5]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* eyeball */}
        <mesh position={[0, 1.2, 0]} castShadow>
          <sphereGeometry args={[2.1, 36, 26]} />
          <meshStandardMaterial color={chemBurn ? "#f87171" : "#f8fafc"} roughness={0.35} />
        </mesh>
        {/* globe rupture: crack wedges */}
        {ruptured && (
          <group>
            {[-0.6, 0, 0.6].map((dz, i) => (
              <mesh key={i} position={[1.55, 2.1 - i * 0.35, dz]} rotation={[0, 0.4, 0.5 - i * 0.3]}>
                <boxGeometry args={[0.7, 0.12, 0.3]} />
                <meshStandardMaterial color="#450a0a" roughness={0.9} />
              </mesh>
            ))}
            <mesh position={[1.9, 1.9, 0]}>
              <sphereGeometry args={[0.5, 14, 12]} />
              <meshStandardMaterial color="#dc2626" roughness={0.4} emissive="#7f1d1d" emissiveIntensity={0.5} />
            </mesh>
          </group>
        )}
        {/* chemical burn: splash droplets eating the surface */}
        {chemBurn && (
          <group>
            {Array.from({ length: 14 }).map((_, i) => {
              const a = (i * 2.4) % (Math.PI * 2);
              return (
                <mesh key={i} position={[1.3 + Math.cos(a) * 0.9, 1.2 + Math.sin(a) * 1.1, 1.2]}>
                  <sphereGeometry args={[0.16 + ((i * 0.13) % 0.12), 10, 8]} />
                  <meshStandardMaterial color="#fbbf24" roughness={0.3} emissive="#b45309" emissiveIntensity={0.6} />
                </mesh>
              );
            })}
            <Label text="ACID — irrigate NOW" position={[1.4, 3.8, 1.2]} size={0.55} color="#fbbf24" />
          </group>
        )}

        {/* cornea + iris */}
        <mesh position={[0, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <sphereGeometry args={[1.98, 36, 20, -Math.PI * 0.24, Math.PI * 0.48, Math.PI * 0.3, Math.PI * 0.4]} />
          <meshStandardMaterial color="#bae6fd" transparent opacity={0.4} roughness={0.15} />
        </mesh>
        <mesh position={[1.95, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.68, 0.32, 14, 32]} />
          <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
        </mesh>

        {/* incoming metal shard */}
        {injury === "foreign body" && (
          <group ref={shard}>
            <mesh position={[shardX, 1.75, 0]} rotation={[0, 0, Math.PI / 2]}>
              <coneGeometry args={[0.14, 1.4, 8]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.9} roughness={0.25} />
            </mesh>
            <Arrow from={[shardX + 1.6, 1.75, 0]} to={[shardX + 0.75, 1.75, 0]} color="#fbbf24" radius={0.06} />
            <Label text="Metal foreign body" position={[shardX + 0.6, 2.6, 0]} size={0.5} color="#e2e8f0" />
            {depth > 70 && <Label text="Perforated — inside the eye ⚠" position={[shardX, 0.3, 0]} size={0.48} color="#fca5a5" />}
          </group>
        )}

        <Label text="NEVER rub · shield it · get help fast" position={[0, -1.9, 0]} size={0.44} color="#94a3b8" />
        <Animator shard={shard} elapsed={elapsed} injury={injury} />
      </SimCanvas>
    </div>
  );
}
