// Gram-negative cocci & Gram-positive bacilli: pink Neisseria pairs
// (diplococci) tumble beside sturdy purple rods with protective spores.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Gram-negative cocci, Gram-positive bacilli",
  blurb: "Pink Neisseria diplococci tumble beside sturdy purple rods carrying tough endospores.",
};

const N_PAIRS = 6;
const N_RODS = 5;

function Animator({ pairs, rods, elapsed, speed, setTick }: {
  pairs: React.RefObject<(THREE.Group | null)[]>;
  rods: React.RefObject<(THREE.Group | null)[]>;
  elapsed: React.RefObject<number>;
  speed: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    pairs.current.forEach((g, i) => {
      if (!g) return;
      g.position.y = 1.7 + Math.sin(t * 2.2 + i * 1.6) * 0.22;
      g.rotation.z = Math.sin(t * 1.4 + i) * 0.5;
      g.rotation.y = t * 0.8 + i;
    });
    rods.current.forEach((g, i) => {
      if (!g) return;
      g.position.y = 1.5 + Math.cos(t * 1.6 + i * 2.1) * 0.15;
      g.rotation.z = Math.PI / 2 + Math.sin(t * 1.1 + i * 1.3) * 0.25;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(t * 10)); }
  });
  return null;
}

export function Topic10132Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const pairs = useRef<(THREE.Group | null)[]>([]);
  const rods = useRef<(THREE.Group | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Neisseria (G− cocci)", "pink pairs"],
          ["Bacilli (G+ rods)", "purple, with spores"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* Neisseria: pink diplococci pairs (coffee-bean pairs) */}
        {Array.from({ length: N_PAIRS }).map((_, i) => (
          <group
            key={i}
            ref={(g) => { pairs.current[i] = g; }}
            position={[-3.4 + (i % 3) * 1.1 - 1, 1.7, Math.floor(i / 3) * 1.2 - 0.6]}
          >
            {[-0.22, 0.22].map((x, j) => (
              <mesh key={j} position={[x, 0, 0]} scale={[1, 0.85, 0.85]} castShadow>
                <sphereGeometry args={[0.3, 16, 12]} />
                <meshStandardMaterial color="#f472b6" roughness={0.45} />
              </mesh>
            ))}
          </group>
        ))}
        {showLabels && <Label text="Neisseria — pink diplococci (G−)" position={[-3.4, 3.3, 0]} color="#f9a8d4" />}

        {/* Gram-positive bacilli: purple rods, one with a terminal spore */}
        {Array.from({ length: N_RODS }).map((_, i) => (
          <group
            key={`r${i}`}
            ref={(g) => { rods.current[i] = g; }}
            position={[2.2 + (i % 3) * 1.3, 1.5, Math.floor(i / 3) * 1.4 - 0.7]}
          >
            <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
              <capsuleGeometry args={[0.26, 1.1, 6, 12]} />
              <meshStandardMaterial color="#7c3aed" roughness={0.45} />
            </mesh>
            {i === 2 && (
              <mesh position={[0.85, 0, 0]}>
                <sphereGeometry args={[0.3, 14, 10]} />
                <meshStandardMaterial color="#fde047" emissive="#a16207" emissiveIntensity={0.6} roughness={0.4} />
              </mesh>
            )}
          </group>
        ))}
        {showLabels && <Label text="Gram-positive bacilli (rods)" position={[3.2, 3.3, 0]} color="#c4b5fd" />}
        {showLabels && <Label text="endospore — survives boiling!" position={[4.6, 2.2, -0.7]} size={0.4} color="#fde047" />}

        <mesh position={[-0.1, 1.6, 0]}>
          <boxGeometry args={[0.06, 3.8, 0.06]} />
          <meshStandardMaterial color="#334155" />
        </mesh>

        <Animator pairs={pairs} rods={rods} elapsed={elapsed} speed={speed} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
