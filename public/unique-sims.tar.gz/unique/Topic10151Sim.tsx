"use client";
// Medical jurisprudence: consent, negligence, medical records.
// A doctor figure beside a consent form on a clipboard; a signature
// draws itself while record pages stack up — consent before treatment.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "scenario", label: "Scenario", kind: "select", min: 0, max: 0, step: 1, default: "consent", options: ["consent", "refusal", "records"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Medical Jurisprudence: Consent, Negligence, Records",
  blurb: "Watch valid consent get signed before treatment, and see why complete medical records protect everyone.",
};

function Animator({ pen, page, elapsed, speed }: { pen: React.RefObject<THREE.Group>; page: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current % 6;
    const draw = Math.min(1, t / 3.2); // signature draws over ~3.2s
    if (pen.current) {
      pen.current.position.x = -2.9 + draw * 1.7 + Math.sin(t * 9) * 0.08 * draw;
      pen.current.position.y = 1.55 + Math.sin(draw * Math.PI * 3) * 0.14;
    }
    if (page.current) {
      const s = page.current.scale;
      page.current.scale.set(Math.max(0.02, draw), s.y, s.z);
    }
  });
  return null;
}

export function Topic10151Sim(props: SimProps) {
  const scenario = String(props.scenario ?? "consent");
  const speed = Number(props.speed ?? 1);
  const pen = useRef<THREE.Group>(null!);
  const page = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const sigColor = scenario === "refusal" ? "#ef4444" : scenario === "records" ? "#38bdf8" : "#22c55e";
  const sigText = scenario === "refusal" ? "REFUSED" : scenario === "records" ? "FILED" : "CONSENT";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Scenario", scenario], ["Form", sigText]]} />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* doctor figure */}
        <group position={[-4.6, 0, 0]}>
          <mesh position={[0, 0.75, 0]} castShadow>
            <capsuleGeometry args={[0.5, 1.1, 6, 14]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.7} />
          </mesh>
          <mesh position={[0, 2.15, 0]} castShadow>
            <sphereGeometry args={[0.42, 20, 20]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
          <mesh position={[0, 2.62, 0]}>
            <sphereGeometry args={[0.3, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <meshStandardMaterial color="#1e293b" roughness={0.7} />
          </mesh>
          <Label text="DOCTOR" position={[0, 3.3, 0]} size={0.55} />
        </group>
        <Arrow from={[-3.4, 1.6, 0]} to={[-1.6, 1.6, 0]} color="#38bdf8" />
        {/* clipboard with consent form */}
        <group position={[0.4, 0, 0]} rotation={[-0.12, 0, 0]}>
          <mesh position={[0, 1.7, -0.08]} castShadow>
            <boxGeometry args={[3.4, 4.4, 0.14]} />
            <meshStandardMaterial color="#92400e" roughness={0.7} />
          </mesh>
          <mesh position={[0, 1.7, 0]}>
            <boxGeometry args={[3, 4, 0.06]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.9} />
          </mesh>
          <mesh position={[0, 3.5, 0.08]}>
            <boxGeometry args={[0.8, 0.4, 0.12]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.6} roughness={0.4} />
          </mesh>
          {/* form lines */}
          {[2.9, 2.55, 2.2].map((y) => (
            <mesh key={y} position={[0, y, 0.05]}>
              <boxGeometry args={[2.4, 0.07, 0.02]} />
              <meshStandardMaterial color="#cbd5e1" roughness={0.9} />
            </mesh>
          ))}
          {/* signature that draws itself */}
          <mesh ref={page} position={[-2.05, 1.15, 0.05]}>
            <boxGeometry args={[1.9, 0.16, 0.03]} />
            <meshStandardMaterial color={sigColor} roughness={0.6} />
          </mesh>
          <group ref={pen} position={[-2.9, 1.55, 0.2]}>
            <mesh rotation={[0.4, 0, 0.5]} castShadow>
              <cylinderGeometry args={[0.05, 0.02, 0.9, 8]} />
              <meshStandardMaterial color="#1d4ed8" roughness={0.5} />
            </mesh>
          </group>
          <Label text={sigText} position={[0, 0.35, 0.3]} size={0.65} color={sigColor} />
          <Label text="CONSENT FORM" position={[0, 4.35, 0]} size={0.6} color="#fbbf24" />
        </group>
        {/* record pages stacking */}
        <group position={[4.4, 0, 0]}>
          {[0, 1, 2, 3, 4].map((i) => (
            <mesh key={i} position={[0, 0.35 + i * 0.22, 0]} rotation={[0, i * 0.12, 0]} castShadow>
              <boxGeometry args={[2.2, 0.16, 2.8]} />
              <meshStandardMaterial color={i === 4 ? "#38bdf8" : "#e2e8f0"} roughness={0.9} />
            </mesh>
          ))}
          <Label text="MEDICAL RECORDS" position={[0, 2.2, 0]} size={0.6} color="#38bdf8" />
        </group>
        <Animator pen={pen} page={page} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
