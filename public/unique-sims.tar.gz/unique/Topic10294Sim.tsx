// Fracture basics: classification, healing, principles of management.
// A long bone snaps — then heals in four stages: blood clot, soft callus,
// hard bony callus, and remodeling. Compare a plaster cast with a metal plate.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Healing stage", kind: "select", min: 0, max: 0, step: 1, default: "auto", options: ["auto", "hematoma", "soft_callus", "hard_callus", "remodeled"] },
  { key: "treatment", label: "Treatment", kind: "select", min: 0, max: 0, step: 1, default: "cast", options: ["cast", "plate", "none"] },
];

export const UNIQUE_META = {
  title: "Broken Bone: How It Heals",
  blurb: "A bone breaks, bleeds, then rebuilds itself in four stages — held still by a cast or a screwed-on plate.",
};

const STAGE_INFO = [
  ["hematoma", "1. Blood clot forms"],
  ["soft_callus", "2. Soft callus (cartilage)"],
  ["hard_callus", "3. Hard bony callus"],
  ["remodeled", "4. Remodeled — as good as new"],
];

function Animator({
  group, callus, elapsed, stage,
}: {
  group: React.RefObject<THREE.Group>;
  callus: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  stage: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    const idx = stage === "auto" ? Math.floor((t % 16) / 4) : STAGE_INFO.findIndex(([k]) => k === stage);
    if (callus.current) {
      const m = callus.current.material as THREE.MeshStandardMaterial;
      if (idx === 0) {
        callus.current.visible = true;
        callus.current.scale.set(1.1, 0.9, 1.1);
        m.color.set("#b91c1c"); m.emissive.set("#7f1d1d"); m.emissiveIntensity = 0.4 + 0.3 * Math.sin(t * 4);
      } else if (idx === 1) {
        callus.current.visible = true;
        callus.current.scale.set(1.5, 1.2, 1.5);
        m.color.set("#fbbf24"); m.emissive.set("#92400e"); m.emissiveIntensity = 0.2;
      } else if (idx === 2) {
        callus.current.visible = true;
        callus.current.scale.set(1.35, 1.1, 1.35);
        m.color.set("#e2e8f0"); m.emissive.set("#000000"); m.emissiveIntensity = 0;
      } else {
        callus.current.visible = false; // remodeled: invisible repair
      }
    }
  });
  return null;
}

export function Topic10294Sim(props: SimProps) {
  const stage = String(props.stage ?? "auto");
  const treatment = String(props.treatment ?? "cast");
  const group = useRef<THREE.Group>(null!);
  const callus = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const stageIdx = stage === "auto" ? -1 : STAGE_INFO.findIndex(([k]) => k === stage);
  const stageLabel = stage === "auto" ? "Healing cycle (auto)" : STAGE_INFO[stageIdx]?.[1] ?? stage;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Stage", stageLabel], ["Treatment", treatment === "cast" ? "Plaster cast" : treatment === "plate" ? "Plate + screws" : "No fixation"]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* long bone: two broken ends with jagged gap */}
          <mesh position={[0, 3.35, 0]} castShadow>
            <cylinderGeometry args={[0.34, 0.4, 2.2, 16]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <mesh position={[0, 3.35, 0]}>
            <cylinderGeometry args={[0.2, 0.2, 2.25, 12]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.75, 0]} rotation={[0, 0, 0.06]} castShadow>
            <cylinderGeometry args={[0.4, 0.34, 2.0, 16]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <mesh position={[0, 0.75, 0]}>
            <cylinderGeometry args={[0.2, 0.2, 2.05, 12]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.6} />
          </mesh>
          {/* jagged fracture spikes */}
          {[-0.22, 0, 0.22].map((x, i) => (
            <mesh key={i} position={[x, 2.12, 0]} rotation={[0, 0, x * 2]} castShadow>
              <coneGeometry args={[0.09, 0.4 + (i % 2) * 0.15, 6]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.5} flatShading />
            </mesh>
          ))}
          {/* healing callus bridging the gap */}
          <mesh ref={callus} position={[0, 2.05, 0]} castShadow>
            <sphereGeometry args={[0.5, 18, 14]} />
            <meshStandardMaterial color="#b91c1c" roughness={0.6} />
          </mesh>
          {/* plaster cast */}
          {treatment === "cast" && (
            <mesh position={[0, 2.0, 0]} castShadow>
              <cylinderGeometry args={[0.62, 0.62, 3.6, 18]} />
              <meshStandardMaterial color="#fef3c7" roughness={0.8} />
            </mesh>
          )}
          {/* plate + screws */}
          {treatment === "plate" && (
            <group>
              <mesh position={[0, 2.05, 0.42]} castShadow>
                <boxGeometry args={[0.35, 2.6, 0.1]} />
                <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
              </mesh>
              {[-0.9, -0.45, 0.45, 0.9].map((dy, i) => (
                <mesh key={i} position={[0, 2.05 + dy, 0.42]} rotation={[Math.PI / 2, 0, 0]} castShadow>
                  <cylinderGeometry args={[0.09, 0.09, 0.35, 10]} />
                  <meshStandardMaterial color="#64748b" metalness={0.85} roughness={0.3} />
                </mesh>
              ))}
            </group>
          )}
          <Label text="Broken ends" position={[-2.0, 2.9, 0]} size={0.5} color="#e2e8f0" />
          <Label text="Marrow" position={[1.7, 3.3, 0]} size={0.5} color="#fde68a" />
          {treatment === "cast" && <Label text="Plaster holds it still" position={[1.9, 1.2, 0]} size={0.5} color="#fef3c7" />}
          {treatment === "plate" && <Label text="Plate + screws" position={[1.9, 2.5, 0.4]} size={0.5} color="#cbd5e1" />}
          {stageIdx === 3 && <Label text="✨ Remodeled — strong again" position={[0, 0.05, 0]} size={0.55} color="#86efac" />}
        </group>
        <Animator group={group} callus={callus} elapsed={elapsed} stage={stage} />
      </SimCanvas>
    </div>
  );
}
