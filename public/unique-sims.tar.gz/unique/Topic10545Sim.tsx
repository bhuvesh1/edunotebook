// app/components/sims/unique/Topic10545Sim.tsx
// Special health care needs children: a calm, friendly dental visit — child
// in the dental chair, gentle dentist figure, and a comfort toy. Everything
// moves slowly and reassuringly.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 0.7, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Dental Care for Special-Needs Children",
  blurb: "A calm tell-show-do visit: the chair reclines gently, the dentist explains each step, the child stays comfortable.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ chair, hand, elapsed, speed }: {
  chair: RefObject<THREE.Group>; hand: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (chair.current) {
      // chair reclines very gently and rocks
      chair.current.rotation.z = -0.12 - 0.06 * (0.5 - 0.5 * Math.cos(t * 0.5));
    }
    if (hand.current) {
      // dentist's hand mirror moves in slow reassuring arcs
      hand.current.position.y = 2.9 + 0.25 * Math.sin(t * 0.9);
      hand.current.position.x = 1.9 + 0.3 * Math.cos(t * 0.6);
    }
  });
  return null;
}

export function Topic10545Sim(props: SimProps) {
  const speed = Number(props.speed ?? 0.7);
  const showLabels = String(props.detail ?? "on") === "on";
  const chair = useRef<THREE.Group>(null!);
  const hand = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Approach", "tell – show – do"],
          ["Pace", "slow, predictable steps"],
          ["Support", "parent + comfort toy present"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* dental chair base */}
        <mesh position={[-0.5, 0.5, 0]} castShadow>
          <boxGeometry args={[2.2, 1, 2.4]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.5} />
        </mesh>
        {/* reclining chair with the child */}
        <group ref={chair} position={[-0.5, 1.2, 0]}>
          <mesh position={[0, 0.35, 0]} castShadow>
            <boxGeometry args={[4.6, 0.45, 1.9]} />
            <meshStandardMaterial color="#7dd3fc" roughness={0.5} />
          </mesh>
          <mesh position={[-2.2, 0.9, 0]} rotation={[0, 0, 0.5]} castShadow>
            <boxGeometry args={[1.2, 0.4, 1.7]} />
            <meshStandardMaterial color="#7dd3fc" roughness={0.5} />
          </mesh>
          {/* child lying back: body, head, legs */}
          <mesh position={[0.3, 0.95, 0]} castShadow>
            <capsuleGeometry args={[0.42, 1.6, 6, 12]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.6} />
          </mesh>
          <mesh position={[-1.5, 1.0, 0]} castShadow>
            <sphereGeometry args={[0.55, 20, 20]} />
            <meshStandardMaterial color="#f5c9a3" roughness={0.6} />
          </mesh>
          {/* open mouth smile */}
          <mesh position={[-1.5, 0.82, 0.5]}>
            <sphereGeometry args={[0.16, 12, 12]} />
            <meshStandardMaterial color="#5b1a1a" roughness={0.8} />
          </mesh>
          {/* comfort toy (teddy) on the belly */}
          <group position={[0.6, 1.45, 0.2]}>
            <mesh castShadow>
              <sphereGeometry args={[0.28, 14, 14]} />
              <meshStandardMaterial color="#b45309" roughness={0.8} />
            </mesh>
            <mesh position={[0, 0.32, 0]}>
              <sphereGeometry args={[0.18, 12, 12]} />
              <meshStandardMaterial color="#b45309" roughness={0.8} />
            </mesh>
          </group>
        </group>

        {/* dentist figure with mask */}
        <group position={[2.6, 0, 0]}>
          <mesh position={[0, 0.9, 0]} castShadow>
            <cylinderGeometry args={[0.4, 0.5, 1.8, 14]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.6} />
          </mesh>
          <mesh position={[0, 2.25, 0]} castShadow>
            <sphereGeometry args={[0.45, 18, 18]} />
            <meshStandardMaterial color="#f0b98d" roughness={0.6} />
          </mesh>
          <mesh position={[0, 2.1, 0.38]}>
            <boxGeometry args={[0.5, 0.22, 0.1]} />
            <meshStandardMaterial color="#7dd3fc" roughness={0.5} />
          </mesh>
          {/* arm + mirror reaching toward the child */}
          <group ref={hand} position={[1.9, 2.9, 0]}>
            <mesh position={[-0.7, -0.6, 0]} rotation={[0, 0, 0.7]} castShadow>
              <cylinderGeometry args={[0.12, 0.12, 1.4, 10]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.6} />
            </mesh>
            <mesh position={[-1.35, -1.1, 0]} rotation={[0.4, 0, 0]}>
              <cylinderGeometry args={[0.04, 0.04, 0.7, 8]} />
              <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.3} />
            </mesh>
            <mesh position={[-1.35, -1.5, 0.12]} rotation={[0.4, 0, 0]}>
              <circleGeometry args={[0.12, 14]} />
              <meshStandardMaterial color="#bae6fd" metalness={0.7} roughness={0.2} side={THREE.DoubleSide} />
            </mesh>
          </group>
        </group>

        {/* overhead lamp */}
        <group position={[-0.5, 5.6, 0]}>
          <mesh castShadow>
            <boxGeometry args={[1.4, 0.4, 0.8]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.4} />
          </mesh>
          <mesh position={[0, -0.3, 0]}>
            <boxGeometry args={[1.1, 0.1, 0.6]} />
            <meshStandardMaterial color="#fef9c3" emissive="#fde047" emissiveIntensity={1.2} />
          </mesh>
        </group>

        {showLabels && (
          <>
            <Label p={[-0.5, 4.4, 0]} size={0.3} color="#7dd3fc">tell – show – do</Label>
            <Label p={[2.6, 3.4, 0]} size={0.28} color="#e2e8f0">gentle dentist</Label>
            <Label p={[0.6, 2.4, 0.6]} size={0.26} color="#fbbf24">comfort toy</Label>
          </>
        )}

        <Animator chair={chair} hand={hand} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
