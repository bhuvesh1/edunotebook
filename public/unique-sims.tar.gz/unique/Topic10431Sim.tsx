"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Stage", kind: "select", min: 0, max: 0, step: 1, default: "tryin", options: ["tryin", "processing", "insertion"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Complete dentures: try-in, processing, insertion, post-insertion care",
  blurb: "From wax try-in to hot flask processing to final insertion — the denture's journey into the patient's mouth.",
};

const STAGES: Record<string, { name: string; note: string; color: string }> = {
  tryin: { name: "Wax try-in", note: "Check looks, bite and speech before finalizing", color: "#fde68a" },
  processing: { name: "Flask + heat processing", note: "Wax melts out, pink acrylic flows in", color: "#fca5a5" },
  insertion: { name: "Insertion + aftercare", note: "Seat the denture, check sore spots", color: "#86efac" },
};

function Denture({ wax }: { wax: boolean }) {
  const teeth: { x: number; z: number }[] = [];
  const n = 7;
  for (let i = 0; i < n; i++) {
    const a = Math.PI * (0.12 + (0.76 * i) / (n - 1));
    teeth.push({ x: Math.cos(a) * 1.9, z: Math.sin(a) * 1.9 });
  }
  return (
    <group>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[1.9, 0.42, 12, 32, Math.PI]} />
        <meshStandardMaterial color={wax ? "#fcd34d" : "#f472b6"} roughness={0.5} />
      </mesh>
      {teeth.map((tt, i) => (
        <mesh key={i} position={[tt.x, -0.45, tt.z]}>
          <boxGeometry args={[0.4, 0.5, 0.45]} />
          <meshStandardMaterial color="#fdfbf3" roughness={0.25} />
        </mesh>
      ))}
    </group>
  );
}

function Scene({ stage, speed }: { stage: string; speed: number }) {
  const denture = useRef<THREE.Group>(null!);
  const flaskTop = useRef<THREE.Mesh>(null!);
  const heat = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const st = STAGES[stage] ?? STAGES.tryin;

  useFrame((_, delta) => {
    t.current += delta * speed;
    if (stage === "tryin" && denture.current) {
      denture.current.position.y = 0.5 + Math.sin(t.current * 1.5) * 0.35;
      denture.current.rotation.x = Math.sin(t.current * 0.8) * 0.15;
    }
    if (stage === "processing") {
      if (flaskTop.current) flaskTop.current.position.y = 1.35 - (Math.sin(t.current * 1.2) * 0.5 + 0.5) * 0.9;
      if (heat.current) {
        heat.current.children.forEach((c, i) => {
          c.position.y = -0.6 + ((t.current * 0.8 + i * 0.2) % 1.6);
        });
      }
      if (denture.current) denture.current.position.y = -0.1;
    }
    if (stage === "insertion" && denture.current) {
      const f = (Math.sin(t.current * 1.1) + 1) / 2;
      denture.current.position.set(0, -1.2 + f * 1.7, 0.3);
    }
  });

  return (
    <group>
      {stage === "processing" && (
        <group>
          {/* flask bottom */}
          <mesh position={[0, -1.1, 0]}>
            <cylinderGeometry args={[2.6, 2.6, 0.5, 24]} />
            <meshStandardMaterial color="#64748b" metalness={0.6} roughness={0.4} />
          </mesh>
          {/* flask top pressing */}
          <mesh ref={flaskTop} position={[0, 1.35, 0]}>
            <cylinderGeometry args={[2.6, 2.6, 0.5, 24]} />
            <meshStandardMaterial color="#475569" metalness={0.6} roughness={0.4} />
          </mesh>
          {/* heat waves */}
          <group ref={heat}>
            {[0, 1, 2, 3, 4].map((i) => (
              <mesh key={i} position={[-1.6 + i * 0.8, 0, 1.8]}>
                <sphereGeometry args={[0.14, 8, 8]} />
                <meshStandardMaterial color="#fb923c" emissive="#f97316" emissiveIntensity={1.4} transparent opacity={0.8} />
              </mesh>
            ))}
          </group>
          <Label text="74°C water bath — 8 hrs" position={[0, -2.2, 0]} size={0.45} color="#fdba74" />
        </group>
      )}

      {stage === "insertion" && (
        <group>
          {/* gum ridge receiving */}
          <mesh position={[0, 1.1, 0.3]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[2.0, 0.55, 14, 32, Math.PI]} />
            <meshStandardMaterial color="#e0788a" roughness={0.55} />
          </mesh>
          <Label text="Ridge" position={[-3.2, 1.1, 0.3]} size={0.42} color="#fda4af" />
          {/* sore-spot check */}
          <mesh position={[1.4, 0.4, 1.6]}>
            <sphereGeometry args={[0.14, 10, 10]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={1} />
          </mesh>
          <Label text="Sore spot? — adjust!" position={[1.4, 1.1, 1.6]} size={0.4} color="#fca5a5" />
        </group>
      )}

      <group ref={denture} position={[0, stage === "insertion" ? 0.5 : 0.5, stage === "insertion" ? 0.3 : 0]}>
        <Denture wax={stage === "tryin"} />
      </group>

      {stage === "tryin" && (
        <group position={[0, -1.6, 0]}>
          <Label text="Smile line ✓" position={[-1.5, 0.4, 0]} size={0.4} color="#86efac" />
          <Label text="Bite ✓" position={[0, 0.4, 0]} size={0.4} color="#86efac" />
          <Label text="Speech ✓" position={[1.5, 0.4, 0]} size={0.4} color="#86efac" />
        </group>
      )}

      <Label text={st.name} position={[0, 3.6, 0]} size={0.65} color={stage === "tryin" ? "#fde68a" : stage === "processing" ? "#fdba74" : "#f9a8d4"} />
      <Label text={st.note} position={[0, -2.9, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10431Sim(props: SimProps) {
  const stage = String(props.stage ?? "tryin");
  const speed = Number(props.speed ?? 1);
  const st = STAGES[stage] ?? STAGES.tryin;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Stage", st.name], ["Base", stage === "tryin" ? "Wax" : "Heat-cure acrylic"], ["Next", stage === "tryin" ? "Processing" : stage === "processing" ? "Insertion" : "24-hr recall"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, 0.3, 0]}>
        <Scene stage={stage} speed={speed} />
      </SimCanvas>
    </div>
  );
}
