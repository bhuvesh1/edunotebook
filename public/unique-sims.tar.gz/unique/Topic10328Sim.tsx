"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "urticaria", options: ["urticaria", "sjs-ten"] },
  { key: "severity", label: "Severity", kind: "slider", min: 0.2, max: 1.5, step: 0.1, default: 0.8, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Urticaria, drug reactions — SJS / TEN",
  blurb: "Urticaria: raised itchy wheals that come and go. SJS/TEN: sheets of epidermis peel away — a drug-reaction emergency.",
};

const SKIN = "#f7c9a8";
const EPIDERMIS = "#e8a87c";
const DERMIS = "#d9826b";

// Itchy urticaria wheal: edematous raised plaque with pale center, erythematous rim.
function Wheal({ severity, speed, showLabels }: { severity: number; speed: number; showLabels: boolean }) {
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (group.current) {
      const b = 1 + Math.sin(elapsed.current * 3) * 0.05;
      group.current.scale.set(severity * b, severity * (0.5 + 0.1 * Math.sin(elapsed.current * 3)), severity * b);
    }
  });
  return (
    <group>
      {/* surrounding erythema */}
      <mesh position={[0, 0.38, 0]}>
        <cylinderGeometry args={[2.1, 2.3, 0.14, 40]} />
        <meshStandardMaterial color="#ef4444" transparent opacity={0.55} roughness={0.6} />
      </mesh>
      {/* raised wheal */}
      <group ref={group} position={[0, 0.42, 0]}>
        <mesh castShadow>
          <sphereGeometry args={[1.5, 40, 20, 0, Math.PI * 2, 0, Math.PI / 2]} />
          <meshStandardMaterial color="#fde8d8" roughness={0.55} />
        </mesh>
        {/* pale center */}
        <mesh position={[0, 0.55, 0]}>
          <sphereGeometry args={[0.7, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
          <meshStandardMaterial color="#fff7ed" roughness={0.4} />
        </mesh>
      </group>
      {/* histamine sparkle dots drifting */}
      {Array.from({ length: 10 }).map((_, i) => (
        <mesh key={i} position={[(Math.random() - 0.5) * 5, 0.8 + Math.random() * 1.4, (Math.random() - 0.5) * 3]}>
          <sphereGeometry args={[0.06, 8, 8]} />
          <meshBasicMaterial color="#facc15" />
        </mesh>
      ))}
      {showLabels && (
        <Text position={[0, 2.6, 0]} fontSize={0.46} color="#fecaca">Raised wheal — pale center, red rim</Text>
      )}
    </group>
  );
}

// SJS/TEN: epidermal sheet lifting off raw red dermis, Nikolsky-positive peeling.
function PeelSheet({ severity, speed, showLabels }: { severity: number; speed: number; showLabels: boolean }) {
  const sheet = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (sheet.current) {
      sheet.current.rotation.x = -0.15 - severity * (0.5 + 0.28 * Math.sin(elapsed.current * 1.4));
    }
  });
  const curl = severity;
  return (
    <group>
      {/* exposed raw dermis */}
      <mesh position={[0, -0.32, 0]}>
        <boxGeometry args={[7.6, 0.35, 3.6]} />
        <meshStandardMaterial color="#dc2626" roughness={0.35} emissive="#7f1d1d" emissiveIntensity={0.35} />
      </mesh>
      {/* detaching epidermal sheet, hinged at back edge */}
      <group position={[0, 0.1, -1.8]}>
        <mesh ref={sheet} position={[0, 0, 1.8]} castShadow>
          <boxGeometry args={[7.6, 0.22, 3.6]} />
          <meshStandardMaterial color={EPIDERMIS} roughness={0.7} side={THREE.DoubleSide} />
        </mesh>
      </group>
      {/* dusky targetoid spots */}
      {[
        [-2.4, 0.9], [-0.8, -0.7], [1.6, 0.6], [2.8, -0.9],
      ].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.25, z]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[0.32 * severity + 0.15, 20]} />
          <meshBasicMaterial color="#7c2d12" transparent opacity={0.85} />
        </mesh>
      ))}
      {showLabels && (
        <>
          <Text position={[-5.2, 0.4, 0]} fontSize={0.42} color="#fecaca">Detaching epidermis</Text>
          <Text position={[4.6, -0.6, 0]} fontSize={0.42} color="#fca5a5">Raw dermis (Nikolsky +)</Text>
        </>
      )}
    </group>
  );
}

export function Topic10328Sim(props: SimProps) {
  const condition = String(props.condition ?? "urticaria");
  const severity = Number(props.severity ?? 0.8);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const urticaria = condition === "urticaria";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", urticaria ? "Urticaria" : "SJS / TEN"],
          ["Mechanism", urticaria ? "Histamine → edema" : "Cytotoxic T-cells"],
          ["Emergency", urticaria ? "usually no" : "YES — stop drug"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5, 11]} target={[0, 0.3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.25, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* base skin block (urticaria) */}
        {urticaria && (
          <group>
            <mesh position={[0, -1.1, 0]} castShadow receiveShadow>
              <boxGeometry args={[8, 2.2, 4]} />
              <meshStandardMaterial color={DERMIS} roughness={0.85} />
            </mesh>
            <mesh position={[0, 0.1, 0]} castShadow>
              <boxGeometry args={[8, 0.5, 4]} />
              <meshStandardMaterial color={EPIDERMIS} roughness={0.7} />
            </mesh>
            <Wheal severity={severity} speed={speed} showLabels={showLabels} />
          </group>
        )}
        {!urticaria && <PeelSheet severity={severity} speed={speed} showLabels={showLabels} />}
      </SimCanvas>
    </div>
  );
}
