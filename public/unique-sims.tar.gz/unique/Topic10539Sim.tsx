// app/components/sims/unique/Topic10539Sim.tsx
// Restorative dentistry in children: stainless steel crowns (SSCs) and strip
// crowns. The chosen crown descends over the prepared baby tooth.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "crown", label: "Crown type", kind: "select", min: 0, max: 0, step: 1, default: "ssc", options: ["ssc", "strip"] },
  { key: "seat", label: "Crown seating", kind: "slider", min: 0, max: 100, step: 1, default: 100, unit: "%" },
];

export const UNIQUE_META = {
  title: "Restorative Dentistry in Children: SSCs & Strip Crowns",
  blurb: "A steel crown or a tooth-colored strip crown slides down over the prepared baby tooth.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ crownG, elapsed, seat }: {
  crownG: RefObject<THREE.Group>; elapsed: RefObject<number>; seat: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (crownG.current) {
      const s = seat / 100;
      crownG.current.position.y = (1 - s) * 3 + 0.03 * Math.sin(elapsed.current * 2);
    }
  });
  return null;
}

const INFO: Record<string, { name: string; note: string; color: string }> = {
  ssc: { name: "Stainless steel crown", note: "back teeth — strong, silver", color: "#cbd5e1" },
  strip: { name: "Strip crown", note: "front teeth — tooth-colored", color: "#fefce8" },
};

export function Topic10539Sim(props: SimProps) {
  const crown = String(props.crown ?? "ssc");
  const seat = Number(props.seat ?? 100);
  const crownG = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = INFO[crown];
  const isSSC = crown === "ssc";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Crown", info.name],
          ["Use", info.note],
          ["Fit", seat >= 99 ? "seated with cement ✓" : "try-in — not seated"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* prepared baby tooth (shaved-down stump) */}
        <group position={[0, 1.6, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.55, 0.7, 1.1, 14]} />
            <meshStandardMaterial color="#fefce8" roughness={0.35} />
          </mesh>
          <mesh position={[0, -0.9, 0]} rotation={[Math.PI, 0, 0]}>
            <coneGeometry args={[0.28, 0.9, 10]} />
            <meshStandardMaterial color="#fefce8" roughness={0.35} />
          </mesh>
        </group>
        {/* gum */}
        <mesh position={[0, 0.7, 0]} castShadow>
          <boxGeometry args={[3.4, 0.7, 1.6]} />
          <meshStandardMaterial color="#e0607a" roughness={0.6} />
        </mesh>

        {/* the crown descending over the stump */}
        <group ref={crownG} position={[0, 2.5, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.72, 0.82, 1.35, 16, 1, true]} />
            <meshStandardMaterial
              color={isSSC ? "#cbd5e1" : "#fefce8"}
              metalness={isSSC ? 0.9 : 0.05}
              roughness={isSSC ? 0.25 : 0.3}
              side={THREE.DoubleSide}
            />
          </mesh>
          <mesh position={[0, 0.68, 0]}>
            <cylinderGeometry args={[0.72, 0.72, 0.12, 16]} />
            <meshStandardMaterial
              color={isSSC ? "#cbd5e1" : "#fefce8"}
              metalness={isSSC ? 0.9 : 0.05}
              roughness={isSSC ? 0.25 : 0.3}
            />
          </mesh>
          {!isSSC && (
            <mesh position={[0, 0.1, 0]}>
              <cylinderGeometry args={[0.6, 0.66, 1.0, 14, 1, true]} />
              <meshStandardMaterial color="#fde68a" transparent opacity={0.35} roughness={0.2} side={THREE.DoubleSide} />
            </mesh>
          )}
        </group>

        <Label p={[-2.6, 2.5, 0]} size={0.3} color={isSSC ? "#cbd5e1" : "#fefce8"}>{info.name}</Label>
        <Label p={[2.6, 1.6, 0]} size={0.3} color="#fefce8">prepared tooth stump</Label>
        <Label p={[0, 4.9, 0]} size={0.32} color="#e2e8f0">{info.note}</Label>

        <Animator crownG={crownG} elapsed={elapsed} seat={seat} />
      </SimCanvas>
    </div>
  );
}
