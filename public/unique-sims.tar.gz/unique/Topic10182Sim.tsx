"use client";
// International health: WHO, UNICEF, global health agencies.
// A globe spins with latitude lines while agency badges — WHO, UNICEF,
/// World Bank — orbit around it like satellites.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "agency", label: "Agency", kind: "select", min: 0, max: 0, step: 1, default: "who", options: ["who", "unicef", "worldbank"] },
  { key: "speed", label: "Orbit speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "International Health: WHO, UNICEF & Partners",
  blurb: "The world turns while WHO, UNICEF and the World Bank orbit it — pick an agency to hear its mission.",
};

const AGENCIES: Record<string, { name: string; color: string; mission: string }> = {
  who: { name: "WHO", color: "#38bdf8", mission: "Health for all nations" },
  unicef: { name: "UNICEF", color: "#7dd3fc", mission: "Every child healthy" },
  worldbank: { name: "WORLD BANK", color: "#4ade80", mission: "Funds health projects" },
};

function Animator({ globe, sats, elapsed, speed }: { globe: React.RefObject<THREE.Group>; sats: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (globe.current) globe.current.rotation.y = elapsed.current * 0.4;
    if (sats.current) {
      sats.current.children.forEach((s, i) => {
        const a = elapsed.current * 0.55 + (i * Math.PI * 2) / 3;
        s.position.set(Math.cos(a) * 4.6, 0.4 + Math.sin(a * 2 + i) * 0.5, Math.sin(a) * 4.6);
      });
    }
  });
  return null;
}

export function Topic10182Sim(props: SimProps) {
  const agency = String(props.agency ?? "who");
  const speed = Number(props.speed ?? 1);
  const globe = useRef<THREE.Group>(null!);
  const sats = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = AGENCIES[agency] ?? AGENCIES.who;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Agency", info.name], ["Mission", info.mission]]} />
      <SimCanvas cameraPosition={[0, 3.6, 14]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0b1020" roughness={1} />
        </mesh>
        {/* stars */}
        {Array.from({ length: 40 }, (_, i) => (
          <mesh key={i} position={[Math.sin(i * 12.9) * 16, 2 + ((i * 7.3) % 9), -6 - ((i * 3.1) % 6)]}>
            <sphereGeometry args={[0.05, 6, 6]} />
            <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.8} />
          </mesh>
        ))}
        {/* globe */}
        <group position={[0, 2.6, 0]}>
          <group ref={globe}>
            <mesh castShadow>
              <sphereGeometry args={[2.2, 28, 22]} />
              <meshStandardMaterial color="#1d4ed8" roughness={0.55} />
            </mesh>
            {/* continents: blobby patches */}
            {[[0.8, 0.9, 0.9], [-0.9, 0.3, 1.1], [0.2, -0.8, 0.8], [-0.4, -0.2, -1.2]].map(([x, y, z], i) => (
              <mesh key={i} position={[x, y, z]}>
                <sphereGeometry args={[0.62, 10, 10]} />
                <meshStandardMaterial color="#4ade80" roughness={0.8} />
              </mesh>
            ))}
            {[-1.1, 0, 1.1].map((y) => (
              <mesh key={y} rotation={[Math.PI / 2, 0, 0]} position={[0, y, 0]}>
                <torusGeometry args={[2.22, 0.025, 6, 40]} />
                <meshStandardMaterial color="#93c5fd" transparent opacity={0.6} />
              </mesh>
            ))}
          </group>
          {/* orbit ring */}
          <mesh rotation={[Math.PI / 2.4, 0, 0]}>
            <torusGeometry args={[4.6, 0.04, 8, 60]} />
            <meshStandardMaterial color="#475569" transparent opacity={0.7} />
          </mesh>
          <group ref={sats}>
            {Object.keys(AGENCIES).map((k) => (
              <group key={k} position={[4.6, 0, 0]}>
                <mesh castShadow>
                  <sphereGeometry args={[0.75, 18, 18]} />
                  <meshStandardMaterial color={AGENCIES[k].color} emissive={AGENCIES[k].color} emissiveIntensity={k === agency ? 0.9 : 0.15} roughness={0.4} />
                </mesh>
                <Label text={AGENCIES[k].name} position={[0, 1.25, 0]} size={0.5} color={k === agency ? AGENCIES[k].color : "#94a3b8"} />
              </group>
            ))}
          </group>
          <Label text="🌍 GLOBAL HEALTH" position={[0, 5.9, 0]} size={0.7} color="#93c5fd" />
        </group>
        <Animator globe={globe} sats={sats} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
