"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "nephrotic syndrome", options: ["normal", "nephrotic syndrome", "AKI", "CKD"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Kidney: Glomerulus to Tubule",
  blurb: "A filtering glomerulus feeds the tubule: watch protein leak in nephrotic syndrome or flow stop in AKI.",
};

function Animator({ root, kid, ur, leak, elapsed, speed, neph, aki, ckd }: { root: RefObject<THREE.Group>; kid: RefObject<THREE.Group>; ur: RefObject<THREE.Group>; leak: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; neph: boolean; aki: boolean; ckd: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (kid.current) {
      const s = ckd ? 0.68 : 1;
      kid.current.scale.setScalar(s + 0.02 * Math.sin(t * 1.5));
    }
    if (ur.current) {
      ur.current.children.forEach((m, i) => {
        const q = aki ? 0.05 : (t * 0.6 + i / 7) % 1;
        const a = q * Math.PI * 1.1;
        m.position.set(0.9 + Math.cos(a) * 0.9, 2.5 - q * 1.9, 0);
        m.scale.setScalar(aki ? 0.4 : 1);
      });
    }
    if (leak.current) {
      leak.current.visible = neph;
      leak.current.children.forEach((m, i) => {
        const r = (t * 0.7 + i / 8) % 1;
        m.position.set(-0.6 + Math.sin(i * 3) * 0.5, 2.6 - r * 1.6, (i % 2) * 0.4 - 0.2);
      });
    }
  });
  return null;
}

export function Topic10099Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const cond = String(props.cond ?? "nephrotic syndrome");
  const neph = cond === "nephrotic syndrome";
  const aki = cond === "AKI";
  const ckd = cond === "CKD";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const kid = useRef<THREE.Group>(null!);
  const ur = useRef<THREE.Group>(null!);
  const leak = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", cond],
          ["GFR", neph ? "normal/high" : aki ? "acutely fallen" : ckd ? "chronically low" : "125 mL/min"],
          ["Urine", neph ? "proteinuria > 3.5 g/day" : aki ? "oliguria" : ckd ? "isosthenuria" : "normal"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <group ref={kid}>
            <mesh position={[0, 1.9, 0]} scale={[1.15, 1.55, 1]} castShadow>
              <sphereGeometry args={[1, 26, 26]} /><meshStandardMaterial color={ckd ? "#9a3412" : "#b91c1c"} roughness={0.55} />
            </mesh>
            <mesh position={[0.75, 1.9, 0]} scale={[0.5, 0.7, 0.6]}>
              <sphereGeometry args={[0.8, 16, 16]} /><meshStandardMaterial color="#0f172a" roughness={1} />
            </mesh>
          </group>
          <Label text="kidney" position={[-1.9, 3.2, 0]} color="#f87171" />
          <group position={[0, 2.9, 0]}>
            {[0, 1, 2].map((i) => (
              <mesh key={i} rotation={[0.5 * i, 0.4 * i, 0]}>
                <torusGeometry args={[0.42, 0.11, 10, 20]} /><meshStandardMaterial color="#ef4444" emissive="#b91c1d" emissiveIntensity={0.5} />
              </mesh>
            ))}
            <Label text="glomerulus" position={[0, 0.85, 0]} size={0.42} color="#f87171" />
          </group>
          <mesh position={[1.35, 1.75, 0]} rotation={[0, 0, -0.5]}>
            <torusGeometry args={[0.75, 0.16, 10, 24, Math.PI * 1.15]} /><meshStandardMaterial color="#fbbf24" roughness={0.55} />
          </mesh>
          <Label text="tubule" position={[2.4, 1.2, 0]} size={0.4} color="#fbbf24" />
          <group ref={ur}>
            {Array.from({ length: 7 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.11, 8, 8]} /><meshStandardMaterial color="#fde047" emissive="#eab308" emissiveIntensity={0.9} /></mesh>
            ))}
          </group>
          <group ref={leak} visible={false}>
            {Array.from({ length: 8 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.13, 8, 8]} /><meshStandardMaterial color="#ef4444" emissive="#b91c1d" emissiveIntensity={0.9} /></mesh>
            ))}
          </group>
          <Label text={neph ? "protein leaking \u2014 nephrotic" : aki ? "tubules blocked \u2014 no urine!" : ckd ? "shrunken kidneys \u2014 CKD" : "filtration \u2192 urine"} position={[0, 4.6, 0]} size={0.46} color={cond === "normal" ? "#4ade80" : "#f87171"} />
        </group>
        <Animator root={root} kid={kid} ur={ur} leak={leak} elapsed={elapsed} speed={speed} neph={neph} aki={aki} ckd={ckd} />
      </SimCanvas>
    </div>
  );
}
