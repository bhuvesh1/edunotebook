// Blood protozoa: red blood cells carry glowing ring-stage malaria parasites
// while crescent gametocytes drift by, waiting for the next mosquito.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "para", label: "Parasitemia", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Blood protozoa: malaria",
  blurb: "Red cells carry glowing ring-stage parasites while crescent gametocytes drift by.",
};

const N_RBC = 9;
const N_GAM = 5;

function Animator({ rbcs, rings, gams, elapsed, para, setTick }: {
  rbcs: React.RefObject<(THREE.Group | null)[]>;
  rings: React.RefObject<(THREE.Mesh | null)[]>;
  gams: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  para: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = para / 100;
    let infected = 0;
    rbcs.current.forEach((g, i) => {
      if (!g) return;
      // cells flow left to right in the bloodstream
      const f = (t * 0.22 + i / N_RBC) % 1;
      g.position.set(-5.5 + f * 11, 1.6 + Math.sin(i * 2.2 + t) * 0.35, Math.sin(i * 1.4) * 1.1);
      g.rotation.y = t * 0.7 + i;
      const inf = ((i * 37) % 10) / 10 < k;
      if (inf) infected++;
      const ring = rings.current[i];
      if (ring) {
        ring.visible = inf;
        if (inf) (ring.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.8 + Math.sin(t * 4 + i) * 0.4;
      }
    });
    gams.current.forEach((gm, i) => {
      if (!gm) return;
      gm.visible = k > 0.15;
      const a = t * 0.5 + i * 1.3;
      gm.position.set(Math.cos(a) * 3.6, 3.1 + Math.sin(a * 1.6) * 0.3, Math.sin(a) * 2);
      gm.rotation.z = a;
      gm.rotation.y = t * 0.8 + i;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(infected); }
  });
  return null;
}

export function Topic10143Sim(props: SimProps) {
  const para = Number(props.para ?? 55);
  const showLabels = String(props.detail ?? "on") === "on";
  const rbcs = useRef<(THREE.Group | null)[]>([]);
  const rings = useRef<(THREE.Mesh | null)[]>([]);
  const gams = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Infected RBCs", `${tick}/${N_RBC}`],
          ["Stage", "rings → crescent gametocytes"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* blood vessel */}
        <mesh position={[0, 1.6, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[1.8, 1.8, 12, 20, 1, true]} />
          <meshStandardMaterial color="#7f1d1d" transparent opacity={0.3} side={THREE.DoubleSide} />
        </mesh>
        {showLabels && <Label text="bloodstream" position={[0, 3.9, 0]} size={0.45} color="#fca5a5" />}

        {/* red blood cells with ring parasites */}
        {Array.from({ length: N_RBC }).map((_, i) => (
          <group key={i} ref={(g) => { rbcs.current[i] = g; }}>
            <mesh scale={[1, 1, 0.42]} castShadow>
              <sphereGeometry args={[0.5, 18, 14]} />
              <meshStandardMaterial color="#dc2626" roughness={0.45} />
            </mesh>
            <mesh ref={(m) => { rings.current[i] = m; }} position={[0.12, 0.12, 0.16]} rotation={[0.4, 0.3, 0]}>
              <torusGeometry args={[0.16, 0.055, 8, 16]} />
              <meshStandardMaterial color="#fde047" emissive="#eab308" emissiveIntensity={1} />
            </mesh>
          </group>
        ))}
        {showLabels && <Label text="RBCs — glowing ring stages inside" position={[-3.8, 0.35, 0]} size={0.45} color="#fde047" />}

        {/* crescent gametocytes */}
        {Array.from({ length: N_GAM }).map((_, i) => (
          <mesh key={`g${i}`} ref={(m) => { gams.current[i] = m; }} castShadow>
            <torusGeometry args={[0.3, 0.11, 8, 18, Math.PI * 1.25]} />
            <meshStandardMaterial color="#fb923c" emissive="#c2410c" emissiveIntensity={0.9} />
          </mesh>
        ))}
        {showLabels && <Label text="crescent gametocytes — infect mosquitoes" position={[0, 4.4, 0]} size={0.45} color="#fdba74" />}

        <Animator rbcs={rbcs} rings={rings} gams={gams} elapsed={elapsed} para={para} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
