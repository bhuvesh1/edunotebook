"use client";
// Local Drug Delivery in Periodontics — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Drug dose", kind: "slider", min: 0.5, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Local Drug Delivery in Periodontics",
  blurb: "Antibiotic microspheres are tucked into the pocket — they drift in, dissolve, and wipe out the bacteria.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    for (let i = 0; i < 10; i++) {
      const m: any = g("micro" + i);
      if (m) {
        const ph = (t * 0.35 + i / 10) % 1;
        m.position.set(-0.28 + 0.05 * Math.sin(t * 2 + i), 2.3 - ph * 1.7, 0.15);
        const s = 0.07 * p.dose * (1 - ph * 0.85);
        m.scale.setScalar(Math.max(0.001, s));
      }
    }
    for (let i = 0; i < 6; i++) {
      const b: any = g("pbact" + i);
      if (b) {
        const kill = (t * 0.35 + i / 10) % 1;
        (b.material as any).opacity = Math.max(0.05, 0.9 - kill);
      }
    }
  });
  return null;
}

export function Topic10487Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const dose = Number(props.dose ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, dose };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Drug", "Doxycycline microspheres"],
          ["Dose", `${dose.toFixed(1)}×`],
          ["Site", "Inside periodontal pocket"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1.2, 0]} scale={1.5} />
          <mesh position={[-0.95, 1.5, 0]}>
            <boxGeometry args={[1.1, 1.5, 2]} />
            <meshStandardMaterial color="#e0808f" roughness={0.6} />
          </mesh>
          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
            <mesh key={i} name={"micro" + i}>
              <sphereGeometry args={[1, 8, 8]} />
              <meshStandardMaterial color="#fde047" emissive="#fde047" emissiveIntensity={0.5} roughness={0.4} />
            </mesh>
          ))}
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <mesh key={i} name={"pbact" + i} position={[-0.35 + (i % 3) * 0.18, 1 + Math.floor(i / 3) * 0.4, 0.5]}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshStandardMaterial color="#4d7c0f" transparent opacity={0.9} roughness={0.9} />
            </mesh>
          ))}
          <Label text="Microspheres" position={[2.3, 2.6, 0]} size={0.42} color="#fde047" />
          <Label text="Bacteria dying off" position={[-2.7, 0.7, 0.5]} size={0.42} color="#84cc16" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
