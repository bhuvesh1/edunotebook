// Embryology: placenta and umbilical cord — a lobed placental disc exchanging
// maternal blood, with a twisted umbilical cord (2 arteries + 1 vein) pulsing
// blood to and from the fetus.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "flow", label: "Cord blood flow", kind: "slider", min: 0, max: 2.5, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Embryology: Placenta & Umbilical Cord",
  blurb: "The placental disc trades nutrients with maternal blood while the twisted cord pulses flow to the fetus.",
};

function Animator({
  pulses, cotyledons, cord, elapsed, flow, speed,
}: {
  pulses: React.RefObject<THREE.Group>;
  cotyledons: React.RefObject<THREE.Group>;
  cord: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  flow: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // blood pulses travel along the cord from placenta (x=-1) to fetus (x=5)
    if (pulses.current) {
      pulses.current.children.forEach((m, i) => {
        const dir = m.userData.dir as number; // +1 arterial (fetus-bound), -1 venous
        const ph = ((t * 0.35 * flow + i / 6) % 1 + 1) % 1;
        m.position.x = dir > 0 ? -0.6 + ph * 5.4 : 4.8 - ph * 5.4;
        m.visible = flow > 0.02;
      });
    }
    if (cotyledons.current) {
      cotyledons.current.children.forEach((m, i) => {
        const s = 1 + 0.07 * Math.sin(t * 2.2 + i * 1.1);
        m.scale.setScalar(s);
      });
    }
    if (cord.current) cord.current.rotation.x = t * 0.25;
  });
  return null;
}

export function Topic10024Sim(props: SimProps) {
  const flow = Number(props.flow ?? 1);
  const speed = Number(props.speed ?? 1);
  const pulses = useRef<THREE.Group>(null!);
  const cotyledons = useRef<THREE.Group>(null!);
  const cord = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const cotyledonPos = useMemo(
    () =>
      Array.from({ length: 12 }).map((_, i) => {
        const a = (i / 12) * Math.PI * 2;
        const r = 0.7 + (i % 2) * 0.9;
        return [Math.cos(a) * r, Math.sin(a) * r] as [number, number];
      }),
    []
  );
  const pulseDefs = useMemo(
    () =>
      Array.from({ length: 12 }).map((_, i) => ({
        dir: i % 3 === 2 ? -1 : 1, // 2 arteries -> fetus, 1 vein <- fetus
        vein: i % 3 === 2,
      })),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Cord vessels", "2 arteries + 1 vein"],
          ["Exchange", "maternal ↔ fetal blood"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 6.5, 15]} target={[1, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* placental disc */}
        <group position={[-3.4, 2.2, 0]} rotation={[0, 0, Math.PI / 2]}>
          <mesh castShadow>
            <cylinderGeometry args={[2.4, 2.6, 1.1, 24]} />
            <meshStandardMaterial color="#991b1b" roughness={0.55} />
          </mesh>
        </group>
        {/* cotyledons (lobes) on the maternal face */}
        <group ref={cotyledons} position={[-4.05, 2.2, 0]}>
          {cotyledonPos.map(([x, y], i) => (
            <mesh key={i} position={[0, x, y]} rotation={[0, 0, Math.PI / 2]} castShadow>
              <sphereGeometry args={[0.34, 12, 12]} />
              <meshStandardMaterial color="#dc2626" roughness={0.5} />
            </mesh>
          ))}
        </group>
        {/* maternal blood pool shimmer */}
        <mesh position={[-4.7, 2.2, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[2.7, 2.7, 0.25, 24]} />
          <meshStandardMaterial color="#7f1d1d" transparent opacity={0.5} roughness={0.4} />
        </mesh>
        <Label text="placenta (fetal face)" position={[-3.4, 5.1, 0]} size={0.4} color="#f8fafc" />
        <Label text="cotyledons — maternal face" position={[-5.6, 0.5, 0]} size={0.3} color="#fca5a5" />

        {/* umbilical cord: twisted group with 3 vessels */}
        <group ref={cord} position={[0, 2.2, 0]}>
          <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
            <cylinderGeometry args={[0.55, 0.55, 6.4, 16]} />
            <meshStandardMaterial color="#fde68a" transparent opacity={0.35} roughness={0.3} />
          </mesh>
          {[0, 1, 2].map((i) => {
            const a = (i / 3) * Math.PI * 2;
            const vein = i === 2;
            return (
              <group key={i} rotation={[a, 0, 0]}>
                <mesh position={[0, 0.3, 0]} rotation={[0.35, 0, Math.PI / 2]}>
                  <cylinderGeometry args={[vein ? 0.16 : 0.11, vein ? 0.16 : 0.11, 6.3, 10]} />
                  <meshStandardMaterial color={vein ? "#ef4444" : "#3b82f6"} roughness={0.4} />
                </mesh>
              </group>
            );
          })}
        </group>
        {/* blood pulses inside the cord */}
        <group ref={pulses}>
          {pulseDefs.map((p, i) => (
            <mesh key={i} position={[-0.6, 2.2 + (p.vein ? 0.3 : -0.2 + (i % 2) * 0.4), (i % 2) * 0.2 - 0.1]}
              ref={(m) => { if (m) m.userData.dir = p.dir; }}>
              <sphereGeometry args={[0.14, 10, 10]} />
              <meshBasicMaterial color={p.vein ? "#fca5a5" : "#93c5fd"} />
            </mesh>
          ))}
        </group>
        <Label text="umbilical cord" position={[1.8, 3.6, 0]} size={0.4} color="#f8fafc" />
        <Label text="2 umbilical arteries (blue)" position={[1.8, 1.15, 0]} size={0.3} color="#93c5fd" />
        <Label text="1 umbilical vein (red)" position={[1.8, 0.75, 0]} size={0.3} color="#fca5a5" />

        {/* fetus side: simple curled fetus hint */}
        <group position={[6.4, 2.0, 0]}>
          <mesh castShadow scale={[1, 1.25, 1]}>
            <sphereGeometry args={[0.9, 20, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.45} />
          </mesh>
          <mesh position={[0.5, 0.55, 0.55]}>
            <sphereGeometry args={[0.42, 16, 16]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.45} />
          </mesh>
        </group>
        <Label text="fetus" position={[6.4, 3.6, 0]} size={0.36} color="#f8fafc" />

        <Animator pulses={pulses} cotyledons={cotyledons} cord={cord} elapsed={elapsed} flow={flow} speed={speed} />
      </SimCanvas>
    </div>
  );
}
