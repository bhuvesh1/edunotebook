// Emergency drugs: the ECG flatlines — an adrenaline shot restarts the heart
// and the trace springs back into a steady rhythm.
"use client";

import { useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Adrenaline dose", kind: "slider", min: 0, max: 100, step: 5, default: 70, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Emergency drugs",
  blurb: "The ECG flatlines — an adrenaline shot restarts the heart and the trace springs back to life.",
};

function ecgPoint(x: number, alive: number, t: number): number {
  if (alive < 0.05) return 0;
  // classic PQRST-ish spike train scrolling with time
  const ph = ((x * 0.8 + t * 2.2) % 1 + 1) % 1;
  let y = 0;
  if (ph > 0.1 && ph < 0.16) y = 0.25; // P
  else if (ph > 0.3 && ph < 0.34) y = -0.3; // Q
  else if (ph > 0.34 && ph < 0.4) y = 1.0; // R
  else if (ph > 0.4 && ph < 0.46) y = -0.45; // S
  else if (ph > 0.6 && ph < 0.7) y = 0.35; // T
  return y * alive;
}

function Animator({ line, heart, shot, elapsed, dose, setTick }: {
  line: React.RefObject<THREE.Line>;
  heart: React.RefObject<THREE.Group>;
  shot: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  dose: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    // resuscitation: heart restarts a few seconds in, faster with dose
    const alive = THREE.MathUtils.clamp((t - (2.5 - k * 1.8)) / 1.5, 0, 1);
    if (line.current) {
      const pos = line.current.geometry.attributes.position;
      for (let i = 0; i < pos.count; i++) {
        const x = -5 + (i / (pos.count - 1)) * 10;
        pos.setY(i, 2.2 + ecgPoint(x, alive, t));
      }
      pos.needsUpdate = true;
      (line.current.material as THREE.LineBasicMaterial).color.set(alive > 0.5 ? "#4ade80" : "#ef4444");
    }
    if (heart.current) {
      const beat = alive * Math.pow(Math.max(0, Math.sin(t * Math.PI * 2 * (0.8 + k * 0.6))), 2);
      const s = 1 - beat * 0.18;
      heart.current.scale.set(1 / Math.sqrt(s), s, 1 / Math.sqrt(s));
      const hm = (heart.current.children[0] as THREE.Mesh).material as THREE.MeshStandardMaterial;
      hm.color.setHSL(0, alive > 0.5 ? 0.75 : 0.1, alive > 0.5 ? 0.5 : 0.35);
    }
    if (shot.current) {
      // syringe plunges at the start, then rests
      const f = Math.min(1, t / 2);
      shot.current.position.y = 2.6 - f * 1.4;
      shot.current.rotation.z = -0.5 + f * 0.2;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(alive * 100)); }
  });
  return null;
}

export function Topic10128Sim(props: SimProps) {
  const dose = Number(props.dose ?? 70);
  const showLabels = String(props.detail ?? "on") === "on";
  const line = useRef<THREE.Line>(null!);
  const heart = useRef<THREE.Group>(null!);
  const shot = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const ecgGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const pts = new Float32Array(120 * 3);
    for (let i = 0; i < 120; i++) {
      pts[i * 3] = -5 + (i / 119) * 10;
      pts[i * 3 + 1] = 2.2;
      pts[i * 3 + 2] = 0;
    }
    g.setAttribute("position", new THREE.BufferAttribute(pts, 3));
    return g;
  }, []);
  const ecgLine = useMemo(
    () => new THREE.Line(ecgGeo, new THREE.LineBasicMaterial({ color: "#ef4444" })),
    [ecgGeo]
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Rhythm restored", `${tick}%`],
          ["Status", tick > 80 ? "ROSC — pulse back!" : tick > 10 ? "restarting…" : "cardiac arrest"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* ECG monitor */}
        <mesh position={[0, 2.2, -1.6]}>
          <boxGeometry args={[11.5, 2.6, 0.4]} />
          <meshStandardMaterial color="#020617" roughness={0.4} />
        </mesh>
        {/* grid lines */}
        {[-1.5, -0.5, 0.5, 1.5].map((y, i) => (
          <mesh key={i} position={[0, 2.2 + y * 0.5, -1.38]}>
            <boxGeometry args={[11, 0.02, 0.01]} />
            <meshStandardMaterial color="#164e63" transparent opacity={0.5} />
          </mesh>
        ))}
        <primitive object={ecgLine} ref={line} position={[0, 0, -1.35]} />
        {showLabels && <Label text="ECG monitor" position={[0, 4.1, -1.6]} color="#67e8f9" />}

        {/* heart */}
        <group ref={heart} position={[-3.2, 0.9, 1]}>
          <mesh castShadow>
            <sphereGeometry args={[0.8, 24, 18]} />
            <meshStandardMaterial color="#7f1d1d" roughness={0.5} />
          </mesh>
          <mesh position={[0, 1.0, 0]}>
            <cylinderGeometry args={[0.2, 0.28, 0.8, 12]} />
            <meshStandardMaterial color="#991b1b" roughness={0.5} />
          </mesh>
        </group>
        {showLabels && <Label text="heart" position={[-3.2, 2.4, 1]} size={0.45} color="#fca5a5" />}

        {/* adrenaline syringe */}
        <group ref={shot} position={[3.2, 2.6, 1]}>
          <mesh rotation={[0, 0, -0.5]} castShadow>
            <cylinderGeometry args={[0.18, 0.18, 1.5, 12]} />
            <meshStandardMaterial color="#fef08a" emissive="#eab308" emissiveIntensity={0.5} transparent opacity={0.9} />
          </mesh>
          <mesh position={[-0.65, -0.85, 0]} rotation={[0, 0, -0.5]}>
            <cylinderGeometry args={[0.04, 0.04, 0.8, 8]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.6} roughness={0.3} />
          </mesh>
        </group>
        {showLabels && <Label text={`adrenaline ${dose}%`} position={[3.2, 3.9, 1]} color="#fde047" />}

        {/* crash cart */}
        <group position={[4.6, 0, -0.6]}>
          <mesh position={[0, 0.9, 0]} castShadow>
            <boxGeometry args={[1.2, 1.6, 0.9]} />
            <meshStandardMaterial color="#dc2626" roughness={0.5} />
          </mesh>
          <mesh position={[0, 1.85, 0]}>
            <boxGeometry args={[1.3, 0.12, 1]} />
            <meshStandardMaterial color="#7f1d1d" roughness={0.5} />
          </mesh>
        </group>
        {showLabels && <Label text="crash cart" position={[4.6, 2.5, -0.6]} size={0.45} color="#fca5a5" />}

        <Animator line={line} heart={heart} shot={shot} elapsed={elapsed} dose={dose} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
