"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "mode", label: "Analysis", kind: "select", min: 0, max: 0, step: 1, default: "identify", options: ["identify", "age"] },
  { key: "tooth", label: "Tooth number (FDI)", kind: "slider", min: 11, max: 18, step: 1, default: 16, unit: "" },
];

export const UNIQUE_META = {
  title: "Forensic odontology basics: dental identification, age estimation",
  blurb: "A numbered dental arch under forensic examination — a caliper measures a tooth while ID markers or eruption stages highlight.",
};

function Scene({ mode, tooth }: { mode: string; tooth: number }) {
  const caliper = useRef<THREE.Group>(null!);
  const t = useRef(0);

  useFrame((_, delta) => {
    t.current += delta;
    if (caliper.current) {
      caliper.current.position.y = 2.6 + Math.sin(t.current * 1.5) * 0.15;
      caliper.current.rotation.z = Math.sin(t.current * 0.8) * 0.06;
    }
  });

  const n = 8;
  const teeth: { x: number; z: number; a: number; fdi: number }[] = [];
  for (let i = 0; i < n; i++) {
    const a = Math.PI * (0.08 + (0.84 * i) / (n - 1));
    teeth.push({ x: Math.cos(a) * 2.6, z: Math.sin(a) * 2.6, a, fdi: 18 - i });
  }
  const selected = teeth.find((tt) => tt.fdi === tooth) ?? teeth[2];
  const selAngle = Math.atan2(selected.z, selected.x);

  return (
    <group>
      {/* jaw base */}
      <mesh position={[0, -0.5, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[2.6, 0.75, 14, 40, Math.PI]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>
      <mesh position={[0, -0.9, 0]}>
        <cylinderGeometry args={[3.6, 3.8, 0.5, 32]} />
        <meshStandardMaterial color="#1e293b" roughness={1} />
      </mesh>

      {/* teeth with FDI numbers */}
      {teeth.map((tt) => {
        const isSel = tt.fdi === tooth;
        const isMissing = mode === "identify" && tt.fdi === 14;
        const isCrowned = mode === "identify" && tt.fdi === 16;
        return (
          <group key={tt.fdi} position={[tt.x, 0.45, tt.z]} rotation={[0, -tt.a + Math.PI / 2, 0]}>
            {!isMissing && (
              <mesh>
                <cylinderGeometry args={[0.26, 0.34, isSel ? 0.9 : 0.7, 10]} />
                <meshStandardMaterial color={isCrowned ? "#fbbf24" : isSel ? "#7dd3fc" : "#f8fafc"} roughness={0.3} emissive={isSel ? "#0ea5e9" : "#000"} emissiveIntensity={isSel ? 0.4 : 0} />
              </mesh>
            )}
            {isMissing && (
              <mesh position={[0, 0.1, 0]}>
                <boxGeometry args={[0.5, 0.12, 0.5]} />
                <meshStandardMaterial color="#ef4444" roughness={0.6} />
              </mesh>
            )}
            <Label text={String(tt.fdi)} position={[0, 1.0, 0]} size={0.34} color={isSel ? "#7dd3fc" : "#94a3b8"} />
            {mode === "identify" && isCrowned && <Label text="gold crown" position={[0, -0.5, 0]} size={0.32} color="#fbbf24" />}
            {mode === "identify" && isMissing && <Label text="missing — ante-mortem record" position={[0, -0.5, 0]} size={0.32} color="#f87171" />}
          </group>
        );
      })}

      {/* caliper measuring selected tooth */}
      <group ref={caliper} position={[selected.x, 2.6, selected.z]} rotation={[0, -selAngle, 0]}>
        <mesh position={[0, 0.5, 0]}>
          <boxGeometry args={[0.12, 1.0, 0.12]} />
          <meshStandardMaterial color="#94a3b8" metalness={0.7} roughness={0.35} />
        </mesh>
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * 0.32, 0.05, 0]}>
            <boxGeometry args={[0.08, 0.5, 0.08]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.7} roughness={0.35} />
          </mesh>
        ))}
        <Label text={`${(10 + (tooth % 10) * 0.7).toFixed(1)} mm`} position={[0, 1.25, 0]} size={0.4} color="#7dd3fc" />
      </group>

      {mode === "age" && (
        <group position={[0, -1.9, 0]}>
          <Label text="Age estimation: 3rd molar (18) erupting → ~17–21 yrs" position={[0, 0.4, 0]} size={0.45} color="#86efac" />
          {/* eruption stage bar */}
          {[0, 1, 2, 3, 4].map((i) => (
            <mesh key={i} position={[-2 + i, 0, 0]}>
              <boxGeometry args={[0.8, 0.3, 0.3]} />
              <meshStandardMaterial color={i <= 3 ? "#22c55e" : "#334155"} roughness={0.5} />
            </mesh>
          ))}
          <Label text="Child → Teen → Adult" position={[0, -0.5, 0]} size={0.4} color="#94a3b8" />
        </group>
      )}
      <Label text={mode === "identify" ? "Dental identification: match to records" : "Age estimation: eruption + wear"} position={[0, 3.6, 0]} size={0.55} color="#e2e8f0" />
    </group>
  );
}

export function Topic10413Sim(props: SimProps) {
  const mode = String(props.mode ?? "identify");
  const tooth = Number(props.tooth ?? 16);
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Analysis", mode === "identify" ? "Identification" : "Age estimation"], ["Tooth", `FDI ${tooth}`], ["Method", mode === "identify" ? "Compare ante/post-mortem" : "Eruption staging"]]} />
      <SimCanvas cameraPosition={[0, 4, 9]} target={[0, 0.3, 0]}>
        <Scene mode={mode} tooth={tooth} />
      </SimCanvas>
    </div>
  );
}
