"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "mat", label: "Material", kind: "select", min: 0, max: 0, step: 1, default: "gic", options: ["gic", "compomer", "rmgic"] },
  { key: "speed", label: "Ion release", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Glass ionomer and compomer restorations",
  blurb: "White glass-ionomer filling that chemically bonds to the tooth and leaks protective fluoride ions for months.",
};

const MATS: Record<string, { name: string; color: string; note: string; bond: string }> = {
  gic: { name: "Conventional GIC", color: "#f8fafc", note: "Best fluoride release — kids & root caries", bond: "Chemical bond — no drilling for retention!" },
  compomer: { name: "Compomer", color: "#fdf6e3", note: "Prettier, less fluoride — front teeth", bond: "Needs a bonding agent" },
  rmgic: { name: "Resin-modified GIC", color: "#e0f2fe", note: "Light-cured, tougher — sandwich fillings", bond: "Chemical + light cure" },
};

function FluorideLeak({ speed }: { speed: number }) {
  const pts = useRef<THREE.Points>(null!);
  const t = useRef(Math.random() * 5);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(30 * 3), 3));
    return g;
  }, []);
  useFrame((_, delta) => {
    t.current += delta * speed;
    if (!pts.current) return;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < 30; i++) {
      const f = (t.current * 0.5 + i / 30) % 1;
      const a = i * 2.7;
      pos.setXYZ(i, Math.cos(a) * (0.4 + f * 1.6), 1.3 + Math.sin(a) * (0.3 + f * 1.2), Math.sin(a * 1.3) * (0.4 + f * 1.4));
    }
    pos.needsUpdate = true;
  });
  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial color="#7dd3fc" size={0.13} transparent opacity={0.9} />
    </points>
  );
}

function Scene({ mat, speed }: { mat: string; speed: number }) {
  const m = MATS[mat] ?? MATS.gic;
  const t = useRef(0);
  const bond = useRef<THREE.Mesh>(null!);

  useFrame((_, delta) => {
    t.current += delta * speed;
    if (bond.current) {
      (bond.current.material as THREE.MeshStandardMaterial).opacity = 0.5 + Math.sin(t.current * 2.5) * 0.2;
    }
  });

  return (
    <group>
      {/* tooth with cervical cavity */}
      <mesh position={[0, 0.6, 0]}>
        <cylinderGeometry args={[1.05, 1.25, 1.5, 20]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.25} />
      </mesh>
      <mesh position={[0, -0.9, 0]}>
        <coneGeometry args={[0.85, 1.5, 18]} />
        <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
      </mesh>
      {/* Class V cavity near gumline */}
      <mesh position={[0, -0.05, 1.05]} rotation={[0.2, 0, 0]}>
        <boxGeometry args={[0.9, 0.5, 0.3]} />
        <meshStandardMaterial color="#475569" roughness={0.9} />
      </mesh>
      {/* GIC filling */}
      <mesh position={[0, -0.05, 1.08]} rotation={[0.2, 0, 0]}>
        <boxGeometry args={[0.86, 0.46, 0.24]} />
        <meshStandardMaterial color={m.color} roughness={0.4} />
      </mesh>
      {/* chemical bond glow at interface */}
      <mesh ref={bond} position={[0, -0.05, 1.2]} rotation={[0.2, 0, 0]}>
        <boxGeometry args={[0.95, 0.55, 0.06]} />
        <meshStandardMaterial color="#38bdf8" transparent opacity={0.6} emissive="#0ea5e9" emissiveIntensity={0.8} />
      </mesh>
      <Label text="Chemical bond — sticks itself!" position={[2.2, -0.05, 1.2]} size={0.42} color="#7dd3fc" />

      <FluorideLeak speed={speed} />
      <Label text="Fluoride ions leaking out for months" position={[-2.4, 2.2, 0]} size={0.42} color="#7dd3fc" />

      {/* powder + liquid mixing */}
      <group position={[-2.6, -1.2, 0]}>
        <mesh position={[-0.4, 0, 0]}>
          <cylinderGeometry args={[0.3, 0.35, 0.5, 12]} />
          <meshStandardMaterial color="#e2e8f0" roughness={0.6} />
        </mesh>
        <mesh position={[0.4, 0, 0]}>
          <cylinderGeometry args={[0.2, 0.25, 0.6, 12]} />
          <meshStandardMaterial color="#bae6fd" roughness={0.4} />
        </mesh>
        <Label text="Powder + liquid → mix" position={[0, 0.8, 0]} size={0.4} color="#e2e8f0" />
      </group>

      <Label text={m.name} position={[0, 3.4, 0]} size={0.6} color={m.color === "#f8fafc" ? "#e2e8f0" : m.color} />
      <Label text={`${m.note} · ${m.bond}`} position={[0, -2.6, 0]} size={0.42} color="#e2e8f0" />
    </group>
  );
}

export function Topic10447Sim(props: SimProps) {
  const mat = String(props.mat ?? "gic");
  const speed = Number(props.speed ?? 1);
  const m = MATS[mat] ?? MATS.gic;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Material", m.name], ["Fluoride release", mat === "gic" ? "High" : mat === "rmgic" ? "Medium" : "Low"], ["Bond", "Chemical"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 9]} target={[0, 0.3, 0]}>
        <Scene mat={mat} speed={speed} />
      </SimCanvas>
    </div>
  );
}
