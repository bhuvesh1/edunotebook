// Sedatives & antiepileptics: neurons in the brain fire electrical sparks —
// sedative drugs calm the storm and the firing slows to a gentle rhythm.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "sed", label: "Sedation level", kind: "slider", min: 0, max: 100, step: 5, default: 45, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Sedatives & antiepileptics",
  blurb: "Neurons fire electrical sparks — sedative drugs calm the storm into a gentle rhythm.",
};

const NEURONS: [number, number, number][] = [
  [-2.2, 1.6, 0.4], [-0.7, 2.2, -0.6], [0.9, 1.7, 0.5], [2.3, 2.3, -0.3],
  [-1.5, 0.8, -0.5], [0.2, 0.9, 0.6], [1.7, 0.7, -0.4],
];
const N_SPARKS = 14;

function Animator({ sparks, brain, elapsed, level, setTick }: {
  sparks: React.RefObject<(THREE.Mesh | null)[]>;
  brain: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  level: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = level / 100;
    const activity = 1 - k * 0.85; // firing rate
    if (brain.current) {
      // seizure-like jitter at low sedation, calm at high
      const j = (1 - k) * 0.06;
      brain.current.position.x = Math.sin(t * 23) * j;
      brain.current.position.z = Math.cos(t * 19) * j;
      brain.current.rotation.y = t * 0.15;
    }
    sparks.current.forEach((s, i) => {
      if (!s) return;
      const a = NEURONS[i % NEURONS.length];
      const b = NEURONS[(i + 1) % NEURONS.length];
      const f = (t * (0.6 + activity * 2.2) + i / N_SPARKS) % 1;
      s.position.set(a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f);
      const vis = ((i * 37) % 10) / 10 < activity;
      s.visible = vis;
      ((s as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = 0.6 + activity * 1.6;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(activity * 100)); }
  });
  return null;
}

export function Topic10113Sim(props: SimProps) {
  const level = Number(props.sed ?? 45);
  const showLabels = String(props.detail ?? "on") === "on";
  const sparks = useRef<(THREE.Mesh | null)[]>([]);
  const brain = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const state = level < 30 ? "seizure-like storm" : level < 65 ? "calming" : "deeply sedated";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Neuronal activity", `${tick}%`],
          ["Brain state", state],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 11]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* brain: lumpy pink mass */}
        <group ref={brain} position={[0, 1.5, 0]}>
          {[
            [-1.2, 0.5, 0, 1.1], [0, 0.9, 0, 1.25], [1.2, 0.5, 0, 1.1],
            [-0.6, 0.1, 0.5, 0.9], [0.6, 0.1, -0.5, 0.9], [0, 0.3, 0.7, 1.0],
            [-1.5, -0.2, -0.3, 0.75], [1.5, -0.2, 0.3, 0.75],
          ].map((b, i) => (
            <mesh key={i} position={[b[0], b[1], b[2]]} castShadow>
              <sphereGeometry args={[b[3], 20, 14]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.65} />
            </mesh>
          ))}
          {/* neurons */}
          {NEURONS.map((n, i) => (
            <group key={`n${i}`} position={[n[0], n[1], n[2]]}>
              <mesh castShadow>
                <sphereGeometry args={[0.22, 14, 10]} />
                <meshStandardMaterial color="#a855f7" emissive="#7e22ce" emissiveIntensity={0.9} />
              </mesh>
            </group>
          ))}
          {/* firing sparks travelling between neurons */}
          {Array.from({ length: N_SPARKS }).map((_, i) => (
            <mesh key={`s${i}`} ref={(m) => { sparks.current[i] = m; }}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshStandardMaterial color="#fef08a" emissive="#facc15" emissiveIntensity={1.5} />
            </mesh>
          ))}
        </group>
        {showLabels && <Label text="brain — neurons firing" position={[0, 4.4, 0]} color="#f9a8d4" />}

        {/* sedative pill */}
        <group position={[4.4, 0, 1.4]}>
          <mesh position={[0, 0.6, 0]} castShadow>
            <capsuleGeometry args={[0.24, 0.4, 8, 16]} />
            <meshStandardMaterial color="#8b5cf6" roughness={0.3} />
          </mesh>
        </group>
        {showLabels && <Label text="sedative / antiepileptic" position={[4.4, 1.7, 1.4]} size={0.45} color="#c4b5fd" />}

        <Animator sparks={sparks} brain={brain} elapsed={elapsed} level={level} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
