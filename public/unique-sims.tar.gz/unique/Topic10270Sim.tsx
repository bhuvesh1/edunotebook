// Cardiology: congenital heart diseases — acyanotic and cyanotic.
// A beating heart with four chambers. Blood flows red on the left, blue on the
// right; a hole in the wall (ASD/VSD) lets blood shunt across, and Tetralogy
// shows its classic four defects.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "defect", label: "Heart defect", kind: "select", min: 0, max: 0, step: 1, default: "vsd", options: ["normal", "asd", "vsd", "tof"] },
  { key: "rate", label: "Heart rate", kind: "slider", min: 0.4, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Baby's Heart: Holes & Blue Baby",
  blurb: "A beating heart pumps red and blue blood — see a hole between chambers (ASD/VSD) or the four defects of Tetralogy of Fallot.",
};

const N_BLOOD = 36;

function Animator({
  heart, blood, shunt, elapsed, rate, defect,
}: {
  heart: React.RefObject<THREE.Group>;
  blood: React.RefObject<THREE.Group>;
  shunt: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  rate: number;
  defect: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * rate;
    const t = elapsed.current;
    // heartbeat: lub-dub double thump
    const beat = Math.pow(Math.max(0, Math.sin(t * 4.2)), 3) + 0.5 * Math.pow(Math.max(0, Math.sin(t * 4.2 + 0.9)), 6);
    if (heart.current) {
      heart.current.scale.set(1 + beat * 0.07, 1 + beat * 0.05, 1 + beat * 0.07);
      heart.current.rotation.y = Math.sin(t * 0.3) * 0.25;
    }
    // blood cells circulate; with a defect some cross the septum
    if (blood.current) {
      blood.current.children.forEach((c, i) => {
        const left = i % 2 === 0;
        const ph = ((t * 0.5 + i / N_BLOOD) % 1);
        const crosses = defect !== "normal" && i % 5 === 0;
        let x: number;
        if (crosses) {
          // shunt across the septum through the hole
          const f = ph < 0.5 ? ph * 2 : 2 - ph * 2;
          x = left ? 0.55 - f * 1.1 : -0.55 + f * 1.1;
        } else {
          x = (left ? 0.62 : -0.62) + Math.sin(ph * Math.PI * 2 + i) * 0.18;
        }
        c.position.set(x, 2.6 - ph * 2.2, Math.cos(i * 1.3) * 0.35);
      });
    }
    if (shunt.current) {
      shunt.current.visible = defect !== "normal";
      shunt.current.children.forEach((s, i) => {
        (s as THREE.Mesh).scale.setScalar(1 + 0.3 * Math.sin(t * 6 + i * 2));
      });
    }
  });
  return null;
}

export function Topic10270Sim(props: SimProps) {
  const defect = String(props.defect ?? "vsd");
  const rate = Number(props.rate ?? 1);
  const heart = useRef<THREE.Group>(null!);
  const blood = useRef<THREE.Group>(null!);
  const shunt = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const isTof = defect === "tof";
  const holeY = defect === "asd" ? 3.0 : 1.9; // ASD high, VSD low

  const names: Record<string, string> = {
    normal: "Normal heart", asd: "ASD (hole between atria)", vsd: "VSD (hole between ventricles)", tof: "Tetralogy of Fallot",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Defect", names[defect] ?? defect], ["Heart rate", `${rate.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={heart}>
          {/* heart muscle: two ventricle cones + atrial tops */}
          {[-0.55, 0.55].map((x, i) => (
            <group key={i} position={[x, 1.5, 0]}>
              <mesh scale={[0.85, 1.25, 0.8]} castShadow>
                <coneGeometry args={[0.62, 1.9, 24]} />
                <meshStandardMaterial color={i === 0 ? "#1d4ed8" : "#b91c1c"} roughness={0.5} />
              </mesh>
              <mesh position={[0, 1.15, 0]} scale={[0.8, 0.75, 0.75]} castShadow>
                <sphereGeometry args={[0.5, 20, 14]} />
                <meshStandardMaterial color={i === 0 ? "#1d4ed8" : "#b91c1c"} roughness={0.5} />
              </mesh>
            </group>
          ))}
          {/* septum wall between chambers */}
          <mesh position={[0, 1.9, 0]} castShadow>
            <boxGeometry args={[0.14, 2.9, 1.1]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.6} />
          </mesh>
          {/* the hole (glowing marker where blood shunts) */}
          {defect !== "normal" && (
            <mesh position={[0, holeY, 0.45]} castShadow>
              <torusGeometry args={[0.22, 0.09, 10, 18]} />
              <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1.2} />
            </mesh>
          )}
          {/* TOF extras: overriding aorta + narrowed pulmonary artery */}
          {isTof && (
            <>
              <mesh position={[0.1, 3.6, 0]} rotation={[0, 0, 0.15]} castShadow>
                <cylinderGeometry args={[0.34, 0.34, 1.4, 16]} />
                <meshStandardMaterial color="#ef4444" roughness={0.45} />
              </mesh>
              <mesh position={[-0.85, 3.5, 0]} rotation={[0, 0, 0.3]} castShadow>
                <cylinderGeometry args={[0.12, 0.12, 1.2, 12]} />
                <meshStandardMaterial color="#3b82f6" roughness={0.45} />
              </mesh>
            </>
          )}
          {/* normal great vessels */}
          {!isTof && (
            <>
              <mesh position={[0.55, 3.6, 0]} rotation={[0, 0, -0.2]} castShadow>
                <cylinderGeometry args={[0.28, 0.28, 1.3, 16]} />
                <meshStandardMaterial color="#ef4444" roughness={0.45} />
              </mesh>
              <mesh position={[-0.55, 3.6, 0]} rotation={[0, 0, 0.2]} castShadow>
                <cylinderGeometry args={[0.28, 0.28, 1.3, 16]} />
                <meshStandardMaterial color="#3b82f6" roughness={0.45} />
              </mesh>
            </>
          )}
          {/* blood cells */}
          <group ref={blood}>
            {Array.from({ length: N_BLOOD }).map((_, i) => (
              <mesh key={i}>
                <sphereGeometry args={[0.11, 10, 8]} />
                <meshBasicMaterial color={i % 2 === 0 ? "#f87171" : "#60a5fa"} />
              </mesh>
            ))}
          </group>
          {/* shunt warning markers */}
          <group ref={shunt} visible={false}>
            {[0, 1].map((i) => (
              <mesh key={i} position={[i === 0 ? -0.45 : 0.45, holeY + 0.45, 0.6]}>
                <sphereGeometry args={[0.14, 10, 8]} />
                <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1.4} />
              </mesh>
            ))}
          </group>
          <Label text="Blue blood (to lungs)" position={[-2.2, 2.6, 0]} size={0.5} color="#93c5fd" />
          <Label text="Red blood (to body)" position={[2.2, 2.6, 0]} size={0.5} color="#fca5a5" />
          {defect === "asd" && <Label text="⚠ Hole between atria" position={[0, 3.9, 0.5]} size={0.55} color="#fde68a" />}
          {defect === "vsd" && <Label text="⚠ Hole between ventricles" position={[0, 0.55, 0.5]} size={0.55} color="#fde68a" />}
          {isTof && <Label text="⚠ TOF: 4 defects, blue baby" position={[0, 0.5, 0]} size={0.55} color="#93c5fd" />}
          {defect === "normal" && <Label text="No mixing ✓" position={[0, 0.5, 0]} size={0.55} color="#86efac" />}
          <Arrow from={[-0.55, 4.4, 0]} to={[-0.55, 3.0, 0]} color="#60a5fa" radius={0.06} />
          <Arrow from={[0.55, 4.4, 0]} to={[0.55, 3.0, 0]} color="#f87171" radius={0.06} />
        </group>
        <Animator heart={heart} blood={blood} shunt={shunt} elapsed={elapsed} rate={rate} defect={defect} />
      </SimCanvas>
    </div>
  );
}
