"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Rotation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 0.6, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Abdomen: anterior abdominal wall, peritoneum, GI viscera, liver, spleen, pancreas",
  blurb: "The belly's organs on display: the big liver, J-shaped stomach and the coiled small intestine — gently churning.",
};

function Organs({ speed }: { speed: number }) {
  const g = useRef<THREE.Group>(null!);
  const gut = useRef<THREE.Mesh>(null!);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d * speed;
    if (g.current) g.current.rotation.y = t.current * 0.5;
    if (gut.current) gut.current.rotation.z = Math.sin(t.current * 1.1) * 0.12;
  });
  return (
    <group ref={g} position={[0, 0.6, 0]}>
      {/* abdominal wall hint */}
      <mesh position={[0, 3.0, 0]}>
        <cylinderGeometry args={[2.2, 1.9, 5.4, 24, 1, true]} />
        <meshStandardMaterial color="#f1c27d" roughness={0.8} transparent opacity={0.16} side={THREE.DoubleSide} />
      </mesh>
      {/* liver: big right lobe */}
      <mesh position={[0.9, 4.3, 0.3]} rotation={[0, 0, -0.25]} castShadow>
        <sphereGeometry args={[1.15, 22, 18]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.45} emissive="#450a0a" emissiveIntensity={0.4} />
      </mesh>
      {/* gallbladder */}
      <mesh position={[0.5, 3.5, 0.9]} castShadow>
        <sphereGeometry args={[0.28, 14, 14]} />
        <meshStandardMaterial color="#4d7c0f" roughness={0.4} />
      </mesh>
      {/* stomach: J-shape */}
      <mesh position={[-1.0, 3.8, 0.2]} rotation={[0, 0, 0.5]} castShadow>
        <torusGeometry args={[0.55, 0.32, 14, 22, Math.PI * 1.3]} />
        <meshStandardMaterial color="#fca5a5" roughness={0.5} />
      </mesh>
      {/* esophagus into stomach */}
      <mesh position={[-1.35, 4.7, 0.2]} castShadow>
        <cylinderGeometry args={[0.16, 0.16, 0.9, 10]} />
        <meshStandardMaterial color="#fca5a5" roughness={0.5} />
      </mesh>
      {/* pancreas behind stomach */}
      <mesh position={[-0.2, 3.3, -0.5]} rotation={[0, 0.3, 0.15]} castShadow>
        <boxGeometry args={[1.3, 0.35, 0.4]} />
        <meshStandardMaterial color="#fde68a" roughness={0.55} />
      </mesh>
      {/* spleen */}
      <mesh position={[-1.7, 4.0, -0.4]} castShadow>
        <sphereGeometry args={[0.35, 14, 14]} />
        <meshStandardMaterial color="#9333ea" roughness={0.5} />
      </mesh>
      {/* coiled small intestine */}
      <mesh ref={gut} position={[0, 1.7, 0.2]} castShadow>
        <torusKnotGeometry args={[0.85, 0.24, 90, 12]} />
        <meshStandardMaterial color="#fdba74" roughness={0.55} />
      </mesh>
      {/* large intestine frame */}
      <mesh position={[0, 1.8, 0.1]} castShadow>
        <torusGeometry args={[1.25, 0.2, 12, 28]} />
        <meshStandardMaterial color="#f59e0b" roughness={0.55} />
      </mesh>
    </group>
  );
}

export function Topic10006Sim(props: SimProps) {
  const speed = Number(props.speed ?? 0.6);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Largest organ", "liver"], ["Gut", "peristalsis"], ["Cavity", "peritoneal"]]} />
      <SimCanvas cameraPosition={[7, 4.5, 10]} target={[0, 2.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Organs speed={speed} />
        {showLabels && (
          <>
            <Label text="Liver" position={[3.0, 5.4, 0]} color="#fca5a5" size={0.5} />
            <Label text="Stomach" position={[-3.0, 4.6, 0]} color="#fda4af" size={0.5} />
            <Label text="Small intestine" position={[2.8, 2.2, 0]} color="#fdba74" size={0.5} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
