// app/components/sims/unique/Topic10546Sim.tsx
// Infant oral health, teething and natal teeth: a baby's gum pad with a
// tooth bud erupting through as the age slider passes 6 months.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "age", label: "Age", kind: "slider", min: 0, max: 12, step: 0.5, default: 7, unit: " mo" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Infant Oral Health & Teething",
  blurb: "A tooth bud pushes through the baby's gum around 6 months — drool, chewing, and sleepless nights included.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ bud, drool, elapsed, speed, age }: {
  bud: RefObject<THREE.Group>; drool: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number; age: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (bud.current) {
      // eruption progress: starts ~4 mo, full by ~8 mo
      const k = Math.max(0, Math.min((age - 4) / 4, 1));
      bud.current.position.y = -0.7 + k * 1.05 + 0.03 * Math.sin(t * 2);
      bud.current.visible = age >= 3.5;
    }
    if (drool.current) {
      const teething = age >= 4 && age <= 9;
      drool.current.visible = teething;
      drool.current.children.forEach((c, i) => {
        c.position.y = 1.6 - ((t * 0.9 + i * 0.33) % 1.2);
      });
    }
  });
  return null;
}

export function Topic10546Sim(props: SimProps) {
  const age = Number(props.age ?? 7);
  const speed = Number(props.speed ?? 1);
  const bud = useRef<THREE.Group>(null!);
  const drool = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const note = age < 4 ? "gums only — wipe with a soft cloth" : age <= 9 ? "teething! drooling + chewing — cold teether helps" : "first teeth are in — start brushing with a smear of fluoride toothpaste";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Age", `${age.toFixed(1)} months`],
          ["Teeth", age < 6 ? "0 (pre-eruption)" : age < 8 ? "erupting…" : "lower central incisors ✓"],
          ["Care", note],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* baby head */}
        <mesh position={[0, 3.0, -0.6]} castShadow>
          <sphereGeometry args={[1.9, 32, 32]} />
          <meshStandardMaterial color="#f7cfa8" roughness={0.65} />
        </mesh>
        {/* chubby cheeks */}
        {[-0.9, 0.9].map((x, i) => (
          <mesh key={i} position={[x, 2.7, 0.9]} castShadow>
            <sphereGeometry args={[0.55, 18, 18]} />
            <meshStandardMaterial color="#f7cfa8" roughness={0.65} />
          </mesh>
        ))}
        {/* open little mouth */}
        <mesh position={[0, 2.1, 1.0]}>
          <sphereGeometry args={[0.75, 20, 20]} />
          <meshStandardMaterial color="#5b1a1a" roughness={0.9} />
        </mesh>
        {/* gum pad */}
        <mesh position={[0, 1.85, 0.9]} scale={[1.3, 0.5, 0.9]} castShadow>
          <sphereGeometry args={[0.7, 18, 18]} />
          <meshStandardMaterial color="#e0607a" roughness={0.55} />
        </mesh>

        {/* erupting tooth bud */}
        <group ref={bud} position={[0, -0.7, 0.9]} visible={false}>
          <mesh castShadow>
            <boxGeometry args={[0.4, 0.5, 0.35]} />
            <meshStandardMaterial color="#ffffff" roughness={0.25} />
          </mesh>
          {/* gum bulge over the bud */}
          <mesh position={[0, 0.32, 0]}>
            <sphereGeometry args={[0.3, 14, 14]} />
            <meshStandardMaterial color="#f0809a" transparent opacity={0.7} roughness={0.5} />
          </mesh>
        </group>

        {/* drool drops while teething */}
        <group ref={drool} visible={false}>
          {[...Array(5)].map((_, i) => (
            <mesh key={i} position={[-0.4 + i * 0.2, 1.6, 1.3]}>
              <sphereGeometry args={[0.07, 8, 8]} />
              <meshStandardMaterial color="#bae6fd" transparent opacity={0.8} roughness={0.2} />
            </mesh>
          ))}
        </group>

        {/* natal tooth warning for age 0 */}
        {age < 1 && (
          <Label p={[0, 4.9, 0.6]} size={0.3} color="#fde68a">natal teeth (present at birth) are rare — check with the dentist</Label>
        )}

        <Label p={[2.4, 1.85, 1.0]} size={0.3} color="#ffffff">first tooth ~6 months</Label>
        <Label p={[0, 0.4, 0.8]} size={0.3} color="#e2e8f0">{note}</Label>

        <Animator bud={bud} drool={drool} elapsed={elapsed} speed={speed} age={age} />
      </SimCanvas>
    </div>
  );
}
