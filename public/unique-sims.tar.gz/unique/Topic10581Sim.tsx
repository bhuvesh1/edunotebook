// Topic10581 — Diastema closure and aesthetic contouring.
// Two front teeth with a gap. Orthodontic force (and veneers) pull them
// together — watch the millimetre gap shrink to zero.

"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "gap", label: "Diastema gap", kind: "slider", min: 0, max: 6, step: 0.5, default: 3, unit: "mm" },
  { key: "forces", label: "Show forces", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Diastema closure and aesthetic contouring",
  blurb: "A gap between front teeth closes under gentle orthodontic force — dial the millimetres down.",
};

function Animator({
  left,
  right,
  spark,
  elapsed,
  target,
}: {
  left: RefObject<THREE.Group>;
  right: RefObject<THREE.Group>;
  spark: RefObject<THREE.Group>;
  elapsed: RefObject<number>;
  target: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const half = 0.55 + target * 0.32;
    if (left.current) {
      left.current.position.x += ((-half - left.current.position.x) * Math.min(1, delta * 2.5));
      left.current.position.y = 2.1 + Math.sin(t * 3) * 0.015;
    }
    if (right.current) {
      right.current.position.x += ((half - right.current.position.x) * Math.min(1, delta * 2.5));
      right.current.position.y = 2.1 + Math.sin(t * 3 + 1) * 0.015;
    }
    if (spark.current) {
      const closed = target < 0.25;
      spark.current.visible = closed;
      spark.current.rotation.y = t * 2.5;
      const s = closed ? 0.8 + 0.3 * Math.sin(t * 6) : 0.001;
      spark.current.children.forEach((m) => m.scale.setScalar(s));
    }
  });
  return null;
}

function Incisor() {
  return (
    <group>
      <mesh position={[0, 0, 0]} castShadow>
        <boxGeometry args={[1.0, 1.7, 0.62]} />
        <meshStandardMaterial color="#fefdf8" roughness={0.3} />
      </mesh>
      <mesh position={[0, -1.25, 0]} castShadow>
        <coneGeometry args={[0.34, 1.1, 12]} />
        <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
      </mesh>
    </group>
  );
}

export function Topic10581Sim(props: SimProps) {
  const gap = Number(props.gap ?? 3);
  const showForces = String(props.forces ?? "on") === "on";
  const left = useRef<THREE.Group>(null!);
  const right = useRef<THREE.Group>(null!);
  const spark = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const half = 0.55 + gap * 0.32;
  const closed = gap < 0.25;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Gap", `${gap.toFixed(1)} mm`],
          ["Status", closed ? "Closed ✓" : "Closing…"],
          ["Method", "Ortho force + contouring"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 11]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* gum ridge behind the teeth */}
        <mesh position={[0, 1.5, -0.9]}>
          <boxGeometry args={[7.5, 2.2, 1.4]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.7} />
        </mesh>

        <group ref={left} position={[-half, 2.1, 0]}>
          <Incisor />
        </group>
        <group ref={right} position={[half, 2.1, 0]}>
          <Incisor />
        </group>

        {/* orthodontic force arrows pushing teeth together */}
        {showForces && !closed && (
          <>
            <Arrow from={[-3.6, 2.1, 0]} to={[-half - 0.7, 2.1, 0]} color="#fbbf24" />
            <Arrow from={[3.6, 2.1, 0]} to={[half + 0.7, 2.1, 0]} color="#fbbf24" />
          </>
        )}

        {/* celebration sparkle at the contact point when closed */}
        <group ref={spark} position={[0, 2.4, 0.4]}>
          {Array.from({ length: 8 }).map((_, i) => {
            const a = (i / 8) * Math.PI * 2;
            return (
              <mesh key={i} position={[Math.cos(a) * 0.55, Math.sin(a) * 0.55, 0]}>
                <octahedronGeometry args={[0.1]} />
                <meshStandardMaterial color="#fef9c3" emissive="#facc15" emissiveIntensity={1.6} />
              </mesh>
            );
          })}
        </group>

        <Label text="DIASTEMA — the gap" position={[0, 3.9, 0]} size={0.42} color="#fcd34d" />
        <Label text={closed ? "GAP CLOSED — perfect contact!" : "ORTHODONTIC FORCE pulls teeth together"} position={[0, -0.35, 0]} size={0.38} color={closed ? "#86efac" : "#fbbf24"} />
        <Label text="CONTOURING reshapes edges for symmetry" position={[0, 0.45, -0.9]} size={0.34} color="#94a3b8" />

        <Animator left={left} right={right} spark={spark} elapsed={elapsed} target={gap} />
      </SimCanvas>
    </div>
  );
}
