"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Lesion stage", kind: "slider", min: 0, max: 4, step: 1, default: 2, unit: "" },
  { key: "risk", label: "Caries risk", kind: "select", min: 0, max: 0, step: 1, default: "moderate", options: ["low", "moderate", "high"] },
];

export const UNIQUE_META = {
  title: "Dental caries: diagnosis, caries risk assessment, minimal intervention",
  blurb: "A tooth's decay journey from white spot to deep cavity — slide the stage and see when a filling becomes unavoidable.",
};

const STAGE_INFO = [
  { name: "Sound", color: "#f8fafc", note: "Healthy enamel — keep brushing + fluoride" },
  { name: "White spot", color: "#fefce8", note: "Chalky demineralization — REVERSIBLE with fluoride!" },
  { name: "Enamel cavity", color: "#fcd34d", note: "Surface broken — needs a small filling" },
  { name: "Dentin cavity", color: "#b45309", note: "Brown decay into dentin — bigger filling" },
  { name: "Pulp exposed", color: "#dc2626", note: "Nerve involved — root canal or extraction" },
];

const RISK_COLORS: Record<string, string> = { low: "#86efac", moderate: "#fde68a", high: "#fca5a5" };

function Scene({ stage, risk }: { stage: number; risk: string }) {
  const lesion = useRef<THREE.Mesh>(null!);
  const t = useRef(0);
  const st = STAGE_INFO[stage] ?? STAGE_INFO[2];

  useFrame((_, delta) => {
    t.current += delta;
    if (lesion.current && stage >= 2) {
      lesion.current.scale.setScalar(1 + Math.sin(t.current * 3) * 0.05);
    }
  });

  const riskCount = risk === "low" ? 4 : risk === "moderate" ? 10 : 18;

  return (
    <group>
      {/* tooth */}
      <group>
        <mesh position={[0, 0.7, 0]}>
          <cylinderGeometry args={[1.0, 1.2, 1.4, 20]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.25} />
        </mesh>
        {/* dentin layer hint */}
        <mesh position={[0, 0.7, 0]}>
          <cylinderGeometry args={[0.8, 0.95, 1.2, 18]} />
          <meshStandardMaterial color="#f5d78e" roughness={0.5} transparent opacity={0.0} />
        </mesh>
        <mesh position={[0, -0.8, 0]}>
          <coneGeometry args={[0.8, 1.4, 18]} />
          <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
        </mesh>
        {/* pulp */}
        <mesh position={[0, 0.1, 0]}>
          <cylinderGeometry args={[0.22, 0.26, 1.8, 12]} />
          <meshStandardMaterial color={stage >= 4 ? "#ef4444" : "#fca5a5"} emissive={stage >= 4 ? "#ef4444" : "#000"} emissiveIntensity={stage >= 4 ? 1 : 0} roughness={0.5} />
        </mesh>
      </group>

      {/* lesion per stage */}
      {stage === 1 && (
        <mesh position={[-0.4, 1.42, 0.55]} rotation={[-0.5, 0, 0]}>
          <circleGeometry args={[0.4, 16]} />
          <meshStandardMaterial color="#fefce8" roughness={0.9} />
        </mesh>
      )}
      {stage >= 2 && (
        <mesh ref={lesion} position={[-0.35, 1.3 - (stage - 2) * 0.25, 0.5]}>
          <sphereGeometry args={[0.28 + stage * 0.09, 16, 16]} />
          <meshStandardMaterial color={st.color} roughness={0.8} />
        </mesh>
      )}
      {stage >= 4 && (
        <mesh position={[-0.3, 0.5, 0.45]}>
          <boxGeometry args={[0.25, 0.8, 0.25]} />
          <meshStandardMaterial color="#7f1d1d" roughness={0.9} />
        </mesh>
      )}

      {/* risk bacteria swarm */}
      {Array.from({ length: riskCount }).map((_, i) => (
        <mesh key={i} position={[(i % 6) * 0.9 - 2.2, 2.4 + Math.floor(i / 6) * 0.5, -1.5]}>
          <sphereGeometry args={[0.13, 8, 8]} />
          <meshStandardMaterial color="#4d7c0f" roughness={0.6} />
        </mesh>
      ))}
      <Label text={`Caries risk: ${risk}`} position={[0, 4.0, -1.5]} size={0.45} color={RISK_COLORS[risk]} />

      {/* explorer probe */}
      <group position={[1.8, 2.2, 0.8]} rotation={[0, 0, -0.5]}>
        <mesh position={[0, 0.6, 0]}>
          <cylinderGeometry args={[0.06, 0.06, 1.4, 8]} />
          <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
        </mesh>
        <mesh position={[0, -0.25, 0]} rotation={[0, 0, 0.5]}>
          <cylinderGeometry args={[0.02, 0.005, 0.5, 6]} />
          <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.3} />
        </mesh>
      </group>
      <Label text="Explorer + X-ray diagnose" position={[1.8, 3.2, 0.8]} size={0.4} color="#bae6fd" />

      <Label text={`Stage ${stage}: ${st.name}`} position={[0, 3.2, 0]} size={0.6} color={st.color === "#f8fafc" ? "#e2e8f0" : st.color} />
      <Label text={st.note} position={[0, -2.4, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10443Sim(props: SimProps) {
  const stage = Number(props.stage ?? 2);
  const risk = String(props.risk ?? "moderate");
  const st = STAGE_INFO[stage] ?? STAGE_INFO[2];
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Stage", st.name], ["Risk", risk], ["Action", stage <= 1 ? "Fluoride, no drilling" : stage <= 3 ? "Minimal filling" : "Root canal"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 9]} target={[0, 0.4, 0]}>
        <Scene stage={stage} risk={risk} />
      </SimCanvas>
    </div>
  );
}
