// app/components/sims/unique/Topic10575Sim.tsx
// Surgical placement protocols: the drilling sequence — pilot drill, then
// progressively wider twist drills — followed by implant insertion, all in
// one animated loop.

"use client";

import { useRef, useState, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Surgical Placement Protocols",
  blurb: "The implant drilling sequence loops: pilot drill, widening drills, then the fixture goes in.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

const STEPS = ["pilot drill", "2.0 mm twist drill", "2.8 mm twist drill", "3.5 mm twist drill", "implant placement"];

function Animator({ tools, implant, elapsed, speed, bump }: {
  tools: RefObject<THREE.Group>[]; implant: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number; bump: () => void;
}) {
  const step = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // each step lasts 2.4 s, loop forever
    const s = Math.floor(t / 2.4) % 5;
    if (s !== step.current) { step.current = s; bump(); }
    const local = (t % 2.4) / 2.4; // 0..1 within the step
    tools.forEach((tool, i) => {
      if (!tool.current) return;
      const active = i === s;
      tool.current.visible = active;
      if (active) {
        tool.current.position.y = 4.6 - 1.1 * Math.sin(local * Math.PI);
        tool.current.rotation.y = t * 14;
      }
    });
    if (implant.current) {
      const placing = s === 4;
      implant.current.visible = true;
      const targetY = placing ? 1.5 : 3.6;
      implant.current.position.y += (targetY - implant.current.position.y) * Math.min(delta * 4, 1);
      implant.current.rotation.y = placing ? t * 6 : 0;
    }
    if (++n.current % 30 === 0) bump();
  });
  return null;
}

export function Topic10575Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const t0 = useRef<THREE.Group>(null!);
  const t1 = useRef<THREE.Group>(null!);
  const t2 = useRef<THREE.Group>(null!);
  const t3 = useRef<THREE.Group>(null!);
  const implant = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [, setTick] = useState(0);
  const bump = () => setTick((v: number) => v + 1);

  const drills = [t0, t1, t2, t3];
  const widths = [0.1, 0.16, 0.24, 0.32];
  const stepIdx = Math.floor(elapsed.current / 2.4) % 5;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Current step", STEPS[stepIdx]],
          ["Irrigation", "copious saline, < 47 °C"],
          ["Protocol", "sequential widening"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* bone + gum */}
        <mesh position={[0, 1.1, 0]} castShadow receiveShadow>
          <boxGeometry args={[6, 2.2, 2.2]} />
          <meshStandardMaterial color="#d9b98a" roughness={0.85} />
        </mesh>
        <mesh position={[0, 2.45, 0]} castShadow>
          <boxGeometry args={[6, 0.5, 2.4]} />
          <meshStandardMaterial color="#f472b6" roughness={0.6} />
        </mesh>

        {/* four drills, one active at a time */}
        {drills.map((ref, i) => (
          <group key={i} ref={ref} position={[0, 4.6, 0]} visible={i === 0}>
            <mesh castShadow>
              <cylinderGeometry args={[0.34, 0.34, 1.2, 14]} />
              <meshStandardMaterial color="#475569" metalness={0.7} roughness={0.35} />
            </mesh>
            <mesh position={[0, -1.25, 0]}>
              <cylinderGeometry args={[widths[i], widths[i] * 0.7, 1.4, 12]} />
              <meshStandardMaterial color="#e2e8f0" metalness={0.9} roughness={0.2} />
            </mesh>
            {showLabels && (
              <Text position={[2.2, 0.4, 0]} fontSize={0.3} color="#e2e8f0" anchorX="center" anchorY="middle">
                {STEPS[i]}
              </Text>
            )}
          </group>
        ))}

        {/* implant waiting / being placed */}
        <group ref={implant} position={[0, 3.6, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.32, 0.24, 1.7, 16]} />
            <meshStandardMaterial color="#9ca3af" metalness={0.85} roughness={0.3} />
          </mesh>
          {[0.55, 0.18, -0.19, -0.56].map((dy, j) => (
            <mesh key={j} position={[0, dy, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.31, 0.05, 8, 20]} />
              <meshStandardMaterial color="#d1d5db" metalness={0.85} roughness={0.3} />
            </mesh>
          ))}
          {showLabels && (
            <Text position={[2.2, 0.6, 0]} fontSize={0.3} color="#d1d5db" anchorX="center" anchorY="middle">
              {STEPS[4]}
            </Text>
          )}
        </group>

        {/* coolant spray particles during drilling */}
        {stepIdx < 4 && (
          <group>
            {[...Array(10)].map((_, i) => (
              <mesh key={i} position={[Math.sin(i * 2.3) * 0.8, 3.1 + (i % 3) * 0.3, Math.cos(i * 1.7) * 0.8]}>
                <sphereGeometry args={[0.06, 8, 8]} />
                <meshStandardMaterial color="#7dd3fc" transparent opacity={0.7} />
              </mesh>
            ))}
          </group>
        )}

        <Animator tools={drills} implant={implant} elapsed={elapsed} speed={speed} bump={bump} />
      </SimCanvas>
    </div>
  );
}
