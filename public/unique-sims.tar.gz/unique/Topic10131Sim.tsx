// Gram-positive cocci: staphylococci pile up like bunches of purple grapes
// while streptococci link into long chains.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Gram-positive cocci",
  blurb: "Staphylococci pile like bunches of purple grapes; streptococci link into long chains.",
};

const STAPH: [number, number, number][] = [
  [0, 0, 0], [0.55, 0.15, 0.1], [-0.5, 0.2, -0.15], [0.1, 0.55, -0.1],
  [-0.15, -0.5, 0.15], [0.5, -0.4, -0.2], [-0.55, -0.25, 0.2],
  [0.2, 0.1, 0.5], [-0.2, 0.35, -0.5], [0.05, -0.15, -0.55],
];

function Animator({ staph, strep, elapsed, speed, setTick }: {
  staph: React.RefObject<THREE.Group>;
  strep: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (staph.current) {
      staph.current.rotation.y = t * 0.5;
      staph.current.children.forEach((c, i) => {
        c.position.y = STAPH[i][1] + Math.sin(t * 2 + i * 1.9) * 0.06;
      });
    }
    if (strep.current) {
      strep.current.children.forEach((c, i) => {
        c.position.y = 1.5 + Math.sin(t * 2.4 + i * 0.9) * 0.14;
        c.rotation.z = Math.sin(t * 1.8 + i) * 0.15;
      });
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(t * 10)); }
  });
  return null;
}

export function Topic10131Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const staph = useRef<THREE.Group>(null!);
  const strep = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stain", "Gram-positive — purple"],
          ["Staph arrangement", "clusters (grapes)"],
          ["Strep arrangement", "chains"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* Staphylococcus: grape-like cluster */}
        <group ref={staph} position={[-3, 1.5, 0]}>
          {STAPH.map((p, i) => (
            <mesh key={i} position={p} castShadow>
              <sphereGeometry args={[0.34, 18, 14]} />
              <meshStandardMaterial color="#7c3aed" roughness={0.4} />
            </mesh>
          ))}
        </group>
        {showLabels && <Label text="Staphylococcus — clusters" position={[-3, 3.2, 0]} color="#c4b5fd" />}
        {showLabels && <Label text="like grapes" position={[-3, -0.2, 0]} size={0.4} color="#a78bfa" />}

        {/* Streptococcus: chain */}
        <group ref={strep} position={[3, 0, 0]}>
          {Array.from({ length: 9 }).map((_, i) => (
            <mesh key={i} position={[(i - 4) * 0.62, 1.5, 0]} castShadow>
              <sphereGeometry args={[0.34, 18, 14]} />
              <meshStandardMaterial color="#8b5cf6" roughness={0.4} />
            </mesh>
          ))}
        </group>
        {showLabels && <Label text="Streptococcus — chains" position={[3, 3.2, 0]} color="#c4b5fd" />}
        {showLabels && <Label text="like beads on a string" position={[3, -0.2, 0]} size={0.4} color="#a78bfa" />}

        {/* dividing line */}
        <mesh position={[0, 1.5, 0]}>
          <boxGeometry args={[0.06, 3.6, 0.06]} />
          <meshStandardMaterial color="#334155" />
        </mesh>

        <Animator staph={staph} strep={strep} elapsed={elapsed} speed={speed} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
