// Bacterial morphology & Gram staining: coccus, bacillus and spirillum under the
// microscope — flood with crystal violet and watch Gram-positive stay purple
// while Gram-negative counterstains pink.
"use client";

import { useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stain", label: "Gram stain step", kind: "select", min: 0, max: 0, step: 1, default: "crystal violet", options: ["crystal violet", "iodine", "decolorizer", "safranin"] },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Bacterial morphology & staining",
  blurb: "Coccus, bacillus, spirillum under the microscope — Gram-positive stays purple, Gram-negative turns pink.",
};

function Animator({ group, elapsed, setTick }: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (group.current) {
      group.current.rotation.y = Math.sin(elapsed.current * 0.25) * 0.35;
      group.current.position.y = Math.sin(elapsed.current * 0.9) * 0.08;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(elapsed.current * 10)); }
  });
  return null;
}

export function Topic10129Sim(props: SimProps) {
  const stain = String(props.stain ?? "crystal violet");
  const showLabels = String(props.detail ?? "on") === "on";
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  // Gram-positive (coccus, bacillus): purple throughout; Gram-negative (spirillum): pink after safranin
  const gp = stain === "safranin" ? "#7c3aed" : stain === "decolorizer" ? "#c4b5fd" : "#6d28d9";
  const gn = stain === "safranin" ? "#f472b6" : stain === "decolorizer" ? "#e9d5ff" : "#6d28d9";
  const helix = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 60; i++) {
      const a = (i / 60) * Math.PI * 6;
      pts.push(new THREE.Vector3((i / 60 - 0.5) * 3.4, Math.cos(a) * 0.45, Math.sin(a) * 0.45));
    }
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 64, 0.16, 10);
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stain step", stain],
          ["Gram-positive", "purple"],
          ["Gram-negative", stain === "safranin" ? "pink" : "…"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={group}>
          {/* coccus — Gram-positive sphere */}
          <mesh position={[-3.4, 1.6, 0]} castShadow>
            <sphereGeometry args={[0.9, 24, 18]} />
            <meshStandardMaterial color={gp} roughness={0.45} />
          </mesh>
          {/* bacillus — Gram-positive rod */}
          <mesh position={[0, 1.6, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
            <capsuleGeometry args={[0.55, 1.8, 8, 18]} />
            <meshStandardMaterial color={gp} roughness={0.45} />
          </mesh>
          {/* spirillum — Gram-negative helix */}
          <mesh geometry={helix} position={[3.4, 1.6, 0]} castShadow>
            <meshStandardMaterial color={gn} roughness={0.45} />
          </mesh>
        </group>
        {showLabels && <Label text="coccus (G+)" position={[-3.4, 3.1, 0]} color="#c4b5fd" />}
        {showLabels && <Label text="bacillus (G+)" position={[0, 3.1, 0]} color="#c4b5fd" />}
        {showLabels && <Label text="spirillum (G−)" position={[3.4, 3.1, 0]} color="#f9a8d4" />}

        {/* microscope slide */}
        <mesh position={[0, 0.25, 0]} receiveShadow>
          <boxGeometry args={[10.5, 0.18, 3.6]} />
          <meshStandardMaterial color="#bae6fd" transparent opacity={0.35} roughness={0.1} />
        </mesh>
        {showLabels && <Label text="microscope slide" position={[0, -0.35, 0]} size={0.45} color="#7dd3fc" />}

        {/* stain dropper bottle */}
        <group position={[5.4, 0, 1.4]}>
          <mesh position={[0, 0.55, 0]} castShadow>
            <cylinderGeometry args={[0.35, 0.35, 1.1, 14]} />
            <meshStandardMaterial color={stain === "safranin" ? "#f472b6" : "#7c3aed"} roughness={0.35} />
          </mesh>
          <mesh position={[0, 1.3, 0]}>
            <cylinderGeometry args={[0.12, 0.2, 0.4, 10]} />
            <meshStandardMaterial color="#1e293b" roughness={0.4} />
          </mesh>
        </group>
        {showLabels && <Label text={`${stain} stain`} position={[5.4, 2.2, 1.4]} size={0.45} color="#d8b4fe" />}

        <Animator group={group} elapsed={elapsed} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
