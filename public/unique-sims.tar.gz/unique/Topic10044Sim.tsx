// Renal: urine concentration, micturition, acid-base — the bladder fills with
// yellow urine (ADH concentrates it), then voids through the urethra; a pH
// scale shows the kidney's acid-base balancing act.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "water", label: "Water intake", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "ph", label: "Blood pH", kind: "slider", min: 7.0, max: 7.8, step: 0.05, default: 7.4, unit: "" },
];

export const UNIQUE_META = {
  title: "Renal: Bladder, Micturition & pH",
  blurb: "The bladder fills and voids while the pH scale shows the kidney excreting acid or base to hold 7.4.",
};

function Animator({
  urineLevel, stream, detrusor, elapsed, water, speed,
}: {
  urineLevel: React.RefObject<THREE.Mesh>;
  stream: React.RefObject<THREE.Group>;
  detrusor: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  water: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const T = 16;
    const ph = (t / T) % 1;
    const fillRate = 0.25 + water * 0.75;
    // fill for 70% of cycle, void for 30%
    const fill = ph < 0.7 ? (ph / 0.7) * fillRate : fillRate * (1 - (ph - 0.7) / 0.3);
    const voiding = ph >= 0.7;
    if (urineLevel.current) {
      urineLevel.current.scale.y = Math.max(0.04, fill);
      urineLevel.current.position.y = -0.9 + fill * 0.9;
      const mat = urineLevel.current.material as THREE.MeshStandardMaterial;
      mat.color.set(water > 1.2 ? "#fef9c3" : water < 0.6 ? "#f59e0b" : "#fde047");
    }
    if (stream.current) {
      stream.current.children.forEach((m, i) => {
        const sp = ((t * 1.4 + i / 6) % 1 + 1) % 1;
        m.position.y = -1.6 - sp * 1.8;
        m.visible = voiding;
      });
    }
    if (detrusor.current) {
      const s = voiding ? 1 - 0.18 * Math.sin(((ph - 0.7) / 0.3) * Math.PI) : 1 + 0.06 * fill;
      detrusor.current.scale.set(s, 1 + (voiding ? -0.1 : 0.12 * fill), s);
    }
  });
  return null;
}

export function Topic10044Sim(props: SimProps) {
  const water = Number(props.water ?? 1);
  const ph = Number(props.ph ?? 7.4);
  const speed = 1;
  const urineLevel = useRef<THREE.Mesh>(null!);
  const stream = useRef<THREE.Group>(null!);
  const detrusor = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const kidneyAction = ph < 7.35 ? "excrete H⁺, reabsorb HCO₃⁻" : ph > 7.45 ? "excrete HCO₃⁻" : "balanced ✓";
  const actionColor = ph < 7.35 || ph > 7.45 ? "#fca5a5" : "#86efac";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Bladder", "filling → micturition reflex"],
          ["Kidney pH correction", kidneyAction],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5, 14]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* bladder: detrusor muscle shell + urine inside */}
        <group position={[-3.5, 0, 0]}>
          <mesh ref={detrusor} castShadow scale={[1, 1.1, 1]}>
            <sphereGeometry args={[1.5, 24, 24]} />
            <meshStandardMaterial color="#f43f5e" transparent opacity={0.5} roughness={0.45} />
          </mesh>
          <mesh ref={urineLevel} position={[0, -0.9, 0]}>
            <sphereGeometry args={[1.15, 20, 20]} />
            <meshStandardMaterial color="#fde047" transparent opacity={0.85} roughness={0.3} />
          </mesh>
          {/* ureters entering */}
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 1.7, 1.6, 0]} rotation={[0, 0, s * -0.5]} castShadow>
              <cylinderGeometry args={[0.16, 0.16, 2.2, 10]} />
              <meshStandardMaterial color="#fda4af" roughness={0.5} />
            </mesh>
          ))}
          {/* urethra */}
          <mesh position={[0, -2.2, 0]} castShadow>
            <cylinderGeometry args={[0.22, 0.22, 1.6, 10]} />
            <meshStandardMaterial color="#fb7185" roughness={0.5} />
          </mesh>
          {/* internal sphincter */}
          <mesh position={[0, -1.55, 0]}>
            <torusGeometry args={[0.3, 0.1, 8, 16]} />
            <meshStandardMaterial color="#9f1239" roughness={0.5} />
          </mesh>
        </group>
        {/* urine stream during voiding */}
        <group ref={stream}>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[-3.5, -1.6, 0]}>
              <sphereGeometry args={[0.12, 8, 8]} />
              <meshStandardMaterial color="#fde047" emissive="#a16207" emissiveIntensity={0.4} />
            </mesh>
          ))}
        </group>
        <Label text="bladder (detrusor muscle)" position={[-3.5, 2.6, 0]} size={0.4} color="#f8fafc" />
        <Label text="ureters in" position={[-5.9, 2.6, 0]} size={0.3} color="#fda4af" />
        <Label text="urethra — micturition" position={[-3.5, -3.4, 0]} size={0.32} color="#fde68a" />
        <Label text={water > 1.2 ? "dilute urine (lots of water)" : water < 0.6 ? "concentrated urine (ADH high)" : "normal concentration"}
          position={[-3.5, 3.6, 0]} size={0.3} color="#7dd3fc" />

        {/* pH scale */}
        <group position={[4.5, 0, 0]}>
          <mesh position={[0, 1.8, 0]} castShadow>
            <boxGeometry args={[6.4, 0.5, 0.5]} />
            <meshStandardMaterial color="#1e293b" roughness={0.6} />
          </mesh>
          {[7.0, 7.2, 7.4, 7.6, 7.8].map((v, i) => {
            const x = -3.2 + (i / 4) * 6.4;
            const c = v < 7.35 ? "#f87171" : v > 7.45 ? "#38bdf8" : "#4ade80";
            return (
              <group key={v} position={[x, 1.8, 0]}>
                <mesh position={[0, 0.45, 0]}>
                  <boxGeometry args={[0.08, 0.4, 0.08]} />
                  <meshBasicMaterial color={c} />
                </mesh>
                <Label text={v.toFixed(1)} position={[0, 0.85, 0]} size={0.3} color={c} />
              </group>
            );
          })}
          {/* marker at current pH */}
          <mesh position={[-3.2 + ((ph - 7.0) / 0.8) * 6.4, 2.6, 0]}>
            <coneGeometry args={[0.18, 0.4, 4]} />
            <meshBasicMaterial color="#fef08a" />
          </mesh>
          {/* kidney response arrows */}
          <mesh position={[0, 0.7, 0]} castShadow scale={[1, 1.2, 1]}>
            <sphereGeometry args={[0.8, 18, 18]} />
            <meshStandardMaterial color="#b91c1c" roughness={0.45} />
          </mesh>
        </group>
        <Label text="blood pH — kidney corrects toward 7.4" position={[4.5, 3.6, 0]} size={0.36} color="#f8fafc" />
        <Label text={kidneyAction} position={[4.5, -0.6, 0]} size={0.34} color={actionColor} />

        <Animator urineLevel={urineLevel} stream={stream} detrusor={detrusor}
          elapsed={elapsed} water={water} speed={speed} />
      </SimCanvas>
    </div>
  );
}
