"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "phase", label: "Remodeling phase", kind: "select", min: 0, max: 0, step: 1, default: "balanced", options: ["balanced", "resorption", "formation"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Alveolar bone: structure and remodeling",
  blurb: "Bone is alive — osteoclasts chew it away while osteoblasts rebuild it. Tip the balance and watch the socket gain or lose bone.",
};

const INFO: Record<string, { note: string; color: string }> = {
  balanced: { note: "Resorption = formation — socket stays stable", color: "#e7e5e4" },
  resorption: { note: "Osteoclasts win — bone melts away (periodontitis, disuse)", color: "#f87171" },
  formation: { note: "Osteoblasts win — bone builds up (orthodontic tension side)", color: "#4ade80" },
};

// deterministic pseudo-random positions for cell dots
function cellSpots(n: number, seed: number) {
  const arr: [number, number, number][] = [];
  let s = seed;
  const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  for (let i = 0; i < n; i++) {
    const a = rnd() * Math.PI * 2;
    const r = 1.7 + rnd() * 0.7;
    arr.push([Math.cos(a) * r, -2.6 + rnd() * 3.4, Math.sin(a) * r]);
  }
  return arr;
}

function RemodelScene({ phase, speed, showLabels }: { phase: string; speed: number; showLabels: boolean }) {
  const wall = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const info = INFO[phase] ?? INFO.balanced;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (wall.current) {
      const target = phase === "resorption" ? 1.35 : phase === "formation" ? 0.82 : 1;
      const s = THREE.MathUtils.lerp(wall.current.scale.x, target, 0.03);
      wall.current.scale.set(s, 1, s);
      // breathing shimmer
      (wall.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.12 + Math.sin(elapsed.current * 2) * 0.06;
    }
  });

  const blasts = cellSpots(10, 7);
  const clasts = cellSpots(10, 42);

  return (
    <group>
      {/* socket wall — grows/shrinks with remodeling balance */}
      <mesh ref={wall} position={[0, -0.9, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[2.2, 2.0, 3.6, 28, 1, true]} />
        <meshStandardMaterial color={info.color} roughness={0.7} side={THREE.DoubleSide} emissive={phase === "balanced" ? "#000000" : phase === "resorption" ? "#7f1d1d" : "#14532d"} emissiveIntensity={0.12} />
      </mesh>
      {/* trabecular struts */}
      {Array.from({ length: 8 }).map((_, i) => {
        const a = (i / 8) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 2.9, -0.9 + (i % 3) * 0.8 - 0.8, Math.sin(a) * 2.9]} rotation={[0, -a, 0.5]} castShadow>
            <boxGeometry args={[1.6, 0.28, 0.28]} />
            <meshStandardMaterial color="#d6d3d1" roughness={0.8} />
          </mesh>
        );
      })}
      {/* tooth in socket */}
      <mesh position={[0, 1.6, 0]} castShadow>
        <boxGeometry args={[1.7, 1.5, 1.6]} />
        <meshStandardMaterial color="#fef9c3" roughness={0.25} />
      </mesh>
      <mesh position={[0, -1.2, 0]} castShadow>
        <cylinderGeometry args={[1.0, 0.35, 4.2, 16]} />
        <meshStandardMaterial color="#fdba74" roughness={0.5} />
      </mesh>

      {/* osteoblasts (blue builders) crawling on wall */}
      {blasts.map((p, i) => (
        <Cell key={"b" + i} pos={p} color="#60a5fa" speed={speed} active={phase !== "resorption"} />
      ))}
      {/* osteoclasts (red eaters) */}
      {clasts.map((p, i) => (
        <Cell key={"c" + i} pos={p} color="#ef4444" speed={speed} active={phase !== "formation"} />
      ))}

      {showLabels && (
        <>
          <Text position={[4.4, 1.2, 0]} fontSize={0.42} color="#60a5fa">Osteoblasts — build bone</Text>
          <Text position={[4.4, 0.2, 0]} fontSize={0.42} color="#f87171">Osteoclasts — resorb bone</Text>
          <Text position={[-4.4, -0.9, 0]} fontSize={0.42} color="#e7e5e4">Alveolar socket wall</Text>
          <Text position={[0, 4.3, 0]} fontSize={0.44} color="#fef3c7" maxWidth={10}>{info.note}</Text>
        </>
      )}
    </group>
  );
}

function Cell({ pos, color, speed, active }: { pos: [number, number, number]; color: string; speed: number; active: boolean }) {
  const m = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(Math.random() * 10);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (m.current) {
      m.current.position.y = pos[1] + Math.sin(elapsed.current * 2 + pos[0]) * 0.12;
      const s = active ? 1 : 0.55;
      m.current.scale.setScalar(THREE.MathUtils.lerp(m.current.scale.x, s, 0.05));
    }
  });
  return (
    <mesh ref={m} position={pos}>
      <sphereGeometry args={[0.16, 12, 10]} />
      <meshStandardMaterial color={color} roughness={0.4} emissive={color} emissiveIntensity={active ? 0.5 : 0.05} />
    </mesh>
  );
}

export function Topic10379Sim(props: SimProps) {
  const phase = String(props.phase ?? "balanced");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Phase", phase],
          ["Turnover", "~10% of bone / year"],
          ["Socket", phase === "resorption" ? "widening ⚠" : phase === "formation" ? "filling in ✓" : "stable"],
        ]}
      />
      <SimCanvas cameraPosition={[7.5, 3.5, 9]} target={[0, -0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.4, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <RemodelScene phase={phase} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
