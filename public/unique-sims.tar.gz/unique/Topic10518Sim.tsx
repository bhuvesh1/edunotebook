// app/components/sims/unique/Topic10518Sim.tsx
// Ulcerative lesions: aphthous (round, yellow base, red halo), traumatic
// (irregular, near a sharp tooth), and infective (multiple small ulcers).

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ulcer", label: "Ulcer type", kind: "select", min: 0, max: 0, step: 1, default: "aphthous", options: ["aphthous", "traumatic", "infective"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Ulcerative Lesions: Aphthous, Traumatic, Infective",
  blurb: "Three ulcer stories: the classic canker sore, a bite from a sharp tooth, and a crop of infective ulcers.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ sore, elapsed, speed }: {
  sore: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (sore.current) sore.current.scale.setScalar(1 + 0.08 * Math.sin(elapsed.current * 3));
  });
  return null;
}

function UlcerDisc({ p, r, rot }: { p: [number, number, number]; r: number; rot?: [number, number, number] }) {
  return (
    <group position={p} rotation={rot ?? [0, 0, 0]}>
      {/* red halo */}
      <mesh>
        <circleGeometry args={[r * 1.5, 20]} />
        <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.35} roughness={0.7} side={THREE.DoubleSide} />
      </mesh>
      {/* yellow fibrin base */}
      <mesh position={[0, 0, 0.012]}>
        <circleGeometry args={[r, 20]} />
        <meshStandardMaterial color="#fde68a" roughness={0.85} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}

const INFO: Record<string, { name: string; clue: string; care: string }> = {
  aphthous: { name: "Aphthous ulcer (canker sore)", clue: "round, yellow base + red halo", care: "heals in 7–10 days" },
  traumatic: { name: "Traumatic ulcer", clue: "irregular, next to sharp tooth", care: "remove the cause — smooth the tooth" },
  infective: { name: "Infective ulcers", clue: "multiple small ulcers, fever", care: "treat the infection" },
};

export function Topic10518Sim(props: SimProps) {
  const ulcer = String(props.ulcer ?? "aphthous");
  const speed = Number(props.speed ?? 1);
  const sore = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = INFO[ulcer] ?? INFO.aphthous;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Type", info.name],
          ["Clue", info.clue],
          ["Care", info.care],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.6, 10]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* face + open mouth */}
        <mesh position={[0, 2.6, -0.8]} castShadow>
          <sphereGeometry args={[2.6, 32, 32]} />
          <meshStandardMaterial color="#f0b98d" roughness={0.7} />
        </mesh>
        <mesh position={[0, 2.4, 1.2]}>
          <sphereGeometry args={[1.35, 24, 24]} />
          <meshStandardMaterial color="#5b1a1a" roughness={0.9} />
        </mesh>
        <mesh position={[0, 2.4, 1.55]} scale={[1.35, 0.85, 0.6]} castShadow>
          <torusGeometry args={[1.05, 0.28, 14, 32]} />
          <meshStandardMaterial color="#e0788a" roughness={0.55} />
        </mesh>
        {/* tongue */}
        <mesh position={[0, 1.85, 1.5]} scale={[1, 0.45, 1.15]} castShadow>
          <sphereGeometry args={[0.85, 24, 24]} />
          <meshStandardMaterial color="#e0607a" roughness={0.55} />
        </mesh>
        {/* inner lip */}
        <mesh position={[0, 2.9, 1.9]} scale={[1.6, 0.7, 0.5]}>
          <sphereGeometry args={[0.8, 20, 20]} />
          <meshStandardMaterial color="#d96a7f" roughness={0.6} />
        </mesh>

        <group ref={sore}>
          {ulcer === "aphthous" && (
            <UlcerDisc p={[0.3, 2.95, 2.15]} r={0.28} rot={[-0.3, 0, 0]} />
          )}
          {ulcer === "traumatic" && (
            <>
              {/* sharp broken tooth */}
              <mesh position={[0.85, 3.0, 1.6]} castShadow>
                <coneGeometry args={[0.18, 0.55, 4]} />
                <meshStandardMaterial color="#ffffff" roughness={0.3} />
              </mesh>
              <Label p={[1.7, 3.35, 1.6]} size={0.26} color="#fde68a">sharp tooth edge</Label>
              {/* irregular ulcer hugging it */}
              <group position={[0.55, 2.85, 2.0]} rotation={[-0.3, -0.3, 0.4]}>
                <mesh>
                  <circleGeometry args={[0.4, 7]} />
                  <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.3} roughness={0.7} side={THREE.DoubleSide} />
                </mesh>
                <mesh position={[0, 0, 0.012]}>
                  <circleGeometry args={[0.26, 7]} />
                  <meshStandardMaterial color="#fde68a" roughness={0.85} side={THREE.DoubleSide} />
                </mesh>
              </group>
            </>
          )}
          {ulcer === "infective" && (
            <>
              <UlcerDisc p={[-0.5, 2.9, 2.1]} r={0.16} rot={[-0.3, 0.2, 0]} />
              <UlcerDisc p={[0.1, 2.75, 2.2]} r={0.13} rot={[-0.3, -0.1, 0]} />
              <UlcerDisc p={[0.6, 2.95, 2.05]} r={0.15} rot={[-0.3, -0.3, 0]} />
              <UlcerDisc p={[-0.1, 2.2, 2.1]} r={0.14} rot={[-0.4, 0, 0]} />
              <UlcerDisc p={[0.45, 2.05, 2.15]} r={0.12} rot={[-0.4, -0.2, 0]} />
            </>
          )}
        </group>

        <Label p={[2.6, 2.5, 1.6]} size={0.3} color="#fde68a">{info.name}</Label>
        <Label p={[0, 4.9, 0.5]} size={0.3} color="#e2e8f0">painful ulcer — {info.clue}</Label>

        <Animator sore={sore} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
