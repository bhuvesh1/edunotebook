"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "grit", label: "Abrasive grit", kind: "select", min: 0, max: 0, step: 1, default: "medium", options: ["coarse", "medium", "fine", "polish"] },
  { key: "rpm", label: "Handpiece speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Finishing and polishing materials, abrasives",
  blurb: "Spin the polishing wheel against the crown — go from coarse grinding scratches to a mirror shine, grit by grit.",
};

const GRITS: Record<string, { name: string; color: string; rough: string; shine: number }> = {
  coarse: { name: "Coarse diamond", color: "#78716c", rough: "rough — shapes fast", shine: 0.15 },
  medium: { name: "Medium bur", color: "#a8a29e", rough: "smooths the shape", shine: 0.35 },
  fine: { name: "Fine abrasive", color: "#d6d3d1", rough: "removes scratches", shine: 0.6 },
  polish: { name: "Polishing paste", color: "#fef9c3", rough: "mirror shine ✨", shine: 0.95 },
};

function PolishScene({ grit, rpm, speed, showLabels }: { grit: string; rpm: number; speed: number; showLabels: boolean }) {
  const wheel = useRef<THREE.Group>(null!);
  const crown = useRef<THREE.Mesh>(null!);
  const sparks = useRef<THREE.Points>(null!);
  const elapsed = useRef(0);
  const cfg = GRITS[grit] ?? GRITS.medium;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (wheel.current) wheel.current.rotation.x = elapsed.current * 14 * rpm;
    if (crown.current) {
      const m = crown.current.material as THREE.MeshStandardMaterial;
      m.roughness = THREE.MathUtils.lerp(m.roughness, 1 - cfg.shine, 0.03);
    }
    if (sparks.current) {
      sparks.current.visible = rpm > 0.1;
      const p = sparks.current.geometry.attributes.position;
      for (let i = 0; i < p.count; i++) {
        let y = p.getY(i) - delta * speed * 2;
        let x = p.getX(i) + (Math.random() - 0.5) * delta * 4;
        if (y < -1.5) { y = 1; x = (Math.random() - 0.5) * 0.6; }
        p.setY(i, y); p.setX(i, x);
      }
      p.needsUpdate = true;
      (sparks.current.material as THREE.PointsMaterial).size = grit === "coarse" ? 0.14 : grit === "medium" ? 0.1 : 0.06;
    }
  });

  return (
    <group>
      {/* crown being finished */}
      <group position={[-2.2, 0.4, 0]}>
        <mesh ref={crown} castShadow>
          <cylinderGeometry args={[1.1, 1.25, 1.6, 22, 1, true]} />
          <meshStandardMaterial color="#fef9c3" roughness={0.85} metalness={0.1} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[0, 0.8, 0]} castShadow>
          <sphereGeometry args={[1.1, 22, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
          <meshStandardMaterial color="#fef9c3" roughness={0.85} metalness={0.1} />
        </mesh>
        {/* scratch lines fade with finer grits */}
        {grit !== "polish" &&
          [-0.4, 0, 0.4].map((y, i) => (
            <mesh key={i} position={[0, y, 1.18]} rotation={[0, 0, 0.4 * i]}>
              <planeGeometry args={[1.6, 0.05]} />
              <meshBasicMaterial color="#a8a29e" transparent opacity={grit === "coarse" ? 0.8 : 0.35} />
            </mesh>
          ))}
      </group>

      {/* handpiece + wheel */}
      <group position={[1.6, 1.2, 0]} rotation={[0, 0, -0.35]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.35, 0.45, 2.6, 14]} />
          <meshStandardMaterial color="#0ea5e9" roughness={0.35} />
        </mesh>
        <group ref={wheel} position={[0, -1.7, 0]}>
          {/* abrasive wheel */}
          <mesh castShadow rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[1.15, 1.15, 0.35, 28]} />
            <meshStandardMaterial color={cfg.color} roughness={0.9} />
          </mesh>
          {/* grit dots on wheel face */}
          {Array.from({ length: 14 }).map((_, i) => {
            const a = (i / 14) * Math.PI * 2;
            return (
              <mesh key={i} position={[Math.cos(a) * 0.8, 0, Math.sin(a) * 0.8]}>
                <sphereGeometry args={[0.09, 8, 8]} />
                <meshBasicMaterial color={grit === "coarse" ? "#44403c" : "#e7e5e4"} />
              </mesh>
            );
          })}
        </group>
      </group>

      {/* sparks / paste flecks */}
      <points ref={sparks} position={[0.6, 0.6, 0]}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[new Float32Array(Array.from({ length: 40 }, () => [(Math.random() - 0.5) * 0.6, Math.random() * 2.5 - 1.5, (Math.random() - 0.5) * 0.6]).reduce((a, b) => a.concat(b), [] as number[])), 3]} />
        </bufferGeometry>
        <pointsMaterial color="#fde68a" size={0.1} transparent opacity={0.9} />
      </points>

      {showLabels && (
        <>
          <Text position={[-2.2, 2.8, 0]} fontSize={0.44} color="#fef3c7">Crown — {cfg.rough}</Text>
          <Text position={[3.4, 3.2, 0]} fontSize={0.42} color="#7dd3fc">{cfg.name} wheel</Text>
          <Text position={[0, -3.2, 0]} fontSize={0.42} color="#e2e8f0" maxWidth={10}>
            Sequence: coarse → medium → fine → polish. Never skip grits!
          </Text>
        </>
      )}
    </group>
  );
}

export function Topic10398Sim(props: SimProps) {
  const grit = String(props.grit ?? "medium");
  const rpm = Number(props.rpm ?? 1);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = GRITS[grit] ?? GRITS.medium;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Abrasive", cfg.name],
          ["Surface", cfg.rough],
          ["Shine", `${Math.round(cfg.shine * 100)}%`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <PolishScene grit={grit} rpm={rpm} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
