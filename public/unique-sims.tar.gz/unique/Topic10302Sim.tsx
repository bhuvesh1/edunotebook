// Bone tumors: benign and malignant — osteosarcoma, Ewing's.
// A tumor erupts from the bone: osteosarcoma's sunburst of bony spicules, or
// Ewing's onion-skin layers. The mass grows as you raise the growth rate.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "type", label: "Tumor type", kind: "select", min: 0, max: 0, step: 1, default: "osteosarcoma", options: ["osteosarcoma", "ewings", "benign"] },
  { key: "growth", label: "Growth rate", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Bone Tumors: Osteosarcoma & Ewing's",
  blurb: "A lump erupts from bone — sunburst spikes of osteosarcoma, onion-skin layers of Ewing's, or a harmless benign bump.",
};

function Animator({
  group, tumor, spicules, elapsed, growth, type,
}: {
  group: React.RefObject<THREE.Group>;
  tumor: React.RefObject<THREE.Mesh>;
  spicules: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  growth: number;
  type: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * growth;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // tumor grows in pulsing waves, capped
    if (tumor.current) {
      const g = Math.min(1.6, 0.55 + (t % 12) * 0.09);
      tumor.current.scale.set(g, g * 0.85, g);
      (tumor.current.material as THREE.MeshStandardMaterial).emissiveIntensity =
        type === "benign" ? 0.1 : 0.35 + 0.3 * Math.sin(t * 4);
    }
    if (spicules.current) {
      spicules.current.visible = type === "osteosarcoma";
      spicules.current.children.forEach((s, i) => {
        (s as THREE.Mesh).scale.setScalar(1 + 0.2 * Math.sin(t * 3 + i * 1.9));
      });
    }
  });
  return null;
}

export function Topic10302Sim(props: SimProps) {
  const type = String(props.type ?? "osteosarcoma");
  const growth = Number(props.growth ?? 1);
  const group = useRef<THREE.Group>(null!);
  const tumor = useRef<THREE.Mesh>(null!);
  const spicules = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    osteosarcoma: "Osteosarcoma (malignant)", ewings: "Ewing's sarcoma", benign: "Benign (osteochondroma)",
  };
  const tumorColor = type === "benign" ? "#fbbf24" : type === "ewings" ? "#c084fc" : "#dc2626";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Tumor", names[type] ?? type], ["Growth", `${growth.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* femur with the tumor at its lower end (classic spot) */}
          <mesh position={[0, 3.3, 0]} castShadow>
            <cylinderGeometry args={[0.32, 0.34, 2.2, 16]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <mesh position={[0, 1.75, 0]} castShadow>
            <cylinderGeometry args={[0.34, 0.42, 1.4, 16]} />
            <meshStandardMaterial color={type === "benign" ? "#f8fafc" : "#fecaca"} roughness={0.5} />
          </mesh>
          {/* the tumor mass */}
          <mesh ref={tumor} position={[0.45, 1.75, 0.15]} castShadow>
            <icosahedronGeometry args={[0.55, 1]} />
            <meshStandardMaterial color={tumorColor} roughness={0.45} emissive={type === "benign" ? "#92400e" : "#7f1d1d"} emissiveIntensity={0.4} flatShading />
          </mesh>
          {/* sunburst spicules (osteosarcoma) */}
          <group ref={spicules} visible={false} position={[0.45, 1.75, 0.15]}>
            {Array.from({ length: 14 }).map((_, i) => {
              const a = (i / 14) * Math.PI * 2;
              return (
                <mesh key={i} position={[Math.cos(a) * 0.75, Math.sin(a) * 0.65, Math.sin(a * 2) * 0.3]}
                  rotation={[0, 0, a - Math.PI / 2]} castShadow>
                  <coneGeometry args={[0.07, 0.55, 6]} />
                  <meshStandardMaterial color="#e2e8f0" roughness={0.5} flatShading />
                </mesh>
              );
            })}
          </group>
          {/* onion-skin layers (Ewing's) */}
          {type === "ewings" && (
            <>
              {[0.85, 1.05, 1.25].map((r, i) => (
                <mesh key={i} position={[0.45, 1.75, 0.15]} castShadow>
                  <torusGeometry args={[r, 0.05, 8, 28]} />
                  <meshStandardMaterial color="#c084fc" roughness={0.5} transparent opacity={0.7 - i * 0.15} />
                </mesh>
              ))}
            </>
          )}
          {/* benign: smooth cap of cartilage */}
          {type === "benign" && (
            <mesh position={[0.45, 2.35, 0.15]} scale={[1, 0.5, 1]} castShadow>
              <sphereGeometry args={[0.4, 16, 12]} />
              <meshStandardMaterial color="#7dd3fc" roughness={0.3} transparent opacity={0.85} />
            </mesh>
          )}
          <Label text="Femur" position={[-1.7, 3.5, 0]} size={0.5} color="#f8fafc" />
          <Label text={type === "osteosarcoma" ? "⚠ Sunburst = cancer" : type === "ewings" ? "⚠ Onion-skin = Ewing's" : "Smooth benign bump"} position={[0.45, 0.55, 0.15]} size={0.55} color={type === "benign" ? "#fde68a" : "#fca5a5"} />
        </group>
        <Animator group={group} tumor={tumor} spicules={spicules} elapsed={elapsed} growth={growth} type={type} />
      </SimCanvas>
    </div>
  );
}
