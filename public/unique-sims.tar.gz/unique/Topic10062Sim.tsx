"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "subs", label: "Substrate molecules", kind: "slider", min: 1, max: 5, step: 1, default: 3 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Enzyme Action: Lock and Key",
  blurb: "Substrate molecules dock into the enzyme active site and leave as products, in a looping catalytic cycle.",
};

function Animator({ root, parts, site, elapsed, speed, subs }: { root: RefObject<THREE.Group>; parts: RefObject<THREE.Group>; site: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; subs: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (root.current) root.current.rotation.y = Math.sin(t * 0.3) * 0.15;
    let docked = false;
    if (parts.current) {
      for (let i = 0; i < subs; i++) {
        const sub = parts.current.children[i * 3];
        const pa = parts.current.children[i * 3 + 1];
        const pb = parts.current.children[i * 3 + 2];
        const p = (t * 0.22 + i / subs) % 1;
        if (p < 0.35) {
          const x = 6 - (p / 0.35) * 6;
          sub.position.set(x, 1.6, 0); sub.visible = true;
          pa.visible = false; pb.visible = false; sub.scale.setScalar(1);
        } else if (p < 0.55) {
          sub.position.set(0, 1.6, 0); sub.visible = true;
          pa.visible = false; pb.visible = false;
          sub.scale.setScalar(1 + 0.3 * Math.abs(Math.sin(t * 18)));
          docked = true;
        } else {
          const q = (p - 0.55) / 0.45;
          sub.visible = false; pa.visible = true; pb.visible = true;
          pa.position.set(q * 4.5, 1.6 + q * 2.4, 0);
          pb.position.set(q * 4.5, 1.6 - q * 2.4, 0);
        }
      }
    }
    if (site.current) {
      const m = site.current.material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = docked ? 2.4 : 0.5;
    }
  });
  return null;
}

export function Topic10062Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const subs = Math.round(Number(props.subs ?? 3));
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const parts = useRef<THREE.Group>(null!);
  const site = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Model", "lock-and-key"],
          ["Complex", "enzyme\u2013substrate (ES)"],
          ["Kinetics", "Michaelis\u2013Menten"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.6, 11]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 2.55, 0]} castShadow>
            <sphereGeometry args={[1.0, 24, 24]} /><meshStandardMaterial color="#8b5cf6" roughness={0.45} />
          </mesh>
          <mesh position={[0, 0.65, 0]} castShadow>
            <sphereGeometry args={[1.0, 24, 24]} /><meshStandardMaterial color="#8b5cf6" roughness={0.45} />
          </mesh>
          <mesh ref={site} position={[0, 1.6, 0]}>
            <sphereGeometry args={[0.3, 16, 16]} />
            <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={0.5} />
          </mesh>
          <group ref={parts}>
            {Array.from({ length: subs }).map((_, i) => (
              <group key={i}>
                <mesh position={[6, 1.6, 0]} castShadow>
                  <sphereGeometry args={[0.42, 20, 20]} /><meshStandardMaterial color="#fb923c" roughness={0.35} />
                </mesh>
                <mesh visible={false}><sphereGeometry args={[0.3, 16, 16]} /><meshStandardMaterial color="#22d3ee" roughness={0.35} /></mesh>
                <mesh visible={false}><sphereGeometry args={[0.3, 16, 16]} /><meshStandardMaterial color="#22d3ee" roughness={0.35} /></mesh>
              </group>
            ))}
          </group>
          <Label text="enzyme" position={[-2.2, 3.4, 0]} color="#a78bfa" />
          <Label text="active site" position={[0, 0.35, 0]} size={0.42} color="#fbbf24" />
          <Label text="substrate" position={[4.6, 2.7, 0]} size={0.45} color="#fb923c" />
          <Label text="products" position={[4.6, 0.4, 0]} size={0.45} color="#22d3ee" />
        </group>
        <Animator root={root} parts={parts} site={site} elapsed={elapsed} speed={speed} subs={subs} />
      </SimCanvas>
    </div>
  );
}
