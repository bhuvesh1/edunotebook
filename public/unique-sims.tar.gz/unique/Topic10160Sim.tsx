"use client";
// Toxicology: general principles — corrosives & irritants.
// Three labelled poison bottles (acid, alkali, irritant) with bubbling
// liquid; pick one to see its colour code and first-aid rule.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "poison", label: "Poison", kind: "select", min: 0, max: 0, step: 1, default: "acid", options: ["acid", "alkali", "irritant"] },
  { key: "speed", label: "Bubble speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Toxicology: Corrosives & Irritants",
  blurb: "Three poison bottles bubble away — pick one and learn its warning colour and the first rule of first aid.",
};

const POISONS: Record<string, { color: string; liquid: string; aid: string; label: string }> = {
  acid: { color: "#ef4444", liquid: "#fca5a5", aid: "Do NOT induce vomiting", label: "CORROSIVE ACID" },
  alkali: { color: "#3b82f6", liquid: "#93c5fd", aid: "Do NOT induce vomiting", label: "CORROSIVE ALKALI" },
  irritant: { color: "#f59e0b", liquid: "#fcd34d", aid: "Wash skin, call doctor", label: "IRRITANT" },
};

function Animator({ bubbles, elapsed, speed }: { bubbles: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (bubbles.current) {
      bubbles.current.children.forEach((b, i) => {
        const ph = (elapsed.current * 0.5 + i * 0.13) % 1;
        b.position.y = 0.7 + ph * 1.5;
        const s = 0.5 + ph * 0.8;
        b.scale.set(s, s, s);
      });
    }
  });
  return null;
}

function Bottle({ x, active, info, label, bubbles, bubRef }: { x: number; active: boolean; info: { color: string; liquid: string }; label: string; bubbles: React.ReactNode; bubRef?: React.RefObject<THREE.Group> }) {
  return (
    <group position={[x, 0, 0]}>
      <mesh position={[0, 1.5, 0]} castShadow>
        <cylinderGeometry args={[0.85, 0.85, 2.2, 18]} />
        <meshStandardMaterial color="#e2e8f0" transparent opacity={0.35} roughness={0.15} />
      </mesh>
      <mesh position={[0, 1.25, 0]}>
        <cylinderGeometry args={[0.72, 0.72, 1.5, 18]} />
        <meshStandardMaterial color={info.liquid} transparent opacity={0.85} roughness={0.3} />
      </mesh>
      <mesh position={[0, 2.9, 0]} castShadow>
        <cylinderGeometry args={[0.3, 0.3, 0.6, 12]} />
        <meshStandardMaterial color="#94a3b8" roughness={0.5} />
      </mesh>
      <mesh position={[0, 3.3, 0]}>
        <cylinderGeometry args={[0.36, 0.36, 0.25, 12]} />
        <meshStandardMaterial color="#475569" roughness={0.6} />
      </mesh>
      {/* hazard diamond */}
      <mesh position={[0, 1.6, 0.88]} rotation={[0, 0, Math.PI / 4]}>
        <boxGeometry args={[0.55, 0.55, 0.04]} />
        <meshStandardMaterial color={info.color} emissive={info.color} emissiveIntensity={active ? 0.9 : 0.25} />
      </mesh>
      {bubbles}
      <Label text={label} position={[0, 0.25, 0]} size={0.5} color={active ? info.color : "#94a3b8"} />
      {active && (
        <mesh position={[0, 1.5, 0]}>
          <torusGeometry args={[1.15, 0.07, 8, 28]} />
          <meshStandardMaterial color={info.color} emissive={info.color} emissiveIntensity={0.8} />
        </mesh>
      )}
    </group>
  );
}

export function Topic10160Sim(props: SimProps) {
  const poison = String(props.poison ?? "acid");
  const speed = Number(props.speed ?? 1);
  const bubbles = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = POISONS[poison] ?? POISONS.acid;

  const dots = useMemo(
    () =>
      Array.from({ length: 9 }, (_, i) => (
        <mesh key={i} position={[(Math.sin(i * 7.3) * 0.4), 0.7 + (i / 9) * 1.5, Math.cos(i * 5.1) * 0.4]}>
          <sphereGeometry args={[0.11, 8, 8]} />
          <meshStandardMaterial color="#ffffff" transparent opacity={0.8} roughness={0.2} />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Poison", info.label], ["First aid", info.aid]]} />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <mesh position={[0, 0.15, 0]} receiveShadow>
          <boxGeometry args={[11, 0.3, 3.4]} />
          <meshStandardMaterial color="#1e293b" roughness={0.8} />
        </mesh>
        {(Object.keys(POISONS) as string[]).map((k, i) => (
          <Bottle
            key={k}
            x={(i - 1) * 3.6}
            active={k === poison}
            info={POISONS[k]}
            label={POISONS[k].label}
            bubbles={k === poison ? <group ref={bubbles}>{dots}</group> : null}
          />
        ))}
        <Label text={info.aid} position={[0, 4.6, 0]} size={0.65} color="#fbbf24" />
        <Animator bubbles={bubbles} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
