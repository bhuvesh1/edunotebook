// Reproductive: female cycle, pregnancy, lactation — a 28-day cycle dial: the
// endometrium thickens, an egg bursts from the ovary at day 14, and the
// uterus either sheds or nurtures a growing embryo.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "day", label: "Cycle day", kind: "slider", min: 1, max: 28, step: 1, default: 14, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Reproductive: The 28-Day Cycle",
  blurb: "Slide through the cycle: follicles grow, ovulation bursts at day 14, the endometrium thickens — then decides.",
};

function Animator({
  follicle, eggBurst, flow, embryo, elapsed, day, speed,
}: {
  follicle: React.RefObject<THREE.Mesh>;
  eggBurst: React.RefObject<THREE.Group>;
  flow: React.RefObject<THREE.Group>;
  embryo: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  day: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // follicle swells toward day 14
    if (follicle.current) {
      const swell = day <= 14 ? 0.5 + (day / 14) * 0.7 : Math.max(0.3, 1.2 - (day - 14) * 0.08);
      follicle.current.scale.setScalar(Math.max(0.25, swell));
    }
    // ovulation burst sparkles around day 13-15
    if (eggBurst.current) {
      const ov = day >= 13 && day <= 15;
      eggBurst.current.visible = ov;
      if (ov) {
        eggBurst.current.children.forEach((m, i) => {
          const a = (i / 8) * Math.PI * 2 + t * 2;
          m.position.set(Math.cos(a) * (0.5 + 0.3 * Math.sin(t * 4)), Math.sin(a) * (0.5 + 0.3 * Math.sin(t * 4)), 0);
        });
      }
    }
    // menstrual flow on days 1-5
    if (flow.current) {
      const men = day <= 5;
      flow.current.children.forEach((m, i) => {
        const ph = ((t * 0.8 + i / 6) % 1 + 1) % 1;
        m.position.y = 1.4 - ph * 2.6;
        m.visible = men;
      });
    }
    // embryo grows if "pregnant" (day > 21 held) — gentle pulse
    if (embryo.current) {
      embryo.current.visible = day >= 22;
      if (day >= 22) {
        const g = 0.5 + ((day - 21) / 7) * 0.7;
        embryo.current.scale.setScalar(g * (1 + 0.05 * Math.sin(t * 3)));
      }
    }
  });
  return null;
}

export function Topic10051Sim(props: SimProps) {
  const day = Number(props.day ?? 14);
  const speed = Number(props.speed ?? 1);
  const follicle = useRef<THREE.Mesh>(null!);
  const eggBurst = useRef<THREE.Group>(null!);
  const flow = useRef<THREE.Group>(null!);
  const embryo = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const phase = day <= 5 ? "menstrual" : day <= 13 ? "follicular (estrogen ↑)" : day <= 15 ? "OVULATION 🎯" : day <= 21 ? "early luteal (progesterone ↑)" : "late luteal — pregnant? or menses";
  const phaseColor = day >= 13 && day <= 15 ? "#fde68a" : "#f8fafc";
  // endometrium thickness follows the cycle
  const endoThick = day <= 5 ? 0.25 : day <= 14 ? 0.25 + (day / 14) * 0.75 : 1.0 - Math.max(0, (day - 21) / 7) * 0.35;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          [`Day ${day}`, phase],
          ["Endometrium", `${(endoThick * 8).toFixed(1)} mm`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* uterus */}
        <group position={[0, 0, 0]}>
          <mesh position={[0, 2.2, 0]} castShadow scale={[1.25, 1.5, 1]}>
            <sphereGeometry args={[1.15, 22, 22]} />
            <meshStandardMaterial color="#fb7185" transparent opacity={0.65} roughness={0.45} />
          </mesh>
          {/* endometrium lining: thickness follows cycle */}
          <mesh position={[0, 2.2, 0]} scale={[1.25 * endoThick + 0.15, 1.5 * endoThick + 0.1, 1 * endoThick + 0.1]}>
            <sphereGeometry args={[1.0, 20, 20]} />
            <meshStandardMaterial color="#fda4af" emissive="#9f1239" emissiveIntensity={0.35} roughness={0.4} />
          </mesh>
          {/* fallopian tubes */}
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 1.9, 3.1, 0]} rotation={[0, 0, s * -1.2]} castShadow>
              <cylinderGeometry args={[0.16, 0.16, 1.8, 10]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
            </mesh>
          ))}
          {/* cervix */}
          <mesh position={[0, 0.35, 0]} castShadow>
            <cylinderGeometry args={[0.35, 0.42, 0.9, 12]} />
            <meshStandardMaterial color="#f43f5e" roughness={0.5} />
          </mesh>
        </group>
        <Label text="uterus" position={[0, 4.5, 0]} size={0.42} color="#f8fafc" />
        <Label text="endometrium thickens →" position={[-3.4, 2.2, 0]} size={0.3} color="#fda4af" />

        {/* ovary with maturing follicle */}
        <group position={[-4.2, 3.0, 0]}>
          <mesh castShadow scale={[1.3, 1, 1]}>
            <sphereGeometry args={[0.85, 18, 18]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
          </mesh>
          <mesh ref={follicle} position={[0.35, 0.25, 0.5]}>
            <sphereGeometry args={[0.35, 14, 14]} />
            <meshStandardMaterial color="#fef3c7" emissive="#a16207" emissiveIntensity={0.5} roughness={0.4} />
          </mesh>
          {/* small antral follicles */}
          {[[-0.4, -0.2], [0.1, -0.4]].map(([x, y], i) => (
            <mesh key={i} position={[x, y, 0.55]}>
              <sphereGeometry args={[0.16, 10, 10]} />
              <meshStandardMaterial color="#fde68a" roughness={0.5} />
            </mesh>
          ))}
        </group>
        {/* ovulation burst */}
        <group ref={eggBurst} position={[-3.85, 3.25, 0.5]} visible={false}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[0, 0, 0]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshBasicMaterial color="#fef08a" />
            </mesh>
          ))}
        </group>
        <Label text="ovary — Graafian follicle" position={[-4.2, 4.5, 0]} size={0.36} color="#f8fafc" />

        {/* menstrual flow */}
        <group ref={flow}>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[0, 1.4, 0]}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshBasicMaterial color="#ef4444" />
            </mesh>
          ))}
        </group>

        {/* embryo if late luteal */}
        <group ref={embryo} position={[0, 2.2, 0]} visible={false}>
          <mesh castShadow>
            <sphereGeometry args={[0.5, 16, 16]} />
            <meshStandardMaterial color="#e879f9" roughness={0.4} />
          </mesh>
          <mesh>
            <sphereGeometry args={[0.68, 16, 16]} />
            <meshStandardMaterial color="#f0abfc" transparent opacity={0.3} roughness={0.3} />
          </mesh>
        </group>
        {day >= 22 && (
          <Label text="implanted embryo 🤰" position={[0, 1.0, 0]} size={0.34} color="#f0abfc" />
        )}

        {/* cycle dial */}
        <group position={[6.6, 2.4, 0]}>
          <mesh castShadow>
            <torusGeometry args={[1.4, 0.16, 10, 32]} />
            <meshStandardMaterial color="#475569" roughness={0.5} />
          </mesh>
          {Array.from({ length: 28 }).map((_, i) => {
            const a = Math.PI / 2 - (i / 28) * Math.PI * 2;
            const isDay = i + 1 === Math.round(day);
            return (
              <mesh key={i} position={[Math.cos(a) * 1.4, Math.sin(a) * 1.4, 0]}>
                <sphereGeometry args={[isDay ? 0.14 : 0.06, 8, 8]} />
                <meshBasicMaterial color={isDay ? "#fde047" : i < 5 ? "#ef4444" : i < 15 ? "#f9a8d4" : "#c084fc"} />
              </mesh>
            );
          })}
          {/* ovulation marker */}
          <mesh position={[Math.cos(Math.PI / 2 - (14 / 28) * Math.PI * 2) * 1.4, Math.sin(Math.PI / 2 - (14 / 28) * Math.PI * 2) * 1.4, 0]}>
            <sphereGeometry args={[0.1, 8, 8]} />
            <meshBasicMaterial color="#fef08a" />
          </mesh>
        </group>
        <Label text="28-day dial" position={[6.6, 4.4, 0]} size={0.36} color="#f8fafc" />
        <Label text={phase} position={[6.6, 0.5, 0]} size={0.32} color={phaseColor} />

        {/* lactation hint: prolactin */}
        <group position={[-7.4, 1.6, 0]}>
          <mesh castShadow scale={[1, 0.8, 1]}>
            <sphereGeometry args={[0.7, 16, 16]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.5} />
          </mesh>
          <mesh position={[0, -0.5, 0.3]}>
            <coneGeometry args={[0.18, 0.4, 10]} />
            <meshStandardMaterial color="#f0abfc" roughness={0.5} />
          </mesh>
        </group>
        <Label text="lactation: prolactin → milk" position={[-7.4, 2.9, 0]} size={0.3} color="#f0abfc" />

        <Animator follicle={follicle} eggBurst={eggBurst} flow={flow} embryo={embryo}
          elapsed={elapsed} day={day} speed={speed} />
      </SimCanvas>
    </div>
  );
}
