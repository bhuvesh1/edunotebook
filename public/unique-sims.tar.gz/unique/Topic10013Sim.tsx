"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "CSF flow speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Neuroanatomy: ventricular system, CSF circulation, blood supply of brain",
  blurb: "See-through brain with its fluid chambers: CSF flows from the lateral ventricles down through the 3rd and 4th.",
};

// waypoints of CSF circulation inside the brain
const PATH: [number, number, number][] = [
  [-0.7, 3.6, 0], [-0.35, 3.1, 0], [0, 2.75, 0],
  [0, 2.3, 0.15], [0, 1.9, -0.4], [0.5, 2.4, -0.9], [0.9, 3.2, -0.7], [0.4, 3.9, -0.3], [-0.4, 4.0, -0.2],
];

function Ventricles({ speed }: { speed: number }) {
  const drops = useRef<(THREE.Mesh | null)[]>([]);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d * speed;
    drops.current.forEach((m, i) => {
      if (!m) return;
      const k = ((t.current * 0.35 + i * 0.1) % 1) * (PATH.length - 1);
      const a = Math.floor(k), b = Math.min(a + 1, PATH.length - 1), f = k - a;
      m.position.set(
        PATH[a][0] + (PATH[b][0] - PATH[a][0]) * f,
        PATH[a][1] + (PATH[b][1] - PATH[a][1]) * f,
        PATH[a][2] + (PATH[b][2] - PATH[a][2]) * f
      );
    });
  });
  return (
    <group position={[0, 0.4, 0]}>
      {/* translucent cerebrum */}
      <mesh position={[0, 3.0, 0]} castShadow>
        <sphereGeometry args={[1.9, 28, 22]} />
        <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.28} />
      </mesh>
      {/* lateral ventricles (paired) */}
      {[-0.7, 0.7].map((x) => (
        <mesh key={x} position={[x * 0.9, 3.6, 0]} rotation={[0, 0, 0.3]}>
          <capsuleGeometry args={[0.22, 0.9, 6, 12]} />
          <meshStandardMaterial color="#22d3ee" emissive="#0e7490" emissiveIntensity={0.7} roughness={0.4} />
        </mesh>
      ))}
      {/* third ventricle */}
      <mesh position={[0, 2.75, 0]}>
        <boxGeometry args={[0.3, 0.5, 0.4]} />
        <meshStandardMaterial color="#22d3ee" emissive="#0e7490" emissiveIntensity={0.7} roughness={0.4} />
      </mesh>
      {/* fourth ventricle */}
      <mesh position={[0, 2.0, -0.3]} rotation={[0.4, 0, 0]}>
        <capsuleGeometry args={[0.2, 0.5, 6, 10]} />
        <meshStandardMaterial color="#22d3ee" emissive="#0e7490" emissiveIntensity={0.7} roughness={0.4} />
      </mesh>
      {/* cerebral aqueduct */}
      <mesh position={[0, 2.35, -0.05]} castShadow>
        <cylinderGeometry args={[0.08, 0.08, 0.5, 8]} />
        <meshStandardMaterial color="#67e8f9" roughness={0.4} />
      </mesh>
      {/* CSF droplets circulating */}
      {Array.from({ length: 10 }).map((_, i) => (
        <mesh key={i} ref={(m) => { drops.current[i] = m; }} position={[0, 3.6, 0]}>
          <sphereGeometry args={[0.1, 10, 10]} />
          <meshStandardMaterial color="#a5f3fc" emissive="#22d3ee" emissiveIntensity={1.8} />
        </mesh>
      ))}
      {/* blood supply: carotid hints */}
      {[-0.5, 0.5].map((x) => (
        <mesh key={x} position={[x, 0.9, 0.3]} castShadow>
          <cylinderGeometry args={[0.12, 0.12, 1.4, 10]} />
          <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={0.5} roughness={0.4} />
        </mesh>
      ))}
    </group>
  );
}

export function Topic10013Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Fluid", "CSF"], ["Route", "lateral → 3rd → 4th"], ["Supply", "carotid arteries"]]} />
      <SimCanvas cameraPosition={[5.5, 4, 10]} target={[0, 3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Ventricles speed={speed} />
        {showLabels && (
          <>
            <Label text="Lateral ventricles" position={[-3.0, 4.6, 0]} color="#a5f3fc" size={0.5} />
            <Label text="3rd ventricle" position={[2.6, 3.4, 0]} color="#a5f3fc" size={0.5} />
            <Label text="4th ventricle" position={[2.4, 2.2, -0.4]} color="#a5f3fc" size={0.5} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
