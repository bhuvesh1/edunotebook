// app/components/sims/unique/Topic7097Sim.tsx
// Area under the velocity–time graph: the yellow line is the car's
// constant velocity; the orange region filling in beneath it is the
// area v·t — and the car below travels exactly that far. Area = distance.

"use client";

import { useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "velocity", label: "Velocity", kind: "slider", min: 1, max: 6, step: 0.5, default: 3, unit: "m/s" },
];

export const UNIQUE_META = {
  title: "Area Under Velocity–Time Graph",
  blurb: "The orange area filling under the v–t line equals the distance the car travels. Area = distance.",
};

// Board-local plot frame.
const X0 = -3.4, Y0 = -2.3, W = 6.8, HGT = 3.6, VMAX = 6;

function Animator({
  car, vLine, shade, tip, velocity, state, bump,
}: {
  car: RefObject<THREE.Group>;
  vLine: RefObject<THREE.Mesh>;
  shade: RefObject<THREE.Mesh>;
  tip: RefObject<THREE.Mesh>;
  velocity: number;
  state: RefObject<{ t: number; area: number }>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const cycleT = 14 / velocity;
    const T = t.current % cycleT;
    const p = T / cycleT;
    const vh = (velocity / VMAX) * HGT;
    state.current = { t: T, area: velocity * T };
    if (car.current) car.current.position.x = -7 + T * velocity;
    if (vLine.current) vLine.current.position.y = Y0 + vh;
    if (shade.current) {
      shade.current.scale.x = Math.max(p * W, 0.001);
      shade.current.scale.y = Math.max(vh, 0.001);
      shade.current.position.set(X0 + (p * W) / 2, Y0 + vh / 2, 0.015);
    }
    if (tip.current) tip.current.position.set(X0 + p * W, Y0 + vh, 0.05);
    if (++n.current % 15 === 0) bump();
  });
  return null;
}

export function Topic7097Sim(props: SimProps) {
  const velocity = Number(props.velocity ?? 3);
  const car = useRef<THREE.Group>(null!);
  const vLine = useRef<THREE.Mesh>(null!);
  const shade = useRef<THREE.Mesh>(null!);
  const tip = useRef<THREE.Mesh>(null!);
  const state = useRef({ t: 0, area: 0 });
  const [, bump] = useState(0);

  const axes = useMemo(
    () =>
      new THREE.LineSegments(
        new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(X0, Y0, 0), new THREE.Vector3(X0 + W, Y0, 0),
          new THREE.Vector3(X0, Y0, 0), new THREE.Vector3(X0, Y0 + HGT, 0),
        ]),
        new THREE.LineBasicMaterial({ color: "#94a3b8" })
      ),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Area = v × t", `${state.current.area.toFixed(1)} m`],
          ["Car distance", `${state.current.area.toFixed(1)} m`],
          ["🟧 Orange", "area under the curve"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2.2, -1]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <mesh position={[0, 0.05, 3.2]} receiveShadow>
          <boxGeometry args={[20, 0.1, 2.4]} />
          <meshStandardMaterial color="#334155" roughness={0.9} />
        </mesh>

        <group position={[0, 3.5, -6.5]}>
          <mesh receiveShadow>
            <planeGeometry args={[8.6, 5.2]} />
            <meshStandardMaterial color="#16213a" roughness={0.9} />
          </mesh>
          <primitive object={axes} />
          {/* shaded area: unit plane scaled by animator */}
          <mesh ref={shade}>
            <planeGeometry args={[1, 1]} />
            <meshStandardMaterial color="#fb923c" transparent opacity={0.45} roughness={0.8} />
          </mesh>
          {/* velocity line */}
          <mesh ref={vLine}>
            <boxGeometry args={[W, 0.07, 0.02]} />
            <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.7} />
          </mesh>
          <mesh ref={tip}>
            <sphereGeometry args={[0.1, 12, 12]} />
            <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.9} />
          </mesh>
        </group>

        <group ref={car} position={[-7, 0, 3.2]}>
          <mesh position={[0, 0.72, 0]} castShadow>
            <boxGeometry args={[2.2, 0.66, 1.2]} />
            <meshStandardMaterial color="#a78bfa" roughness={0.35} metalness={0.4} />
          </mesh>
          <mesh position={[-0.15, 1.3, 0]} castShadow>
            <boxGeometry args={[1.1, 0.55, 1.0]} />
            <meshStandardMaterial color="#bae6fd" roughness={0.2} metalness={0.3} />
          </mesh>
          {[-0.75, 0.75].map((x) =>
            [-0.62, 0.62].map((z) => (
              <mesh key={`${x}${z}`} position={[x, 0.32, z]} rotation={[Math.PI / 2, 0, 0]}>
                <cylinderGeometry args={[0.32, 0.32, 0.18, 18]} />
                <meshStandardMaterial color="#111827" roughness={0.8} />
              </mesh>
            ))
          )}
        </group>

        <Animator
          car={car} vLine={vLine} shade={shade} tip={tip}
          velocity={velocity} state={state} bump={() => bump((v) => v + 1)}
        />
      </SimCanvas>
    </div>
  );
}
