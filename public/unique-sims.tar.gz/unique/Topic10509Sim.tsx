// app/components/sims/unique/Topic10509Sim.tsx
// Orthognathic surgery: side-view skull showing Le Fort I (upper jaw) and
// BSSO (lower jaw) osteotomy cut lines, with the segments sliding to their
// new positions.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "proc", label: "Procedure", kind: "select", min: 0, max: 0, step: 1, default: "lefort", options: ["lefort", "bsso"] },
  { key: "move", label: "Segment movement", kind: "slider", min: -1, max: 1, step: 0.05, default: 0.6, unit: "cm" },
];

export const UNIQUE_META = {
  title: "Orthognathic Surgery: Le Fort I & BSSO",
  blurb: "Osteotomy cut lines glow on the skull, then the jaw segment slides into its corrected position.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ seg, elapsed, move, proc }: {
  seg: RefObject<THREE.Group>; elapsed: RefObject<number>; move: number; proc: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (!seg.current) return;
    // oscillate gently around the target position so motion is visible
    const breathe = 0.06 * Math.sin(elapsed.current * 1.5);
    const target = move * 0.8;
    if (proc === "lefort") seg.current.position.x = target + breathe;
    else seg.current.position.x = target * 0.8 + breathe;
  });
  return null;
}

const BONE = "#e8dcc3";
const CUT = "#ef4444";

export function Topic10509Sim(props: SimProps) {
  const proc = String(props.proc ?? "lefort");
  const move = Number(props.move ?? 0.6);
  const seg = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const isLeFort = proc === "lefort";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Procedure", isLeFort ? "Le Fort I (maxilla)" : "BSSO (mandible)"],
          ["Movement", `${move > 0 ? "+" : ""}${move.toFixed(2)} cm ${move >= 0 ? "forward" : "back"}`],
          ["Fixation", "titanium plates + screws"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 12]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* cranium */}
        <mesh position={[-0.2, 3.7, 0]} castShadow>
          <sphereGeometry args={[1.45, 32, 32]} />
          <meshStandardMaterial color={BONE} roughness={0.6} />
        </mesh>
        {/* midface (fixed part) */}
        <mesh position={[0.5, 3.1, 0]} castShadow>
          <boxGeometry args={[1.5, 0.5, 1.1]} />
          <meshStandardMaterial color={BONE} roughness={0.6} />
        </mesh>

        {isLeFort ? (
          <>
            {/* Le Fort I cut line above the tooth roots */}
            <mesh position={[0.75, 2.62, 0]}>
              <boxGeometry args={[1.5, 0.07, 1.16]} />
              <meshStandardMaterial color={CUT} emissive={CUT} emissiveIntensity={1.2} />
            </mesh>
            {/* mobile maxillary segment */}
            <group ref={seg}>
              <mesh position={[0.75, 2.15, 0]} castShadow>
                <boxGeometry args={[1.5, 0.7, 1.1]} />
                <meshStandardMaterial color="#f5eeda" roughness={0.6} />
              </mesh>
              {[0.25, 0.55, 0.85, 1.15, 1.35].map((x, i) => (
                <mesh key={i} position={[x, 1.62, 0]} castShadow>
                  <boxGeometry args={[0.2, 0.35, 0.5]} />
                  <meshStandardMaterial color="#ffffff" roughness={0.3} />
                </mesh>
              ))}
            </group>
            <Label p={[0.75, 1.0, 0]} size={0.3} color="#fca5a5">maxilla slides as one piece</Label>
            <Label p={[-2.2, 2.62, 0]} size={0.28} color={CUT}>Le Fort I cut</Label>
          </>
        ) : (
          <>
            {/* mandible: fixed ramus part */}
            <mesh position={[-0.75, 2.2, 0]} castShadow>
              <boxGeometry args={[0.6, 1.6, 0.8]} />
              <meshStandardMaterial color={BONE} roughness={0.6} />
            </mesh>
            {/* BSSO sagittal split line on ramus */}
            <mesh position={[-0.45, 2.2, 0.42]} rotation={[0, 0, 0.5]}>
              <boxGeometry args={[0.07, 1.3, 0.02]} />
              <meshStandardMaterial color={CUT} emissive={CUT} emissiveIntensity={1.2} />
            </mesh>
            {/* mobile distal segment */}
            <group ref={seg}>
              <mesh position={[0.75, 1.75, 0]} castShadow>
                <boxGeometry args={[2.2, 0.6, 0.8]} />
                <meshStandardMaterial color="#f5eeda" roughness={0.6} />
              </mesh>
              <mesh position={[1.85, 1.9, 0]} castShadow>
                <sphereGeometry args={[0.32, 16, 16]} />
                <meshStandardMaterial color="#f5eeda" roughness={0.6} />
              </mesh>
              {[0.4, 0.7, 1.0, 1.3].map((x, i) => (
                <mesh key={i} position={[x, 2.2, 0]} castShadow>
                  <boxGeometry args={[0.2, 0.32, 0.45]} />
                  <meshStandardMaterial color="#ffffff" roughness={0.3} />
                </mesh>
              ))}
            </group>
            <Label p={[0.75, 0.9, 0]} size={0.3} color="#fca5a5">distal segment slides</Label>
            <Label p={[-2.3, 2.2, 0.5]} size={0.28} color={CUT}>BSSO split</Label>
          </>
        )}

        <Animator seg={seg} elapsed={elapsed} move={move} proc={proc} />
      </SimCanvas>
    </div>
  );
}
