"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "surface", label: "Surface treatment", kind: "select", min: 0, max: 0, step: 1, default: "sla", options: ["machined", "sla", "anodized"] },
  { key: "osseointegration", label: "Osseointegration", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.6, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Dental implants materials: titanium, surface treatments",
  blurb: "A threaded titanium implant in bone — roughen its surface and watch bone cells climb on and lock it in.",
};

const SURF: Record<string, { name: string; rough: number; color: string; note: string }> = {
  machined: { name: "Machined (smooth)", rough: 0.15, color: "#e2e8f0", note: "smooth — slow bone hug" },
  sla: { name: "SLA (sandblasted + etched)", rough: 0.7, color: "#cbd5e1", note: "micro-rough — bone loves it" },
  anodized: { name: "Anodized", rough: 0.5, color: "#a5b4fc", note: "oxide nanopores — fast healing" },
};

function ImplantScene({ surface, osseointegration, speed, showLabels }: { surface: string; osseointegration: number; speed: number; showLabels: boolean }) {
  const cells = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const cfg = SURF[surface] ?? SURF.sla;
  const N = 40;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (cells.current) {
      cells.current.children.forEach((c, i) => {
        const a = (i / N) * Math.PI * 2;
        // cells migrate onto the implant as osseointegration rises
        const rTarget = THREE.MathUtils.lerp(2.6, 1.05, osseointegration);
        const r = rTarget + Math.sin(elapsed.current * 2 + i) * 0.08;
        c.position.set(Math.cos(a) * r, -2.4 + ((i * 37) % 40) / 40 * 4.4, Math.sin(a) * r);
        const s = 0.6 + osseointegration * 0.7;
        c.scale.setScalar(s);
        ((c as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = osseointegration * 0.8;
      });
    }
  });

  return (
    <group>
      {/* bone block, cut open */}
      <mesh position={[0, -0.4, 0]} castShadow receiveShadow>
        <boxGeometry args={[6.4, 5.2, 4.4]} />
        <meshStandardMaterial color="#e7e5e4" roughness={0.8} />
      </mesh>
      {/* cortical plate top */}
      <mesh position={[0, 2.3, 0]} castShadow>
        <boxGeometry args={[6.4, 0.5, 4.4]} />
        <meshStandardMaterial color="#d6d3d1" roughness={0.7} />
      </mesh>
      {/* osteotomy channel */}
      <mesh position={[0, -0.2, 0]}>
        <cylinderGeometry args={[1.02, 1.02, 4.6, 20]} />
        <meshBasicMaterial color="#0f172a" />
      </mesh>

      {/* implant: threaded titanium screw */}
      <group position={[0, -0.2, 0]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.85, 0.55, 4.4, 20]} />
          <meshStandardMaterial color={cfg.color} metalness={0.9} roughness={1 - cfg.rough * 0.7} />
        </mesh>
        {/* threads */}
        {Array.from({ length: 9 }).map((_, i) => (
          <mesh key={i} position={[0, -1.9 + i * 0.48, 0]} castShadow>
            <torusGeometry args={[0.82 - i * 0.02, 0.09, 8, 22]} />
            <meshStandardMaterial color={cfg.color} metalness={0.9} roughness={1 - cfg.rough * 0.7} />
          </mesh>
        ))}
        {/* abutment + crown on top */}
        <mesh position={[0, 2.75, 0]} castShadow>
          <cylinderGeometry args={[0.5, 0.7, 0.9, 14]} />
          <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.3} />
        </mesh>
        <mesh position={[0, 3.9, 0]} castShadow>
          <boxGeometry args={[1.7, 1.4, 1.6]} />
          <meshStandardMaterial color="#fef9c3" roughness={0.25} />
        </mesh>
      </group>

      {/* osteoblasts colonizing the surface */}
      <group ref={cells}>
        {Array.from({ length: N }).map((_, i) => (
          <mesh key={i}>
            <sphereGeometry args={[0.13, 10, 8]} />
            <meshStandardMaterial color="#60a5fa" roughness={0.4} emissive="#1d4ed8" emissiveIntensity={0.4} />
          </mesh>
        ))}
      </group>

      {/* gum cuff */}
      <mesh position={[0, 2.75, 0]} castShadow>
        <torusGeometry args={[1.15, 0.45, 12, 24]} />
        <meshStandardMaterial color="#e88ca0" roughness={0.6} />
      </mesh>

      {showLabels && (
        <>
          <Text position={[4.4, 3.9, 0]} fontSize={0.4} color="#fef9c3">Crown</Text>
          <Text position={[4.4, 2.4, 0]} fontSize={0.38} color="#cbd5e1">Abutment</Text>
          <Text position={[4.4, -0.2, 0]} fontSize={0.4} color={cfg.color}>Titanium fixture — {cfg.name}</Text>
          <Text position={[-4.6, -0.2, 0]} fontSize={0.4} color="#60a5fa">Osteoblasts lock on</Text>
          <Text position={[0, 5.6, 0]} fontSize={0.44} color="#fef3c7" maxWidth={10}>{cfg.note}</Text>
        </>
      )}
    </group>
  );
}

export function Topic10399Sim(props: SimProps) {
  const surface = String(props.surface ?? "sla");
  const osseointegration = Number(props.osseointegration ?? 0.6);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = SURF[surface] ?? SURF.sla;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Surface", cfg.name],
          ["Bone contact", `${Math.round(osseointegration * 100)}%`],
          ["Healing", osseointegration > 0.8 ? "load it ✓" : "wait…"],
        ]}
      />
      <SimCanvas cameraPosition={[7.5, 3.5, 10]} target={[0, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.1, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <ImplantScene surface={surface} osseointegration={osseointegration} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
