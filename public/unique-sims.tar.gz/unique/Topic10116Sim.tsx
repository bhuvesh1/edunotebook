// Antiparkinsonian drugs: dopamine flows from the substantia nigra to the
// striatum — in Parkinson's the stream runs dry and the hand trembles; L-dopa
// refills it and the tremor settles.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dopa", label: "L-dopa dose", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Antiparkinsonian drugs",
  blurb: "Dopamine refills the brain's movement pathway — the trembling hand steadies as L-dopa rises.",
};

const N_DOPA = 12;

function Animator({ dopa, hand, nigra, elapsed, dose, setTick }: {
  dopa: React.RefObject<(THREE.Mesh | null)[]>;
  hand: React.RefObject<THREE.Group>;
  nigra: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  dose: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    // dopamine stream: sparse when untreated, rich with L-dopa
    dopa.current.forEach((d, i) => {
      if (!d) return;
      const alive = ((i * 47) % 10) / 10 < 0.15 + k * 0.85;
      d.visible = alive;
      if (!alive) return;
      const f = (t * (0.3 + k * 0.7) + i / N_DOPA) % 1;
      d.position.set(-2.8 + f * 5.6, 2.6 + Math.sin(f * Math.PI) * 0.9, Math.sin(i * 1.7) * 0.3);
      ((d as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = 0.5 + k * 1.2;
    });
    // hand tremor amplitude shrinks with dose
    if (hand.current) {
      const tremor = (1 - k) * 0.22;
      hand.current.position.x = 4.2 + Math.sin(t * 21) * tremor;
      hand.current.position.y = 1.1 + Math.cos(t * 17) * tremor * 0.7;
      hand.current.rotation.z = Math.sin(t * 19) * tremor * 1.5;
    }
    if (nigra.current) {
      (nigra.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.2 + k * 1.1;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(k * 100)); }
  });
  return null;
}

export function Topic10116Sim(props: SimProps) {
  const dose = Number(props.dopa ?? 55);
  const showLabels = String(props.detail ?? "on") === "on";
  const dopa = useRef<(THREE.Mesh | null)[]>([]);
  const hand = useRef<THREE.Group>(null!);
  const nigra = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const k = dose / 100;
  const tremor = k < 0.3 ? "severe tremor" : k < 0.65 ? "mild tremor" : "steady hand";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Dopamine supply", `${tick}%`],
          ["Hand", tremor],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0.6, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* substantia nigra */}
        <mesh ref={nigra} position={[-2.8, 2.6, 0]} castShadow>
          <sphereGeometry args={[0.7, 20, 14]} />
          <meshStandardMaterial color="#1f2937" emissive="#a855f7" emissiveIntensity={0.6} roughness={0.5} />
        </mesh>
        {showLabels && <Label text="substantia nigra" position={[-2.8, 3.8, 0]} size={0.45} color="#c4b5fd" />}

        {/* striatum */}
        <mesh position={[2.8, 2.6, 0]} castShadow>
          <sphereGeometry args={[0.85, 20, 14]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.5} />
        </mesh>
        {showLabels && <Label text="striatum" position={[2.8, 3.8, 0]} size={0.45} color="#7dd3fc" />}

        {/* dopamine pathway arc */}
        <mesh position={[0, 2.6, 0]} rotation={[0, 0, 0]}>
          <torusGeometry args={[2.8, 0.1, 8, 32, Math.PI]} />
          <meshStandardMaterial color="#475569" transparent opacity={0.6} />
        </mesh>

        {/* dopamine molecules */}
        {Array.from({ length: N_DOPA }).map((_, i) => (
          <mesh key={i} ref={(m) => { dopa.current[i] = m; }}>
            <sphereGeometry args={[0.14, 10, 8]} />
            <meshStandardMaterial color="#e879f9" emissive="#a21caf" emissiveIntensity={1} />
          </mesh>
        ))}
        {showLabels && <Label text="dopamine" position={[0, 4.6, 0]} size={0.45} color="#f0abfc" />}

        {/* patient's hand */}
        <group ref={hand} position={[4.2, 1.1, 1.2]}>
          <mesh castShadow>
            <boxGeometry args={[0.5, 0.28, 0.9]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
          {[-0.3, -0.1, 0.1, 0.3].map((z, i) => (
            <mesh key={i} position={[0.42, 0, z]} castShadow>
              <boxGeometry args={[0.35, 0.16, 0.14]} />
              <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
            </mesh>
          ))}
        </group>
        {showLabels && <Label text={`hand — ${tremor}`} position={[4.2, 2.3, 1.2]} size={0.45} color="#fde68a" />}

        {/* L-dopa pill */}
        <group position={[-2.8, 0, 1.6]}>
          <mesh position={[0, 0.5, 0]} castShadow>
            <capsuleGeometry args={[0.22, 0.36, 8, 16]} />
            <meshStandardMaterial color="#f0abfc" roughness={0.3} />
          </mesh>
        </group>
        {showLabels && <Label text="L-dopa" position={[-2.8, 1.4, 1.6]} size={0.45} color="#f0abfc" />}

        <Animator dopa={dopa} hand={hand} nigra={nigra} elapsed={elapsed} dose={dose} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
