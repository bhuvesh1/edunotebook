// Head & neck cancers — oral & oropharyngeal. An open mouth: tongue, teeth,
// tonsils. A cancerous ulcer grows on the tongue edge / tonsil with the stage
// slider — from small white patch to large red crater.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Cancer stage", kind: "slider", min: 0, max: 4, step: 1, default: 2, unit: "" },
  { key: "site", label: "Site", kind: "select", min: 0, max: 0, step: 1, default: "tongue", options: ["tongue", "tonsil", "floor of mouth"] },
];

export const UNIQUE_META = {
  title: "Head & Neck Cancers",
  blurb: "An open mouth with a growing ulcer on the tongue or tonsil — stage slider shows how a tiny white patch becomes a dangerous crater.",
};

function Animator({ lesion, elapsed, stage }: {
  lesion: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  stage: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (lesion.current) {
      lesion.current.children.forEach((c, i) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = 0.35 + 0.3 * Math.sin(t * 3 + i);
      });
    }
  });
  return null;
}

export function Topic10196Sim(props: SimProps) {
  const stage = Number(props.stage ?? 2);
  const site = String(props.site ?? "tongue");
  const lesion = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const lesionScale = 0.35 + stage * 0.35;
  const lesionPos: [number, number, number] =
    site === "tongue" ? [0.9, 1.15, 0.55] : site === "tonsil" ? [-2.0, 1.9, -0.5] : [0, 0.75, 1.1];
  const stageNames = ["0 — white patch (leukoplakia)", "I — small ulcer", "II — growing crater", "III — invading deeper", "IV — spread to nodes"];
  const nodeSwollen = stage >= 4;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Stage", stageNames[stage]], ["Warning signs", "non-healing ulcer > 3 weeks"], ["Nodes", nodeSwollen ? "neck node involved ⚠" : "clear"]]} />
      <SimCanvas cameraPosition={[0, 2.6, 10.5]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* open mouth frame */}
        <mesh position={[0, 1.9, -1.2]} castShadow>
          <boxGeometry args={[5.4, 4.4, 1.4]} />
          <meshStandardMaterial color="#f5d0b8" roughness={0.65} />
        </mesh>
        {/* oral cavity */}
        <mesh position={[0, 1.9, -0.3]}>
          <sphereGeometry args={[2.0, 28, 20]} />
          <meshStandardMaterial color="#7f1d1d" roughness={0.7} side={THREE.BackSide} />
        </mesh>
        {/* tongue */}
        <mesh position={[0, 1.05, 0.35]} scale={[1.5, 0.55, 1.9]} castShadow>
          <sphereGeometry args={[1.0, 26, 18]} />
          <meshStandardMaterial color="#f87171" roughness={0.55} />
        </mesh>
        {/* teeth */}
        {Array.from({ length: 8 }).map((_, i) => (
          <mesh key={i} position={[-1.75 + i * 0.5, 3.35, 0.75]}>
            <boxGeometry args={[0.38, 0.5, 0.3]} />
            <meshStandardMaterial color="#fefce8" roughness={0.4} />
          </mesh>
        ))}
        {/* tonsils */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * 1.85, 1.9, -0.6]} scale={[1, 1.3, 0.8]}>
            <sphereGeometry args={[0.42, 16, 12]} />
            <meshStandardMaterial color="#fca5a5" roughness={0.6} />
          </mesh>
        ))}

        {/* the cancerous lesion */}
        <group ref={lesion}>
          <mesh position={lesionPos} scale={[lesionScale, lesionScale * 0.6, lesionScale]}>
            <sphereGeometry args={[0.5, 18, 14]} />
            <meshStandardMaterial color={stage === 0 ? "#fefce8" : "#dc2626"} roughness={0.7} emissive={stage === 0 ? "#a16207" : "#7f1d1d"} emissiveIntensity={0.4} />
          </mesh>
          {stage >= 2 && (
            <mesh position={[lesionPos[0], lesionPos[1] + lesionScale * 0.35, lesionPos[2]]} scale={[lesionScale * 0.55, lesionScale * 0.3, lesionScale * 0.55]}>
              <sphereGeometry args={[0.5, 14, 10]} />
              <meshStandardMaterial color="#450a0a" roughness={0.9} />
            </mesh>
          )}
        </group>
        {/* involved neck node at stage IV */}
        {nodeSwollen && (
          <mesh position={[3.4, 0.4, 0.6]}>
            <sphereGeometry args={[0.55, 16, 14]} />
            <meshStandardMaterial color="#ef4444" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.5} />
          </mesh>
        )}

        <Label text={`Ulcer on ${site}`} position={[lesionPos[0], lesionPos[1] + 1.4, lesionPos[2]]} size={0.52} color={stage === 0 ? "#fde047" : "#fca5a5"} />
        {nodeSwollen && <Label text="Spread to neck node" position={[3.4, 1.6, 0.6]} size={0.5} color="#fca5a5" />}
        <Label text="Tobacco + alcohol are the big risks · early = curable" position={[0, -1.4, 0]} size={0.44} color="#94a3b8" />
        <Animator lesion={lesion} elapsed={elapsed} stage={stage} />
      </SimCanvas>
    </div>
  );
}
