"use client";
// Forensic psychiatry: insanity, criminal responsibility.
// A glowing brain on one pan of the scales, a gavel on the other —
// slide "mental capacity" and watch justice tip one way or the other.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "capacity", label: "Mental capacity", kind: "slider", min: 0, max: 100, step: 5, default: 50, unit: "%" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Forensic Psychiatry: Insanity & Criminal Responsibility",
  blurb: "The brain and the gavel balance on the scales — slide mental capacity to see when the law holds someone responsible.",
};

function Animator({ beam, brain, elapsed, speed, capacity }: { beam: React.RefObject<THREE.Group>; brain: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; speed: number; capacity: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    // low capacity -> brain side sinks (not responsible); high -> gavel side sinks (responsible)
    const target = (50 - capacity) / 50 * 0.35;
    if (beam.current) {
      beam.current.rotation.z += (target + Math.sin(elapsed.current * 1.4) * 0.02 - beam.current.rotation.z) * 0.06;
    }
    if (brain.current) {
      const s = 1 + Math.sin(elapsed.current * 2.2) * 0.05;
      brain.current.scale.set(s, s, s);
    }
  });
  return null;
}

export function Topic10159Sim(props: SimProps) {
  const capacity = Number(props.capacity ?? 50);
  const speed = Number(props.speed ?? 1);
  const beam = useRef<THREE.Group>(null!);
  const brain = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const verdict = capacity < 30 ? "Not responsible (insanity)" : capacity > 70 ? "Fully responsible" : "Diminished responsibility";
  const verdictColor = capacity < 30 ? "#38bdf8" : capacity > 70 ? "#f87171" : "#fbbf24";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Capacity", `${capacity}%`], ["Verdict", verdict]]} />
      <SimCanvas cameraPosition={[0, 3.8, 13]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* pillar */}
        <mesh position={[0, 1.4, 0]} castShadow>
          <cylinderGeometry args={[0.22, 0.35, 2.8, 14]} />
          <meshStandardMaterial color="#64748b" roughness={0.6} />
        </mesh>
        <mesh position={[0, 2.95, 0]}>
          <sphereGeometry args={[0.28, 14, 14]} />
          <meshStandardMaterial color="#fbbf24" metalness={0.7} roughness={0.3} />
        </mesh>
        {/* tilting beam */}
        <group ref={beam} position={[0, 2.95, 0]}>
          <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
            <cylinderGeometry args={[0.09, 0.09, 7, 10]} />
            <meshStandardMaterial color="#fbbf24" metalness={0.7} roughness={0.3} />
          </mesh>
          {/* brain pan (left) */}
          <group position={[-3.5, 0, 0]}>
            <mesh position={[0, -0.9, 0]} rotation={[0, 0, 0.15]}>
              <cylinderGeometry args={[0.08, 0.08, 1.1, 8]} />
              <meshStandardMaterial color="#fbbf24" metalness={0.6} roughness={0.35} />
            </mesh>
            <mesh position={[0, -1.5, 0]}>
              <cylinderGeometry args={[1, 0.75, 0.25, 18]} />
              <meshStandardMaterial color="#fde68a" metalness={0.6} roughness={0.35} />
            </mesh>
            <mesh ref={brain} position={[0, -0.85, 0]} castShadow>
              <icosahedronGeometry args={[0.75, 1]} />
              <meshStandardMaterial color="#f472b6" roughness={0.55} emissive="#ec4899" emissiveIntensity={0.25} flatShading />
            </mesh>
            <Label text="MIND" position={[0, 0.4, 0]} size={0.55} color="#f9a8d4" />
          </group>
          {/* gavel pan (right) */}
          <group position={[3.5, 0, 0]}>
            <mesh position={[0, -0.9, 0]} rotation={[0, 0, -0.15]}>
              <cylinderGeometry args={[0.08, 0.08, 1.1, 8]} />
              <meshStandardMaterial color="#fbbf24" metalness={0.6} roughness={0.35} />
            </mesh>
            <mesh position={[0, -1.5, 0]}>
              <cylinderGeometry args={[1, 0.75, 0.25, 18]} />
              <meshStandardMaterial color="#fde68a" metalness={0.6} roughness={0.35} />
            </mesh>
            <mesh position={[0, -0.9, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
              <cylinderGeometry args={[0.22, 0.22, 0.6, 12]} />
              <meshStandardMaterial color="#b45309" roughness={0.5} />
            </mesh>
            <Label text="LAW" position={[0, 0.4, 0]} size={0.55} color="#fbbf24" />
          </group>
        </group>
        <Label text={verdict} position={[0, 5.6, 0]} size={0.7} color={verdictColor} />
        <Animator beam={beam} brain={brain} elapsed={elapsed} speed={speed} capacity={capacity} />
      </SimCanvas>
    </div>
  );
}
