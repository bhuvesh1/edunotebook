"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "group", label: "Patient group", kind: "select", min: 0, max: 0, step: 1, default: "pregnant", options: ["pregnant", "child", "elderly"] },
  { key: "dose", label: "Dose adjustment", kind: "slider", min: 25, max: 100, step: 5, default: 50, unit: "%" },
];

export const UNIQUE_META = {
  title: "Pharmacology in pregnancy, children, elderly dental patients",
  blurb: "Three special patients — pregnant mother, child, elderly — each gets a right-sized dose pill and a safety badge.",
};

const GROUPS: Record<string, { name: string; color: string; pillScale: number; badge: string; badgeColor: string; note: string }> = {
  pregnant: { name: "Pregnant patient", color: "#f9a8d4", pillScale: 0.7, badge: "Avoid in 1st trimester", badgeColor: "#fbbf24", note: "Paracetamol safest · avoid NSAIDs late" },
  child: { name: "Child patient", color: "#7dd3fc", pillScale: 0.5, badge: "Weight-based dosing", badgeColor: "#7dd3fc", note: "mg per kg — never adult dose" },
  elderly: { name: "Elderly patient", color: "#c4b5fd", pillScale: 0.65, badge: "Start low, go slow", badgeColor: "#86efac", note: "Kidneys slower — reduce dose" },
};

function Person({ kind, x, active, dose }: { kind: string; x: number; active: boolean; dose: number }) {
  const g = GROUPS[kind]!;
  const bob = useRef<THREE.Group>(null!);
  const t = useRef(Math.random() * 5);
  useFrame((_, delta) => {
    t.current += delta;
    if (bob.current) bob.current.position.y = Math.sin(t.current * 1.5) * 0.06;
  });
  const s = active ? 1.25 : 0.85;
  return (
    <group position={[x, 0, 0]} scale={s}>
      <group ref={bob}>
        {/* head */}
        <mesh position={[0, 1.9, 0]}>
          <sphereGeometry args={[0.42, 18, 18]} />
          <meshStandardMaterial color="#f2c9a0" roughness={0.6} />
        </mesh>
        {/* body */}
        <mesh position={[0, 0.9, 0]}>
          <capsuleGeometry args={[0.4, 1.0, 8, 14]} />
          <meshStandardMaterial color={active ? g.color : "#475569"} roughness={0.7} />
        </mesh>
        {/* pregnant belly */}
        {kind === "pregnant" && (
          <mesh position={[0, 0.85, 0.45]}>
            <sphereGeometry args={[0.38, 16, 16]} />
            <meshStandardMaterial color={active ? g.color : "#475569"} roughness={0.7} />
          </mesh>
        )}
        {/* elderly cane */}
        {kind === "elderly" && (
          <mesh position={[0.65, 0.6, 0]} rotation={[0, 0, 0.1]}>
            <cylinderGeometry args={[0.05, 0.05, 1.6, 8]} />
            <meshStandardMaterial color="#a16207" roughness={0.6} />
          </mesh>
        )}
        {/* dose pill sized to patient */}
        <group position={[0, 0.4, 0.9]}>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <capsuleGeometry args={[0.16 * g.pillScale * (dose / 50), 0.3 * g.pillScale * (dose / 50), 6, 12]} />
            <meshStandardMaterial color={g.color} roughness={0.35} />
          </mesh>
          <Label text={`${dose}% dose`} position={[0, 0.55, 0]} size={0.36} color={g.color} />
        </group>
        <Label text={g.name} position={[0, 2.7, 0]} size={0.42} color={active ? g.color : "#94a3b8"} />
        {active && <Label text={g.badge} position={[0, -0.6, 0]} size={0.42} color={g.badgeColor} />}
      </group>
    </group>
  );
}

function Scene({ group, dose }: { group: string; dose: number }) {
  const g = GROUPS[group] ?? GROUPS.pregnant;
  return (
    <group>
      <Person kind="pregnant" x={-3} active={group === "pregnant"} dose={dose} />
      <Person kind="child" x={0} active={group === "child"} dose={dose} />
      <Person kind="elderly" x={3} active={group === "elderly"} dose={dose} />
      {/* dentist figure */}
      <group position={[0, 0, -2.2]}>
        <mesh position={[0, 1.9, 0]}>
          <sphereGeometry args={[0.4, 16, 16]} />
          <meshStandardMaterial color="#f2c9a0" roughness={0.6} />
        </mesh>
        <mesh position={[0, 0.9, 0]}>
          <capsuleGeometry args={[0.38, 1.0, 8, 14]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.7} />
        </mesh>
        <Label text="Dentist adjusts dose" position={[0, 2.65, 0]} size={0.4} color="#e2e8f0" />
      </group>
      <Label text={g.name} position={[0, 3.9, 0]} size={0.65} color={g.color} />
      <Label text={g.note} position={[0, -2.2, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10427Sim(props: SimProps) {
  const group = String(props.group ?? "pregnant");
  const dose = Number(props.dose ?? 50);
  const g = GROUPS[group] ?? GROUPS.pregnant;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Patient", g.name], ["Dose", `${dose}% of adult`], ["Rule", g.badge]]} />
      <SimCanvas cameraPosition={[0, 2, 11]} target={[0, 0.8, 0]}>
        <Scene group={group} dose={dose} />
      </SimCanvas>
    </div>
  );
}
