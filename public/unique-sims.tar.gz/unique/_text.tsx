// app/components/sims/unique/_text.tsx
// Tiny canvas-sprite text label for unique sims. No external assets.

"use client";

import { useMemo } from "react";
import * as THREE from "three";

export function Label({
  text,
  position = [0, 0, 0],
  color = "#f8fafc",
  size = 0.5,
}: {
  text: string;
  position?: [number, number, number];
  color?: string;
  size?: number;
}) {
  const { tex, aspect } = useMemo(() => {
    const font = "700 60px system-ui, -apple-system, sans-serif";
    const meas = document.createElement("canvas").getContext("2d")!;
    meas.font = font;
    const tw = Math.ceil(meas.measureText(text).width);
    const c = document.createElement("canvas");
    c.width = tw + 44;
    c.height = 100;
    const g = c.getContext("2d")!;
    // pill background
    g.fillStyle = "rgba(2,6,23,0.78)";
    const r = 22;
    g.beginPath();
    g.moveTo(r, 2);
    g.lineTo(c.width - r, 2);
    g.quadraticCurveTo(c.width - 2, 2, c.width - 2, r);
    g.lineTo(c.width - 2, 100 - r);
    g.quadraticCurveTo(c.width - 2, 98, c.width - r, 98);
    g.lineTo(r, 98);
    g.quadraticCurveTo(2, 98, 2, 100 - r);
    g.lineTo(2, r);
    g.quadraticCurveTo(2, 2, r, 2);
    g.closePath();
    g.fill();
    g.font = font;
    g.textBaseline = "middle";
    g.fillStyle = color;
    g.fillText(text, 22, 52);
    const tex = new THREE.CanvasTexture(c);
    tex.anisotropy = 4;
    return { tex, aspect: c.width / c.height };
  }, [text, color]);

  return (
    <sprite position={position} scale={[size * aspect, size, 1]} renderOrder={10}>
      <spriteMaterial map={tex} transparent depthTest={false} />
    </sprite>
  );
}

/** Simple arrow: cylinder shaft + cone head, pointing along +dir from base. */
export function Arrow({
  from,
  to,
  color = "#fbbf24",
  radius = 0.07,
}: {
  from: [number, number, number];
  to: [number, number, number];
  color?: string;
  radius?: number;
}) {
  const dir = useMemo(() => {
    const a = new THREE.Vector3(...from);
    const b = new THREE.Vector3(...to);
    const d = b.clone().sub(a);
    const len = d.length();
    const mid = a.clone().add(b).multiplyScalar(0.5);
    const quat = new THREE.Quaternion().setFromUnitVectors(
      new THREE.Vector3(0, 1, 0),
      d.clone().normalize()
    );
    return { len, mid, quat };
  }, [from, to]);
  const shaftLen = Math.max(0.01, dir.len - radius * 4);
  return (
    <group position={dir.mid.toArray()} quaternion={dir.quat}>
      <mesh position={[0, -(dir.len / 2) + shaftLen / 2, 0]}>
        <cylinderGeometry args={[radius, radius, shaftLen, 10]} />
        <meshStandardMaterial color={color} roughness={0.5} />
      </mesh>
      <mesh position={[0, dir.len / 2 - radius * 2, 0]}>
        <coneGeometry args={[radius * 2.6, radius * 5, 12]} />
        <meshStandardMaterial color={color} roughness={0.5} />
      </mesh>
    </group>
  );
}
