"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Casting stage", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.45, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Investment materials and casting procedures",
  blurb: "Lost-wax casting: invest the wax crown pattern, burn the wax out with flame, and pour metal into the empty mold.",
};

const STEPS = [
  "Wax pattern on sprue, ready to invest",
  "Invested — ring filled with plaster-bonded investment",
  "Burnout: wax melts and burns away",
  "Empty mold cavity — cast the metal!",
];

function InvestmentScene({ stage, speed, showLabels }: { stage: number; speed: number; showLabels: boolean }) {
  const wax = useRef<THREE.Group>(null!);
  const flame = useRef<THREE.Group>(null!);
  const metal = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const step = Math.min(3, Math.floor(stage * 4));

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (wax.current) {
      const gone = stage > 0.5 ? Math.max(0.001, 1 - (stage - 0.5) * 2.4) : 1;
      wax.current.scale.setScalar(gone);
      wax.current.visible = gone > 0.01;
    }
    if (flame.current) {
      flame.current.visible = stage > 0.35 && stage < 0.75;
      flame.current.children.forEach((f, i) => {
        f.scale.y = 1 + Math.sin(elapsed.current * 18 + i * 2) * 0.3;
      });
    }
    if (metal.current) {
      const fill = stage > 0.75 ? Math.min(1, (stage - 0.75) * 4) : 0.001;
      metal.current.scale.setScalar(Math.max(fill, 0.001));
      metal.current.visible = fill > 0.01;
      (metal.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 1.5 * (1 - fill * 0.7);
    }
  });

  return (
    <group>
      {/* casting ring */}
      <mesh position={[0, 0.4, 0]} castShadow>
        <cylinderGeometry args={[2.1, 2.1, 3.4, 28, 1, true]} />
        <meshStandardMaterial color="#94a3b8" metalness={0.7} roughness={0.35} side={THREE.DoubleSide} />
      </mesh>
      {/* investment fill */}
      <mesh position={[0, 0.4, 0]} castShadow>
        <cylinderGeometry args={[1.95, 1.95, 3.2, 28]} />
        <meshStandardMaterial color={step >= 2 ? "#d6a35c" : "#e7e5e4"} roughness={0.9} />
      </mesh>

      {/* wax crown pattern + sprue */}
      <group ref={wax} position={[0, 0.9, 0]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.75, 0.85, 1, 18, 1, true]} />
          <meshStandardMaterial color="#22c55e" roughness={0.4} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[0, -1.1, 0]} castShadow>
          <cylinderGeometry args={[0.14, 0.14, 1.6, 10]} />
          <meshStandardMaterial color="#facc15" roughness={0.45} />
        </mesh>
      </group>

      {/* cast metal crown appearing in the cavity */}
      <mesh ref={metal} position={[0, 0.9, 0]} scale={[0.001, 0.001, 0.001]} visible={false} castShadow>
        <cylinderGeometry args={[0.75, 0.85, 1, 18, 1, true]} />
        <meshStandardMaterial color="#fbbf24" metalness={0.9} roughness={0.25} emissive="#f97316" emissiveIntensity={1.5} side={THREE.DoubleSide} />
      </mesh>

      {/* burnout flame under the ring */}
      <group ref={flame} position={[0, -2.2, 0]} visible={false}>
        {[0, 1, 2].map((i) => (
          <mesh key={i} position={[(i - 1) * 0.7, 0.5, 0]}>
            <coneGeometry args={[0.45, 1.6, 10]} />
            <meshBasicMaterial color={i === 1 ? "#fde68a" : "#f97316"} transparent opacity={0.85} />
          </mesh>
        ))}
      </group>
      {/* furnace base */}
      <mesh position={[0, -3.1, 0]} castShadow>
        <boxGeometry args={[4.5, 0.5, 4.5]} />
        <meshStandardMaterial color="#44403c" roughness={0.8} />
      </mesh>

      {showLabels && (
        <>
          <Text position={[0, 3.4, 0]} fontSize={0.46} color="#fef3c7">Lost-wax casting ring</Text>
          <Text position={[0, -4.4, 0]} fontSize={0.42} color={step === 2 ? "#fdba74" : "#e2e8f0"} maxWidth={10}>
            {STEPS[step]}
          </Text>
          <Text position={[-4.6, 0.4, 0]} fontSize={0.38} color="#22c55e" maxWidth={4}>Wax pattern + sprue</Text>
          <Text position={[4.6, 0.4, 0]} fontSize={0.38} color="#e7e5e4" maxWidth={4}>Investment expands to fit the metal</Text>
        </>
      )}
    </group>
  );
}

export function Topic10397Sim(props: SimProps) {
  const stage = Number(props.stage ?? 0.45);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const step = Math.min(3, Math.floor(stage * 4));

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Step", `${step + 1} / 4`],
          ["Investment", "silica + binder (expands on heating)"],
          ["Burnout", "wax eliminated ~700 °C"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 0.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.5, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <InvestmentScene stage={stage} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
