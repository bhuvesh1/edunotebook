"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "state", label: "Sinus state", kind: "select", min: 0, max: 0, step: 1, default: "healthy", options: ["healthy", "sinusitis"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Maxillary sinus and nasal cavity relations",
  blurb: "The maxillary sinus hollows out the cheekbone right above your upper molars — see why a tooth infection can become sinusitis.",
};

// mucus / inflamed fluid draining
function Drainage({ sinusitis, speed }: { sinusitis: boolean; speed: number }) {
  const pts = useRef<THREE.Points>(null!);
  const N = 30;
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (!pts.current) return;
    const p = pts.current.geometry.attributes.position;
    for (let i = 0; i < N; i++) {
      const t = ((elapsed.current * 0.25 + i / N) % 1 + 1) % 1;
      // ostium at top of sinus → drains into nasal cavity
      p.setXYZ(i,
        THREE.MathUtils.lerp(1.9, 0.6, t) + Math.sin(t * 9 + i) * 0.08,
        THREE.MathUtils.lerp(2.6, 3.4, t),
        0.9 - t * 0.4
      );
    }
    p.needsUpdate = true;
  });
  return (
    <points ref={pts}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[new Float32Array(N * 3), 3]} />
      </bufferGeometry>
      <pointsMaterial color={sinusitis ? "#facc15" : "#7dd3fc"} size={0.14} transparent opacity={0.9} />
    </points>
  );
}

function SinusScene({ state, speed, showLabels }: { state: string; speed: number; showLabels: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const fluid = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const sinusitis = state === "sinusitis";

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) g.current.rotation.y = Math.sin(elapsed.current * 0.3) * 0.18;
    if (fluid.current) {
      const target = sinusitis ? 1 : 0.001;
      const s = THREE.MathUtils.lerp(fluid.current.scale.x, target, 0.04);
      fluid.current.scale.setScalar(Math.max(s, 0.001));
      (fluid.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.3 + Math.sin(elapsed.current * 3) * 0.15;
    }
  });

  return (
    <group ref={g}>
      {/* skull block (translucent) */}
      <mesh position={[0, 2.5, -0.5]} castShadow>
        <boxGeometry args={[6.4, 5.6, 4]} />
        <meshPhysicalMaterial color="#e7e5e4" transparent opacity={0.22} roughness={0.5} />
      </mesh>
      {/* nasal cavity septum */}
      <mesh position={[0, 2.6, 0.6]} castShadow>
        <boxGeometry args={[0.25, 3.4, 2.2]} />
        <meshStandardMaterial color="#f9a8d4" roughness={0.55} />
      </mesh>
      {/* turbinates */}
      {[-0.9, 0.9].map((x, i) => (
        <mesh key={i} position={[x * 0.9, 2.9, 0.6]} rotation={[0, 0, x * 0.35]} castShadow>
          <boxGeometry args={[0.9, 0.3, 1.8]} />
          <meshStandardMaterial color="#fda4af" roughness={0.55} />
        </mesh>
      ))}
      {/* maxillary sinuses: hollow pyramids in the cheekbones */}
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * 1.9, 1.6, 0.4]} castShadow>
            <coneGeometry args={[1.15, 2.2, 4]} />
            <meshPhysicalMaterial color="#bae6fd" transparent opacity={0.35} roughness={0.2} side={THREE.DoubleSide} />
          </mesh>
          {/* inflamed fluid level */}
          <mesh ref={s === 1 ? fluid : undefined} position={[s * 1.9, 1.1, 0.4]} scale={[0.001, 0.001, 0.001]}>
            <coneGeometry args={[0.95, 1.2, 4]} />
            <meshStandardMaterial color="#facc15" transparent opacity={0.75} roughness={0.3} emissive="#a16207" emissiveIntensity={0.3} />
          </mesh>
        </group>
      ))}
      {/* ostium (drainage hole) marker */}
      <mesh position={[1.9, 2.6, 0.6]}>
        <torusGeometry args={[0.18, 0.06, 8, 16]} />
        <meshBasicMaterial color={sinusitis ? "#ef4444" : "#4ade80"} />
      </mesh>
      <Drainage sinusitis={sinusitis} speed={speed} />
      {/* upper molars whose roots touch the sinus floor */}
      {[1.3, 2.1].map((x, i) => (
        <group key={i} position={[x, -0.9, 0.9]}>
          <mesh castShadow>
            <boxGeometry args={[0.62, 0.7, 0.62]} />
            <meshStandardMaterial color="#fef9c3" roughness={0.25} />
          </mesh>
          <mesh position={[0, -0.7, 0]} castShadow>
            <coneGeometry args={[0.2, 0.9, 8]} />
            <meshStandardMaterial color="#fde68a" roughness={0.4} />
          </mesh>
          {/* infection spread line in sinusitis */}
          {sinusitis && (
            <mesh position={[0, 0.3, 0]}>
              <cylinderGeometry args={[0.05, 0.05, 1.2, 6]} />
              <meshBasicMaterial color="#ef4444" transparent opacity={0.7} />
            </mesh>
          )}
        </group>
      ))}
      {showLabels && (
        <>
          <Text position={[3.9, 1.6, 0.4]} fontSize={0.4} color="#7dd3fc">Maxillary sinus</Text>
          <Text position={[-3.6, 2.6, 0.6]} fontSize={0.4} color="#f9a8d4">Nasal cavity</Text>
          <Text position={[1.9, 3.3, 0.6]} fontSize={0.34} color={sinusitis ? "#fca5a5" : "#86efac"}>Ostium {sinusitis ? "(blocked!)" : "(drains)"}</Text>
          <Text position={[1.7, -2.2, 0.9]} fontSize={0.36} color="#fef9c3">Molar roots touch sinus floor</Text>
          <Text position={[0, 6.2, 0]} fontSize={0.44} color="#fef3c7" maxWidth={10}>
            {sinusitis ? "Sinusitis: ostium blocked, pus collects — tooth infection can spread upward" : "Healthy: mucus drains freely through the ostium"}
          </Text>
        </>
      )}
    </group>
  );
}

export function Topic10383Sim(props: SimProps) {
  const state = String(props.state ?? "healthy");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Sinus", state === "healthy" ? "clear ✓" : "inflamed ⚠"],
          ["Drainage", state === "healthy" ? "ostium open" : "ostium blocked"],
          ["Dental link", "molar roots ↔ sinus floor"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.8, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <SinusScene state={state} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
