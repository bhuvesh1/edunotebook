"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "bp", label: "Base pairs", kind: "slider", min: 6, max: 16, step: 1, default: 10 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "DNA Double Helix",
  blurb: "A rotating B-DNA double helix with color-coded A-T and G-C base pairs on a sugar-phosphate backbone.",
};

function Animator({ root, g, elapsed, speed }: { root: RefObject<THREE.Group>; g: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (root.current) root.current.rotation.y = t * 0.4;
    if (g.current) g.current.position.y = Math.sin(t * 1.4) * 0.15;
  });
  return null;
}

export function Topic10061Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const bp = Math.round(Number(props.bp ?? 10));
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const g = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Base pairs", `${bp}`],
          ["Form", "B-DNA \u00b7 right-handed"],
          ["Rise / turn", "3.4 \u00c5 \u00b7 10.5 bp"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 11]} target={[0, 2.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <group ref={g}>
            {Array.from({ length: bp }).map((_, i) => {
              const a = i * 0.62;
              const y = 0.6 + i * 0.55;
              const ca = Math.cos(a), sa = Math.sin(a);
              const isAT = i % 2 === 0;
              const c1 = isAT ? "#4ade80" : "#60a5fa";
              const c2 = isAT ? "#f87171" : "#facc15";
              return (
                <group key={i}>
                  <mesh position={[ca * 1.3, y, sa * 1.3]} castShadow>
                    <sphereGeometry args={[0.24, 16, 16]} /><meshStandardMaterial color="#c084fc" roughness={0.4} />
                  </mesh>
                  <mesh position={[-ca * 1.3, y, -sa * 1.3]} castShadow>
                    <sphereGeometry args={[0.24, 16, 16]} /><meshStandardMaterial color="#c084fc" roughness={0.4} />
                  </mesh>
                  <mesh position={[ca * 0.62, y, sa * 0.62]} rotation={[0, -a, 0]}>
                    <boxGeometry args={[1.25, 0.2, 0.2]} /><meshStandardMaterial color={c1} roughness={0.4} />
                  </mesh>
                  <mesh position={[-ca * 0.62, y, -sa * 0.62]} rotation={[0, -a, 0]}>
                    <boxGeometry args={[1.25, 0.2, 0.2]} /><meshStandardMaterial color={c2} roughness={0.4} />
                  </mesh>
                </group>
              );
            })}
          </group>
          <Label text="sugar\u2013phosphate backbone" position={[2.6, 0.6 + bp * 0.55 + 0.4, 0]} size={0.42} color="#c084fc" />
          <Label text="A\u2013T (2 H-bonds)" position={[-3.4, 2.2, 0]} size={0.42} color="#4ade80" />
          <Label text="G\u2013C (3 H-bonds)" position={[-3.4, 1.4, 0]} size={0.42} color="#60a5fa" />
        </group>
        <Animator root={root} g={g} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
