// Topic10577 — Peri-implant diseases and maintenance.
// A titanium implant in jawbone. Plaque bacteria swarm it; the gum
// ring reddens, swells and the pocket deepens as inflammation rises.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "inflam", label: "Inflammation", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "plaque", label: "Plaque level", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
];

export const UNIQUE_META = {
  title: "Peri-implant diseases and maintenance",
  blurb: "Plaque bacteria attack a dental implant — watch the gum inflame, swell and the pocket deepen.",
};

function Animator({
  gum,
  bugs,
  implant,
  elapsed,
  inflam,
  plaque,
}: {
  gum: RefObject<THREE.Mesh>;
  bugs: RefObject<THREE.Group>;
  implant: RefObject<THREE.Group>;
  elapsed: RefObject<number>;
  inflam: number;
  plaque: number;
}) {
  const pink = useMemo(() => new THREE.Color("#f472b6"), []);
  const red = useMemo(() => new THREE.Color("#dc2626"), []);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    // swarming bacteria
    if (bugs.current) {
      const n = bugs.current.children.length;
      bugs.current.children.forEach((m, i) => {
        const a = t * (0.6 + plaque / 120) + (i / n) * Math.PI * 2;
        const r = 1.5 + Math.sin(t * 2 + i) * 0.25;
        m.position.set(Math.cos(a) * r, 2.2 + Math.sin(t * 3 + i * 1.7) * 0.35, Math.sin(a) * r * 0.6);
        m.scale.setScalar(0.6 + plaque / 200);
      });
      bugs.current.visible = plaque > 3;
    }
    // inflamed gum: reddens + pulses
    if (gum.current) {
      const mat = gum.current.material as THREE.MeshStandardMaterial;
      mat.color.copy(pink).lerp(red, inflam / 100);
      const pulse = 1 + (inflam / 100) * 0.14 * Math.sin(t * 4);
      gum.current.scale.set(pulse, 1, pulse);
    }
    // late-stage peri-implantitis: the implant itself wobbles (bone loss)
    if (implant.current) {
      implant.current.rotation.z = inflam > 70 ? Math.sin(t * 7) * 0.02 : 0;
    }
  });
  return null;
}

export function Topic10577Sim(props: SimProps) {
  const inflam = Number(props.inflam ?? 55);
  const plaque = Number(props.plaque ?? 60);
  const gum = useRef<THREE.Mesh>(null!);
  const bugs = useRef<THREE.Group>(null!);
  const implant = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const pocket = (2 + (inflam / 100) * 4).toFixed(1);
  const status = inflam < 25 ? "Healthy" : inflam < 60 ? "Peri-implant mucositis" : "Peri-implantitis";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Pocket depth", `${pocket} mm`],
          ["Status", status],
          ["Plaque", `${plaque}%`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 11]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* jawbone block */}
        <mesh position={[0, 0.35, 0]} receiveShadow castShadow>
          <boxGeometry args={[7, 1.5, 3]} />
          <meshStandardMaterial color="#c99a7c" roughness={0.9} />
        </mesh>
        {/* gum surface on top of bone */}
        <mesh position={[0, 1.25, 0]}>
          <boxGeometry args={[7, 0.25, 3]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.7} />
        </mesh>

        {/* the implant: titanium screw + abutment + crown */}
        <group ref={implant}>
          <mesh position={[0, 0.7, 0]} castShadow>
            <cylinderGeometry args={[0.34, 0.3, 1.5, 16]} />
            <meshStandardMaterial color="#9ca3af" roughness={0.25} metalness={0.9} />
          </mesh>
          {[0.15, 0.45, 0.75, 1.05].map((y) => (
            <mesh key={y} position={[0, y, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.33, 0.05, 8, 20]} />
              <meshStandardMaterial color="#d1d5db" roughness={0.3} metalness={0.9} />
            </mesh>
          ))}
          <mesh position={[0, 1.55, 0]} castShadow>
            <cylinderGeometry args={[0.22, 0.28, 0.45, 14]} />
            <meshStandardMaterial color="#6b7280" roughness={0.35} metalness={0.85} />
          </mesh>
          {/* crown */}
          <mesh position={[0, 2.35, 0]} castShadow>
            <cylinderGeometry args={[0.5, 0.4, 1.1, 18]} />
            <meshStandardMaterial color="#fef9ef" roughness={0.3} />
          </mesh>
        </group>

        {/* inflamed gum ring hugging the implant */}
        <mesh ref={gum} position={[0, 1.42, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.62, 0.3, 12, 28]} />
          <meshStandardMaterial color="#f472b6" roughness={0.55} emissive="#7f1d1d" emissiveIntensity={0.35} />
        </mesh>

        {/* plaque bacteria swarm */}
        <group ref={bugs}>
          {Array.from({ length: 14 }).map((_, i) => (
            <mesh key={i} position={[1.5, 2.2, 0]}>
              <sphereGeometry args={[0.09, 10, 10]} />
              <meshStandardMaterial color="#84cc16" roughness={0.4} emissive="#365314" emissiveIntensity={0.6} />
            </mesh>
          ))}
        </group>

        <Label text="TITANIUM IMPLANT SCREW" position={[-4.2, 0.7, 0]} size={0.4} color="#e5e7eb" />
        <Label text="INFLAMED GUM — peri-implant pocket" position={[0, 3.6, 0]} size={0.42} color="#fca5a5" />
        <Label text="PLAQUE BACTERIA — brush & floss daily!" position={[0, -1.15, 0]} size={0.4} color="#bef264" />

        <Animator gum={gum} bugs={bugs} implant={implant} elapsed={elapsed} inflam={inflam} plaque={plaque} />
      </SimCanvas>
    </div>
  );
}
