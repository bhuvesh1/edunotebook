"use client";
// Concepts of health and disease, levels of prevention.
// A three-tier pyramid — primary, secondary, tertiary prevention —
// with a highlight beam cycling through the levels.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "level", label: "Prevention level", kind: "select", min: 0, max: 0, step: 1, default: "auto", options: ["auto", "primary", "secondary", "tertiary"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Levels of Prevention: The Health Pyramid",
  blurb: "Climb the prevention pyramid: stop disease before it starts, catch it early, or limit its damage.",
};

const LEVELS = [
  { key: "primary", name: "PRIMARY", desc: "Vaccines, clean water — stop disease", color: "#22c55e", y: 0.75, w: 5.6 },
  { key: "secondary", name: "SECONDARY", desc: "Screening — catch it early", color: "#fbbf24", y: 2.05, w: 3.7 },
  { key: "tertiary", name: "TERTIARY", desc: "Rehab — limit disability", color: "#f87171", y: 3.35, w: 1.9 },
];

function Animator({ beam, elapsed, speed, level }: { beam: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; speed: number; level: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (beam.current) {
      const idx = level === "auto" ? Math.floor(elapsed.current * 0.7) % 3 : LEVELS.findIndex((l) => l.key === level);
      const L = LEVELS[idx < 0 ? 0 : idx];
      beam.current.position.y += (L.y - beam.current.position.y) * 0.08;
      (beam.current.material as THREE.MeshStandardMaterial).color.set(L.color);
      (beam.current.material as THREE.MeshStandardMaterial).emissive.set(L.color);
    }
  });
  return null;
}

export function Topic10166Sim(props: SimProps) {
  const level = String(props.level ?? "auto");
  const speed = Number(props.speed ?? 1);
  const beam = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const activeIdx = level === "auto" ? -1 : LEVELS.findIndex((l) => l.key === level);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Focus", level === "auto" ? "cycling…" : LEVELS[activeIdx]?.desc ?? ""]]} />
      <SimCanvas cameraPosition={[0, 3.4, 12]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {LEVELS.map((L, i) => (
          <group key={L.key}>
            <mesh position={[0, L.y, 0]} castShadow>
              <boxGeometry args={[L.w, 1.15, 3.4]} />
              <meshStandardMaterial color={L.color} roughness={0.65} transparent opacity={activeIdx === -1 || activeIdx === i ? 1 : 0.35} />
            </mesh>
            <Label text={L.name} position={[-L.w / 2 - 1.6, L.y, 0]} size={0.55} color={L.color} />
            <Label text={L.desc} position={[L.w / 2 + 2.6, L.y, 0]} size={0.45} color="#e2e8f0" />
          </group>
        ))}
        {/* highlight beam */}
        <mesh ref={beam} position={[0, 0.75, 0]}>
          <boxGeometry args={[6.4, 1.3, 3.7]} />
          <meshStandardMaterial color="#22c55e" transparent opacity={0.18} emissive="#22c55e" emissiveIntensity={0.5} depthWrite={false} />
        </mesh>
        {/* person climbing */}
        <group position={[4.6, 0, 0]}>
          <mesh position={[0, 0.8, 0]} castShadow>
            <capsuleGeometry args={[0.4, 0.9, 6, 12]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.7} />
          </mesh>
          <mesh position={[0, 1.95, 0]}>
            <sphereGeometry args={[0.34, 16, 16]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
          <Label text="YOU" position={[0, 2.8, 0]} size={0.55} color="#fbbf24" />
        </group>
        <Animator beam={beam} elapsed={elapsed} speed={speed} level={level} />
      </SimCanvas>
    </div>
  );
}
