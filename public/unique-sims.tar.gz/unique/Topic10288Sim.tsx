// Gynecology: genital prolapse, urinary incontinence.
// The pelvic floor is a hammock holding bladder, uterus and rectum. When it
// weakens, the uterus slides down (prolapse) or the bladder leaks on coughing.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "prolapse", options: ["normal", "prolapse", "incontinence"] },
  { key: "severity", label: "Severity", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.7, unit: "" },
];

export const UNIQUE_META = {
  title: "Pelvic Floor: Prolapse & Leaks",
  blurb: "A hammock of muscle holds the pelvic organs — watch the uterus slip down in prolapse, or urine leak with a cough.",
};

function Animator({
  group, uterus, floor, leaks, elapsed, severity, condition,
}: {
  group: React.RefObject<THREE.Group>;
  uterus: React.RefObject<THREE.Mesh>;
  floor: React.RefObject<THREE.Mesh>;
  leaks: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  severity: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // prolapse: uterus descends with severity; sags more when "bearing down"
    if (uterus.current) {
      const drop = condition === "prolapse" ? severity * 1.6 : 0;
      const strain = condition === "prolapse" ? Math.max(0, Math.sin(t * 1.4)) * 0.25 : 0;
      uterus.current.position.y = 2.5 - drop - strain;
    }
    // pelvic floor hammock sags
    if (floor.current) {
      const sag = condition === "prolapse" ? severity : 0;
      floor.current.scale.set(1 + sag * 0.15, 1 - sag * 0.5, 1 + sag * 0.15);
    }
    // incontinence: cough bursts leak drops
    if (leaks.current) {
      leaks.current.visible = condition === "incontinence";
      const cough = Math.pow(Math.max(0, Math.sin(t * 1.8)), 8); // sharp cough spikes
      leaks.current.children.forEach((d, i) => {
        const ph = ((t * 2 + i / leaks.current!.children.length) % 1);
        d.position.set(Math.sin(i * 2.2) * 0.15, 1.55 - ph * 1.5, 0.9);
        d.visible = cough > 0.3 || ph < 0.2;
      });
    }
  });
  return null;
}

export function Topic10288Sim(props: SimProps) {
  const condition = String(props.condition ?? "prolapse");
  const severity = Number(props.severity ?? 0.7);
  const group = useRef<THREE.Group>(null!);
  const uterus = useRef<THREE.Mesh>(null!);
  const floor = useRef<THREE.Mesh>(null!);
  const leaks = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = { normal: "Strong pelvic floor", prolapse: "Uterine prolapse", incontinence: "Stress incontinence" };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Severity", `${Math.round(severity * 100)}%`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* pelvic bones */}
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 1.8, 1.6, 0]} rotation={[0, 0, s * 0.3]} castShadow>
              <torusGeometry args={[1.1, 0.26, 14, 24, Math.PI * 1.15]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
            </mesh>
          ))}
          {/* pelvic floor hammock */}
          <mesh ref={floor} position={[0, 1.05, 0]} scale={[1.9, 0.35, 1.3]} castShadow>
            <sphereGeometry args={[1.0, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <meshStandardMaterial color={condition === "normal" ? "#4ade80" : "#f87171"} roughness={0.6}
              emissive={condition === "normal" ? "#166534" : "#7f1d1d"} emissiveIntensity={0.35} />
          </mesh>
          {/* bladder (front) */}
          <mesh position={[0, 2.1, 0.95]} scale={[0.85, 0.8, 0.7]} castShadow>
            <sphereGeometry args={[0.62, 22, 16]} />
            <meshStandardMaterial color="#fb923c" roughness={0.5} transparent opacity={0.85} />
          </mesh>
          {/* urethra */}
          <mesh position={[0, 1.25, 0.95]} castShadow>
            <cylinderGeometry args={[0.1, 0.1, 0.9, 10]} />
            <meshStandardMaterial color="#f0abfc" roughness={0.5} />
          </mesh>
          {/* uterus (middle) — descends in prolapse */}
          <mesh ref={uterus} position={[0, 2.5, -0.1]} scale={[0.95, 1.1, 0.8]} castShadow>
            <sphereGeometry args={[0.85, 26, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
          </mesh>
          {/* rectum (back) */}
          <mesh position={[0, 2.0, -1.15]} castShadow>
            <cylinderGeometry args={[0.32, 0.32, 2.2, 14]} />
            <meshStandardMaterial color="#b45309" roughness={0.6} />
          </mesh>
          {/* leaking urine drops */}
          <group ref={leaks} visible={false}>
            {Array.from({ length: 10 }).map((_, i) => (
              <mesh key={i}>
                <sphereGeometry args={[0.09, 8, 6]} />
                <meshBasicMaterial color="#facc15" />
              </mesh>
            ))}
          </group>
          <Label text="Bladder" position={[1.6, 2.5, 0.95]} size={0.5} color="#fdba74" />
          <Label text="Uterus" position={[-1.7, 2.9, -0.1]} size={0.5} color="#f9a8d4" />
          <Label text="Pelvic floor muscle" position={[0, 0.35, 0]} size={0.5} color={condition === "normal" ? "#86efac" : "#fca5a5"} />
          {condition === "prolapse" && <Label text="⚠ Uterus slipping down" position={[1.9, 1.6, -0.1]} size={0.55} color="#fca5a5" />}
          {condition === "incontinence" && <Label text="🤧 Cough → leak!" position={[1.6, 1.2, 0.95]} size={0.55} color="#fde68a" />}
          {condition === "normal" && <Label text="Everything held up ✓" position={[0, 3.9, 0]} size={0.55} color="#86efac" />}
        </group>
        <Animator group={group} uterus={uterus} floor={floor} leaks={leaks} elapsed={elapsed} severity={severity} condition={condition} />
      </SimCanvas>
    </div>
  );
}
