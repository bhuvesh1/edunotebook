// Nerve & muscle: muscle contraction — a sarcomere with Z-discs, thin actin
// filaments sliding past thick myosin; calcium sparks trigger the power stroke.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "calcium", label: "Ca²⁺ level", kind: "slider", min: 0, max: 1.5, step: 0.05, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Nerve & Muscle: Sliding Filaments",
  blurb: "Watch actin slide past myosin in the sarcomere — calcium sparks trigger each power stroke.",
};

function Animator({
  actinL, actinR, caSparks, zdiscs, elapsed, calcium, speed,
}: {
  actinL: React.RefObject<THREE.Group>;
  actinR: React.RefObject<THREE.Group>;
  caSparks: React.RefObject<THREE.Group>;
  zdiscs: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  calcium: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // contraction cycle: 0=relaxed, 1=contracted
    const cyc = 0.5 + 0.5 * Math.sin(t * 2.2);
    const slide = cyc * 0.55 * Math.min(calcium, 1.2);
    if (actinL.current) actinL.current.position.x = slide;
    if (actinR.current) actinR.current.position.x = -slide;
    if (zdiscs.current) {
      zdiscs.current.children.forEach((m, i) => {
        m.position.x = (i === 0 ? -3 : 3) * (1 - 0.12 * cyc * Math.min(calcium, 1.2));
      });
    }
    if (caSparks.current) {
      caSparks.current.children.forEach((m, i) => {
        const burst = Math.max(0, Math.sin(t * 2.2 - 0.6));
        const mat = (m as THREE.Mesh).material as THREE.MeshBasicMaterial;
        mat.opacity = calcium > 0.05 ? burst * Math.min(1, calcium) : 0;
        m.position.y = 1.6 + Math.sin(t * 6 + i * 2.2) * 0.5;
      });
    }
  });
  return null;
}

export function Topic10036Sim(props: SimProps) {
  const calcium = Number(props.calcium ?? 1);
  const speed = Number(props.speed ?? 1);
  const actinL = useRef<THREE.Group>(null!);
  const actinR = useRef<THREE.Group>(null!);
  const caSparks = useRef<THREE.Group>(null!);
  const zdiscs = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const thinXs = [-2.2, -1.8, -1.4];
  const myosinXs = [-0.7, -0.35, 0, 0.35, 0.7];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Sarcomere", "Z-disc → Z-disc"],
          ["Sliding filaments", calcium > 0.05 ? "contracting" : "relaxed (no Ca²⁺)"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 13]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* Z-discs */}
        <group ref={zdiscs}>
          {[-3, 3].map((x, i) => (
            <mesh key={i} position={[x, 1.5, 0]} castShadow>
              <boxGeometry args={[0.18, 2.6, 2.6]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.4} />
            </mesh>
          ))}
        </group>
        <Label text="Z-disc" position={[-3, 3.3, 0]} size={0.36} color="#f8fafc" />

        {/* thick myosin filaments (centre, with cross-bridge heads) */}
        <group position={[0, 1.5, 0]}>
          {myosinXs.map((x, i) => (
            <group key={i} position={[x, 0, (i % 3 - 1) * 0.45]}>
              <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
                <cylinderGeometry args={[0.14, 0.14, 2.6, 10]} />
                <meshStandardMaterial color="#3b82f6" roughness={0.4} />
              </mesh>
              {[-0.8, -0.3, 0.3, 0.8].map((y, j) => (
                <mesh key={j} position={[0.22, y, 0]} rotation={[0, 0, -0.7]}>
                  <boxGeometry args={[0.3, 0.08, 0.08]} />
                  <meshStandardMaterial color="#93c5fd" roughness={0.4} />
                </mesh>
              ))}
            </group>
          ))}
        </group>
        <Label text="myosin (thick)" position={[0, 3.35, 0]} size={0.34} color="#93c5fd" />

        {/* thin actin filaments sliding in from both Z-discs */}
        <group ref={actinL}>
          {thinXs.map((x, i) => (
            <mesh key={i} position={[x, 1.5, (i - 1) * 0.45]} rotation={[0, 0, Math.PI / 2]} castShadow>
              <cylinderGeometry args={[0.09, 0.09, 2.4, 8]} />
              <meshStandardMaterial color="#f87171" roughness={0.45} />
            </mesh>
          ))}
        </group>
        <group ref={actinR}>
          {thinXs.map((x, i) => (
            <mesh key={i} position={[-x, 1.5, (i - 1) * 0.45]} rotation={[0, 0, Math.PI / 2]} castShadow>
              <cylinderGeometry args={[0.09, 0.09, 2.4, 8]} />
              <meshStandardMaterial color="#f87171" roughness={0.45} />
            </mesh>
          ))}
        </group>
        <Label text="actin (thin) — slides inward" position={[-1.8, 0.35, 0]} size={0.32} color="#fca5a5" />

        {/* titin springs */}
        {[-0.9, 0.9].map((x, i) => (
          <mesh key={i} position={[x, 0.75, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.05, 0.05, 2.2, 6]} />
            <meshStandardMaterial color="#a78bfa" roughness={0.5} />
          </mesh>
        ))}
        <Label text="titin (elastic)" position={[2.2, 0.75, 0]} size={0.28} color="#c4b5fd" />

        {/* Ca2+ sparks */}
        <group ref={caSparks}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[-2 + (i % 4), 1.6, ((i * 1.3) % 3 - 1) * 0.5]}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshBasicMaterial color="#fef08a" transparent opacity={0.8} />
            </mesh>
          ))}
        </group>
        <Label text="Ca²⁺ sparks" position={[-2.4, 2.75, 0]} size={0.3} color="#fef08a" />

        <Animator actinL={actinL} actinR={actinR} caSparks={caSparks} zdiscs={zdiscs}
          elapsed={elapsed} calcium={calcium} speed={speed} />
      </SimCanvas>
    </div>
  );
}
