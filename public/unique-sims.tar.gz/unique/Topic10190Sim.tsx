"use client";
// Nose: sinusitis — acute, chronic, complications; epistaxis.
// Four sinus cavities around the nose fill with glowing mucus; switch
// to nosebleed and watch red drips fall from the nostril.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "sinusitis", options: ["sinusitis", "epistaxis"] },
  { key: "severity", label: "Severity", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
];

export const UNIQUE_META = {
  title: "Sinusitis & Nosebleeds (Epistaxis)",
  blurb: "Four sinus caves fill with mucus in sinusitis — or pinch and lean forward as a nosebleed drips in epistaxis.",
};

function Animator({ mucus, drips, elapsed, severity, condition }: { mucus: React.RefObject<THREE.Group>; drips: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; severity: number; condition: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (mucus.current) {
      mucus.current.visible = condition === "sinusitis";
      mucus.current.children.forEach((m) => {
        const target = 0.25 + (severity / 100) * 0.75;
        const s = m.scale.y + (target - m.scale.y) * 0.06;
        m.scale.set(1, s, 1);
        m.position.y = -0.35 + s * 0.35;
      });
    }
    if (drips.current) {
      drips.current.visible = condition === "epistaxis";
      drips.current.children.forEach((d, i) => {
        const ph = (elapsed.current * (0.6 + severity / 120) + i * 0.25) % 1;
        d.position.y = 1.5 - ph * 1.5;
        d.visible = ph < 0.95;
      });
    }
  });
  return null;
}

const SINUSES: [string, [number, number, number], number][] = [
  ["Frontal", [-1.3, 4.6, 0], 0.55],
  ["Frontal", [1.3, 4.6, 0], 0.55],
  ["Maxillary", [-1.7, 2.5, 0], 0.7],
  ["Maxillary", [1.7, 2.5, 0], 0.7],
];

export function Topic10190Sim(props: SimProps) {
  const condition = String(props.condition ?? "sinusitis");
  const severity = Number(props.severity ?? 55);
  const mucus = useRef<THREE.Group>(null!);
  const drips = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", condition], ["Advice", condition === "sinusitis" ? "Steam + decongestants" : "Pinch nose, lean forward"]]} />
      <SimCanvas cameraPosition={[0, 3.2, 13]} target={[0, 2.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* face outline */}
        <mesh position={[0, 3, -0.9]} castShadow>
          <sphereGeometry args={[2.9, 24, 20]} />
          <meshStandardMaterial color="#f5c9a0" transparent opacity={0.28} roughness={0.7} />
        </mesh>
        {/* nose */}
        <mesh position={[0, 3, 0.9]} castShadow>
          <coneGeometry args={[0.7, 1.8, 12]} />
          <meshStandardMaterial color="#fcd9b8" roughness={0.65} />
        </mesh>
        {/* sinus cavities */}
        <group ref={mucus}>
          {SINUSES.map(([name, pos, r], i) => (
            <group key={i} position={[pos[0], pos[1], pos[2]]}>
              <mesh>
                <sphereGeometry args={[r, 16, 16]} />
                <meshStandardMaterial color="#e0f2fe" transparent opacity={0.35} roughness={0.4} />
              </mesh>
              <mesh position={[0, -0.35, 0]}>
                <sphereGeometry args={[r * 0.92, 14, 14]} />
                <meshStandardMaterial color="#fbbf24" transparent opacity={0.8} roughness={0.35} emissive="#f59e0b" emissiveIntensity={0.4} />
              </mesh>
              {i < 2 && <Label text={name.toUpperCase()} position={[0, r + 0.55, 0]} size={0.42} color="#7dd3fc" />}
            </group>
          ))}
        </group>
        <Label text="SINUSES" position={[0, 6.1, 0]} size={0.6} color="#7dd3fc" />
        {/* nosebleed drips */}
        <group ref={drips}>
          {[0, 1, 2, 3].map((i) => (
            <mesh key={i} position={[0.1, 1.5 - i * 0.35, 1.35]}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshStandardMaterial color="#ef4444" emissive="#dc2626" emissiveIntensity={0.8} />
            </mesh>
          ))}
        </group>
        {condition === "epistaxis" && (
          <group>
            <Label text="🩸 NOSEBLEED" position={[0, 5, 1.2]} size={0.65} color="#f87171" />
            <Label text="pinch + lean forward" position={[0, 0.7, 1.2]} size={0.5} color="#fca5a5" />
          </group>
        )}
        <Animator mucus={mucus} drips={drips} elapsed={elapsed} severity={severity} condition={condition} />
      </SimCanvas>
    </div>
  );
}
