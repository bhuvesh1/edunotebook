// Orthopedic implants and fixation principles.
// How broken bones are held: a plate screwed across the fracture, a nail down
// the marrow canal, or an external frame of pins — each with its own logic.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "implant", label: "Implant", kind: "select", min: 0, max: 0, step: 1, default: "plate", options: ["plate", "nail", "external"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Fixing Bones: Plates, Nails, Frames",
  blurb: "Plate screwed on, nail down the middle, or pins from outside — three ways surgeons hold a broken bone.",
};

function Animator({
  group, stress, elapsed, speed,
}: {
  group: React.RefObject<THREE.Group>;
  stress: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // load arrows pulse to show the implant carrying force across the break
    if (stress.current) {
      stress.current.children.forEach((a, i) => {
        const s = 0.7 + 0.3 * Math.sin(t * 3 + i * 1.5);
        a.scale.set(s, s, s);
      });
    }
  });
  return null;
}

export function Topic10307Sim(props: SimProps) {
  const implant = String(props.implant ?? "plate");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const stress = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    plate: "Plate + screws", nail: "Intramedullary nail", external: "External fixator",
  };
  const how: Record<string, string> = {
    plate: "Screws grip both fragments",
    nail: "Rod inside shares the load",
    external: "Pins hold from outside the skin",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Implant", names[implant] ?? implant], ["Principle", how[implant] ?? ""], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10.5]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* broken tibia: two fragments */}
          <mesh position={[0, 3.1, 0]} castShadow>
            <cylinderGeometry args={[0.3, 0.3, 1.7, 16]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <mesh position={[0.08, 1.15, 0]} rotation={[0, 0, -0.05]} castShadow>
            <cylinderGeometry args={[0.3, 0.3, 1.7, 16]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          {/* marrow canal hint */}
          <mesh position={[0, 3.1, 0]}>
            <cylinderGeometry args={[0.14, 0.14, 1.72, 10]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.6} />
          </mesh>
          <mesh position={[0.08, 1.15, 0]}>
            <cylinderGeometry args={[0.14, 0.14, 1.72, 10]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.6} />
          </mesh>

          {implant === "plate" && (
            <group>
              <mesh position={[0.04, 2.15, 0.36]} castShadow>
                <boxGeometry args={[0.34, 3.0, 0.09]} />
                <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
              </mesh>
              {[-1.1, -0.55, 0.55, 1.1].map((dy, i) => (
                <mesh key={i} position={[0.04, 2.15 + dy, 0.36]} rotation={[Math.PI / 2, 0, 0]} castShadow>
                  <cylinderGeometry args={[0.08, 0.08, 0.4, 10]} />
                  <meshStandardMaterial color="#64748b" metalness={0.85} roughness={0.3} />
                </mesh>
              ))}
            </group>
          )}
          {implant === "nail" && (
            <group>
              <mesh position={[0.04, 2.15, 0]} castShadow>
                <cylinderGeometry args={[0.13, 0.13, 3.4, 12]} />
                <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.25} />
              </mesh>
              {[-1.3, 1.35].map((dy, i) => (
                <mesh key={i} position={[0.04, 2.15 + dy, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
                  <cylinderGeometry args={[0.06, 0.06, 0.8, 8]} />
                  <meshStandardMaterial color="#64748b" metalness={0.85} roughness={0.3} />
                </mesh>
              ))}
            </group>
          )}
          {implant === "external" && (
            <group>
              {/* skin tube */}
              <mesh position={[0.04, 2.15, 0]} castShadow>
                <cylinderGeometry args={[0.55, 0.55, 3.4, 16, 1, true]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} transparent opacity={0.45} side={THREE.DoubleSide} />
              </mesh>
              {/* pins through skin into bone */}
              {[-1.2, -0.4, 0.5, 1.2].map((dy, i) => (
                <mesh key={i} position={[0.35, 2.15 + dy, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
                  <cylinderGeometry args={[0.05, 0.05, 1.6, 8]} />
                  <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
                </mesh>
              ))}
              {/* external bar */}
              <mesh position={[1.15, 2.15, 0]} castShadow>
                <cylinderGeometry args={[0.09, 0.09, 3.2, 10]} />
                <meshStandardMaterial color="#38bdf8" metalness={0.7} roughness={0.35} />
              </mesh>
              {[-1.2, -0.4, 0.5, 1.2].map((dy, i) => (
                <mesh key={i} position={[0.75, 2.15 + dy, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
                  <cylinderGeometry args={[0.06, 0.06, 0.85, 8]} />
                  <meshStandardMaterial color="#0284c7" metalness={0.7} roughness={0.35} />
                </mesh>
              ))}
            </group>
          )}
          {/* load arrows showing force flowing through the implant */}
          <group ref={stress}>
            <mesh position={[0, 4.35, 0]} rotation={[Math.PI, 0, 0]} castShadow>
              <coneGeometry args={[0.16, 0.4, 10]} />
              <meshStandardMaterial color="#4ade80" emissive="#166534" emissiveIntensity={0.6} />
            </mesh>
            <mesh position={[0, 0.05, 0]} castShadow>
              <coneGeometry args={[0.16, 0.4, 10]} />
              <meshStandardMaterial color="#4ade80" emissive="#166534" emissiveIntensity={0.6} />
            </mesh>
          </group>
          <Label text="Broken tibia" position={[-1.9, 2.6, 0]} size={0.5} color="#f8fafc" />
          <Label text={how[implant]} position={[0, -0.45, 0]} size={0.55} color="#86efac" />
          {implant === "plate" && <Label text="Plate + 4 screws" position={[1.9, 2.9, 0.36]} size={0.5} color="#cbd5e1" />}
          {implant === "nail" && <Label text="Nail down the canal" position={[1.9, 2.9, 0]} size={0.5} color="#cbd5e1" />}
          {implant === "external" && <Label text="Frame outside skin" position={[2.3, 2.9, 0]} size={0.5} color="#7dd3fc" />}
        </group>
        <Animator group={group} stress={stress} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
