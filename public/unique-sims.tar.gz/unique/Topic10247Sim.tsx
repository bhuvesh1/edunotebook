// Gallstones, cholecystitis & obstructive jaundice — the gallbladder
// inflames (wall thickens, reddens) as stones multiply; a stone wedges in
// the cystic duct; the bilirubin slider turns the patient yellow.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "bilirubin", label: "Bilirubin", kind: "slider", min: 0.5, max: 20, step: 0.5, default: 8, unit: " mg/dL" },
  { key: "inflame", label: "Gallbladder inflammation", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
];

export const UNIQUE_META = {
  title: "Gallstones & Jaundice",
  blurb: "Stones jam the gallbladder neck, its wall thickens red, and rising bilirubin turns the patient yellow — obstructive jaundice.",
};

function Animator({ stones, elapsed }: {
  stones: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (stones.current) {
      stones.current.children.forEach((c, i) => {
        c.rotation.x = t * (0.5 + i * 0.12);
        c.rotation.z = t * (0.4 + i * 0.09);
      });
    }
  });
  return null;
}

export function Topic10247Sim(props: SimProps) {
  const bilirubin = Number(props.bilirubin ?? 8);
  const inflame = Number(props.inflame ?? 60);
  const stones = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const f = inflame / 100;
  const jaundiced = bilirubin > 3;
  const nStones = Math.round(2 + f * 7);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Bilirubin", `${bilirubin} mg/dL`], ["Jaundice", jaundiced ? "YES — yellow ⚠" : "no"], ["Gallbladder", inflame > 55 ? "cholecystitis — thick red wall" : "mild"]]} />
      <SimCanvas cameraPosition={[0, 3, 12.5]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* liver hint above */}
        <mesh position={[-0.5, 4.6, -0.5]} scale={[1.8, 0.9, 1.0]} castShadow>
          <sphereGeometry args={[1.3, 26, 20]} />
          <meshStandardMaterial color={jaundiced ? "#d6a05c" : "#b45309"} roughness={0.55} />
        </mesh>
        {/* gallbladder: pear, wall thickens with inflammation */}
        <mesh position={[0.4, 3.0, 0.7]} scale={[1 + f * 0.3, 1.35 + f * 0.25, 1 + f * 0.3]} castShadow>
          <sphereGeometry args={[0.8, 24, 18]} />
          <meshStandardMaterial color={f > 0.55 ? "#ef4444" : "#4d7c0f"} roughness={0.5} transparent opacity={0.8} emissive={f > 0.55 ? "#7f1d1d" : "#000"} emissiveIntensity={0.45} />
        </mesh>
        {/* stones inside */}
        <group ref={stones}>
          {Array.from({ length: nStones }).map((_, i) => (
            <mesh key={i} position={[0.4 + ((i * 0.53) % 0.9) - 0.45, 2.9 + ((i * 0.37) % 0.8) - 0.4, 0.7 + ((i * 0.29) % 0.5) - 0.25]}>
              <dodecahedronGeometry args={[0.17 + (i % 3) * 0.05, 0]} />
              <meshStandardMaterial color="#d6a05c" roughness={0.85} flatShading />
            </mesh>
          ))}
        </group>
        {/* cystic duct + common bile duct */}
        <mesh position={[-0.5, 2.3, 0.5]} rotation={[0, 0, Math.PI / 3.2]}>
          <cylinderGeometry args={[0.14, 0.14, 1.5, 10, 1, true]} />
          <meshStandardMaterial color="#a3e635" roughness={0.5} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[-1.2, 1.4, 0.4]} rotation={[0, 0, 0.15]}>
          <cylinderGeometry args={[0.17, 0.17, 2.4, 10, 1, true]} />
          <meshStandardMaterial color={jaundiced ? "#facc15" : "#a3e635"} roughness={0.5} side={THREE.DoubleSide} />
        </mesh>
        {/* impacted stone at the neck */}
        <mesh position={[-0.28, 2.62, 0.55]}>
          <dodecahedronGeometry args={[0.24, 0]} />
          <meshStandardMaterial color="#d6a05c" roughness={0.85} flatShading emissive="#a16207" emissiveIntensity={0.5} />
        </mesh>
        <Label text="Stone impacted at the neck ⚠" position={[-0.28, 3.7, 0.55]} size={0.5} color="#fde047" />

        {/* patient face turning yellow */}
        <group position={[3.6, 2.2, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[1.0, 24, 18]} />
            <meshStandardMaterial color={jaundiced ? new THREE.Color("#f5d0b8").lerp(new THREE.Color("#facc15"), Math.min(0.8, (bilirubin - 3) / 17)) : "#f5d0b8"} roughness={0.65} />
          </mesh>
          {/* yellow eyes */}
          {[-0.35, 0.35].map((x, i) => (
            <mesh key={i} position={[x, 0.15, 0.85]}>
              <sphereGeometry args={[0.18, 12, 10]} />
              <meshStandardMaterial color={jaundiced ? "#facc15" : "#f8fafc"} roughness={0.3} />
            </mesh>
          ))}
          <Label text={jaundiced ? `Jaundiced (${bilirubin} mg/dL)` : "No jaundice"} position={[0, 1.7, 0]} size={0.5} color={jaundiced ? "#fde047" : "#86efac"} />
        </group>

        <Label text="Murphy's sign: pain on pressing under right ribs" position={[0, -1.2, 0]} size={0.44} color="#94a3b8" />
        <Animator stones={stones} elapsed={elapsed} />
      </SimCanvas>
    </div>
  );
}
