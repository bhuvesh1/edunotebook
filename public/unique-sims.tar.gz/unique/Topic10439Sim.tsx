"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ptype", label: "Prosthesis", kind: "select", min: 0, max: 0, step: 1, default: "overdenture", options: ["overdenture", "fixed"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Implant-supported prostheses: overdentures, fixed implant prosthesis",
  blurb: "Titanium implants screwed into bone — snap a removable overdenture on and off, or fix a permanent bridge on top.",
};

function Implant({ x }: { x: number }) {
  return (
    <group position={[x, -0.6, 0]}>
      {/* fixture with threads */}
      <mesh position={[0, -0.5, 0]}>
        <cylinderGeometry args={[0.28, 0.2, 1.6, 12]} />
        <meshStandardMaterial color="#9ca3af" metalness={0.85} roughness={0.3} />
      </mesh>
      {[0, 1, 2, 3].map((i) => (
        <mesh key={i} position={[0, -1.05 + i * 0.36, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.27, 0.045, 8, 16]} />
          <meshStandardMaterial color="#d1d5db" metalness={0.85} roughness={0.3} />
        </mesh>
      ))}
      {/* abutment */}
      <mesh position={[0, 0.45, 0]}>
        <cylinderGeometry args={[0.16, 0.22, 0.5, 10]} />
        <meshStandardMaterial color="#d4af37" metalness={0.8} roughness={0.3} />
      </mesh>
    </group>
  );
}

function Scene({ ptype, speed }: { ptype: string; speed: number }) {
  const denture = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const over = ptype === "overdenture";

  useFrame((_, delta) => {
    t.current += delta * speed;
    if (over && denture.current) {
      // snap on / lift off loop
      const f = (Math.sin(t.current * 1.1) + 1) / 2;
      const eased = f * f * (3 - 2 * f);
      denture.current.position.y = 1.5 + eased * 1.6;
    }
  });

  return (
    <group>
      {/* bone block */}
      <mesh position={[0, -1.9, 0]} receiveShadow>
        <boxGeometry args={[7, 2.0, 2.6]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>
      {/* gum */}
      <mesh position={[0, -0.75, 0]}>
        <boxGeometry args={[7, 0.4, 2.8]} />
        <meshStandardMaterial color="#e0788a" roughness={0.6} />
      </mesh>
      <Label text="Jaw bone" position={[-3.9, -1.9, 0]} size={0.42} color="#fde68a" />

      <Implant x={-1.8} />
      <Implant x={1.8} />
      <Label text="Titanium implant" position={[-1.8, -2.9, 0]} size={0.4} color="#d1d5db" />

      {over ? (
        <group ref={denture} position={[0, 1.5, 0]}>
          {/* overdenture with attachment housings */}
          <mesh rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[2.0, 0.5, 12, 32, Math.PI]} />
            <meshStandardMaterial color="#f472b6" roughness={0.5} />
          </mesh>
          {[-1.8, 1.8].map((x) => (
            <mesh key={x} position={[x, -0.35, 0.4]}>
              <cylinderGeometry args={[0.24, 0.24, 0.3, 12]} />
              <meshStandardMaterial color="#fbbf24" metalness={0.7} roughness={0.35} />
            </mesh>
          ))}
          {[-1.2, -0.4, 0.4, 1.2].map((x, i) => (
            <mesh key={i} position={[x, -0.55, 1.15]}>
              <boxGeometry args={[0.42, 0.5, 0.5]} />
              <meshStandardMaterial color="#fdfbf3" roughness={0.3} />
            </mesh>
          ))}
          <Label text="Overdenture — snaps on!" position={[0, 1.3, 0]} size={0.45} color="#f9a8d4" />
        </group>
      ) : (
        <group>
          {/* fixed bridge screwed to implants */}
          {[-1.8, 1.8].map((x) => (
            <mesh key={x} position={[x, 0.15, 0]}>
              <cylinderGeometry args={[0.2, 0.2, 0.5, 10]} />
              <meshStandardMaterial color="#9ca3af" metalness={0.8} roughness={0.3} />
            </mesh>
          ))}
          <mesh position={[0, 0.35, 0]}>
            <boxGeometry args={[4.6, 0.5, 1.4]} />
            <meshStandardMaterial color="#d4af37" metalness={0.6} roughness={0.35} />
          </mesh>
          {[-1.5, -0.5, 0.5, 1.5].map((x, i) => (
            <mesh key={i} position={[x, 0.85, 0]}>
              <boxGeometry args={[0.5, 0.55, 0.9]} />
              <meshStandardMaterial color="#fdfbf3" roughness={0.25} />
            </mesh>
          ))}
          <Label text="Fixed implant bridge" position={[0, 1.8, 0]} size={0.45} color="#fde68a" />
        </group>
      )}

      {!over && <Label text="Screw-retained — only dentist removes" position={[0, -3.0, 0]} size={0.42} color="#94a3b8" />}
      {over && <Label text="Ball attachments click into the denture" position={[0, -3.0, 0]} size={0.42} color="#e2e8f0" />}
      <Label text={over ? "Implant overdenture" : "Fixed implant prosthesis"} position={[0, 3.6, 0]} size={0.65} color="#f9a8d4" />
    </group>
  );
}

export function Topic10439Sim(props: SimProps) {
  const ptype = String(props.ptype ?? "overdenture");
  const speed = Number(props.speed ?? 1);
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Prosthesis", ptype === "overdenture" ? "Overdenture" : "Fixed bridge"], ["Implants", "2"], ["Retention", ptype === "overdenture" ? "Snap attachments" : "Screws"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, -0.3, 0]}>
        <Scene ptype={ptype} speed={speed} />
      </SimCanvas>
    </div>
  );
}
