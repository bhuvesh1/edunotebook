"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "dilated cardiomyopathy", options: ["normal", "dilated cardiomyopathy", "hypertrophic cardiomyopathy", "pericarditis"] },
  { key: "hr", label: "Heart rate", kind: "slider", min: 40, max: 160, step: 5, default: 75, unit: " bpm" },
];

export const UNIQUE_META = {
  title: "Cardiomyopathy & Pericardium",
  blurb: "A beating heart remodels: dilated and floppy, thick-walled and stiff, or squeezed by pericardial fluid.",
};

function Animator({ root, heart, fluid, elapsed, hr, dcm, hcm, peri }: { root: RefObject<THREE.Group>; heart: RefObject<THREE.Group>; fluid: RefObject<THREE.Mesh>; elapsed: RefObject<number>; hr: number; dcm: boolean; hcm: boolean; peri: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += 0.016;
    const t = elapsed.current;
    if (heart.current) {
      const strength = dcm ? 0.06 : 0.14;
      const beat = 1 + strength * Math.abs(Math.sin(t * hr / 60 * Math.PI * 2));
      const base = dcm ? 1.38 : hcm ? 0.88 : 1;
      heart.current.scale.set(base * beat, base * (2 - beat) * 0.98, base * beat);
      heart.current.rotation.y = Math.sin(t * 0.5) * 0.2;
    }
    if (fluid.current) {
      fluid.current.visible = peri;
      fluid.current.scale.setScalar(1.45 + 0.05 * Math.sin(t * 2));
      (fluid.current.material as THREE.MeshStandardMaterial).opacity = 0.3 + 0.12 * Math.sin(t * 3);
    }
  });
  return null;
}

export function Topic10095Sim(props: SimProps) {
  const hr = Number(props.hr ?? 75);
  const cond = String(props.cond ?? "dilated cardiomyopathy");
  const dcm = cond === "dilated cardiomyopathy";
  const hcm = cond === "hypertrophic cardiomyopathy";
  const peri = cond === "pericarditis";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const heart = useRef<THREE.Group>(null!);
  const fluid = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", cond],
          ["Heart rate", `${hr} bpm`],
          ["Ejection", dcm ? "reduced (HFrEF)" : hcm ? "preserved, stiff (HFpEF)" : peri ? "tamponade risk" : "normal"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <group ref={heart} position={[0, 2, 0]}>
            <mesh castShadow><sphereGeometry args={[1, 26, 26]} /><meshStandardMaterial color={hcm ? "#991b1b" : "#ef4444"} roughness={0.45} /></mesh>
            <mesh position={[0.62, 0.5, 0]}><sphereGeometry args={[0.6, 20, 20]} /><meshStandardMaterial color={hcm ? "#7f1d1d" : "#dc2626"} roughness={0.45} /></mesh>
            <mesh position={[0, 1.25, 0]} rotation={[0.5, 0, 0]}><coneGeometry args={[0.62, 1.1, 16]} /><meshStandardMaterial color={hcm ? "#7f1d1d" : "#b91c1c"} roughness={0.45} /></mesh>
            {hcm && (
              <mesh><sphereGeometry args={[0.55, 16, 16]} /><meshStandardMaterial color="#450a0a" roughness={0.6} /></mesh>
            )}
          </group>
          <mesh ref={fluid} visible={false} position={[0, 2, 0]}>
            <sphereGeometry args={[1.5, 24, 24]} />
            <meshStandardMaterial color="#fde047" transparent opacity={0.3} roughness={0.3} />
          </mesh>
          <Label text={dcm ? "dilated \u2014 thin, weak walls" : hcm ? "hypertrophic \u2014 thick, stiff walls" : peri ? "pericardial effusion" : "normal heart"} position={[0, 4.4, 0]} size={0.48} color={cond === "normal" ? "#4ade80" : "#f87171"} />
          <Label text="LV" position={[-1.5, 2.2, 0]} size={0.42} color="#fca5a5" />
        </group>
        <Animator root={root} heart={heart} fluid={fluid} elapsed={elapsed} hr={hr} dcm={dcm} hcm={hcm} peri={peri} />
      </SimCanvas>
    </div>
  );
}
