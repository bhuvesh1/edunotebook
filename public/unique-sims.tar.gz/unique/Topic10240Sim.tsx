// Critical care — ventilators, vasopressors & ABG. A ventilator box pumps a
// bellows; the tube runs to a patient whose chest rises and falls at the set
// respiratory rate. A vasopressor drip squeezes a vessel; the ABG monitor
// shows pH drifting with the rate.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "rate", label: "Respiratory rate", kind: "slider", min: 6, max: 30, step: 1, default: 14, unit: "/min" },
  { key: "pressor", label: "Vasopressor", kind: "select", min: 0, max: 0, step: 1, default: "off", options: ["off", "noradrenaline"] },
];

export const UNIQUE_META = {
  title: "Critical Care Basics",
  blurb: "A ventilator breathes for the patient — set the rate and watch the chest rise; add noradrenaline and the vessel squeezes while ABG shifts.",
};

function Animator({ bellows, chest, drip, elapsed, rate }: {
  bellows: React.RefObject<THREE.Mesh>;
  chest: React.RefObject<THREE.Mesh>;
  drip: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  rate: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const breath = (Math.sin((t * rate * Math.PI) / 30) + 1) / 2; // 0..1
    if (bellows.current) {
      bellows.current.scale.y = 0.6 + breath * 0.7;
    }
    if (chest.current) {
      chest.current.scale.set(1 + breath * 0.12, 1 + breath * 0.06, 1 + breath * 0.16);
    }
    if (drip.current) {
      drip.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * 1.4 + i * 0.2) % 1);
        m.position.y = 4.4 - ph * 1.8;
      });
    }
  });
  return null;
}

export function Topic10240Sim(props: SimProps) {
  const rate = Number(props.rate ?? 14);
  const pressorOn = String(props.pressor ?? "off") === "noradrenaline";
  const bellows = useRef<THREE.Mesh>(null!);
  const chest = useRef<THREE.Mesh>(null!);
  const drip = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  // ABG drifts: slow rate → CO2 up → acidotic; fast → alkalotic
  const ph = 7.4 + (14 - rate) * 0.008;
  const abgState = ph < 7.35 ? "respiratory acidosis" : ph > 7.45 ? "respiratory alkalosis" : "normal";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Vent rate", `${rate}/min`], ["ABG pH", `${ph.toFixed(2)} — ${abgState}`], ["Vasopressor", pressorOn ? "noradrenaline running" : "off"]]} />
      <SimCanvas cameraPosition={[0, 3, 14]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* ventilator */}
        <group position={[-4.6, 0, 0]}>
          <mesh position={[0, 1.6, 0]} castShadow>
            <boxGeometry args={[2.4, 3.2, 1.8]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.4} />
          </mesh>
          <mesh position={[0, 2.6, 0.95]}>
            <boxGeometry args={[1.7, 0.8, 0.1]} />
            <meshStandardMaterial color="#0ea5e9" roughness={0.3} emissive="#0c4a6e" emissiveIntensity={0.7} />
          </mesh>
          {/* bellows */}
          <mesh ref={bellows} position={[0, 0.9, 1.05]}>
            <cylinderGeometry args={[0.55, 0.55, 1.0, 18]} />
            <meshStandardMaterial color="#38bdf8" transparent opacity={0.75} roughness={0.3} />
          </mesh>
          <Label text="Ventilator" position={[0, 3.8, 0]} size={0.52} color="#7dd3fc" />
        </group>
        {/* breathing tube to patient */}
        <mesh position={[-2.4, 2.6, 0]} rotation={[0, 0, Math.PI / 2.15]}>
          <cylinderGeometry args={[0.18, 0.18, 4.6, 12]} />
          <meshStandardMaterial color="#94a3b8" roughness={0.4} />
        </mesh>

        {/* patient on bed */}
        <mesh position={[2.2, 0.7, 0]} castShadow>
          <boxGeometry args={[5.6, 0.5, 2.4]} />
          <meshStandardMaterial color="#334155" roughness={0.6} />
        </mesh>
        <group position={[2.2, 0, 0]}>
          <mesh position={[-1.4, 1.75, 0]} castShadow>
            <sphereGeometry args={[0.62, 20, 16]} />
            <meshStandardMaterial color="#f5d0b8" roughness={0.65} />
          </mesh>
          <mesh ref={chest} position={[0.4, 1.55, 0]} scale={[1.5, 0.85, 1.0]} castShadow>
            <sphereGeometry args={[0.95, 22, 16]} />
            <meshStandardMaterial color="#93c5fd" roughness={0.65} />
          </mesh>
          <mesh position={[0.4, 1.15, 0]}>
            <boxGeometry args={[2.6, 0.35, 1.9]} />
            <meshStandardMaterial color="#1e3a8a" roughness={0.7} />
          </mesh>
        </group>
        <Label text="Chest rises & falls with the vent" position={[2.6, 3.4, 0]} size={0.48} color="#93c5fd" />

        {/* vasopressor drip + vessel */}
        {pressorOn && (
          <group>
            <mesh position={[5.6, 5.0, -1]}>
              <boxGeometry args={[0.7, 1.0, 0.5]} />
              <meshStandardMaterial color="#fde68a" transparent opacity={0.8} roughness={0.3} />
            </mesh>
            <group ref={drip}>
              {Array.from({ length: 5 }).map((_, i) => (
                <mesh key={i} position={[5.6, 4.4, -1]}>
                  <sphereGeometry args={[0.08, 8, 8]} />
                  <meshBasicMaterial color="#facc15" />
                </mesh>
              ))}
            </group>
            <mesh position={[5.6, 2.6, -1]} rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.5, 0.5, 3.0, 14, 1, true]} />
              <meshStandardMaterial color="#dc2626" roughness={0.5} side={THREE.DoubleSide} />
            </mesh>
            <mesh position={[5.6, 2.6, -1]} rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.34, 0.34, 3.0, 14]} />
              <meshStandardMaterial color="#7f1d1d" roughness={0.6} />
            </mesh>
            <Label text="Noradrenaline squeezes vessels → BP up" position={[5.6, 6.2, -1]} size={0.46} color="#fde047" />
          </group>
        )}

        <Animator bellows={bellows} chest={chest} drip={drip} elapsed={elapsed} rate={rate} />
      </SimCanvas>
    </div>
  );
}
