// Diagnostic methods: colonies bloom on the petri dish over incubation time,
// the test tube flips color on a positive, and the PCR cycler pulses through
// its temperature stages.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "time", label: "Incubation time", kind: "slider", min: 0, max: 48, step: 2, default: 24, unit: "h" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Diagnostic methods",
  blurb: "Colonies bloom on the petri dish, the test tube flips color, and PCR cycles its temperatures.",
};

const N_COL = 14;

function Animator({ cols, tubeLiq, pcr, pcrLight, elapsed, time, setTick }: {
  cols: React.RefObject<(THREE.Mesh | null)[]>;
  tubeLiq: React.RefObject<THREE.Mesh>;
  pcr: React.RefObject<THREE.Group>;
  pcrLight: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  time: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  const stages = ["denature 95°C", "anneal 55°C", "extend 72°C"];
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const growth = Math.min(1, time / 36);
    let grown = 0;
    cols.current.forEach((c, i) => {
      if (!c) return;
      const th = ((i * 41) % 10) / 10;
      const g = Math.max(0.02, Math.min(1, (growth - th * 0.4) * 2.2));
      if (g > 0.1) grown++;
      c.scale.set(g, g * 0.55, g);
      c.visible = g > 0.06;
    });
    if (tubeLiq.current) {
      // positive result: liquid turns from blue to pink as incubation passes 12h
      const pos = time >= 12;
      const m = tubeLiq.current.material as THREE.MeshStandardMaterial;
      m.color.set(pos ? "#f472b6" : "#38bdf8");
      m.emissive.set(m.color.getHex());
      m.emissiveIntensity = 0.3 + Math.sin(t * 3) * 0.15;
    }
    if (pcr.current && pcrLight.current) {
      const stage = Math.floor(t * 0.8) % 3;
      pcr.current.rotation.y = t * 0.3;
      const lm = pcrLight.current.material as THREE.MeshStandardMaterial;
      lm.color.set(["#ef4444", "#38bdf8", "#4ade80"][stage]);
      lm.emissive.set(lm.color.getHex());
      lm.emissiveIntensity = 1.2;
      if (Math.abs(t - last.current) > 0.3) setTick(stage * 100 + grown);
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; }
  });
  return null;
}

export function Topic10149Sim(props: SimProps) {
  const time = Number(props.time ?? 24);
  const showLabels = String(props.detail ?? "on") === "on";
  const cols = useRef<(THREE.Mesh | null)[]>([]);
  const tubeLiq = useRef<THREE.Mesh>(null!);
  const pcr = useRef<THREE.Group>(null!);
  const pcrLight = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const stageIdx = Math.floor(tick / 100) % 3;
  const grown = tick % 100;
  const stages = ["denature 95°C", "anneal 55°C", "extend 72°C"];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Colonies grown", `${grown}`],
          ["Serology tube", time >= 12 ? "POSITIVE" : "pending…"],
          ["PCR stage", stages[stageIdx]],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 13]} target={[0, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* petri dish with agar */}
        <group position={[-3.6, 0.5, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[1.9, 1.9, 0.35, 28]} />
            <meshStandardMaterial color="#e2e8f0" transparent opacity={0.5} roughness={0.15} />
          </mesh>
          <mesh position={[0, 0.12, 0]}>
            <cylinderGeometry args={[1.75, 1.75, 0.12, 28]} />
            <meshStandardMaterial color="#fde68a" roughness={0.6} />
          </mesh>
          {Array.from({ length: N_COL }).map((_, i) => {
            const a = (i / N_COL) * Math.PI * 2 + 0.4;
            const r = 0.4 + ((i * 53) % 10) / 10 * 1.1;
            return (
              <mesh
                key={i}
                ref={(m) => { cols.current[i] = m; }}
                position={[Math.cos(a) * r, 0.28, Math.sin(a) * r]}
              >
                <sphereGeometry args={[0.22, 12, 10]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
            );
          })}
        </group>
        {showLabels && <Label text="culture — colonies bloom" position={[-3.6, 2.1, 0]} color="#fef3c7" />}

        {/* serology test tube */}
        <group position={[0.4, 0, 0]}>
          <mesh position={[0, 1.1, 0]} castShadow>
            <cylinderGeometry args={[0.32, 0.32, 1.8, 16, 1, true]} />
            <meshStandardMaterial color="#e2e8f0" transparent opacity={0.4} side={THREE.DoubleSide} roughness={0.1} />
          </mesh>
          <mesh ref={tubeLiq} position={[0, 0.75, 0]}>
            <cylinderGeometry args={[0.26, 0.26, 0.9, 14]} />
            <meshStandardMaterial color="#38bdf8" emissive="#38bdf8" emissiveIntensity={0.3} transparent opacity={0.85} />
          </mesh>
          <mesh position={[0, 2.15, 0]}>
            <boxGeometry args={[0.9, 0.12, 0.5]} />
            <meshStandardMaterial color="#64748b" roughness={0.5} />
          </mesh>
        </group>
        {showLabels && <Label text={time >= 12 ? "serology — POSITIVE" : "serology test"} position={[0.4, 2.8, 0]} size={0.45} color={time >= 12 ? "#f9a8d4" : "#7dd3fc"} />}

        {/* PCR thermal cycler */}
        <group ref={pcr} position={[4.2, 0, 0]}>
          <mesh position={[0, 0.8, 0]} castShadow>
            <boxGeometry args={[2.2, 1.6, 1.8]} />
            <meshStandardMaterial color="#334155" roughness={0.45} />
          </mesh>
          <mesh position={[0, 1.75, 0]}>
            <boxGeometry args={[1.8, 0.25, 1.4]} />
            <meshStandardMaterial color="#1e293b" roughness={0.4} />
          </mesh>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[-0.6 + (i % 3) * 0.6, 1.95, (Math.floor(i / 3) - 0.5) * 0.6]}>
              <cylinderGeometry args={[0.12, 0.12, 0.35, 10]} />
              <meshStandardMaterial color="#f472b6" emissive="#be185d" emissiveIntensity={0.5} />
            </mesh>
          ))}
          <mesh ref={pcrLight} position={[0, 0.8, 0.95]}>
            <sphereGeometry args={[0.14, 10, 8]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={1.2} />
          </mesh>
        </group>
        {showLabels && <Label text={`PCR — ${stages[stageIdx]}`} position={[4.2, 2.9, 0]} size={0.45} color="#f9a8d4" />}

        <Animator cols={cols} tubeLiq={tubeLiq} pcr={pcr} pcrLight={pcrLight} elapsed={elapsed} time={time} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
