// app/components/sims/unique/Topic10544Sim.tsx
// Pediatric periodontal and mucosal conditions: a child's mouth with red,
// swollen, bleeding gums around the teeth. Inflammation slider controls
// the swelling and redness.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "inflam", label: "Gum inflammation", kind: "slider", min: 0, max: 100, step: 1, default: 60, unit: "%" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Pediatric Periodontal & Mucosal Conditions",
  blurb: "A child's gums swell, redden, and bleed more as inflammation rises — brushing brings it back down.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ gums, bleed, elapsed, speed, inflam }: {
  gums: RefObject<THREE.Group>; bleed: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number; inflam: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const f = inflam / 100;
    if (gums.current) {
      const throb = 1 + f * 0.1 * Math.sin(t * 3.5);
      gums.current.scale.set(1 + f * 0.25, throb, 1 + f * 0.25);
      gums.current.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.isMesh) {
          const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
          mat.color.setHSL(0.98 - f * 0.02, 0.55 + f * 0.3, 0.62 - f * 0.14);
          mat.emissive.set("#ef4444");
          mat.emissiveIntensity = f * (0.25 + 0.15 * Math.sin(t * 3.5));
        }
      });
    }
    if (bleed.current) {
      bleed.current.visible = inflam > 55;
      bleed.current.children.forEach((c, i) => {
        c.position.y = 2.9 - ((t * 0.8 + i * 0.23) % 0.9);
        (c as THREE.Mesh).scale.setScalar(0.5 + ((t * 0.8 + i * 0.23) % 0.9));
      });
    }
  });
  return null;
}

const TEETH_X = [-0.9, -0.54, -0.18, 0.18, 0.54, 0.9];

export function Topic10544Sim(props: SimProps) {
  const inflam = Number(props.inflam ?? 60);
  const speed = Number(props.speed ?? 1);
  const gums = useRef<THREE.Group>(null!);
  const bleed = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const state = inflam < 25 ? "healthy gums" : inflam < 55 ? "gingivitis — bleeds on brushing" : "severe inflammation — spontaneous bleeding";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Status", state],
          ["Cause", "plaque at the gumline"],
          ["Fix", "brushing + flossing"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 9]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* smaller child face */}
        <mesh position={[0, 2.7, -0.7]} castShadow>
          <sphereGeometry args={[2.1, 32, 32]} />
          <meshStandardMaterial color="#f5c9a3" roughness={0.7} />
        </mesh>
        {/* open mouth */}
        <mesh position={[0, 2.5, 1.0]}>
          <sphereGeometry args={[1.15, 24, 24]} />
          <meshStandardMaterial color="#5b1a1a" roughness={0.9} />
        </mesh>
        <mesh position={[0, 2.5, 1.3]} scale={[1.3, 0.85, 0.6]} castShadow>
          <torusGeometry args={[0.95, 0.26, 14, 32]} />
          <meshStandardMaterial color="#e0788a" roughness={0.55} />
        </mesh>

        {/* gums: swell + redden with inflammation */}
        <group ref={gums}>
          <mesh position={[0, 3.05, 1.25]} scale={[1.45, 0.5, 0.7]} castShadow>
            <sphereGeometry args={[0.8, 20, 20]} />
            <meshStandardMaterial color="#e0607a" roughness={0.55} />
          </mesh>
          <mesh position={[0, 2.0, 1.2]} scale={[1.35, 0.45, 0.65]} castShadow>
            <sphereGeometry args={[0.75, 20, 20]} />
            <meshStandardMaterial color="#e0607a" roughness={0.55} />
          </mesh>
        </group>

        {/* teeth poking through the gums */}
        {TEETH_X.map((x, i) => (
          <mesh key={i} position={[x, 2.78, 1.5]} castShadow>
            <boxGeometry args={[0.3, 0.42, 0.25]} />
            <meshStandardMaterial color="#ffffff" roughness={0.3} />
          </mesh>
        ))}
        {/* plaque film at the gumline (grows with inflammation) */}
        {inflam > 20 && (
          <mesh position={[0, 2.95, 1.62]} scale={[1.5, 0.18, 0.3]}>
            <sphereGeometry args={[0.8, 16, 16]} />
            <meshStandardMaterial color="#fde68a" transparent opacity={0.25 + (inflam / 100) * 0.4} roughness={0.9} />
          </mesh>
        )}

        {/* bleeding droplets */}
        <group ref={bleed} visible={false}>
          {[...Array(8)].map((_, i) => (
            <mesh key={i} position={[-0.9 + i * 0.26, 2.9, 1.55]}>
              <sphereGeometry args={[0.06, 8, 8]} />
              <meshStandardMaterial color="#dc2626" roughness={0.3} />
            </mesh>
          ))}
        </group>

        <Label p={[2.5, 3.1, 1.2]} size={0.3} color="#fca5a5">swollen red gums</Label>
        <Label p={[-2.5, 2.2, 1.2]} size={0.3} color="#fde68a">plaque at gumline</Label>
        <Label p={[0, 5.0, 0.4]} size={0.32} color="#e2e8f0">child's mouth — {state}</Label>

        <Animator gums={gums} bleed={bleed} elapsed={elapsed} speed={speed} inflam={inflam} />
      </SimCanvas>
    </div>
  );
}
