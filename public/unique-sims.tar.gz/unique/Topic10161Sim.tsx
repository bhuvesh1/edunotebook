"use client";
// Toxicology: neurotoxic poisons — opium, barbiturates, alcohol.
// A glowing brain sends signal sparks down nerve paths; raise the dose
// and watch the sparks slow, dim and finally stop.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "poison", label: "Poison", kind: "select", min: 0, max: 0, step: 1, default: "alcohol", options: ["opium", "barbiturates", "alcohol"] },
  { key: "dose", label: "Dose", kind: "slider", min: 0, max: 100, step: 5, default: 30, unit: "%" },
];

export const UNIQUE_META = {
  title: "Neurotoxic Poisons: Opium, Barbiturates, Alcohol",
  blurb: "Signal sparks race down the nerves — raise the dose and watch the brain's messages slow to a stop.",
};

const POISON_TXT: Record<string, string> = {
  opium: "Opium: pin-point pupils, slow breathing",
  barbiturates: "Barbiturates: deep sleep → coma",
  alcohol: "Alcohol: slurred speech, unsteady walk",
};
const N_SPARKS = 18;

function Animator({ sparks, paths, elapsed, dose }: { sparks: React.RefObject<THREE.Group>; paths: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; dose: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const vigour = 1 - dose / 100; // 1 = fully awake
    if (sparks.current) {
      sparks.current.children.forEach((s, i) => {
        const lane = i % 3;
        const ph = (elapsed.current * (0.25 + vigour * 1.1) + i * 0.31) % 1;
        const x = (lane - 1) * 1.5;
        s.position.set(x + Math.sin(ph * Math.PI * 2) * 0.15, 3.2 - ph * 3.4, 0);
        const m = (s as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = 0.2 + vigour * 1.1;
        s.visible = ph < 0.15 + vigour * 0.85;
      });
    }
    if (paths.current) {
      paths.current.children.forEach((p) => {
        const m = (p as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = 0.1 + vigour * 0.5;
      });
    }
  });
  return null;
}

export function Topic10161Sim(props: SimProps) {
  const poison = String(props.poison ?? "alcohol");
  const dose = Number(props.dose ?? 30);
  const sparks = useRef<THREE.Group>(null!);
  const paths = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const state = dose < 25 ? "Alert" : dose < 60 ? "Drowsy" : dose < 85 ? "Stupor" : "Coma risk!";
  const stateColor = dose < 25 ? "#22c55e" : dose < 60 ? "#fbbf24" : dose < 85 ? "#fb923c" : "#ef4444";

  const sparkMeshes = useMemo(
    () =>
      Array.from({ length: N_SPARKS }, (_, i) => (
        <mesh key={i} position={[0, 3, 0]}>
          <sphereGeometry args={[0.14, 10, 10]} />
          <meshStandardMaterial color="#fde68a" emissive="#fbbf24" emissiveIntensity={1.2} />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Poison", poison], ["Sign", POISON_TXT[poison] ?? ""], ["Brain state", state]]} />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* brain */}
        <group position={[0, 4.4, 0]}>
          <mesh castShadow>
            <icosahedronGeometry args={[1.1, 1]} />
            <meshStandardMaterial color="#f472b6" roughness={0.55} emissive="#ec4899" emissiveIntensity={0.3} flatShading />
          </mesh>
          <mesh position={[0, 0, 0]} rotation={[0.3, 0, 0]}>
            <torusGeometry args={[1.12, 0.05, 8, 24, Math.PI]} />
            <meshStandardMaterial color="#9d2463" roughness={0.6} />
          </mesh>
          <Label text="BRAIN" position={[0, 1.6, 0]} size={0.6} color="#f9a8d4" />
        </group>
        {/* nerve paths */}
        <group ref={paths}>
          {[-1.5, 0, 1.5].map((x) => (
            <mesh key={x} position={[x, 1.7, 0]}>
              <cylinderGeometry args={[0.09, 0.09, 3.6, 8]} />
              <meshStandardMaterial color="#f9a8d4" emissive="#ec4899" emissiveIntensity={0.5} roughness={0.5} />
            </mesh>
          ))}
        </group>
        <group ref={sparks}>{sparkMeshes}</group>
        {/* body targets */}
        {[[-1.5, "HANDS"], [0, "LEGS"], [1.5, "HEART"]].map(([x, t]) => (
          <group key={t as string} position={[x as number, -0.2, 0]}>
            <mesh castShadow>
              <sphereGeometry args={[0.45, 14, 14]} />
              <meshStandardMaterial color={dose > 60 ? "#7f1d1d" : "#f87171"} roughness={0.6} />
            </mesh>
            <Label text={t as string} position={[0, -0.9, 0]} size={0.5} />
          </group>
        ))}
        <Label text={state} position={[0, 6.3, 0]} size={0.75} color={stateColor} />
        <Animator sparks={sparks} paths={paths} elapsed={elapsed} dose={dose} />
      </SimCanvas>
    </div>
  );
}
