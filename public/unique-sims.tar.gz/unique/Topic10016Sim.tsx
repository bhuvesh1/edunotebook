// Histology: connective tissue, cartilage, bone — three tissue panels side by
// side: loose connective fibres, cartilage with chondrocytes in lacunae, and a
// bone osteon with a pulsing Haversian canal.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "pulse", label: "Blood pulse rate", kind: "slider", min: 0, max: 3, step: 0.1, default: 1.2, unit: "Hz" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Histology: Connective Tissue, Cartilage, Bone",
  blurb: "Loose connective fibres, chondrocytes in lacunae, and a bone osteon with its pulsing Haversian canal.",
};

function Animator({
  osteon, blood, fibres, elapsed, speed, pulse,
}: {
  osteon: React.RefObject<THREE.Group>;
  blood: React.RefObject<THREE.Mesh>;
  fibres: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  pulse: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (osteon.current) osteon.current.rotation.y = t * 0.35;
    if (blood.current) {
      const s = 1 + 0.22 * Math.sin(t * pulse * Math.PI * 2);
      blood.current.scale.set(s, 1, s);
    }
    if (fibres.current) {
      fibres.current.children.forEach((m, i) => {
        m.rotation.z = Math.sin(t * 0.6 + i * 0.9) * 0.06 + (m.userData.baseRot ?? 0);
      });
    }
  });
  return null;
}

export function Topic10016Sim(props: SimProps) {
  const pulse = Number(props.pulse ?? 1.2);
  const speed = Number(props.speed ?? 1);
  const osteon = useRef<THREE.Group>(null!);
  const blood = useRef<THREE.Mesh>(null!);
  const fibres = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  // criss-cross collagen fibres for loose connective tissue
  const fibreSpecs = useMemo(
    () =>
      Array.from({ length: 14 }).map((_, i) => ({
        key: i,
        x: -7.5 + (i % 7) * 1.1,
        z: (i < 7 ? -0.9 : 0.9),
        rot: (i * 0.7) % 1.2 - 0.6,
        len: 1.6 + (i % 3) * 0.5,
      })),
    []
  );
  const osteocytes = useMemo(
    () =>
      Array.from({ length: 10 }).map((_, i) => {
        const a = (i / 10) * Math.PI * 2;
        return [Math.cos(a) * 1.35, Math.sin(a) * 1.35] as [number, number];
      }),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Osteon", "Haversian system"],
          ["Pulse", `${pulse.toFixed(1)} Hz`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 6.5, 15]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* loose connective tissue */}
        <group ref={fibres}>
          {fibreSpecs.map((f) => (
            <mesh key={f.key} position={[f.x, 1.6, f.z]} rotation={[0, 0, f.rot]}
              ref={(m) => { if (m) m.userData.baseRot = f.rot; }}>
              <cylinderGeometry args={[0.09, 0.09, f.len, 8]} />
              <meshStandardMaterial color="#fbbf24" roughness={0.6} />
            </mesh>
          ))}
        </group>
        {[[-6.5, 1.2], [-5.2, 2.1], [-3.9, 1.4]].map(([x, y], i) => (
          <mesh key={i} position={[x, y, 0]} castShadow scale={[1.6, 0.7, 0.7]}>
            <sphereGeometry args={[0.32, 14, 14]} />
            <meshStandardMaterial color="#fb7185" roughness={0.5} />
          </mesh>
        ))}
        <Label text="loose connective tissue" position={[-5.5, 3.3, 0]} size={0.4} color="#f8fafc" />
        <Label text="fibroblast" position={[-3.9, 2.35, 0]} size={0.3} color="#fda4af" />
        <Label text="collagen fibres" position={[-7.6, 0.6, 0]} size={0.3} color="#fde68a" />

        {/* hyaline cartilage */}
        <mesh position={[0.5, 1.7, -0.6]} castShadow>
          <boxGeometry args={[5.6, 3.4, 1.6]} />
          <meshStandardMaterial color="#7dd3fc" transparent opacity={0.5} roughness={0.3} />
        </mesh>
        {[[-1.1, 2.4], [0.6, 1.9], [2.2, 2.6], [1.4, 1.1], [-0.2, 1.2]].map(([x, y], i) => (
          <group key={i} position={[x, y, 0]}>
            <mesh>
              <torusGeometry args={[0.42, 0.09, 10, 20]} />
              <meshStandardMaterial color="#e0f2fe" roughness={0.4} />
            </mesh>
            <mesh>
              <sphereGeometry args={[0.28, 14, 14]} />
              <meshStandardMaterial color="#0c4a6e" roughness={0.4} />
            </mesh>
          </group>
        ))}
        <Label text="hyaline cartilage" position={[0.5, 3.9, 0]} size={0.4} color="#f8fafc" />
        <Label text="chondrocyte in lacuna" position={[2.2, 3.35, 0]} size={0.3} color="#e0f2fe" />

        {/* bone osteon */}
        <group position={[7.2, 1.9, 0]} ref={osteon}>
          {[0.5, 0.85, 1.2, 1.55].map((r, i) => (
            <mesh key={i} rotation={[Math.PI / 2, 0, 0]} castShadow>
              <torusGeometry args={[r, 0.16, 10, 32]} />
              <meshStandardMaterial color={i % 2 ? "#d6d3d1" : "#e7e5e4"} roughness={0.55} />
            </mesh>
          ))}
          <mesh ref={blood}>
            <cylinderGeometry args={[0.3, 0.3, 1.1, 16]} />
            <meshStandardMaterial color="#dc2626" emissive="#7f1d1d" emissiveIntensity={0.6} />
          </mesh>
          {osteocytes.map(([x, y], i) => (
            <mesh key={i} position={[x, 0.55, y]} rotation={[Math.PI / 2, 0, 0]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshStandardMaterial color="#44403c" />
            </mesh>
          ))}
        </group>
        <Label text="osteon" position={[7.2, 4.1, 0]} size={0.4} color="#f8fafc" />
        <Label text="Haversian canal" position={[7.2, 0.45, 0]} size={0.32} color="#fca5a5" />
        <Label text="lamellae" position={[9.3, 2.9, 0]} size={0.3} color="#d6d3d1" />

        <Animator osteon={osteon} blood={blood} fibres={fibres} elapsed={elapsed} speed={speed} pulse={pulse} />
      </SimCanvas>
    </div>
  );
}
