// Reproductive: male physiology & spermatogenesis — a coiled seminiferous
// tubule where germ cells mature stage by stage into swimming sperm, with
// testosterone pulsing from Leydig cells.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Maturation stage", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.7, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Reproductive: Spermatogenesis",
  blurb: "Inside the seminiferous tubule, germ cells mature stage by stage — spermatogonia to swimming spermatozoa.",
};

function Animator({
  swimmers, leydig, elapsed, speed,
}: {
  swimmers: React.RefObject<THREE.Group>;
  leydig: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (swimmers.current) {
      swimmers.current.children.forEach((m, i) => {
        const ph = ((t * 0.25 + i / 8) % 1 + 1) % 1;
        m.position.x = -1.5 + ph * 4.5;
        m.position.y = 1.3 + Math.sin(t * 5 + i * 2.4) * 0.25;
        m.rotation.z = Math.sin(t * 12 + i * 2) * 0.4;
      });
    }
    if (leydig.current) {
      leydig.current.children.forEach((m, i) => {
        const s = 1 + 0.12 * Math.sin(t * 2.5 + i * 1.9);
        m.scale.setScalar(s);
      });
    }
  });
  return null;
}

export function Topic10050Sim(props: SimProps) {
  const stage = Number(props.stage ?? 0.7);
  const speed = Number(props.speed ?? 1);
  const swimmers = useRef<THREE.Group>(null!);
  const leydig = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  // tubule wall as a coil
  const coilPts = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 80; i++) {
      const f = i / 80;
      pts.push(new THREE.Vector3(-5 + f * 10, 1.8 + Math.sin(f * Math.PI * 6) * 0.55, Math.cos(f * Math.PI * 6) * 0.55));
    }
    return pts;
  }, []);
  const coilTube = useMemo(
    () =>
      new THREE.Mesh(
        new THREE.TubeGeometry(new THREE.CatmullRomCurve3(coilPts), 160, 0.34, 10, false),
        new THREE.MeshStandardMaterial({ color: "#f9a8d4", roughness: 0.5 })
      ),
    [coilPts]
  );

  // maturation: cells at positions along the tubule grow tails with `stage`
  const stages = [
    { name: "spermatogonium", tail: 0, color: "#f472b6", size: 0.3 },
    { name: "primary spermatocyte", tail: 0, color: "#e879f9", size: 0.36 },
    { name: "spermatid", tail: 0.35, color: "#c084fc", size: 0.28 },
    { name: "spermatozoon", tail: 1, color: "#67e8f9", size: 0.24 },
  ];
  const visibleStages = stages.slice(0, Math.max(1, Math.round(stage * 4)));

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Site", "seminiferous tubule"],
          ["Duration", "~64 days start → finish"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 14]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* coiled seminiferous tubule */}
        <primitive object={coilTube} />
        {/* Sertoli cell "nurse" hints along the coil */}
        {[-3.5, -1, 1.5, 4].map((x, i) => (
          <mesh key={i} position={[x, 2.6, 0]} castShadow scale={[1, 1.6, 1]}>
            <sphereGeometry args={[0.22, 10, 10]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.5} />
          </mesh>
        ))}
        <Label text="seminiferous tubule (coiled)" position={[0, 0.4, 0]} size={0.38} color="#f8fafc" />
        <Label text="Sertoli (nurse) cells" position={[4.6, 3.1, 0]} size={0.3} color="#fde68a" />

        {/* maturation stages growing along the tubule */}
        <group position={[0, -1.6, 0]}>
          {visibleStages.map((s, i) => (
            <group key={s.name} position={[-4.5 + i * 2.4, 0, 0]}>
              <mesh castShadow>
                <sphereGeometry args={[s.size, 14, 14]} />
                <meshStandardMaterial color={s.color} roughness={0.45} />
              </mesh>
              {s.tail > 0 && (
                <mesh position={[-0.3 - s.tail * 0.4, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
                  <cylinderGeometry args={[0.035, 0.02, s.tail * 1.1, 6]} />
                  <meshStandardMaterial color="#22d3ee" />
                </mesh>
              )}
              <Label text={s.name} position={[0, -0.75, 0]} size={0.3} color="#f8fafc" />
            </group>
          ))}
        </group>
        <Label text="maturation: mitosis → meiosis → spermiogenesis" position={[0, -3.1, 0]} size={0.32} color="#d8b4fe" />

        {/* Leydig cells pulsing testosterone */}
        <group ref={leydig} position={[-6.8, 1.6, 0]}>
          {[[0, 0], [0.55, 0.3], [0.2, -0.5]].map(([x, y], i) => (
            <mesh key={i} position={[x, y, 0]} castShadow>
              <dodecahedronGeometry args={[0.32]} />
              <meshStandardMaterial color="#fb923c" emissive="#7c2d12" emissiveIntensity={0.5} roughness={0.45} />
            </mesh>
          ))}
        </group>
        <Label text="Leydig cells → testosterone" position={[-6.8, 2.9, 0]} size={0.32} color="#fdba74" />

        {/* mature sperm swimming out */}
        <group ref={swimmers}>
          {Array.from({ length: 8 }).map((_, i) => (
            <group key={i} position={[-1.5, 1.3, 0]}>
              <mesh rotation={[0, 0, -Math.PI / 2]} castShadow>
                <coneGeometry args={[0.16, 0.45, 10]} />
                <meshStandardMaterial color="#67e8f9" roughness={0.4} />
              </mesh>
              <mesh position={[-0.75, 0, 0]}>
                <boxGeometry args={[0.9, 0.045, 0.045]} />
                <meshStandardMaterial color="#22d3ee" />
              </mesh>
            </group>
          ))}
        </group>
        <Label text="spermatozoa swim to epididymis" position={[2.4, 0.3, 0]} size={0.32} color="#a5f3fc" />

        <Animator swimmers={swimmers} leydig={leydig} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
