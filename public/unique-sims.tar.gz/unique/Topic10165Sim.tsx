"use client";
// Forensic laboratory: DNA fingerprinting, toxicological analysis.
// A rotating DNA double helix beside a fingerprint of glowing arcs,
// with a test tube rack — how the lab identifies people and poisons.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Rotation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "sample", label: "Sample", kind: "select", min: 0, max: 0, step: 1, default: "dna", options: ["dna", "fingerprint", "blood"] },
];

export const UNIQUE_META = {
  title: "Forensic Lab: DNA Fingerprinting & Toxicology",
  blurb: "Spin the DNA double helix and trace the fingerprint whorls — the two signatures the forensic lab reads.",
};

const SAMPLE_TXT: Record<string, string> = {
  dna: "DNA: unique to every person",
  fingerprint: "Fingerprint: arches, loops, whorls",
  blood: "Blood: poison hunt in toxicology",
};

function Animator({ helix, print, elapsed, speed }: { helix: React.RefObject<THREE.Group>; print: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (helix.current) helix.current.rotation.y = elapsed.current * 0.8;
    if (print.current) {
      print.current.children.forEach((a, i) => {
        (a as THREE.Mesh).rotation.z = Math.sin(elapsed.current * 1.5 + i * 0.4) * 0.15;
      });
    }
  });
  return null;
}

export function Topic10165Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const sample = String(props.sample ?? "dna");
  const helix = useRef<THREE.Group>(null!);
  const print = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const helixParts = useMemo(() => {
    const els: React.ReactNode[] = [];
    const turns = 3, per = 12;
    for (let i = 0; i < turns * per; i++) {
      const a = (i / per) * Math.PI * 2;
      const y = (i / (turns * per)) * 4.4 - 2.2;
      const x1 = Math.cos(a) * 0.8, z1 = Math.sin(a) * 0.8;
      const x2 = Math.cos(a + Math.PI) * 0.8, z2 = Math.sin(a + Math.PI) * 0.8;
      els.push(
        <mesh key={`a${i}`} position={[x1, y, z1]}>
          <sphereGeometry args={[0.14, 10, 10]} />
          <meshStandardMaterial color="#38bdf8" emissive="#0ea5e9" emissiveIntensity={0.7} />
        </mesh>,
        <mesh key={`b${i}`} position={[x2, y, z2]}>
          <sphereGeometry args={[0.14, 10, 10]} />
          <meshStandardMaterial color="#f472b6" emissive="#ec4899" emissiveIntensity={0.7} />
        </mesh>
      );
      if (i % 3 === 0) {
        els.push(
          <mesh key={`r${i}`} position={[(x1 + x2) / 2, y, (z1 + z2) / 2]} rotation={[0, -a, Math.PI / 2]}>
            <cylinderGeometry args={[0.045, 0.045, 1.6, 6]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
          </mesh>
        );
      }
    }
    return els;
  }, []);

  const printArcs = useMemo(
    () =>
      Array.from({ length: 7 }, (_, i) => (
        <mesh key={i} position={[0, 0, i * 0.02]} rotation={[0, 0, 0]}>
          <torusGeometry args={[0.4 + i * 0.32, 0.055, 8, 40, Math.PI * 1.6]} />
          <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={0.6} roughness={0.5} />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Sample", sample], ["Fact", SAMPLE_TXT[sample] ?? ""]]} />
      <SimCanvas cameraPosition={[0, 3.4, 13]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* DNA helix */}
        <group position={[-3.4, 2.9, 0]}>
          <group ref={helix}>{helixParts}</group>
          <Label text="DNA" position={[0, 3.1, 0]} size={0.7} color="#7dd3fc" />
        </group>
        {/* fingerprint */}
        <group position={[0.6, 2.6, 0.6]}>
          <group ref={print}>{printArcs}</group>
          <Label text="FINGERPRINT" position={[0, -2.4, 0]} size={0.6} color="#fbbf24" />
        </group>
        {/* test tube rack */}
        <group position={[4.4, 0, 0]}>
          <mesh position={[0, 0.6, 0]} castShadow>
            <boxGeometry args={[2.4, 0.25, 1]} />
            <meshStandardMaterial color="#475569" roughness={0.7} />
          </mesh>
          {[0, 1, 2].map((i) => (
            <group key={i} position={[(i - 1) * 0.75, 0, 0]}>
              <mesh position={[0, 1.5, 0]}>
                <cylinderGeometry args={[0.22, 0.22, 1.6, 12, 1, true]} />
                <meshStandardMaterial color="#e2e8f0" transparent opacity={0.4} roughness={0.15} side={THREE.DoubleSide} />
              </mesh>
              <mesh position={[0, 1.1, 0]}>
                <cylinderGeometry args={[0.18, 0.18, 0.8, 12]} />
                <meshStandardMaterial color={["#ef4444", "#38bdf8", "#a3e635"][i]} transparent opacity={0.85} roughness={0.3} />
              </mesh>
            </group>
          ))}
          <Label text="TOXICOLOGY TUBES" position={[0, 2.9, 0]} size={0.55} color="#e2e8f0" />
        </group>
        <Animator helix={helix} print={print} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
