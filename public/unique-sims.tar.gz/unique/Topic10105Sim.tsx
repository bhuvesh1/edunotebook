// Pharmacokinetics: a pill's ADME journey — gut -> blood -> liver -> kidney.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Dose", kind: "slider", min: 50, max: 500, step: 50, default: 200, unit: "mg" },
  { key: "absorb", label: "Absorption speed", kind: "slider", min: 0.3, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Pharmacokinetics: ADME",
  blurb: "Follow a pill's journey — Absorption in the gut, Distribution in blood, Metabolism in the liver, Excretion by the kidney.",
};

const STAGES = ["Absorption — gut", "Distribution — blood", "Metabolism — liver", "Excretion — kidney"];
const PATH: [number, number, number][] = [
  [-6, 1.3, 0],
  [-2, 1.3, 0],
  [2, 1.3, 0],
  [6, 1.3, 0],
  [6, -0.6, 0], // excreted out
];

function Animator({ pill, elapsed, speed, setTick }: {
  pill: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = (elapsed.current * 0.09) % 1;
    const seg = Math.min(3, Math.floor(t * 4));
    const f = t * 4 - seg;
    const a = PATH[seg];
    const b = PATH[seg + 1];
    if (pill.current) {
      pill.current.position.set(
        a[0] + (b[0] - a[0]) * f,
        a[1] + (b[1] - a[1]) * f,
        a[2] + (b[2] - a[2]) * f
      );
      pill.current.rotation.y = elapsed.current * 2;
      const op = seg === 3 ? Math.max(0, 1 - f * 1.2) : 1;
      pill.current.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.isMesh) ((m as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = op;
      });
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(elapsed.current * 10)); }
  });
  return null;
}

function Arrow({ x }: { x: number }) {
  return (
    <mesh position={[x, 1.3, 0]} rotation={[0, 0, -Math.PI / 2]}>
      <coneGeometry args={[0.18, 0.5, 12]} />
      <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={0.7} />
    </mesh>
  );
}

export function Topic10105Sim(props: SimProps) {
  const dose = Number(props.dose ?? 200);
  const speed = Number(props.absorb ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const pill = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const seg = Math.min(3, Math.floor(((elapsed.current * 0.09) % 1) * 4));

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Dose", `${dose} mg`],
          ["Stage", STAGES[seg]],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 15]} target={[0, 1, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* Gut — intestine loop */}
        <mesh position={[-6, 1.3, 0]} castShadow>
          <torusGeometry args={[0.85, 0.34, 12, 24]} />
          <meshStandardMaterial color="#d4a373" roughness={0.7} />
        </mesh>
        {showLabels && <Label text="Gut — Absorption" position={[-6, 2.9, 0]} color="#fed7aa" />}

        {/* Blood — vessel */}
        <mesh position={[-2, 1.3, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.5, 0.5, 2.6, 16]} />
          <meshStandardMaterial color="#dc2626" roughness={0.5} />
        </mesh>
        {showLabels && <Label text="Blood — Distribution" position={[-2, 2.9, 0]} color="#fca5a5" />}

        {/* Liver */}
        <mesh position={[2, 1.3, 0]} scale={[1.25, 0.72, 0.85]} castShadow>
          <sphereGeometry args={[0.9, 24, 18]} />
          <meshStandardMaterial color="#7c2d12" roughness={0.6} />
        </mesh>
        {showLabels && <Label text="Liver — Metabolism" position={[2, 2.9, 0]} color="#fdba74" />}

        {/* Kidney + ureter */}
        <mesh position={[6, 1.3, 0]} scale={[0.62, 0.95, 0.62]} castShadow>
          <sphereGeometry args={[0.9, 24, 18]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.55} />
        </mesh>
        <mesh position={[6, 0.1, 0]}>
          <cylinderGeometry args={[0.12, 0.12, 1.4, 10]} />
          <meshStandardMaterial color="#f59e0b" roughness={0.6} />
        </mesh>
        {showLabels && <Label text="Kidney — Excretion" position={[6, 2.9, 0]} color="#fcd34d" />}

        <Arrow x={-4} />
        <Arrow x={0} />
        <Arrow x={4} />

        {/* the pill */}
        <group ref={pill}>
          <mesh castShadow>
            <capsuleGeometry args={[0.22, 0.42, 8, 16]} />
            <meshStandardMaterial color="#f97316" roughness={0.3} transparent />
          </mesh>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <torusGeometry args={[0.225, 0.045, 8, 20]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.4} transparent />
          </mesh>
        </group>
        {showLabels && <Label text="drug pill" position={[-6, 0.2, 1.6]} size={0.45} color="#fdba74" />}

        <Animator pill={pill} elapsed={elapsed} speed={speed} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
