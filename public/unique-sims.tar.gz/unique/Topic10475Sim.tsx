"use client";
// Clear Aligners — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Aligner number", kind: "slider", min: 1, max: 3, step: 1, default: 1 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Clear Aligners",
  blurb: "A crystal-clear tray hugs the teeth — each new aligner nudges the crooked tooth a little straighter.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const th: any = g("algntooth");
    if (th) {
      const target = 0.45 * (1 - (p.stage - 1) / 2);
      th.rotation.z += (target - th.rotation.z) * 0.08;
    }
    const tray: any = g("tray");
    if (tray) {
      const ph = (t % 6) / 6;
      tray.position.z = ph < 0.4 ? 2.2 * (1 - ph / 0.4) : 0;
      (tray.material as any).opacity = 0.18 + 0.08 * Math.sin(t * 2);
    }
    group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
  });
  return null;
}

export function Topic10475Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const stage = Number(props.stage ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, stage };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Aligner", `#${stage} of series`],
          ["Correction", `${Math.round(((stage - 1) / 2) * 100)}% done`],
          ["Wear", "22 hrs/day"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          {[-2.4, -1.2, 1.2, 2.4].map((x, i) => (
            <mesh key={i} position={[x, 1.2, 0]}>
              <boxGeometry args={[1, 1.6, 1]} />
              <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
            </mesh>
          ))}
          <group name="algntooth" position={[0, 1.2, 0]} rotation={[0, 0, 0.45]}>
            <mesh>
              <boxGeometry args={[1, 1.6, 1]} />
              <meshStandardMaterial color="#fbbf24" roughness={0.4} />
            </mesh>
          </group>
          <mesh name="tray" position={[0, 1.35, 2.2]}>
            <boxGeometry args={[5.6, 1.9, 1.5]} />
            <meshStandardMaterial color="#bae6fd" roughness={0.1} transparent opacity={0.2} />
          </mesh>
          <GumSlab position={[0, 0.15, -0.3]} scale={1.3} />
          <Label text="Crooked tooth straightening" position={[0, 2.9, 0]} size={0.42} color="#fbbf24" />
          <Label text="Clear aligner tray" position={[3.4, 2.2, 0]} size={0.42} color="#bae6fd" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
