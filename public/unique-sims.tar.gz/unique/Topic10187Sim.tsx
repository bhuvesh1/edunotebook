"use client";
// Ear: vertigo — Meniere's disease, BPPV, vestibular neuritis.
// Three balance canals with loose crystals tumbling inside; pick the
// condition and spin the world to feel why the room turns.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "bppv", options: ["meniere", "bppv", "neuritis"] },
  { key: "speed", label: "Spin speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Vertigo: When the Balance Canals Misfire",
  blurb: "Loose crystals tumble through the balance canals — spin the world and see why BPPV, Meniere's and neuritis make rooms spin.",
};

const COND_TXT: Record<string, string> = {
  meniere: "Meniere's: fluid pressure + ringing",
  bppv: "BPPV: loose crystals, brief spins",
  neuritis: "Neuritis: nerve inflamed, constant spin",
};

function Animator({ room, crystals, elapsed, speed }: { room: React.RefObject<THREE.Group>; crystals: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (room.current) room.current.rotation.z = elapsed.current * 0.35;
    if (crystals.current) {
      crystals.current.children.forEach((c, i) => {
        const a = elapsed.current * 1.8 + i * 2.1;
        c.position.set(Math.cos(a) * (0.5 + (i % 3) * 0.12), Math.sin(a * 1.3) * 0.4, Math.sin(a) * 0.3);
      });
    }
  });
  return null;
}

export function Topic10187Sim(props: SimProps) {
  const condition = String(props.condition ?? "bppv");
  const speed = Number(props.speed ?? 1);
  const room = useRef<THREE.Group>(null!);
  const crystals = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const crystalMeshes = useMemo(
    () =>
      Array.from({ length: 9 }, (_, i) => (
        <mesh key={i} position={[0, 0, 0]}>
          <octahedronGeometry args={[0.11, 0]} />
          <meshStandardMaterial color="#fde68a" emissive="#f59e0b" emissiveIntensity={0.9} flatShading />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", condition], ["Feels like", COND_TXT[condition] ?? ""]]} />
      <SimCanvas cameraPosition={[0, 3.4, 13]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* spinning room ring */}
        <group ref={room} position={[0, 2.6, -1.5]}>
          {Array.from({ length: 12 }, (_, i) => {
            const a = (i / 12) * Math.PI * 2;
            return (
              <mesh key={i} position={[Math.cos(a) * 5.4, Math.sin(a) * 5.4, 0]}>
                <boxGeometry args={[1.1, 0.28, 0.28]} />
                <meshStandardMaterial color={i % 2 ? "#334155" : "#475569"} roughness={0.8} />
              </mesh>
            );
          })}
        </group>
        <Label text="THE ROOM SPINS" position={[0, 8.6, -1.5]} size={0.6} color="#94a3b8" />
        {/* balance canals */}
        <group position={[0, 2.6, 0.8]}>
          {[0, 1, 2].map((i) => (
            <mesh key={i} rotation={[i * 0.7, 0.5, 0]} castShadow>
              <torusGeometry args={[1.05, 0.2, 12, 28]} />
              <meshStandardMaterial
                color={condition === "meniere" ? "#38bdf8" : "#6ee7b7"}
                transparent
                opacity={0.75}
                roughness={0.4}
                emissive={condition === "meniere" ? "#0ea5e9" : "#10b981"}
                emissiveIntensity={0.35}
              />
            </mesh>
          ))}
          {(condition === "bppv" || condition === "meniere") && <group ref={crystals}>{crystalMeshes}</group>}
          {condition === "neuritis" && (
            <mesh position={[1.6, 0.6, 0]} rotation={[0, 0, 0.5]}>
              <cylinderGeometry args={[0.14, 0.14, 1.8, 8]} />
              <meshStandardMaterial color="#f87171" emissive="#ef4444" emissiveIntensity={0.8} roughness={0.5} />
            </mesh>
          )}
          <Label text="BALANCE CANALS" position={[0, 2, 0]} size={0.6} color="#6ee7b7" />
          {condition === "neuritis" && (
            <Label text="INFLAMED NERVE" position={[2.6, 1.2, 0]} size={0.5} color="#f87171" />
          )}
        </group>
        {/* dizzy person */}
        <group position={[-4.6, 0, 1.5]}>
          <mesh position={[0, 1, 0]} castShadow>
            <capsuleGeometry args={[0.42, 0.95, 6, 12]} />
            <meshStandardMaterial color="#c4b5fd" roughness={0.7} />
          </mesh>
          <mesh position={[0, 2.1, 0]} castShadow>
            <sphereGeometry args={[0.36, 16, 16]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
          {[0, 1, 2].map((i) => (
            <mesh key={i} position={[Math.sin(i * 2.1) * 0.9, 3 + Math.cos(i * 2.1) * 0.4, 0]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={0.9} />
            </mesh>
          ))}
          <Label text="DIZZY!" position={[0, 3.8, 0]} size={0.6} color="#fbbf24" />
        </group>
        <Animator room={room} crystals={crystals} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
