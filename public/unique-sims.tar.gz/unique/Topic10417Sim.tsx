"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "agent", label: "Agent", kind: "select", min: 0, max: 0, step: 1, default: "lignocaine", options: ["lignocaine", "articaine", "mepivacaine"] },
  { key: "vaso", label: "Vasoconstrictor", kind: "select", min: 0, max: 0, step: 1, default: "with", options: ["with", "without"] },
];

export const UNIQUE_META = {
  title: "Local anesthetics: lignocaine, articaine, vasoconstrictors",
  blurb: "A dental syringe numbs a tooth — watch the blue numb zone spread along the nerve, faster and longer with vasoconstrictor.",
};

const AGENTS: Record<string, { name: string; color: string; duration: string; note: string }> = {
  lignocaine: { name: "Lignocaine 2%", color: "#38bdf8", duration: "~60–90 min", note: "The gold standard amide" },
  articaine: { name: "Articaine 4%", color: "#a78bfa", duration: "~75–120 min", note: "Better bone penetration" },
  mepivacaine: { name: "Mepivacaine 3%", color: "#34d399", duration: "~30–45 min", note: "Plain — no vasoconstrictor needed" },
};

function NumbZone({ speed, vaso }: { speed: number; vaso: boolean }) {
  const zone = useRef<THREE.Mesh>(null!);
  const t = useRef(0);
  useFrame((_, delta) => {
    t.current += delta * speed;
    if (zone.current) {
      const s = Math.min(1, (t.current % 8) / 8);
      zone.current.scale.set(0.4 + s * 2.6, 0.35 + s * 0.5, 0.4 + s * 1.4);
      (zone.current.material as THREE.MeshStandardMaterial).opacity = 0.5 - s * 0.25;
    }
  });
  return (
    <mesh ref={zone} position={[-0.4, 0.4, 0.3]}>
      <sphereGeometry args={[0.8, 20, 20]} />
      <meshStandardMaterial color="#38bdf8" transparent opacity={0.4} roughness={0.2} />
    </mesh>
  );
}

function Drip({ color }: { color: string }) {
  const pts = useRef<THREE.Points>(null!);
  const t = useRef(0);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(10 * 3), 3));
    return g;
  }, []);
  useFrame((_, delta) => {
    t.current += delta;
    if (!pts.current) return;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < 10; i++) {
      const f = (t.current * 0.8 + i / 10) % 1;
      pos.setXYZ(i, -2.4 + f * 1.6, 2.4 - f * 1.9, 0.6);
    }
    pos.needsUpdate = true;
  });
  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial color={color} size={0.14} transparent opacity={0.95} />
    </points>
  );
}

function Scene({ agent, vaso }: { agent: string; vaso: boolean }) {
  const a = AGENTS[agent] ?? AGENTS.lignocaine;
  const t = useRef(0);
  const nerve = useRef<THREE.Mesh>(null!);

  useFrame((_, delta) => {
    t.current += delta;
    if (nerve.current) {
      const m = nerve.current.material as THREE.MeshStandardMaterial;
      const f = Math.min(1, (t.current % 8) / 8);
      m.color.setHSL(0.13 - f * 0.08, 0.85, 0.5 + f * 0.1);
    }
  });

  return (
    <group>
      {/* jaw */}
      <mesh position={[0.4, -0.5, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[2.4, 0.75, 14, 32, Math.PI]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>
      {/* tooth being numbed */}
      <group position={[-0.6, 0.6, 1.5]}>
        <mesh position={[0, 0.3, 0]}>
          <cylinderGeometry args={[0.4, 0.52, 0.85, 14]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.25} />
        </mesh>
        <mesh position={[0, -0.45, 0]}>
          <coneGeometry args={[0.38, 1.1, 14]} />
          <meshStandardMaterial color="#e8dcc8" roughness={0.45} />
        </mesh>
        <Label text="Tooth" position={[0, 1.3, 0]} size={0.4} color="#e2e8f0" />
      </group>
      {/* nerve */}
      <mesh ref={nerve} position={[-0.6, -0.5, 1.1]} rotation={[0, 0, Math.PI / 2.2]}>
        <cylinderGeometry args={[0.09, 0.09, 4.4, 10]} />
        <meshStandardMaterial color="#facc15" roughness={0.4} />
      </mesh>
      <Label text="Nerve" position={[-2.6, -0.9, 1.1]} size={0.4} color="#fde68a" />
      {/* blood vessel squeezed by vasoconstrictor */}
      <mesh position={[-0.6, -0.5, 0.55]} rotation={[0, 0, Math.PI / 2.2]}>
        <cylinderGeometry args={[vaso ? 0.045 : 0.1, vaso ? 0.045 : 0.1, 4.4, 10]} />
        <meshStandardMaterial color="#ef4444" roughness={0.4} />
      </mesh>
      <Label text={vaso ? "Vessel constricted (adrenaline)" : "Vessel open (plain)"} position={[-2.6, 0.1, 0.55]} size={0.38} color={vaso ? "#fca5a5" : "#94a3b8"} />

      {/* syringe */}
      <group position={[-2.6, 2.6, 0.9]} rotation={[0, 0, -0.7]}>
        <mesh>
          <cylinderGeometry args={[0.28, 0.28, 1.8, 14]} />
          <meshStandardMaterial color="#e0f2fe" transparent opacity={0.7} roughness={0.2} />
        </mesh>
        <mesh position={[0, 0, 0]}>
          <cylinderGeometry args={[0.22, 0.22, 1.2, 12]} />
          <meshStandardMaterial color={a.color} roughness={0.3} />
        </mesh>
        <mesh position={[0, -1.4, 0]}>
          <cylinderGeometry args={[0.03, 0.012, 1.1, 8]} />
          <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
        </mesh>
        <mesh position={[0, 1.05, 0]}>
          <cylinderGeometry args={[0.32, 0.32, 0.25, 14]} />
          <meshStandardMaterial color="#64748b" roughness={0.5} />
        </mesh>
      </group>
      <Drip color={a.color} />
      <NumbZone speed={vaso ? 0.8 : 1.4} vaso={vaso} />
      <Label text="Numb zone spreading" position={[-0.4, 1.7, 0.3]} size={0.45} color="#7dd3fc" />

      <Label text={a.name} position={[0, 3.6, 0]} size={0.65} color={a.color} />
      <Label text={`${a.note} · Numb for ${a.duration}${vaso ? " · adrenaline prolongs" : ""}`} position={[0, -2.6, 0]} size={0.42} color="#e2e8f0" />
    </group>
  );
}

export function Topic10417Sim(props: SimProps) {
  const agent = String(props.agent ?? "lignocaine");
  const vaso = String(props.vaso ?? "with") === "with";
  const a = AGENTS[agent] ?? AGENTS.lignocaine;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Agent", a.name], ["Vasoconstrictor", vaso ? "Adrenaline 1:100k" : "None"], ["Duration", a.duration]]} />
      <SimCanvas cameraPosition={[0, 2, 10]} target={[0, 0.3, 0]}>
        <Scene agent={agent} vaso={vaso} />
      </SimCanvas>
    </div>
  );
}
