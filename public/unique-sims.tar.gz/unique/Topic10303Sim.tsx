// Metabolic bone disease: osteoporosis, rickets, osteomalacia.
// Strong bone is dense; osteoporotic bone is full of holes and snaps. In
// children, soft bones bow under weight — rickets' bow legs.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "osteoporosis", options: ["normal", "osteoporosis", "rickets", "osteomalacia"] },
  { key: "severity", label: "Severity", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.7, unit: "" },
];

export const UNIQUE_META = {
  title: "Weak Bones: Osteoporosis & Rickets",
  blurb: "Dense bone vs bone full of holes — and a child's soft bones bowing into rickets' bow legs.",
};

function Animator({
  group, pores, legL, legR, snap, elapsed, severity, condition,
}: {
  group: React.RefObject<THREE.Group>;
  pores: React.RefObject<THREE.Group>;
  legL: React.RefObject<THREE.Mesh>;
  legR: React.RefObject<THREE.Mesh>;
  snap: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  severity: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // osteoporotic pores throb
    if (pores.current) {
      pores.current.visible = condition === "osteoporosis" || condition === "osteomalacia";
      pores.current.children.forEach((p, i) => {
        const s = (condition === "osteoporosis" ? 0.7 : 0.45) * severity * (1 + 0.15 * Math.sin(t * 2 + i));
        (p as THREE.Mesh).scale.setScalar(Math.max(0.05, s));
      });
    }
    // rickets: legs bow more with severity, child wobbles
    if (legL.current && legR.current && condition === "rickets") {
      const bow = 0.25 + severity * 0.5;
      legL.current.rotation.z = bow + Math.sin(t * 1.2) * 0.04;
      legR.current.rotation.z = -bow - Math.sin(t * 1.2) * 0.04;
    }
    // osteoporotic bone snaps under load, then resets
    if (snap.current && condition === "osteoporosis") {
      const cyc = (t % 6) / 6;
      const broken = cyc > 0.4 && cyc < 0.75;
      snap.current.children.forEach((half, i) => {
        half.position.y = broken ? (i === 0 ? 0.35 : -0.35) : 0;
        half.rotation.z = broken ? (i === 0 ? 0.35 : -0.3) : 0;
      });
    }
  });
  return null;
}

export function Topic10303Sim(props: SimProps) {
  const condition = String(props.condition ?? "osteoporosis");
  const severity = Number(props.severity ?? 0.7);
  const group = useRef<THREE.Group>(null!);
  const pores = useRef<THREE.Group>(null!);
  const legL = useRef<THREE.Mesh>(null!);
  const legR = useRef<THREE.Mesh>(null!);
  const snap = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    normal: "Normal dense bone", osteoporosis: "Osteoporosis", rickets: "Rickets (child)", osteomalacia: "Osteomalacia (adult)",
  };
  const isBoneView = condition === "normal" || condition === "osteoporosis" || condition === "osteomalacia";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Severity", `${Math.round(severity * 100)}%`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {isBoneView && (
            <>
              {/* bone cross-section: dense outer shell + spongy inside */}
              <group ref={snap}>
                <mesh position={[0, 2.9, 0]} castShadow>
                  <cylinderGeometry args={[0.55, 0.55, 1.2, 20]} />
                  <meshStandardMaterial color="#f8fafc" roughness={0.5} />
                </mesh>
                <mesh position={[0, 1.35, 0]} castShadow>
                  <cylinderGeometry args={[0.55, 0.55, 1.7, 20]} />
                  <meshStandardMaterial color="#f8fafc" roughness={0.5} />
                </mesh>
              </group>
              {/* porous holes eating the bone */}
              <group ref={pores} visible={false}>
                {Array.from({ length: 16 }).map((_, i) => {
                  const a = (i / 16) * Math.PI * 2;
                  const y = 1.0 + (i % 5) * 0.45;
                  return (
                    <mesh key={i} position={[Math.cos(a) * 0.4, y, Math.sin(a) * 0.4]}>
                      <sphereGeometry args={[0.16, 10, 8]} />
                      <meshBasicMaterial color="#0f172a" />
                    </mesh>
                  );
                })}
              </group>
              <Label text={condition === "normal" ? "Dense, strong ✓" : "⚠ Full of holes — fragile"} position={[0, 0.35, 0]} size={0.6} color={condition === "normal" ? "#86efac" : "#fca5a5"} />
              {condition === "osteoporosis" && <Label text="Snaps under small load!" position={[1.9, 2.2, 0]} size={0.5} color="#fde68a" />}
              {condition === "osteomalacia" && <Label text="Soft, poorly mineralized" position={[1.9, 2.2, 0]} size={0.5} color="#fde68a" />}
            </>
          )}
          {condition === "rickets" && (
            <>
              {/* child torso */}
              <mesh position={[0, 3.6, 0]} scale={[0.8, 1.1, 0.6]} castShadow>
                <sphereGeometry args={[0.7, 20, 14]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              <mesh position={[0, 4.6, 0]} castShadow>
                <sphereGeometry args={[0.45, 18, 14]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              {/* bowed legs */}
              <mesh ref={legL} position={[-0.35, 2.0, 0]} castShadow>
                <cylinderGeometry args={[0.16, 0.14, 2.0, 12]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              <mesh ref={legR} position={[0.35, 2.0, 0]} castShadow>
                <cylinderGeometry args={[0.16, 0.14, 2.0, 12]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              {/* rachitic rosary beads on ribs */}
              {[-0.3, 0, 0.3].map((x, i) => (
                <mesh key={i} position={[x, 3.7, 0.42]}>
                  <sphereGeometry args={[0.09, 8, 6]} />
                  <meshStandardMaterial color="#fbbf24" emissive="#92400e" emissiveIntensity={0.6} />
                </mesh>
              ))}
              <Label text="⚠ Bow legs — soft bones bend" position={[0, 0.55, 0]} size={0.6} color="#fca5a5" />
              <Label text="Beaded ribs" position={[1.6, 3.7, 0.42]} size={0.5} color="#fde68a" />
              <Label text="☀ Needs vitamin D!" position={[-2.3, 2.6, 0]} size={0.55} color="#fef9c3" />
            </>
          )}
        </group>
        <Animator group={group} pores={pores} legL={legL} legR={legR} snap={snap} elapsed={elapsed} severity={severity} condition={condition} />
      </SimCanvas>
    </div>
  );
}
