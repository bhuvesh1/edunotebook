"use client";
// Epidemiology: measures of disease frequency, study designs.
// Bars show incidence vs prevalence while two study cohorts march
// forward in time — cohort vs case-control made visible.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "measure", label: "Measure", kind: "select", min: 0, max: 0, step: 1, default: "incidence", options: ["incidence", "prevalence"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Epidemiology: Counting Disease, Designing Studies",
  blurb: "Incidence counts NEW cases, prevalence counts ALL cases — then watch cohort and case-control studies race through time.",
};

function Animator({ cohorts, newBar, elapsed, speed }: { cohorts: React.RefObject<THREE.Group>; newBar: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current % 10;
    if (cohorts.current) {
      cohorts.current.children.forEach((c, i) => {
        c.position.x = -4.5 + ((t * 0.9 + i * 1.4) % 9);
      });
    }
    if (newBar.current) {
      const pulse = 0.75 + Math.max(0, Math.sin(elapsed.current * 2)) * 0.5;
      newBar.current.scale.y = pulse;
    }
  });
  return null;
}

export function Topic10167Sim(props: SimProps) {
  const measure = String(props.measure ?? "incidence");
  const speed = Number(props.speed ?? 1);
  const cohorts = useRef<THREE.Group>(null!);
  const newBar = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const isInc = measure === "incidence";
  const def = isInc ? "NEW cases / time" : "ALL cases / population";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Measure", measure], ["Means", def]]} />
      <SimCanvas cameraPosition={[0, 3.6, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* bar chart: incidence vs prevalence */}
        <group position={[-4.4, 0, 0]}>
          <mesh position={[-0.9, 1.5, 0]} castShadow>
            <boxGeometry args={[1.1, 3, 1.1]} />
            <meshStandardMaterial color={isInc ? "#38bdf8" : "#334155"} emissive={isInc ? "#0ea5e9" : "#000000"} emissiveIntensity={isInc ? 0.5 : 0} />
          </mesh>
          <mesh ref={newBar} position={[0.9, 1.5, 0]} castShadow>
            <boxGeometry args={[1.1, 3, 1.1]} />
            <meshStandardMaterial color={!isInc ? "#a78bfa" : "#334155"} emissive={!isInc ? "#8b5cf6" : "#000000"} emissiveIntensity={!isInc ? 0.5 : 0} />
          </mesh>
          <Label text="INCIDENCE" position={[-0.9, 0.25, 0]} size={0.5} color="#7dd3fc" />
          <Label text="PREVALENCE" position={[0.9, 0.25, 0]} size={0.5} color="#c4b5fd" />
          <Label text="NEW" position={[-0.9, 3.5, 0]} size={0.55} color="#38bdf8" />
          <Label text="ALL" position={[0.9, 3.5, 0]} size={0.55} color="#a78bfa" />
        </group>
        {/* study design race */}
        <group position={[2.6, 0, 0]}>
          <mesh position={[0, 0.1, 0]}>
            <boxGeometry args={[9.6, 0.14, 0.4]} />
            <meshStandardMaterial color="#334155" roughness={0.8} />
          </mesh>
          <group ref={cohorts}>
            {[0, 1, 2, 3].map((i) => (
              <mesh key={`c${i}`} position={[-4.5 + i * 1.4, 0.65, 0]} castShadow>
                <capsuleGeometry args={[0.28, 0.5, 4, 10]} />
                <meshStandardMaterial color="#22c55e" roughness={0.6} />
              </mesh>
            ))}
            {[0, 1, 2].map((i) => (
              <mesh key={`k${i}`} position={[-4 + i * 2.2, 0.65, 0.9]} castShadow>
                <capsuleGeometry args={[0.28, 0.5, 4, 10]} />
                <meshStandardMaterial color="#f59e0b" roughness={0.6} />
              </mesh>
            ))}
          </group>
          <Arrow from={[-4.8, 1.6, 0]} to={[4.8, 1.6, 0]} color="#e2e8f0" />
          <Label text="COHORT (green): exposure → disease" position={[0, 2.5, 0]} size={0.45} color="#86efac" />
          <Label text="CASE-CONTROL (amber): disease → exposure" position={[0, 3.15, 0]} size={0.45} color="#fcd34d" />
          <Label text="TIME →" position={[0, 1.05, 0]} size={0.5} color="#e2e8f0" />
        </group>
        <Animator cohorts={cohorts} newBar={newBar} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
