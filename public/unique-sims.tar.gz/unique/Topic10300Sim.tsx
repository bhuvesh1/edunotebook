// Arthritis: osteoarthritis, rheumatoid arthritis, septic arthritis.
// Inside the knee: smooth cartilage cushions the bones. Osteoarthritis wears
// it away with bony spurs; rheumatoid inflames the lining; septic fills the
// joint with pus.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "type", label: "Arthritis type", kind: "select", min: 0, max: 0, step: 1, default: "osteo", options: ["healthy", "osteo", "rheumatoid", "septic"] },
  { key: "severity", label: "Severity", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.7, unit: "" },
];

export const UNIQUE_META = {
  title: "Knee Arthritis: 3 Types",
  blurb: "Inside the knee joint — worn cartilage and spurs in osteoarthritis, angry red lining in rheumatoid, pus in septic arthritis.",
};

function Animator({
  group, knee, lining, pus, elapsed, severity, type,
}: {
  group: React.RefObject<THREE.Group>;
  knee: React.RefObject<THREE.Group>;
  lining: React.RefObject<THREE.Mesh>;
  pus: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  severity: number;
  type: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // the knee bends; arthritic knees are stiff and grind
    if (knee.current) {
      const stiff = type === "healthy" ? 1 : 1 - severity * 0.6;
      const bend = (0.5 + 0.5 * Math.sin(t * 1.6)) * 0.7 * stiff;
      knee.current.rotation.x = bend;
      if (type !== "healthy") {
        knee.current.position.x = Math.sin(t * 22) * 0.02 * severity; // grinding judder
      } else {
        knee.current.position.x = 0;
      }
    }
    if (lining.current) {
      lining.current.visible = type === "rheumatoid";
      lining.current.scale.set(1 + severity * 0.5, 1 + severity * 0.3, 1 + severity * 0.5);
      (lining.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.4 + 0.4 * Math.sin(t * 4);
    }
    if (pus.current) {
      pus.current.visible = type === "septic";
      pus.current.scale.setScalar(0.6 + severity * 0.5 + 0.08 * Math.sin(t * 3));
    }
  });
  return null;
}

export function Topic10300Sim(props: SimProps) {
  const type = String(props.type ?? "osteo");
  const severity = Number(props.severity ?? 0.7);
  const group = useRef<THREE.Group>(null!);
  const knee = useRef<THREE.Group>(null!);
  const lining = useRef<THREE.Mesh>(null!);
  const pus = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    healthy: "Healthy knee", osteo: "Osteoarthritis", rheumatoid: "Rheumatoid arthritis", septic: "Septic arthritis",
  };
  const worn = type === "osteo";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Type", names[type] ?? type], ["Severity", `${Math.round(severity * 100)}%`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* femur above */}
          <mesh position={[0, 3.6, 0]} castShadow>
            <cylinderGeometry args={[0.3, 0.42, 1.8, 16]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <mesh position={[0, 2.75, 0]} scale={[1.2, 0.8, 1]} castShadow>
            <sphereGeometry args={[0.42, 18, 14]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          {/* cartilage caps: thick & blue when healthy, worn thin in OA */}
          <mesh position={[0, 2.42, 0]} scale={[1.15, worn ? 1 - severity * 0.75 : 1, 0.95]} castShadow>
            <sphereGeometry args={[0.4, 18, 12]} />
            <meshStandardMaterial color={worn ? "#fbbf24" : "#7dd3fc"} roughness={worn ? 0.8 : 0.25} transparent opacity={0.9} />
          </mesh>
          {/* osteophytes: bony spurs */}
          {worn && [-0.55, 0.55].map((x, i) => (
            <mesh key={i} position={[x, 2.5, 0.15]} rotation={[0, 0, x * 1.2]} castShadow>
              <coneGeometry args={[0.12 * (0.5 + severity), 0.4 * (0.5 + severity), 8]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.6} flatShading />
            </mesh>
          ))}
          {/* lower leg bends at the knee */}
          <group ref={knee} position={[0, 2.2, 0]}>
            <mesh position={[0, -0.15, 0]} scale={[1.1, 0.7, 0.95]} castShadow>
              <sphereGeometry args={[0.38, 18, 14]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.5} />
            </mesh>
            <mesh position={[0, -1.1, 0]} castShadow>
              <cylinderGeometry args={[0.26, 0.22, 1.6, 14]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.5} />
            </mesh>
          </group>
          {/* inflamed synovial lining (rheumatoid) */}
          <mesh ref={lining} position={[0, 2.35, 0]} visible={false} castShadow>
            <torusGeometry args={[0.55, 0.22, 12, 20]} />
            <meshStandardMaterial color="#dc2626" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.6} />
          </mesh>
          {/* pus in the joint (septic) */}
          <mesh ref={pus} position={[0, 2.35, 0.1]} visible={false} castShadow>
            <sphereGeometry args={[0.5, 16, 12]} />
            <meshStandardMaterial color="#a3a380" roughness={0.3} transparent opacity={0.85} emissive="#52521f" emissiveIntensity={0.4} />
          </mesh>
          <Label text="Femur" position={[-1.7, 3.6, 0]} size={0.5} color="#f8fafc" />
          <Label text="Cartilage" position={[1.7, 2.42, 0]} size={0.5} color={worn ? "#fde68a" : "#7dd3fc"} />
          <Label text="Tibia" position={[-1.7, 1.1, 0]} size={0.5} color="#f8fafc" />
          {worn && <Label text="⚠ Cartilage worn + bone spurs" position={[0, 0.15, 0]} size={0.55} color="#fde68a" />}
          {type === "rheumatoid" && <Label text="⚠ Immune attack on lining" position={[0, 0.15, 0]} size={0.55} color="#fca5a5" />}
          {type === "septic" && <Label text="🚨 Pus! Drain urgently" position={[0, 0.15, 0.1]} size={0.6} color="#fde68a" />}
          {type === "healthy" && <Label text="Smooth gliding ✓" position={[0, 0.15, 0]} size={0.55} color="#86efac" />}
        </group>
        <Animator group={group} knee={knee} lining={lining} pus={pus} elapsed={elapsed} severity={severity} type={type} />
      </SimCanvas>
    </div>
  );
}
