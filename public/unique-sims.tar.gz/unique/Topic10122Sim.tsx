// Corticosteroids & sex hormones: the HPA feedback loop — brain signals the
// adrenal gland to release cortisol, and steroid pills switch the loop OFF.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Steroid pill dose", kind: "slider", min: 0, max: 100, step: 5, default: 45, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Corticosteroids & hormones",
  blurb: "The brain-adrenal feedback loop: steroid pills switch the body's own cortisol signal OFF.",
};

const N_SIG = 6;

function Animator({ down, up, pill, gland, elapsed, dose, setTick }: {
  down: React.RefObject<(THREE.Mesh | null)[]>;
  up: React.RefObject<(THREE.Mesh | null)[]>;
  pill: React.RefObject<THREE.Group>;
  gland: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  dose: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    const drive = 1 - k * 0.9; // brain drive suppressed by steroid
    down.current.forEach((d, i) => {
      if (!d) return;
      const f = (t * (0.3 + drive * 0.7) + i / N_SIG) % 1;
      d.position.set(0, 3.6 - f * 2.2, 0);
      d.visible = drive > 0.08;
      ((d as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = drive;
    });
    up.current.forEach((u, i) => {
      if (!u) return;
      // cortisol rises from the gland; exogenous steroid adds its own glow
      const f = (t * 0.4 + i / N_SIG) % 1;
      u.position.set(2.6, 1.6 + f * 1.6, 0);
      const m = u.material as THREE.MeshStandardMaterial;
      m.opacity = Math.max(0, 1 - f) * (0.25 + drive * 0.75 + k * 0.5);
      u.visible = m.opacity > 0.05;
    });
    if (gland.current) {
      const gm = gland.current.material as THREE.MeshStandardMaterial;
      gm.emissiveIntensity = 0.2 + drive * 1.2;
      gland.current.scale.setScalar(1 + Math.sin(t * 2) * 0.03 * drive);
    }
    if (pill.current) {
      pill.current.rotation.y = t * 1.4;
      pill.current.position.y = 0.7 + Math.abs(Math.sin(t * 1.8)) * 0.25;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(drive * 100)); }
  });
  return null;
}

export function Topic10122Sim(props: SimProps) {
  const dose = Number(props.dose ?? 45);
  const showLabels = String(props.detail ?? "on") === "on";
  const down = useRef<(THREE.Mesh | null)[]>([]);
  const up = useRef<(THREE.Mesh | null)[]>([]);
  const pill = useRef<THREE.Group>(null!);
  const gland = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const k = dose / 100;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Body's own cortisol signal", `${tick}%`],
          ["Feedback", k > 0.5 ? "suppressed by pill" : "loop active"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0.8, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* brain (hypothalamus/pituitary) */}
        <mesh position={[0, 3.9, 0]} castShadow>
          <sphereGeometry args={[0.9, 20, 14]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
        </mesh>
        {showLabels && <Label text="brain — ACTH signal" position={[0, 5.2, 0]} color="#f9a8d4" />}

        {/* downward signals */}
        {Array.from({ length: N_SIG }).map((_, i) => (
          <mesh key={i} ref={(m) => { down.current[i] = m; }}>
            <coneGeometry args={[0.14, 0.36, 8]} />
            <meshStandardMaterial color="#f472b6" emissive="#be185d" emissiveIntensity={1} transparent />
          </mesh>
        ))}

        {/* kidney + adrenal gland */}
        <group position={[2.6, 1.2, 0]}>
          <mesh scale={[0.55, 0.85, 0.55]} castShadow>
            <sphereGeometry args={[0.8, 20, 14]} />
            <meshStandardMaterial color="#7f1d1d" roughness={0.6} />
          </mesh>
          <mesh ref={gland} position={[0, 0.85, 0]} scale={[1, 0.5, 1]} castShadow>
            <sphereGeometry args={[0.45, 16, 12]} />
            <meshStandardMaterial color="#facc15" emissive="#eab308" emissiveIntensity={0.8} />
          </mesh>
        </group>
        {showLabels && <Label text="adrenal gland — cortisol" position={[2.6, 2.9, 0]} color="#fde047" />}

        {/* cortisol rising */}
        {Array.from({ length: N_SIG }).map((_, i) => (
          <mesh key={`u${i}`} ref={(m) => { up.current[i] = m; }}>
            <sphereGeometry args={[0.13, 10, 8]} />
            <meshStandardMaterial color="#fde047" emissive="#a16207" emissiveIntensity={1} transparent />
          </mesh>
        ))}

        {/* steroid pill */}
        <group ref={pill} position={[-3.2, 0.7, 1]}>
          <mesh castShadow>
            <capsuleGeometry args={[0.26, 0.44, 8, 16]} />
            <meshStandardMaterial color="#f97316" roughness={0.3} />
          </mesh>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <torusGeometry args={[0.265, 0.05, 8, 20]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.4} />
          </mesh>
        </group>
        {showLabels && <Label text="steroid pill" position={[-3.2, 1.9, 1]} size={0.45} color="#fdba74" />}

        {/* negative feedback X */}
        {k > 0.5 && showLabels && <Label text="✕ feedback OFF" position={[0, 2.4, 0]} color="#fca5a5" />}

        <Animator down={down} up={up} pill={pill} gland={gland} elapsed={elapsed} dose={dose} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
