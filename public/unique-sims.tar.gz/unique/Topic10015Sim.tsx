// Histology: epithelium and glands — three epithelial cell types on their
// basement membranes, plus a gland acinus secreting droplets down its duct.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "secretion", label: "Secretion rate", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Histology: Epithelium & Glands",
  blurb: "Compare squamous, cuboidal and columnar epithelium — and watch a gland secrete into its duct.",
};

function EpiRow({
  x, w, h, color, label, goblet,
}: {
  x: number; w: number; h: number; color: string; label: string; goblet: boolean;
}) {
  return (
    <group position={[x, 0, 0]}>
      {/* basement membrane */}
      <mesh position={[0, 0.05, 0]}>
        <boxGeometry args={[5.4, 0.1, 1.6]} />
        <meshStandardMaterial color="#f472b6" roughness={0.7} />
      </mesh>
      {[-2, -1, 0, 1, 2].map((i) => {
        const isGoblet = goblet && i === 0;
        const ch = isGoblet ? h * 1.35 : h;
        return (
          <group key={i} position={[i * 1.05, 0.1 + ch / 2, 0]}>
            <mesh castShadow>
              <boxGeometry args={[w, ch, 1.3]} />
              <meshStandardMaterial color={isGoblet ? "#fde68a" : color} roughness={0.55} />
            </mesh>
            {/* nucleus */}
            <mesh position={[0, isGoblet ? -ch / 4 : 0, 0]}>
              <sphereGeometry args={[Math.min(w, h) * 0.28, 12, 12]} />
              <meshStandardMaterial color="#1e3a8a" roughness={0.4} />
            </mesh>
            {isGoblet && (
              <mesh position={[0, ch / 2 + 0.18, 0]}>
                <sphereGeometry args={[0.3, 12, 12]} />
                <meshStandardMaterial color="#fef9c3" roughness={0.3} />
              </mesh>
            )}
          </group>
        );
      })}
      <Label text="basement membrane" position={[0, 0.55, 1.1]} size={0.32} color="#f9a8d4" />
      <Label text={label} position={[0, h + (goblet ? 1.6 : 1.1), 0]} size={0.42} color="#f8fafc" />
    </group>
  );
}

function DropAnimator({
  drops, acini, elapsed, secretion, speed,
}: {
  drops: React.RefObject<THREE.Group>;
  acini: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  secretion: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (drops.current) {
      drops.current.children.forEach((m, i) => {
        const ph = ((t * 0.55 * secretion + i / 8) % 1 + 1) % 1;
        m.position.y = 3.1 - ph * 2.7;
        m.visible = secretion > 0.02;
      });
    }
    if (acini.current) {
      acini.current.children.forEach((m, i) => {
        const s = 1 + 0.08 * Math.sin(t * 3 + i * 1.7);
        m.scale.setScalar(s);
      });
    }
  });
  return null;
}

export function Topic10015Sim(props: SimProps) {
  const secretion = Number(props.secretion ?? 1);
  const speed = Number(props.speed ?? 1);
  const drops = useRef<THREE.Group>(null!);
  const acini = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const acinusCells: [number, number, number][] = [
    [0, 0, 0], [0.62, 0.15, 0.2], [-0.6, 0.12, -0.15], [0.3, 0.62, -0.3],
    [-0.28, 0.6, 0.28], [0.15, -0.5, 0.25], [-0.2, -0.48, -0.25],
  ];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Secretion", `${secretion.toFixed(1)}×`],
          ["Exocrine gland", "merocrine"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 14.5]} target={[1.5, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <EpiRow x={-7} w={0.95} h={0.55} color="#fda4af" label="squamous" goblet={false} />
        <EpiRow x={-1.6} w={0.95} h={1.0} color="#fdba74" label="cuboidal" goblet={false} />
        <EpiRow x={3.8} w={0.9} h={2.1} color="#5eead4" label="columnar + goblet cell" goblet />

        {/* gland acinus: berry-like cluster */}
        <group position={[8.6, 3.4, 0]} ref={acini}>
          {acinusCells.map((p, i) => (
            <mesh key={i} position={p} castShadow>
              <sphereGeometry args={[0.42, 16, 16]} />
              <meshStandardMaterial color="#e879f9" roughness={0.5} />
            </mesh>
          ))}
        </group>
        {/* duct */}
        <mesh position={[8.6, 1.65, 0]} castShadow>
          <cylinderGeometry args={[0.28, 0.28, 3.1, 16]} />
          <meshStandardMaterial color="#c084fc" roughness={0.5} />
        </mesh>
        {/* secretion droplets flowing down the duct */}
        <group ref={drops}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[8.6, 3.1, 0]}>
              <sphereGeometry args={[0.13, 10, 10]} />
              <meshStandardMaterial color="#fef08a" emissive="#a16207" emissiveIntensity={0.5} />
            </mesh>
          ))}
        </group>
        <Label text="gland acinus" position={[8.6, 4.9, 0]} size={0.42} color="#f8fafc" />
        <Label text="duct" position={[9.35, 1.6, 0]} size={0.36} color="#d8b4fe" />

        <DropAnimator drops={drops} acini={acini} elapsed={elapsed} secretion={secretion} speed={speed} />
      </SimCanvas>
    </div>
  );
}
