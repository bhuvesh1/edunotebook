// Anticancer drugs: a dark tumor keeps dividing while healthy pink cells sit
// quietly — chemotherapy selectively shrinks the tumor.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Chemotherapy dose", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Anticancer drugs",
  blurb: "A dark tumor keeps dividing while healthy cells rest — chemotherapy selectively shrinks the tumor.",
};

const N_TUMOR = 14;
const N_DX = 10;

function Animator({ tumor, healthy, dx, elapsed, dose, setTick }: {
  tumor: React.RefObject<(THREE.Group | null)[]>;
  healthy: React.RefObject<(THREE.Mesh | null)[]>;
  dx: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  dose: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    tumor.current.forEach((g, i) => {
      if (!g) return;
      // tumor regrows slowly, drug kills in waves
      const kill = Math.max(0, Math.sin(t * 0.9 + i * 1.1)) * k;
      const s = Math.max(0.05, 1 - kill * 0.95);
      g.scale.setScalar(s);
      g.visible = s > 0.08;
      g.rotation.y = t * 0.5 + i;
    });
    healthy.current.forEach((h, i) => {
      if (!h) return;
      // healthy cells only mildly affected at high dose
      const s = 1 - k * 0.08 * (0.5 + 0.5 * Math.sin(t * 1.3 + i * 2));
      h.scale.setScalar(s);
    });
    dx.current.forEach((d, i) => {
      if (!d) return;
      const f = (t * 0.5 + i / N_DX) % 1;
      d.position.set(4.2 - f * 6.4, 3.6 - f * 2.4 + Math.sin(f * 8 + i) * 0.3, Math.cos(f * 5 + i) * 0.8);
      d.rotation.y = t * 4 + i;
      d.visible = k > 0.03;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(k * 100)); }
  });
  return null;
}

export function Topic10123Sim(props: SimProps) {
  const dose = Number(props.dose ?? 60);
  const showLabels = String(props.detail ?? "on") === "on";
  const tumor = useRef<(THREE.Group | null)[]>([]);
  const healthy = useRef<(THREE.Mesh | null)[]>([]);
  const dx = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const remaining = Math.max(3, Math.round(100 - (dose / 100) * 90));

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Tumor remaining", `${remaining}%`],
          ["Healthy cells", dose > 80 ? "mildly affected" : "safe"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* tumor: dark purple lumpy mass of dividing cells */}
        {Array.from({ length: N_TUMOR }).map((_, i) => {
          const ang = (i / N_TUMOR) * Math.PI * 2;
          const r = 0.4 + ((i * 37) % 10) / 10 * 0.9;
          return (
            <group
              key={i}
              ref={(g) => { tumor.current[i] = g; }}
              position={[-2.4 + Math.cos(ang) * r, 1.6 + Math.sin(ang * 1.7) * r * 0.8, Math.sin(ang) * r * 0.6]}
            >
              <mesh castShadow>
                <icosahedronGeometry args={[0.34]} />
                <meshStandardMaterial color="#6b21a8" emissive="#4c1d95" emissiveIntensity={0.9} roughness={0.5} />
              </mesh>
            </group>
          );
        })}
        {showLabels && <Label text="tumor — dividing fast" position={[-2.4, 3.4, 0]} color="#d8b4fe" />}

        {/* healthy cells */}
        {Array.from({ length: 8 }).map((_, i) => (
          <mesh
            key={`h${i}`}
            ref={(m) => { healthy.current[i] = m; }}
            position={[2.6 + (i % 4) * 0.9 - 1.3, 1.1 + Math.floor(i / 4) * 1.1, (i % 2) * 0.6 - 0.3]}
            castShadow
          >
            <sphereGeometry args={[0.32, 16, 12]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
          </mesh>
        ))}
        {showLabels && <Label text="healthy cells — resting" position={[2.6, 3.2, 0]} size={0.45} color="#f9a8d4" />}

        {/* chemo drug molecules */}
        {Array.from({ length: N_DX }).map((_, i) => (
          <mesh key={`d${i}`} ref={(m) => { dx.current[i] = m; }}>
            <octahedronGeometry args={[0.15]} />
            <meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={1.2} />
          </mesh>
        ))}

        {/* IV bag */}
        <group position={[4.6, 0, 1.2]}>
          <mesh position={[0, 3.2, 0]}>
            <boxGeometry args={[0.7, 1, 0.3]} />
            <meshStandardMaterial color="#bbf7d0" transparent opacity={0.75} />
          </mesh>
          <mesh position={[0, 1.8, 0]}>
            <cylinderGeometry args={[0.04, 0.04, 2, 8]} />
            <meshStandardMaterial color="#94a3b8" />
          </mesh>
        </group>
        {showLabels && <Label text="chemo IV" position={[4.6, 4.2, 1.2]} size={0.45} color="#86efac" />}

        <Animator tumor={tumor} healthy={healthy} dx={dx} elapsed={elapsed} dose={dose} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
