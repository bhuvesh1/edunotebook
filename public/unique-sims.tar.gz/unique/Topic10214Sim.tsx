// Ischemic heart disease — angina & MI. A beating heart with a coronary
// artery on its surface; plaque clogs it (blockage slider), the downstream
// muscle turns dark (infarct) and the beat weakens.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "blockage", label: "Coronary blockage", kind: "slider", min: 0, max: 100, step: 5, default: 75, unit: "%" },
  { key: "labels", label: "Labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Ischemic Heart Disease",
  blurb: "Plaque chokes a coronary artery; the starved heart muscle dies (MI) and the beat falters. Push blockage to 100% for a heart attack.",
};

function Animator({ heart, flow, elapsed, blockage }: {
  heart: React.RefObject<THREE.Group>;
  flow: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  blockage: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const weak = blockage / 100;
    const rate = 2.4 - weak * 1.1;
    if (heart.current) {
      const beat = Math.pow(Math.max(0, Math.sin(t * rate * Math.PI)), 3);
      const s = 1 + beat * (0.09 - weak * 0.05);
      heart.current.scale.set(s, 2 - s > 0 ? 1 - beat * (0.05 - weak * 0.03) : 1, s);
    }
    if (flow.current) {
      flow.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * (1.4 - weak * 1.1) + i * 0.18) % 1);
        m.position.y = 3.4 - ph * 2.6;
        m.visible = ph < 0.45 || blockage < 90; // past the clot almost nothing passes
      });
    }
  });
  return null;
}

export function Topic10214Sim(props: SimProps) {
  const blockage = Number(props.blockage ?? 75);
  const showLabels = String(props.labels ?? "on") === "on";
  const heart = useRef<THREE.Group>(null!);
  const flow = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const mi = blockage >= 95;
  const angina = blockage >= 60 && blockage < 95;
  const infarct = Math.min(1, Math.max(0, (blockage - 55) / 40));

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Artery", `${blockage}% blocked`], ["Status", mi ? "HEART ATTACK (MI) ⚠" : angina ? "angina — chest pain on effort" : "mild plaque"], ["Muscle damage", `${Math.round(infarct * 100)}%`]]} />
      <SimCanvas cameraPosition={[0, 2.8, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={heart}>
          {/* heart mass */}
          <mesh position={[0, 2.1, 0]} scale={[1, 1.25, 0.95]} castShadow>
            <sphereGeometry args={[1.7, 32, 26]} />
            <meshStandardMaterial color="#dc2626" roughness={0.45} />
          </mesh>
          {/* infarct: dead dark patch downstream */}
          <mesh position={[0.75, 1.35, 0.95]} scale={[0.9, 1.1, 0.5]} visible={infarct > 0.02}>
            <sphereGeometry args={[0.85, 18, 14]} />
            <meshStandardMaterial color="#450a0a" roughness={0.8} transparent opacity={0.35 + infarct * 0.6} />
          </mesh>
          {/* aorta */}
          <mesh position={[-0.3, 3.9, 0]} rotation={[0, 0, 0.25]}>
            <cylinderGeometry args={[0.42, 0.5, 1.6, 16]} />
            <meshStandardMaterial color="#ef4444" roughness={0.5} />
          </mesh>
          {/* coronary artery on the surface */}
          <mesh position={[0, 3.1, 1.15]} rotation={[Math.PI / 2.2, 0, 0.2]}>
            <cylinderGeometry args={[0.2, 0.2, 3.2, 14]} />
            <meshStandardMaterial color="#f87171" roughness={0.4} transparent opacity={0.75} />
          </mesh>
          {/* plaque */}
          <mesh position={[0, 2.35, 1.32]} scale={[1, 1 + (blockage / 100) * 1.4, 1 + (blockage / 100) * 1.4]}>
            <sphereGeometry args={[0.3, 14, 12]} />
            <meshStandardMaterial color="#fde68a" roughness={0.9} emissive="#a16207" emissiveIntensity={0.35} />
          </mesh>
        </group>

        {/* blood flow dots in the artery */}
        <group ref={flow}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i} position={[0, 3.4, 1.32]}>
              <sphereGeometry args={[0.09, 10, 10]} />
              <meshBasicMaterial color="#fecaca" />
            </mesh>
          ))}
        </group>

        {showLabels && (
          <>
            <Label text="Plaque clot" position={[1.7, 2.5, 1.3]} size={0.5} color="#fde047" />
            {infarct > 0.05 && <Label text={mi ? "INFARCT — muscle dying ⚠" : "Starved muscle"} position={[1.9, 1.2, 0.9]} size={0.52} color="#fca5a5" />}
            <Label text="Time is muscle — call emergency at chest pain" position={[0, -1.2, 0]} size={0.44} color="#94a3b8" />
          </>
        )}
        <Animator heart={heart} flow={flow} elapsed={elapsed} blockage={blockage} />
      </SimCanvas>
    </div>
  );
}
