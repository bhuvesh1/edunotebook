"use client";
// Toxicology: snakebite & scorpion sting, plant poisons.
// A slithering snake, a scorpion with a raised tail, and a poisonous
// plant — pick one and watch its venom spread from the bite mark.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "creature", label: "Creature", kind: "select", min: 0, max: 0, step: 1, default: "snake", options: ["snake", "scorpion", "plant"] },
  { key: "spread", label: "Venom spread", kind: "slider", min: 0, max: 100, step: 5, default: 30, unit: "%" },
];

export const UNIQUE_META = {
  title: "Snakebite, Scorpion Sting & Plant Poisons",
  blurb: "Meet the snake, the scorpion and the poisonous plant — then watch venom spread from the bite and learn the first-aid rule.",
};

const CREATURE_TXT: Record<string, string> = {
  snake: "Snakebite: keep limb still, rush to hospital",
  scorpion: "Scorpion sting: severe pain, watch the heart",
  plant: "Plant poison: never taste unknown seeds",
};

function Animator({ snake, tail, elapsed, speed }: { snake: React.RefObject<THREE.Group>; tail: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (snake.current) {
      snake.current.children.forEach((seg, i) => {
        seg.position.x = Math.sin(elapsed.current * 2 + i * 0.55) * 0.45;
      });
      snake.current.position.z = Math.sin(elapsed.current * 0.7) * 0.2;
    }
    if (tail.current) tail.current.rotation.x = -0.5 + Math.sin(elapsed.current * 3) * 0.25;
  });
  return null;
}

export function Topic10164Sim(props: SimProps) {
  const creature = String(props.creature ?? "snake");
  const spread = Number(props.spread ?? 30);
  const snake = useRef<THREE.Group>(null!);
  const tail = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const segments = useMemo(
    () =>
      Array.from({ length: 12 }, (_, i) => (
        <mesh key={i} position={[0, 0.35, -2.6 + i * 0.45]} castShadow>
          <sphereGeometry args={[0.34 - i * 0.012, 14, 14]} />
          <meshStandardMaterial color={i % 2 === 0 ? "#4d7c0f" : "#365314"} roughness={0.6} />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Creature", creature], ["First aid", CREATURE_TXT[creature] ?? ""]]} />
      <SimCanvas cameraPosition={[0, 4, 14]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#1a2e1a" roughness={1} />
        </mesh>
        {/* snake */}
        {creature === "snake" && (
          <group>
            <group ref={snake}>{segments}</group>
            <mesh position={[0, 0.75, 3.1]} castShadow>
              <sphereGeometry args={[0.42, 16, 16]} />
              <meshStandardMaterial color="#4d7c0f" roughness={0.6} />
            </mesh>
            {[[-0.18], [0.18]].map(([x]) => (
              <mesh key={x} position={[x, 0.85, 3.45]}>
                <sphereGeometry args={[0.08, 8, 8]} />
                <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.8} />
              </mesh>
            ))}
            <Label text="SNAKE" position={[0, 1.9, 3]} size={0.6} color="#a3e635" />
          </group>
        )}
        {/* scorpion */}
        {creature === "scorpion" && (
          <group position={[0, 0, 0]}>
            <mesh position={[0, 0.35, 0]} castShadow>
              <capsuleGeometry args={[0.4, 1.4, 6, 12]} />
              <meshStandardMaterial color="#92400e" roughness={0.6} />
            </mesh>
            {[[-0.9], [0.9]].map(([x]) => (
              <mesh key={x} position={[x, 0.3, 1.1]} castShadow>
                <sphereGeometry args={[0.32, 12, 12]} />
                <meshStandardMaterial color="#92400e" roughness={0.6} />
              </mesh>
            ))}
            <group ref={tail} position={[0, 0.5, -1]}>
              <mesh position={[0, 0.5, -0.7]} rotation={[0.9, 0, 0]} castShadow>
                <cylinderGeometry args={[0.12, 0.2, 1.6, 8]} />
                <meshStandardMaterial color="#78350f" roughness={0.6} />
              </mesh>
              <mesh position={[0, 1.35, -1.35]}>
                <coneGeometry args={[0.18, 0.4, 8]} />
                <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.7} />
              </mesh>
            </group>
            {[0, 1, 2].map((i) => (
              <mesh key={i} position={[0, 0.25, 0.3 - i * 0.45]} rotation={[0, 0, Math.PI / 2]}>
                <cylinderGeometry args={[0.05, 0.05, 1.6, 6]} />
                <meshStandardMaterial color="#78350f" roughness={0.7} />
              </mesh>
            ))}
            <Label text="SCORPION" position={[0, 2.2, 0]} size={0.6} color="#fb923c" />
          </group>
        )}
        {/* poisonous plant */}
        {creature === "plant" && (
          <group position={[0, 0, 0]}>
            <mesh position={[0, 0.8, 0]} castShadow>
              <cylinderGeometry args={[0.12, 0.16, 1.6, 8]} />
              <meshStandardMaterial color="#4d7c0f" roughness={0.8} />
            </mesh>
            {[0, 1, 2, 3].map((i) => (
              <mesh key={i} position={[Math.sin(i * 1.7) * 0.7, 1 + (i % 2) * 0.5, Math.cos(i * 1.7) * 0.5]} rotation={[0.6, 0, Math.sin(i * 1.7) * 0.8]} castShadow>
                <sphereGeometry args={[0.45, 10, 10]} />
                <meshStandardMaterial color="#65a30d" roughness={0.7} />
              </mesh>
            ))}
            {[[-0.4, 0.4], [0.4, -0.3], [0, 0.6]].map(([x, z], i) => (
              <mesh key={i} position={[x, 2.1, z]} castShadow>
                <sphereGeometry args={[0.28, 12, 12]} />
                <meshStandardMaterial color="#7c3aed" emissive="#7c3aed" emissiveIntensity={0.5} roughness={0.5} />
              </mesh>
            ))}
            <Label text="POISONOUS PLANT" position={[0, 3, 0]} size={0.6} color="#c4b5fd" />
          </group>
        )}
        {/* venom spread ring on the "skin" */}
        <mesh position={[4.6, 0.06, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.3, 0.3 + spread * 0.035, 28]} />
          <meshStandardMaterial color="#ef4444" transparent opacity={0.7} emissive="#ef4444" emissiveIntensity={0.6} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[4.6, 0.1, 0]}>
          <sphereGeometry args={[0.25, 12, 12]} />
          <meshStandardMaterial color="#991b1b" roughness={0.6} />
        </mesh>
        <Label text="BITE MARK" position={[4.6, 1.1, 0]} size={0.55} color="#f87171" />
        <Animator snake={snake} tail={tail} elapsed={elapsed} speed={1} />
      </SimCanvas>
    </div>
  );
}
