"use client";
// Throat: pharyngitis, laryngitis, vocal cord disorders.
// Two vocal cords flutter in the larynx — raise inflammation and they
// redden, swell and slow, turning the voice hoarse.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "laryngitis", options: ["pharyngitis", "laryngitis", "nodules"] },
  { key: "inflame", label: "Inflammation", kind: "slider", min: 0, max: 100, step: 5, default: 45, unit: "%" },
];

export const UNIQUE_META = {
  title: "Pharyngitis, Laryngitis & Vocal Cords",
  blurb: "Watch the vocal cords flutter to make sound — inflame them and the voice turns hoarse and rough.",
};

function Animator({ cords, waves, elapsed, inflame, condition }: { cords: React.RefObject<THREE.Group>; waves: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; inflame: number; condition: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const health = 1 - inflame / 140;
    if (cords.current) {
      cords.current.children.forEach((c, i) => {
        const side = i % 2 === 0 ? -1 : 1;
        c.position.x = side * (0.42 + Math.abs(Math.sin(elapsed.current * (10 * health + 2))) * 0.28 * health);
        c.rotation.z = side * 0.12;
      });
    }
    if (waves.current) {
      waves.current.visible = condition !== "nodules" || inflame < 60;
      waves.current.children.forEach((w, i) => {
        const ph = (elapsed.current * (1.5 * health + 0.3) + i * 0.3) % 1;
        w.position.y = -0.5 - ph * 2;
        const s = 0.5 + ph;
        w.scale.set(s, 1, s);
        (w as THREE.Mesh).material = (w as THREE.Mesh).material;
      });
    }
  });
  return null;
}

export function Topic10193Sim(props: SimProps) {
  const condition = String(props.condition ?? "laryngitis");
  const inflame = Number(props.inflame ?? 45);
  const cords = useRef<THREE.Group>(null!);
  const waves = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const voice = inflame < 30 ? "clear voice" : inflame < 65 ? "hoarse voice" : "voice nearly gone";
  const cordColor = new THREE.Color().setHSL(0.02, 0.55, 0.75 - (inflame / 100) * 0.3).getStyle();

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", condition], ["Voice", voice]]} />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* larynx frame: thyroid cartilage */}
        <group position={[0, 2.6, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[1.5, 1.1, 2.2, 6]} />
            <meshStandardMaterial color={condition === "pharyngitis" ? "#f87171" : "#e8b58e"} transparent opacity={0.4} roughness={0.6} emissive={condition === "pharyngitis" ? "#ef4444" : "#000000"} emissiveIntensity={condition === "pharyngitis" ? 0.35 : 0} />
          </mesh>
          <Label text="LARYNX (voice box)" position={[0, 1.7, 0]} size={0.55} color="#fcd9b8" />
          {/* vocal cords */}
          <group ref={cords}>
            {[-1, 1].map((s) => (
              <mesh key={s} position={[s * 0.55, 0.5, 0]} castShadow>
                <boxGeometry args={[0.5, 0.16, 1.4]} />
                <meshStandardMaterial color={cordColor} roughness={0.5} emissive="#ef4444" emissiveIntensity={inflame / 220} />
              </mesh>
            ))}
          </group>
          <Label text="VOCAL CORDS" position={[0, 1.15, 0]} size={0.5} color="#fca5a5" />
          {/* nodules */}
          {condition === "nodules" && (
            <group>
              {[-0.35, 0.35].map((x) => (
                <mesh key={x} position={[x, 0.62, 0.3]}>
                  <sphereGeometry args={[0.14, 10, 10]} />
                  <meshStandardMaterial color="#fde047" emissive="#eab308" emissiveIntensity={0.6} />
                </mesh>
              ))}
              <Label text="NODULES (singer's bumps)" position={[0, -0.4, 0]} size={0.5} color="#fde047" />
            </group>
          )}
          {/* sound waves below */}
          <group ref={waves}>
            {[0, 1, 2].map((i) => (
              <mesh key={i} position={[0, -0.5 - i * 0.6, 0]}>
                <torusGeometry args={[0.4, 0.06, 8, 20]} />
                <meshStandardMaterial color="#7dd3fc" emissive="#38bdf8" emissiveIntensity={0.8} transparent opacity={0.8} />
              </mesh>
            ))}
          </group>
        </group>
        <Animator cords={cords} waves={waves} elapsed={elapsed} inflame={inflame} condition={condition} />
      </SimCanvas>
    </div>
  );
}
