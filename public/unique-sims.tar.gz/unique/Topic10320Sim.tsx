// Bacterial skin infections: impetigo, cellulitis, folliculitis.
// A cross-section of skin — epidermis, dermis, hair follicle. Golden staph
// invades: honey-colored crusts of impetigo, the spreading red of cellulitis,
// or pus-filled bumps around hairs.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "infection", label: "Infection", kind: "select", min: 0, max: 0, step: 1, default: "impetigo", options: ["impetigo", "cellulitis", "folliculitis"] },
  { key: "severity", label: "Severity", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.7, unit: "" },
];

export const UNIQUE_META = {
  title: "Skin Infections: Impetigo & Cellulitis",
  blurb: "Under the skin's surface — honey crusts of impetigo, cellulitis redness spreading, or infected hair follicles.",
};

function Animator({
  group, germs, spread, elapsed, severity, infection,
}: {
  group: React.RefObject<THREE.Group>;
  germs: React.RefObject<THREE.Group>;
  spread: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  severity: number;
  infection: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.15;
    if (germs.current) {
      germs.current.children.forEach((g, i) => {
        g.position.y = 2.2 + Math.sin(t * 2.5 + i * 2.1) * 0.15;
        (g as THREE.Mesh).scale.setScalar(0.8 + 0.4 * severity + 0.15 * Math.sin(t * 4 + i));
      });
    }
    if (spread.current && infection === "cellulitis") {
      // redness spreads outward with severity
      const r = 0.8 + severity * 1.6 + 0.1 * Math.sin(t * 2);
      spread.current.scale.set(r, 1, r * 0.8);
      (spread.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.3 + 0.3 * Math.sin(t * 3);
    }
  });
  return null;
}

export function Topic10320Sim(props: SimProps) {
  const infection = String(props.infection ?? "impetigo");
  const severity = Number(props.severity ?? 0.7);
  const group = useRef<THREE.Group>(null!);
  const germs = useRef<THREE.Group>(null!);
  const spread = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    impetigo: "Impetigo (honey crusts)", cellulitis: "Cellulitis (spreading)", folliculitis: "Folliculitis",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Infection", names[infection] ?? infection], ["Severity", `${Math.round(severity * 100)}%`]]} />
      <SimCanvas cameraPosition={[0, 2.6, 10]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* dermis block */}
          <mesh position={[0, 1.0, 0]} castShadow receiveShadow>
            <boxGeometry args={[7, 1.6, 4]} />
            <meshStandardMaterial color="#f0abfc" roughness={0.7} />
          </mesh>
          {/* epidermis: thin top layer */}
          <mesh position={[0, 1.95, 0]} castShadow>
            <boxGeometry args={[7, 0.3, 4]} />
            <meshStandardMaterial color="#f5c396" roughness={0.6} />
          </mesh>
          {/* hair follicles */}
          {[-2.2, -0.7, 0.8, 2.3].map((x, i) => (
            <group key={i} position={[x, 1.9, 0.5]}>
              <mesh rotation={[0, 0, 0.3]} castShadow>
                <cylinderGeometry args={[0.12, 0.16, 1.2, 10]} />
                <meshStandardMaterial color="#92400e" roughness={0.6} />
              </mesh>
              <mesh position={[0.25, 0.9, 0]} rotation={[0, 0, 0.3]} castShadow>
                <cylinderGeometry args={[0.03, 0.03, 0.9, 6]} />
                <meshStandardMaterial color="#451a03" roughness={0.6} />
              </mesh>
              {/* infected follicle: red pus bump */}
              {infection === "folliculitis" && (
                <mesh position={[0, 0.35, 0]} castShadow>
                  <sphereGeometry args={[0.28 * (0.5 + severity), 14, 10]} />
                  <meshStandardMaterial color="#dc2626" roughness={0.4} emissive="#7f1d1d" emissiveIntensity={0.7} />
                </mesh>
              )}
            </group>
          ))}
          {/* impetigo: honey-colored crusts on the surface */}
          {infection === "impetigo" && (
            <>
              {[-1.4, 0.2, 1.6].map((x, i) => (
                <mesh key={i} position={[x, 2.18, 0.3]} scale={[1, 0.35, 0.8]} castShadow>
                  <sphereGeometry args={[0.45 * (0.5 + severity * 0.7), 14, 10]} />
                  <meshStandardMaterial color="#fbbf24" roughness={0.9} emissive="#92400e" emissiveIntensity={0.3} flatShading />
                </mesh>
              ))}
            </>
          )}
          {/* cellulitis: spreading red zone */}
          {infection === "cellulitis" && (
            <mesh ref={spread} position={[0, 2.05, 0]} castShadow>
              <cylinderGeometry args={[1, 1, 0.25, 28]} />
              <meshStandardMaterial color="#ef4444" roughness={0.5} transparent opacity={0.55} emissive="#7f1d1d" emissiveIntensity={0.5} />
            </mesh>
          )}
          {/* staph bacteria (golden clusters) */}
          <group ref={germs}>
            {Array.from({ length: 14 }).map((_, i) => (
              <mesh key={i} position={[-2.5 + (i % 7) * 0.85, 2.2, -1 + Math.floor(i / 7) * 1.6]} castShadow>
                <sphereGeometry args={[0.13, 10, 8]} />
                <meshStandardMaterial color="#fde047" emissive="#a16207" emissiveIntensity={0.9} />
              </mesh>
            ))}
          </group>
          {/* lymphatic streak heading up (cellulitis warning) */}
          {infection === "cellulitis" && (
            <mesh position={[2.8, 2.6, 0]} rotation={[0, 0, 0.5]} castShadow>
              <cylinderGeometry args={[0.08, 0.08, 1.6, 8]} />
              <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={0.8} />
            </mesh>
          )}
          <Label text="Epidermis" position={[-3.9, 1.95, 0]} size={0.5} color="#f5c396" />
          <Label text="Dermis" position={[-3.9, 1.0, 0]} size={0.5} color="#f0abfc" />
          <Label text="🦠 Staph bacteria" position={[0, 3.1, 0]} size={0.55} color="#fde047" />
          {infection === "impetigo" && <Label text="🍯 Honey-colored crusts" position={[0, 0.15, 0.3]} size={0.55} color="#fde68a" />}
          {infection === "cellulitis" && <Label text="⚠ Redness spreading — needs antibiotics" position={[0, 0.15, 0]} size={0.55} color="#fca5a5" />}
          {infection === "folliculitis" && <Label text="Pus bumps around hairs" position={[0, 0.15, 0.5]} size={0.55} color="#fca5a5" />}
        </group>
        <Animator group={group} germs={germs} spread={spread} elapsed={elapsed} severity={severity} infection={infection} />
      </SimCanvas>
    </div>
  );
}
