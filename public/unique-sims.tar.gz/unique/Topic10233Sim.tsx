// Glomerular diseases, tubular disorders & dialysis — a giant glomerulus:
// a ball of capillaries that should keep protein in. The leak slider opens
// holes and red protein dots spill into the urine cup; a dialysis machine
// cycles blood through its filter.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "leak", label: "Glomerular leak", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "dialysis", label: "Dialysis", kind: "select", min: 0, max: 0, step: 1, default: "off", options: ["off", "on"] },
];

export const UNIQUE_META = {
  title: "Glomerular Disease & Dialysis",
  blurb: "Protein spills through a leaky glomerulus into the urine — flip dialysis on and watch the machine clean the blood.",
};

function Animator({ protein, blood, elapsed, leak, dialysisOn }: {
  protein: React.RefObject<THREE.Group>;
  blood: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  leak: number;
  dialysisOn: boolean;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (protein.current) {
      protein.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * 0.7 + i * 0.19) % 1);
        // protein dots fall from the glomerulus into the urine cup
        m.position.y = 2.6 - ph * 3.4;
        m.position.x = -2.4 + Math.sin(ph * 6 + i) * 0.25;
        m.visible = ph < leak / 100;
      });
    }
    if (blood.current) {
      blood.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * 0.9 + i * 0.11) % 1);
        // blood loops: body → machine → back
        const x = 1.6 + ph * 5.2;
        m.position.x = x > 6.8 ? 11.6 - x : x; // out-and-back
        m.visible = dialysisOn;
      });
    }
  });
  return null;
}

export function Topic10233Sim(props: SimProps) {
  const leak = Number(props.leak ?? 60);
  const dialysisOn = String(props.dialysis ?? "off") === "on";
  const protein = useRef<THREE.Group>(null!);
  const blood = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const capLoops = useMemo(() => {
    return Array.from({ length: 14 }).map((_, i) => {
      const a = (i / 14) * Math.PI * 2;
      return { a, r: 0.55 + ((i * 0.37) % 0.5) };
    });
  }, []);

  const foamy = leak > 55;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Protein in urine", `${Math.round((leak / 100) * 4.2 * 10) / 10} g/day`], ["Urine", foamy ? "frothy ⚠" : "normal"], ["Dialysis", dialysisOn ? "running — blood cleaned" : "off"]]} />
      <SimCanvas cameraPosition={[0, 2.8, 14]} target={[0.6, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* Bowman's capsule */}
        <mesh position={[-2.4, 2.6, 0]} castShadow>
          <sphereGeometry args={[1.5, 28, 22]} />
          <meshStandardMaterial color="#fde68a" transparent opacity={0.35} roughness={0.3} side={THREE.DoubleSide} />
        </mesh>
        {/* glomerulus: tangled capillary ball */}
        <group position={[-2.4, 2.6, 0]}>
          {capLoops.map((c, i) => (
            <mesh key={i} rotation={[c.a, c.a * 0.7, 0]}>
              <torusGeometry args={[c.r, 0.11, 8, 22]} />
              <meshStandardMaterial color="#dc2626" roughness={0.45} emissive="#7f1d1d" emissiveIntensity={0.35} />
            </mesh>
          ))}
        </group>
        {/* leaking protein dots */}
        <group ref={protein}>
          {Array.from({ length: 12 }).map((_, i) => (
            <mesh key={i} position={[-2.4, 2.6, 0]}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshBasicMaterial color="#f87171" />
            </mesh>
          ))}
        </group>
        {/* urine cup */}
        <mesh position={[-2.4, -0.6, 0]}>
          <cylinderGeometry args={[0.75, 0.6, 1.0, 18, 1, true]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.4} side={THREE.DoubleSide} transparent opacity={0.7} />
        </mesh>
        <mesh position={[-2.4, -0.75, 0]}>
          <cylinderGeometry args={[0.68, 0.68, 0.3 + (leak / 100) * 0.4, 18]} />
          <meshStandardMaterial color="#facc15" roughness={0.3} emissive={foamy ? "#a16207" : "#000"} emissiveIntensity={0.3} />
        </mesh>
        <Label text={foamy ? "Frothy urine = protein leak" : "Glomerulus filters blood"} position={[-2.4, 4.6, 0]} size={0.5} color={foamy ? "#fca5a5" : "#fde047"} />

        {/* dialysis machine */}
        <group position={[4.6, 0, 0]}>
          <mesh position={[0, 1.8, 0]} castShadow>
            <boxGeometry args={[2.2, 3.2, 1.6]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.4} />
          </mesh>
          <mesh position={[0, 2.4, 0.85]}>
            <boxGeometry args={[1.6, 1.0, 0.1]} />
            <meshStandardMaterial color={dialysisOn ? "#22c55e" : "#1e293b"} roughness={0.3} emissive={dialysisOn ? "#14532d" : "#000"} emissiveIntensity={0.6} />
          </mesh>
          {/* dialyzer cylinder */}
          <mesh position={[0, 0.9, 0.9]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.3, 0.3, 1.6, 14]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.35} transparent opacity={0.8} />
          </mesh>
          <Label text={dialysisOn ? "Dialysis ON — artificial kidney" : "Dialysis machine (off)"} position={[0, 4.0, 0]} size={0.48} color={dialysisOn ? "#86efac" : "#94a3b8"} />
        </group>
        {/* blood loop dots */}
        <group ref={blood}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i} position={[1.6, 1.0, 0.9]}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshBasicMaterial color="#ef4444" />
            </mesh>
          ))}
        </group>

        <Animator protein={protein} blood={blood} elapsed={elapsed} leak={leak} dialysisOn={dialysisOn} />
      </SimCanvas>
    </div>
  );
}
