// Obstetrics: normal labor — stages, mechanisms, partograph.
// The baby descends through the pelvis head-first: engagement, descent with
// rotation, then crowning and delivery. The stage marker lights as labor
// progresses from contractions to the placenta.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Labor stage", kind: "select", min: 0, max: 0, step: 1, default: "auto", options: ["auto", "stage1", "stage2", "stage3"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Normal Labor: Baby's Journey Out",
  blurb: "Follow the baby's head-first journey through the pelvis — engagement, rotation, crowning, and delivery of the placenta.",
};

const STAGES = ["1st: cervix opens", "2nd: baby is born", "3rd: placenta out"];

function Animator({
  group, baby, stageDots, contractRing, elapsed, speed, stage,
}: {
  group: React.RefObject<THREE.Group>;
  baby: React.RefObject<THREE.Group>;
  stageDots: React.RefObject<THREE.Group>;
  contractRing: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
  stage: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
    // labor timeline: 24s loop through all stages (or hold one stage)
    const cyc = stage === "auto" ? (t % 24) / 24 : { stage1: 0.15, stage2: 0.6, stage3: 0.9 }[stage] ?? 0.15;
    const stageIdx = cyc < 0.45 ? 0 : cyc < 0.8 ? 1 : 2;
    if (baby.current) {
      // descent path: high in pelvis -> rotating -> crowning -> out
      const d = Math.min(1, Math.max(0, (cyc - 0.05) / 0.75));
      baby.current.position.y = 3.1 - d * 3.3;
      baby.current.position.z = 0.1 + d * 0.5;
      baby.current.rotation.y = d * Math.PI * 0.5; // internal rotation
      baby.current.rotation.x = d > 0.8 ? (d - 0.8) * 2 : 0;
    }
    if (stageDots.current) {
      stageDots.current.children.forEach((dot, i) => {
        const m = (dot as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = i === stageIdx ? 1.6 : i < stageIdx ? 0.7 : 0.08;
      });
    }
    if (contractRing.current) {
      // contraction waves squeeze the uterus in stage 1
      const wave = stageIdx === 0 ? 0.5 + 0.5 * Math.sin(t * 2.4) : 0;
      contractRing.current.scale.set(1 - wave * 0.12, 1, 1 - wave * 0.12);
      (contractRing.current.material as THREE.MeshStandardMaterial).emissiveIntensity = wave * 0.8;
    }
  });
  return null;
}

export function Topic10277Sim(props: SimProps) {
  const stage = String(props.stage ?? "auto");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const baby = useRef<THREE.Group>(null!);
  const stageDots = useRef<THREE.Group>(null!);
  const contractRing = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Mode", stage === "auto" ? "Full labor (auto)" : STAGES[["stage1", "stage2", "stage3"].indexOf(stage)]], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.6, 10.5]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* pelvis: two hip bones forming the birth canal */}
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 1.35, 1.9, 0]} rotation={[0, 0, s * 0.35]} castShadow>
              <torusGeometry args={[1.05, 0.28, 14, 24, Math.PI * 1.1]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
            </mesh>
          ))}
          {/* uterus contracting above */}
          <mesh ref={contractRing} position={[0, 3.6, -0.2]} scale={[1.15, 1.25, 1]} castShadow>
            <sphereGeometry args={[1.0, 28, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.6} emissive="#be185d" emissiveIntensity={0.2} />
          </mesh>
          {/* baby: head-first, curled */}
          <group ref={baby} position={[0, 3.1, 0.1]}>
            <mesh position={[0, -0.55, 0]} castShadow>
              <sphereGeometry args={[0.42, 22, 16]} />
              <meshStandardMaterial color="#fde68a" roughness={0.6} />
            </mesh>
            <mesh position={[0, 0.25, 0]} scale={[0.9, 1.1, 0.8]} castShadow>
              <sphereGeometry args={[0.4, 22, 16]} />
              <meshStandardMaterial color="#fde68a" roughness={0.6} />
            </mesh>
            {[-0.35, 0.35].map((x, i) => (
              <mesh key={i} position={[x, 0.0, 0.25]} rotation={[0, 0, i === 0 ? 0.5 : -0.5]} castShadow>
                <capsuleGeometry args={[0.1, 0.35, 6, 10]} />
                <meshStandardMaterial color="#fde68a" roughness={0.6} />
              </mesh>
            ))}
          </group>
          {/* placenta delivered in stage 3 */}
          <mesh position={[1.9, 0.75, 0.6]} scale={[1, 0.35, 1]} castShadow>
            <cylinderGeometry args={[0.5, 0.55, 0.25, 18]} />
            <meshStandardMaterial color="#7c2d12" roughness={0.6} />
          </mesh>
          <mesh position={[1.9, 1.05, 0.6]} rotation={[0, 0, 0.6]} castShadow>
            <cylinderGeometry args={[0.06, 0.06, 1.1, 8]} />
            <meshStandardMaterial color="#f472b6" roughness={0.5} />
          </mesh>
          {/* stage tracker */}
          <group ref={stageDots} position={[-3.6, 3.2, 0]}>
            {STAGES.map((_, i) => (
              <mesh key={i} position={[0, -i * 0.85, 0]} castShadow>
                <sphereGeometry args={[0.24, 14, 10]} />
                <meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={1.2} />
              </mesh>
            ))}
          </group>
          {STAGES.map((s, i) => (
            <Label key={s} text={s} position={[-2.3, 3.2 - i * 0.85, 0]} size={0.44} color="#bae6fd" />
          ))}
          <Label text="Pelvis" position={[2.6, 2.4, 0]} size={0.55} color="#e2e8f0" />
          <Label text="Placenta (3rd stage)" position={[1.9, 0.05, 0.6]} size={0.45} color="#fdba74" />
        </group>
        <Animator group={group} baby={baby} stageDots={stageDots} contractRing={contractRing} elapsed={elapsed} speed={speed} stage={stage} />
      </SimCanvas>
    </div>
  );
}
