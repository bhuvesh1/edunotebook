// Topic10583 — Dental identification in mass disasters.
// A forensic bench: an unknown jaw under a scanner beam. As the beam
// sweeps, each tooth's shape matches the ante-mortem chart — when all
// match, the identity is confirmed.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Scan speed", kind: "slider", min: 0.5, max: 3, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Dental identification in mass disasters",
  blurb: "A scanner sweeps an unknown jaw and matches every tooth to the dental chart — identity confirmed.",
};

const TOOTH_XS = [-3.15, -2.25, -1.35, -0.45, 0.45, 1.35, 2.25, 3.15];
const FDI = ["18", "17", "16", "15", "25", "26", "27", "28"];

function Animator({
  beam,
  teeth,
  confirmed,
  elapsed,
  speed,
}: {
  beam: RefObject<THREE.Mesh>;
  teeth: RefObject<THREE.Group>;
  confirmed: RefObject<THREE.Group>;
  elapsed: RefObject<number>;
  speed: number;
}) {
  const matched = useMemo(() => new Array(TOOTH_XS.length).fill(false), []);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const cycle = 12;
    const ct = t % cycle;
    const bx = -4 + (ct / (cycle - 2)) * 8; // sweep, then pause
    if (beam.current) {
      beam.current.position.x = bx;
      const m = beam.current.material as THREE.MeshStandardMaterial;
      m.opacity = ct > cycle - 2 ? 0.08 : 0.45;
    }
    if (teeth.current) {
      let all = true;
      teeth.current.children.forEach((mesh, i) => {
        if (ct > cycle - 2) matched[i] = false; // reset during pause
        else if (bx > TOOTH_XS[i] - 0.2) matched[i] = true;
        const mat = (mesh as THREE.Mesh).material as THREE.MeshStandardMaterial;
        mat.emissive.setHex(matched[i] ? 0x16a34a : 0x000000);
        mat.emissiveIntensity = matched[i] ? 0.7 : 0;
        if (!matched[i]) all = false;
      });
      if (confirmed.current) {
        confirmed.current.visible = all;
        confirmed.current.scale.setScalar(all ? 1 + 0.06 * Math.sin(t * 8) : 1);
      }
    }
  });
  return null;
}

export function Topic10583Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const beam = useRef<THREE.Mesh>(null!);
  const teeth = useRef<THREE.Group>(null!);
  const confirmed = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Teeth matched", "8 / 8"],
          ["Basis", "Fillings, shape, roots"],
          ["ID status", "CONFIRMED ✓"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.2, 12]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* steel examination tray */}
        <mesh position={[0, 0.75, 0]} receiveShadow>
          <boxGeometry args={[9, 0.25, 3.4]} />
          <meshStandardMaterial color="#64748b" roughness={0.35} metalness={0.7} />
        </mesh>
        {/* the unknown jaw */}
        <mesh position={[0, 1.0, 0]}>
          <boxGeometry args={[8, 0.5, 2.2]} />
          <meshStandardMaterial color="#d6c2a3" roughness={0.8} />
        </mesh>
        <group ref={teeth}>
          {TOOTH_XS.map((x, i) => (
            <mesh key={i} position={[x, 1.75, 0]} castShadow>
              <boxGeometry args={[0.72, 0.9, 0.72]} />
              <meshStandardMaterial color="#fefdf8" roughness={0.35} />
            </mesh>
          ))}
        </group>
        {/* one gold crown — a strong identifier */}
        <mesh position={[TOOTH_XS[5], 1.75, 0]}>
          <boxGeometry args={[0.74, 0.92, 0.74]} />
          <meshStandardMaterial color="#eab308" roughness={0.25} metalness={0.8} />
        </mesh>

        {/* scanner beam */}
        <mesh ref={beam} position={[-4, 2.2, 0]}>
          <boxGeometry args={[0.35, 2.6, 2.6]} />
          <meshStandardMaterial color="#22d3ee" transparent opacity={0.4} emissive="#0ea5e9" emissiveIntensity={1.2} />
        </mesh>

        {/* ante-mortem record board */}
        <group position={[5.6, 2.6, -1.5]} rotation={[0, -0.5, 0]}>
          <mesh castShadow>
            <boxGeometry args={[3.4, 4.4, 0.15]} />
            <meshStandardMaterial color="#1e293b" roughness={0.6} />
          </mesh>
          {FDI.map((f, i) => (
            <mesh key={f} position={[-1.25 + (i % 4) * 0.85, 1.5 - Math.floor(i / 4) * 0.85, 0.1]}>
              <boxGeometry args={[0.6, 0.6, 0.06]} />
              <meshStandardMaterial color="#16a34a" roughness={0.5} emissive="#16a34a" emissiveIntensity={0.35} />
            </mesh>
          ))}
          <mesh position={[1.1, 1.5, 0.1]}>
            <boxGeometry args={[0.62, 0.62, 0.07]} />
            <meshStandardMaterial color="#eab308" roughness={0.3} metalness={0.7} emissive="#a16207" emissiveIntensity={0.5} />
          </mesh>
        </group>

        {/* CONFIRMED stamp */}
        <group ref={confirmed} position={[0, 4.6, 0]}>
          <mesh>
            <boxGeometry args={[4.6, 1.1, 0.2]} />
            <meshStandardMaterial color="#052e16" roughness={0.5} emissive="#16a34a" emissiveIntensity={0.8} />
          </mesh>
        </group>

        <Label text="UNKNOWN JAW — scan me" position={[-4.9, 1.6, 0]} size={0.38} color="#fcd34d" />
        <Label text="ANTE-MORTEM CHART — every tooth matches" position={[5.6, 5.4, -1.5]} size={0.36} color="#86efac" />
        <Label text="GOLD CROWN ON 26 — unique identifier!" position={[0, 0.1, 0]} size={0.36} color="#fde047" />
        <group position={[0, 4.6, 0.15]}>
          <Label text="IDENTITY: CONFIRMED ✓" position={[0, 0, 0]} size={0.5} color="#4ade80" />
        </group>

        <Animator beam={beam} teeth={teeth} confirmed={confirmed} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
