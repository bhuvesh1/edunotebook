// Bronchodilators: an asthma attack narrows the airway to a slit — a puff from
// the inhaler relaxes the muscle ring and the airway springs open.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "puffs", label: "Inhaler puffs", kind: "slider", min: 0, max: 4, step: 1, default: 2, unit: "" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Bronchodilators",
  blurb: "An asthma attack narrows the airway — inhaler puffs relax it and air flows freely again.",
};

const N_AIR = 12;

function Animator({ ring, air, puff, elapsed, puffs, setTick }: {
  ring: React.RefObject<THREE.Mesh>;
  air: React.RefObject<(THREE.Mesh | null)[]>;
  puff: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  puffs: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    // airway opens with puffs, slowly re-narrows
    const open = THREE.MathUtils.clamp(0.25 + puffs * 0.22 - Math.max(0, Math.sin(t * 0.25)) * 0.08, 0.2, 1);
    if (ring.current) {
      ring.current.scale.set(open, open, 1);
      const m = ring.current.material as THREE.MeshStandardMaterial;
      m.color.set(open > 0.7 ? "#4ade80" : open > 0.45 ? "#f59e0b" : "#ef4444");
      m.emissive.set(m.color.getHex());
    }
    air.current.forEach((a, i) => {
      if (!a) return;
      const f = (t * (0.4 + open * 1.1) + i / N_AIR) % 1;
      a.position.set(0, 3.4 - f * 4.6, 0);
      a.visible = open > 0.3 || f < 0.4;
      ((a as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = open * (1 - f * 0.5);
    });
    if (puff.current) {
      // periodic puff cloud from the inhaler
      const f = (t * 0.5) % 1;
      puff.current.position.set(2.9, 2.2, 0.4 - f * 1.6);
      puff.current.scale.setScalar(0.3 + f * 1.4);
      puff.current.children.forEach((c) => {
        ((c as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = Math.max(0, 0.7 - f * 0.9);
      });
      puff.current.visible = puffs > 0;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(open * 100)); }
  });
  return null;
}

export function Topic10125Sim(props: SimProps) {
  const puffs = Number(props.puffs ?? 2);
  const showLabels = String(props.detail ?? "on") === "on";
  const ring = useRef<THREE.Mesh>(null!);
  const air = useRef<(THREE.Mesh | null)[]>([]);
  const puff = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const state = tick > 70 ? "airway open" : tick > 45 ? "partial" : "bronchospasm!";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Airway opening", `${tick}%`],
          ["Status", state],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* trachea */}
        <mesh position={[0, 4.1, 0]} castShadow>
          <cylinderGeometry args={[0.5, 0.5, 1.6, 16]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.55} />
        </mesh>
        {/* bronchi splitting left/right */}
        {[-0.55, 0.55].map((x, i) => (
          <mesh key={i} position={[x, 2.9, 0]} rotation={[0, 0, x > 0 ? -0.45 : 0.45]} castShadow>
            <cylinderGeometry args={[0.34, 0.42, 1.6, 14]} />
            <meshStandardMaterial color="#f4a7b9" roughness={0.55} />
          </mesh>
        ))}
        {showLabels && <Label text="bronchial tree" position={[-2.6, 3.4, 0]} size={0.45} color="#f9a8d4" />}

        {/* constricting muscle ring around left bronchus */}
        <mesh ref={ring} position={[-0.88, 2.55, 0]} rotation={[0, 0, 0.45]}>
          <torusGeometry args={[0.5, 0.16, 10, 22]} />
          <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.6} />
        </mesh>
        {showLabels && <Label text="airway muscle — spasming" position={[-0.88, 1.5, 0]} size={0.45} color="#fca5a5" />}

        {/* airflow particles */}
        {Array.from({ length: N_AIR }).map((_, i) => (
          <mesh key={i} ref={(m) => { air.current[i] = m; }}>
            <sphereGeometry args={[0.09, 8, 8]} />
            <meshStandardMaterial color="#bae6fd" emissive="#38bdf8" emissiveIntensity={0.8} transparent />
          </mesh>
        ))}

        {/* inhaler */}
        <group position={[3.1, 1.4, 0.6]}>
          <mesh position={[0, 0.5, 0]} castShadow>
            <boxGeometry args={[0.5, 0.9, 0.5]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.4} />
          </mesh>
          <mesh position={[0, 1.1, 0.1]} rotation={[0.4, 0, 0]}>
            <boxGeometry args={[0.28, 0.35, 0.28]} />
            <meshStandardMaterial color="#0c4a6e" roughness={0.4} />
          </mesh>
        </group>
        {showLabels && <Label text={`inhaler — ${puffs} puffs`} position={[3.1, 2.7, 0.6]} size={0.45} color="#7dd3fc" />}

        {/* puff cloud */}
        <group ref={puff} visible={false}>
          {[0, 1, 2].map((i) => (
            <mesh key={i} position={[(i - 1) * 0.25, (i % 2) * 0.2, 0]}>
              <sphereGeometry args={[0.3, 10, 8]} />
              <meshStandardMaterial color="#e0f2fe" transparent opacity={0.6} />
            </mesh>
          ))}
        </group>

        <Animator ring={ring} air={air} puff={puff} elapsed={elapsed} puffs={puffs} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
