"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "infection", label: "Infection", kind: "select", min: 0, max: 0, step: 1, default: "abscess", options: ["abscess", "pericoronitis", "osteomyelitis"] },
  { key: "prophylaxis", label: "Endocarditis prophylaxis", kind: "select", min: 0, max: 0, step: 1, default: "off", options: ["off", "on"] },
];

export const UNIQUE_META = {
  title: "Antibiotics in dentistry: indications, prophylaxis for endocarditis",
  blurb: "Antibiotic capsules hunt down a dental infection — and a heart gets a protective shield when endocarditis prophylaxis is on.",
};

const INFO: Record<string, { name: string; note: string }> = {
  abscess: { name: "Periapical abscess", note: "Amoxicillin + drainage" },
  pericoronitis: { name: "Pericoronitis", note: "Metronidazole for anaerobes" },
  osteomyelitis: { name: "Osteomyelitis", note: "Long-course antibiotics" },
};

function KillBursts({ speed }: { speed: number }) {
  const pts = useRef<THREE.Points>(null!);
  const t = useRef(0);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(30 * 3), 3));
    return g;
  }, []);
  const centers = useMemo(() => [[-1.9, 0.6, 0], [-1.2, 0.9, 0.3], [-2.5, 0.3, -0.2]], []);
  useFrame((_, delta) => {
    t.current += delta * speed;
    if (!pts.current) return;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < 30; i++) {
      const c = centers[i % 3];
      const f = (t.current + i * 0.37) % 1;
      const a = i * 2.4;
      pos.setXYZ(i, c[0] + Math.cos(a) * f * 0.7, c[1] + f * 0.7, c[2] + Math.sin(a) * f * 0.7);
    }
    pos.needsUpdate = true;
  });
  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial color="#fde047" size={0.13} transparent opacity={0.95} />
    </points>
  );
}

function Scene({ infection, prophylaxis }: { infection: string; prophylaxis: boolean }) {
  const t = useRef(0);
  const pill = useRef<THREE.Group>(null!);
  const info = INFO[infection] ?? INFO.abscess;

  useFrame((_, delta) => {
    t.current += delta;
    if (pill.current) {
      pill.current.position.x = -3.4 + ((t.current * 0.9) % 3.4);
      pill.current.rotation.z = t.current * 2;
    }
  });

  return (
    <group>
      {/* infected tooth with pus */}
      <group position={[-1.9, 0.4, 0]}>
        <mesh position={[0, 0.3, 0]}>
          <cylinderGeometry args={[0.42, 0.55, 0.9, 14]} />
          <meshStandardMaterial color="#d6cfae" roughness={0.4} />
        </mesh>
        <mesh position={[0, -0.5, 0]}>
          <coneGeometry args={[0.4, 1.1, 14]} />
          <meshStandardMaterial color="#c9bfa4" roughness={0.5} />
        </mesh>
        {/* pus at apex */}
        <mesh position={[0, -1.15, 0]}>
          <sphereGeometry args={[0.4, 14, 14]} />
          <meshStandardMaterial color="#fde047" roughness={0.35} />
        </mesh>
        <Label text={info.name} position={[0, 1.6, 0]} size={0.5} color="#fde047" />
      </group>

      {/* antibiotic capsule flying in */}
      <group ref={pill} position={[-3.4, 2.2, 0]}>
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <capsuleGeometry args={[0.22, 0.5, 8, 14]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.35} />
        </mesh>
        <mesh position={[0.18, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.225, 0.225, 0.28, 14]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.35} />
        </mesh>
      </group>
      <KillBursts speed={1.2} />
      <Label text="Antibiotic kills bacteria" position={[-3, 2.9, 0]} size={0.45} color="#7dd3fc" />

      {/* heart with valve */}
      <group position={[2.4, 0.6, 0]}>
        <mesh position={[-0.28, 0.25, 0]}>
          <sphereGeometry args={[0.55, 18, 18]} />
          <meshStandardMaterial color="#dc2626" roughness={0.5} />
        </mesh>
        <mesh position={[0.28, 0.25, 0]}>
          <sphereGeometry args={[0.55, 18, 18]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.5} />
        </mesh>
        <mesh position={[0, -0.55, 0]} rotation={[Math.PI, 0, 0]}>
          <coneGeometry args={[0.62, 1.1, 18]} />
          <meshStandardMaterial color="#991b1b" roughness={0.5} />
        </mesh>
        {/* valve */}
        <mesh position={[0, 0.35, 0.35]} rotation={[Math.PI / 2.4, 0, 0]}>
          <torusGeometry args={[0.22, 0.06, 8, 18]} />
          <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.6} />
        </mesh>
        {prophylaxis && (
          <mesh>
            <sphereGeometry args={[1.35, 20, 20]} />
            <meshStandardMaterial color="#34d399" transparent opacity={0.22} roughness={0.2} side={THREE.BackSide} />
          </mesh>
        )}
        <Label text="Heart valve" position={[0, 1.5, 0]} size={0.45} color="#fca5a5" />
        <Label text={prophylaxis ? "Prophylaxis ON — 2g amoxicillin" : "Prophylaxis off"} position={[0, -1.9, 0]} size={0.42} color={prophylaxis ? "#6ee7b7" : "#94a3b8"} />
      </group>

      <Label text={info.note} position={[0, -2.9, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10420Sim(props: SimProps) {
  const infection = String(props.infection ?? "abscess");
  const prophylaxis = String(props.prophylaxis ?? "off") === "on";
  const info = INFO[infection] ?? INFO.abscess;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Infection", info.name], ["Regimen", info.note], ["Prophylaxis", prophylaxis ? "Given" : "Not needed"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, 0.3, 0]}>
        <Scene infection={infection} prophylaxis={prophylaxis} />
      </SimCanvas>
    </div>
  );
}
