"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "asthma", options: ["normal", "asthma", "COPD (emphysema)", "pneumonia"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Lung Disease: Asthma to COPD",
  blurb: "A branching airway tree with alveoli that narrow in asthma, over-inflate in emphysema, or consolidate in pneumonia.",
};

function Animator({ root, bron, alv, cons, air, elapsed, speed, asthma, copd, pneu }: { root: RefObject<THREE.Group>; bron: RefObject<THREE.Group>; alv: RefObject<THREE.Group>; cons: RefObject<THREE.Mesh>; air: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; asthma: boolean; copd: boolean; pneu: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const breath = 1 + 0.06 * Math.sin(t * 1.6);
    if (bron.current) {
      const narrow = asthma ? 0.55 + 0.1 * Math.sin(t * 5) : 1;
      bron.current.children.forEach((m) => { m.scale.x = narrow * breath; m.scale.z = narrow * breath; });
    }
    if (alv.current) {
      alv.current.children.forEach((m, i) => {
        const s = (copd ? 1.9 : 1) * (1 + 0.12 * Math.sin(t * 1.6 + i));
        m.scale.setScalar(s);
        ((m as THREE.Mesh).material as THREE.MeshStandardMaterial).color.set(copd ? "#fca5a5" : "#fda4af");
      });
    }
    if (cons.current) {
      cons.current.visible = pneu;
      (cons.current.material as THREE.MeshStandardMaterial).opacity = 0.45 + 0.15 * Math.sin(t * 2.5);
    }
    if (air.current) {
      air.current.children.forEach((m, i) => {
        const r = (t * 0.5 + i / 6) % 1;
        m.position.set(-0.2 + Math.sin(i * 3) * (0.3 + r * 1.6), 4.6 - r * 3.4, 0);
        m.scale.setScalar(asthma ? 0.5 : 1);
      });
    }
  });
  return null;
}

export function Topic10096Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const cond = String(props.cond ?? "asthma");
  const asthma = cond === "asthma";
  const copd = cond === "COPD (emphysema)";
  const pneu = cond === "pneumonia";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const bron = useRef<THREE.Group>(null!);
  const alv = useRef<THREE.Group>(null!);
  const cons = useRef<THREE.Mesh>(null!);
  const air = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", cond],
          ["Pathology", asthma ? "bronchospasm \u2014 reversible" : copd ? "alveolar destruction" : pneu ? "lobar consolidation" : "none"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 12]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 4.2, 0]} castShadow>
            <cylinderGeometry args={[0.42, 0.42, 2.2, 14]} /><meshStandardMaterial color="#fda4af" roughness={0.55} />
          </mesh>
          <group ref={bron}>
            {[[-1, 0.5], [1, -0.5]].map(([sx], i) => (
              <group key={i}>
                <mesh position={[sx * 0.9, 2.9, 0]} rotation={[0, 0, sx * 0.6]} castShadow>
                  <cylinderGeometry args={[0.3, 0.24, 1.8, 12]} /><meshStandardMaterial color="#fb7185" roughness={0.55} />
                </mesh>
                <mesh position={[sx * 1.7, 2.1, 0]} rotation={[0, 0, sx * 0.9]} castShadow>
                  <cylinderGeometry args={[0.2, 0.16, 1.4, 10]} /><meshStandardMaterial color="#f9a8d4" roughness={0.55} />
                </mesh>
              </group>
            ))}
          </group>
          <Label text="trachea" position={[1.2, 4.6, 0]} size={0.4} color="#fda4af" />
          <Label text="bronchi" position={[-2.6, 2.9, 0]} size={0.4} color="#fb7185" />
          <group ref={alv}>
            {Array.from({ length: 10 }).map((_, i) => {
              const sx = i % 2 === 0 ? -1 : 1;
              const x = sx * (1.9 + (i % 5) * 0.32), y = 1.15 + Math.floor(i / 2) * 0.3;
              return (
                <mesh key={i} position={[x, y, (i % 3 - 1) * 0.5]} castShadow>
                  <sphereGeometry args={[0.3, 14, 14]} /><meshStandardMaterial color="#fda4af" roughness={0.5} transparent opacity={0.9} />
                </mesh>
              );
            })}
          </group>
          <Label text="alveoli" position={[3.2, 1.4, 0]} size={0.4} color="#fda4af" />
          <mesh ref={cons} visible={false} position={[2.4, 1.5, 0]}>
            <sphereGeometry args={[1.1, 18, 18]} />
            <meshStandardMaterial color="#ef4444" transparent opacity={0.45} emissive="#b91c1d" emissiveIntensity={0.6} />
          </mesh>
          <group ref={air}>
            {Array.from({ length: 6 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.09, 8, 8]} /><meshStandardMaterial color="#bae6fd" transparent opacity={0.7} /></mesh>
            ))}
          </group>
          <Label text={asthma ? "asthma: airways narrow \u2014 wheeze" : copd ? "emphysema: alveoli destroyed, over-inflated" : pneu ? "pneumonia: lobe consolidated" : "healthy lungs"} position={[0, 5.6, 0]} size={0.46} color={cond === "normal" ? "#4ade80" : "#f87171"} />
        </group>
        <Animator root={root} bron={bron} alv={alv} cons={cons} air={air} elapsed={elapsed} speed={speed} asthma={asthma} copd={copd} pneu={pneu} />
      </SimCanvas>
    </div>
  );
}
