// Hospital-acquired infections: green germs hop from bed to bed down the ward
// — but good hand hygiene throws up a soap shield that stops the spread.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "hygiene", label: "Hand hygiene compliance", kind: "slider", min: 0, max: 100, step: 5, default: 65, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Hospital-acquired infections",
  blurb: "Germs hop bed to bed down the ward — hand hygiene throws up a shield that stops the spread.",
};

const N_GERMS = 12;
const BEDS = [-4.5, -1.5, 1.5, 4.5];

function Animator({ germs, shield, elapsed, hygiene, setTick }: {
  germs: React.RefObject<(THREE.Mesh | null)[]>;
  shield: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  hygiene: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = hygiene / 100;
    let spread = 0;
    germs.current.forEach((g, i) => {
      if (!g) return;
      // germs hop from bed to bed; hygiene blocks the hop
      const hop = (t * 0.3 + i / N_GERMS) % 1;
      const from = Math.floor(i / 3) % 4;
      const blocked = ((i * 47) % 10) / 10 < k;
      const reach = blocked ? 0.35 : 1; // how far the hop gets
      const bedX = BEDS[from];
      const nextX = BEDS[(from + 1) % 4];
      const arc = Math.sin(hop * Math.PI);
      g.position.set(
        bedX + (nextX - bedX) * hop * reach,
        1.9 + arc * 0.9,
        Math.sin(i * 2.1) * 0.8
      );
      g.rotation.y = t * 4 + i;
      const s = 0.7 + arc * 0.5;
      g.scale.setScalar(s);
      if (!blocked && hop > 0.8) spread++;
      ((g as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = blocked ? 0.2 : 0.9;
    });
    shield.current.forEach((s, i) => {
      if (!s) return;
      s.visible = k > 0.15;
      ((s as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = 0.1 + k * 0.25;
      s.rotation.y = t * 0.6 + i;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(spread); }
  });
  return null;
}

function Bed({ x }: { x: number }) {
  return (
    <group position={[x, 0, 0]}>
      <mesh position={[0, 0.75, 0]} castShadow>
        <boxGeometry args={[2.2, 0.22, 1.2]} />
        <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
      </mesh>
      {[-0.9, 0.9].map((lx, i) => (
        <mesh key={i} position={[lx, 0.35, 0.45]}>
          <cylinderGeometry args={[0.06, 0.06, 0.7, 8]} />
          <meshStandardMaterial color="#64748b" metalness={0.5} roughness={0.4} />
        </mesh>
      ))}
      {[-0.9, 0.9].map((lx, i) => (
        <mesh key={`b${i}`} position={[lx, 0.35, -0.45]}>
          <cylinderGeometry args={[0.06, 0.06, 0.7, 8]} />
          <meshStandardMaterial color="#64748b" metalness={0.5} roughness={0.4} />
        </mesh>
      ))}
      {/* patient */}
      <mesh position={[-0.3, 1.05, 0]} castShadow>
        <capsuleGeometry args={[0.22, 0.9, 6, 10]} />
        <meshStandardMaterial color="#93c5fd" roughness={0.6} />
      </mesh>
      <mesh position={[-0.3, 1.05, 0]} rotation={[0, 0, Math.PI / 2]}>
        <capsuleGeometry args={[0.22, 0.9, 6, 10]} />
        <meshStandardMaterial color="#93c5fd" roughness={0.6} />
      </mesh>
      <mesh position={[0.75, 1.0, 0]}>
        <sphereGeometry args={[0.2, 12, 10]} />
        <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
      </mesh>
    </group>
  );
}

export function Topic10148Sim(props: SimProps) {
  const hygiene = Number(props.hygiene ?? 65);
  const showLabels = String(props.detail ?? "on") === "on";
  const germs = useRef<(THREE.Mesh | null)[]>([]);
  const shield = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["New infections spreading", `${tick}`],
          ["Control", hygiene > 70 ? "hygiene holding" : hygiene > 35 ? "partial" : "outbreak!"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 14]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* ward floor */}
        <mesh position={[0, 0.02, 0]} receiveShadow>
          <boxGeometry args={[12.5, 0.06, 3.4]} />
          <meshStandardMaterial color="#1e3a5f" roughness={0.7} />
        </mesh>

        {BEDS.map((x, i) => (
          <group key={i}>
            <Bed x={x} />
            {/* soap shield over each bed */}
            <mesh ref={(m) => { shield.current[i] = m; }} position={[x, 1.4, 0]} visible={hygiene > 15}>
              <sphereGeometry args={[1.5, 18, 12]} />
              <meshStandardMaterial color="#67e8f9" transparent opacity={0.2} side={THREE.DoubleSide} depthWrite={false} />
            </mesh>
          </group>
        ))}
        {showLabels && <Label text="hospital ward" position={[0, 3.4, 0]} color="#bae6fd" />}
        {showLabels && <Label text="hand-hygiene shield" position={[4.5, 2.9, 0]} size={0.4} color="#67e8f9" />}

        {/* hopping germs */}
        {Array.from({ length: N_GERMS }).map((_, i) => (
          <mesh key={i} ref={(m) => { germs.current[i] = m; }} castShadow>
            <icosahedronGeometry args={[0.2]} />
            <meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={0.8} flatShading />
          </mesh>
        ))}
        {showLabels && <Label text="HAI germs hopping bed → bed" position={[-4.5, 3.1, 0]} size={0.45} color="#86efac" />}

        {/* sanitizer dispenser */}
        <group position={[0, 0, 2.8]}>
          <mesh position={[0, 1.1, 0]} castShadow>
            <boxGeometry args={[0.5, 0.9, 0.35]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.4} />
          </mesh>
          <mesh position={[0, 1.7, 0]}>
            <boxGeometry args={[0.2, 0.15, 0.2]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.4} />
          </mesh>
        </group>
        {showLabels && <Label text={`sanitizer — ${hygiene}%`} position={[0, 2.2, 2.8]} size={0.45} color="#7dd3fc" />}

        <Animator germs={germs} shield={shield} elapsed={elapsed} hygiene={hygiene} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
