"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "htype", label: "Hypersensitivity", kind: "select", min: 0, max: 0, step: 1, default: "Type I", options: ["Type I", "Type IV"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Hypersensitivity: Allergy Attack",
  blurb: "Allergens cross-link IgE on a mast cell and trigger explosive histamine degranulation.",
};

function Animator({ root, alg, hist, tcell, elapsed, speed, type1 }: { root: RefObject<THREE.Group>; alg: RefObject<THREE.Group>; hist: RefObject<THREE.Group>; tcell: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; type1: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const q = (t * 0.4) % 1;
    if (alg.current) {
      alg.current.visible = type1;
      alg.current.children.forEach((m, i) => {
        const a = i * 1.7;
        m.position.set(Math.cos(a) * (4.5 - Math.min(1, q * 1.6) * 3.4), 1.9 + Math.sin(a) * 1.4, Math.sin(a) * 1.2);
      });
    }
    if (hist.current) {
      hist.current.visible = type1;
      hist.current.children.forEach((m, i) => {
        const r = Math.max(0, q - 0.45) * 3.4;
        const a = (i / 10) * Math.PI * 2;
        m.position.set(Math.cos(a) * (1 + r), 1.9 + Math.sin(a * 1.5) * (0.6 + r * 0.5), Math.sin(a) * (1 + r));
        m.scale.setScalar(q > 0.45 ? 1 : 0.001);
      });
    }
    if (tcell.current) {
      tcell.current.visible = !type1;
      tcell.current.position.set(5 - ((t * 0.25) % 1) * 3.4, 1.9 + Math.sin(t * 2) * 0.2, 0);
    }
  });
  return null;
}

export function Topic10088Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const htype = String(props.htype ?? "Type I");
  const type1 = htype === "Type I";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const alg = useRef<THREE.Group>(null!);
  const hist = useRef<THREE.Group>(null!);
  const tcell = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Type", htype],
          ["Mediator", type1 ? "histamine (immediate)" : "cytokines (delayed 48\u201372 h)"],
          ["Cell", type1 ? "mast cell + IgE" : "Th1 + macrophage"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 1.9, 0]} castShadow>
            <icosahedronGeometry args={[1.15, 1]} />
            <meshStandardMaterial color="#a855f7" roughness={0.5} flatShading />
          </mesh>
          {Array.from({ length: 6 }).map((_, i) => {
            const a = (i / 6) * Math.PI * 2;
            return (
              <mesh key={i} position={[Math.cos(a) * 1.25, 1.9 + Math.sin(a) * 1.25, 0]} rotation={[0, 0, a - Math.PI / 2]}>
                <coneGeometry args={[0.12, 0.5, 8]} /><meshStandardMaterial color="#facc15" roughness={0.4} />
              </mesh>
            );
          })}
          <Label text="mast cell" position={[-2.2, 3.3, 0]} color="#c084fc" />
          <Label text="IgE antibodies" position={[2.2, 3.3, 0]} size={0.42} color="#facc15" />
          <group ref={alg}>
            {Array.from({ length: 4 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.24, 12, 12]} /><meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={0.7} /></mesh>
            ))}
          </group>
          <Label text="allergen" position={[4.4, 1, 0]} size={0.42} color="#4ade80" />
          <group ref={hist}>
            {Array.from({ length: 10 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.15, 10, 10]} /><meshStandardMaterial color="#fb923c" emissive="#ea580c" emissiveIntensity={1} /></mesh>
            ))}
          </group>
          <Label text="histamine burst!" position={[0, 4.4, 0]} size={0.45} color="#fb923c" />
          <mesh ref={tcell} visible={false} castShadow>
            <sphereGeometry args={[0.6, 18, 18]} /><meshStandardMaterial color="#38bdf8" roughness={0.45} />
          </mesh>
          <Label text={type1 ? "Type I: immediate \u2014 anaphylaxis" : "Type IV: delayed \u2014 T-cell mediated"} position={[0, 5.2, 0]} size={0.45} color="#f8fafc" />
        </group>
        <Animator root={root} alg={alg} hist={hist} tcell={tcell} elapsed={elapsed} speed={speed} type1={type1} />
      </SimCanvas>
    </div>
  );
}
