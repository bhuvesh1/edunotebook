// CVS: cardiac output, coronary circulation, shock — a beating heart wrapped in
// red coronary arteries, with CO ejected per beat; flip to shock and the heart
// pales as flow collapses.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "co", label: "Cardiac output", kind: "slider", min: 1, max: 12, step: 0.5, default: 5, unit: "L/min" },
  { key: "state", label: "Circulatory state", kind: "select", min: 0, max: 0, step: 1, default: "normal", options: ["normal", "shock"] },
];

export const UNIQUE_META = {
  title: "CVS: Cardiac Output & Shock",
  blurb: "Coronary arteries feed the beating heart — watch output collapse and the heart pale in shock.",
};

function Animator({
  heart, ejecta, coronaries, elapsed, co, shock, speed,
}: {
  heart: React.RefObject<THREE.Group>;
  ejecta: React.RefObject<THREE.Group>;
  coronaries: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  co: number;
  shock: boolean;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const hr = shock ? 130 : 72;
    const cyc = (t * (hr / 60)) % 1;
    const beat = Math.pow(Math.max(0, Math.sin(cyc * Math.PI * 2)), 2);
    if (heart.current) {
      const s = 1 + (shock ? 0.06 : 0.13) * beat;
      heart.current.scale.set(s, 1 - 0.08 * beat, s);
    }
    if (ejecta.current) {
      ejecta.current.children.forEach((m, i) => {
        const ph = ((cyc * 2 + i / 10) % 1 + 1) % 1;
        m.position.y = 4.6 + ph * 2.2 * (shock ? 0.4 : 1);
        const sc = (shock ? 0.4 : 1) * (0.5 + (co / 12)) * (1 - ph * 0.5);
        m.scale.setScalar(Math.max(0.05, sc));
        m.visible = beat > 0.15;
      });
    }
    if (coronaries.current) {
      coronaries.current.children.forEach((m, i) => {
        const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = (shock ? 0.15 : 0.55) + 0.25 * beat * (i % 2 ? 1 : 0.4);
      });
    }
  });
  return null;
}

export function Topic10039Sim(props: SimProps) {
  const co = Number(props.co ?? 5);
  const shock = String(props.state ?? "normal") === "shock";
  const speed = 1;
  const heart = useRef<THREE.Group>(null!);
  const ejecta = useRef<THREE.Group>(null!);
  const coronaries = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const heartColor = shock ? "#b0898f" : "#dc2626";

  const coronaryCurves = useMemo(() => {
    const mk = (pts: [number, number, number][]) =>
      new THREE.Mesh(
        new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(...p))), 40, 0.09, 8, false),
        new THREE.MeshStandardMaterial({ color: "#f87171", emissive: "#7f1d1d", emissiveIntensity: 0.5, roughness: 0.4 })
      );
    return [
      mk([[-0.4, 3.9, 0.9], [-0.9, 3.0, 1.05], [-0.7, 2.0, 0.95], [-0.3, 1.2, 0.7]]), // LAD
      mk([[0.4, 3.9, 0.9], [1.0, 3.2, 1.0], [1.1, 2.2, 0.85], [0.8, 1.4, 0.6]]),     // RCA
      mk([[-0.4, 3.9, 0.9], [-1.3, 3.4, 0.5], [-1.5, 2.6, 0.2]]),                    // LCx
    ];
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Cardiac output", `${co.toFixed(1)} L/min`],
          ["State", shock ? "⚠ SHOCK — low perfusion" : "normal perfusion ✓"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 14]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* heart */}
        <group ref={heart} position={[-1.5, 0, 0]}>
          <mesh position={[0, 2.4, 0]} castShadow scale={[1.05, 1.3, 0.95]}>
            <sphereGeometry args={[1.25, 24, 24]} />
            <meshStandardMaterial color={heartColor} roughness={0.4} />
          </mesh>
          {/* aorta arch */}
          <mesh position={[0.1, 4.15, 0]} rotation={[0, 0, -0.3]} castShadow>
            <cylinderGeometry args={[0.34, 0.34, 2.0, 14]} />
            <meshStandardMaterial color={shock ? "#c49a9e" : "#ef4444"} roughness={0.4} />
          </mesh>
          {/* coronary arteries on the surface */}
          <group ref={coronaries}>
            {coronaryCurves.map((c, i) => (
              <primitive key={i} object={c} />
            ))}
          </group>
        </group>
        {/* stroke volume ejected upward per beat */}
        <group ref={ejecta}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i} position={[-1.4, 4.6, 0]}>
              <sphereGeometry args={[0.16, 10, 10]} />
              <meshBasicMaterial color={shock ? "#d6a97c" : "#fca5a5"} />
            </mesh>
          ))}
        </group>
        <Label text="heart" position={[-1.5, 0.5, 0]} size={0.42} color="#f8fafc" />
        <Label text="coronary arteries" position={[-3.6, 3.4, 0]} size={0.32} color="#fca5a5" />
        <Label text="LAD" position={[-2.6, 2.2, 1.1]} size={0.28} color="#fca5a5" />
        <Label text="stroke volume ejected" position={[-1.5, 6.6, 0]} size={0.3} color="#fde68a" />
        <Label text="CO = HR × SV" position={[-1.5, -0.5, 0]} size={0.34} color="#fde68a" />

        {/* perfusion monitor: body silhouette with flow dots */}
        <group position={[4.5, 0, 0]}>
          <mesh position={[0, 2.6, 0]} castShadow>
            <sphereGeometry args={[0.5, 14, 14]} />
            <meshStandardMaterial color={shock ? "#94a3b8" : "#fcd9b8"} roughness={0.5} />
          </mesh>
          <mesh position={[0, 1.4, 0]} castShadow scale={[1, 1.6, 0.7]}>
            <sphereGeometry args={[0.55, 14, 14]} />
            <meshStandardMaterial color={shock ? "#94a3b8" : "#fcd9b8"} roughness={0.5} />
          </mesh>
          {/* perfusion sparkles */}
          {[-0.3, 0.1, 0.45].map((x, i) => (
            <mesh key={i} position={[x, 1.6 + (i % 2) * 0.5, 0.5]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshBasicMaterial color={shock ? "#475569" : "#f87171"} />
            </mesh>
          ))}
        </group>
        <Label text={shock ? "poor perfusion — cold, clammy" : "tissues well perfused"}
          position={[4.5, 4.0, 0]} size={0.34} color={shock ? "#fca5a5" : "#86efac"} />
        <Label text="shock: ↓CO → ↓tissue perfusion" position={[4.5, 0.4, 0]} size={0.3} color="#94a3b8" />

        <Animator heart={heart} ejecta={ejecta} coronaries={coronaries}
          elapsed={elapsed} co={co} shock={shock} speed={speed} />
      </SimCanvas>
    </div>
  );
}
