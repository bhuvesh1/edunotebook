// Adrenal, pituitary & calcium disorders — kidneys wearing adrenal caps
// (Cushing's cortisol storm vs Addison's failure), the pituitary pea at the
// brain base pulsing hormones down, and calcium crystals for hypo/hyper.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "gland", label: "Gland", kind: "select", min: 0, max: 0, step: 1, default: "adrenal", options: ["adrenal", "pituitary", "parathyroid"] },
  { key: "level", label: "Hormone level", kind: "slider", min: 0, max: 100, step: 5, default: 70, unit: "%" },
];

export const UNIQUE_META = {
  title: "Adrenal, Pituitary & Calcium",
  blurb: "Adrenal caps flood or fail, the pituitary pea pulses hormones down to the body, and calcium crystals pile up or vanish.",
};

function Animator({ pulses, adrenals, elapsed, level, gland }: {
  pulses: React.RefObject<THREE.Group>;
  adrenals: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  level: number;
  gland: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (pulses.current) {
      pulses.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * (0.3 + (level / 100) * 0.9) + i * 0.2) % 1);
        m.position.y = 5.6 - ph * 3.2;
        m.visible = gland !== "parathyroid" && (level > 15 || i < 2);
      });
    }
    if (adrenals.current) {
      adrenals.current.children.forEach((c, i) => {
        const s = gland === "adrenal" ? 1 + (level / 100) * 0.5 * Math.sin(t * 3 + i * 2) * 0.1 + (level / 100) * 0.45 : 1;
        c.scale.setScalar(s);
      });
    }
  });
  return null;
}

export function Topic10231Sim(props: SimProps) {
  const gland = String(props.gland ?? "adrenal");
  const level = Number(props.level ?? 70);
  const pulses = useRef<THREE.Group>(null!);
  const adrenals = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const adrenalState = level > 65 ? "Cushing's — too much cortisol" : level < 35 ? "Addison's — too little ⚠" : "balanced";
  const pitState = level > 65 ? "acromegaly / excess GH" : level < 35 ? "deficiency — growth failure" : "balanced";
  const caState = level > 65 ? "hypercalcemia — stones, bones, groans" : level < 35 ? "hypocalcemia — tingling, spasms ⚠" : "normal calcium";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Gland", gland], ["State", gland === "adrenal" ? adrenalState : gland === "pituitary" ? pitState : caState]]} />
      <SimCanvas cameraPosition={[0, 3.2, 13]} target={[0, 2.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* kidneys with adrenal caps */}
        {[-1, 1].map((s) => (
          <group key={s} position={[s * 2.6, 1.8, 0]}>
            <mesh scale={[0.8, 1.2, 0.7]} castShadow>
              <sphereGeometry args={[0.85, 22, 16]} />
              <meshStandardMaterial color="#b91c1c" roughness={0.55} />
            </mesh>
          </group>
        ))}
        <group ref={adrenals}>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 2.6, 3.15, 0]} scale={[0.9, 0.5, 0.7]}>
              <sphereGeometry args={[0.55, 18, 14]} />
              <meshStandardMaterial color={gland === "adrenal" ? (level > 65 ? "#f87171" : level < 35 ? "#93c5fd" : "#fbbf24") : "#fbbf24"} roughness={0.5} emissive={gland === "adrenal" && level > 65 ? "#7f1d1d" : "#000"} emissiveIntensity={0.45} />
            </mesh>
          ))}
        </group>
        <Label text="Adrenal glands (caps on kidneys)" position={[0, 4.4, 0]} size={0.5} color="#fbbf24" />
        {gland === "adrenal" && <Label text={adrenalState} position={[0, 5.2, 0]} size={0.5} color={level > 65 || level < 35 ? "#fca5a5" : "#86efac"} />}

        {/* brain + pituitary */}
        <mesh position={[0, 6.3, -1.2]} scale={[1.4, 1.1, 1.2]} castShadow>
          <sphereGeometry args={[1.1, 26, 20]} />
          <meshStandardMaterial color="#f472b6" roughness={0.55} />
        </mesh>
        <mesh position={[0, 5.35, -1.2]}>
          <sphereGeometry args={[0.28, 14, 12]} />
          <meshStandardMaterial color={gland === "pituitary" ? "#f472b6" : "#c084fc"} roughness={0.4} emissive={gland === "pituitary" ? "#9d174d" : "#000"} emissiveIntensity={0.6} />
        </mesh>
        <Label text="Pituitary — the master pea" position={[2.8, 6.6, -1.2]} size={0.48} color="#f9a8d4" />
        {gland === "pituitary" && <Label text={pitState} position={[0, 7.6, -1.2]} size={0.5} color={level > 65 || level < 35 ? "#fca5a5" : "#86efac"} />}

        {/* hormone pulses raining down */}
        <group ref={pulses}>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[(i % 3 - 1) * 1.2, 5.6, -1.2 + (i % 2) * 0.5]}>
              <sphereGeometry args={[0.12, 10, 10]} />
              <meshBasicMaterial color="#f9a8d4" />
            </mesh>
          ))}
        </group>

        {/* parathyroid calcium crystals */}
        {gland === "parathyroid" && (
          <group position={[0, 4.6, 1.6]}>
            {Array.from({ length: Math.round((level / 100) * 14) }).map((_, i) => (
              <mesh key={i} position={[((i * 0.67) % 2.4) - 1.2, ((i * 0.43) % 1.2) - 0.6, ((i * 0.29) % 0.8) - 0.4]} rotation={[i, i * 2, 0]}>
                <octahedronGeometry args={[0.14, 0]} />
                <meshStandardMaterial color="#fefce8" roughness={0.3} emissive="#a16207" emissiveIntensity={0.4} flatShading />
              </mesh>
            ))}
            <Label text={`Parathyroid → ${caState}`} position={[0, 1.6, 0]} size={0.5} color={level > 65 || level < 35 ? "#fca5a5" : "#86efac"} />
          </group>
        )}

        <Animator pulses={pulses} adrenals={adrenals} elapsed={elapsed} level={level} gland={gland} />
      </SimCanvas>
    </div>
  );
}
