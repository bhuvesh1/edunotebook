"use client";
// Periodontium: Gingiva, PDL, Cementum, Bone — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "explode", label: "Explode layers", kind: "slider", min: 0, max: 2, step: 0.1, default: 0.6, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Periodontium: Gingiva, PDL, Cementum, Bone",
  blurb: "Explode the tooth's support system into layers — gum, ligament, cementum and bone, each labeled.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const parts = [["gumL", -1], ["pdlL", -2], ["cemL", -3], ["boneL", -4]];
    parts.forEach(([nm, dir]: any) => {
      const m: any = g(nm);
      if (m) m.position.x = dir * p.explode * 0.9 + (m.userData.bx ?? (m.userData.bx = m.position.x));
    });
    group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
  });
  return null;
}

export function Topic10476Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const explode = Number(props.explode ?? 0.6);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, explode };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Gingiva", "Pink gum collar"],
          ["PDL", "Shock-absorber fibers"],
          ["Cementum", "Root coating"],
          ["Alveolar bone", "Socket wall"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[1.6, 1.2, 0]} scale={1.5} />
          <mesh name="gumL" position={[0.1, 1.9, 0]}>
            <boxGeometry args={[0.9, 1.1, 1.8]} />
            <meshStandardMaterial color="#e0808f" roughness={0.6} />
          </mesh>
          <group name="pdlL" position={[-0.15, 0.9, 0]}>
            {[-0.4, -0.15, 0.1, 0.35].map((y, i) => (
              <mesh key={i} position={[0.35, y, 0]} rotation={[0, 0, 0.6]}>
                <cylinderGeometry args={[0.035, 0.035, 0.8, 6]} />
                <meshStandardMaterial color="#eab308" roughness={0.6} />
              </mesh>
            ))}
          </group>
          <mesh name="cemL" position={[0.62, 0.35, 0]}>
            <cylinderGeometry args={[0.34, 0.28, 1.5, 12, 1, true]} />
            <meshStandardMaterial color="#fb923c" roughness={0.5} side={2} />
          </mesh>
          <mesh name="boneL" position={[-0.9, 0.6, 0]}>
            <boxGeometry args={[1, 2.6, 2]} />
            <meshStandardMaterial color="#cbb894" roughness={0.9} />
          </mesh>
          <Label text="Gingiva" position={[-1.4, 3.1, 0]} size={0.42} color="#e0808f" />
          <Label text="PDL fibers" position={[-1.5, 1.2, 0]} size={0.42} color="#eab308" />
          <Label text="Cementum" position={[1.6, -0.6, 0]} size={0.42} color="#fb923c" />
          <Label text="Alveolar bone" position={[-2.6, -0.5, 0]} size={0.42} color="#cbb894" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
