// Herpesviruses & arboviruses: herpes hides latent in the neuron's nucleus —
// stress wakes it and it travels down the axon; nearby, a mosquito bites to
// spread dengue.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stress", label: "Stress level", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Herpesviruses & arboviruses",
  blurb: "Herpes hides in the neuron — stress wakes it down the axon; a mosquito bites to spread dengue.",
};

const N_HERP = 8;

function Animator({ herp, nucleus, mozzie, elapsed, stress, setTick }: {
  herp: React.RefObject<(THREE.Mesh | null)[]>;
  nucleus: React.RefObject<THREE.Mesh>;
  mozzie: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  stress: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = stress / 100;
    const awake = k > 0.25;
    herp.current.forEach((h, i) => {
      if (!h) return;
      if (!awake) {
        // latent: clustered in the nucleus
        const a = (i / N_HERP) * Math.PI * 2;
        h.position.set(-3.4 + Math.cos(a) * 0.25, 2.5 + Math.sin(a) * 0.25, Math.sin(a * 2) * 0.2);
        ((h as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = 0.65;
      } else {
        // reactivated: travelling down the axon
        const f = (t * (0.2 + k * 0.5) + i / N_HERP) % 1;
        h.position.set(-3.4 + f * 4.6, 2.5 - f * 0.4 + Math.sin(f * 10 + i) * 0.12, 0);
        ((h as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = 1;
      }
      h.rotation.y = t * 3 + i;
    });
    if (nucleus.current) {
      (nucleus.current.material as THREE.MeshStandardMaterial).emissiveIntensity = awake ? 0.9 : 0.25;
    }
    if (mozzie.current) {
      // mosquito bobs down to bite the arm
      const bite = 0.5 + 0.5 * Math.sin(t * 0.7);
      mozzie.current.position.set(3.4 + Math.sin(t * 1.3) * 0.3, 3.6 - bite * 1.5, 0.6);
      mozzie.current.rotation.z = -0.4 - bite * 0.4;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(awake ? Math.round(k * 100) : 0); }
  });
  return null;
}

export function Topic10139Sim(props: SimProps) {
  const stress = Number(props.stress ?? 60);
  const showLabels = String(props.detail ?? "on") === "on";
  const herp = useRef<(THREE.Mesh | null)[]>([]);
  const nucleus = useRef<THREE.Mesh>(null!);
  const mozzie = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const state = tick === 0 ? "latent in neuron" : "reactivated — cold sore!";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Herpes state", state],
          ["Dengue vector", "mosquito biting"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* neuron cell body */}
        <mesh position={[-3.4, 2.5, 0]} castShadow>
          <sphereGeometry args={[0.9, 20, 14]} />
          <meshStandardMaterial color="#f59e0b" roughness={0.5} />
        </mesh>
        {/* nucleus */}
        <mesh ref={nucleus} position={[-3.4, 2.5, 0]}>
          <sphereGeometry args={[0.45, 16, 12]} />
          <meshStandardMaterial color="#7c3aed" emissive="#6d28d9" emissiveIntensity={0.4} />
        </mesh>
        {/* axon */}
        <mesh position={[-0.9, 2.3, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.18, 0.24, 4.4, 12]} />
          <meshStandardMaterial color="#b45309" roughness={0.55} />
        </mesh>
        {/* nerve ending / lip */}
        <mesh position={[1.5, 2.1, 0]} scale={[1, 0.7, 0.8]} castShadow>
          <sphereGeometry args={[0.5, 16, 12]} />
          <meshStandardMaterial color="#f4a7b9" roughness={0.6} />
        </mesh>
        {showLabels && <Label text="neuron — herpes hides here" position={[-3.4, 4, 0]} color="#fcd34d" />}
        {showLabels && <Label text="cold-sore site" position={[1.5, 3.1, 0]} size={0.4} color="#f9a8d4" />}

        {/* herpes virions */}
        {Array.from({ length: N_HERP }).map((_, i) => (
          <mesh key={i} ref={(m) => { herp.current[i] = m; }}>
            <icosahedronGeometry args={[0.14]} />
            <meshStandardMaterial color="#c084fc" emissive="#7e22ce" emissiveIntensity={0.9} transparent />
          </mesh>
        ))}

        {/* arm for the mosquito */}
        <mesh position={[3.6, 1.2, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <capsuleGeometry args={[0.42, 2.4, 8, 14]} />
          <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
        </mesh>
        {showLabels && <Label text="arm — mosquito bite" position={[3.6, 2.3, 0]} size={0.45} color="#fde68a" />}

        {/* mosquito */}
        <group ref={mozzie}>
          <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
            <capsuleGeometry args={[0.13, 0.65, 6, 10]} />
            <meshStandardMaterial color="#1f2937" roughness={0.5} />
          </mesh>
          {[-0.45, 0.45].map((s, i) => (
            <mesh key={i} position={[0, 0.16, s * 0.28]} rotation={[0.4 * s, 0, 0.5]}>
              <planeGeometry args={[0.85, 0.32]} />
              <meshStandardMaterial color="#e5e7eb" transparent opacity={0.5} side={THREE.DoubleSide} />
            </mesh>
          ))}
          {/* striped legs hint */}
          <mesh position={[0.42, -0.1, 0]} rotation={[0, 0, -Math.PI / 2]}>
            <cylinderGeometry args={[0.025, 0.01, 0.55, 6]} />
            <meshStandardMaterial color="#f8fafc" />
          </mesh>
        </group>
        {showLabels && <Label text="Aedes mosquito — dengue, chikungunya" position={[0.6, 4.6, 0]} size={0.4} color="#e5e7eb" />}

        <Animator herp={herp} nucleus={nucleus} mozzie={mozzie} elapsed={elapsed} stress={stress} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
