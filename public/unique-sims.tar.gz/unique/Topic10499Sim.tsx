"use client";
// Impacted Third Molars — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ang", label: "Angulation", kind: "select", min: 0, max: 0, step: 1, default: "Mesioangular", options: ["Mesioangular", "Horizontal", "Vertical", "Distoangular"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Impacted Third Molars",
  blurb: "A wisdom tooth stuck sideways — flap up, bone away, section it, and elevate it out.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const tilts: any = { Mesioangular: 0.5, Horizontal: 1.45, Vertical: 0, Distoangular: -0.5 };
    const wt: any = g("wisdom");
    if (wt) wt.rotation.z += ((tilts[p.ang] ?? 0.5) - wt.rotation.z) * 0.06;
    const T = 10;
    const ph = (t % T) / T;
    const flap: any = g("wflap");
    if (flap) flap.rotation.x = -(ph < 0.3 ? ph / 0.3 : ph < 0.75 ? 1 : 1 - (ph - 0.75) / 0.25) * 1.1;
    const chip: any = g("bonechip");
    if (chip) {
      chip.visible = ph > 0.2 && ph < 0.8;
      chip.position.y = 1.9 + (ph > 0.2 ? Math.min(1, (ph - 0.2) * 4) : 0) * 1.2;
    }
    if (wt) {
      const out = ph > 0.45 ? Math.min(1, (ph - 0.45) / 0.3) : 0;
      wt.position.y = 1.1 + out * 2.2;
    }
  });
  return null;
}

export function Topic10499Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const ang = String(props.ang ?? "Mesioangular");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, ang };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Angulation", ang],
          ["Difficulty", ang === "Horizontal" ? "Hardest" : ang === "Mesioangular" ? "Common" : "Moderate"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <mesh position={[-2.2, 1.1, 0]}>
            <boxGeometry args={[1.1, 1.5, 1]} />
            <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
          </mesh>
          <mesh position={[0.4, 0.5, -0.3]}>
            <boxGeometry args={[3.4, 1.6, 1.6]} />
            <meshStandardMaterial color="#cbb894" roughness={0.9} />
          </mesh>
          <group name="wisdom" position={[0.9, 1.1, 0]} rotation={[0, 0, 0.5]}>
            <Tooth scale={1.15} />
          </group>
          <group position={[0.9, 1.7, 0.9]}>
            <mesh name="wflap" position={[0, 0.45, 0]}>
              <boxGeometry args={[2.4, 0.9, 0.2]} />
              <meshStandardMaterial color="#e0808f" roughness={0.55} />
            </mesh>
          </group>
          <mesh name="bonechip" position={[1.7, 1.9, -0.3]} visible={false}>
            <boxGeometry args={[0.7, 0.5, 0.7]} />
            <meshStandardMaterial color="#d9c69c" roughness={0.9} />
          </mesh>
          <mesh position={[0.9, 1.35, 0.15]} rotation={[0, 0, 0.5]}>
            <boxGeometry args={[0.06, 1.8, 0.06]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.7} transparent opacity={0.8} />
          </mesh>
          <Label text="Impacted wisdom tooth" position={[0.9, 3.1, 0]} size={0.42} />
          <Label text="Section line" position={[-1.3, 1.5, 0.15]} size={0.4} color="#ef4444" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
