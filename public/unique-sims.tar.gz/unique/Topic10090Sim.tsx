"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "atype", label: "Anemia", kind: "select", min: 0, max: 0, step: 1, default: "iron deficiency", options: ["normal", "iron deficiency", "megaloblastic", "sickle cell"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Anemias: Reading Red Cells",
  blurb: "Compare red cell shapes: normal discs, pale microcytes, giant macrocytes, and sickle crescents.",
};

function Animator({ root, cells, elapsed, speed }: { root: RefObject<THREE.Group>; cells: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (cells.current) {
      cells.current.children.forEach((m, i) => {
        m.position.y = 1.9 + Math.sin(t * 1.8 + i * 1.3) * 0.3;
        m.rotation.y = t * 0.8 + i;
        m.rotation.x = Math.sin(t * 0.9 + i) * 0.4;
      });
    }
  });
  return null;
}

export function Topic10090Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const atype = String(props.atype ?? "iron deficiency");
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const cells = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Anemia", atype],
          ["RBC picture", atype === "normal" ? "normocytic normochromic" : atype === "iron deficiency" ? "microcytic hypochromic" : atype === "megaloblastic" ? "macrocytic + hypersegmented neutrophils" : "sickle cells + hemolysis"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <group ref={cells}>
            {Array.from({ length: 12 }).map((_, i) => {
              const x = -4.5 + (i % 4) * 3, z = Math.floor(i / 4) * 2.4 - 2.4;
              if (atype === "sickle cell") {
                return (
                  <mesh key={i} position={[x, 1.9, z]} rotation={[0.4, i, 0]}>
                    <torusGeometry args={[0.34, 0.16, 10, 20, Math.PI * 1.5]} />
                    <meshStandardMaterial color="#b91c1c" roughness={0.5} />
                  </mesh>
                );
              }
              const s = atype === "iron deficiency" ? 0.68 : atype === "megaloblastic" ? 1.35 : 1;
              const c = atype === "iron deficiency" ? "#fca5a5" : "#dc2626";
              return (
                <mesh key={i} position={[x, 1.9, z]} scale={atype === "megaloblastic" ? [s, s * 0.5, s * 0.85] : [s, s * 0.45, s]}>
                  <sphereGeometry args={[0.36, 16, 16]} /><meshStandardMaterial color={c} roughness={0.5} />
                </mesh>
              );
            })}
          </group>
          {atype === "megaloblastic" && (
            <group position={[0, 3.9, -2]}>
              {[0, 1, 2, 3].map((i) => (
                <mesh key={i} position={[(i - 1.5) * 0.5, 0, 0]}>
                  <sphereGeometry args={[0.24, 12, 12]} /><meshStandardMaterial color="#e2e8f0" roughness={0.5} />
                </mesh>
              ))}
              <Label text="hypersegmented neutrophil" position={[0, 0.7, 0]} size={0.4} color="#e2e8f0" />
            </group>
          )}
          <Label text={atype === "normal" ? "normal RBC \u2014 biconcave disc" : atype === "iron deficiency" ? "microcytic, pale \u2014 low iron" : atype === "megaloblastic" ? "macrocytic \u2014 B12/folate low" : "sickle crescents \u2014 hemolysis"} position={[0, 5, 0]} size={0.48} color="#f8fafc" />
        </group>
        <Animator root={root} cells={cells} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
