"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "bmr", label: "BMR", kind: "slider", min: 1000, max: 2500, step: 50, default: 1600, unit: " kcal" },
  { key: "activity", label: "Activity", kind: "select", min: 0, max: 0, step: 1, default: "active", options: ["sedentary", "active", "athlete"] },
];

export const UNIQUE_META = {
  title: "BMR & Balanced Diet",
  blurb: "A balanced plate split into carbs, protein and fat, with a metabolic flame that grows with BMR.",
};

function Animator({ root, flame, plate, elapsed, bmr }: { root: RefObject<THREE.Group>; flame: RefObject<THREE.Group>; plate: RefObject<THREE.Group>; elapsed: RefObject<number>; bmr: number }) {
  useFrame((_, delta) => {
    elapsed.current += 0.016;
    const t = elapsed.current;
    if (plate.current) plate.current.rotation.y = t * 0.3;
    if (flame.current) {
      const s = 0.55 + (bmr / 2500) * 0.9;
      flame.current.scale.set(s * (1 + 0.1 * Math.sin(t * 11)), s * (1 + 0.16 * Math.sin(t * 13 + 1)), s);
      flame.current.rotation.y = t * 2;
    }
  });
  return null;
}

export function Topic10080Sim(props: SimProps) {
  const speed = 1;
  const bmr = Number(props.bmr ?? 1600);
  const activity = String(props.activity ?? "active");
  const mult = activity === "sedentary" ? 1.2 : activity === "athlete" ? 1.9 : 1.55;
  const tdee = Math.round(bmr * mult);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const flame = useRef<THREE.Group>(null!);
  const plate = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["BMR", `${bmr} kcal`],
          ["TDEE", `${tdee} kcal`],
          ["Plate", "55% carbs \u00b7 20% protein \u00b7 25% fat"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 11]} target={[0, 1.7, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <group ref={plate} position={[-2.2, 1.5, 0]}>
            <mesh rotation={[-Math.PI / 2, 0, 0]} castShadow>
              <cylinderGeometry args={[2, 2, 0.18, 32]} /><meshStandardMaterial color="#e2e8f0" roughness={0.5} />
            </mesh>
            <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.1, 0]}>
              <cylinderGeometry args={[1.7, 1.7, 0.1, 32, 1, false, 0, Math.PI * 2 * 0.55]} />
              <meshStandardMaterial color="#facc15" roughness={0.5} />
            </mesh>
            <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.12, 0]}>
              <cylinderGeometry args={[1.7, 1.7, 0.1, 32, 1, false, Math.PI * 2 * 0.55, Math.PI * 2 * 0.2]} />
              <meshStandardMaterial color="#f87171" roughness={0.5} />
            </mesh>
            <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.14, 0]}>
              <cylinderGeometry args={[1.7, 1.7, 0.1, 32, 1, false, Math.PI * 2 * 0.75, Math.PI * 2 * 0.25]} />
              <meshStandardMaterial color="#fb923c" roughness={0.5} />
            </mesh>
          </group>
          <Label text="carbs 55%" position={[-2.2, 3.1, 1.2]} size={0.4} color="#facc15" />
          <Label text="protein 20%" position={[-3.8, 2.4, -1]} size={0.4} color="#f87171" />
          <Label text="fat 25%" position={[-0.6, 2.4, -1]} size={0.4} color="#fb923c" />
          <group ref={flame} position={[2.8, 0.4, 0]}>
            <mesh position={[0, 1, 0]} castShadow>
              <coneGeometry args={[0.7, 1.9, 16]} /><meshStandardMaterial color="#f97316" emissive="#ea580c" emissiveIntensity={1.2} transparent opacity={0.9} />
            </mesh>
            <mesh position={[0, 0.75, 0]}>
              <coneGeometry args={[0.38, 1.1, 14]} /><meshStandardMaterial color="#fde047" emissive="#facc15" emissiveIntensity={1.6} />
            </mesh>
          </group>
          <Label text={`BMR ${bmr} kcal`} position={[2.8, 3.4, 0]} size={0.45} color="#fb923c" />
          <Label text={`TDEE \u2248 ${tdee} kcal`} position={[2.8, 2.75, 0]} size={0.4} color="#94a3b8" />
          <Label text="PEM: energy \u00d7 protein deficit" position={[0, 4.6, 0]} size={0.4} color="#94a3b8" />
        </group>
        <Animator root={root} flame={flame} plate={plate} elapsed={elapsed} bmr={bmr} />
      </SimCanvas>
    </div>
  );
}
