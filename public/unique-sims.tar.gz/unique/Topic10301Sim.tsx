// Bone infections: osteomyelitis, tuberculosis of bone and spine.
// Bacteria invade the bone — a glowing infected zone with pus draining out
// (osteomyelitis), or TB silently collapsing two vertebrae (Pott's spine).

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "type", label: "Infection", kind: "select", min: 0, max: 0, step: 1, default: "osteomyelitis", options: ["osteomyelitis", "tb_spine"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Bone Infection: Osteomyelitis & TB Spine",
  blurb: "Germs inside bone — osteomyelitis glows with draining pus, while spinal TB crumbles vertebrae into a hunch.",
};

function Animator({
  group, germs, pus, collapsed, elapsed, speed, type,
}: {
  group: React.RefObject<THREE.Group>;
  germs: React.RefObject<THREE.Group>;
  pus: React.RefObject<THREE.Group>;
  collapsed: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  type: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = type === "osteomyelitis" ? Math.sin(t * 0.25) * 0.3 : Math.sin(t * 0.15) * 0.2;
    if (germs.current) {
      germs.current.visible = type === "osteomyelitis";
      germs.current.children.forEach((g, i) => {
        g.position.y = 1.9 + Math.sin(t * 3 + i * 2.2) * 0.25;
        g.position.x = Math.cos(t * 2 + i * 1.7) * 0.3;
      });
    }
    if (pus.current) {
      pus.current.visible = type === "osteomyelitis";
      pus.current.children.forEach((d, i) => {
        const ph = ((t * 0.7 + i / pus.current!.children.length) % 1);
        d.position.set(0.45 + Math.sin(i * 2.5) * 0.1, 1.9 - ph * 1.6, 0.45);
      });
    }
    if (collapsed.current) {
      collapsed.current.visible = type === "tb_spine";
      collapsed.current.children.forEach((v, i) => {
        // the two middle vertebrae crumble and tilt
        const crush = i === 1 || i === 2 ? 0.55 + 0.1 * Math.sin(t * 1.2 + i) : 1;
        (v as THREE.Mesh).scale.set(1, crush, 1);
        (v as THREE.Mesh).rotation.z = i === 1 ? 0.25 : i === 2 ? -0.2 : 0;
      });
    }
  });
  return null;
}

export function Topic10301Sim(props: SimProps) {
  const type = String(props.type ?? "osteomyelitis");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const germs = useRef<THREE.Group>(null!);
  const pus = useRef<THREE.Group>(null!);
  const collapsed = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = { osteomyelitis: "Osteomyelitis (long bone)", tb_spine: "TB spine (Pott's disease)" };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Infection", names[type] ?? type], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10.5]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {type === "osteomyelitis" && (
            <>
              {/* long bone with infected segment glowing */}
              <mesh position={[0, 3.1, 0]} castShadow>
                <cylinderGeometry args={[0.32, 0.32, 1.6, 16]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
              <mesh position={[0, 1.9, 0]} castShadow>
                <cylinderGeometry args={[0.42, 0.42, 1.1, 16]} />
                <meshStandardMaterial color="#f87171" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.8} />
              </mesh>
              <mesh position={[0, 0.85, 0]} castShadow>
                <cylinderGeometry args={[0.32, 0.32, 1.4, 16]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
              {/* dead bone fragment (sequestrum) */}
              <mesh position={[0, 1.9, 0.1]} rotation={[0, 0, 0.4]} castShadow>
                <boxGeometry args={[0.25, 0.5, 0.2]} />
                <meshStandardMaterial color="#57534e" roughness={0.8} />
              </mesh>
              {/* bacteria swarming the infection */}
              <group ref={germs} visible={false}>
                {Array.from({ length: 12 }).map((_, i) => (
                  <mesh key={i} position={[Math.sin(i * 2.1) * 0.5, 1.9, Math.cos(i * 1.6) * 0.5]} castShadow>
                    <sphereGeometry args={[0.1, 8, 6]} />
                    <meshStandardMaterial color="#4ade80" emissive="#166534" emissiveIntensity={1} />
                  </mesh>
                ))}
              </group>
              {/* draining sinus: pus trickling out */}
              <group ref={pus} visible={false}>
                {Array.from({ length: 8 }).map((_, i) => (
                  <mesh key={i}>
                    <sphereGeometry args={[0.09, 8, 6]} />
                    <meshBasicMaterial color="#d9f99d" />
                  </mesh>
                ))}
              </group>
              <Label text="🦠 Infected bone" position={[-1.9, 2.4, 0]} size={0.55} color="#fca5a5" />
              <Label text="Dead fragment" position={[1.7, 1.9, 0.1]} size={0.5} color="#a8a29e" />
              <Label text="Pus draining out" position={[1.7, 0.7, 0.45]} size={0.5} color="#d9f99d" />
            </>
          )}
          {type === "tb_spine" && (
            <>
              {/* 5 vertebrae, middle two crumbling from TB */}
              <group ref={collapsed} visible={false}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <mesh key={i} position={[0, 1.1 + i * 0.62, 0]} castShadow>
                    <cylinderGeometry args={[0.5, 0.5, 0.42, 18]} />
                    <meshStandardMaterial
                      color={i === 1 || i === 2 ? "#f87171" : "#e2e8f0"}
                      roughness={0.5}
                      emissive={i === 1 || i === 2 ? "#7f1d1d" : "#000000"}
                      emissiveIntensity={0.6}
                    />
                  </mesh>
                ))}
              </group>
              {/* cold abscess bulge */}
              <mesh position={[0.75, 1.9, 0]} scale={[0.7, 1.1, 0.7]} castShadow>
                <sphereGeometry args={[0.4, 16, 12]} />
                <meshStandardMaterial color="#fbbf24" roughness={0.5} transparent opacity={0.7} />
              </mesh>
              <Label text="🦠 TB eats the vertebrae" position={[-2.2, 2.8, 0]} size={0.55} color="#fca5a5" />
              <Label text="Cold abscess" position={[1.9, 2.4, 0]} size={0.5} color="#fde68a" />
              <Label text="⚠ Spine bends → hunchback" position={[0, 0.25, 0]} size={0.55} color="#fde68a" />
            </>
          )}
        </group>
        <Animator group={group} germs={germs} pus={pus} collapsed={collapsed} elapsed={elapsed} speed={speed} type={type} />
      </SimCanvas>
    </div>
  );
}
