"use client";
// Communicable diseases: surveillance and control principles.
// A radar sweep circles a district map, lighting up case dots —
// surveillance spots the outbreak, then control teams move in.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Radar speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "disease", label: "Disease", kind: "select", min: 0, max: 0, step: 1, default: "measles", options: ["measles", "cholera", "flu"] },
];

export const UNIQUE_META = {
  title: "Surveillance: Spotting Outbreaks Early",
  blurb: "The surveillance radar sweeps the district, case dots light up — and control teams rush to the hotspot.",
};

const DISEASE_COLOR: Record<string, string> = { measles: "#ef4444", cholera: "#38bdf8", flu: "#f59e0b" };

function Animator({ sweep, dots, team, elapsed, speed }: { sweep: React.RefObject<THREE.Mesh>; dots: React.RefObject<THREE.Group>; team: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (sweep.current) sweep.current.rotation.z = -elapsed.current * 1.4;
    if (dots.current) {
      const ang = (-elapsed.current * 1.4) % (Math.PI * 2);
      dots.current.children.forEach((d) => {
        const m = d as THREE.Mesh;
        const da = Math.atan2(m.position.y - 1.6, m.position.x);
        let diff = Math.abs(((ang - da) % (Math.PI * 2) + Math.PI * 3) % (Math.PI * 2) - Math.PI);
        const lit = diff < 0.9;
        ((m as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = lit ? 1.4 : 0.15;
        m.visible = true;
        m.scale.setScalar(lit ? 1.35 : 0.8);
      });
    }
    if (team.current) {
      const t = (elapsed.current * 0.25) % 1;
      team.current.position.x = -5 + t * 10;
      team.current.position.z = Math.sin(t * Math.PI * 3) * 1.6;
    }
  });
  return null;
}

export function Topic10171Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const disease = String(props.disease ?? "measles");
  const sweep = useRef<THREE.Mesh>(null!);
  const dots = useRef<THREE.Group>(null!);
  const team = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const dc = DISEASE_COLOR[disease] ?? "#ef4444";

  const caseDots = useMemo(
    () =>
      Array.from({ length: 22 }, (_, i) => {
        const a = (i * 2.399) % (Math.PI * 2);
        const r = 1 + ((i * 1.7) % 3.4);
        return (
          <mesh key={i} position={[Math.cos(a) * r, 1.6 + Math.sin(a) * r * 0.7, 0.12]}>
            <sphereGeometry args={[0.16, 10, 10]} />
            <meshStandardMaterial color={dc} emissive={dc} emissiveIntensity={0.15} />
          </mesh>
        );
      }),
    [dc]
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Watching for", disease], ["Hotspot", "north-east cluster"]]} />
      <SimCanvas cameraPosition={[0, 6, 11]} target={[0, 1, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* district map board */}
        <mesh position={[0, 1.6, 0]} rotation={[-0.25, 0, 0]} receiveShadow>
          <boxGeometry args={[11, 7.5, 0.25]} />
          <meshStandardMaterial color="#12351f" roughness={0.9} />
        </mesh>
        {/* map grid */}
        {[-4, -2, 0, 2, 4].map((x) => (
          <mesh key={`v${x}`} position={[x, 1.62, 0.16]} rotation={[-0.25, 0, 0]}>
            <boxGeometry args={[0.05, 7.3, 0.02]} />
            <meshStandardMaterial color="#1f5c33" roughness={0.9} />
          </mesh>
        ))}
        {[-2.4, -1.2, 0, 1.2, 2.4].map((y) => (
          <mesh key={`h${y}`} position={[0, 1.62 + y, 0.16]} rotation={[-0.25, 0, 0]}>
            <boxGeometry args={[10.8, 0.05, 0.02]} />
            <meshStandardMaterial color="#1f5c33" roughness={0.9} />
          </mesh>
        ))}
        <group ref={dots}>{caseDots}</group>
        {/* radar sweep */}
        <mesh ref={sweep} position={[0, 1.6, 0.3]} rotation={[-0.25, 0, 0]}>
          <circleGeometry args={[4.6, 24, 0, 0.7]} />
          <meshStandardMaterial color="#4ade80" transparent opacity={0.3} emissive="#22c55e" emissiveIntensity={0.5} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
        <mesh position={[0, 1.6, 0.32]} rotation={[-0.25, 0, 0]}>
          <ringGeometry args={[4.55, 4.7, 40]} />
          <meshStandardMaterial color="#4ade80" transparent opacity={0.7} side={THREE.DoubleSide} />
        </mesh>
        {/* control team van */}
        <group ref={team} position={[-5, 0, 3.6]}>
          <mesh position={[0, 0.7, 0]} castShadow>
            <boxGeometry args={[1.7, 0.9, 0.9]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.6} />
          </mesh>
          <mesh position={[0.9, 0.55, 0]}>
            <boxGeometry args={[0.5, 0.6, 0.9]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.5} />
          </mesh>
          {[[-0.55], [0.55]].map(([x]) => (
            <mesh key={x} position={[x, 0.28, 0.48]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[0.26, 0.26, 0.15, 12]} />
              <meshStandardMaterial color="#1e293b" roughness={0.9} />
            </mesh>
          ))}
          <mesh position={[0, 1.35, 0]}>
            <boxGeometry args={[0.5, 0.35, 0.5]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.6} />
          </mesh>
          <Label text="CONTROL TEAM" position={[0, 2, 0]} size={0.5} color="#f87171" />
        </group>
        <Label text="SURVEILLANCE RADAR" position={[0, 6.4, 0]} size={0.65} color="#4ade80" />
        <Animator sweep={sweep} dots={dots} team={team} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
