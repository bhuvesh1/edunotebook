"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "hormone", label: "Hormone", kind: "select", min: 0, max: 0, step: 1, default: "insulin", options: ["insulin", "glucagon"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Glycogen & Blood Sugar",
  blurb: "Insulin builds the glycogen tree and lowers blood glucose; glucagon breaks it down and glucose floods out.",
};

function Animator({ root, gly, gluc, meter, st, elapsed, speed, storing }: { root: RefObject<THREE.Group>; gly: RefObject<THREE.Group>; gluc: RefObject<THREE.Group>; meter: RefObject<THREE.Mesh>; st: RefObject<{ s: number; lvl: number }>; elapsed: RefObject<number>; speed: number; storing: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const k = Math.min(1, delta * 2);
    st.current.s += ((storing ? 1 : 0.38) - st.current.s) * k;
    st.current.lvl += ((storing ? 90 : 220) - st.current.lvl) * k;
    if (gly.current) gly.current.scale.setScalar(st.current.s);
    if (meter.current) {
      const h = (st.current.lvl / 300) * 3.2;
      meter.current.scale.y = Math.max(0.05, h);
      meter.current.position.y = 0.25 + h / 2;
      const m = meter.current.material as THREE.MeshStandardMaterial;
      m.color.set(st.current.lvl > 140 ? "#ef4444" : "#4ade80");
    }
    if (gluc.current) {
      gluc.current.children.forEach((m, i) => {
        const r = (t * (storing ? 0.25 : 0.8) + i / 12) % 1;
        if (storing) m.position.set(-2 + (i % 4) * 1.1, 0.3 + r * 1.2, 1.6 + Math.sin(i) * 0.5);
        else m.position.set(-2 + (i % 4) * 1.1, 0.4 + r * 3.4, 1.6 + Math.sin(i) * 0.5);
        m.scale.setScalar(storing ? 0.5 : 1);
      });
    }
  });
  return null;
}

export function Topic10065Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const hormone = String(props.hormone ?? "insulin");
  const storing = hormone === "insulin";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const gly = useRef<THREE.Group>(null!);
  const gluc = useRef<THREE.Group>(null!);
  const meter = useRef<THREE.Mesh>(null!);
  const st = useRef({ s: 1, lvl: 90 });
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Hormone", hormone],
          ["Blood glucose", storing ? "\u2248 90 mg/dL" : "\u2248 220 mg/dL"],
          ["Glycogen", storing ? "synthesis (build)" : "glycogenolysis (breakdown)"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <group ref={gly}>
            <mesh position={[-1.5, 1.4, 0]} castShadow>
              <cylinderGeometry args={[0.16, 0.22, 2.4, 10]} /><meshStandardMaterial color="#92400e" roughness={0.7} />
            </mesh>
            {Array.from({ length: 8 }).map((_, b) => {
              const a = (b / 8) * Math.PI * 2;
              const dx = Math.cos(a), dz = Math.sin(a);
              return (
                <group key={b}>
                  {[0.7, 1.2, 1.7].map((d, j) => (
                    <mesh key={j} position={[-1.5 + dx * d, 1.2 + j * 0.55 + d * 0.35, dz * d]} castShadow>
                      <sphereGeometry args={[0.28, 14, 14]} /><meshStandardMaterial color="#4ade80" roughness={0.4} />
                    </mesh>
                  ))}
                </group>
              );
            })}
          </group>
          <group ref={gluc}>
            {Array.from({ length: 12 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.15, 10, 10]} /><meshStandardMaterial color="#fefce8" emissive="#fde68a" emissiveIntensity={0.7} /></mesh>
            ))}
          </group>
          <mesh position={[4.2, 1.85, 0]}><boxGeometry args={[0.7, 3.5, 0.5]} /><meshStandardMaterial color="#1e293b" roughness={0.6} /></mesh>
          <mesh ref={meter} position={[4.2, 1, 0]}><boxGeometry args={[0.46, 1, 0.46]} /><meshStandardMaterial color="#4ade80" /></mesh>
          <Label text="glycogen" position={[-1.5, 4.1, 0]} color="#4ade80" />
          <Label text="glucose" position={[0.5, 0.6, 2.2]} size={0.42} color="#fefce8" />
          <Label text="blood glucose" position={[4.2, 4, 0]} size={0.42} />
          <Label text={storing ? "insulin: storing glucose" : "glucagon: releasing glucose"} position={[0, 4.6, 0]} size={0.5} color={storing ? "#60a5fa" : "#fb923c"} />
        </group>
        <Animator root={root} gly={gly} gluc={gluc} meter={meter} st={st} elapsed={elapsed} speed={speed} storing={storing} />
      </SimCanvas>
    </div>
  );
}
