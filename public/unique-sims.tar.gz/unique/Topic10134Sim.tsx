// Mycobacteria: waxy red acid-fast rods of TB drift toward the lung, where the
// immune system walls them into a granuloma nodule.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Mycobacteria: TB & leprosy",
  blurb: "Waxy red acid-fast rods drift into the lung, where immunity walls them into a granuloma.",
};

const N_RODS = 8;

function Animator({ rods, gran, elapsed, speed, setTick }: {
  rods: React.RefObject<(THREE.Group | null)[]>;
  gran: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    rods.current.forEach((g, i) => {
      if (!g) return;
      // rods drift toward the lung, get captured into the granuloma
      const f = (t * 0.14 + i / N_RODS) % 1;
      const sx = -5.5 + i * 0.4;
      const captured = f > 0.62;
      const x = captured ? 2.2 + Math.cos(i * 2.7) * 0.55 : sx + (2.2 - sx) * (f / 0.62);
      const y = captured ? 1.7 + Math.sin(i * 3.1) * 0.5 : 2.6 + Math.sin(t * 1.2 + i * 2) * 0.3 - f * 0.9;
      g.position.set(x, y, Math.sin(i * 1.9) * 0.5);
      g.rotation.z = t * 0.4 + i;
      g.rotation.y = t * 0.3 + i * 2;
    });
    if (gran.current) {
      // granuloma wall slowly thickens
      const w = 1 + Math.min(0.35, t * 0.02);
      gran.current.scale.setScalar(w);
      gran.current.rotation.y = t * 0.2;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(t * 10)); }
  });
  return null;
}

export function Topic10134Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const rods = useRef<(THREE.Group | null)[]>([]);
  const gran = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stain", "acid-fast — red rods"],
          ["Waxy coat", "mycolic acid — drug-resistant"],
          ["Lung defense", "granuloma wall"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* lung */}
        <mesh position={[2.2, 1.9, -0.8]} scale={[1.1, 1.5, 0.8]} castShadow>
          <sphereGeometry args={[1.1, 20, 14]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.65} transparent opacity={0.8} />
        </mesh>
        {showLabels && <Label text="lung" position={[2.2, 4.3, -0.8]} color="#f9a8d4" />}

        {/* granuloma: fibrous wall around captured bacilli */}
        <group ref={gran} position={[2.2, 1.7, 0.4]}>
          <mesh>
            <sphereGeometry args={[1.05, 20, 14]} />
            <meshStandardMaterial color="#d6a05c" roughness={0.8} transparent opacity={0.4} side={THREE.DoubleSide} />
          </mesh>
          <mesh rotation={[0.6, 0, 0.3]}>
            <torusGeometry args={[1.05, 0.1, 8, 24]} />
            <meshStandardMaterial color="#b97f3c" roughness={0.8} />
          </mesh>
          <mesh rotation={[1.2, 0.5, 0]}>
            <torusGeometry args={[1.05, 0.08, 8, 24]} />
            <meshStandardMaterial color="#b97f3c" roughness={0.8} />
          </mesh>
        </group>
        {showLabels && <Label text="granuloma — walled off" position={[2.2, 3.3, 0.4]} size={0.45} color="#fde68a" />}

        {/* acid-fast rods with waxy coat */}
        {Array.from({ length: N_RODS }).map((_, i) => (
          <group key={i} ref={(g) => { rods.current[i] = g; }}>
            <mesh castShadow>
              <capsuleGeometry args={[0.13, 0.75, 6, 12]} />
              <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={0.8} />
            </mesh>
            <mesh>
              <capsuleGeometry args={[0.2, 0.75, 6, 12]} />
              <meshStandardMaterial color="#fca5a5" transparent opacity={0.35} roughness={0.2} />
            </mesh>
          </group>
        ))}
        {showLabels && <Label text="M. tuberculosis — acid-fast rods" position={[-3.4, 3.6, 0]} size={0.45} color="#fca5a5" />}
        {showLabels && <Label text="waxy coat" position={[-3.4, -0.1, 0]} size={0.4} color="#fecaca" />}

        {/* leprosy note */}
        {showLabels && <Label text="M. leprae → skin & nerves" position={[-3.4, 4.5, 0]} size={0.4} color="#fda4af" />}

        <Animator rods={rods} gran={gran} elapsed={elapsed} speed={speed} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
