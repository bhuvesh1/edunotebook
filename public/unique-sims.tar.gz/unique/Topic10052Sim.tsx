// Neurophysiology: sensory receptors, ascending tracts, pain — a pinprick sends
// a red pain volley up the spinothalamic tract of the spinal cord to the brain,
// while touch travels the dorsal columns.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stimulus", label: "Stimulus intensity", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "modality", label: "Modality", kind: "select", min: 0, max: 0, step: 1, default: "pain", options: ["pain", "touch"] },
];

export const UNIQUE_META = {
  title: "Neurophysiology: Sensory Pathways",
  blurb: "A pinprick volley climbs the spinothalamic tract to the brain — switch to touch for the dorsal columns.",
};

function Animator({
  volley, receptor, elapsed, stimulus, pain, speed,
}: {
  volley: React.RefObject<THREE.Group>;
  receptor: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  stimulus: number;
  pain: boolean;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (volley.current) {
      volley.current.children.forEach((m, i) => {
        const ph = ((t * 0.35 * stimulus + i / 8) % 1 + 1) % 1;
        // skin (-7) -> cord entry (0) -> up tract -> brain (6)
        if (ph < 0.35) {
          const f = ph / 0.35;
          m.position.set(-7 + f * 7, 1.0 + Math.sin(f * Math.PI) * 0.6, 0);
        } else {
          const f = (ph - 0.35) / 0.65;
          m.position.set(0.4 + (pain ? 0.35 : -0.35), 1.6 + f * 3.4, 0);
        }
        m.visible = stimulus > 0.02;
        const s = 0.7 + stimulus * 0.4;
        m.scale.setScalar(s);
      });
    }
    if (receptor.current) {
      const s = 1 + 0.2 * Math.sin(t * 8) * Math.min(1, stimulus);
      receptor.current.scale.setScalar(s);
    }
  });
  return null;
}

export function Topic10052Sim(props: SimProps) {
  const stimulus = Number(props.stimulus ?? 1);
  const modality = String(props.modality ?? "pain");
  const pain = modality === "pain";
  const speed = 1;
  const volley = useRef<THREE.Group>(null!);
  const receptor = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const volleyColor = pain ? "#ef4444" : "#38bdf8";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Modality", pain ? "pain → spinothalamic tract" : "fine touch → dorsal columns"],
          ["Receptor", pain ? "free nerve ending" : "Meissner/Pacinian corpuscle"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* skin patch with receptor */}
        <group position={[-7, 0, 0]}>
          <mesh position={[0, 0.9, 0]} castShadow>
            <boxGeometry args={[2.6, 0.5, 2.0]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.45, 0]} castShadow>
            <boxGeometry args={[2.6, 0.5, 2.0]} />
            <meshStandardMaterial color="#f0abfc" roughness={0.6} />
          </mesh>
          {/* receptor ending */}
          <mesh ref={receptor} position={[0, 1.35, 0]} castShadow>
            {pain ? (
              <coneGeometry args={[0.22, 0.6, 10]} />
            ) : (
              <sphereGeometry args={[0.28, 12, 12]} />
            )}
            <meshStandardMaterial color={pain ? "#ef4444" : "#38bdf8"} roughness={0.45} />
          </mesh>
          {/* pin for pain */}
          {pain && (
            <mesh position={[0.6, 2.2, 0]} rotation={[0, 0, -0.9]} castShadow>
              <coneGeometry args={[0.12, 1.4, 8]} />
              <meshStandardMaterial color="#e2e8f0" metalness={0.7} roughness={0.3} />
            </mesh>
          )}
        </group>
        <Label text={pain ? "pinprick — free nerve ending" : "touch — corpuscle receptor"} position={[-7, 2.6, 0]} size={0.32} color="#f8fafc" />

        {/* peripheral nerve to cord */}
        <mesh position={[-3.5, 1.2, 0]} rotation={[0, 0, 0.18]} castShadow>
          <cylinderGeometry args={[0.14, 0.14, 7.2, 10]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.45} />
        </mesh>
        <Label text="1st-order neuron" position={[-3.5, 0.5, 0]} size={0.28} color="#fde68a" />

        {/* spinal cord cross-section with tracts */}
        <group position={[0.4, 0, 0]}>
          <mesh position={[0, 3.3, 0]} castShadow scale={[1, 1.25, 1]}>
            <sphereGeometry args={[1.0, 20, 20]} />
            <meshStandardMaterial color="#e7e5e4" roughness={0.5} />
          </mesh>
          {/* grey matter butterfly */}
          <mesh position={[0, 3.3, 0.55]}>
            <sphereGeometry args={[0.42, 12, 12]} />
            <meshStandardMaterial color="#94a3b8" roughness={0.5} />
          </mesh>
          {/* spinothalamic tract (anterolateral) */}
          <mesh position={[0.62, 3.0, 0.75]}>
            <sphereGeometry args={[0.2, 10, 10]} />
            <meshStandardMaterial color="#ef4444" emissive="#7f1d1d" emissiveIntensity={pain ? 0.8 : 0.15} />
          </mesh>
          {/* dorsal columns (posterior) */}
          <mesh position={[-0.28, 3.95, 0.75]}>
            <sphereGeometry args={[0.2, 10, 10]} />
            <meshStandardMaterial color="#38bdf8" emissive="#0c4a6e" emissiveIntensity={pain ? 0.15 : 0.8} />
          </mesh>
          {/* ascending tract column */}
          <mesh position={[pain ? 0.75 : -0.15, 4.9, 0]} castShadow>
            <cylinderGeometry args={[0.22, 0.22, 2.6, 10]} />
            <meshStandardMaterial color={pain ? "#ef4444" : "#38bdf8"} roughness={0.45} />
          </mesh>
        </group>
        <Label text="spinal cord" position={[0.4, 6.6, 0]} size={0.38} color="#f8fafc" />
        <Label text="spinothalamic (pain)" position={[2.6, 3.3, 0]} size={0.3} color="#fca5a5" />
        <Label text="dorsal columns (touch)" position={[-2.2, 4.3, 0]} size={0.3} color="#7dd3fc" />

        {/* brain receiving */}
        <group position={[4.6, 6.4, 0]}>
          <mesh castShadow scale={[1.2, 0.85, 1]}>
            <sphereGeometry args={[1.1, 20, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
          </mesh>
          {/* somatosensory cortex glow */}
          <mesh position={[-0.4, 0.55, 0.6]}>
            <sphereGeometry args={[0.35, 12, 12]} />
            <meshBasicMaterial color={volleyColor} transparent opacity={0.75} />
          </mesh>
        </group>
        <Label text="somatosensory cortex" position={[4.6, 7.9, 0]} size={0.32} color="#f8fafc" />

        {/* sensory volley */}
        <group ref={volley}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[-7, 1.0, 0]}>
              <sphereGeometry args={[0.14, 10, 10]} />
              <meshBasicMaterial color={volleyColor} />
            </mesh>
          ))}
        </group>

        <Animator volley={volley} receptor={receptor} elapsed={elapsed}
          stimulus={stimulus} pain={pain} speed={speed} />
      </SimCanvas>
    </div>
  );
}
