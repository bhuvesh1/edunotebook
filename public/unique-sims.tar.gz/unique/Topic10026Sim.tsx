// Embryology: GI, liver, respiratory development — the foregut tube sprouts a
// branching lung bud, a liver bud and a pancreatic bud; buds grow and branch.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "growth", label: "Bud growth", kind: "slider", min: 0.2, max: 1.5, step: 0.05, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Embryology: Gut Tube Buds",
  blurb: "From the foregut tube sprout the lung bud (branching), the liver bud and the pancreatic bud.",
};

// recursive branching lung bud
function LungBranch({ depth, length, radius }: { depth: number; length: number; radius: number }) {
  const kids = useMemo(() => (depth <= 0 ? [] : [-0.5, 0.5]), [depth]);
  return (
    <group>
      <mesh position={[0, length / 2, 0]} castShadow>
        <cylinderGeometry args={[radius * 0.75, radius, length, 10]} />
        <meshStandardMaterial color="#7dd3fc" roughness={0.45} />
      </mesh>
      {kids.map((a, i) => (
        <group key={i} position={[0, length, 0]} rotation={[0, 0, a]}>
          <LungBranch depth={depth - 1} length={length * 0.72} radius={radius * 0.72} />
        </group>
      ))}
      {depth === 0 && (
        <mesh position={[0, length + 0.12, 0]}>
          <sphereGeometry args={[radius * 1.5, 10, 10]} />
          <meshStandardMaterial color="#bae6fd" roughness={0.4} />
        </mesh>
      )}
    </group>
  );
}

function Animator({
  buds, elapsed, growth, speed,
}: {
  buds: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  growth: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (buds.current) {
      const s = growth * (1 + 0.04 * Math.sin(t * 2.5));
      buds.current.scale.setScalar(s);
    }
  });
  return null;
}

export function Topic10026Sim(props: SimProps) {
  const growth = Number(props.growth ?? 1);
  const speed = Number(props.speed ?? 1);
  const buds = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Foregut", "week 4: budding"],
          ["Buds", "lung • liver • pancreas"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 14]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* foregut tube */}
        <mesh position={[-4.5, 2.2, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.5, 0.5, 11, 18]} />
          <meshStandardMaterial color="#fda4af" roughness={0.5} />
        </mesh>
        <Label text="foregut tube" position={[-8.6, 3.4, 0]} size={0.36} color="#f8fafc" />

        <group ref={buds} position={[0, 0, 0]}>
          {/* lung bud: branching tree off the ventral foregut */}
          <group position={[-2.2, 2.5, 0]} rotation={[0, 0, Math.PI]}>
            <LungBranch depth={3} length={1.1} radius={0.22} />
          </group>
          <Label text="lung bud (branching)" position={[-2.2, 5.6, 0]} size={0.34} color="#7dd3fc" />

          {/* liver bud: green-brown mass with gallbladder hint */}
          <group position={[1.2, 1.4, 0.3]}>
            <mesh castShadow scale={[1.4, 1, 1]}>
              <sphereGeometry args={[0.85, 18, 18]} />
              <meshStandardMaterial color="#65a30d" roughness={0.5} />
            </mesh>
            <mesh position={[0.9, -0.5, 0.4]} castShadow scale={[0.6, 1.1, 0.6]}>
              <sphereGeometry args={[0.3, 12, 12]} />
              <meshStandardMaterial color="#4d7c0f" roughness={0.5} />
            </mesh>
          </group>
          <Label text="liver bud" position={[1.2, 2.9, 0.3]} size={0.34} color="#bef264" />
          <Label text="gallbladder bud" position={[2.9, 0.6, 0.4]} size={0.28} color="#a3e635" />

          {/* pancreatic bud */}
          <group position={[3.4, 2.0, -0.3]} rotation={[0, 0, -0.5]}>
            <mesh castShadow>
              <capsuleGeometry args={[0.32, 1.4, 6, 12]} />
              <meshStandardMaterial color="#fbbf24" roughness={0.5} />
            </mesh>
          </group>
          <Label text="pancreatic bud" position={[4.6, 2.9, -0.3]} size={0.34} color="#fde68a" />

          {/* stomach swelling */}
          <mesh position={[-4.9, 2.2, 0]} castShadow scale={[1, 1.35, 1]}>
            <sphereGeometry args={[0.75, 16, 16]} />
            <meshStandardMaterial color="#fb7185" roughness={0.5} />
          </mesh>
          <Label text="stomach primordium" position={[-6.3, 3.9, 0]} size={0.3} color="#fda4af" />
        </group>

        <Animator buds={buds} elapsed={elapsed} growth={growth} speed={speed} />
      </SimCanvas>
    </div>
  );
}
