"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "technique", label: "Technique", kind: "select", min: 0, max: 0, step: 1, default: "ianb", options: ["ianb", "infiltration", "intraligamentary"] },
  { key: "complication", label: "Complication", kind: "select", min: 0, max: 0, step: 1, default: "none", options: ["none", "hematoma", "trismus"] },
];

export const UNIQUE_META = {
  title: "Local anesthesia techniques and complications management",
  blurb: "Needle approaches a jaw nerve for three injection techniques — toggle a complication to see hematoma or trismus appear.",
};

const TECH: Record<string, { name: string; needle: [number, number, number]; rot: [number, number, number]; note: string }> = {
  ianb: { name: "Inferior alveolar nerve block", needle: [-2.2, 1.6, 1.2], rot: [0, 0, -0.9], note: "Needle to the mandibular foramen — numbs half the jaw" },
  infiltration: { name: "Infiltration", needle: [-0.7, 2.2, 1.8], rot: [0.3, 0, -0.25], note: "Small deposit near the root tip — upper teeth" },
  intraligamentary: { name: "Intraligamentary (PDL)", needle: [-0.15, 1.5, 1.9], rot: [0.1, 0, -0.1], note: "Into the gum crevice — single tooth" },
};

const COMP: Record<string, { name: string; note: string }> = {
  none: { name: "No complication", note: "Aspiration negative — safe to inject" },
  hematoma: { name: "Hematoma", note: "Vessel nicked — apply pressure, cold pack" },
  trismus: { name: "Trismus", note: "Muscle spasm — jaw locks, heat + physio" },
};

function Scene({ technique, complication }: { technique: string; complication: string }) {
  const needle = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const tc = TECH[technique] ?? TECH.ianb;
  const cp = COMP[complication] ?? COMP.none;

  useFrame((_, delta) => {
    t.current += delta;
    if (needle.current) {
      needle.current.position.y = tc.needle[1] + Math.sin(t.current * 1.2) * 0.12;
    }
  });

  return (
    <group>
      {/* mandible with foramen */}
      <mesh position={[0, -0.6, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[2.4, 0.75, 14, 32, Math.PI]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>
      {/* mandibular foramen target */}
      <mesh position={[-2.1, 0.1, 1.0]}>
        <torusGeometry args={[0.22, 0.07, 8, 16]} />
        <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.7} />
      </mesh>
      <Label text="Nerve entry (foramen)" position={[-2.1, 0.85, 1.0]} size={0.4} color="#fbbf24" />
      {/* IAN nerve */}
      <mesh position={[-1.1, -0.4, 0.9]} rotation={[0, 0.25, Math.PI / 2.15]}>
        <cylinderGeometry args={[0.08, 0.08, 3.6, 10]} />
        <meshStandardMaterial color="#facc15" roughness={0.4} />
      </mesh>
      {/* tooth */}
      <group position={[-0.6, 0.7, 1.5]}>
        <mesh position={[0, 0.3, 0]}>
          <cylinderGeometry args={[0.38, 0.5, 0.8, 12]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.25} />
        </mesh>
      </group>

      {/* needle */}
      <group ref={needle} position={tc.needle} rotation={tc.rot}>
        <mesh position={[0, 0.9, 0]}>
          <cylinderGeometry args={[0.26, 0.26, 1.6, 12]} />
          <meshStandardMaterial color="#e0f2fe" transparent opacity={0.7} roughness={0.2} />
        </mesh>
        <mesh position={[0, -0.5, 0]}>
          <cylinderGeometry args={[0.028, 0.01, 1.3, 8]} />
          <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
        </mesh>
        <mesh position={[0, -1.15, 0]}>
          <sphereGeometry args={[0.09, 10, 10]} />
          <meshStandardMaterial color="#38bdf8" emissive="#38bdf8" emissiveIntensity={1.2} />
        </mesh>
      </group>
      <Label text="Aspirate first!" position={[tc.needle[0], tc.needle[1] + 2.1, tc.needle[2]]} size={0.42} color="#f87171" />

      {/* complications */}
      {complication === "hematoma" && (
        <group position={[-1.9, 0.9, 1.2]}>
          <mesh scale={[1.2, 0.9, 0.9]}>
            <sphereGeometry args={[0.55, 16, 16]} />
            <meshStandardMaterial color="#6d28d9" roughness={0.5} />
          </mesh>
          <Label text="Hematoma — swelling" position={[0, 1.1, 0]} size={0.45} color="#c4b5fd" />
        </group>
      )}
      {complication === "trismus" && (
        <group position={[1.8, 0.4, 1.1]}>
          <mesh rotation={[0, 0, 0.4]}>
            <boxGeometry args={[0.5, 1.4, 0.6]} />
            <meshStandardMaterial color="#ef4444" roughness={0.6} />
          </mesh>
          <Label text="Muscle spasm — jaw locked" position={[0, 1.3, 0]} size={0.45} color="#fca5a5" />
        </group>
      )}

      <Label text={tc.name} position={[0, 3.8, 0]} size={0.6} color="#7dd3fc" />
      <Label text={tc.note} position={[0, -2.7, 0]} size={0.42} color="#e2e8f0" />
      <Label text={`${cp.name}: ${cp.note}`} position={[0, -3.4, 0]} size={0.42} color={complication === "none" ? "#86efac" : "#fbbf24"} />
    </group>
  );
}

export function Topic10418Sim(props: SimProps) {
  const technique = String(props.technique ?? "ianb");
  const complication = String(props.complication ?? "none");
  const tc = TECH[technique] ?? TECH.ianb;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Technique", tc.name], ["Complication", (COMP[complication] ?? COMP.none).name], ["Step 1", "Aspirate"]]} />
      <SimCanvas cameraPosition={[0, 2, 10]} target={[0, 0.3, 0]}>
        <Scene technique={technique} complication={complication} />
      </SimCanvas>
    </div>
  );
}
