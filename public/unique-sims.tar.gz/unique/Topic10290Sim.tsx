// Gynecology: contraception — methods, emergency contraception.
// How each method stops pregnancy: the daily pill, the T-shaped IUD sitting
// in the uterus, and the tiny implant rod under the skin of the arm.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "method", label: "Method", kind: "select", min: 0, max: 0, step: 1, default: "iud", options: ["pill", "iud", "implant", "emergency"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Contraception: How Each Method Works",
  blurb: "Pill, IUD, or implant — see exactly where each contraceptive sits and how it blocks pregnancy.",
};

function Animator({
  group, pill, iud, implant, sperm, elapsed, speed, method,
}: {
  group: React.RefObject<THREE.Group>;
  pill: React.RefObject<THREE.Mesh>;
  iud: React.RefObject<THREE.Group>;
  implant: React.RefObject<THREE.Mesh>;
  sperm: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  method: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
    // daily pill pops out of the pack
    if (pill.current) {
      pill.current.visible = method === "pill";
      const cyc = (t % 4) / 4;
      pill.current.position.y = 3.2 - Math.min(1, cyc * 3) * 1.1;
      pill.current.rotation.x = t * 2;
    }
    if (iud.current) {
      iud.current.visible = method === "iud" || method === "emergency";
      iud.current.rotation.z = Math.sin(t * 1.2) * 0.06;
    }
    if (implant.current) {
      implant.current.visible = method === "implant";
      (implant.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.4 + 0.4 * Math.sin(t * 3);
    }
    // sperm try to swim up but are blocked at the method's barrier
    if (sperm.current) {
      sperm.current.visible = method !== "pill";
      const barrierY = method === "iud" || method === "emergency" ? 1.9 : 1.2;
      sperm.current.children.forEach((s, i) => {
        const ph = ((t * 0.35 + i / sperm.current!.children.length) % 1);
        const y = 0.4 + ph * (barrierY - 0.2);
        const blocked = y >= barrierY - 0.15;
        s.position.set(Math.sin(i * 2.4 + t * 3) * (blocked ? 0.35 : 0.15), y, 0.2);
        (s as THREE.Mesh).rotation.z = t * 6 + i;
      });
    }
  });
  return null;
}

export function Topic10290Sim(props: SimProps) {
  const method = String(props.method ?? "iud");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const pill = useRef<THREE.Mesh>(null!);
  const iud = useRef<THREE.Group>(null!);
  const implant = useRef<THREE.Mesh>(null!);
  const sperm = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    pill: "Daily pill", iud: "Copper IUD (T)", implant: "Arm implant", emergency: "Emergency IUD",
  };
  const how: Record<string, string> = {
    pill: "Hormones stop the egg",
    iud: "T sits in uterus — blocks sperm",
    implant: "Rod in arm — 3 yrs, no daily pill",
    emergency: "IUD within 5 days — most effective",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Method", names[method] ?? method], ["How", how[method] ?? ""], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10.5]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* uterus */}
          <mesh position={[0, 2.0, 0]} scale={[1.0, 1.15, 0.85]} castShadow>
            <sphereGeometry args={[0.95, 28, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.55} />
          </mesh>
          {/* vagina canal where sperm enter */}
          <mesh position={[0, 0.7, 0]} castShadow>
            <cylinderGeometry args={[0.3, 0.36, 1.4, 14]} />
            <meshStandardMaterial color="#f0abfc" roughness={0.5} transparent opacity={0.7} />
          </mesh>
          {/* sperm swimmers */}
          <group ref={sperm} visible={false}>
            {Array.from({ length: 12 }).map((_, i) => (
              <group key={i}>
                <mesh castShadow>
                  <sphereGeometry args={[0.09, 8, 6]} />
                  <meshBasicMaterial color="#e0f2fe" />
                </mesh>
                <mesh position={[0, -0.18, 0]} castShadow>
                  <boxGeometry args={[0.03, 0.3, 0.03]} />
                  <meshBasicMaterial color="#bae6fd" />
                </mesh>
              </group>
            ))}
          </group>
          {/* IUD: copper T inside the uterus */}
          <group ref={iud} position={[0, 2.0, 0.1]} visible={false}>
            <mesh castShadow>
              <boxGeometry args={[1.1, 0.12, 0.12]} />
              <meshStandardMaterial color="#f59e0b" roughness={0.35} metalness={0.6} />
            </mesh>
            <mesh position={[0, -0.45, 0]} castShadow>
              <boxGeometry args={[0.12, 0.9, 0.12]} />
              <meshStandardMaterial color="#f59e0b" roughness={0.35} metalness={0.6} />
            </mesh>
            <mesh position={[0, -0.95, 0]} castShadow>
              <cylinderGeometry args={[0.03, 0.03, 0.5, 8]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.4} />
            </mesh>
          </group>
          {/* pill pack */}
          {method === "pill" && (
            <group position={[-2.6, 2.6, 0]}>
              <mesh castShadow>
                <boxGeometry args={[1.6, 2.2, 0.15]} />
                <meshStandardMaterial color="#f472b6" roughness={0.5} />
              </mesh>
              {Array.from({ length: 12 }).map((_, i) => (
                <mesh key={i} position={[-0.45 + (i % 3) * 0.45, 0.75 - Math.floor(i / 3) * 0.45, 0.1]}>
                  <cylinderGeometry args={[0.14, 0.14, 0.06, 14]} />
                  <meshStandardMaterial color="#fef3c7" roughness={0.4} />
                </mesh>
              ))}
              <mesh ref={pill} position={[0.45, 3.2, 0.3]} visible={false} castShadow>
                <cylinderGeometry args={[0.14, 0.14, 0.06, 14]} />
                <meshStandardMaterial color="#fbbf24" roughness={0.4} emissive="#b45309" emissiveIntensity={0.5} />
              </mesh>
            </group>
          )}
          {/* arm with implant rod */}
          {method === "implant" && (
            <group position={[2.7, 2.4, 0]}>
              <mesh rotation={[0, 0, 0.25]} castShadow>
                <capsuleGeometry args={[0.45, 2.4, 8, 16]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} transparent opacity={0.75} />
              </mesh>
              <mesh ref={implant} position={[0.1, 0.5, 0.35]} rotation={[0, 0, 0.25]} visible={false} castShadow>
                <capsuleGeometry args={[0.07, 0.7, 6, 10]} />
                <meshStandardMaterial color="#38bdf8" roughness={0.4} emissive="#0284c7" emissiveIntensity={0.6} />
              </mesh>
            </group>
          )}
          <Label text="Uterus" position={[-1.9, 2.7, 0]} size={0.55} color="#f9a8d4" />
          {method === "iud" && <Label text="Copper T blocks sperm ⛔" position={[0, 0.9, 0.3]} size={0.55} color="#fde68a" />}
          {method === "pill" && <Label text="One pill every day 💊" position={[-2.6, 4.0, 0]} size={0.55} color="#fbcfe8" />}
          {method === "implant" && <Label text="Tiny rod under skin" position={[2.7, 4.0, 0]} size={0.55} color="#7dd3fc" />}
          {method === "emergency" && <Label text="🚨 Works up to 5 days after" position={[0, 0.9, 0.3]} size={0.55} color="#fca5a5" />}
        </group>
        <Animator group={group} pill={pill} iud={iud} implant={implant} sperm={sperm} elapsed={elapsed} speed={speed} method={method} />
      </SimCanvas>
    </div>
  );
}
