// Nephrology (pediatrics): nephrotic syndrome, UTI in children.
// A kidney cut open reveals the nephron; zoom into the glomerulus — a tuft of
// capillaries inside Bowman's capsule. In nephrotic syndrome, protein leaks out
// into the urine.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "nephrotic", options: ["healthy", "nephrotic", "uti"] },
  { key: "filtration", label: "Filtration", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Kidney Filter: Nephrotic Syndrome",
  blurb: "Dive into the kidney's filter — in nephrotic syndrome the filter leaks precious protein into the urine.",
};

const N_PROTEIN = 14;

function Animator({
  group, protein, tuft, elapsed, filtration, condition,
}: {
  group: React.RefObject<THREE.Group>;
  protein: React.RefObject<THREE.Group>;
  tuft: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  filtration: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * filtration;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // glomerular tuft pulses with each filtration beat
    if (tuft.current) {
      tuft.current.scale.setScalar(1 + 0.08 * Math.sin(t * 3));
    }
    // protein leaks through the filter in nephrotic syndrome
    if (protein.current) {
      protein.current.visible = condition === "nephrotic";
      protein.current.children.forEach((p, i) => {
        const ph = ((t * 0.4 + i / N_PROTEIN) % 1);
        p.position.set(Math.sin(i * 2.1) * 0.5, 2.6 - ph * 3.0, Math.cos(i * 1.9) * 0.5);
        (p as THREE.Mesh).scale.setScalar(0.7 + ph * 0.6);
      });
    }
  });
  return null;
}

export function Topic10272Sim(props: SimProps) {
  const condition = String(props.condition ?? "nephrotic");
  const filtration = Number(props.filtration ?? 1);
  const group = useRef<THREE.Group>(null!);
  const protein = useRef<THREE.Group>(null!);
  const tuft = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = { healthy: "Healthy filter", nephrotic: "Nephrotic syndrome", uti: "UTI in child" };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Filtration", `${filtration.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.6, 10]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* whole kidney (left, smaller, for context) */}
          <group position={[-3.2, 2.4, -0.5]} scale={0.8}>
            <mesh scale={[0.85, 1.15, 0.6]} castShadow>
              <sphereGeometry args={[0.62, 24, 18]} />
              <meshStandardMaterial color="#b91c1c" roughness={0.5} />
            </mesh>
            <mesh position={[0.3, 0, 0.1]} scale={[0.55, 0.75, 0.45]} castShadow>
              <sphereGeometry args={[0.35, 16, 12]} />
              <meshStandardMaterial color="#fca5a5" roughness={0.5} />
            </mesh>
          </group>
          {/* nephron magnified: glomerulus + tubule */}
          {/* Bowman's capsule: transparent cup */}
          <mesh position={[0.6, 2.6, 0]} castShadow>
            <sphereGeometry args={[1.05, 28, 20, 0, Math.PI * 2, 0, Math.PI * 0.72]} />
            <meshStandardMaterial color="#bae6fd" roughness={0.2} transparent opacity={0.35} side={THREE.DoubleSide} />
          </mesh>
          {/* glomerular tuft: knot of capillaries */}
          <group ref={tuft} position={[0.6, 2.75, 0]}>
            {Array.from({ length: 12 }).map((_, i) => {
              const a = (i / 12) * Math.PI * 2;
              return (
                <mesh key={i} position={[Math.cos(a) * 0.42, Math.sin(a * 2) * 0.25, Math.sin(a) * 0.42]} castShadow>
                  <sphereGeometry args={[0.22, 12, 10]} />
                  <meshStandardMaterial
                    color={condition === "nephrotic" ? "#f87171" : "#dc2626"}
                    roughness={0.4}
                    emissive={condition === "nephrotic" ? "#7f1d1d" : "#000000"}
                    emissiveIntensity={0.6}
                  />
                </mesh>
              );
            })}
          </group>
          {/* afferent arteriole feeding in */}
          <mesh position={[-0.7, 2.9, 0]} rotation={[0, 0, 1.25]} castShadow>
            <cylinderGeometry args={[0.16, 0.16, 1.4, 12]} />
            <meshStandardMaterial color="#ef4444" roughness={0.4} />
          </mesh>
          {/* tubule draining down */}
          <mesh position={[0.6, 1.15, 0]} castShadow>
            <cylinderGeometry args={[0.22, 0.22, 1.6, 14]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.5} transparent opacity={0.85} />
          </mesh>
          <mesh position={[1.5, 0.55, 0]} rotation={[0, 0, 0.9]} castShadow>
            <cylinderGeometry args={[0.18, 0.18, 1.4, 12]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.5} transparent opacity={0.85} />
          </mesh>
          {/* leaking protein particles */}
          <group ref={protein} visible={false}>
            {Array.from({ length: N_PROTEIN }).map((_, i) => (
              <mesh key={i}>
                <sphereGeometry args={[0.12, 10, 8]} />
                <meshBasicMaterial color="#fde047" />
              </mesh>
            ))}
          </group>
          {/* UTI: bacteria in the bladder below */}
          {condition === "uti" && (
            <group position={[0.6, -0.35, 0]}>
              <mesh scale={[1.1, 0.9, 0.85]} castShadow>
                <sphereGeometry args={[0.55, 20, 14]} />
                <meshStandardMaterial color="#fb923c" roughness={0.5} emissive="#c2410c" emissiveIntensity={0.5} />
              </mesh>
              {Array.from({ length: 8 }).map((_, i) => (
                <mesh key={i} position={[Math.sin(i * 2.4) * 0.35, Math.cos(i * 1.8) * 0.3, Math.sin(i * 3.1) * 0.35]}>
                  <sphereGeometry args={[0.09, 8, 6]} />
                  <meshStandardMaterial color="#4ade80" emissive="#166534" emissiveIntensity={1} />
                </mesh>
              ))}
            </group>
          )}
          <Label text="Kidney" position={[-3.2, 3.6, -0.5]} size={0.5} color="#fca5a5" />
          <Label text="Glomerulus (filter)" position={[2.3, 3.3, 0]} size={0.55} color="#bae6fd" />
          <Label text="Tubule → urine" position={[2.35, 0.7, 0]} size={0.5} color="#fde68a" />
          <Arrow from={[-1.35, 3.15, 0]} to={[-0.25, 2.9, 0]} color="#ef4444" radius={0.06} />
          {condition === "nephrotic" && <Label text="⚠ Protein leaking out!" position={[0.6, 0.05, 0]} size={0.55} color="#fde047" />}
          {condition === "uti" && <Label text="🔥 Bacteria in bladder" position={[0.6, -1.15, 0]} size={0.55} color="#fdba74" />}
          {condition === "healthy" && <Label text="Filter holds protein ✓" position={[0.6, 0.05, 0]} size={0.5} color="#86efac" />}
        </group>
        <Animator group={group} protein={protein} tuft={tuft} elapsed={elapsed} filtration={filtration} condition={condition} />
      </SimCanvas>
    </div>
  );
}
