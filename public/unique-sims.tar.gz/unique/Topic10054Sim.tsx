// Neurophysiology: autonomic nervous system & hypothalamus — a balance scale
// tips between sympathetic (fight-or-flight, red) and parasympathetic
// (rest-and-digest, blue); organs respond live to the stress slider.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stress", label: "Stress level", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.5, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Neurophysiology: Autonomic Balance",
  blurb: "Tip the scale from rest-and-digest to fight-or-flight — heart, pupils and gut respond instantly.",
};

function Animator({
  beam, heart, pupil, gut, elapsed, stress, speed,
}: {
  beam: React.RefObject<THREE.Group>;
  heart: React.RefObject<THREE.Group>;
  pupil: React.RefObject<THREE.Mesh>;
  gut: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  stress: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // balance beam tips with stress
    if (beam.current) {
      const target = (stress - 0.5) * 0.5;
      const cur = beam.current.userData.a ?? target;
      const na = cur + (target - cur) * Math.min(1, delta * 3);
      beam.current.userData.a = na;
      beam.current.rotation.z = na;
    }
    // heart races with stress
    if (heart.current) {
      const hr = 60 + stress * 90;
      const beat = Math.pow(Math.max(0, Math.sin(t * (hr / 60) * Math.PI * 2)), 2);
      heart.current.scale.setScalar(1 + 0.12 * beat);
    }
    // pupils dilate with stress
    if (pupil.current) {
      pupil.current.scale.setScalar(0.5 + stress * 0.9);
    }
    // gut motility slows with stress
    if (gut.current) {
      const mat = gut.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = (1 - stress) * 0.5 + 0.15 * Math.sin(t * (1 + (1 - stress) * 5));
    }
  });
  return null;
}

export function Topic10054Sim(props: SimProps) {
  const stress = Number(props.stress ?? 0.5);
  const speed = Number(props.speed ?? 1);
  const beam = useRef<THREE.Group>(null!);
  const heart = useRef<THREE.Group>(null!);
  const pupil = useRef<THREE.Mesh>(null!);
  const gut = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const mode = stress > 0.66 ? "SYMPATHETIC — fight or flight 🔴" : stress < 0.33 ? "PARASYMPATHETIC — rest & digest 🔵" : "balanced ⚖";
  const modeColor = stress > 0.66 ? "#fca5a5" : stress < 0.33 ? "#7dd3fc" : "#f8fafc";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["State", mode],
          ["Heart rate", `${Math.round(60 + stress * 90)} bpm`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* hypothalamus: the conductor */}
        <group position={[0, 6.6, 0]}>
          <mesh castShadow scale={[1.2, 0.8, 1]}>
            <sphereGeometry args={[0.9, 16, 16]} />
            <meshStandardMaterial color="#c084fc" roughness={0.45} />
          </mesh>
        </group>
        <Label text="hypothalamus — autonomic conductor" position={[0, 7.8, 0]} size={0.34} color="#d8b4fe" />

        {/* balance scale */}
        <group position={[0, 0, 0]}>
          <mesh position={[0, 2.4, 0]} castShadow>
            <cylinderGeometry args={[0.12, 0.2, 4.8, 10]} />
            <meshStandardMaterial color="#64748b" roughness={0.5} />
          </mesh>
          <group ref={beam} position={[0, 4.6, 0]}>
            <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
              <cylinderGeometry args={[0.09, 0.09, 8.4, 10]} />
              <meshStandardMaterial color="#94a3b8" roughness={0.5} />
            </mesh>
            {/* sympathetic pan (red) */}
            <group position={[4.0, 0, 0]}>
              <mesh position={[0, -0.9, 0]} castShadow>
                <cylinderGeometry args={[0.9, 0.7, 0.25, 16]} />
                <meshStandardMaterial color="#ef4444" roughness={0.45} />
              </mesh>
              <mesh position={[0, -0.5, 0]}>
                <boxGeometry args={[0.06, 0.8, 0.06]} />
                <meshStandardMaterial color="#94a3b8" />
              </mesh>
              <Label text="sympathetic" position={[0, -1.5, 0]} size={0.34} color="#fca5a5" />
            </group>
            {/* parasympathetic pan (blue) */}
            <group position={[-4.0, 0, 0]}>
              <mesh position={[0, -0.9, 0]} castShadow>
                <cylinderGeometry args={[0.9, 0.7, 0.25, 16]} />
                <meshStandardMaterial color="#3b82f6" roughness={0.45} />
              </mesh>
              <mesh position={[0, -0.5, 0]}>
                <boxGeometry args={[0.06, 0.8, 0.06]} />
                <meshStandardMaterial color="#94a3b8" />
              </mesh>
              <Label text="parasympathetic" position={[0, -1.5, 0]} size={0.34} color="#7dd3fc" />
            </group>
          </group>
        </group>

        {/* target organs */}
        {/* heart */}
        <group ref={heart} position={[-6.4, 2.0, 0]}>
          <mesh castShadow scale={[1, 1.2, 0.9]}>
            <sphereGeometry args={[0.8, 18, 18]} />
            <meshStandardMaterial color="#dc2626" roughness={0.4} />
          </mesh>
        </group>
        <Label text={`heart: ${Math.round(60 + stress * 90)} bpm`} position={[-6.4, 3.5, 0]} size={0.32} color="#fca5a5" />
        {/* eye with pupil */}
        <group position={[6.4, 2.0, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.7, 18, 18]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.25} />
          </mesh>
          <mesh position={[0, 0, 0.55]}>
            <circleGeometry args={[0.32, 18]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.3} />
          </mesh>
          <mesh ref={pupil} position={[0, 0, 0.6]}>
            <circleGeometry args={[0.16, 18]} />
            <meshBasicMaterial color="#0f172a" />
          </mesh>
        </group>
        <Label text={stress > 0.5 ? "pupils dilate" : "pupils constrict"} position={[6.4, 3.3, 0]} size={0.3} color="#f8fafc" />
        {/* gut */}
        <mesh ref={gut} position={[-6.4, -0.6, 0]} rotation={[0, 0, 0.4]} castShadow>
          <torusGeometry args={[0.7, 0.28, 10, 20, Math.PI * 1.5]} />
          <meshStandardMaterial color="#fda4af" emissive="#7f1d1d" emissiveIntensity={0.3} roughness={0.5} />
        </mesh>
        <Label text={stress > 0.5 ? "gut slows (blood → muscles)" : "gut digests happily"} position={[-6.4, -1.9, 0]} size={0.3} color="#fda4af" />
        {/* bronchioles */}
        <mesh position={[6.4, -0.6, 0]} castShadow>
          <cylinderGeometry args={[0.2 + stress * 0.18, 0.2 + stress * 0.18, 1.6, 10]} />
          <meshStandardMaterial color="#c084fc" roughness={0.5} />
        </mesh>
        <Label text={stress > 0.5 ? "airways dilate" : "airways normal"} position={[6.4, -1.9, 0]} size={0.3} color="#d8b4fe" />

        <Label text={mode} position={[0, 0.4, 0]} size={0.4} color={modeColor} />

        <Animator beam={beam} heart={heart} pupil={pupil} gut={gut} elapsed={elapsed} stress={stress} speed={speed} />
      </SimCanvas>
    </div>
  );
}
