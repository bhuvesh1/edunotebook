// app/components/sims/unique/Topic10506Sim.tsx
// Cysts and tumors of the jaws: a mandible with a translucent cystic cavity
// growing inside the bone, expanding the jaw as it enlarges.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "growth", label: "Lesion growth", kind: "slider", min: 0, max: 100, step: 1, default: 55, unit: "%" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Cysts & Tumors of the Jaws",
  blurb: "A cyst expands inside the jawbone, thinning the cortex and displacing teeth as it grows.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ cyst, jaw, elapsed, speed, growth }: {
  cyst: RefObject<THREE.Mesh>; jaw: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number; growth: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const pulse = 1 + 0.04 * Math.sin(elapsed.current * 2.5);
    if (cyst.current) {
      cyst.current.scale.setScalar(Math.max((0.2 + (growth / 100) * 1.5) * pulse, 0.001));
      const mat = cyst.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = 0.5 + 0.3 * Math.sin(elapsed.current * 2.5);
    }
    if (jaw.current) jaw.current.rotation.y = Math.sin(elapsed.current * 0.25) * 0.35;
  });
  return null;
}

const BONE = "#e6d9bd";

// tooth positions along the mandibular U-arc (lower half of the ring)
const TEETH: [number, number][] = [];
for (let i = 0; i < 9; i++) {
  const a = Math.PI * (1.15 + (i / 8) * 0.7);
  TEETH.push([Math.cos(a) * 2.1, 1.2 + Math.sin(a) * 2.1]);
}

export function Topic10506Sim(props: SimProps) {
  const growth = Number(props.growth ?? 55);
  const speed = Number(props.speed ?? 1);
  const cyst = useRef<THREE.Mesh>(null!);
  const jaw = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Lesion size", `${(0.4 + (growth / 100) * 3).toFixed(1)} cm`],
          ["● Cyst cavity", "blue, expansile"],
          ["Effect", growth > 70 ? "cortical expansion + tooth displacement" : growth > 30 ? "bone expansion" : "small radiolucency"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 11]} target={[0, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={jaw}>
          {/* mandible body: U-shaped arc */}
          <mesh position={[0, 1.2, 0]} rotation={[0, 0, Math.PI]} castShadow>
            <torusGeometry args={[2.1, 0.55, 14, 40, Math.PI]} />
            <meshStandardMaterial color={BONE} roughness={0.65} />
          </mesh>
          {/* chin */}
          <mesh position={[0, -0.9, 0]} castShadow>
            <sphereGeometry args={[0.55, 20, 20]} />
            <meshStandardMaterial color={BONE} roughness={0.65} />
          </mesh>
          {/* rami going up at the back */}
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 2.1, 2.2, 0]} castShadow>
              <boxGeometry args={[0.7, 2, 0.8]} />
              <meshStandardMaterial color={BONE} roughness={0.65} />
            </mesh>
          ))}
          {/* teeth along the arc */}
          {TEETH.map(([x, z], i) => (
            <mesh key={i} position={[x, 1.95, z]} castShadow>
              <boxGeometry args={[0.34, 0.5, 0.34]} />
              <meshStandardMaterial color="#ffffff" roughness={0.3} />
            </mesh>
          ))}
          {/* expanding cyst inside the bone (right body of mandible) */}
          <mesh ref={cyst} position={[1.45, 1.25, 0.35]}>
            <sphereGeometry args={[0.62, 28, 28]} />
            <meshStandardMaterial color="#38bdf8" emissive="#0ea5e9" emissiveIntensity={0.6} transparent opacity={0.55} roughness={0.2} />
          </mesh>
          <Label p={[1.45, 2.6, 0.35]} size={0.3} color="#7dd3fc">cyst cavity</Label>
          <Label p={[-1.6, 0.6, 1.6]} size={0.3} color={BONE}>mandible</Label>
        </group>

        <Animator cyst={cyst} jaw={jaw} elapsed={elapsed} speed={speed} growth={growth} />
      </SimCanvas>
    </div>
  );
}
