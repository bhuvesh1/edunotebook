// app/components/sims/unique/Topic10512Sim.tsx
// Implant surgery: cross-section of gum and jawbone. Stages animate the
// drill, implant placement, bone graft particles, and final crown.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Surgical stage", kind: "select", min: 0, max: 0, step: 1, default: "placement", options: ["drilling", "placement", "grafting", "crown"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Implant Surgery: Placement & Bone Grafting",
  blurb: "Drill the osteotomy, thread the implant in, pack bone graft, and seat the crown — stage by stage.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function ImplantScrew({ position, y = 0 }: { position: [number, number, number]; y?: number }) {
  return (
    <group position={position}>
      {/* threaded fixture */}
      <mesh position={[0, y, 0]} castShadow>
        <cylinderGeometry args={[0.28, 0.2, 1.6, 16]} />
        <meshStandardMaterial color="#9ca3af" metalness={0.85} roughness={0.3} />
      </mesh>
      {/* thread rings */}
      {[0.5, 0.15, -0.2, -0.55].map((dy, i) => (
        <mesh key={i} position={[0, y + dy, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.27, 0.05, 8, 20]} />
          <meshStandardMaterial color="#d1d5db" metalness={0.85} roughness={0.3} />
        </mesh>
      ))}
      {/* abutment */}
      <mesh position={[0, y + 1.05, 0]} castShadow>
        <cylinderGeometry args={[0.18, 0.24, 0.5, 14]} />
        <meshStandardMaterial color="#e5e7eb" metalness={0.9} roughness={0.25} />
      </mesh>
    </group>
  );
}

function Animator({ drill, implant, elapsed, speed, stage }: {
  drill: RefObject<THREE.Group>; implant: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number; stage: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (drill.current) {
      drill.current.visible = stage === "drilling";
      if (stage === "drilling") {
        drill.current.position.y = 3.4 + 0.35 * Math.abs(Math.sin(t * 4));
        drill.current.rotation.y = t * 12;
      }
    }
    if (implant.current) {
      implant.current.visible = stage !== "drilling";
      // screw threads down into the bone with a screwing motion
      const targetY = stage === "placement" ? 0 : stage === "grafting" ? -0.15 : -0.15;
      const cyc = (Math.sin(t * 1.2) * 0.5 + 0.5);
      implant.current.position.y = targetY + (stage === "placement" ? cyc * 0.5 : 0);
      implant.current.rotation.y = stage === "placement" ? t * 3 : 0;
    }
  });
  return null;
}

const GUM = "#f472b6";
const BONE = "#d9b98a";

const STAGE_INFO: Record<string, string> = {
  drilling: "Pilot + sequential drills shape the osteotomy",
  placement: "Fixture threaded to 35 Ncm torque",
  grafting: "Bone graft packed around threads",
  crown: "Healing done — crown seated on abutment",
};

export function Topic10512Sim(props: SimProps) {
  const stage = String(props.stage ?? "placement");
  const speed = Number(props.speed ?? 1);
  const drill = useRef<THREE.Group>(null!);
  const implant = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", stage],
          ["Protocol", STAGE_INFO[stage]],
          ["● Implant", "titanium fixture"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* jawbone block */}
        <mesh position={[0, 1.1, -0.2]} castShadow receiveShadow>
          <boxGeometry args={[7, 2.4, 2.4]} />
          <meshStandardMaterial color={BONE} roughness={0.85} />
        </mesh>
        {/* cortical top line */}
        <mesh position={[0, 2.32, -0.2]}>
          <boxGeometry args={[7, 0.12, 2.45]} />
          <meshStandardMaterial color="#b98d54" roughness={0.8} />
        </mesh>
        {/* gum */}
        <mesh position={[0, 2.62, -0.2]} castShadow>
          <boxGeometry args={[7, 0.55, 2.6]} />
          <meshStandardMaterial color={GUM} roughness={0.6} />
        </mesh>
        {/* osteotomy hole (dark) */}
        <mesh position={[0, 1.7, 1.05]}>
          <cylinderGeometry args={[0.32, 0.32, 2.2, 16]} />
          <meshStandardMaterial color="#3f2d18" roughness={1} />
        </mesh>

        {/* drill (visible in drilling stage) */}
        <group ref={drill} position={[0, 3.4, 1.05]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.3, 0.3, 1.4, 14]} />
            <meshStandardMaterial color="#64748b" metalness={0.7} roughness={0.35} />
          </mesh>
          <mesh position={[0, -1.2, 0]}>
            <cylinderGeometry args={[0.16, 0.1, 1.2, 12]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.2} />
          </mesh>
        </group>

        {/* implant fixture + abutment */}
        <group ref={implant} position={[0, 0, 1.05]}>
          <ImplantScrew position={[0, 1.55, 0]} />
        </group>

        {/* bone graft particles (grafting stage) */}
        {stage === "grafting" && (
          <group>
            {[...Array(14)].map((_, i) => {
              const a = (i / 14) * Math.PI * 2;
              return (
                <mesh key={i} position={[Math.cos(a) * 0.75, 1.9 + ((i * 37) % 40) / 40, 1.05 + Math.sin(a) * 0.75]}>
                  <sphereGeometry args={[0.09, 10, 10]} />
                  <meshStandardMaterial color="#fef3c7" roughness={0.8} />
                </mesh>
              );
            })}
            <Label p={[2.2, 2.2, 1.4]} size={0.3} color="#fef3c7">bone graft</Label>
          </group>
        )}

        {/* crown (final stage) */}
        {stage === "crown" && (
          <group>
            <mesh position={[0, 3.6, 1.05]} castShadow>
              <boxGeometry args={[0.95, 0.8, 0.95]} />
              <meshStandardMaterial color="#ffffff" roughness={0.25} />
            </mesh>
            <mesh position={[0, 3.05, 1.05]}>
              <boxGeometry args={[0.7, 0.35, 0.7]} />
              <meshStandardMaterial color="#e5e7eb" metalness={0.8} roughness={0.3} />
            </mesh>
            <Label p={[2.1, 3.6, 1.2]} size={0.3} color="#ffffff">porcelain crown</Label>
          </group>
        )}

        <Label p={[-3.2, 1.1, 1.2]} size={0.3} color="#fde68a">jawbone</Label>
        <Label p={[-3.2, 2.62, 1.2]} size={0.3} color="#f9a8d4">gum</Label>
        <Label p={[0, 0.1, 1.2]} size={0.3} color="#d1d5db">titanium implant</Label>

        <Animator drill={drill} implant={implant} elapsed={elapsed} speed={speed} stage={stage} />
      </SimCanvas>
    </div>
  );
}
