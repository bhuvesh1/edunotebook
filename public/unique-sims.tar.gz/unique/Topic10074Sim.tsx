"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "view", label: "Show", kind: "select", min: 0, max: 0, step: 1, default: "both", options: ["both", "fat-soluble", "water-soluble"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Vitamins: Fat vs Water Soluble",
  blurb: "A, D, E and K ride in an oil droplet while the B-complex and C dissolve and rain through water.",
};

const VITS: [string, string][] = [["A","#fb923c"],["D","#facc15"],["E","#4ade80"],["K","#c084fc"]];
const BS: [string, string][] = [["B1","#60a5fa"],["B2","#38bdf8"],["B6","#818cf8"],["B12","#22d3ee"],["Folate","#2dd4bf"],["C","#f472b6"]];

function Animator({ root, caps, drops, elapsed, speed }: { root: RefObject<THREE.Group>; caps: RefObject<THREE.Group>; drops: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (caps.current) {
      caps.current.children.forEach((m, i) => {
        const a = t * 0.55 + (i / 4) * Math.PI * 2;
        m.position.set(-2.6 + Math.cos(a) * 2.1, 1.9 + Math.sin(t * 1.3 + i) * 0.25, Math.sin(a) * 2.1);
        m.rotation.z = a;
      });
    }
    if (drops.current) {
      drops.current.children.forEach((m, i) => {
        m.position.y = 2.4 - ((t * 0.5 + i / 6) % 1) * 2.1;
      });
    }
  });
  return null;
}

export function Topic10074Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const view = String(props.view ?? "both");
  const showFat = view !== "water-soluble";
  const showWater = view !== "fat-soluble";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const caps = useRef<THREE.Group>(null!);
  const drops = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Fat-soluble", "A \u00b7 D \u00b7 E \u00b7 K"],
          ["Water-soluble", "B-complex \u00b7 C"],
          ["Storage", "liver + fat vs excreted"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <group visible={showFat}>
            <mesh position={[-2.6, 1.9, 0]}>
              <sphereGeometry args={[1.25, 24, 24]} />
              <meshStandardMaterial color="#f59e0b" transparent opacity={0.45} roughness={0.3} />
            </mesh>
            <group ref={caps}>
              {VITS.map(([name, color]) => (
                <group key={name}>
                  <mesh castShadow>
                    <capsuleGeometry args={[0.26, 0.5, 6, 12]} />
                    <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.35} roughness={0.35} />
                  </mesh>
                  <Label text={name} position={[0, 0.62, 0]} size={0.4} color={color} />
                </group>
              ))}
            </group>
            <Label text="oil \u2014 fat soluble" position={[-2.6, 0.35, 0]} size={0.42} color="#f59e0b" />
          </group>
          <group visible={showWater}>
            <mesh position={[3, 1.55, 0]}>
              <boxGeometry args={[3.4, 2.7, 2.2]} />
              <meshStandardMaterial color="#38bdf8" transparent opacity={0.16} roughness={0.2} />
            </mesh>
            <group ref={drops}>
              {BS.map(([name], i) => (
                <mesh key={name} position={[2 + (i % 3) * 1, 2.4, (Math.floor(i / 3) - 0.5) * 1.1]}>
                  <sphereGeometry args={[0.24, 14, 14]} /><meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={0.8} />
                </mesh>
              ))}
            </group>
            {BS.map(([name], i) => (
              <Label key={name} text={name} position={[2 + (i % 3) * 1, 0.25, (Math.floor(i / 3) - 0.5) * 1.1]} size={0.36} color="#7dd3fc" />
            ))}
            <Label text="water \u2014 B-complex + C" position={[3, 3.35, 0]} size={0.42} color="#38bdf8" />
          </group>
        </group>
        <Animator root={root} caps={caps} drops={drops} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
