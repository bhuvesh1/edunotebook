// Fracture complications: open fractures, compartment syndrome, fat embolism.
// Three emergencies: bone piercing the skin, a swelling muscle compartment
// strangling itself, and fat droplets escaping into the blood toward the lungs.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "complication", label: "Complication", kind: "select", min: 0, max: 0, step: 1, default: "compartment", options: ["open", "compartment", "fat_embolism"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Fracture Emergencies",
  blurb: "Bone through skin, a muscle compartment swelling shut, or fat emboli racing to the lungs — act fast.",
};

function Animator({
  group, swelling, fat, gauge, elapsed, speed, complication,
}: {
  group: React.RefObject<THREE.Group>;
  swelling: React.RefObject<THREE.Mesh>;
  fat: React.RefObject<THREE.Group>;
  gauge: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
  complication: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
    if (swelling.current && complication === "compartment") {
      // compartment swells relentlessly
      const s = 1 + 0.3 * (0.5 + 0.5 * Math.sin(t * 0.8)) + 0.12 * Math.sin(t * 6);
      swelling.current.scale.set(s, 1, s);
      (swelling.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.3 + 0.4 * (0.5 + 0.5 * Math.sin(t * 6));
    }
    if (fat.current) {
      fat.current.visible = complication === "fat_embolism";
      fat.current.children.forEach((d, i) => {
        const ph = ((t * 0.5 + i / fat.current!.children.length) % 1);
        d.position.set(-1.2 + ph * 3.4, 1.6 + Math.sin(ph * 6 + i) * 0.3, 0.2);
      });
    }
    if (gauge.current && complication === "compartment") {
      // pressure needle climbs into the red zone
      const p = 0.5 + 0.5 * Math.sin(t * 0.8);
      gauge.current.rotation.z = 0.8 - p * 1.9;
    }
  });
  return null;
}

export function Topic10295Sim(props: SimProps) {
  const complication = String(props.complication ?? "compartment");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const swelling = useRef<THREE.Mesh>(null!);
  const fat = useRef<THREE.Group>(null!);
  const gauge = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    open: "Open fracture", compartment: "Compartment syndrome", fat_embolism: "Fat embolism",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Emergency", names[complication] ?? complication], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10.5]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {complication === "open" && (
            <>
              {/* leg with skin */}
              <mesh position={[-1.6, 1.9, 0]} rotation={[0, 0, 0.12]} castShadow>
                <capsuleGeometry args={[0.75, 2.8, 8, 16]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              {/* bone shard piercing out */}
              <mesh position={[-1.15, 2.1, 0.3]} rotation={[0, 0, -0.9]} castShadow>
                <coneGeometry args={[0.22, 1.6, 8]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} flatShading />
              </mesh>
              {/* wound + bleeding */}
              <mesh position={[-1.45, 1.95, 0.35]} castShadow>
                <sphereGeometry args={[0.4, 14, 10]} />
                <meshStandardMaterial color="#b91c1c" roughness={0.4} emissive="#7f1d1d" emissiveIntensity={0.7} />
              </mesh>
              <Label text="⚠ Bone through skin — infection risk!" position={[-1.6, 3.9, 0.3]} size={0.6} color="#fca5a5" />
            </>
          )}

          {complication === "compartment" && (
            <>
              {/* leg cross-section: fascia ring + swelling muscles */}
              <mesh position={[0, 1.9, 0]} castShadow>
                <torusGeometry args={[1.15, 0.14, 12, 28]} />
                <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
              </mesh>
              <mesh ref={swelling} position={[0, 1.9, 0]} castShadow>
                <sphereGeometry args={[0.95, 24, 18]} />
                <meshStandardMaterial color="#dc2626" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.5} />
              </mesh>
              {/* squashed nerve + artery in the middle */}
              <mesh position={[0, 1.9, 0.1]} castShadow>
                <cylinderGeometry args={[0.12, 0.12, 0.7, 10]} />
                <meshStandardMaterial color="#fbbf24" roughness={0.5} />
              </mesh>
              <mesh position={[0.3, 1.9, 0.1]} castShadow>
                <cylinderGeometry args={[0.1, 0.1, 0.7, 10]} />
                <meshStandardMaterial color="#60a5fa" roughness={0.5} />
              </mesh>
              {/* pressure gauge */}
              <group position={[2.8, 2.8, 0]}>
                <mesh castShadow>
                  <cylinderGeometry args={[0.55, 0.55, 0.15, 24]} />
                  <meshStandardMaterial color="#1e293b" roughness={0.4} />
                </mesh>
                <mesh position={[0, 0, 0.1]} rotation={[Math.PI / 2, 0, 0]}>
                  <torusGeometry args={[0.42, 0.06, 8, 20, Math.PI * 1.2]} />
                  <meshStandardMaterial color="#ef4444" roughness={0.4} />
                </mesh>
                <mesh ref={gauge} position={[0, 0, 0.12]}>
                  <boxGeometry args={[0.06, 0.4, 0.04]} />
                  <meshStandardMaterial color="#f8fafc" roughness={0.4} />
                </mesh>
              </group>
              <Label text="Fascia won't stretch!" position={[-2.3, 2.9, 0]} size={0.55} color="#e2e8f0" />
              <Label text="⚠ Pressure rising — cut fascia NOW" position={[0, 0.35, 0]} size={0.6} color="#fca5a5" />
            </>
          )}

          {complication === "fat_embolism" && (
            <>
              {/* broken femur leaking marrow fat */}
              <mesh position={[-1.2, 1.9, 0]} rotation={[0, 0, 0.15]} castShadow>
                <cylinderGeometry args={[0.32, 0.32, 2.6, 14]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
              <mesh position={[-1.2, 1.9, 0]}>
                <cylinderGeometry args={[0.18, 0.18, 2.65, 10]} />
                <meshStandardMaterial color="#fbbf24" roughness={0.6} />
              </mesh>
              {/* vein carrying fat to lungs */}
              <mesh position={[0.9, 1.6, 0.2]} rotation={[0, 0, 1.35]} castShadow>
                <cylinderGeometry args={[0.22, 0.22, 4.2, 14, 1, true]} />
                <meshStandardMaterial color="#3b82f6" roughness={0.4} transparent opacity={0.4} side={THREE.DoubleSide} />
              </mesh>
              {/* lungs at the end */}
              <mesh position={[2.6, 2.6, 0.2]} scale={[0.9, 1.2, 0.7]} castShadow>
                <sphereGeometry args={[0.7, 20, 14]} />
                <meshStandardMaterial color="#fda4af" roughness={0.5} />
              </mesh>
              <group ref={fat} visible={false}>
                {Array.from({ length: 12 }).map((_, i) => (
                  <mesh key={i} castShadow>
                    <sphereGeometry args={[0.14, 10, 8]} />
                    <meshStandardMaterial color="#fde047" roughness={0.3} emissive="#a16207" emissiveIntensity={0.6} />
                  </mesh>
                ))}
              </group>
              <Label text="Marrow fat escapes" position={[-1.2, 3.5, 0]} size={0.55} color="#fde68a" />
              <Label text="⚠ Fat reaches the lungs!" position={[2.6, 3.7, 0.2]} size={0.6} color="#fca5a5" />
            </>
          )}
        </group>
        <Animator group={group} swelling={swelling} fat={fat} gauge={gauge} elapsed={elapsed} speed={speed} complication={complication} />
      </SimCanvas>
    </div>
  );
}
