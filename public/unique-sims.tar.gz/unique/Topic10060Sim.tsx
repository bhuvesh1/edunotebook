"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "count", label: "Amino acids", kind: "slider", min: 8, max: 24, step: 1, default: 14 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Protein Structure & Amino Acids",
  blurb: "An amino-acid chain folds into a spinning alpha-helix, color-coded by side-chain class.",
};

const AA_COLORS = ["#38bdf8", "#4ade80", "#fbbf24", "#f87171"];
const AA_NAMES = ["hydrophobic", "polar", "basic", "acidic"];

function Animator({ root, beads, elapsed, speed }: { root: RefObject<THREE.Group>; beads: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (root.current) root.current.rotation.y = t * 0.35;
    if (beads.current) {
      beads.current.children.forEach((m, i) => {
        m.scale.setScalar(1 + 0.22 * Math.sin(t * 3.2 - i * 0.55));
      });
    }
  });
  return null;
}

export function Topic10060Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const count = Math.round(Number(props.count ?? 14));
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const beads = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Residues", `${count}`],
          ["Structure", "\u03b1-helix (secondary)"],
          ["Bonds", "peptide (C\u2013N)"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 11]} target={[0, 3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <group ref={beads}>
            {Array.from({ length: count }).map((_, i) => {
              const a = i * 1.75;
              return (
                <mesh key={i} position={[Math.cos(a) * 1.4, 0.6 + i * 0.42, Math.sin(a) * 1.4]} castShadow>
                  <sphereGeometry args={[0.34, 20, 20]} />
                  <meshStandardMaterial color={AA_COLORS[i % 4]} roughness={0.35} />
                </mesh>
              );
            })}
          </group>
          <Label text="\u03b1-helix" position={[0, 0.6 + count * 0.42 + 0.8, 0]} />
          {AA_NAMES.map((n, i) => (
            <group key={n} position={[3.4, 3.4 - i * 0.8, 0]}>
              <mesh><sphereGeometry args={[0.18, 16, 16]} /><meshStandardMaterial color={AA_COLORS[i]} /></mesh>
              <Label text={n} position={[1.1, 0, 0]} size={0.42} />
            </group>
          ))}
          <Label text="peptide bonds link C\u2013N" position={[0, 0.1, 0]} size={0.42} color="#94a3b8" />
        </group>
        <Animator root={root} beads={beads} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
