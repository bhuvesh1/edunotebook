// Pharmacodynamics: drug molecules dock onto cell receptors — agonists switch
// them ON, antagonists sit in the slot and block the response.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "conc", label: "Drug concentration", kind: "slider", min: 1, max: 8, step: 1, default: 5, unit: "mol" },
  { key: "drug", label: "Drug type", kind: "select", min: 0, max: 0, step: 1, default: "agonist", options: ["agonist", "antagonist"] },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Pharmacodynamics: receptors",
  blurb: "Drug molecules dock onto cell receptors — agonists switch them ON, antagonists block the slot.",
};

const N_REC = 8;
const REC_X = (i: number) => -3.5 + i * 1;

function Animator({ mols, elapsed, speed, setTick }: {
  mols: React.RefObject<(THREE.Group | null)[]>;
  elapsed: React.RefObject<number>;
  speed: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    mols.current.forEach((g, i) => {
      if (!g) return;
      // molecules bob above, then settle into their receptor slot in sequence
      const docked = (Math.floor(t * 1.2) + i * 2) % 12 < 8 - i * 0.4;
      const targetY = docked ? 1.55 : 2.6 + Math.sin(t * 2 + i * 1.7) * 0.25;
      const targetX = REC_X(i % N_REC) + (docked ? 0 : Math.sin(t * 0.8 + i) * 0.5);
      g.position.x += (targetX - g.position.x) * 0.06;
      g.position.y += (targetY - g.position.y) * 0.06;
      g.rotation.y = t * 1.5 + i;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(elapsed.current * 10)); }
  });
  return null;
}

export function Topic10106Sim(props: SimProps) {
  const conc = Math.round(Number(props.conc ?? 5));
  const drug = String(props.drug ?? "agonist");
  const isAgonist = drug === "agonist";
  const showLabels = String(props.detail ?? "on") === "on";
  const mols = useRef<(THREE.Group | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const occupancy = Math.min(100, Math.round((conc / N_REC) * 100));
  const response = isAgonist ? occupancy : 0;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Drug", isAgonist ? "Agonist" : "Antagonist"],
          ["Receptor occupancy", `${occupancy}%`],
          ["Cell response", `${response}%`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 11]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* cell membrane slab */}
        <mesh position={[0, 0.85, 0]} receiveShadow>
          <boxGeometry args={[9, 0.35, 3]} />
          <meshStandardMaterial color="#7c3aed" roughness={0.6} />
        </mesh>
        {showLabels && <Label text="cell membrane" position={[4.2, 0.5, 1.6]} size={0.45} color="#c4b5fd" />}

        {/* receptors: ring slots on the membrane, glow when switched ON */}
        {Array.from({ length: N_REC }).map((_, i) => {
          const on = isAgonist && i < conc;
          return (
            <group key={i} position={[REC_X(i), 1.25, 0]}>
              <mesh rotation={[Math.PI / 2, 0, 0]}>
                <torusGeometry args={[0.28, 0.1, 10, 20]} />
                <meshStandardMaterial
                  color={on ? "#22c55e" : "#475569"}
                  emissive={on ? "#22c55e" : "#000000"}
                  emissiveIntensity={on ? 1.2 : 0}
                />
              </mesh>
              <mesh position={[0, -0.15, 0]}>
                <cylinderGeometry args={[0.08, 0.08, 0.3, 8]} />
                <meshStandardMaterial color="#64748b" />
              </mesh>
            </group>
          );
        })}
        {showLabels && <Label text="receptors" position={[-3.5, 2.1, 0]} size={0.45} color="#c4b5fd" />}

        {/* drug molecules */}
        {Array.from({ length: 8 }).map((_, i) => (
          <group key={i} ref={(g) => { mols.current[i] = g; }} position={[REC_X(i), 3, 0]} visible={i < conc}>
            <mesh castShadow>
              <sphereGeometry args={[0.22, 16, 12]} />
              <meshStandardMaterial
                color={isAgonist ? "#22c55e" : "#ef4444"}
                emissive={isAgonist ? "#16a34a" : "#b91c1c"}
                emissiveIntensity={0.8}
              />
            </mesh>
            <mesh position={[0, 0.3, 0]}>
              <coneGeometry args={[0.1, 0.22, 8]} />
              <meshStandardMaterial color={isAgonist ? "#86efac" : "#fca5a5"} emissiveIntensity={0.5} emissive={isAgonist ? "#16a34a" : "#b91c1c"} />
            </mesh>
          </group>
        ))}
        {showLabels && (
          <Label
            text={isAgonist ? "agonist molecules — switch ON" : "antagonist molecules — block"}
            position={[0, 3.6, 0]}
            color={isAgonist ? "#86efac" : "#fca5a5"}
          />
        )}

        <Animator mols={mols} elapsed={elapsed} speed={1} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
