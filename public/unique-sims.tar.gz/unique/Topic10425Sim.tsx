"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "drug", label: "Emergency drug", kind: "select", min: 0, max: 0, step: 1, default: "adrenaline", options: ["adrenaline", "hemostatic", "antihistamine"] },
  { key: "bleed", label: "Bleeding severity", kind: "slider", min: 0, max: 10, step: 1, default: 6, unit: "/10" },
];

export const UNIQUE_META = {
  title: "Hemostatics and styptics, emergency drugs in dental office",
  blurb: "A bleeding vessel clots under a hemostatic pack while the emergency drug tray stands ready — adrenaline, styptic, antihistamine.",
};

const DRUGS: Record<string, { name: string; color: string; use: string }> = {
  adrenaline: { name: "Adrenaline 1:1000", color: "#ef4444", use: "Anaphylaxis — IM into thigh" },
  hemostatic: { name: "Tranexamic acid / styptic", color: "#fbbf24", use: "Press on socket — clot forms" },
  antihistamine: { name: "Chlorpheniramine", color: "#7dd3fc", use: "Allergy — slows the reaction" },
};

function BloodFlow({ rate, clotted }: { rate: number; clotted: boolean }) {
  const pts = useRef<THREE.Points>(null!);
  const t = useRef(0);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(30 * 3), 3));
    return g;
  }, []);
  useFrame((_, delta) => {
    t.current += delta * (0.4 + rate * 0.15);
    if (!pts.current) return;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < 30; i++) {
      const f = (t.current * 0.7 + i / 30) % 1;
      const stop = clotted ? 0.45 : 1;
      pos.setXYZ(i, -3 + Math.min(f, stop) * 6, 0.9 - Math.min(f, stop) * 0.5, 0);
    }
    pos.needsUpdate = true;
    (pts.current.material as THREE.PointsMaterial).opacity = clotted ? 0.25 : 0.95;
  });
  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial color="#ef4444" size={0.17} transparent />
    </points>
  );
}

function Scene({ drug, bleed }: { drug: string; bleed: number }) {
  const t = useRef(0);
  const clot = useRef<THREE.Mesh>(null!);
  const d = DRUGS[drug] ?? DRUGS.adrenaline;
  const clotted = drug === "hemostatic" && bleed < 9;

  useFrame((_, delta) => {
    t.current += delta;
    if (clot.current) {
      const s = clotted ? Math.min(1, t.current * 0.5) : Math.max(0, 1 - t.current * 0.3);
      clot.current.scale.setScalar(Math.max(0.01, s));
      clot.current.visible = s > 0.02;
    }
  });

  return (
    <group>
      {/* cut vessel */}
      <mesh position={[0, 1.1, 0]} rotation={[0, 0, 0.15]}>
        <cylinderGeometry args={[0.32, 0.32, 6.4, 16, 1, true]} />
        <meshStandardMaterial color="#b91c1c" roughness={0.4} side={THREE.DoubleSide} />
      </mesh>
      {/* cut gap */}
      <mesh position={[0.1, 0.62, 0]}>
        <boxGeometry args={[0.5, 0.35, 0.7]} />
        <meshStandardMaterial color="#450a0a" roughness={0.9} />
      </mesh>
      <BloodFlow rate={bleed} clotted={clotted} />
      <Label text="Bleeding vessel" position={[-3.4, 1.3, 0]} size={0.45} color="#fca5a5" />

      {/* hemostatic pack pressing */}
      <group position={[0.1, 1.35, 0]}>
        <mesh>
          <boxGeometry args={[1.4, 0.5, 1.2]} />
          <meshStandardMaterial color="#fef3c7" roughness={0.85} />
        </mesh>
        <Label text={drug === "hemostatic" ? "Hemostatic pack — press!" : "Gauze pack"} position={[0, 0.75, 0]} size={0.42} color="#fde68a" />
      </group>
      {/* clot forming */}
      <mesh ref={clot} position={[0.1, 0.62, 0]}>
        <sphereGeometry args={[0.42, 14, 14]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.35} />
      </mesh>
      {clotted && <Label text="Clot formed ✓" position={[0.1, -0.1, 0]} size={0.45} color="#86efac" />}

      {/* emergency drug tray */}
      <group position={[2.6, -1.4, 0]}>
        <mesh position={[0, -0.35, 0]}>
          <boxGeometry args={[2.6, 0.25, 1.6]} />
          <meshStandardMaterial color="#334155" roughness={0.6} />
        </mesh>
        {Object.entries(DRUGS).map(([key, dd], i) => {
          const activeD = key === drug;
          return (
            <group key={key} position={[-0.85 + i * 0.85, 0.15, 0]}>
              <mesh>
                <cylinderGeometry args={[0.16, 0.16, 0.7, 12]} />
                <meshStandardMaterial color={dd.color} roughness={0.3} emissive={activeD ? dd.color : "#000"} emissiveIntensity={activeD ? 0.7 : 0} />
              </mesh>
              <mesh position={[0, 0.45, 0]}>
                <cylinderGeometry args={[0.08, 0.08, 0.2, 10]} />
                <meshStandardMaterial color="#e2e8f0" roughness={0.4} />
              </mesh>
              {activeD && <Label text={dd.name} position={[0, 1.0, 0]} size={0.38} color={dd.color} />}
            </group>
          );
        })}
        <Label text="Emergency drug tray" position={[0, -0.9, 0]} size={0.45} color="#e2e8f0" />
      </group>

      <Label text={d.name} position={[0, 3.2, 0]} size={0.6} color={d.color} />
      <Label text={d.use} position={[0, -2.9, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10425Sim(props: SimProps) {
  const drug = String(props.drug ?? "adrenaline");
  const bleed = Number(props.bleed ?? 6);
  const d = DRUGS[drug] ?? DRUGS.adrenaline;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Drug", d.name], ["Bleeding", `${bleed}/10`], ["Clot", drug === "hemostatic" && bleed < 9 ? "Forming" : "Not forming"]]} />
      <SimCanvas cameraPosition={[0, 1, 10]} target={[0, 0.3, 0]}>
        <Scene drug={drug} bleed={bleed} />
      </SimCanvas>
    </div>
  );
}
