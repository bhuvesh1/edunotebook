"use client";
// Mandibular Fractures — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "site", label: "Fracture site", kind: "select", min: 0, max: 0, step: 1, default: "Angle", options: ["Symphysis", "Angle", "Condyle"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Mandibular Fractures",
  blurb: "The jaw can snap at the chin, the angle or the condyle — pick a site and see the fracture glow.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const sites = [["fxSym", "Symphysis"], ["fxAng", "Angle"], ["fxCon", "Condyle"]];
    sites.forEach(([nm]: any, i: number) => {
      const m: any = g(nm);
      if (m) {
        const on = p.site === sites[i][1];
        (m.material as any).emissiveIntensity = on ? 0.9 + 0.4 * Math.sin(t * 5) : 0.15;
        (m.material as any).opacity = on ? 1 : 0.45;
      }
    });
    const frag: any = g("fragA");
    if (frag) frag.position.x = (p.site === "Angle" ? 0.08 * Math.sin(t * 2.5) : 0);
  });
  return null;
}

export function Topic10502Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const site = String(props.site ?? "Angle");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, site };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Site", site],
          ["Sign", site === "Condyle" ? "Can't open mouth" : site === "Angle" ? "Wisdom-tooth weak spot" : "Chin impact"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <group name="fragA" position={[0, 1.6, 0]}>
            <mesh rotation={[0, 0, Math.PI / 2]}>
              <torusGeometry args={[1.9, 0.5, 12, 26, Math.PI * 1.15]} />
              <meshStandardMaterial color="#ded3ba" roughness={0.65} />
            </mesh>
            {[-1.35, -0.45, 0.45, 1.35].map((x, i) => (
              <mesh key={i} position={[x, 3.15, 0]}>
                <boxGeometry args={[0.75, 0.85, 0.75]} />
                <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
              </mesh>
            ))}
          </group>
          <mesh name="fxSym" position={[0, 1.62, 0]} rotation={[0, 0, 0.1]}>
            <boxGeometry args={[0.12, 1.1, 1.1]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" transparent opacity={0.45} />
          </mesh>
          <mesh name="fxAng" position={[-1.85, 2.05, 0]} rotation={[0, 0, 0.6]}>
            <boxGeometry args={[0.12, 1.1, 1.1]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" transparent opacity={0.45} />
          </mesh>
          <mesh name="fxCon" position={[-2.35, 3.1, 0]} rotation={[0, 0, 0.25]}>
            <boxGeometry args={[0.12, 0.9, 1]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" transparent opacity={0.45} />
          </mesh>
          <Label text="Symphysis (chin)" position={[1.9, 1.2, 0]} size={0.4} />
          <Label text="Angle" position={[-3.2, 2.1, 0]} size={0.4} />
          <Label text="Condyle" position={[-3.4, 3.4, 0]} size={0.4} />
          <Label text={"Fracture: " + site} position={[0, 4.3, 0]} size={0.46} color="#ef4444" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
