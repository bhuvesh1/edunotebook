"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "conc", label: "Chlorhexidine", kind: "slider", min: 0, max: 0.2, step: 0.02, default: 0.12, unit: "%" },
  { key: "time", label: "Rinse time", kind: "slider", min: 0, max: 60, step: 5, default: 30, unit: "s" },
];

export const UNIQUE_META = {
  title: "Antiseptics and mouthwashes: chlorhexidine",
  blurb: "Blue chlorhexidine rinse pours over germs on a tooth — bacteria burst and a protective blue film stays behind (substantivity).",
};

function RinseStream({ on }: { on: boolean }) {
  const pts = useRef<THREE.Points>(null!);
  const t = useRef(0);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(40 * 3), 3));
    return g;
  }, []);
  useFrame((_, delta) => {
    t.current += delta * 1.6;
    if (!pts.current) return;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < 40; i++) {
      const f = (t.current + i / 40) % 1;
      pos.setXYZ(i, -2.6 + Math.sin(i * 2.1) * 0.25, 3.4 - f * 3.6, 0.6 + Math.cos(i * 1.7) * 0.25);
    }
    pos.needsUpdate = true;
    pts.current.visible = on;
  });
  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial color="#38bdf8" size={0.16} transparent opacity={0.95} />
    </points>
  );
}

function Scene({ conc, time }: { conc: number; time: number }) {
  const t = useRef(0);
  const film = useRef<THREE.Mesh>(null!);
  const killPower = Math.min(1, (conc / 0.12) * (time / 30));
  const pouring = time > 0;

  const germs = useMemo(() => {
    const arr: { p: [number, number, number]; s: number; ph: number }[] = [];
    for (let i = 0; i < 30; i++) {
      arr.push({
        p: [(Math.random() - 0.5) * 3.4, 1.35 + Math.random() * 0.5, (Math.random() - 0.5) * 1.6],
        s: 0.7 + Math.random() * 0.6,
        ph: Math.random() * Math.PI * 2,
      });
    }
    return arr;
  }, []);

  useFrame((_, delta) => {
    t.current += delta;
    if (film.current) {
      const m = film.current.material as THREE.MeshStandardMaterial;
      m.opacity = Math.min(0.5, killPower * 0.5);
    }
  });

  const dead = Math.floor(germs.length * Math.min(1, killPower));

  return (
    <group>
      {/* tooth */}
      <group>
        <mesh position={[0, 0.55, 0]}>
          <cylinderGeometry args={[1.05, 1.3, 1.5, 20]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.25} />
        </mesh>
        <mesh position={[0, -0.9, 0]}>
          <coneGeometry args={[0.85, 1.5, 18]} />
          <meshStandardMaterial color="#e8dcc8" roughness={0.45} />
        </mesh>
      </group>
      {/* substantivity film */}
      <mesh ref={film} position={[0, 1.32, 0]}>
        <cylinderGeometry args={[1.08, 1.08, 0.1, 20]} />
        <meshStandardMaterial color="#0ea5e9" transparent opacity={0.4} roughness={0.2} emissive="#0ea5e9" emissiveIntensity={0.5} />
      </mesh>
      <Label text="Stays 8–12 hrs (substantivity)" position={[2.6, 1.35, 0]} size={0.42} color="#7dd3fc" />

      {/* germs */}
      {germs.map((g, i) => {
        const isDead = i < dead;
        return (
          <mesh key={i} position={g.p} scale={isDead ? g.s * 0.45 : g.s} rotation={[0, g.ph, 0]}>
            <sphereGeometry args={[0.17, 10, 10]} />
            <meshStandardMaterial color={isDead ? "#64748b" : "#4d7c0f"} roughness={0.6} />
          </mesh>
        );
      })}
      <Label text={dead >= germs.length ? "All germs killed ✓" : "Plaque germs"} position={[0, 2.5, 0]} size={0.5} color={dead >= germs.length ? "#86efac" : "#a3e635"} />

      {/* mouthwash bottle */}
      <group position={[-2.6, 3.4, 0.6]} rotation={[0, 0, 0.5]}>
        <mesh>
          <cylinderGeometry args={[0.55, 0.6, 1.6, 16]} />
          <meshStandardMaterial color="#0ea5e9" transparent opacity={0.75} roughness={0.2} />
        </mesh>
        <mesh position={[0, 0.55, 0]}>
          <cylinderGeometry args={[0.5, 0.5, 0.5, 16]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.3} />
        </mesh>
        <mesh position={[0, 1.0, 0]}>
          <cylinderGeometry args={[0.25, 0.25, 0.35, 12]} />
          <meshStandardMaterial color="#1e3a8a" roughness={0.4} />
        </mesh>
        <Label text="Chlorhexidine" position={[0, 1.6, 0]} size={0.42} color="#7dd3fc" />
      </group>
      <RinseStream on={pouring} />

      <Label text={`${(conc).toFixed(2)}% · rinse ${time}s`} position={[0, -2.4, 0]} size={0.5} color="#e2e8f0" />
      <Label text="Gold standard anti-plaque — brown staining with long use" position={[0, -3.1, 0]} size={0.4} color="#94a3b8" />
    </group>
  );
}

export function Topic10424Sim(props: SimProps) {
  const conc = Number(props.conc ?? 0.12);
  const time = Number(props.time ?? 30);
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Concentration", `${conc.toFixed(2)}%`], ["Rinse", `${time}s`], ["Effect", conc >= 0.1 && time >= 30 ? "Optimal kill" : "Sub-optimal"]]} />
      <SimCanvas cameraPosition={[0, 2, 9.5]} target={[0, 0.4, 0]}>
        <Scene conc={conc} time={time} />
      </SimCanvas>
    </div>
  );
}
