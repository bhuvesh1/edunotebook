// Obstetrics: medical disorders in pregnancy — diabetes, heart disease, anemia.
// The pregnant mother carries three possible burdens: sugar cubes flooding the
// blood (diabetes), a straining heart, or pale weak blood (anemia).

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "disorder", label: "Disorder", kind: "select", min: 0, max: 0, step: 1, default: "diabetes", options: ["healthy", "diabetes", "heart", "anemia"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Pregnancy + Medical Disorders",
  blurb: "Pregnancy with diabetes, heart disease, or anemia — see what changes inside the mother's body.",
};

function Animator({
  group, heart, sugar, rbcs, elapsed, speed, disorder,
}: {
  group: React.RefObject<THREE.Group>;
  heart: React.RefObject<THREE.Mesh>;
  sugar: React.RefObject<THREE.Group>;
  rbcs: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  disorder: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
    if (heart.current) {
      // heart disease: fast, weak, irregular thumps
      const sick = disorder === "heart";
      const rate = sick ? 6.5 : 4.2;
      const irr = sick ? 0.6 + 0.4 * Math.sin(t * 0.7) : 1;
      const beat = Math.pow(Math.max(0, Math.sin(t * rate)), 2) * irr;
      heart.current.scale.setScalar(1 + beat * (sick ? 0.04 : 0.09));
      (heart.current.material as THREE.MeshStandardMaterial).emissiveIntensity = sick ? 0.4 + 0.4 * Math.sin(t * 6.5) : 0.1;
    }
    if (sugar.current) {
      sugar.current.visible = disorder === "diabetes";
      sugar.current.children.forEach((s, i) => {
        const ph = ((t * 0.5 + i / sugar.current!.children.length) % 1);
        s.position.set(Math.sin(i * 2.7) * 0.9, 4.2 - ph * 3.4, Math.cos(i * 1.9) * 0.6);
        s.rotation.x = t * 2 + i; s.rotation.y = t * 1.5 + i;
      });
    }
    if (rbcs.current) {
      rbcs.current.children.forEach((c, i) => {
        const ph = ((t * 0.4 + i / rbcs.current!.children.length) % 1);
        c.position.set(-0.9 + Math.sin(i * 1.4) * 0.35, 3.6 - ph * 2.2, 0.3);
      });
      const pale = disorder === "anemia";
      rbcs.current.children.forEach((c) => {
        ((c as THREE.Mesh).material as THREE.MeshStandardMaterial).color.set(pale ? "#fca5a5" : "#dc2626");
      });
    }
  });
  return null;
}

export function Topic10282Sim(props: SimProps) {
  const disorder = String(props.disorder ?? "diabetes");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const heart = useRef<THREE.Mesh>(null!);
  const sugar = useRef<THREE.Group>(null!);
  const rbcs = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    healthy: "Healthy pregnancy", diabetes: "Gestational diabetes", heart: "Heart disease in pregnancy", anemia: "Anemia in pregnancy",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Disorder", names[disorder] ?? disorder], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.6, 10.5]} target={[0, 2.3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* mother torso */}
          <mesh position={[-0.9, 2.9, -0.5]} scale={[1.1, 1.7, 0.85]} castShadow>
            <sphereGeometry args={[1.0, 28, 20]} />
            <meshStandardMaterial color="#f5c396" roughness={0.6} transparent opacity={0.42} />
          </mesh>
          {/* heart in chest */}
          <mesh ref={heart} position={[-0.9, 3.7, 0.1]} scale={[1, 1.2, 0.9]} castShadow>
            <sphereGeometry args={[0.42, 20, 14]} />
            <meshStandardMaterial color="#b91c1c" roughness={0.45} emissive="#7f1d1d" emissiveIntensity={0.1} />
          </mesh>
          {/* uterus + baby */}
          <mesh position={[-0.9, 1.8, 0.1]} scale={[1.05, 1.2, 0.9]} castShadow>
            <sphereGeometry args={[0.85, 28, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.5} />
          </mesh>
          <mesh position={[-0.9, 1.8, 0.2]} castShadow>
            <sphereGeometry args={[0.32, 18, 14]} />
            <meshStandardMaterial color="#fde68a" roughness={0.6} />
          </mesh>
          {/* blood vessel with red cells */}
          <mesh position={[-0.9, 2.5, 0.3]} castShadow>
            <cylinderGeometry args={[0.3, 0.3, 2.6, 14, 1, true]} />
            <meshStandardMaterial color="#ef4444" roughness={0.4} transparent opacity={0.35} side={THREE.DoubleSide} />
          </mesh>
          <group ref={rbcs}>
            {Array.from({ length: 10 }).map((_, i) => (
              <mesh key={i} castShadow>
                <cylinderGeometry args={[0.12, 0.12, 0.05, 12]} />
                <meshStandardMaterial color="#dc2626" roughness={0.4} />
              </mesh>
            ))}
          </group>
          {/* sugar cubes floating in blood (diabetes) */}
          <group ref={sugar} visible={false}>
            {Array.from({ length: 14 }).map((_, i) => (
              <mesh key={i} castShadow>
                <boxGeometry args={[0.16, 0.16, 0.16]} />
                <meshStandardMaterial color="#fef3c7" roughness={0.3} emissive="#f59e0b" emissiveIntensity={0.4} />
              </mesh>
            ))}
          </group>
          {/* glucose meter */}
          {disorder === "diabetes" && (
            <group position={[2.6, 2.2, 0]}>
              <mesh castShadow>
                <boxGeometry args={[0.7, 1.1, 0.25]} />
                <meshStandardMaterial color="#1e293b" roughness={0.4} />
              </mesh>
              <mesh position={[0, 0.15, 0.14]}>
                <planeGeometry args={[0.5, 0.35]} />
                <meshBasicMaterial color="#ef4444" />
              </mesh>
            </group>
          )}
          <Label text="Mother's heart" position={[-2.4, 3.9, 0.1]} size={0.5} color="#fca5a5" />
          <Label text="Baby" position={[-0.9, 0.75, 0.2]} size={0.5} color="#fde68a" />
          {disorder === "diabetes" && <Label text="⚠ High blood sugar!" position={[2.6, 3.3, 0]} size={0.55} color="#fde68a" />}
          {disorder === "heart" && <Label text="⚠ Heart working too hard" position={[-0.9, 4.6, 0.1]} size={0.55} color="#fca5a5" />}
          {disorder === "anemia" && <Label text="⚠ Pale, weak blood" position={[0.9, 2.5, 0.3]} size={0.55} color="#fecdd3" />}
          {disorder === "healthy" && <Label text="All well ✓" position={[1.4, 2.9, 0]} size={0.55} color="#86efac" />}
        </group>
        <Animator group={group} heart={heart} sugar={sugar} rbcs={rbcs} elapsed={elapsed} speed={speed} disorder={disorder} />
      </SimCanvas>
    </div>
  );
}
