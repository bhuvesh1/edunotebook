"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "lobe", label: "Highlight lobe", kind: "select", min: 0, max: 0, step: 1, default: "frontal", options: ["frontal", "parietal", "temporal", "occipital"] },
  { key: "speed", label: "Rotation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 0.6, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Neuroanatomy: brain lobes, basal ganglia, thalamus, hypothalamus",
  blurb: "The four lobes of the cerebrum in color — pick one and it lights up: frontal thinks, occipital sees.",
};

const LOBES = [
  { key: "frontal", color: "#3b82f6", pos: [0, 0.5, 1.35] as [number, number, number], job: "thinking, planning" },
  { key: "parietal", color: "#22c55e", pos: [0, 1.45, 0.1] as [number, number, number], job: "touch, space" },
  { key: "temporal", color: "#eab308", pos: [-1.35, -0.15, 0.35] as [number, number, number], job: "hearing, memory" },
  { key: "occipital", color: "#ef4444", pos: [0, 0.35, -1.4] as [number, number, number], job: "vision" },
];

function Brain({ lobe, speed }: { lobe: string; speed: number }) {
  const g = useRef<THREE.Group>(null!);
  const mats = useRef<(THREE.MeshStandardMaterial | null)[]>([]);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d * speed;
    if (g.current) g.current.rotation.y = t.current * 0.6;
    mats.current.forEach((m, i) => {
      if (!m) return;
      m.emissiveIntensity = LOBES[i].key === lobe ? 0.9 + Math.sin(t.current * 3) * 0.3 : 0.08;
    });
  });
  return (
    <group ref={g} position={[0, 2.8, 0]}>
      {/* cerebrum base */}
      <mesh castShadow>
        <sphereGeometry args={[1.7, 28, 22]} />
        <meshStandardMaterial color="#f9a8d4" roughness={0.55} />
      </mesh>
      {/* lobe patches on the surface */}
      {LOBES.map((l, i) => (
        <mesh key={l.key} position={l.pos}>
          <sphereGeometry args={[0.85, 18, 16]} />
          <meshStandardMaterial
            ref={(m) => { mats.current[i] = m; }}
            color={l.color}
            roughness={0.5}
            emissive={l.color}
            emissiveIntensity={0.08}
          />
        </mesh>
      ))}
      {/* central sulcus groove */}
      <mesh position={[0, 1.1, 0.75]} rotation={[0.5, 0, 0]}>
        <torusGeometry args={[1.15, 0.06, 8, 24, Math.PI]} />
        <meshStandardMaterial color="#9d174d" roughness={0.6} />
      </mesh>
      {/* deep structures: thalamus + basal ganglia hint */}
      <mesh position={[0, -0.3, 0]}>
        <sphereGeometry args={[0.5, 14, 14]} />
        <meshStandardMaterial color="#f472b6" emissive="#be185d" emissiveIntensity={0.5} roughness={0.5} />
      </mesh>
    </group>
  );
}

export function Topic10011Sim(props: SimProps) {
  const lobe = String(props.lobe ?? "frontal");
  const speed = Number(props.speed ?? 0.6);
  const showLabels = String(props.detail ?? "on") === "on";
  const info = LOBES.find((l) => l.key === lobe);
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Lobe", lobe], ["Does", info?.job ?? ""], ["Hemispheres", "2"]]} />
      <SimCanvas cameraPosition={[0, 4, 11]} target={[0, 2.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Brain lobe={lobe} speed={speed} />
        {showLabels && (
          <>
            <Label text={"Frontal"} position={[-2.6, 4.4, 1.2]} color="#93c5fd" size={0.5} />
            <Label text={"Occipital"} position={[2.6, 3.6, -1.2]} color="#fca5a5" size={0.5} />
            <Label text={"Temporal"} position={[-3.2, 2.4, 0]} color="#fde047" size={0.5} />
            <Label text={"Parietal"} position={[2.4, 4.8, 0]} color="#86efac" size={0.5} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
