"use client";
// Interceptive Orthodontics — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Interceptive Orthodontics",
  blurb: "A baby tooth is lost early — a band-and-loop space maintainer holds the gap open for the permanent tooth.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const er: any = g("premolar");
    if (er) {
      const T = 9;
      const ph = (t % T) / T;
      er.position.y = ph < 0.7 ? 3.6 - (3.6 - 1.15) * (ph / 0.7) : 1.15;
      er.visible = true;
    }
    const loop: any = g("sloop");
    if (loop) (loop.material as any).emissiveIntensity = 0.25 + 0.2 * Math.sin(t * 2.5);
  });
  return null;
}

export function Topic10472Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Appliance", "Band & loop maintainer"],
          ["Job", "Holds space for premolar"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <mesh position={[-2.2, 1.2, 0]}>
            <boxGeometry args={[1.1, 1.6, 1]} />
            <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
          </mesh>
          <mesh position={[2.2, 1.2, 0]}>
            <boxGeometry args={[1.1, 1.6, 1]} />
            <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
          </mesh>
          <mesh position={[-2.2, 1.2, 0]}>
            <torusGeometry args={[0.68, 0.09, 10, 20]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
          </mesh>
          <group name="sloop">
            <Wire points={[[-2.2, 1.5, 0], [-1, 1.7, 0], [1, 1.7, 0], [2.2, 1.5, 0]]} color="#94a3b8" radius={0.05} />
          </group>
          <group name="premolar" position={[0, 3.6, 0]}>
            <Tooth scale={1.05} enamel="#fbf7ec" />
          </group>
          <Arrow from={[0, 4.8, 0]} to={[0, 3.9, 0]} color="#22c55e" />
          <GumSlab position={[0, 0.15, -0.3]} scale={1.2} />
          <Label text="Band on molar" position={[-2.2, 2.7, 0]} size={0.42} />
          <Label text="Loop holds the space" position={[0, 2.5, 0]} size={0.42} color="#94a3b8" />
          <Label text="Permanent tooth erupts into saved space" position={[0, 5.3, 0]} size={0.42} color="#22c55e" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
