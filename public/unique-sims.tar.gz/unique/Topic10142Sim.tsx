// Intestinal protozoa: a wobbling amoeba pushes out pseudopods to engulf food
// while teardrop Giardia with beating flagella swims through the intestine.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Intestinal protozoa",
  blurb: "A wobbling amoeba engulfs food with pseudopods while Giardia swims through the intestine.",
};

const N_GIARDIA = 4;

function Animator({ amoeba, pseudos, giardia, food, elapsed, speed, setTick }: {
  amoeba: React.RefObject<THREE.Mesh>;
  pseudos: React.RefObject<(THREE.Mesh | null)[]>;
  giardia: React.RefObject<(THREE.Group | null)[]>;
  food: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  speed: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (amoeba.current) {
      // amoeboid wobble
      amoeba.current.scale.set(
        1 + Math.sin(t * 1.8) * 0.14,
        1 + Math.sin(t * 2.6 + 1) * 0.18,
        1 + Math.cos(t * 1.4) * 0.14
      );
      amoeba.current.position.x = -2.6 + Math.sin(t * 0.4) * 0.4;
    }
    pseudos.current.forEach((p, i) => {
      if (!p) return;
      // pseudopods extend and retract in sequence
      const ext = 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(t * 1.6 + i * 2.1));
      const a = (i / 5) * Math.PI * 2 + 0.5;
      p.position.set(-2.6 + Math.cos(a) * (0.9 + ext * 0.5), 1.5 + Math.sin(a) * (0.7 + ext * 0.4), 0);
      p.scale.setScalar(0.5 + ext * 0.7);
      p.lookAt(-2.6, 1.5, 0);
    });
    giardia.current.forEach((g, i) => {
      if (!g) return;
      const a = t * 0.8 + i * (Math.PI * 2 / N_GIARDIA);
      g.position.set(2.8 + Math.cos(a) * 1.5, 1.6 + Math.sin(a * 1.3) * 0.5, Math.sin(a) * 1.1);
      g.rotation.y = -a;
      g.rotation.z = Math.sin(t * 6 + i) * 0.2; // flagellar wiggle
    });
    food.current.forEach((f, i) => {
      if (!f) return;
      // food particles drift toward the amoeba and get engulfed
      const cyc = (t * 0.25 + i / 6) % 1;
      f.position.set(-5.2 + cyc * 2.8, 1.5 + Math.sin(i * 2.4) * 0.5, Math.cos(i * 1.8) * 0.5);
      const near = cyc > 0.85;
      f.visible = !near || (t * 4 + i) % 1 > 0.5;
      if (near) f.scale.setScalar(Math.max(0.05, 1 - (cyc - 0.85) * 6));
      else f.scale.setScalar(1);
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(t * 10)); }
  });
  return null;
}

export function Topic10142Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const amoeba = useRef<THREE.Mesh>(null!);
  const pseudos = useRef<(THREE.Mesh | null)[]>([]);
  const giardia = useRef<(THREE.Group | null)[]>([]);
  const food = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Entamoeba", "pseudopods — engulfs food"],
          ["Giardia", "teardrop + flagella"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* intestine tube */}
        <mesh position={[0, 1.4, -1.4]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[1.7, 1.7, 11, 20, 1, true]} />
          <meshStandardMaterial color="#d4a373" transparent opacity={0.35} side={THREE.DoubleSide} roughness={0.7} />
        </mesh>
        {showLabels && <Label text="intestine" position={[0, 3.6, -1.4]} size={0.45} color="#e8b48c" />}

        {/* amoeba body */}
        <mesh ref={amoeba} position={[-2.6, 1.5, 0]} castShadow>
          <sphereGeometry args={[0.95, 22, 16]} />
          <meshStandardMaterial color="#a7f3d0" transparent opacity={0.9} roughness={0.35} />
        </mesh>
        {/* nucleus */}
        <mesh position={[-2.6, 1.5, 0]}>
          <sphereGeometry args={[0.28, 14, 10]} />
          <meshStandardMaterial color="#047857" roughness={0.4} />
        </mesh>
        {/* pseudopods */}
        {Array.from({ length: 5 }).map((_, i) => (
          <mesh key={i} ref={(m) => { pseudos.current[i] = m; }}>
            <coneGeometry args={[0.3, 0.9, 10]} />
            <meshStandardMaterial color="#a7f3d0" transparent opacity={0.85} roughness={0.4} />
          </mesh>
        ))}
        {showLabels && <Label text="Entamoeba — pseudopods" position={[-2.6, 3.2, 0]} color="#6ee7b7" />}

        {/* food particles */}
        {Array.from({ length: 6 }).map((_, i) => (
          <mesh key={`f${i}`} ref={(m) => { food.current[i] = m; }}>
            <sphereGeometry args={[0.1, 8, 8]} />
            <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.6} />
          </mesh>
        ))}

        {/* Giardia: teardrop bodies with flagella */}
        {Array.from({ length: N_GIARDIA }).map((_, i) => (
          <group key={`g${i}`} ref={(g) => { giardia.current[i] = g; }}>
            <mesh scale={[1, 1.35, 0.7]} castShadow>
              <sphereGeometry args={[0.34, 16, 12]} />
              <meshStandardMaterial color="#7dd3fc" roughness={0.45} />
            </mesh>
            {/* face: two nuclei eyes */}
            {[-0.13, 0.13].map((x, e) => (
              <mesh key={e} position={[x, 0.12, 0.26]}>
                <sphereGeometry args={[0.07, 8, 8]} />
                <meshStandardMaterial color="#0c4a6e" />
              </mesh>
            ))}
            {/* flagella */}
            {[-0.5, -0.25, 0.25, 0.5].map((x, f2) => (
              <mesh key={f2} position={[x * 0.5, -0.55, 0]} rotation={[0, 0, x * 0.6]}>
                <cylinderGeometry args={[0.025, 0.01, 0.7, 6]} />
                <meshStandardMaterial color="#bae6fd" />
              </mesh>
            ))}
          </group>
        ))}
        {showLabels && <Label text="Giardia — 'smiley face' parasite" position={[2.8, 2.9, 0]} size={0.45} color="#7dd3fc" />}

        <Animator amoeba={amoeba} pseudos={pseudos} giardia={giardia} food={food} elapsed={elapsed} speed={speed} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
