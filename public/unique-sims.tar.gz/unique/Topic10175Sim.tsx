"use client";
// Maternal and child health: antenatal care, IMNCI.
// A mother and baby figure beside a pregnancy check-up calendar —
// visit dots pulse as each antenatal milestone arrives.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "visit", label: "Care visit", kind: "select", min: 0, max: 0, step: 1, default: "anc1", options: ["anc1", "anc2", "anc3", "anc4", "delivery", "pnc"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Maternal & Child Health: Antenatal Care",
  blurb: "Mother and baby at the clinic: four antenatal check-ups, safe delivery, then postnatal care — every visit matters.",
};

const VISITS = [
  { key: "anc1", name: "ANC 1", desc: "1st check-up: register, tetanus shot", x: -4.6 },
  { key: "anc2", name: "ANC 2", desc: "2nd check-up: growth scan", x: -2.75 },
  { key: "anc3", name: "ANC 3", desc: "3rd check-up: iron tablets", x: -0.9 },
  { key: "anc4", name: "ANC 4", desc: "4th check-up: birth plan", x: 0.95 },
  { key: "delivery", name: "DELIVERY", desc: "Safe delivery at hospital", x: 2.8 },
  { key: "pnc", name: "PNC", desc: "Postnatal: baby vaccines (IMNCI)", x: 4.65 },
];

function Animator({ dots, heart, elapsed, speed }: { dots: React.RefObject<THREE.Group>; heart: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (dots.current) {
      dots.current.children.forEach((d, i) => {
        const s = 1 + Math.sin(elapsed.current * 2.5 + i * 1.1) * 0.22;
        d.scale.set(s, s, s);
      });
    }
    if (heart.current) {
      const b = 1 + Math.pow(Math.max(0, Math.sin(elapsed.current * 4.4)), 4) * 0.18;
      heart.current.scale.set(b, b, b);
    }
  });
  return null;
}

export function Topic10175Sim(props: SimProps) {
  const visit = String(props.visit ?? "anc1");
  const speed = Number(props.speed ?? 1);
  const dots = useRef<THREE.Group>(null!);
  const heart = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const activeIdx = Math.max(0, VISITS.findIndex((v) => v.key === visit));
  const active = VISITS[activeIdx];

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Visit", active.name], ["Happens", active.desc]]} />
      <SimCanvas cameraPosition={[0, 3.8, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* mother figure */}
        <group position={[-4.8, 0, -2.4]}>
          <mesh position={[0, 1, 0]} castShadow>
            <capsuleGeometry args={[0.5, 1.1, 6, 14]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.7} />
          </mesh>
          <mesh position={[0, 2.3, 0]} castShadow>
            <sphereGeometry args={[0.4, 18, 18]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
          {/* baby bump */}
          <mesh position={[0, 1.15, 0.5]}>
            <sphereGeometry args={[0.42, 14, 14]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.7} />
          </mesh>
          <Label text="MOTHER" position={[0, 3.2, 0]} size={0.55} color="#f9a8d4" />
        </group>
        {/* baby figure */}
        <group position={[-2.9, 0, -2.4]}>
          <mesh position={[0, 0.55, 0]} castShadow>
            <capsuleGeometry args={[0.32, 0.5, 6, 12]} />
            <meshStandardMaterial color="#bae6fd" roughness={0.7} />
          </mesh>
          <mesh position={[0, 1.35, 0]} castShadow>
            <sphereGeometry args={[0.32, 16, 16]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
          <mesh ref={heart} position={[0, 0.75, 0.35]}>
            <sphereGeometry args={[0.14, 10, 10]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.8} />
          </mesh>
          <Label text="BABY" position={[0, 2.1, 0]} size={0.55} color="#7dd3fc" />
        </group>
        {/* clinic */}
        <group position={[3.4, 0, -2.6]}>
          <mesh position={[0, 1.4, 0]} castShadow>
            <boxGeometry args={[3.4, 2.8, 2.6]} />
            <meshStandardMaterial color="#e0f2fe" roughness={0.8} />
          </mesh>
          <mesh position={[0, 3.3, 0]} castShadow>
            <coneGeometry args={[2.6, 1.2, 4]} />
            <meshStandardMaterial color="#ef4444" roughness={0.7} />
          </mesh>
          <mesh position={[0, 1.9, 0]}>
            <boxGeometry args={[1.2, 1.2, 0.1]} />
            <meshStandardMaterial color="#ffffff" emissive="#ef4444" emissiveIntensity={0.35} />
          </mesh>
          <mesh position={[0, 1.9, 0.06]}>
            <boxGeometry args={[0.7, 0.22, 0.04]} />
            <meshStandardMaterial color="#ef4444" roughness={0.6} />
          </mesh>
          <mesh position={[0, 1.9, 0.06]}>
            <boxGeometry args={[0.22, 0.7, 0.04]} />
            <meshStandardMaterial color="#ef4444" roughness={0.6} />
          </mesh>
          <Label text="CLINIC" position={[0, 4.4, 0]} size={0.6} color="#f87171" />
        </group>
        {/* visit timeline */}
        <mesh position={[0, 0.12, 2.6]}>
          <boxGeometry args={[11.4, 0.14, 0.4]} />
          <meshStandardMaterial color="#334155" roughness={0.8} />
        </mesh>
        <group ref={dots}>
          {VISITS.map((v, i) => (
            <group key={v.key} position={[v.x, 0.55, 2.6]}>
              <mesh castShadow>
                <sphereGeometry args={[0.32, 14, 14]} />
                <meshStandardMaterial color={i <= activeIdx ? "#f472b6" : "#475569"} emissive={i <= activeIdx ? "#ec4899" : "#000000"} emissiveIntensity={i <= activeIdx ? 0.7 : 0} />
              </mesh>
              <Label text={v.name} position={[0, -0.75, 0]} size={0.45} color={i === activeIdx ? "#f9a8d4" : "#94a3b8"} />
            </group>
          ))}
        </group>
        <Animator dots={dots} heart={heart} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
