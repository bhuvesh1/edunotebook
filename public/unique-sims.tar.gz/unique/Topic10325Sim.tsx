// Acne, rosacea, pigmentary disorders — vitiligo, melasma.
// A face with its stories: clogged pores erupting into pimples, rosacea's
// butterfly flush, vitiligo's pale patches where color vanished, and melasma's
// brown mask.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "acne", options: ["acne", "rosacea", "vitiligo", "melasma"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Face: Acne, Rosacea, Vitiligo",
  blurb: "Pimples erupting from clogged pores, rosacea's red flush, vitiligo's pale patches, melasma's brown mask.",
};

function Animator({
  group, pimples, flush, elapsed, speed, condition,
}: {
  group: React.RefObject<THREE.Group>;
  pimples: React.RefObject<THREE.Group>;
  flush: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // pimples grow, pop, and reform
    if (pimples.current && condition === "acne") {
      pimples.current.children.forEach((p, i) => {
        const cyc = ((t * 0.35 + i * 0.23) % 1);
        const s = cyc < 0.5 ? 0.4 + cyc * 1.2 : cyc < 0.6 ? 1.0 - (cyc - 0.5) * 8 : 0.35;
        (p as THREE.Mesh).scale.setScalar(Math.max(0.3, s));
      });
    }
    // rosacea flush throbs with triggers
    if (flush.current && condition === "rosacea") {
      const throb = 0.5 + 0.5 * Math.sin(t * 2.2);
      (flush.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.3 + throb * 0.5;
      flush.current.scale.set(1 + throb * 0.05, 1 + throb * 0.05, 1);
    }
  });
  return null;
}

export function Topic10325Sim(props: SimProps) {
  const condition = String(props.condition ?? "acne");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const pimples = useRef<THREE.Group>(null!);
  const flush = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    acne: "Acne vulgaris", rosacea: "Rosacea", vitiligo: "Vitiligo", melasma: "Melasma",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 9.5]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* face: rounded head */}
          <mesh position={[0, 2.3, 0]} scale={[0.95, 1.15, 0.9]} castShadow>
            <sphereGeometry args={[1.35, 32, 24]} />
            <meshStandardMaterial color="#f5c396" roughness={0.6} />
          </mesh>
          {/* simple eyes + mouth for a face kids recognize */}
          {[-0.5, 0.5].map((x, i) => (
            <mesh key={i} position={[x, 2.7, 1.15]} castShadow>
              <sphereGeometry args={[0.14, 12, 10]} />
              <meshStandardMaterial color="#1c1917" roughness={0.4} />
            </mesh>
          ))}
          <mesh position={[0, 1.75, 1.18]} rotation={[0, 0, 0]} castShadow>
            <torusGeometry args={[0.28, 0.06, 8, 18, Math.PI]} />
            <meshStandardMaterial color="#92400e" roughness={0.5} />
          </mesh>

          {/* ACNE: pimples with whiteheads */}
          <group ref={pimples} visible={condition === "acne"}>
            {[[-0.7, 3.2], [0.6, 3.0], [-0.2, 2.3], [0.8, 2.2], [-0.9, 2.5], [0.2, 3.4]].map(([x, y], i) => (
              <group key={i} position={[x, y, 1.18]}>
                <mesh castShadow>
                  <sphereGeometry args={[0.14, 12, 10]} />
                  <meshStandardMaterial color="#dc2626" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.4} />
                </mesh>
                <mesh position={[0, 0.1, 0.08]}>
                  <sphereGeometry args={[0.06, 8, 6]} />
                  <meshStandardMaterial color="#fefce8" roughness={0.4} />
                </mesh>
              </group>
            ))}
          </group>

          {/* ROSACEA: butterfly flush across cheeks + nose */}
          {condition === "rosacea" && (
            <mesh ref={flush} position={[0, 2.35, 1.05]} scale={[1.15, 0.75, 0.4]} castShadow>
              <sphereGeometry args={[0.85, 20, 14]} />
              <meshStandardMaterial color="#f87171" roughness={0.6} transparent opacity={0.75} emissive="#b91c1c" emissiveIntensity={0.5} />
            </mesh>
          )}

          {/* VITILIGO: pale depigmented patches */}
          {condition === "vitiligo" && (
            <>
              {[[-0.75, 2.9, 0.5], [0.7, 2.4, 0.55], [-0.1, 1.9, 0.5], [0.9, 3.1, 0.35]].map(([x, y, r], i) => (
                <mesh key={i} position={[x, y, 1.02]} scale={[r, r * 0.8, 0.25]} castShadow>
                  <sphereGeometry args={[0.55, 16, 12]} />
                  <meshStandardMaterial color="#fef3c7" roughness={0.7} />
                </mesh>
              ))}
            </>
          )}

          {/* MELASMA: brown mask across cheeks/forehead */}
          {condition === "melasma" && (
            <mesh position={[0, 2.75, 1.08]} scale={[1.25, 0.55, 0.35]} castShadow>
              <sphereGeometry args={[0.95, 20, 14]} />
              <meshStandardMaterial color="#92400e" roughness={0.7} transparent opacity={0.65} />
            </mesh>
          )}

          <Label text={names[condition]} position={[0, 0.45, 0.6]} size={0.6} color="#fde68a" />
          {condition === "acne" && <Label text="Clogged pore → pimple" position={[-2.5, 3.0, 0.8]} size={0.5} color="#fca5a5" />}
          {condition === "rosacea" && <Label text="🦋 Butterfly flush — spicy food, sun, stress" position={[2.4, 3.2, 0.6]} size={0.5} color="#fca5a5" />}
          {condition === "vitiligo" && <Label text="Color-making cells lost their color" position={[2.5, 2.2, 0.6]} size={0.5} color="#fef3c7" />}
          {condition === "melasma" && <Label text="Hormones + sun → brown mask" position={[2.5, 2.6, 0.6]} size={0.5} color="#d6a05c" />}
        </group>
        <Animator group={group} pimples={pimples} flush={flush} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
