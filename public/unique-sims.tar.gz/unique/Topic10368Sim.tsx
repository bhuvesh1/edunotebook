"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "tooth", label: "Tooth type", kind: "select", min: 0, max: 0, step: 1, default: "molar", options: ["incisor", "canine", "premolar", "molar"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Tooth morphology: permanent dentition",
  blurb: "The four tooth families side by side — flat incisors for cutting, pointed canines for tearing, premolars and molars for grinding.",
};

const ENAMEL = "#fef9c3";
const GUM = "#e88ca0";

// Crown shapes per family
function Crown({ kind }: { kind: string }) {
  const mat = <meshStandardMaterial color={ENAMEL} roughness={0.25} />;
  if (kind === "incisor") {
    // flat shovel edge
    return (
      <mesh castShadow>
        <boxGeometry args={[1.1, 1.3, 0.55]} />
        {mat}
      </mesh>
    );
  }
  if (kind === "canine") {
    // single sharp cusp
    return (
      <group>
        <mesh position={[0, -0.35, 0]} castShadow>
          <boxGeometry args={[0.95, 0.7, 0.6]} />
          {mat}
        </mesh>
        <mesh position={[0, 0.35, 0]} castShadow>
          <coneGeometry args={[0.48, 0.9, 4]} />
          {mat}
        </mesh>
      </group>
    );
  }
  if (kind === "premolar") {
    // two cusps
    return (
      <group>
        <mesh position={[0, -0.35, 0]} castShadow>
          <boxGeometry args={[1, 0.7, 0.85]} />
          {mat}
        </mesh>
        {[-0.28, 0.28].map((x, i) => (
          <mesh key={i} position={[x, 0.3, 0]} castShadow>
            <coneGeometry args={[0.32, 0.7, 4]} />
            {mat}
          </mesh>
        ))}
      </group>
    );
  }
  // molar: 4 cusps
  return (
    <group>
      <mesh position={[0, -0.3, 0]} castShadow>
        <boxGeometry args={[1.35, 0.75, 1.25]} />
        {mat}
      </mesh>
      {[[-0.36, -0.33], [0.36, -0.33], [-0.36, 0.33], [0.36, 0.33]].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.32, z]} castShadow>
          <coneGeometry args={[0.3, 0.6, 4]} />
          {mat}
        </mesh>
      ))}
    </group>
  );
}

function Tooth({ kind, position, active, speed, showLabels, caption }: {
  kind: string; position: [number, number, number]; active: boolean; speed: number; showLabels: boolean; caption: string;
}) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const roots = kind === "incisor" || kind === "canine" ? 1 : kind === "premolar" ? 2 : 3;
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) {
      const s = THREE.MathUtils.lerp(g.current.scale.x, active ? 1.5 : 1, 0.08);
      g.current.scale.setScalar(s);
      g.current.position.y = position[1] + Math.sin(elapsed.current * 1.6 + position[0]) * 0.08;
    }
  });
  return (
    <group position={position}>
      <group ref={g}>
        <Crown kind={kind} />
        {/* roots */}
        {Array.from({ length: roots }).map((_, i) => (
          <mesh key={i} position={[(i - (roots - 1) / 2) * 0.45, -1.55, 0]} castShadow>
            <coneGeometry args={[0.2, 1.5, 10]} />
            <meshStandardMaterial color="#fde68a" roughness={0.4} />
          </mesh>
        ))}
      </group>
      {active && (
        <mesh position={[0, -1.1, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[1.5, 1.68, 36]} />
          <meshBasicMaterial color="#facc15" transparent opacity={0.9} side={THREE.DoubleSide} />
        </mesh>
      )}
      {showLabels && (
        <Text position={[0, 2.4, 0]} fontSize={0.44} color={active ? "#facc15" : "#e2e8f0"}>{caption}</Text>
      )}
    </group>
  );
}

const TEETH = [
  { kind: "incisor", caption: "Incisor — cuts", fn: "Cutting" },
  { kind: "canine", caption: "Canine — tears", fn: "Tearing" },
  { kind: "premolar", caption: "Premolar — crushes", fn: "Crushing" },
  { kind: "molar", caption: "Molar — grinds", fn: "Grinding" },
];

export function Topic10368Sim(props: SimProps) {
  const tooth = String(props.tooth ?? "molar");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const sel = TEETH.find((t) => t.kind === tooth) ?? TEETH[3];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Family", sel.caption.split(" — ")[0]],
          ["Job", sel.fn],
          ["Adult teeth", "32 total"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 13]} target={[0, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.2, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* gum arch */}
        <mesh position={[0, -1.7, 0]} scale={[1.4, 0.55, 1]} castShadow>
          <torusGeometry args={[4.6, 1.5, 16, 48, Math.PI]} />
          <meshStandardMaterial color={GUM} roughness={0.6} />
        </mesh>
        {TEETH.map((t, i) => (
          <Tooth
            key={t.kind}
            kind={t.kind}
            position={[-6 + i * 4, 0.3, 0.8]}
            active={tooth === t.kind}
            speed={speed}
            showLabels={showLabels}
            caption={t.caption}
          />
        ))}
      </SimCanvas>
    </div>
  );
}
