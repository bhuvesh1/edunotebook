// app/components/sims/unique/Topic10576Sim.tsx
// Prosthetic rehabilitation over implants: a full lower arch with four
// implants; the bridge prosthesis descends and seats onto the abutments.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "seat", label: "Bridge seating", kind: "slider", min: 0, max: 100, step: 1, default: 100, unit: "%" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Prosthetic Rehabilitation over Implants",
  blurb: "Four implants anchor a full-arch bridge — slide it down and watch it lock onto the abutments.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ bridge, elapsed, speed, seat }: {
  bridge: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; seat: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (bridge.current) {
      const s = seat / 100;
      bridge.current.position.y = (1 - s) * 3.2 + 0.04 * Math.sin(elapsed.current * 2);
    }
  });
  return null;
}

const IMPLANT_X = [-2.1, -0.7, 0.7, 2.1];

export function Topic10576Sim(props: SimProps) {
  const seat = Number(props.seat ?? 100);
  const speed = Number(props.speed ?? 1);
  const bridge = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Implants", "4 (All-on-4 concept)"],
          ["Prosthesis", seat >= 99 ? "seated ✓" : "unseated"],
          ["Retention", "screw-retained bridge"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* edentulous ridge (gum) */}
        <mesh position={[0, 1.5, 0]} castShadow>
          <boxGeometry args={[7.5, 1, 2.2]} />
          <meshStandardMaterial color="#f472b6" roughness={0.6} />
        </mesh>
        {/* bone under it */}
        <mesh position={[0, 0.7, 0]} castShadow>
          <boxGeometry args={[7.5, 0.8, 2]} />
          <meshStandardMaterial color="#d9b98a" roughness={0.85} />
        </mesh>

        {/* four implants with abutments */}
        {IMPLANT_X.map((x, i) => (
          <group key={i} position={[x, 0, 0]}>
            <mesh position={[0, 1.15, 0]} castShadow>
              <cylinderGeometry args={[0.26, 0.2, 1.4, 14]} />
              <meshStandardMaterial color="#9ca3af" metalness={0.85} roughness={0.3} />
            </mesh>
            <mesh position={[0, 2.1, 0]} castShadow>
              <cylinderGeometry args={[0.16, 0.22, 0.5, 12]} />
              <meshStandardMaterial color="#e5e7eb" metalness={0.9} roughness={0.25} />
            </mesh>
            {/* seating guide beam when unseated */}
            {seat < 99 && (
              <mesh position={[0, 3.4, 0]}>
                <cylinderGeometry args={[0.04, 0.04, 2.6, 8]} />
                <meshStandardMaterial color="#fbbf24" transparent opacity={0.6} emissive="#f59e0b" emissiveIntensity={0.6} />
              </mesh>
            )}
          </group>
        ))}

        {/* full-arch bridge: pink base + 10 teeth */}
        <group ref={bridge} position={[0, 2.35, 0]}>
          <mesh castShadow>
            <boxGeometry args={[6.6, 0.5, 1.7]} />
            <meshStandardMaterial color="#fb7185" roughness={0.5} />
          </mesh>
          {[...Array(10)].map((_, i) => {
            const x = -2.7 + i * 0.6;
            return (
              <mesh key={i} position={[x, 0.62, 0]} castShadow>
                <boxGeometry args={[0.5, 0.75, 0.9]} />
                <meshStandardMaterial color="#ffffff" roughness={0.25} />
              </mesh>
            );
          })}
        </group>

        <Label p={[-3.6, 0.7, 0]} size={0.3} color="#fde68a">bone</Label>
        <Label p={[3.9, 1.5, 0]} size={0.3} color="#f9a8d4">ridge</Label>
        <Label p={[0, 5.6, 0]} size={0.32} color="#ffffff">screw-retained full-arch bridge</Label>
        <Label p={[-3.4, 2.1, 0]} size={0.28} color="#d1d5db">abutments</Label>

        <Animator bridge={bridge} elapsed={elapsed} speed={speed} seat={seat} />
      </SimCanvas>
    </div>
  );
}
