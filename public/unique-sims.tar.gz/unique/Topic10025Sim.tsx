// Embryology: development of heart and vascular system — the primitive heart
// tube loops (atrium, ventricle, bulbus cordis) and beats; vessels sprout as
// paired dorsal aortae.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "hr", label: "Embryonic heart rate", kind: "slider", min: 20, max: 180, step: 5, default: 140, unit: "bpm" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Embryology: Heart Tube Looping",
  blurb: "The straight heart tube loops into atrium, ventricle and bulbus cordis — and starts beating at ~140 bpm.",
};

function Animator({
  heart, chambers, elapsed, hr, speed,
}: {
  heart: React.RefObject<THREE.Group>;
  chambers: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  hr: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const beat = Math.pow(Math.max(0, Math.sin(t * (hr / 60) * Math.PI * 2)), 3);
    if (heart.current) {
      const s = 1 + 0.16 * beat;
      heart.current.scale.set(s, 1 - 0.1 * beat, s);
    }
    if (chambers.current) {
      chambers.current.children.forEach((m, i) => {
        const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = beat * (i === 1 ? 0.9 : 0.45);
      });
    }
  });
  return null;
}

export function Topic10025Sim(props: SimProps) {
  const hr = Number(props.hr ?? 140);
  const speed = Number(props.speed ?? 1);
  const heart = useRef<THREE.Group>(null!);
  const chambers = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const heartCurve = useMemo(() => {
    // C-loop of the heart tube: sinus venosus -> atrium -> ventricle -> bulbus -> truncus
    const pts = [
      new THREE.Vector3(-2.6, 1.6, 0),
      new THREE.Vector3(-1.4, 2.6, 0.4),
      new THREE.Vector3(-0.2, 2.2, 0.7),
      new THREE.Vector3(0.9, 1.3, 0.3),
      new THREE.Vector3(1.6, 2.3, -0.4),
      new THREE.Vector3(2.8, 3.2, -0.2),
    ];
    return new THREE.CatmullRomCurve3(pts);
  }, []);
  const heartTube = useMemo(
    () =>
      new THREE.Mesh(
        new THREE.TubeGeometry(heartCurve, 60, 0.55, 14, false),
        new THREE.MeshStandardMaterial({ color: "#f43f5e", roughness: 0.4 })
      ),
    [heartCurve]
  );
  const aortaCurve = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 20; i++) {
      const x = -4 + (i / 20) * 8;
      pts.push(new THREE.Vector3(x, 4.6 + Math.sin((i / 20) * Math.PI) * 0.3, -1.6));
    }
    return new THREE.CatmullRomCurve3(pts);
  }, []);
  const aorta = useMemo(
    () =>
      new THREE.Mesh(
        new THREE.TubeGeometry(aortaCurve, 40, 0.16, 10, false),
        new THREE.MeshStandardMaterial({ color: "#ef4444", roughness: 0.4 })
      ),
    [aortaCurve]
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Heart rate", `${hr} bpm`],
          ["Stage", "day 22–28: looping"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 13]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={heart}>
          <primitive object={heartTube} />
          {/* chamber markers that glow with the beat */}
          <group ref={chambers}>
            <mesh position={[-1.4, 2.6, 0.4]}>
              <sphereGeometry args={[0.5, 16, 16]} />
              <meshStandardMaterial color="#fb7185" emissive="#9f1239" emissiveIntensity={0.4} roughness={0.4} />
            </mesh>
            <mesh position={[0.9, 1.3, 0.3]}>
              <sphereGeometry args={[0.62, 16, 16]} />
              <meshStandardMaterial color="#e11d48" emissive="#881337" emissiveIntensity={0.4} roughness={0.4} />
            </mesh>
            <mesh position={[1.6, 2.3, -0.4]}>
              <sphereGeometry args={[0.42, 16, 16]} />
              <meshStandardMaterial color="#fda4af" emissive="#9f1239" emissiveIntensity={0.4} roughness={0.4} />
            </mesh>
          </group>
        </group>

        {/* paired dorsal aortae */}
        <primitive object={aorta} />
        <mesh position={[0, 4.6, -2.6]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.16, 0.16, 8, 10]} />
          <meshStandardMaterial color="#ef4444" roughness={0.4} />
        </mesh>
        {/* vitelline/umbilical vein hints */}
        <mesh position={[-3.4, 1.2, 1.4]} rotation={[0.4, 0, 1.1]}>
          <cylinderGeometry args={[0.14, 0.14, 3.4, 10]} />
          <meshStandardMaterial color="#3b82f6" roughness={0.4} />
        </mesh>

        <Label text="primitive atrium" position={[-1.4, 3.7, 0.4]} size={0.34} color="#fda4af" />
        <Label text="primitive ventricle" position={[0.9, 0.35, 0.3]} size={0.34} color="#fda4af" />
        <Label text="bulbus cordis" position={[2.9, 3.0, -0.4]} size={0.34} color="#fda4af" />
        <Label text="truncus arteriosus" position={[3.9, 3.9, -0.2]} size={0.3} color="#fca5a5" />
        <Label text="dorsal aortae (paired)" position={[0, 5.6, -2]} size={0.32} color="#fca5a5" />
        <Label text="C-loop of the heart tube" position={[-3.6, 4.6, 0]} size={0.38} color="#f8fafc" />

        <Animator heart={heart} chambers={chambers} elapsed={elapsed} hr={hr} speed={speed} />
      </SimCanvas>
    </div>
  );
}
