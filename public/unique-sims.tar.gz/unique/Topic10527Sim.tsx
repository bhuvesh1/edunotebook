// app/components/sims/unique/Topic10527Sim.tsx
// Advanced imaging: CT, CBCT, MRI in dentistry. A scanner gantry ring
// rotates around the patient's head while slice planes sweep through,
// building the 3D volume.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "mod", label: "Modality", kind: "select", min: 0, max: 0, step: 1, default: "cbct", options: ["ct", "cbct", "mri"] },
  { key: "speed", label: "Rotation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Advanced Imaging: CT, CBCT, MRI",
  blurb: "The gantry spins around the head, sweeping slice planes that stack into a 3D dental volume.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ gantry, slice, elapsed, speed }: {
  gantry: RefObject<THREE.Group>; slice: RefObject<THREE.Mesh>;
  elapsed: RefObject<number>; speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (gantry.current) gantry.current.rotation.z = t * 1.8;
    if (slice.current) {
      // slice plane sweeps through the head
      slice.current.position.y = 2.2 + 1.4 * Math.sin(t * 0.9);
      const mat = slice.current.material as THREE.MeshStandardMaterial;
      mat.opacity = 0.25 + 0.15 * Math.sin(t * 3);
    }
  });
  return null;
}

const INFO: Record<string, { use: string; dose: string; color: string }> = {
  ct: { use: "trauma, pathology, large FOV", dose: "higher dose", color: "#38bdf8" },
  cbct: { use: "implants, endo, ortho — dental 3D", dose: "low dose, high detail", color: "#4ade80" },
  mri: { use: "soft tissue, TMJ disc, tumors", dose: "no radiation (magnets)", color: "#c084fc" },
};

export function Topic10527Sim(props: SimProps) {
  const mod = String(props.mod ?? "cbct");
  const speed = Number(props.speed ?? 1);
  const gantry = useRef<THREE.Group>(null!);
  const slice = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const info = INFO[mod] ?? INFO.cbct;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Modality", mod.toUpperCase()],
          ["Best for", info.use],
          ["Dose", info.dose],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 13]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* patient table + head */}
        <mesh position={[0, 0.6, 0]} castShadow>
          <boxGeometry args={[3.2, 0.35, 7]} />
          <meshStandardMaterial color="#334155" roughness={0.6} />
        </mesh>
        <mesh position={[0, 1.6, 1.4]} castShadow>
          <capsuleGeometry args={[0.75, 2.6, 8, 16]} />
          <meshStandardMaterial color="#1e40af" roughness={0.6} />
        </mesh>
        <mesh position={[0, 2.2, 1.4]} castShadow>
          <sphereGeometry args={[0.95, 28, 28]} />
          <meshStandardMaterial color="#f0b98d" roughness={0.7} />
        </mesh>
        {/* skull inside */}
        <mesh position={[0, 2.2, 1.4]}>
          <sphereGeometry args={[0.7, 24, 24]} />
          <meshStandardMaterial color="#e8dcc3" transparent opacity={0.85} roughness={0.6} />
        </mesh>

        {/* gantry ring around the head */}
        <group position={[0, 2.2, 1.4]}>
          <mesh castShadow>
            <torusGeometry args={[2.1, 0.35, 14, 40]} />
            <meshStandardMaterial color="#64748b" metalness={0.6} roughness={0.4} />
          </mesh>
          <group ref={gantry}>
            {/* X-ray source */}
            <mesh position={[0, 2.1, 0]} castShadow>
              <boxGeometry args={[0.7, 0.7, 0.7]} />
              <meshStandardMaterial color={info.color} emissive={info.color} emissiveIntensity={1.2} />
            </mesh>
            {/* detector opposite */}
            <mesh position={[0, -2.1, 0]}>
              <boxGeometry args={[1.1, 0.3, 0.6]} />
              <meshStandardMaterial color="#1e293b" roughness={0.5} />
            </mesh>
            {/* beam fan */}
            <mesh position={[0, 1.05, 0]}>
              <coneGeometry args={[1.1, 2.1, 4, 1, true]} />
              <meshStandardMaterial color={info.color} transparent opacity={0.18} side={THREE.DoubleSide} emissive={info.color} emissiveIntensity={0.4} />
            </mesh>
          </group>
        </group>

        {/* sweeping slice plane */}
        <mesh ref={slice} position={[0, 2.2, 1.4]} rotation={[0, 0, 0]}>
          <boxGeometry args={[3.4, 0.06, 3.4]} />
          <meshStandardMaterial color={info.color} transparent opacity={0.3} emissive={info.color} emissiveIntensity={0.5} />
        </mesh>

        {/* reconstructed slices stacking up */}
        {[...Array(5)].map((_, i) => (
          <mesh key={i} position={[4.2, 1.2 + i * 0.45, 1.4]}>
            <boxGeometry args={[1.6, 0.3, 1.6]} />
            <meshStandardMaterial color={info.color} transparent opacity={0.35 + i * 0.1} roughness={0.4} />
          </mesh>
        ))}
        <Label p={[4.2, 4.0, 1.4]} size={0.3} color={info.color}>3D volume rebuilt</Label>
        <Label p={[0, 5.2, 1.4]} size={0.32} color="#e2e8f0">{mod.toUpperCase()} — {info.use}</Label>

        <Animator gantry={gantry} slice={slice} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
