// Heart failure drugs: a beating heart with a weak squeeze — inotropic drugs
// strengthen each contraction and raise stroke volume.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "drug", label: "Inotrope drug effect", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Heart failure drugs",
  blurb: "A failing heart squeezes weakly — inotropic drugs strengthen each beat and raise stroke volume.",
};

function Animator({ heart, blood, elapsed, level, setTick }: {
  heart: React.RefObject<THREE.Group>;
  blood: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  level: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = level / 100;
    const beat = Math.pow(Math.max(0, Math.sin(t * Math.PI * 2 * 1.1)), 2);
    const squeeze = 1 - beat * (0.08 + k * 0.22);
    if (heart.current) heart.current.scale.set(1 / Math.sqrt(squeeze), squeeze, 1 / Math.sqrt(squeeze));
    // blood spurts out of the aorta on each beat, stronger with drug
    blood.current.forEach((b, i) => {
      if (!b) return;
      const f = (t * 1.1 + i / 6) % 1;
      const dist = f * (1.5 + k * 2.5);
      b.position.set(0.55 + dist * 0.5, 3.4 + dist * 0.8, 0);
      ((b as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = Math.max(0, 1 - f * 1.4);
      b.scale.setScalar(0.6 + k * 0.8);
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(t * 10)); }
  });
  return null;
}

export function Topic10111Sim(props: SimProps) {
  const level = Number(props.drug ?? 55);
  const showLabels = String(props.detail ?? "on") === "on";
  const heart = useRef<THREE.Group>(null!);
  const blood = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const k = level / 100;
  const sv = Math.round(35 + k * 45); // stroke volume mL
  const state = k < 0.33 ? "failing — weak squeeze" : k < 0.66 ? "improving" : "strong contraction";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stroke volume", `${sv} mL/beat`],
          ["Heart state", state],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 11]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* heart: ventricles, atria, aorta */}
        <group ref={heart} position={[0, 1.4, 0]}>
          <mesh position={[-0.45, -0.25, 0]} castShadow>
            <sphereGeometry args={[0.85, 24, 18]} />
            <meshStandardMaterial color="#dc2626" roughness={0.45} />
          </mesh>
          <mesh position={[0.5, -0.15, 0]} castShadow>
            <sphereGeometry args={[0.7, 24, 18]} />
            <meshStandardMaterial color="#ef4444" roughness={0.45} />
          </mesh>
          <mesh position={[-0.4, 0.75, 0]} castShadow>
            <sphereGeometry args={[0.5, 20, 14]} />
            <meshStandardMaterial color="#f87171" roughness={0.5} />
          </mesh>
          <mesh position={[0.45, 0.8, 0]} castShadow>
            <sphereGeometry args={[0.45, 20, 14]} />
            <meshStandardMaterial color="#fca5a5" roughness={0.5} />
          </mesh>
          <mesh position={[0.55, 1.55, 0]} rotation={[0, 0, -0.5]} castShadow>
            <cylinderGeometry args={[0.24, 0.32, 1.1, 14]} />
            <meshStandardMaterial color="#b91c1c" roughness={0.5} />
          </mesh>
        </group>
        {showLabels && <Label text="left ventricle" position={[-1.9, 0.9, 0]} size={0.45} color="#fca5a5" />}
        {showLabels && <Label text="aorta" position={[1.6, 3.6, 0]} size={0.45} color="#fca5a5" />}

        {/* blood ejected per beat */}
        {Array.from({ length: 6 }).map((_, i) => (
          <mesh key={i} ref={(m) => { blood.current[i] = m; }}>
            <sphereGeometry args={[0.16, 10, 8]} />
            <meshStandardMaterial color="#f87171" emissive="#dc2626" emissiveIntensity={0.8} transparent />
          </mesh>
        ))}

        {/* drug IV drip */}
        <group position={[-3.6, 0, 0]}>
          <mesh position={[0, 3.4, 0]}>
            <boxGeometry args={[0.5, 0.8, 0.5]} />
            <meshStandardMaterial color="#bae6fd" transparent opacity={0.7} />
          </mesh>
          <mesh position={[0, 2.2, 0]}>
            <cylinderGeometry args={[0.05, 0.05, 1.8, 8]} />
            <meshStandardMaterial color="#94a3b8" />
          </mesh>
        </group>
        {showLabels && <Label text="inotrope IV drip" position={[-3.6, 4.4, 0]} size={0.45} color="#7dd3fc" />}

        <Animator heart={heart} blood={blood} elapsed={elapsed} level={level} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
