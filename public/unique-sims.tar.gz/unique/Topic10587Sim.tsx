// Topic10587 — Laser physics and tissue interaction.
// A dental laser fires photons at tissue. Slide the wavelength to watch
// the beam change colour; raise the power and the tissue heats, glows
// and finally vaporises — absorption in action.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "wave", label: "Wavelength", kind: "slider", min: 400, max: 1064, step: 10, default: 810, unit: "nm" },
  { key: "power", label: "Laser power", kind: "slider", min: 0, max: 10, step: 0.5, default: 4, unit: "W" },
];

export const UNIQUE_META = {
  title: "Laser physics and tissue interaction",
  blurb: "Fire photons at tissue — change wavelength and power to see absorption, heating and vaporisation.",
};

function waveColor(nm: number): THREE.Color {
  // rough visible-spectrum mapping; NIR shown as dim deep red
  let c: THREE.Color;
  if (nm < 450) c = new THREE.Color("#8b5cf6");
  else if (nm < 495) c = new THREE.Color("#3b82f6");
  else if (nm < 570) c = new THREE.Color("#22c55e");
  else if (nm < 620) c = new THREE.Color("#facc15");
  else if (nm <= 700) c = new THREE.Color("#ef4444");
  else c = new THREE.Color("#7f1d1d");
  return c;
}

function effectOf(power: number): string {
  if (power < 1.5) return "Photobiomodulation (healing)";
  if (power < 4) return "Photothermal (coagulation)";
  if (power < 7) return "Vaporisation (cutting)";
  return "Photoablation (tissue removed)";
}

function Animator({
  photons,
  beam,
  tissueMat,
  plume,
  elapsed,
  power,
}: {
  photons: RefObject<THREE.Group>;
  beam: RefObject<THREE.Mesh>;
  tissueMat: RefObject<THREE.MeshStandardMaterial>;
  plume: RefObject<THREE.Group>;
  elapsed: RefObject<number>;
  power: number;
}) {
  const hot = useMemo(() => new THREE.Color("#f97316"), []);
  const char = useMemo(() => new THREE.Color("#1c0a00"), []);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    // photons stream from laser (-3.4) to tissue (1.2), wave motion
    if (photons.current) {
      const n = photons.current.children.length;
      photons.current.children.forEach((m, i) => {
        const ph = ((t * (1.5 + power * 0.4) + i / n) % 1);
        m.position.set(-3.4 + ph * 4.6, 2.2 + Math.sin(ph * 18 + t * 3) * 0.14, 0);
        m.scale.setScalar(0.5 + power / 14);
      });
      photons.current.visible = power > 0.05;
    }
    if (beam.current) {
      const m = beam.current.material as THREE.MeshStandardMaterial;
      m.opacity = power > 0.05 ? 0.22 + 0.08 * Math.sin(t * 12) : 0;
    }
    // tissue absorbs: heats orange -> chars black as power climbs
    if (tissueMat.current) {
      const heat = Math.min(1, power / 7);
      tissueMat.current.color.copy(hot).lerp(char, Math.max(0, heat - 0.55) * 2);
      tissueMat.current.emissive.setHex(0xea580c);
      tissueMat.current.emissiveIntensity = heat * (0.5 + 0.25 * Math.sin(t * 8));
    }
    // vapor plume rises when vaporising
    if (plume.current) {
      plume.current.visible = power >= 4;
      plume.current.children.forEach((m, i) => {
        const y = 2.4 + ((t * 1.6 + i * 0.5) % 2.2);
        m.position.set(1.2 + Math.sin(t * 2 + i) * 0.2, y, Math.cos(t * 1.6 + i) * 0.2);
        m.scale.setScalar(0.5 + (y - 2.4) * 0.4);
      });
    }
  });
  return null;
}

export function Topic10587Sim(props: SimProps) {
  const wave = Number(props.wave ?? 810);
  const power = Number(props.power ?? 4);
  const photons = useRef<THREE.Group>(null!);
  const beam = useRef<THREE.Mesh>(null!);
  const tissueMat = useRef<THREE.MeshStandardMaterial>(null!);
  const plume = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const beamColor = useMemo(() => waveColor(wave), [wave]);
  const photonEnergy = (1240 / wave).toFixed(2); // eV

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Wavelength", `${wave} nm`],
          ["Photon energy", `${photonEnergy} eV`],
          ["Tissue effect", effectOf(power)],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* laser handpiece */}
        <group position={[-4.2, 2.2, 0]}>
          <mesh castShadow rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.45, 0.55, 1.6, 16]} />
            <meshStandardMaterial color="#1e293b" roughness={0.4} metalness={0.5} />
          </mesh>
          <mesh position={[0.95, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.18, 0.3, 0.5, 12]} />
            <meshStandardMaterial color="#475569" roughness={0.35} metalness={0.7} />
          </mesh>
        </group>

        {/* the beam */}
        <mesh ref={beam} position={[-1.1, 2.2, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.12, 0.12, 4.6, 10, 1, true]} />
          <meshStandardMaterial color={beamColor} transparent opacity={0.25} emissive={beamColor} emissiveIntensity={1.6} side={THREE.DoubleSide} />
        </mesh>

        {/* photons: wave packets riding the beam */}
        <group ref={photons}>
          {Array.from({ length: 14 }).map((_, i) => (
            <mesh key={i} position={[-3.4, 2.2, 0]}>
              <sphereGeometry args={[0.1, 10, 10]} />
              <meshStandardMaterial color={beamColor} emissive={beamColor} emissiveIntensity={2} />
            </mesh>
          ))}
        </group>

        {/* tissue block absorbing the beam */}
        <mesh position={[2.1, 2.2, 0]} castShadow>
          <boxGeometry args={[1.8, 2.6, 2.2]} />
          <meshStandardMaterial ref={tissueMat} color="#f9a8d4" roughness={0.7} />
        </mesh>
        {/* vapor plume */}
        <group ref={plume}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[1.2, 2.5, 0]}>
              <sphereGeometry args={[0.14, 8, 8]} />
              <meshStandardMaterial color="#cbd5e1" transparent opacity={0.5} roughness={1} />
            </mesh>
          ))}
        </group>

        <Label text={`LASER — ${wave} nm ${wave > 700 ? "(near-infrared, invisible)" : ""}`} position={[-4.2, 3.9, 0]} size={0.4} color="#e0f2fe" />
        <Label text="TISSUE ABSORBS PHOTONS → heat" position={[2.1, 4.1, 0]} size={0.4} color="#fdba74" />
        <Label text="Shorter λ = more energy per photon (E = hc/λ)" position={[0, 0.35, 0]} size={0.36} color="#94a3b8" />

        <Animator photons={photons} beam={beam} tissueMat={tissueMat} plume={plume} elapsed={elapsed} power={power} />
      </SimCanvas>
    </div>
  );
}
