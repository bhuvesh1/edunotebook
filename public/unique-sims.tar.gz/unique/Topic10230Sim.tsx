// Thyroid disorders — the butterfly-shaped thyroid in the neck: hypo
// (slow body, weight gain, cold), hyper (racing heart, tremor, heat), or a
// goiter swelling. State select + hormone-level slider drives the body avatar.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "hormone", label: "Thyroid hormone level", kind: "slider", min: 0, max: 100, step: 5, default: 75, unit: "%" },
  { key: "state", label: "State", kind: "select", min: 0, max: 0, step: 1, default: "hyperthyroid", options: ["hyperthyroid", "hypothyroid", "goiter"] },
];

export const UNIQUE_META = {
  title: "Thyroid Disorders",
  blurb: "The butterfly gland in the neck sets the body's speed — hyper races the heart, hypo slows everything, goiter swells the gland.",
};

function Animator({ gland, heart, avatar, elapsed, state, hormone }: {
  gland: React.RefObject<THREE.Group>;
  heart: React.RefObject<THREE.Mesh>;
  avatar: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  state: string;
  hormone: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const speed = state === "hyperthyroid" ? 0.5 + (hormone / 100) * 2.2 : state === "hypothyroid" ? 0.35 : 0.8;
    if (heart.current) {
      const b = Math.pow(Math.max(0, Math.sin(t * 6 * speed)), 3);
      heart.current.scale.setScalar(1 + b * 0.18);
    }
    if (gland.current) {
      const target = state === "goiter" ? 1 + (hormone / 100) * 1.2 : 1 + (hormone / 100) * 0.15;
      gland.current.scale.setScalar(gland.current.scale.x + (target - gland.current.scale.x) * Math.min(1, delta * 4));
    }
    if (avatar.current && state === "hyperthyroid") {
      // tremor
      avatar.current.position.x = Math.sin(t * 25) * 0.03 * (hormone / 100);
    }
  });
  return null;
}

export function Topic10230Sim(props: SimProps) {
  const hormone = Number(props.hormone ?? 75);
  const state = String(props.state ?? "hyperthyroid");
  const gland = useRef<THREE.Group>(null!);
  const heart = useRef<THREE.Mesh>(null!);
  const avatar = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const bpm = state === "hyperthyroid" ? Math.round(80 + (hormone / 100) * 70) : state === "hypothyroid" ? Math.round(70 - (hormone / 100) * 25) : 72;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["State", state], ["Heart rate", `${bpm} bpm`], ["Body speed", state === "hyperthyroid" ? "racing 🔥" : state === "hypothyroid" ? "sluggish 🐢" : "normal"]]} />
      <SimCanvas cameraPosition={[0, 3, 13]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* neck */}
        <mesh position={[-3.4, 3.2, 0]} castShadow>
          <cylinderGeometry args={[0.85, 1.0, 4.2, 20]} />
          <meshStandardMaterial color="#f5d0b8" roughness={0.65} />
        </mesh>
        {/* butterfly thyroid */}
        <group ref={gland} position={[-3.4, 3.1, 0.75]}>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 0.5, 0, 0]} scale={[0.75, 1.15, 0.5]}>
              <sphereGeometry args={[0.5, 18, 14]} />
              <meshStandardMaterial color={state === "hyperthyroid" ? "#f87171" : state === "hypothyroid" ? "#93c5fd" : "#f9a8d4"} roughness={0.5} emissive={state !== "goiter" ? "#7f1d1d" : "#000"} emissiveIntensity={state === "hyperthyroid" ? 0.4 : 0.1} />
            </mesh>
          ))}
          <mesh position={[0, 0.15, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.12, 0.12, 0.9, 10]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
          </mesh>
        </group>
        <Label text="Thyroid (butterfly gland)" position={[-3.4, 5.6, 0.75]} size={0.5} color="#f9a8d4" />
        {state === "goiter" && <Label text="Goiter — visibly swollen neck" position={[-3.4, 1.3, 0.75]} size={0.5} color="#fca5a5" />}

        {/* body avatar showing systemic effects */}
        <group ref={avatar} position={[2.6, 0, 0]}>
          <mesh position={[0, 4.6, 0]} castShadow>
            <sphereGeometry args={[0.75, 22, 18]} />
            <meshStandardMaterial color="#f5d0b8" roughness={0.65} />
          </mesh>
          <mesh position={[0, 2.4, 0]} castShadow>
            <cylinderGeometry args={[0.75, 0.9, 2.8, 18]} />
            <meshStandardMaterial color={state === "hypothyroid" ? "#93c5fd" : state === "hyperthyroid" ? "#fca5a5" : "#c4b5fd"} roughness={0.65} />
          </mesh>
          {/* heart */}
          <mesh ref={heart} position={[0, 3.3, 0.75]} scale={[0.75, 0.95, 0.7]}>
            <sphereGeometry args={[0.5, 18, 14]} />
            <meshStandardMaterial color="#dc2626" roughness={0.45} />
          </mesh>
          {/* sweat drops (hyper) / snowflake (hypo) */}
          {state === "hyperthyroid" && (
            <mesh position={[0.9, 4.4, 0.4]}>
              <sphereGeometry args={[0.14, 10, 10]} />
              <meshBasicMaterial color="#7dd3fc" />
            </mesh>
          )}
          <Label text={`${bpm} bpm`} position={[0, 5.8, 0]} size={0.55} color={bpm > 100 ? "#fca5a5" : "#86efac"} />
        </group>

        <Label text={state === "hyperthyroid" ? "Hyper: weight loss, tremor, heat, palpitations" : state === "hypothyroid" ? "Hypo: weight gain, fatigue, cold, slow" : "Goiter: iodine lack or nodules swell the gland"} position={[0, -1.2, 0]} size={0.46} color="#fde047" />
        <Animator gland={gland} heart={heart} avatar={avatar} elapsed={elapsed} state={state} hormone={hormone} />
      </SimCanvas>
    </div>
  );
}
