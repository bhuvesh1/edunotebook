"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "level", label: "Sedation level", kind: "select", min: 0, max: 0, step: 1, default: "minimal", options: ["minimal", "moderate", "deep"] },
  { key: "anxiety", label: "Patient anxiety", kind: "slider", min: 0, max: 10, step: 1, default: 8, unit: "/10" },
];

export const UNIQUE_META = {
  title: "Anxiolytics and sedation in dentistry",
  blurb: "An anxious patient in the dental chair calms down as sedation deepens — brain waves slow, breathing eases, eyes close.",
};

const LEVELS: Record<string, { name: string; drug: string; depth: number; note: string; color: string }> = {
  minimal: { name: "Minimal (anxiolysis)", drug: "Oral triazolam", depth: 0.3, note: "Relaxed but fully awake", color: "#86efac" },
  moderate: { name: "Moderate (conscious)", drug: "IV midazolam", depth: 0.65, note: "Drowsy, may not remember", color: "#7dd3fc" },
  deep: { name: "Deep sedation", drug: "Propofol + monitoring", depth: 1, note: "Near-sleep — needs monitoring", color: "#a78bfa" },
};

function BrainWaves({ depth, anxiety }: { depth: number; anxiety: number }) {
  const line = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 80; i++) {
      const x = -1.6 + (i / 80) * 3.2;
      const amp = (0.25 + (anxiety / 10) * 0.5) * (1 - depth * 0.75);
      const y = Math.sin(x * 6) * amp + Math.sin(x * 13) * amp * 0.4;
      pts.push(new THREE.Vector3(x, y, 0));
    }
    const g = new THREE.BufferGeometry().setFromPoints(pts);
    return new THREE.Line(g, new THREE.LineBasicMaterial({ color: depth > 0.6 ? "#a78bfa" : "#7dd3fc" }));
  }, [depth, anxiety]);
  return <primitive object={line} />;
}

function Scene({ level, anxiety }: { level: string; anxiety: number }) {
  const t = useRef(0);
  const chest = useRef<THREE.Mesh>(null!);
  const lid = useRef<THREE.Mesh>(null!);
  const L = LEVELS[level] ?? LEVELS.minimal;

  useFrame((_, delta) => {
    t.current += delta;
    const breathRate = 1.6 - L.depth * 0.9;
    if (chest.current) chest.current.scale.y = 1 + Math.sin(t.current * breathRate * 2) * 0.12;
    if (lid.current) lid.current.position.y = 0.62 - L.depth * 0.22 + Math.sin(t.current * 0.5) * 0.01;
  });

  return (
    <group>
      {/* dental chair */}
      <mesh position={[0, -1.15, 0]}>
        <boxGeometry args={[1.6, 0.35, 4.6]} />
        <meshStandardMaterial color="#475569" roughness={0.6} />
      </mesh>
      <mesh position={[0, -0.5, 1.75]} rotation={[0.5, 0, 0]}>
        <boxGeometry args={[1.6, 0.3, 1.4]} />
        <meshStandardMaterial color="#475569" roughness={0.6} />
      </mesh>
      <mesh position={[0, -1.9, 0]}>
        <boxGeometry args={[1.2, 0.6, 4.2]} />
        <meshStandardMaterial color="#1e293b" roughness={0.8} />
      </mesh>

      {/* patient body */}
      <mesh position={[0, -0.55, -0.4]}>
        <capsuleGeometry args={[0.5, 2.4, 8, 16]} />
        <meshStandardMaterial color="#3b82f6" roughness={0.7} />
      </mesh>
      {/* chest (breathing) */}
      <mesh ref={chest} position={[0, -0.45, 0.9]}>
        <sphereGeometry args={[0.52, 16, 16]} />
        <meshStandardMaterial color="#60a5fa" roughness={0.7} />
      </mesh>
      {/* head */}
      <mesh position={[0, 0.1, 2.15]}>
        <sphereGeometry args={[0.55, 20, 20]} />
        <meshStandardMaterial color="#f2c9a0" roughness={0.6} />
      </mesh>
      {/* eyelid closing with sedation */}
      <mesh ref={lid} position={[0, 0.62, 2.55]}>
        <boxGeometry args={[0.8, 0.16, 0.1]} />
        <meshStandardMaterial color="#e0a878" roughness={0.6} />
      </mesh>
      {/* open mouth for dentist */}
      <mesh position={[0, -0.15, 2.62]}>
        <sphereGeometry args={[0.16, 12, 12]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.7} />
      </mesh>

      {/* brain with waves */}
      <group position={[0, 2.6, 1.6]}>
        <mesh scale={[1.2, 1, 1.1]}>
          <sphereGeometry args={[0.7, 20, 20]} />
          <meshStandardMaterial color="#f9a8d4" transparent opacity={0.45} roughness={0.4} />
        </mesh>
        <group position={[0, 0, 0.75]}>
          <BrainWaves depth={L.depth} anxiety={anxiety} />
        </group>
        <Label text="Brain waves calming" position={[0, 1.15, 0]} size={0.42} color="#f9a8d4" />
      </group>

      {/* IV line */}
      <mesh position={[-0.9, 0.4, 1.2]} rotation={[0.2, 0, 0.5]}>
        <cylinderGeometry args={[0.04, 0.04, 2.6, 8]} />
        <meshStandardMaterial color="#e0f2fe" transparent opacity={0.7} roughness={0.3} />
      </mesh>
      <Label text={L.drug} position={[-1.6, 1.5, 1.2]} size={0.42} color={L.color} />

      <Label text={L.name} position={[0, 4.2, 0]} size={0.65} color={L.color} />
      <Label text={`${L.note} · Anxiety ${anxiety}/10 → ${Math.max(1, Math.round(anxiety * (1 - L.depth * 0.8)))}/10`} position={[0, -3.1, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10422Sim(props: SimProps) {
  const level = String(props.level ?? "minimal");
  const anxiety = Number(props.anxiety ?? 8);
  const L = LEVELS[level] ?? LEVELS.minimal;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Sedation", L.name], ["Drug", L.drug], ["Airway", level === "deep" ? "Monitor closely" : "Patient maintains"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, 0.2, 0.8]}>
        <Scene level={level} anxiety={anxiety} />
      </SimCanvas>
    </div>
  );
}
