// app/components/sims/unique/Topic7102Sim.tsx
// Multiplying a vector by a scalar: the slider is k. The arrow stretches
// to k times its length — and flips to point the opposite way (turning
// red) when k goes negative.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "scalar", label: "Scalar k", kind: "slider", min: -2, max: 3, step: 0.5, default: 2, unit: "" },
];

export const UNIQUE_META = {
  title: "Multiplication of Vectors by Scalars",
  blurb: "Stretch the vector with k — negative k flips it around and turns it red.",
};

const V_LEN = 2;

function Animator({
  arrow, k, bump,
}: {
  arrow: RefObject<THREE.Group>;
  k: number;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    if (arrow.current) {
      const L = Math.abs(k) * V_LEN;
      const dir = k >= 0 ? 1 : -1;
      const shaft = arrow.current.children[0] as THREE.Mesh;
      const cone = arrow.current.children[1] as THREE.Mesh;
      shaft.scale.set(1, Math.max(L, 0.001), 1);
      shaft.position.set(0, (dir * L) / 2, 0);
      cone.position.set(0, dir * (L + 0.2), 0);
      cone.rotation.z = dir >= 0 ? 0 : Math.PI;
      const col = k >= 0 ? "#3b82f6" : "#ef4444";
      (shaft.material as THREE.MeshStandardMaterial).color.set(col);
      (shaft.material as THREE.MeshStandardMaterial).emissive.set(col);
      (cone.material as THREE.MeshStandardMaterial).color.set(col);
      (cone.material as THREE.MeshStandardMaterial).emissive.set(col);
      // Gentle pulse so the change is visible.
      const s = 1 + 0.02 * Math.sin(t.current * 4);
      arrow.current.scale.set(s, 1, s);
    }
    if (++n.current % 30 === 0) bump();
  });
  return null;
}

export function Topic7102Sim(props: SimProps) {
  const k = Number(props.scalar ?? 2);
  const arrow = useRef<THREE.Group>(null!);

  const grid = useMemo(() => new THREE.GridHelper(12, 12, "#334155", "#1e293b"), []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["k", `${k}`],
          ["|k·v|", `${(Math.abs(k) * V_LEN).toFixed(1)}`],
          ["Direction", k >= 0 ? "same as v" : "opposite to v"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 12]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0b1020" roughness={1} />
        </mesh>
        <primitive object={grid} position={[0, 0.02, 0]} />
        {/* original vector v (ghost, pointing up) */}
        <group position={[0, 1.2, 0]}>
          <mesh position={[0, V_LEN / 2, 0]}>
            <cylinderGeometry args={[0.06, 0.06, V_LEN, 10]} />
            <meshStandardMaterial color="#94a3b8" transparent opacity={0.5} roughness={0.5} />
          </mesh>
          <mesh position={[0, V_LEN + 0.15, 0]}>
            <coneGeometry args={[0.16, 0.3, 12]} />
            <meshStandardMaterial color="#94a3b8" transparent opacity={0.5} roughness={0.5} />
          </mesh>
        </group>
        {/* k·v */}
        <group position={[0, 1.2, 0]}>
          <group ref={arrow}>
            <mesh>
              <cylinderGeometry args={[0.1, 0.1, 1, 12]} />
              <meshStandardMaterial color="#3b82f6" emissive="#3b82f6" emissiveIntensity={0.5} roughness={0.4} />
            </mesh>
            <mesh>
              <coneGeometry args={[0.24, 0.45, 14]} />
              <meshStandardMaterial color="#3b82f6" emissive="#3b82f6" emissiveIntensity={0.5} roughness={0.4} />
            </mesh>
          </group>
        </group>
        <Animator arrow={arrow} k={k} bump={() => undefined} />
      </SimCanvas>
    </div>
  );
}
