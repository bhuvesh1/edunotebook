"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "bend", label: "Spine bend", kind: "slider", min: -30, max: 30, step: 5, default: 0, unit: "°" },
  { key: "speed", label: "Sway speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Back and spinal cord: vertebral column, spinal meninges",
  blurb: "The vertebral column bends with soft discs between hard vertebrae — the spinal cord threads safely through the middle.",
};

function Spine({ bend, speed }: { bend: number; speed: number }) {
  const segs = useRef<(THREE.Group | null)[]>([]);
  const t = useRef(0);
  const N = 7;
  useFrame((_, d) => {
    t.current += d * speed;
    const sway = Math.sin(t.current * 1.2) * 0.06;
    segs.current.forEach((g, i) => {
      if (!g) return;
      const f = i / (N - 1);
      g.position.x = (bend / 30) * f * f * 2.2 + sway * f;
      g.rotation.z = -(bend / 30) * f * 0.35 + sway * 0.4;
    });
  });
  const bone = { color: "#f5f0e6", roughness: 0.55 };
  return (
    <group position={[0, 0.6, 0]}>
      {Array.from({ length: N }).map((_, i) => (
        <group key={i} ref={(g) => { segs.current[i] = g; }} position={[0, 1.0 + i * 0.85, 0]}>
          {/* vertebral body */}
          <mesh castShadow>
            <cylinderGeometry args={[0.5, 0.5, 0.55, 16]} />
            <meshStandardMaterial {...bone} />
          </mesh>
          {/* spinous process */}
          <mesh position={[0, 0.1, -0.75]} rotation={[0.5, 0, 0]} castShadow>
            <boxGeometry args={[0.22, 0.22, 0.9]} />
            <meshStandardMaterial {...bone} />
          </mesh>
          {/* transverse processes */}
          {[-0.75, 0.75].map((x) => (
            <mesh key={x} position={[x, 0.1, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
              <cylinderGeometry args={[0.09, 0.09, 0.6, 8]} />
              <meshStandardMaterial {...bone} />
            </mesh>
          ))}
          {/* intervertebral disc below */}
          {i < N - 1 && (
            <mesh position={[0, -0.42, 0]} castShadow>
              <cylinderGeometry args={[0.46, 0.46, 0.28, 16]} />
              <meshStandardMaterial color="#93c5fd" roughness={0.5} />
            </mesh>
          )}
        </group>
      ))}
      {/* spinal cord running through */}
      <mesh position={[0, 3.6, 0]}>
        <cylinderGeometry args={[0.16, 0.2, 6.4, 12]} />
        <meshStandardMaterial color="#fde047" emissive="#a16207" emissiveIntensity={0.4} roughness={0.5} />
      </mesh>
      {/* meninges sheath */}
      <mesh position={[0, 3.6, 0]}>
        <cylinderGeometry args={[0.3, 0.34, 6.2, 12, 1, true]} />
        <meshStandardMaterial color="#bae6fd" roughness={0.4} transparent opacity={0.35} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}

export function Topic10010Sim(props: SimProps) {
  const bend = Number(props.bend ?? 0);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Vertebrae", "7 shown"], ["Discs", "cushions"], ["Cord", "protected"]]} />
      <SimCanvas cameraPosition={[6, 4, 11]} target={[0, 3.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Spine bend={bend} speed={speed} />
        {showLabels && (
          <>
            <Label text="Vertebra" position={[-2.6, 5.6, 0]} color="#fef3c7" size={0.5} />
            <Label text="Disc" position={[2.6, 3.4, 0]} color="#bfdbfe" size={0.5} />
            <Label text="Spinal cord" position={[-2.4, 2.2, 0]} color="#fde047" size={0.5} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
