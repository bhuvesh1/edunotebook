// app/components/sims/unique/Topic10543Sim.tsx
// Pediatric oral surgery basics: tooth extraction (forceps rock the tooth
// out, leaving a socket) and frenectomy (releasing a tight lip/tongue
// frenum).

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "proc", label: "Procedure", kind: "select", min: 0, max: 0, step: 1, default: "extraction", options: ["extraction", "frenectomy"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Pediatric Oral Surgery: Extractions & Frenectomy",
  blurb: "Forceps rock a baby tooth out of its socket — or a tight frenum under the tongue gets released.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ tooth, forceps, elapsed, speed, proc }: {
  tooth: RefObject<THREE.Group>; forceps: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number; proc: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (proc !== "extraction") return;
    // 5 s loop: grip, rock side to side, lift out
    const cyc = (t % 5) / 5;
    if (tooth.current) {
      if (cyc < 0.5) {
        tooth.current.position.y = 2.05 + 0.1 * cyc;
        tooth.current.rotation.z = 0.18 * Math.sin(t * 7);
      } else {
        const k = Math.min((cyc - 0.5) / 0.3, 1);
        tooth.current.position.y = 2.1 + k * 2.2;
        tooth.current.rotation.z = 0.18 * Math.sin(t * 7) * (1 - k);
      }
    }
    if (forceps.current) {
      forceps.current.visible = true;
      forceps.current.position.y = cyc < 0.5 ? 2.6 : 2.6 + Math.min((cyc - 0.5) / 0.3, 1) * 2.2;
      forceps.current.rotation.z = 0.1 * Math.sin(t * 7);
    }
  });
  return null;
}

function FrenumAnimator({ frenum, elapsed, speed, proc }: {
  frenum: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; proc: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (proc !== "frenectomy" || !frenum.current) return;
    // frenum band stretches then releases (gaps open)
    const cyc = (elapsed.current % 4) / 4;
    const s = cyc < 0.4 ? 1 : Math.max(1 - (cyc - 0.4) * 2.5, 0.05);
    frenum.current.scale.set(1, s, 1);
  });
  return null;
}

export function Topic10543Sim(props: SimProps) {
  const proc = String(props.proc ?? "extraction");
  const speed = Number(props.speed ?? 1);
  const tooth = useRef<THREE.Group>(null!);
  const forceps = useRef<THREE.Group>(null!);
  const frenum = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const elapsed2 = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Procedure", proc === "extraction" ? "Extraction" : "Frenectomy"],
          ["Key step", proc === "extraction" ? "luxate (rock) before pulling" : "release the tight frenum band"],
          ["After", proc === "extraction" ? "bite on gauze, clot forms" : "tongue/lip moves freely"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {proc === "extraction" ? (
          <>
            {/* gum */}
            <mesh position={[0, 1.2, 0]} castShadow>
              <boxGeometry args={[6, 0.9, 1.6]} />
              <meshStandardMaterial color="#e0607a" roughness={0.6} />
            </mesh>
            {/* neighbor teeth */}
            {[-2.2, -1.4, 1.4, 2.2].map((x, i) => (
              <mesh key={i} position={[x, 2.2, 0]} castShadow>
                <boxGeometry args={[0.66, 0.95, 0.6]} />
                <meshStandardMaterial color="#fefce8" roughness={0.3} />
              </mesh>
            ))}
            {/* the tooth being extracted */}
            <group ref={tooth} position={[0, 2.05, 0]}>
              <mesh castShadow>
                <boxGeometry args={[0.66, 0.95, 0.6]} />
                <meshStandardMaterial color="#ffffff" roughness={0.3} />
              </mesh>
              <mesh position={[0, -0.75, 0]} rotation={[Math.PI, 0, 0]}>
                <coneGeometry args={[0.2, 0.7, 8]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.35} />
              </mesh>
            </group>
            {/* extraction forceps gripping the crown */}
            <group ref={forceps} position={[0, 2.6, 0]}>
              {[-1, 1].map((s) => (
                <mesh key={s} position={[s * 0.45, 0.5, 0]} rotation={[0, 0, s * -0.25]} castShadow>
                  <boxGeometry args={[0.16, 1.6, 0.3]} />
                  <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
                </mesh>
              ))}
              <mesh position={[0, 1.35, 0]} castShadow>
                <boxGeometry args={[1.1, 0.25, 0.35]} />
                <meshStandardMaterial color="#64748b" metalness={0.8} roughness={0.35} />
              </mesh>
            </group>
            <Label p={[2.8, 3.4, 0]} size={0.3} color="#cbd5e1">forceps rock the tooth loose</Label>
          </>
        ) : (
          <>
            {/* tongue sticking out */}
            <mesh position={[0, 2.2, 0.6]} scale={[1.1, 0.5, 1.6]} castShadow>
              <sphereGeometry args={[0.9, 24, 24]} />
              <meshStandardMaterial color="#e0607a" roughness={0.55} />
            </mesh>
            {/* floor of mouth */}
            <mesh position={[0, 1.2, 0]} castShadow>
              <boxGeometry args={[4.5, 0.8, 3]} />
              <meshStandardMaterial color="#d96a7f" roughness={0.6} />
            </mesh>
            {/* tight frenum band under the tongue */}
            <mesh ref={frenum} position={[0, 1.85, 1.15]} castShadow>
              <boxGeometry args={[0.28, 1.0, 0.5]} />
              <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={0.5} roughness={0.5} />
            </mesh>
            {/* laser/scissor cut line */}
            <mesh position={[0, 1.85, 1.42]} rotation={[0, 0, Math.PI / 2]}>
              <boxGeometry args={[0.06, 1.0, 0.06]} />
              <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={1.2} />
            </mesh>
            <Label p={[2.6, 1.85, 1.2]} size={0.3} color="#fde68a">tight frenum (tongue-tie)</Label>
            <Label p={[0, 3.8, 0.8]} size={0.32} color="#e2e8f0">frenectomy frees the tongue</Label>
          </>
        )}

        <Animator tooth={tooth} forceps={forceps} elapsed={elapsed} speed={speed} proc={proc} />
        <FrenumAnimator frenum={frenum} elapsed={elapsed2} speed={speed} proc={proc} />
      </SimCanvas>
    </div>
  );
}
