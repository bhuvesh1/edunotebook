// Sepsis, tropical infections & COVID-19 — the coronavirus ball (spike
// proteins) beside a body avatar; the storm slider unleashes a cytokine
// storm (orange particles swarming the body) and organs flash red as sepsis
// sets in.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "storm", label: "Cytokine storm", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "focus", label: "Focus", kind: "select", min: 0, max: 0, step: 1, default: "COVID-19", options: ["COVID-19", "sepsis"] },
];

export const UNIQUE_META = {
  title: "Sepsis & COVID-19",
  blurb: "The coronavirus meets the body — crank the cytokine storm and watch the immune system rage out of control into sepsis.",
};

function Animator({ virus, storm, organs, elapsed, stormLevel }: {
  virus: React.RefObject<THREE.Group>;
  storm: React.RefObject<THREE.Group>;
  organs: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  stormLevel: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (virus.current) {
      virus.current.rotation.y = t * 0.5;
      virus.current.position.y = 3.4 + Math.sin(t * 1.5) * 0.25;
    }
    if (storm.current) {
      storm.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const a = t * (1 + i * 0.13) + i * 2.4;
        m.position.x = 2.6 + Math.cos(a) * (1.6 + (i % 3) * 0.5);
        m.position.y = 2.6 + Math.sin(a * 1.3) * 1.8;
        m.position.z = Math.sin(a * 0.7) * 1.2;
        m.visible = i < Math.round((stormLevel / 100) * storm.current!.children.length);
      });
    }
    if (organs.current) {
      organs.current.children.forEach((c, i) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = (stormLevel / 100) * (0.4 + 0.35 * Math.sin(t * 4 + i * 2));
      });
    }
  });
  return null;
}

export function Topic10238Sim(props: SimProps) {
  const stormLevel = Number(props.storm ?? 55);
  const focus = String(props.focus ?? "COVID-19");
  const virus = useRef<THREE.Group>(null!);
  const storm = useRef<THREE.Group>(null!);
  const organs = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const spikes = useMemo(() => {
    return Array.from({ length: 30 }).map((_, i) => {
      const a = (i * 2.4) % (Math.PI * 2);
      const b = ((i * 1.7) % Math.PI) - Math.PI / 2;
      return { x: Math.cos(a) * Math.cos(b), y: Math.sin(b), z: Math.sin(a) * Math.cos(b) };
    });
  }, []);

  const septic = stormLevel > 65;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Focus", focus], ["Immune response", stormLevel < 35 ? "controlled" : stormLevel < 65 ? "strong" : "STORM — sepsis ⚠"], ["Organs", septic ? "failing" : "coping"]]} />
      <SimCanvas cameraPosition={[0, 3, 13]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* coronavirus */}
        <group ref={virus} position={[-3.4, 3.4, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[1.0, 26, 20]} />
            <meshStandardMaterial color="#f97316" roughness={0.5} />
          </mesh>
          {spikes.map((s, i) => (
            <mesh key={i} position={[s.x * 1.25, s.y * 1.25, s.z * 1.25]}>
              <sphereGeometry args={[0.12, 8, 8]} />
              <meshStandardMaterial color="#fde047" roughness={0.4} emissive="#b45309" emissiveIntensity={0.5} />
            </mesh>
          ))}
          <Label text="SARS-CoV-2" position={[0, 1.9, 0]} size={0.52} color="#fdba74" />
        </group>

        {/* body avatar */}
        <group position={[2.6, 0, 0]}>
          <mesh position={[0, 4.8, 0]} castShadow>
            <sphereGeometry args={[0.7, 22, 18]} />
            <meshStandardMaterial color="#f5d0b8" roughness={0.65} />
          </mesh>
          <mesh position={[0, 2.6, 0]} castShadow>
            <cylinderGeometry args={[0.8, 0.95, 3.0, 18]} />
            <meshStandardMaterial color="#c4b5fd" roughness={0.65} />
          </mesh>
          {/* organs that fail in sepsis */}
          <group ref={organs}>
            <mesh position={[0, 3.4, 0.7]} scale={[0.7, 0.9, 0.6]}>
              <sphereGeometry args={[0.5, 16, 12]} />
              <meshStandardMaterial color="#dc2626" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.2} />
            </mesh>
            <mesh position={[-0.4, 2.4, 0.6]} scale={[0.6, 0.9, 0.55]}>
              <sphereGeometry args={[0.5, 16, 12]} />
              <meshStandardMaterial color="#b91c1c" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.2} />
            </mesh>
            <mesh position={[0.45, 2.3, 0.6]} scale={[0.9, 0.6, 0.55]}>
              <sphereGeometry args={[0.45, 16, 12]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.2} />
            </mesh>
          </group>
        </group>

        {/* cytokine storm particles */}
        <group ref={storm}>
          {Array.from({ length: 26 }).map((_, i) => (
            <mesh key={i} position={[2.6, 2.6, 0]}>
              <sphereGeometry args={[0.13, 8, 8]} />
              <meshBasicMaterial color="#fb923c" />
            </mesh>
          ))}
        </group>

        <Label text={septic ? "SEPSIS — immune storm attacks own organs ⚠" : "Immune system fighting the infection"} position={[2.6, 6.2, 0]} size={0.52} color={septic ? "#fca5a5" : "#86efac"} />
        <Label text="Sepsis = infection + organ failure — every hour counts" position={[0, -1.2, 0]} size={0.44} color="#94a3b8" />
        <Animator virus={virus} storm={storm} organs={organs} elapsed={elapsed} stormLevel={stormLevel} />
      </SimCanvas>
    </div>
  );
}
