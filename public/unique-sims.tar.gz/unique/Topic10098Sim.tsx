"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "cirrhosis", options: ["normal", "hepatitis", "cirrhosis", "gallstones"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Liver Pathology & Gallbladder",
  blurb: "A liver that inflames in hepatitis, turns nodular in cirrhosis, plus a gallbladder filling with stones.",
};

function Animator({ root, infl, nod, stones, elapsed, speed, hep, cirr, gall }: { root: RefObject<THREE.Group>; infl: RefObject<THREE.Mesh>; nod: RefObject<THREE.Group>; stones: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; hep: boolean; cirr: boolean; gall: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (infl.current) {
      infl.current.visible = hep;
      (infl.current.material as THREE.MeshStandardMaterial).opacity = 0.3 + 0.15 * Math.sin(t * 3);
    }
    if (nod.current) {
      nod.current.visible = cirr;
      nod.current.children.forEach((m, i) => {
        m.scale.setScalar(0.8 + 0.25 * Math.sin(t * 2 + i * 1.7));
      });
    }
    if (stones.current) {
      stones.current.visible = gall;
      stones.current.children.forEach((m, i) => {
        m.position.y = 1.05 + Math.abs(Math.sin(t * 1.4 + i * 2)) * 0.25;
        m.rotation.y = t + i;
      });
    }
    if (root.current) root.current.rotation.y = Math.sin(t * 0.2) * 0.12;
  });
  return null;
}

export function Topic10098Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const cond = String(props.cond ?? "cirrhosis");
  const hep = cond === "hepatitis";
  const cirr = cond === "cirrhosis";
  const gall = cond === "gallstones";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const infl = useRef<THREE.Mesh>(null!);
  const nod = useRef<THREE.Group>(null!);
  const stones = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", cond],
          ["Sign", hep ? "tender hepatomegaly" : cirr ? "shrunken, nodular" : gall ? "Murphy\u2019s sign" : "smooth, non-tender"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[-0.6, 2, 0]} scale={[2.1, 1.15, 1.35]} castShadow>
            <sphereGeometry args={[1, 26, 26]} /><meshStandardMaterial color={cirr ? "#7c2d12" : "#b45309"} roughness={0.6} />
          </mesh>
          <Label text="liver" position={[-0.6, 3.7, 0]} color="#fbbf24" />
          <mesh ref={infl} visible={false} position={[-0.6, 2, 0]} scale={[2.25, 1.28, 1.48]}>
            <sphereGeometry args={[1, 26, 26]} />
            <meshStandardMaterial color="#ef4444" transparent opacity={0.3} emissive="#b91c1d" emissiveIntensity={0.8} />
          </mesh>
          <group ref={nod} visible={false}>
            {Array.from({ length: 12 }).map((_, i) => {
              const a = (i / 12) * Math.PI * 2;
              return (
                <mesh key={i} position={[-0.6 + Math.cos(a) * 2.05, 2 + Math.sin(a * 2) * 0.9, Math.sin(a) * 1.25]} castShadow>
                  <sphereGeometry args={[0.3, 12, 12]} /><meshStandardMaterial color="#92400e" roughness={0.7} />
                </mesh>
              );
            })}
          </group>
          <mesh position={[2.6, 1.1, 0.9]} scale={[0.8, 1.15, 0.8]} castShadow>
            <sphereGeometry args={[0.7, 20, 20]} /><meshStandardMaterial color="#4ade80" roughness={0.45} />
          </mesh>
          <Label text="gallbladder" position={[2.6, 0.1, 0.9]} size={0.42} color="#4ade80" />
          <group ref={stones} visible={false} position={[2.6, 0, 0.9]}>
            {[0, 1, 2].map((i) => (
              <mesh key={i} position={[(i - 1) * 0.35, 1.05, (i % 2) * 0.2]}>
                <dodecahedronGeometry args={[0.22]} /><meshStandardMaterial color="#a8a29e" roughness={0.7} flatShading />
              </mesh>
            ))}
          </group>
          <Label text={hep ? "hepatitis \u2014 inflamed liver" : cirr ? "cirrhosis \u2014 regenerative nodules" : gall ? "cholelithiasis \u2014 gallstones" : "healthy liver"} position={[0, 4.9, 0]} size={0.46} color={cond === "normal" ? "#4ade80" : "#f87171"} />
        </group>
        <Animator root={root} infl={infl} nod={nod} stones={stones} elapsed={elapsed} speed={speed} hep={hep} cirr={cirr} gall={gall} />
      </SimCanvas>
    </div>
  );
}
