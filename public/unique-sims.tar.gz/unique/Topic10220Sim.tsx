// Interstitial lung disease, lung cancer & respiratory failure — a tumor
// nodule grows inside a lung (size slider), spiky ILD fibrosis webs the
// tissue, and the SpO₂ monitor falls as things worsen.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "tumor", label: "Tumor size", kind: "slider", min: 0, max: 100, step: 5, default: 45, unit: "%" },
  { key: "disease", label: "Disease", kind: "select", min: 0, max: 0, step: 1, default: "lung cancer", options: ["lung cancer", "interstitial lung disease", "respiratory failure"] },
];

export const UNIQUE_META = {
  title: "Lung Cancer & Respiratory Failure",
  blurb: "A tumor nodule swells inside the lung while SpO₂ slides down; switch to ILD for fibrotic webs or respiratory failure for the crashing monitor.",
};

function Animator({ tumor, webs, elapsed, tumorSize }: {
  tumor: React.RefObject<THREE.Mesh>;
  webs: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  tumorSize: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (tumor.current) {
      // malignant pulse
      const s = 1 + 0.08 * Math.sin(t * 4);
      tumor.current.scale.set(s, s, s);
      const mat = tumor.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = 0.3 + 0.3 * Math.sin(t * 4);
    }
    if (webs.current) {
      webs.current.rotation.y = t * 0.1;
    }
  });
  return null;
}

export function Topic10220Sim(props: SimProps) {
  const tumorSize = Number(props.tumor ?? 45);
  const disease = String(props.disease ?? "lung cancer");
  const tumor = useRef<THREE.Mesh>(null!);
  const webs = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const tumorR = 0.15 + (tumorSize / 100) * 0.75;
  const spo2 = Math.round(98 - (tumorSize / 100) * 14 - (disease === "respiratory failure" ? 8 : 0));
  const critical = spo2 < 90;

  const webStrands = useMemo(() => {
    return Array.from({ length: 22 }).map((_, i) => {
      const a = (i * 2.8) % (Math.PI * 2);
      return {
        from: [Math.cos(a) * 0.4, 2.6 + ((i * 0.5) % 2.4) - 1.2, Math.sin(a) * 0.3] as [number, number, number],
        to: [Math.cos(a) * 1.35, 2.6 + ((i * 0.7) % 2.8) - 1.4, Math.sin(a) * 0.8] as [number, number, number],
      };
    });
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["SpO₂", `${spo2}%`], ["Status", critical ? "CRITICAL — failing ⚠" : spo2 < 94 ? "low — needs oxygen" : "stable"], ["Disease", disease]]} />
      <SimCanvas cameraPosition={[0, 2.8, 12]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* right lung with the tumor */}
        <mesh position={[2.0, 2.6, 0]} scale={[1, 1.5, 0.7]} castShadow>
          <sphereGeometry args={[1.25, 26, 20]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.6} transparent opacity={disease === "lung cancer" ? 0.75 : 1} />
        </mesh>
        {/* left lung */}
        <mesh position={[-2.0, 2.6, 0]} scale={[1, 1.5, 0.7]} castShadow>
          <sphereGeometry args={[1.25, 26, 20]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
        </mesh>

        {/* tumor nodule */}
        {disease !== "respiratory failure" && (
          <mesh ref={tumor} position={[2.0, 3.1, 0.55]}>
            <dodecahedronGeometry args={[tumorR, 1]} />
            <meshStandardMaterial color="#7f1d1d" roughness={0.6} emissive="#dc2626" emissiveIntensity={0.4} flatShading />
          </mesh>
        )}
        {/* ILD fibrotic webs */}
        {disease === "interstitial lung disease" && (
          <group ref={webs} position={[2.0, 0, 0]}>
            {webStrands.map((w, i) => {
              const dir = new THREE.Vector3(w.to[0] - w.from[0], w.to[1] - w.from[1], w.to[2] - w.from[2]);
              const len = dir.length();
              const mid = new THREE.Vector3((w.from[0] + w.to[0]) / 2, (w.from[1] + w.to[1]) / 2, (w.from[2] + w.to[2]) / 2);
              const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
              return (
                <mesh key={i} position={mid.toArray()} quaternion={quat}>
                  <cylinderGeometry args={[0.035, 0.035, len, 6]} />
                  <meshBasicMaterial color="#a8a29e" transparent opacity={0.8} />
                </mesh>
              );
            })}
          </group>
        )}
        {/* metastatic specks at high tumor size */}
        {disease === "lung cancer" && tumorSize > 60 && (
          <group>
            {[[-2.0, 3.4, 0.4], [-2.3, 2.2, 0.5], [2.6, 1.8, 0.4]].map((p, i) => (
              <mesh key={i} position={p as [number, number, number]}>
                <dodecahedronGeometry args={[0.16, 0]} />
                <meshStandardMaterial color="#991b1b" roughness={0.6} emissive="#dc2626" emissiveIntensity={0.4} flatShading />
              </mesh>
            ))}
            <Label text="Metastases" position={[-2.2, 4.6, 0.4]} size={0.46} color="#fca5a5" />
          </group>
        )}

        {/* SpO2 monitor */}
        <group position={[-5.2, 1.2, 0]}>
          <mesh>
            <boxGeometry args={[2.4, 1.6, 0.25]} />
            <meshStandardMaterial color="#0b1020" roughness={0.6} />
          </mesh>
          <Label text={`${spo2}%`} position={[0, 0.15, 0.2]} size={0.85} color={critical ? "#fca5a5" : spo2 < 94 ? "#fde047" : "#86efac"} />
          <Label text="SpO₂" position={[0, -0.65, 0.2]} size={0.4} color="#94a3b8" />
        </group>

        <Label text={disease === "lung cancer" ? "Tumor nodule — smoking is the #1 cause" : disease === "interstitial lung disease" ? "ILD: scar tissue stiffens the lung (honeycombing)" : "Respiratory failure: lungs can't keep up"} position={[0, -1.1, 0]} size={0.46} color="#fde047" />
        <Animator tumor={tumor} webs={webs} elapsed={elapsed} tumorSize={tumorSize} />
      </SimCanvas>
    </div>
  );
}
