// Hypertension, pericardial diseases & infective endocarditis. An artery
// with pressure waves (pressure slider thickens the wall, speeds the pulse);
// a pericardial sac around the heart that fills with fluid (tamponade);
// vegetations (clumps) on a valve for endocarditis. Condition select.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "pressure", label: "Blood pressure", kind: "slider", min: 90, max: 220, step: 5, default: 150, unit: " mmHg" },
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "hypertension", options: ["hypertension", "pericarditis", "endocarditis"] },
];

export const UNIQUE_META = {
  title: "Hypertension & Pericardium",
  blurb: "Crank the pressure and the artery wall thickens; switch to pericarditis to fill the sac around the heart, or endocarditis for valve vegetations.",
};

function Animator({ pulse, sac, elapsed, pressure, condition }: {
  pulse: React.RefObject<THREE.Group>;
  sac: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  pressure: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const p = (pressure - 90) / 130;
    if (pulse.current) {
      pulse.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * (0.8 + p * 1.4) + i * 0.12) % 1);
        m.position.x = -6.5 + ph * 13;
        m.scale.set(1, 1 + p * 0.9 * Math.sin(ph * Math.PI), 1);
      });
    }
    if (sac.current && condition === "pericarditis") {
      const mat = sac.current.material as THREE.MeshStandardMaterial;
      mat.opacity = 0.25 + 0.2 * Math.sin(t * 2) * 0.3 + 0.25;
    }
  });
  return null;
}

export function Topic10217Sim(props: SimProps) {
  const pressure = Number(props.pressure ?? 150);
  const condition = String(props.condition ?? "hypertension");
  const pulse = useRef<THREE.Group>(null!);
  const sac = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const p = (pressure - 90) / 130;
  const wallThick = 0.22 + p * 0.28;
  const hyper = condition === "hypertension";
  const peri = condition === "pericarditis";
  const endo = condition === "endocarditis";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["BP", `${pressure}/${Math.round(60 + p * 50)} mmHg`], ["Stage", pressure > 180 ? "crisis ⚠" : pressure > 140 ? "stage 2" : pressure > 120 ? "stage 1" : "normal"], ["Focus", condition]]} />
      <SimCanvas cameraPosition={[0, 2.6, 13]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* artery segment */}
        <mesh position={[0, 4.6, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[1.0 + wallThick, 1.0 + wallThick, 13, 24, 1, true]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.5} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[0, 4.6, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[1.0, 1.0, 13, 24, 1, true]} />
          <meshStandardMaterial color="#7f1d1d" roughness={0.6} side={THREE.BackSide} />
        </mesh>
        {/* pressure pulse waves */}
        <group ref={pulse}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[-6.5, 4.6, 0]} rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.75, 0.75, 0.5, 16]} />
              <meshBasicMaterial color="#f87171" transparent opacity={0.35} />
            </mesh>
          ))}
        </group>
        <Label text={hyper ? `Thickened wall @ ${pressure} mmHg` : "Artery"} position={[0, 6.4, 0]} size={0.5} color={pressure > 140 ? "#fca5a5" : "#86efac"} />

        {/* heart inside pericardial sac */}
        <mesh position={[0, 1.6, 0]} scale={[1, 1.25, 0.95]} castShadow>
          <sphereGeometry args={[1.5, 32, 26]} />
          <meshStandardMaterial color="#dc2626" roughness={0.45} />
        </mesh>
        <mesh ref={sac} position={[0, 1.6, 0]} scale={[1.28, 1.5, 1.2]} visible={peri}>
          <sphereGeometry args={[1.5, 32, 26]} />
          <meshStandardMaterial color="#fbbf24" transparent opacity={0.4} roughness={0.3} side={THREE.DoubleSide} emissive="#92400e" emissiveIntensity={0.5} />
        </mesh>
        {peri && <Label text="Pericardial effusion — fluid squeezing the heart ⚠" position={[0, -0.6, 0]} size={0.48} color="#fca5a5" />}

        {/* endocarditis vegetations on valve */}
        {endo && (
          <group>
            <mesh position={[0, 3.35, 0]} rotation={[0, 0, Math.PI / 2]}>
              <torusGeometry args={[0.55, 0.1, 10, 24]} />
              <meshStandardMaterial color="#fbbf24" roughness={0.5} />
            </mesh>
            {[0, 1, 2].map((i) => (
              <mesh key={i} position={[-0.15 + i * 0.18, 3.5 + (i % 2) * 0.12, 0.25]}>
                <dodecahedronGeometry args={[0.18, 0]} />
                <meshStandardMaterial color="#a3e635" roughness={0.7} emissive="#3f6212" emissiveIntensity={0.5} flatShading />
              </mesh>
            ))}
            <Label text="Vegetations — infected clumps on the valve" position={[0, 4.4, 0]} size={0.48} color="#bef264" />
          </group>
        )}

        <Label text={hyper ? "Hypertension: the silent killer — damages heart, brain, kidneys" : peri ? "Pericarditis: sharp chest pain, worse lying flat" : "Endocarditis: fever + new murmur — blood cultures!"} position={[0, -1.9, 0]} size={0.44} color="#94a3b8" />
        <Animator pulse={pulse} sac={sac} elapsed={elapsed} pressure={pressure} condition={condition} />
      </SimCanvas>
    </div>
  );
}
