"use client";
// Sexual offences: medical examination (child-safe, dignified).
// A private examination room: privacy screen, couch, doctor, and a
// consent checklist that ticks itself — examination only with consent.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "step", label: "Exam stage", kind: "select", min: 0, max: 0, step: 1, default: "consent", options: ["consent", "history", "examination", "samples"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Medico-Legal Examination: Consent Comes First",
  blurb: "Inside a private exam room: consent first, then history, gentle examination, and sealed samples — every step explained.",
};

const STEPS = ["consent", "history", "examination", "samples"];
const STEP_TXT: Record<string, string> = {
  consent: "Written consent taken",
  history: "History in private",
  examination: "Gentle examination",
  samples: "Samples sealed & labelled",
};

function Animator({ curtain, ticks, elapsed, speed, step }: { curtain: React.RefObject<THREE.Group>; ticks: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number; step: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (curtain.current) curtain.current.rotation.y = Math.sin(elapsed.current * 0.8) * 0.06;
    if (ticks.current) {
      const idx = STEPS.indexOf(step);
      ticks.current.children.forEach((c, i) => {
        c.visible = i <= idx && (elapsed.current % 8) > i * 1.2;
      });
    }
  });
  return null;
}

export function Topic10157Sim(props: SimProps) {
  const step = String(props.step ?? "consent");
  const speed = Number(props.speed ?? 1);
  const curtain = useRef<THREE.Group>(null!);
  const ticks = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Stage", STEP_TXT[step] ?? ""], ["Rule", "Consent first, always"]]} />
      <SimCanvas cameraPosition={[0, 3.6, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* privacy screen */}
        <group ref={curtain} position={[-3.4, 0, 0.5]}>
          {[0, 1, 2].map((i) => (
            <mesh key={i} position={[(i - 1) * 1.5, 1.6, i === 1 ? 0.3 : 0]} rotation={[0, i === 1 ? 0.35 : 0, 0]} castShadow>
              <boxGeometry args={[1.5, 3.2, 0.08]} />
              <meshStandardMaterial color="#0ea5e9" transparent opacity={0.85} roughness={0.7} />
            </mesh>
          ))}
          <Label text="PRIVACY SCREEN" position={[0, 3.7, 0]} size={0.55} color="#7dd3fc" />
        </group>
        {/* examination couch */}
        <group position={[0.4, 0, 0]}>
          <mesh position={[0, 0.9, 0]} castShadow>
            <boxGeometry args={[3.4, 0.35, 1.8]} />
            <meshStandardMaterial color="#e0f2fe" roughness={0.8} />
          </mesh>
          <mesh position={[-1.2, 1.25, 0]} rotation={[0, 0, 0.5]}>
            <boxGeometry args={[1, 0.3, 1.7]} />
            <meshStandardMaterial color="#bae6fd" roughness={0.8} />
          </mesh>
          {[[-1.4, -0.7], [1.4, -0.7], [-1.4, 0.7], [1.4, 0.7]].map(([x, z]) => (
            <mesh key={`${x}${z}`} position={[x, 0.4, z]}>
              <boxGeometry args={[0.14, 0.8, 0.14]} />
              <meshStandardMaterial color="#64748b" roughness={0.7} />
            </mesh>
          ))}
          <Label text="EXAM COUCH" position={[0, 2.4, 0]} size={0.55} />
        </group>
        {/* doctor figure */}
        <group position={[4.4, 0, 0]}>
          <mesh position={[0, 0.8, 0]} castShadow>
            <capsuleGeometry args={[0.45, 1, 6, 14]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.7} />
          </mesh>
          <mesh position={[0, 2, 0]} castShadow>
            <sphereGeometry args={[0.38, 18, 18]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
          <Label text="DOCTOR" position={[0, 2.9, 0]} size={0.55} />
        </group>
        {/* checklist board */}
        <group position={[4.4, 0, -2.6]}>
          <mesh position={[0, 2.4, 0]} castShadow>
            <boxGeometry args={[3.2, 3.4, 0.12]} />
            <meshStandardMaterial color="#1e293b" roughness={0.8} />
          </mesh>
          <group ref={ticks}>
            {STEPS.map((s, i) => (
              <group key={s} position={[0, 3.5 - i * 0.75, 0.1]}>
                <mesh position={[-1.1, 0, 0]}>
                  <boxGeometry args={[0.34, 0.34, 0.05]} />
                  <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.7} />
                </mesh>
                <Label text={STEP_TXT[s]} position={[0.35, 0, 0]} size={0.42} color="#e2e8f0" />
              </group>
            ))}
          </group>
          <Label text="CHECKLIST" position={[0, 4.5, 0]} size={0.55} color="#22c55e" />
        </group>
        <Animator curtain={curtain} ticks={ticks} elapsed={elapsed} speed={speed} step={step} />
      </SimCanvas>
    </div>
  );
}
