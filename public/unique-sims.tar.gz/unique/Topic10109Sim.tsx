// Adrenergic drugs: adrenaline surges from the adrenal gland — the heart beats
// faster and harder, pupils dilate: the fight-or-flight response.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "adr", label: "Adrenaline level", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Adrenergic drugs",
  blurb: "Adrenaline surges from the adrenal gland — heart beats faster and harder, pupils dilate: fight-or-flight.",
};

const N_DOTS = 8;

function Animator({ heart, pupil, dots, elapsed, level, setTick }: {
  heart: React.RefObject<THREE.Group>;
  pupil: React.RefObject<THREE.Mesh>;
  dots: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  level: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = level / 100;
    const rate = 1.2 + k * 4; // beats per second
    const beat = Math.pow(Math.max(0, Math.sin(t * rate * Math.PI * 2)), 3);
    if (heart.current) {
      const s = 1 + beat * (0.12 + k * 0.15);
      heart.current.scale.set(s, 2 - s > 0 ? 1 / Math.sqrt(s) : 1, s);
    }
    if (pupil.current) {
      const ps = 0.16 + k * 0.22;
      pupil.current.scale.setScalar(ps / 0.16);
    }
    dots.current.forEach((d, i) => {
      if (!d) return;
      const f = (t * (0.3 + k * 0.9) + i / N_DOTS) % 1;
      d.position.set(-4.5 + f * 4.2, 2.6 - f * 1.4 + Math.sin(f * 9 + i) * 0.2, 0);
      ((d as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = 0.35 + k * 0.65;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(t * 10)); }
  });
  return null;
}

export function Topic10109Sim(props: SimProps) {
  const level = Number(props.adr ?? 60);
  const showLabels = String(props.detail ?? "on") === "on";
  const heart = useRef<THREE.Group>(null!);
  const pupil = useRef<THREE.Mesh>(null!);
  const dots = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const k = level / 100;
  const bpm = Math.round((1.2 + k * 4) * 60);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Heart rate", `${bpm} bpm`],
          ["Pupil", k > 0.66 ? "dilated" : k > 0.33 ? "normal" : "constricted"],
          ["Blood pressure", k > 0.66 ? "rising ↑" : "steady"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* kidney + adrenal gland */}
        <group position={[-4.5, 1.6, 0]}>
          <mesh scale={[0.55, 0.85, 0.55]} castShadow>
            <sphereGeometry args={[0.8, 20, 16]} />
            <meshStandardMaterial color="#7f1d1d" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.85, 0]} scale={[1, 0.5, 1]} castShadow>
            <sphereGeometry args={[0.42, 16, 12]} />
            <meshStandardMaterial color="#facc15" emissive="#a16207" emissiveIntensity={0.6} />
          </mesh>
        </group>
        {showLabels && <Label text="adrenal gland" position={[-4.5, 3.3, 0]} color="#fde047" />}

        {/* adrenaline molecules travelling to the heart */}
        {Array.from({ length: N_DOTS }).map((_, i) => (
          <mesh key={i} ref={(m) => { dots.current[i] = m; }}>
            <sphereGeometry args={[0.13, 10, 8]} />
            <meshStandardMaterial color="#facc15" emissive="#eab308" emissiveIntensity={1} transparent />
          </mesh>
        ))}
        {showLabels && <Label text="adrenaline" position={[-2.4, 2.9, 0]} size={0.45} color="#fde047" />}

        {/* heart: two ventricles + aorta */}
        <group ref={heart} position={[1.5, 1.3, 0]}>
          <mesh position={[-0.35, 0, 0]} castShadow>
            <sphereGeometry args={[0.75, 24, 18]} />
            <meshStandardMaterial color="#dc2626" roughness={0.45} />
          </mesh>
          <mesh position={[0.35, 0.1, 0]} castShadow>
            <sphereGeometry args={[0.65, 24, 18]} />
            <meshStandardMaterial color="#ef4444" roughness={0.45} />
          </mesh>
          <mesh position={[0, 1.05, 0]}>
            <cylinderGeometry args={[0.22, 0.3, 0.9, 12]} />
            <meshStandardMaterial color="#b91c1c" roughness={0.5} />
          </mesh>
        </group>
        {showLabels && <Label text={`heart — ${bpm} bpm`} position={[1.5, 3.1, 0]} color="#fca5a5" />}

        {/* eye with dilating pupil */}
        <group position={[4.6, 1.6, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.7, 24, 18]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.35} />
          </mesh>
          <mesh ref={pupil} position={[0, 0, 0.62]}>
            <sphereGeometry args={[0.16, 16, 12]} />
            <meshStandardMaterial color="#020617" roughness={0.2} />
          </mesh>
        </group>
        {showLabels && <Label text="pupil dilates" position={[4.6, 2.9, 0]} color="#e2e8f0" />}

        <Animator heart={heart} pupil={pupil} dots={dots} elapsed={elapsed} level={level} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
