"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Fluoride dose", kind: "slider", min: 0, max: 4, step: 0.5, default: 1, unit: "ppm" },
  { key: "source", label: "Source", kind: "select", min: 0, max: 0, step: 1, default: "toothpaste", options: ["toothpaste", "water", "varnish"] },
];

export const UNIQUE_META = {
  title: "Fluorides: systemic and topical, fluorosis",
  blurb: "Tooth cross-section: fluoride ions lock into enamel to build an acid-proof shield — too much leaves brown fluorosis mottling.",
};

const SOURCES: Record<string, { name: string; color: string }> = {
  toothpaste: { name: "Toothpaste", color: "#7dd3fc" },
  water: { name: "Water fluoridation", color: "#38bdf8" },
  varnish: { name: "Fluoride varnish", color: "#fbbf24" },
};

function FluorideIons({ dose, color }: { dose: number; color: string }) {
  const pts = useRef<THREE.Points>(null!);
  const t = useRef(Math.random() * 5);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(36 * 3), 3));
    return g;
  }, []);
  const count = Math.round(dose * 9);
  useFrame((_, delta) => {
    t.current += delta * (0.5 + dose * 0.3);
    if (!pts.current) return;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < 36; i++) {
      const f = (t.current * 0.4 + i / 36) % 1;
      const landed = f > 0.7;
      const x = -3 + (i % 9) * 0.75;
      pos.setXYZ(
        i,
        x + Math.sin(i * 3) * 0.2,
        landed ? 1.55 : 3.2 - f * 2.4,
        0.4 + Math.cos(i * 2) * 0.5
      );
      (pts.current.material as THREE.PointsMaterial).opacity = i < count ? 0.95 : 0.06;
    }
    pos.needsUpdate = true;
  });
  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial color={color} size={0.15} transparent />
    </points>
  );
}

function Scene({ dose, source }: { dose: number; source: string }) {
  const shield = useRef<THREE.Mesh>(null!);
  const t = useRef(0);
  const s = SOURCES[source] ?? SOURCES.toothpaste;
  const fluorosis = dose > 2.5;

  useFrame((_, delta) => {
    t.current += delta;
    if (shield.current) {
      const m = shield.current.material as THREE.MeshStandardMaterial;
      m.opacity = Math.min(0.65, 0.12 + dose * 0.14) + Math.sin(t.current * 2) * 0.03;
    }
  });

  const spots = useMemo(() => {
    const arr: [number, number][] = [];
    for (let i = 0; i < 12; i++) arr.push([(Math.random() - 0.5) * 2.2, 0.9 + Math.random() * 0.9]);
    return arr;
  }, []);

  return (
    <group>
      {/* tooth cross-section: dentin core */}
      <mesh position={[0, 0.2, 0]}>
        <cylinderGeometry args={[0.85, 1.05, 2.2, 20]} />
        <meshStandardMaterial color="#f5d78e" roughness={0.5} />
      </mesh>
      {/* enamel cap */}
      <mesh position={[0, 1.05, 0]}>
        <cylinderGeometry args={[1.0, 1.02, 0.75, 20]} />
        <meshStandardMaterial color="#fdfbf3" roughness={0.2} transparent opacity={0.92} />
      </mesh>
      {/* fluoride shield layer */}
      <mesh ref={shield} position={[0, 1.45, 0]}>
        <cylinderGeometry args={[1.06, 1.06, 0.12, 20]} />
        <meshStandardMaterial color={s.color} transparent opacity={0.4} roughness={0.15} emissive={s.color} emissiveIntensity={0.4} />
      </mesh>
      {/* pulp */}
      <mesh position={[0, -0.35, 0]}>
        <cylinderGeometry args={[0.25, 0.3, 1.6, 12]} />
        <meshStandardMaterial color="#ef4444" roughness={0.5} />
      </mesh>
      {/* root */}
      <mesh position={[0, -1.6, 0]}>
        <coneGeometry args={[0.7, 1.2, 16]} />
        <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
      </mesh>

      <Label text="Enamel" position={[1.9, 1.1, 0]} size={0.42} color="#fefce8" />
      <Label text="Fluoride shield (fluorapatite)" position={[2.3, 1.75, 0]} size={0.42} color={s.color} />
      <Label text="Dentin" position={[1.9, 0.1, 0]} size={0.42} color="#fde68a" />
      <Label text="Pulp" position={[1.9, -0.6, 0]} size={0.42} color="#fca5a5" />

      <FluorideIons dose={dose} color={s.color} />
      <Label text={`${s.name} — F⁻ ions`} position={[-2.8, 3.2, 0]} size={0.45} color={s.color} />

      {/* fluorosis mottling at excess dose */}
      {fluorosis &&
        spots.map(([x, y], i) => (
          <mesh key={i} position={[x, y, 0.95]}>
            <circleGeometry args={[0.12, 10]} />
            <meshStandardMaterial color="#92400e" roughness={0.9} />
          </mesh>
        ))}
      {fluorosis && <Label text="Fluorosis — brown mottling (too much!)" position={[0, -2.8, 0]} size={0.48} color="#fb923c" />}
      {!fluorosis && dose > 0.2 && <Label text="Enamel hardening — cavity protection ✓" position={[0, -2.8, 0]} size={0.45} color="#86efac" />}
      {dose <= 0.2 && <Label text="No fluoride — enamel vulnerable" position={[0, -2.8, 0]} size={0.45} color="#94a3b8" />}
    </group>
  );
}

export function Topic10423Sim(props: SimProps) {
  const dose = Number(props.dose ?? 1);
  const source = String(props.source ?? "toothpaste");
  const s = SOURCES[source] ?? SOURCES.toothpaste;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Source", s.name], ["Dose", `${dose} ppm`], ["Status", dose > 2.5 ? "Excess — fluorosis risk" : dose > 0.2 ? "Optimal" : "Deficient"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 9]} target={[0, 0.3, 0]}>
        <Scene dose={dose} source={source} />
      </SimCanvas>
    </div>
  );
}
