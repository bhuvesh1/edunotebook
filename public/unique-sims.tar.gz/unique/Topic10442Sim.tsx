"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "proc", label: "Procedure", kind: "select", min: 0, max: 0, step: 1, default: "repair", options: ["repair", "reline", "rebase"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Denture repairs, relining and rebasing",
  blurb: "A cracked denture gets glued with pink repair resin — or a fresh reline layer hugs the shrunken gum again.",
};

const INFO: Record<string, { name: string; note: string; color: string }> = {
  repair: { name: "Repair", note: "Crack glued with self-cure acrylic", color: "#f472b6" },
  reline: { name: "Reline", note: "New soft layer inside — fits the changed gum", color: "#7dd3fc" },
  rebase: { name: "Rebase", note: "Whole base replaced, teeth kept", color: "#a78bfa" },
};

function Scene({ proc, speed }: { proc: string; speed: number }) {
  const t = useRef(0);
  const resin = useRef<THREE.Mesh>(null!);
  const layer = useRef<THREE.Mesh>(null!);
  const info = INFO[proc] ?? INFO.repair;

  useFrame((_, delta) => {
    t.current += delta * speed;
    if (proc === "repair" && resin.current) {
      const s = Math.min(1, (t.current % 6) / 3);
      resin.current.scale.set(1, s, 1);
      (resin.current.material as THREE.MeshStandardMaterial).opacity = 0.4 + s * 0.6;
    }
    if ((proc === "reline" || proc === "rebase") && layer.current) {
      const s = Math.min(1, (t.current % 6) / 3);
      layer.current.scale.y = Math.max(0.05, s);
      (layer.current.material as THREE.MeshStandardMaterial).opacity = 0.3 + s * 0.65;
    }
  });

  const teeth: { x: number; z: number }[] = [];
  const n = 7;
  for (let i = 0; i < n; i++) {
    const a = Math.PI * (0.12 + (0.76 * i) / (n - 1));
    teeth.push({ x: Math.cos(a) * 1.9, z: Math.sin(a) * 1.9 });
  }

  return (
    <group>
      {/* denture base */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[1.9, 0.42, 12, 32, Math.PI]} />
        <meshStandardMaterial color={proc === "rebase" ? "#a78bfa" : "#f472b6"} roughness={0.5} />
      </mesh>
      {teeth.map((tt, i) => (
        <mesh key={i} position={[tt.x, -0.5, tt.z]}>
          <boxGeometry args={[0.4, 0.5, 0.45]} />
          <meshStandardMaterial color="#fdfbf3" roughness={0.3} />
        </mesh>
      ))}

      {/* crack line */}
      {proc === "repair" && (
        <group position={[0.9, 0, 1.35]} rotation={[0, -0.5, 0.15]}>
          {[0, 1, 2].map((i) => (
            <mesh key={i} position={[i * 0.12 - 0.12, i * 0.18 - 0.1, 0]}>
              <boxGeometry args={[0.07, 0.35, 0.1]} />
              <meshStandardMaterial color="#1e293b" roughness={0.9} />
            </mesh>
          ))}
          <Label text="Fracture line" position={[0, 0.8, 0]} size={0.4} color="#fca5a5" />
        </group>
      )}

      {/* repair resin filling the crack */}
      {proc === "repair" && (
        <mesh ref={resin} position={[0.9, 0.05, 1.35]} rotation={[0, -0.5, 0.15]}>
          <boxGeometry args={[0.45, 0.9, 0.35]} />
          <meshStandardMaterial color="#fb7185" transparent opacity={0.8} roughness={0.4} />
        </mesh>
      )}

      {/* reline / rebase new layer */}
      {(proc === "reline" || proc === "rebase") && (
        <mesh ref={layer} position={[0, 0.28, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[1.9, proc === "rebase" ? 0.42 : 0.2, 10, 32, Math.PI]} />
          <meshStandardMaterial color={proc === "reline" ? "#38bdf8" : "#a78bfa"} transparent opacity={0.7} roughness={0.4} />
        </mesh>
      )}
      {proc === "reline" && <Label text="New soft reline layer" position={[2.6, 0.5, 0]} size={0.42} color="#7dd3fc" />}
      {proc === "rebase" && <Label text="Entire base replaced" position={[2.6, 0.5, 0]} size={0.42} color="#c4b5fd" />}

      {/* gum underneath (shrunken) */}
      <mesh position={[0, 0.9, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[1.9, 0.35, 10, 28, Math.PI]} />
        <meshStandardMaterial color="#e0788a" roughness={0.6} transparent opacity={0.7} />
      </mesh>
      <Label text="Resorbed ridge" position={[-2.8, 0.9, 0]} size={0.4} color="#fda4af" />

      <Label text={info.name} position={[0, 3.2, 0]} size={0.65} color={info.color} />
      <Label text={info.note} position={[0, -2.4, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10442Sim(props: SimProps) {
  const proc = String(props.proc ?? "repair");
  const speed = Number(props.speed ?? 1);
  const info = INFO[proc] ?? INFO.repair;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Procedure", info.name], ["Material", proc === "repair" ? "Self-cure acrylic" : proc === "reline" ? "Soft liner" : "Heat-cure acrylic"], ["Time", proc === "repair" ? "Same day" : "1–2 days"]]} />
      <SimCanvas cameraPosition={[0, 2, 10]} target={[0, 0.2, 0]}>
        <Scene proc={proc} speed={speed} />
      </SimCanvas>
    </div>
  );
}
