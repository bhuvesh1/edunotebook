// Exercise physiology & temperature regulation — an exercising figure whose
// core temperature climbs with intensity; sweat droplets cool it down while
// the thermometer and shivering/sweating responses play out.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "intensity", label: "Exercise intensity", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.6, unit: "" },
  { key: "ambient", label: "Ambient temperature", kind: "slider", min: 5, max: 45, step: 1, default: 30, unit: "°C" },
];

export const UNIQUE_META = {
  title: "Exercise & Temperature Regulation",
  blurb: "Crank up exercise intensity: core temperature climbs, sweat pours, and the body fights to hold 37°C.",
};

function Animator({
  runner, sweat, thermoMercury, elapsed, intensity, speed,
}: {
  runner: React.RefObject<THREE.Group>;
  sweat: React.RefObject<THREE.Group>;
  thermoMercury: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  intensity: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // running figure bobs faster with intensity
    if (runner.current) {
      runner.current.position.y = Math.abs(Math.sin(t * (2 + intensity * 8))) * 0.45 * Math.min(1, intensity + 0.1);
      runner.current.children.forEach((m, i) => {
        if (m.userData.limb) {
          m.rotation.x = Math.sin(t * (2 + intensity * 8) + (m.userData.phase ?? 0)) * 0.9 * Math.min(1, intensity + 0.15);
        }
      });
    }
    if (sweat.current) {
      sweat.current.children.forEach((m, i) => {
        const ph = ((t * (0.5 + intensity) + i / 10) % 1 + 1) % 1;
        m.position.y = 3.6 - ph * 2.2;
        m.visible = intensity > 0.25;
        const s = 0.6 + intensity * 0.8;
        m.scale.setScalar(s);
      });
    }
    if (thermoMercury.current) {
      const target = 0.35 + intensity * 0.65;
      const cur = thermoMercury.current.userData.h ?? target;
      const nh = cur + (target - cur) * Math.min(1, delta * 1.5);
      thermoMercury.current.userData.h = nh;
      thermoMercury.current.scale.y = nh;
      thermoMercury.current.position.y = 0.6 + nh * 1.5;
    }
  });
  return null;
}

export function Topic10057Sim(props: SimProps) {
  const intensity = Number(props.intensity ?? 0.6);
  const ambient = Number(props.ambient ?? 30);
  const speed = 1;
  const runner = useRef<THREE.Group>(null!);
  const sweat = useRef<THREE.Group>(null!);
  const thermoMercury = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  // core temp model: rises with intensity & ambient, sweating caps it
  const sweatCooling = Math.min(1, intensity) * 1.8;
  const core = 37 + intensity * 2.2 + Math.max(0, (ambient - 30)) * 0.06 - sweatCooling * Math.min(1, intensity);
  const coreColor = core > 38.5 ? "#fca5a5" : core < 36.5 ? "#7dd3fc" : "#86efac";
  const response = intensity > 0.7 ? "sweating heavily 💦" : intensity > 0.3 ? "sweating, vessels dilated" : ambient < 15 ? "shivering 🥶" : "at rest — balanced";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Core temp", `${core.toFixed(1)}°C`],
          ["Response", response],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* treadmill */}
        <mesh position={[-2.5, 0.15, 0]} receiveShadow>
          <boxGeometry args={[5.5, 0.3, 2.2]} />
          <meshStandardMaterial color="#1e293b" roughness={0.8} />
        </mesh>
        <mesh position={[-2.5, 0.32, 0]}>
          <boxGeometry args={[5.3, 0.04, 2.0]} />
          <meshStandardMaterial color="#334155" roughness={0.7} />
        </mesh>

        {/* running figure */}
        <group ref={runner} position={[-2.5, 0.4, 0]}>
          {/* head */}
          <mesh position={[0, 4.1, 0]} castShadow>
            <sphereGeometry args={[0.32, 14, 14]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.55} />
          </mesh>
          {/* torso */}
          <mesh position={[0, 3.2, 0]} castShadow>
            <capsuleGeometry args={[0.3, 0.9, 6, 10]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.55} />
          </mesh>
          {/* arms (limbs swing) */}
          {[-1, 1].map((s) => (
            <mesh key={`a${s}`} position={[s * 0.45, 3.5, 0]} ref={(m) => { if (m) { m.userData.limb = true; m.userData.phase = s; } }}
              castShadow>
              <capsuleGeometry args={[0.11, 0.8, 4, 8]} />
              <meshStandardMaterial color="#fcd9b8" roughness={0.55} />
            </mesh>
          ))}
          {/* legs (limbs swing opposite) */}
          {[-1, 1].map((s) => (
            <mesh key={`l${s}`} position={[s * 0.2, 2.2, 0]} ref={(m) => { if (m) { m.userData.limb = true; m.userData.phase = s + Math.PI; } }}
              castShadow>
              <capsuleGeometry args={[0.13, 0.9, 4, 8]} />
              <meshStandardMaterial color="#1e3a8a" roughness={0.55} />
            </mesh>
          ))}
        </group>
        {/* sweat droplets */}
        <group ref={sweat}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i} position={[-2.5 + ((i * 1.7) % 3 - 1) * 0.6, 3.6, ((i * 0.9) % 2 - 0.5)]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshStandardMaterial color="#7dd3fc" emissive="#0369a1" emissiveIntensity={0.5} />
            </mesh>
          ))}
        </group>
        <Label text="exercise intensity → heat production" position={[-2.5, 5.2, 0]} size={0.36} color="#f8fafc" />
        <Label text={response} position={[-2.5, -0.9, 0]} size={0.34} color={coreColor} />

        {/* skin blood vessels dilating */}
        <mesh position={[-5.6, 2.6, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.14 + intensity * 0.12, 0.14 + intensity * 0.12, 2.2, 10]} />
          <meshStandardMaterial color="#ef4444" roughness={0.45} />
        </mesh>
        <Label text="skin vessels dilate → radiate heat" position={[-5.6, 3.8, 0]} size={0.3} color="#fca5a5" />

        {/* thermometer */}
        <group position={[5.2, 0, 0]}>
          <mesh position={[0, 2.1, 0]} castShadow>
            <cylinderGeometry args={[0.3, 0.3, 3.4, 14]} />
            <meshStandardMaterial color="#e2e8f0" transparent opacity={0.4} roughness={0.3} />
          </mesh>
          <mesh ref={thermoMercury} position={[0, 0.6, 0]}>
            <cylinderGeometry args={[0.18, 0.18, 3.0, 12]} />
            <meshStandardMaterial color={core > 38.5 ? "#ef4444" : "#f97316"} emissive="#7f1d1d" emissiveIntensity={0.4} />
          </mesh>
          <mesh position={[0, 0.35, 0]}>
            <sphereGeometry args={[0.42, 14, 14]} />
            <meshStandardMaterial color="#ef4444" roughness={0.4} />
          </mesh>
          {[36, 37, 38, 39, 40].map((t, i) => (
            <Label key={t} text={`${t}°`} position={[0.75, 0.9 + i * 0.62, 0]} size={0.26} color="#94a3b8" />
          ))}
        </group>
        <Label text="core temperature" position={[5.2, 4.4, 0]} size={0.38} color="#f8fafc" />
        <Label text={`${core.toFixed(1)}°C`} position={[5.2, 5.1, 0]} size={0.44} color={coreColor} />

        {/* hypothalamus set point */}
        <group position={[0.6, 6.2, -1]}>
          <mesh castShadow>
            <sphereGeometry args={[0.5, 14, 14]} />
            <meshStandardMaterial color="#c084fc" roughness={0.45} />
          </mesh>
        </group>
        <Label text="hypothalamus: set point 37°C" position={[0.6, 7.2, -1]} size={0.32} color="#d8b4fe" />

        <Animator runner={runner} sweat={sweat} thermoMercury={thermoMercury}
          elapsed={elapsed} intensity={intensity} speed={speed} />
      </SimCanvas>
    </div>
  );
}
