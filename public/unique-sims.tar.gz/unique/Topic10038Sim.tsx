// CVS: hemodynamics & blood pressure regulation — a pulse wave travels down an
// elastic artery (wall bulging as it passes); a live BP gauge responds to
// cardiac output and peripheral resistance sliders.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "co", label: "Cardiac output", kind: "slider", min: 2, max: 10, step: 0.5, default: 5, unit: "L/min" },
  { key: "tpr", label: "Peripheral resistance", kind: "slider", min: 0.5, max: 2, step: 0.05, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "CVS: Hemodynamics & BP Regulation",
  blurb: "A pulse wave bulges down the artery while the gauge shows how cardiac output × resistance sets blood pressure.",
};

function Animator({
  waveRings, needle, elapsed, map, speed,
}: {
  waveRings: React.RefObject<THREE.Group>;
  needle: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  map: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (waveRings.current) {
      waveRings.current.children.forEach((m, i) => {
        const ph = ((t * 0.55 + i / 12) % 1 + 1) % 1;
        m.position.x = -5.5 + ph * 11;
        const bulge = Math.exp(-Math.pow((ph - 0.5) * 6, 2));
        m.scale.set(1 + 0.28 * bulge, 1 + 0.28 * bulge, 1);
      });
    }
    if (needle.current) {
      // gauge needle eases toward MAP target
      const target = THREE.MathUtils.clamp((map - 40) / 120, 0, 1);
      const cur = needle.current.userData.v ?? target;
      const nv = cur + (target - cur) * Math.min(1, delta * 3);
      needle.current.userData.v = nv;
      needle.current.rotation.z = Math.PI * 0.75 - nv * Math.PI * 1.5;
    }
  });
  return null;
}

export function Topic10038Sim(props: SimProps) {
  const co = Number(props.co ?? 5);
  const tpr = Number(props.tpr ?? 1);
  const speed = 1;
  const waveRings = useRef<THREE.Group>(null!);
  const needle = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  // MAP ≈ CO × TPR scaled (normal ~93 at CO 5, TPR 1)
  const map = 18.6 * co * tpr;
  const sys = Math.round(map * 1.35);
  const dia = Math.round(map * 0.78);
  const status = map < 70 ? "hypotension" : map > 110 ? "hypertension" : "normal";
  const statusColor = status === "normal" ? "#86efac" : "#fca5a5";

  const ticks = useMemo(() => Array.from({ length: 11 }).map((_, i) => i / 10), []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["BP", `${sys}/${dia} mmHg`],
          ["MAP", `${Math.round(map)} mmHg — ${status}`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* elastic artery with travelling pulse wave (rings bulge) */}
        <mesh position={[0, 2.4, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[1.05, 1.05, 11.6, 24, 1, true]} />
          <meshStandardMaterial color="#ef4444" roughness={0.45} side={THREE.DoubleSide} transparent opacity={0.5} />
        </mesh>
        <group ref={waveRings}>
          {Array.from({ length: 12 }).map((_, i) => (
            <mesh key={i} position={[-5.5, 2.4, 0]} rotation={[0, Math.PI / 2, 0]}>
              <torusGeometry args={[1.05, 0.1, 8, 24]} />
              <meshStandardMaterial color="#fca5a5" emissive="#7f1d1d" emissiveIntensity={0.5} roughness={0.4} />
            </mesh>
          ))}
        </group>
        {/* blood column shimmer */}
        <mesh position={[0, 2.4, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.8, 0.8, 11.5, 16, 1, true]} />
          <meshBasicMaterial color="#dc2626" transparent opacity={0.28} side={THREE.BackSide} />
        </mesh>
        <Label text="elastic artery" position={[0, 4.3, 0]} size={0.4} color="#f8fafc" />
        <Label text="pulse wave →" position={[-5.2, 1.15, 0]} size={0.32} color="#fca5a5" />
        <Label text="BP = CO × TPR" position={[0, 0.85, 0]} size={0.34} color="#fde68a" />

        {/* sphygmomanometer-style gauge */}
        <group position={[7.4, 2.2, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[1.5, 1.5, 0.35, 32]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.35} />
          </mesh>
          <mesh position={[0, 0, 0.19]}>
            <circleGeometry args={[1.28, 32]} />
            <meshStandardMaterial color="#0f172a" roughness={0.6} />
          </mesh>
          {ticks.map((f, i) => {
            const a = Math.PI * 0.75 - f * Math.PI * 1.5;
            return (
              <mesh key={i} position={[Math.cos(a) * 1.05, Math.sin(a) * 1.05, 0.2]} rotation={[0, 0, a - Math.PI / 2]}>
                <boxGeometry args={[0.05, i % 5 === 0 ? 0.22 : 0.12, 0.02]} />
                <meshBasicMaterial color={i > 7 ? "#f87171" : "#94a3b8"} />
              </mesh>
            );
          })}
          {/* green / red zones */}
          <mesh position={[0.62, -0.75, 0.2]} rotation={[0, 0, -0.5]}>
            <boxGeometry args={[0.35, 0.14, 0.02]} />
            <meshBasicMaterial color="#4ade80" />
          </mesh>
          <mesh ref={needle} position={[0, 0, 0.22]}>
            <boxGeometry args={[0.07, 1.05, 0.03]} />
            <meshBasicMaterial color="#fbbf24" />
          </mesh>
          <mesh position={[0, 0, 0.24]}>
            <sphereGeometry args={[0.1, 10, 10]} />
            <meshBasicMaterial color="#fbbf24" />
          </mesh>
        </group>
        <Label text="blood pressure gauge" position={[7.4, 4.3, 0]} size={0.38} color="#f8fafc" />
        <Label text={status} position={[7.4, 0.35, 0]} size={0.36} color={statusColor} />

        {/* baroreceptor feedback hint */}
        <group position={[-7.2, 2.2, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.55, 14, 14]} />
            <meshStandardMaterial color="#c084fc" roughness={0.45} />
          </mesh>
          {[-0.5, 0, 0.5].map((dy, i) => (
            <mesh key={i} position={[0.75 + i * 0.4, dy, 0]} rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.04, 0.04, 0.4, 6]} />
              <meshStandardMaterial color="#c084fc" roughness={0.5} />
            </mesh>
          ))}
        </group>
        <Label text="baroreceptors (carotid)" position={[-7.2, 3.4, 0]} size={0.3} color="#d8b4fe" />
        <Label text="sense stretch → adjust HR/TPR" position={[-7.2, 0.9, 0]} size={0.28} color="#94a3b8" />

        <Animator waveRings={waveRings} needle={needle} elapsed={elapsed} map={map} speed={speed} />
      </SimCanvas>
    </div>
  );
}
