// Arrhythmias, conduction blocks & valvular disease — a heart whose beat
// follows an ECG trace; the rhythm select switches between normal sinus,
// atrial fibrillation (chaotic), and heart block (slow, skipped beats).
// A mitral valve with floppy leaflets is shown for valvular disease.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "rhythm", label: "Rhythm", kind: "select", min: 0, max: 0, step: 1, default: "normal sinus", options: ["normal sinus", "atrial fibrillation", "heart block"] },
  { key: "valve", label: "Mitral valve", kind: "select", min: 0, max: 0, step: 1, default: "normal", options: ["normal", "prolapse", "stenosis"] },
];

export const UNIQUE_META = {
  title: "Arrhythmias & Valves",
  blurb: "The ECG trace drives the heartbeat — flip to atrial fibrillation or heart block and feel the chaos; plus a prolapsing mitral valve.",
};

// heartbeat intensity as a function of time for each rhythm
function beatAt(t: number, rhythm: string): number {
  if (rhythm === "atrial fibrillation") {
    // rapid irregular quiver
    return Math.max(0, Math.sin(t * 17) * 0.5 + Math.sin(t * 7.3) * 0.5) * (0.4 + 0.6 * Math.abs(Math.sin(t * 1.7)));
  }
  if (rhythm === "heart block") {
    // slow beat with dropped beats
    const ph = t % 3.2;
    if (ph > 0.5 && ph < 1.1) return 0; // dropped beat
    return Math.pow(Math.max(0, Math.sin((ph * Math.PI) / 0.5)), 2) * (ph < 0.6 ? 1 : 0);
  }
  // normal sinus: lub-dub
  const ph = t % 1.0;
  return Math.pow(Math.max(0, Math.sin((ph * Math.PI) / 0.35)), 2);
}

function ecgY(t: number, rhythm: string): number {
  if (rhythm === "atrial fibrillation") return Math.sin(t * 30) * 0.35 + Math.sin(t * 13) * 0.2;
  if (rhythm === "heart block") {
    const ph = t % 3.2;
    if (ph < 0.15) return 1.2;
    if (ph > 0.5 && ph < 1.1) return 0; // flatline gap
    if (ph > 1.1 && ph < 1.35) return 1.4;
    return Math.sin(ph * 20) * 0.12;
  }
  const ph = t % 1.0; // P-QRS-T
  if (ph < 0.12) return 0.35;
  if (ph > 0.18 && ph < 0.24) return 1.5;
  if (ph > 0.24 && ph < 0.3) return -0.5;
  if (ph > 0.45 && ph < 0.62) return 0.5;
  return 0;
}

function Animator({ heart, trace, dot, elapsed, rhythm }: {
  heart: React.RefObject<THREE.Group>;
  trace: React.RefObject<THREE.Group>;
  dot: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  rhythm: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (heart.current) {
      const b = beatAt(t, rhythm);
      heart.current.scale.set(1 + b * 0.07, 1 - b * 0.05, 1 + b * 0.07);
    }
    if (trace.current) {
      const n = trace.current.children.length;
      trace.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const tt = t - (n - 1 - i) * 0.06;
        m.position.y = 1.1 + ecgY(Math.max(0, tt), rhythm);
      });
    }
    if (dot.current) {
      const n = 60;
      const tt = t;
      dot.current.position.x = 5.6;
      dot.current.position.y = 1.1 + ecgY(tt, rhythm);
    }
  });
  return null;
}

export function Topic10216Sim(props: SimProps) {
  const rhythm = String(props.rhythm ?? "normal sinus");
  const valve = String(props.valve ?? "normal");
  const heart = useRef<THREE.Group>(null!);
  const trace = useRef<THREE.Group>(null!);
  const dot = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const ecgDots = useMemo(() => Array.from({ length: 60 }).map((_, i) => -0.4 + i * 0.1), []);
  const bad = rhythm !== "normal sinus";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Rhythm", rhythm], ["Pulse", rhythm === "heart block" ? "slow, drops beats" : rhythm === "atrial fibrillation" ? "rapid & irregular" : "steady 72/min"], ["Mitral valve", valve]]} />
      <SimCanvas cameraPosition={[0, 2.6, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* heart */}
        <group ref={heart}>
          <mesh position={[-3.4, 2.1, 0]} scale={[1, 1.25, 0.95]} castShadow>
            <sphereGeometry args={[1.7, 32, 26]} />
            <meshStandardMaterial color={bad ? "#f87171" : "#dc2626"} roughness={0.45} />
          </mesh>
        </group>

        {/* mitral valve leaflets */}
        <group position={[-3.4, 3.3, 0]}>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 0.42, 0, 0]} rotation={[0, 0, s * (valve === "prolapse" ? -0.9 : valve === "stenosis" ? 0.15 : -0.45)]}>
              <boxGeometry args={[0.85, 0.1, 0.7]} />
              <meshStandardMaterial color={valve === "normal" ? "#fbbf24" : "#ef4444"} roughness={0.5} emissive={valve === "normal" ? "#000" : "#7f1d1d"} emissiveIntensity={0.4} />
            </mesh>
          ))}
          <Label text={valve === "prolapse" ? "Prolapse — leaflets flop back" : valve === "stenosis" ? "Stenosis — stiff, narrow" : "Mitral valve"} position={[0, 1.2, 0]} size={0.46} color={valve === "normal" ? "#fde047" : "#fca5a5"} />
        </group>

        {/* ECG monitor */}
        <mesh position={[2.6, 1.1, -0.3]}>
          <boxGeometry args={[7.4, 3.6, 0.25]} />
          <meshStandardMaterial color="#0b1020" roughness={0.6} />
        </mesh>
        <group ref={trace}>
          {ecgDots.map((x, i) => (
            <mesh key={i} position={[2.6 + x, 1.1, -0.15]}>
              <sphereGeometry args={[0.055, 8, 8]} />
              <meshBasicMaterial color={bad ? "#ef4444" : "#22c55e"} />
            </mesh>
          ))}
        </group>
        <mesh ref={dot} position={[5.6, 1.1, -0.15]}>
          <sphereGeometry args={[0.11, 10, 10]} />
          <meshBasicMaterial color="#ffffff" />
        </mesh>
        <Label text="ECG" position={[2.6, 3.4, -0.3]} size={0.5} color={bad ? "#fca5a5" : "#86efac"} />
        <Label text={rhythm === "atrial fibrillation" ? "AF: atria quiver, clots can form → stroke risk" : rhythm === "heart block" ? "Block: signal stalls — may need a pacemaker" : "Normal sinus rhythm"} position={[2.6, -1.4, 0]} size={0.44} color="#94a3b8" />

        <Animator heart={heart} trace={trace} dot={dot} elapsed={elapsed} rhythm={rhythm} />
      </SimCanvas>
    </div>
  );
}
