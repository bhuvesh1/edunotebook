// Embryology: congenital anomalies and teratology — normal vs defective
// development side by side: neural tube closing normally vs spina bifida gap,
// and a heart with vs without a ventricular septal defect.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "anomaly", label: "Anomaly to inspect", kind: "select", min: 0, max: 0, step: 1, default: "spina", options: ["spina", "vsd", "cleft"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Embryology: Congenital Anomalies",
  blurb: "Compare normal development with spina bifida, a ventricular septal defect, or cleft palate.",
};

function Animator({
  alert, elapsed, speed,
}: {
  alert: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (alert.current) {
      alert.current.children.forEach((m) => {
        const mat = (m as THREE.Mesh).material as THREE.MeshBasicMaterial;
        mat.opacity = 0.35 + 0.45 * Math.abs(Math.sin(t * 3.5));
      });
    }
  });
  return null;
}

// a neural-tube segment: closed (normal) or with an open gap (spina bifida)
function NeuralSegment({ x, defective, label }: { x: number; defective: boolean; label: string }) {
  return (
    <group position={[x, 0, 0]}>
      {/* tube body */}
      <mesh position={[0, 1.9, 0]} rotation={[Math.PI / 2.6, 0, 0]} castShadow>
        <cylinderGeometry args={[0.55, 0.55, 3.6, 16, 1, defective]} />
        <meshStandardMaterial color={defective ? "#f87171" : "#38bdf8"} roughness={0.45}
          side={defective ? THREE.DoubleSide : THREE.FrontSide} />
      </mesh>
      {/* open neural folds when defective */}
      {defective && (
        <group>
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 0.75, 2.35, 0]} rotation={[0, 0, -s * 0.7]} castShadow>
              <boxGeometry args={[0.55, 0.9, 3.4]} />
              <meshStandardMaterial color="#f87171" roughness={0.5} />
            </mesh>
          ))}
          <mesh position={[0, 2.1, 0]}>
            <boxGeometry args={[0.9, 0.14, 3.4]} />
            <meshStandardMaterial color="#fecaca" emissive="#dc2626" emissiveIntensity={0.7} />
          </mesh>
        </group>
      )}
      <Label text={label} position={[0, 3.6, 0]} size={0.4} color="#f8fafc" />
      <Label text={defective ? "open neural tube — spina bifida" : "closed neural tube ✓"}
        position={[0, 0.6, 0]} size={0.32} color={defective ? "#fca5a5" : "#86efac"} />
    </group>
  );
}

// a heart: solid septum (normal) or septum with a glowing hole (VSD)
function HeartModel({ x, defective, label }: { x: number; defective: boolean; label: string }) {
  return (
    <group position={[x, 0, 0]}>
      <mesh position={[0, 1.9, 0]} castShadow scale={[1, 1.2, 0.9]}>
        <sphereGeometry args={[1.15, 22, 22]} />
        <meshStandardMaterial color={defective ? "#f87171" : "#f43f5e"} roughness={0.45} />
      </mesh>
      {/* ventricular septum */}
      <mesh position={[0, 1.5, 0]}>
        <boxGeometry args={[0.14, 1.7, 1.5]} />
        <meshStandardMaterial color="#9f1239" roughness={0.5} />
      </mesh>
      {defective && (
        <mesh position={[0, 1.5, 0]}>
          <sphereGeometry args={[0.34, 14, 14]} />
          <meshBasicMaterial color="#fef08a" />
        </mesh>
      )}
      <Label text={label} position={[0, 3.9, 0]} size={0.4} color="#f8fafc" />
      <Label text={defective ? "hole in septum — VSD" : "intact ventricular septum ✓"}
        position={[0, 0.35, 0]} size={0.32} color={defective ? "#fca5a5" : "#86efac"} />
    </group>
  );
}

// palate shelves: fused (normal) or gapped (cleft)
function PalateModel({ x, defective, label }: { x: number; defective: boolean; label: string }) {
  const gap = defective ? 0.55 : 0.02;
  return (
    <group position={[x, 0, 0]}>
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * (0.9 + gap), 2.2, 0]} rotation={[0, 0, s * -0.35]} castShadow>
          <boxGeometry args={[1.5, 0.35, 2.4]} />
          <meshStandardMaterial color={defective ? "#f87171" : "#fda4af"} roughness={0.5} />
        </mesh>
      ))}
      {defective && (
        <mesh position={[0, 2.2, 0]}>
          <boxGeometry args={[1.0, 0.1, 2.2]} />
          <meshBasicMaterial color="#fef08a" transparent opacity={0.8} />
        </mesh>
      )}
      <Label text={label} position={[0, 3.4, 0]} size={0.4} color="#f8fafc" />
      <Label text={defective ? "unfused shelves — cleft palate" : "fused palatal shelves ✓"}
        position={[0, 1.1, 0]} size={0.32} color={defective ? "#fca5a5" : "#86efac"} />
    </group>
  );
}

export function Topic10030Sim(props: SimProps) {
  const anomaly = String(props.anomaly ?? "spina");
  const speed = Number(props.speed ?? 1);
  const alert = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Teratology", "failure of fusion/closure"],
          ["Window", "weeks 3–8: organogenesis"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={alert}>
          {anomaly === "spina" && (
            <>
              <NeuralSegment x={-4} defective={false} label="normal" />
              <NeuralSegment x={4} defective label="spina bifida" />
            </>
          )}
          {anomaly === "vsd" && (
            <>
              <HeartModel x={-4} defective={false} label="normal" />
              <HeartModel x={4} defective label="VSD" />
            </>
          )}
          {anomaly === "cleft" && (
            <>
              <PalateModel x={-4} defective={false} label="normal" />
              <PalateModel x={4} defective label="cleft palate" />
            </>
          )}
        </group>
        {/* pulsing alert ring over the defect */}
        <mesh position={[4, 2.0, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[2.6, 0.07, 8, 40]} />
          <meshBasicMaterial color="#fbbf24" transparent opacity={0.5} />
        </mesh>

        <Animator alert={alert} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
