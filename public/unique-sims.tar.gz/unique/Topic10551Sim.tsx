// app/components/sims/unique/Topic10551Sim.tsx
// School dental health programs: a schoolhouse where a row of student
// teeth gets check-ups — healthy teeth earn green checkmarks, and a
// fluoride/sealant station protects molars.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "School Dental Health Programs",
  blurb: "The school dental camp rolls in: screenings, fluoride, and sealants for every student's smile.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Checkmark({ position }: { position: [number, number, number] }) {
  return (
    <group position={position} rotation={[0, 0, -0.5]}>
      <mesh>
        <boxGeometry args={[0.12, 0.5, 0.08]} />
        <meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={0.8} />
      </mesh>
      <mesh position={[0.2, 0.12, 0]} rotation={[0, 0, 1.1]}>
        <boxGeometry args={[0.12, 0.32, 0.08]} />
        <meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={0.8} />
      </mesh>
    </group>
  );
}

function Animator({ bus, checks, elapsed, speed }: {
  bus: RefObject<THREE.Group>; checks: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (bus.current) {
      // dental van drives in and parks
      const k = Math.min(t / 4, 1);
      bus.current.position.x = -9 + k * 9;
    }
    if (checks.current) {
      // checkmarks pop in one by one as screening proceeds
      checks.current.children.forEach((c, i) => {
        const on = t > 4 + i * 0.7;
        c.visible = on;
        if (on) c.scale.setScalar(Math.min(0.5 + (t - 4 - i * 0.7) * 2, 1));
      });
    }
  });
  return null;
}

const TEETH_X = [-2.4, -1.2, 0, 1.2, 2.4];

export function Topic10551Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const bus = useRef<THREE.Group>(null!);
  const checks = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Program", "school dental camp"],
          ["Services", "screening → fluoride → sealants"],
          ["Coverage", "whole school, every year"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 15]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* schoolhouse */}
        <group position={[-5.5, 0, -2.5]}>
          <mesh position={[0, 1.5, 0]} castShadow>
            <boxGeometry args={[5, 3, 3.5]} />
            <meshStandardMaterial color="#f59e0b" roughness={0.6} />
          </mesh>
          <mesh position={[0, 3.6, 0]} castShadow>
            <coneGeometry args={[3.6, 1.6, 4]} />
            <meshStandardMaterial color="#b45309" roughness={0.6} />
          </mesh>
          <mesh position={[0, 1.2, 1.8]}>
            <boxGeometry args={[1.2, 1.8, 0.1]} />
            <meshStandardMaterial color="#78350f" roughness={0.6} />
          </mesh>
          {showLabels && (
            <Text position={[0, 4.9, 0]} fontSize={0.5} color="#fde68a" anchorX="center" anchorY="middle">
              SCHOOL
            </Text>
          )}
        </group>

        {/* dental van driving in */}
        <group ref={bus} position={[-9, 0, 2.5]}>
          <mesh position={[0, 1.1, 0]} castShadow>
            <boxGeometry args={[3.4, 1.8, 1.8]} />
            <meshStandardMaterial color="#ffffff" roughness={0.4} />
          </mesh>
          <mesh position={[0, 1.3, 0.95]}>
            <boxGeometry args={[1.2, 0.6, 0.06]} />
            <meshStandardMaterial color="#38bdf8" emissive="#0ea5e9" emissiveIntensity={0.4} />
          </mesh>
          {[-1.1, 1.1].map((x, i) => (
            <mesh key={i} position={[x, 0.35, 0.95]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[0.35, 0.35, 0.2, 14]} />
              <meshStandardMaterial color="#1e293b" roughness={0.7} />
            </mesh>
          ))}
          {showLabels && (
            <Text position={[0, 2.5, 0]} fontSize={0.4} color="#0ea5e9" anchorX="center" anchorY="middle">
              DENTAL CAMP
            </Text>
          )}
        </group>

        {/* row of student teeth awaiting screening */}
        {TEETH_X.map((x, i) => (
          <group key={i} position={[x, 1.3, 2.5]}>
            <mesh castShadow>
              <boxGeometry args={[0.8, 1.0, 0.7]} />
              <meshStandardMaterial color="#fefce8" roughness={0.3} />
            </mesh>
            {/* one molar gets a sealant shield */}
            {i === 3 && (
              <mesh position={[0, 0.65, 0]}>
                <boxGeometry args={[0.7, 0.18, 0.6]} />
                <meshStandardMaterial color="#7dd3fc" emissive="#0ea5e9" emissiveIntensity={0.6} transparent opacity={0.9} />
              </mesh>
            )}
          </group>
        ))}

        {/* checkmarks appearing over screened teeth */}
        <group ref={checks}>
          {TEETH_X.map((x, i) => (
            <group key={i} position={[x, 2.6, 2.5]} visible={false}>
              <Checkmark position={[0, 0, 0]} />
            </group>
          ))}
        </group>

        {/* fluoride station */}
        <group position={[4.8, 0, 2.5]}>
          <mesh position={[0, 0.9, 0]} castShadow>
            <cylinderGeometry args={[0.5, 0.6, 1.8, 14]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.4} />
          </mesh>
          {showLabels && (
            <Text position={[0, 2.3, 0]} fontSize={0.34} color="#7dd3fc" anchorX="center" anchorY="middle">
              fluoride
            </Text>
          )}
        </group>

        {showLabels && (
          <Label p={[0, 5.8, 2.5]} size={0.36} color="#e2e8f0">screening camp → every smile checked</Label>
        )}

        <Animator bus={bus} checks={checks} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
