"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "peptic ulcer", options: ["normal", "peptic ulcer", "ulcerative colitis", "colorectal tumor"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "GI Pathology: Ulcer to Tumors",
  blurb: "A stomach and colon that develop a peptic ulcer, ulcerative colitis patches, or a colorectal tumor.",
};

function Animator({ root, lesion, patches, tumor, elapsed, speed, ulcer, uc, crc }: { root: RefObject<THREE.Group>; lesion: RefObject<THREE.Group>; patches: RefObject<THREE.Group>; tumor: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; ulcer: boolean; uc: boolean; crc: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (lesion.current) {
      lesion.current.visible = ulcer;
      lesion.current.scale.setScalar(1 + 0.12 * Math.sin(t * 3));
    }
    if (patches.current) {
      patches.current.visible = uc;
      patches.current.children.forEach((m, i) => {
        ((m as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = 0.6 + 0.4 * Math.sin(t * 2.5 + i);
      });
    }
    if (tumor.current) {
      tumor.current.visible = crc;
      tumor.current.scale.setScalar(1 + 0.08 * Math.sin(t * 2));
      tumor.current.rotation.y = t * 0.6;
    }
    if (root.current) root.current.rotation.y = Math.sin(t * 0.2) * 0.1;
  });
  return null;
}

export function Topic10097Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const cond = String(props.cond ?? "peptic ulcer");
  const ulcer = cond === "peptic ulcer";
  const uc = cond === "ulcerative colitis";
  const crc = cond === "colorectal tumor";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const lesion = useRef<THREE.Group>(null!);
  const patches = useRef<THREE.Group>(null!);
  const tumor = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", cond],
          ["Site", ulcer ? "gastric antrum" : uc ? "rectum \u2192 colon (continuous)" : crc ? "sigmoid colon" : "\u2014"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[-2.4, 3.4, 0]} rotation={[0, 0, 0.5]} castShadow>
            <cylinderGeometry args={[0.3, 0.3, 1.4, 12]} /><meshStandardMaterial color="#fda4af" roughness={0.55} />
          </mesh>
          <mesh position={[-2.2, 2.4, 0]} scale={[1.35, 1, 1]} castShadow>
            <sphereGeometry args={[1.15, 24, 24]} /><meshStandardMaterial color="#f9a8d4" roughness={0.55} />
          </mesh>
          <mesh position={[-1.4, 1.5, 0]} rotation={[0, 0, -0.7]} castShadow>
            <cylinderGeometry args={[0.28, 0.28, 1.2, 12]} /><meshStandardMaterial color="#fda4af" roughness={0.55} />
          </mesh>
          <Label text="stomach" position={[-3.9, 2.6, 0]} size={0.42} color="#f9a8d4" />
          <mesh position={[2.6, 1.5, 0]} rotation={[0, 0, Math.PI / 2.3]} castShadow>
            <cylinderGeometry args={[0.55, 0.55, 4.6, 16]} /><meshStandardMaterial color="#fbbf24" roughness={0.55} />
          </mesh>
          <Label text="colon" position={[4.4, 0.9, 0]} size={0.42} color="#fbbf24" />
          <group ref={lesion} visible={false} position={[-2.2, 2.1, 1.05]}>
            <mesh><cylinderGeometry args={[0.42, 0.5, 0.22, 16]} /><meshStandardMaterial color="#7f1d1d" emissive="#ef4444" emissiveIntensity={0.7} /></mesh>
            <mesh position={[0, 0.14, 0]}><torusGeometry args={[0.5, 0.1, 10, 20]} /><meshStandardMaterial color="#fca5a5" roughness={0.6} /></mesh>
          </group>
          <group ref={patches} visible={false}>
            {[1.4, 2.4, 3.4].map((x, i) => (
              <mesh key={i} position={[x, 1.62, 0.5]}>
                <sphereGeometry args={[0.42, 14, 14]} />
                <meshStandardMaterial color="#ef4444" emissive="#b91c1d" emissiveIntensity={0.6} transparent opacity={0.85} />
              </mesh>
            ))}
          </group>
          <mesh ref={tumor} visible={false} position={[3.1, 1.5, 0]} castShadow>
            <icosahedronGeometry args={[0.8, 1]} /><meshStandardMaterial color="#991b1b" emissive="#7f1d1d" emissiveIntensity={0.5} roughness={0.6} flatShading />
          </mesh>
          <Label text={ulcer ? "peptic ulcer \u2014 mucosal crater" : uc ? "ulcerative colitis \u2014 continuous inflammation" : crc ? "colorectal tumor \u2014 malignant mass" : "healthy gut"} position={[0, 5, 0]} size={0.46} color={cond === "normal" ? "#4ade80" : "#f87171"} />
        </group>
        <Animator root={root} lesion={lesion} patches={patches} tumor={tumor} elapsed={elapsed} speed={speed} ulcer={ulcer} uc={uc} crc={crc} />
      </SimCanvas>
    </div>
  );
}
