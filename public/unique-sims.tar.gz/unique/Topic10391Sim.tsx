"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "mat", label: "Material", kind: "select", min: 0, max: 0, step: 1, default: "mta", options: ["resin", "caoh", "mta"] },
  { key: "cure", label: "Cure / set", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.5, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Dental cements: resin cements, calcium hydroxide, MTA",
  blurb: "Three pulp-friendly heroes: light-cured resin cement, calcium hydroxide pulp cap, and MTA sealing a root end.",
};

const MATS: Record<string, { name: string; color: string; note: string; light: boolean }> = {
  resin: { name: "Resin cement", color: "#fde68a", note: "dual-cure: blue light + chemical set", light: true },
  caoh: { name: "Calcium hydroxide", color: "#fefce8", note: "alkaline pH ~12 — calms the pulp, forms dentin bridge", light: false },
  mta: { name: "MTA", color: "#d6d3d1", note: "seals root ends, sets even in moisture", light: false },
};

function MaterialScene({ mat, cure, speed, showLabels }: { mat: string; cure: number; speed: number; showLabels: boolean }) {
  const beam = useRef<THREE.Mesh>(null!);
  const glow = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const cfg = MATS[mat] ?? MATS.mta;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const on = cfg.light && cure < 0.9;
    if (beam.current) {
      beam.current.visible = on;
      (beam.current.material as THREE.MeshBasicMaterial).opacity = 0.22 + Math.sin(elapsed.current * 14) * 0.08;
    }
    if (glow.current) {
      const m = glow.current.material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = cfg.light ? cure * 0.9 : 0.15 + cure * 0.2;
      m.roughness = THREE.MathUtils.lerp(0.15, 0.7, cure);
    }
  });

  return (
    <group>
      {/* tooth with deep cavity near pulp */}
      <group position={[0, 0, 0]}>
        <mesh position={[0, 1.2, 0]} castShadow>
          <boxGeometry args={[2.6, 2.4, 2.4]} />
          <meshStandardMaterial color="#fef9c3" roughness={0.25} />
        </mesh>
        <mesh position={[0, -1.4, 0]} castShadow>
          <cylinderGeometry args={[1.2, 0.4, 3.4, 16]} />
          <meshStandardMaterial color="#fde68a" roughness={0.4} />
        </mesh>
        {/* cavity */}
        <mesh position={[0, 1.7, 0]} castShadow>
          <boxGeometry args={[1.3, 1.1, 1.3]} />
          <meshStandardMaterial color="#7c2d12" roughness={0.9} />
        </mesh>
        {/* material layer at cavity floor */}
        <mesh ref={glow} position={[0, 1.28, 0]} castShadow>
          <boxGeometry args={[1.28, 0.35, 1.28]} />
          <meshStandardMaterial color={cfg.color} roughness={0.15} emissive={cfg.light ? "#3b82f6" : "#a8a29e"} emissiveIntensity={0.2} />
        </mesh>
        {/* pulp below */}
        <mesh position={[0, -0.2, 0]}>
          <sphereGeometry args={[0.55, 16, 12]} />
          <meshStandardMaterial color="#ef4444" roughness={0.4} emissive="#7f1d1d" emissiveIntensity={0.5} />
        </mesh>
        {/* protective dentin bridge forming (CaOH/MTA) */}
        {!cfg.light && cure > 0.4 && (
          <mesh position={[0, 0.62, 0]}>
            <boxGeometry args={[1.1, 0.18, 1.1]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.5} emissive="#92400e" emissiveIntensity={0.3} />
          </mesh>
        )}
      </group>

      {/* curing light */}
      {cfg.light && (
        <group position={[2.8, 4.4, 1.2]} rotation={[0.5, 0, -0.6]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.35, 0.45, 1.6, 14]} />
            <meshStandardMaterial color="#1e293b" roughness={0.4} />
          </mesh>
          <mesh position={[0, -1, 0]}>
            <cylinderGeometry args={[0.5, 0.5, 0.2, 14]} />
            <meshBasicMaterial color="#3b82f6" />
          </mesh>
          {/* blue beam */}
          <mesh ref={beam} position={[0, -2.6, 0]} visible={false}>
            <coneGeometry args={[1.1, 3.4, 18, 1, true]} />
            <meshBasicMaterial color="#60a5fa" transparent opacity={0.25} side={THREE.DoubleSide} />
          </mesh>
        </group>
      )}

      {showLabels && (
        <>
          <Text position={[0, 3.9, 0]} fontSize={0.46} color="#fef3c7">{cfg.name}</Text>
          <Text position={[0, -3.9, 0]} fontSize={0.42} color="#e2e8f0" maxWidth={10}>{cfg.note}</Text>
          <Text position={[-3.9, 1.2, 0]} fontSize={0.4} color="#fca5a5">Pulp protected below</Text>
          {cfg.light && <Text position={[4.6, 5.2, 1.2]} fontSize={0.4} color="#93c5fd">Blue curing light</Text>}
        </>
      )}
    </group>
  );
}

export function Topic10391Sim(props: SimProps) {
  const mat = String(props.mat ?? "mta");
  const cure = Number(props.cure ?? 0.5);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = MATS[mat] ?? MATS.mta;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Material", cfg.name],
          ["Set", `${Math.round(cure * 100)}%`],
          ["Trick", mat === "resin" ? "light-cured" : mat === "caoh" ? "pH ~12" : "sets wet ✓"],
        ]}
      />
      <SimCanvas cameraPosition={[6.5, 3.5, 10]} target={[0, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.4, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <MaterialScene mat={mat} cure={cure} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
