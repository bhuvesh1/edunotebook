// Thyroid and parathyroid surgery: goiter, thyroid cancer.
// The butterfly-shaped thyroid hugs the windpipe (trachea); tiny parathyroid
// dots sit behind. Watch the lobes swell into a goiter or grow a cancer nodule.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "goiter", options: ["normal", "goiter", "cancer"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Thyroid: Goiter vs Cancer Nodule",
  blurb: "The butterfly thyroid wraps your windpipe — see it swell into a goiter or grow a hard cancer nodule.",
};

function Animator({
  group, lobeL, lobeR, nodule, elapsed, speed, condition,
}: {
  group: React.RefObject<THREE.Group>;
  lobeL: React.RefObject<THREE.Group>;
  lobeR: React.RefObject<THREE.Group>;
  nodule: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.3) * 0.35;
    // breathing motion of the trachea
    const breath = 1 + 0.02 * Math.sin(t * 1.8);
    const goiter = condition === "goiter" ? 1.75 : 1;
    if (lobeL.current) lobeL.current.scale.set(goiter * breath, goiter, goiter);
    if (lobeR.current) lobeR.current.scale.set(goiter * breath * 1.08, goiter * 1.06, goiter * 1.05);
    if (nodule.current) {
      nodule.current.visible = condition === "cancer";
      const s = 1 + 0.15 * Math.sin(t * 3.5);
      nodule.current.scale.set(s, s, s);
    }
  });
  return null;
}

export function Topic10251Sim(props: SimProps) {
  const condition = String(props.condition ?? "goiter");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const lobeL = useRef<THREE.Group>(null!);
  const lobeR = useRef<THREE.Group>(null!);
  const nodule = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", condition === "goiter" ? "Goiter (enlarged)" : condition === "cancer" ? "Thyroid cancer nodule" : "Normal thyroid"], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 9]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* trachea: stack of cartilage rings */}
          {Array.from({ length: 9 }).map((_, i) => (
            <mesh key={i} position={[0, 0.2 + i * 0.42, -0.35]} rotation={[Math.PI / 2, 0, 0]} castShadow>
              <torusGeometry args={[0.55, 0.13, 12, 24]} />
              <meshStandardMaterial color="#bae6fd" roughness={0.5} />
            </mesh>
          ))}
          {/* esophagus behind */}
          <mesh position={[0, 2.1, -1.05]} castShadow>
            <cylinderGeometry args={[0.32, 0.32, 4.4, 14]} />
            <meshStandardMaterial color="#f0abfc" roughness={0.6} />
          </mesh>
          {/* left lobe */}
          <group ref={lobeL} position={[-0.75, 1.9, 0.25]}>
            <mesh scale={[0.85, 1.5, 0.7]} castShadow>
              <sphereGeometry args={[0.55, 24, 18]} />
              <meshStandardMaterial color="#c084fc" roughness={0.45} />
            </mesh>
          </group>
          {/* right lobe */}
          <group ref={lobeR} position={[0.75, 1.9, 0.25]}>
            <mesh scale={[0.85, 1.5, 0.7]} castShadow>
              <sphereGeometry args={[0.55, 24, 18]} />
              <meshStandardMaterial color="#c084fc" roughness={0.45} />
            </mesh>
          </group>
          {/* isthmus bridge */}
          <mesh position={[0, 1.35, 0.55]} scale={[1.5, 0.5, 0.45]} castShadow>
            <sphereGeometry args={[0.42, 20, 14]} />
            <meshStandardMaterial color="#c084fc" roughness={0.45} />
          </mesh>
          {/* cancer nodule on right lobe */}
          <mesh ref={nodule} position={[1.05, 2.35, 0.7]} visible={false} castShadow>
            <icosahedronGeometry args={[0.34, 1]} />
            <meshStandardMaterial color="#7c2d12" roughness={0.4} emissive="#431407" emissiveIntensity={0.6} flatShading />
          </mesh>
          {/* parathyroid glands: tiny dots behind the lobes */}
          {[[-0.75, 2.6], [-0.75, 1.3], [0.75, 2.6], [0.75, 1.3]].map(([x, y], i) => (
            <mesh key={i} position={[x * 1.15, y, -0.35]} castShadow>
              <sphereGeometry args={[0.12, 12, 10]} />
              <meshStandardMaterial color="#fde047" roughness={0.4} emissive="#a16207" emissiveIntensity={0.5} />
            </mesh>
          ))}
          <Label text="Windpipe (trachea)" position={[0, 4.35, -0.35]} size={0.5} color="#bae6fd" />
          <Label text="Thyroid lobes" position={[-2.15, 2.6, 0.25]} size={0.5} color="#e9d5ff" />
          <Label text="Parathyroid ×4" position={[2.2, 1.15, -0.35]} size={0.5} color="#fef08a" />
          {condition === "goiter" && <Label text="⚠ Goiter: swollen" position={[0, 0.35, 0.6]} size={0.55} color="#fca5a5" />}
          {condition === "cancer" && <Label text="⚠ Cancer nodule" position={[1.35, 3.0, 0.7]} size={0.5} color="#fca5a5" />}
        </group>
        <Animator group={group} lobeL={lobeL} lobeR={lobeR} nodule={nodule} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
