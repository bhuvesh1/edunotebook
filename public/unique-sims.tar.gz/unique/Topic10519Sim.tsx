// app/components/sims/unique/Topic10519Sim.tsx
// Pigmented lesions of the oral cavity: dark melanin spots scattered over
// the gums and tongue — from harmless racial pigmentation to melanoma
// warning signs.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "spots", label: "Pigmented spots", kind: "slider", min: 1, max: 10, step: 1, default: 5, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Pigmented Lesions of the Oral Cavity",
  blurb: "Dark melanin spots on gums and tongue — most are harmless, but changing ones need a biopsy.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ group, elapsed, speed }: {
  group: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (group.current) group.current.rotation.y = Math.sin(elapsed.current * 0.3) * 0.12;
  });
  return null;
}

// fixed spot layout (deterministic)
const SPOTS: { p: [number, number, number]; r: number; rot: [number, number, number]; gum: boolean }[] = [
  { p: [-0.9, 3.05, 1.55], r: 0.14, rot: [-0.2, 0.3, 0], gum: true },
  { p: [-0.3, 3.15, 1.6], r: 0.1, rot: [-0.2, 0, 0], gum: true },
  { p: [0.4, 3.1, 1.58], r: 0.17, rot: [-0.2, -0.2, 0], gum: true },
  { p: [0.95, 3.0, 1.5], r: 0.09, rot: [-0.2, -0.4, 0], gum: true },
  { p: [-0.5, 2.15, 2.0], r: 0.13, rot: [-0.5, 0.2, 0], gum: false },
  { p: [0.2, 2.05, 2.05], r: 0.11, rot: [-0.5, 0, 0], gum: false },
  { p: [0.7, 2.2, 1.95], r: 0.15, rot: [-0.5, -0.3, 0], gum: false },
  { p: [-1.1, 2.6, 1.7], r: 0.08, rot: [0, 0.6, 0], gum: false },
  { p: [1.1, 2.65, 1.65], r: 0.1, rot: [0, -0.6, 0], gum: false },
  { p: [0, 3.2, 1.62], r: 0.07, rot: [-0.2, 0, 0], gum: true },
];

export function Topic10519Sim(props: SimProps) {
  const spots = Math.round(Number(props.spots ?? 5));
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Lesions", `${spots} melanin macules`],
          ["Common cause", "physiologic (racial) pigmentation"],
          ["Red flag", "rapid change in size/color → biopsy"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.6, 10]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={group}>
          {/* face */}
          <mesh position={[0, 2.6, -0.8]} castShadow>
            <sphereGeometry args={[2.6, 32, 32]} />
            <meshStandardMaterial color="#f0b98d" roughness={0.7} />
          </mesh>
          {/* open mouth */}
          <mesh position={[0, 2.4, 1.2]}>
            <sphereGeometry args={[1.35, 24, 24]} />
            <meshStandardMaterial color="#5b1a1a" roughness={0.9} />
          </mesh>
          <mesh position={[0, 2.4, 1.55]} scale={[1.35, 0.85, 0.6]} castShadow>
            <torusGeometry args={[1.05, 0.28, 14, 32]} />
            <meshStandardMaterial color="#e0788a" roughness={0.55} />
          </mesh>
          {/* gums */}
          <mesh position={[0, 3.05, 1.35]} scale={[1.5, 0.45, 0.7]} castShadow>
            <sphereGeometry args={[0.85, 20, 20]} />
            <meshStandardMaterial color="#e0607a" roughness={0.55} />
          </mesh>
          {/* tongue */}
          <mesh position={[0, 1.85, 1.5]} scale={[1, 0.45, 1.15]} castShadow>
            <sphereGeometry args={[0.85, 24, 24]} />
            <meshStandardMaterial color="#e0607a" roughness={0.55} />
          </mesh>
          {/* teeth */}
          {[-0.75, -0.38, 0, 0.38, 0.75].map((x, i) => (
            <mesh key={i} position={[x, 2.85, 1.62]} castShadow>
              <boxGeometry args={[0.3, 0.34, 0.25]} />
              <meshStandardMaterial color="#ffffff" roughness={0.3} />
            </mesh>
          ))}

          {/* pigmented macules */}
          {SPOTS.slice(0, spots).map((s, i) => (
            <mesh key={i} position={s.p} rotation={s.rot}>
              <circleGeometry args={[s.r, 16]} />
              <meshStandardMaterial color="#3b2314" roughness={0.8} side={THREE.DoubleSide} />
            </mesh>
          ))}
        </group>

        <Label p={[2.6, 3.0, 1.4]} size={0.3} color="#a16207">melanin macules</Label>
        <Label p={[0, 5.1, 0.5]} size={0.32} color="#e2e8f0">brown-black spots on gums & tongue</Label>

        <Animator group={group} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
