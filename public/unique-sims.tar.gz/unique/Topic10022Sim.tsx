// Embryology: gametogenesis, fertilization, implantation — sperm with wiggling
// tails race to the ovum; on contact a flash marks fertilization, then the
// blastocyst burrows into the uterine wall.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "swimspeed", label: "Sperm swim speed", kind: "slider", min: 0.2, max: 3, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Embryology: Fertilization & Implantation",
  blurb: "Sperm race to the ovum, fertilization flashes, and the blastocyst implants into the uterine wall.",
};

function Animator({
  sperm, tails, flash, blastocyst, elapsed, swimspeed, speed,
}: {
  sperm: React.RefObject<THREE.Group>;
  tails: React.RefObject<THREE.Group>;
  flash: React.RefObject<THREE.Mesh>;
  blastocyst: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  swimspeed: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const T = 14;
    const ph = (t / T) % 1;
    // phase 1 (0-0.45): sperm approach; phase 2: fertilization flash; phase 3: implantation
    if (sperm.current) {
      sperm.current.children.forEach((m, i) => {
        const sp = 1 + (i % 4) * 0.22;
        const swim = Math.min(1, ph / 0.45);
        m.position.x = Math.min(-0.6, -8 + swim * 7.4 * sp * Math.min(swimspeed, 1.4));
        m.position.y = 2.2 + Math.sin(t * 5 + i * 2.3) * 0.25;
        m.visible = ph < 0.62;
      });
    }
    if (tails.current) {
      tails.current.children.forEach((m, i) => {
        m.rotation.z = Math.sin(t * 16 + i * 2.7) * 0.55;
        const s = sperm.current?.children[i];
        if (s) {
          m.position.x = s.position.x - 0.85;
          m.position.y = s.position.y;
          m.visible = s.visible;
        }
      });
    }
    if (flash.current) {
      const on = ph > 0.45 && ph < 0.62;
      flash.current.visible = on;
      if (on) flash.current.scale.setScalar(1 + 0.6 * Math.sin(t * 18));
    }
    if (blastocyst.current) {
      const imp = Math.max(0, Math.min(1, (ph - 0.55) / 0.4));
      blastocyst.current.visible = ph > 0.5;
      blastocyst.current.position.x = 5.6 + imp * 1.5;
      blastocyst.current.position.y = 1.2 - imp * 0.3;
    }
  });
  return null;
}

export function Topic10022Sim(props: SimProps) {
  const swimspeed = Number(props.swimspeed ?? 1);
  const speed = Number(props.speed ?? 1);
  const sperm = useRef<THREE.Group>(null!);
  const tails = useRef<THREE.Group>(null!);
  const flash = useRef<THREE.Mesh>(null!);
  const blastocyst = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", "fertilization → implantation"],
          ["Site", "ampulla → uterus"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* ovum waiting at centre-left */}
        <group position={[-0.6, 2.2, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.95, 24, 24]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.35} />
          </mesh>
          <mesh>
            <sphereGeometry args={[1.12, 24, 24]} />
            <meshStandardMaterial color="#fce7f3" transparent opacity={0.3} roughness={0.2} />
          </mesh>
          <mesh position={[0.2, 0.25, 0.65]}>
            <sphereGeometry args={[0.28, 12, 12]} />
            <meshStandardMaterial color="#831843" />
          </mesh>
        </group>
        <Label text="ovum (secondary oocyte)" position={[-0.6, 3.9, 0]} size={0.38} color="#f8fafc" />
        <Label text="zona pellucida" position={[-2.4, 2.9, 0]} size={0.3} color="#fce7f3" />

        {/* fertilization flash */}
        <mesh ref={flash} position={[-0.6, 2.2, 0]} visible={false}>
          <sphereGeometry args={[1.5, 16, 16]} />
          <meshBasicMaterial color="#fef9c3" transparent opacity={0.55} />
        </mesh>

        {/* racing sperm */}
        <group ref={sperm}>
          {Array.from({ length: 7 }).map((_, i) => (
            <group key={i} position={[-8, 2.2, 0]}>
              <mesh rotation={[0, 0, -Math.PI / 2]} castShadow>
                <coneGeometry args={[0.2, 0.55, 12]} />
                <meshStandardMaterial color="#67e8f9" roughness={0.4} />
              </mesh>
              <mesh position={[-0.32, 0, 0]} rotation={[0, 0, -Math.PI / 2]}>
                <cylinderGeometry args={[0.07, 0.05, 0.35, 8]} />
                <meshStandardMaterial color="#22d3ee" />
              </mesh>
            </group>
          ))}
        </group>
        <group ref={tails}>
          {Array.from({ length: 7 }).map((_, i) => (
            <mesh key={i} position={[-8, 2.2, 0]}>
              <boxGeometry args={[1.0, 0.05, 0.05]} />
              <meshStandardMaterial color="#22d3ee" />
            </mesh>
          ))}
        </group>
        <Label text="sperm" position={[-5.5, 1.2, 0]} size={0.36} color="#a5f3fc" />

        {/* uterine wall on the right */}
        <group position={[8.2, 0, 0]}>
          <mesh position={[0, 2.6, 0]} castShadow>
            <boxGeometry args={[3.4, 1.4, 3.2]} />
            <meshStandardMaterial color="#fb7185" roughness={0.55} />
          </mesh>
          <mesh position={[0, 0.75, 0]} castShadow>
            <boxGeometry args={[3.4, 1.0, 3.2]} />
            <meshStandardMaterial color="#f43f5e" roughness={0.55} />
          </mesh>
          {/* endometrial folds */}
          {[-0.9, 0, 0.9].map((z, i) => (
            <mesh key={i} position={[-1.5, 1.7, z]} rotation={[0, 0, 0.5]} castShadow>
              <coneGeometry args={[0.35, 1.1, 10]} />
              <meshStandardMaterial color="#fda4af" roughness={0.5} />
            </mesh>
          ))}
        </group>
        <Label text="uterine wall (endometrium)" position={[8.2, 4.2, 0]} size={0.36} color="#f8fafc" />

        {/* blastocyst implanting */}
        <group ref={blastocyst} visible={false}>
          <mesh castShadow>
            <sphereGeometry args={[0.7, 20, 20]} />
            <meshStandardMaterial color="#e879f9" roughness={0.4} />
          </mesh>
          <mesh position={[0.25, 0.2, 0.45]}>
            <sphereGeometry args={[0.28, 12, 12]} />
            <meshStandardMaterial color="#a21caf" />
          </mesh>
        </group>
        <Label text="blastocyst implants" position={[6.4, 0.6, 0]} size={0.32} color="#f0abfc" />

        <Animator sperm={sperm} tails={tails} flash={flash} blastocyst={blastocyst}
          elapsed={elapsed} swimspeed={swimspeed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
