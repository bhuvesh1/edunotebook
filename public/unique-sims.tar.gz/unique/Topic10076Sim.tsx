"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "jaundice", label: "Jaundice", kind: "select", min: 0, max: 0, step: 1, default: "off", options: ["off", "on"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Heme Synthesis & Jaundice",
  blurb: "The 8-enzyme heme pathway spins in the marrow while bilirubin piles up when jaundice is switched on.",
};

const HEME_STEPS = ["ALAS","ALAD","PBGD","UROS","UROD","CPOX","PPOX","FECH"];

function Animator({ root, trav, heme, bili, elapsed, speed, jaundice }: { root: RefObject<THREE.Group>; trav: RefObject<THREE.Mesh>; heme: RefObject<THREE.Group>; bili: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; jaundice: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const a = t * 0.7;
    if (trav.current) trav.current.position.set(Math.cos(a) * 3, 1.8, Math.sin(a) * 3);
    if (heme.current) {
      const q = (t * 0.7) % 1;
      const a7 = (7 / 8) * Math.PI * 2;
      heme.current.position.set(Math.cos(a7) * (3 + q * 2.6), 1.8 + q, Math.sin(a7) * (3 + q * 2.6));
      heme.current.rotation.y = t * 2;
    }
    if (bili.current) {
      bili.current.visible = jaundice;
      bili.current.children.forEach((m, i) => {
        const r = (t * 0.4 + i / 10) % 1;
        m.position.set(-4 + (i % 5) * 0.9, 0.4 + r * 3.2, 2.4 + Math.sin(i * 2) * 0.6);
      });
    }
  });
  return null;
}

export function Topic10076Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const jaundice = String(props.jaundice ?? "off") === "on";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const trav = useRef<THREE.Mesh>(null!);
  const heme = useRef<THREE.Group>(null!);
  const bili = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Steps", "8 (ALAS \u2192 FECH)"],
          ["End product", "heme b + Fe\u00b2\u207a"],
          ["Bilirubin", jaundice ? "HIGH \u2014 yellow skin/eyes" : "normal"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 11]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          {HEME_STEPS.map((name, i) => {
            const a = (i / 8) * Math.PI * 2;
            return (
              <group key={name}>
                <mesh position={[Math.cos(a) * 3, 1.8, Math.sin(a) * 3]} castShadow>
                  <boxGeometry args={[0.8, 0.8, 0.8]} />
                  <meshStandardMaterial color={i === 0 ? "#f472b6" : i === 7 ? "#ef4444" : "#fb923c"} roughness={0.5} />
                </mesh>
                <Label text={name} position={[Math.cos(a) * 3, 2.6, Math.sin(a) * 3]} size={0.36} color="#fdba74" />
              </group>
            );
          })}
          <mesh ref={trav}>
            <sphereGeometry args={[0.2, 14, 14]} /><meshStandardMaterial color="#ffffff" emissive="#fb923c" emissiveIntensity={2.2} />
          </mesh>
          <group ref={heme}>
            <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
              <cylinderGeometry args={[0.5, 0.5, 0.14, 20]} /><meshStandardMaterial color="#dc2626" roughness={0.4} />
            </mesh>
            <mesh><sphereGeometry args={[0.16, 12, 12]} /><meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1.5} /></mesh>
            <Label text="heme" position={[0, 0.75, 0]} size={0.42} color="#f87171" />
          </group>
          <group ref={bili} visible={false}>
            {Array.from({ length: 10 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.17, 10, 10]} /><meshStandardMaterial color="#facc15" emissive="#eab308" emissiveIntensity={0.9} /></mesh>
            ))}
          </group>
          <Label text="succinyl-CoA + glycine" position={[-3.6, 3.6, 0]} size={0.4} color="#fdba74" />
          <Label text={jaundice ? "bilirubin accumulating \u2014 jaundice!" : "heme \u2192 hemoglobin"} position={[0, 4.6, 0]} size={0.45} color={jaundice ? "#facc15" : "#94a3b8"} />
        </group>
        <Animator root={root} trav={trav} heme={heme} bili={bili} elapsed={elapsed} speed={speed} jaundice={jaundice} />
      </SimCanvas>
    </div>
  );
}
