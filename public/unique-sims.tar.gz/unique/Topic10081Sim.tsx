"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ros", label: "ROS count", kind: "slider", min: 2, max: 10, step: 1, default: 6 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Free Radicals vs Antioxidants",
  blurb: "Spiky ROS bounce around attacking DNA while antioxidant defenders chase and neutralize them.",
};

function Animator({ root, rosg, aox, dna, vel, elapsed, speed, ros }: { root: RefObject<THREE.Group>; rosg: RefObject<THREE.Group>; aox: RefObject<THREE.Group>; dna: RefObject<THREE.Group>; vel: RefObject<{ v: THREE.Vector3; live: boolean }[]>; elapsed: RefObject<number>; speed: number; ros: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (vel.current.length !== ros) {
      vel.current = Array.from({ length: ros }).map((_, i) => ({
        v: new THREE.Vector3(Math.sin(i * 7.3) * 1.6, Math.cos(i * 3.1) * 1.1, Math.sin(i * 5.7) * 1.6),
        live: true,
      }));
    }
    let hits = 0;
    if (rosg.current) {
      rosg.current.children.forEach((m, i) => {
        const st = vel.current[i]; if (!st) return;
        if (!st.live) {
          if ((t + i) % 9 < delta * speed) { st.live = true; m.scale.setScalar(1); ((m as THREE.Mesh).material as THREE.MeshStandardMaterial).color.set("#ef4444"); m.position.set((Math.sin(i * 9) * 3), 2.5, Math.cos(i * 7) * 2); }
          else return;
        }
        m.position.addScaledVector(st.v, delta * speed);
        (["x", "y", "z"] as const).forEach((ax, k) => {
          const lim = k === 1 ? [0.6, 4.2] : [-4.4, 4.4];
          if (m.position[ax] < lim[0] || m.position[ax] > lim[1]) st.v[ax] *= -1;
          m.position[ax] = Math.min(lim[1], Math.max(lim[0], m.position[ax]));
        });
        m.rotation.x += delta * 3; m.rotation.y += delta * 2;
        if (m.position.distanceTo(new THREE.Vector3(0, 2.2, 0)) < 1.1) hits++;
      });
    }
    if (aox.current && rosg.current) {
      aox.current.children.forEach((a, j) => {
        let best: THREE.Object3D | null = null; let bd = 1e9;
        rosg.current!.children.forEach((m, i) => {
          if (!vel.current[i]?.live) return;
          const d = a.position.distanceTo(m.position);
          if (d < bd) { bd = d; best = m; }
        });
        if (best) {
          const dir = (best as THREE.Object3D).position.clone().sub(a.position);
          const d = dir.length();
          if (d < 0.55) {
            const bi = rosg.current!.children.indexOf(best as THREE.Object3D);
            vel.current[bi].live = false;
            (best as THREE.Object3D).scale.setScalar(0.25);
            ((best as THREE.Object3D) as THREE.Mesh).material = ((best as THREE.Object3D) as THREE.Mesh).material;
            (((best as THREE.Object3D) as THREE.Mesh).material as THREE.MeshStandardMaterial).color.set("#64748b");
          } else {
            a.position.addScaledVector(dir.normalize(), delta * speed * 2.2);
          }
        }
        a.position.y = Math.min(4.2, Math.max(0.6, a.position.y));
      });
    }
    if (dna.current) dna.current.rotation.z = Math.sin(t * 6) * 0.06 * Math.min(3, hits);
  });
  return null;
}

export function Topic10081Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const ros = Math.round(Number(props.ros ?? 6));
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const rosg = useRef<THREE.Group>(null!);
  const aox = useRef<THREE.Group>(null!);
  const dna = useRef<THREE.Group>(null!);
  const vel = useRef<{ v: THREE.Vector3; live: boolean }[]>([]);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["ROS count", `${ros}`],
          ["Defense", "GSH \u00b7 vitamin C \u00b7 vitamin E"],
          ["Damage", "lipid \u00b7 protein \u00b7 DNA oxidation"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 12]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 2.3, 0]}>
            <boxGeometry args={[9.4, 4.2, 5]} />
            <meshStandardMaterial color="#1e293b" transparent opacity={0.18} roughness={0.4} side={THREE.DoubleSide} />
          </mesh>
          <group ref={dna} position={[0, 2.2, 0]}>
            {Array.from({ length: 7 }).map((_, i) => {
              const a = i * 0.9;
              return (
                <group key={i}>
                  <mesh position={[Math.cos(a) * 0.5, -1 + i * 0.34, Math.sin(a) * 0.5]}>
                    <sphereGeometry args={[0.14, 10, 10]} /><meshStandardMaterial color="#60a5fa" />
                  </mesh>
                  <mesh position={[-Math.cos(a) * 0.5, -1 + i * 0.34, -Math.sin(a) * 0.5]}>
                    <sphereGeometry args={[0.14, 10, 10]} /><meshStandardMaterial color="#f472b6" />
                  </mesh>
                </group>
              );
            })}
          </group>
          <Label text="DNA under attack" position={[0, 4.1, 0]} size={0.42} color="#93c5fd" />
          <group ref={rosg}>
            {Array.from({ length: ros }).map((_, i) => (
              <mesh key={i} position={[Math.sin(i * 9) * 3, 2.5, Math.cos(i * 7) * 2]}>
                <icosahedronGeometry args={[0.32, 0]} />
                <meshStandardMaterial color="#ef4444" emissive="#b91c1d" emissiveIntensity={0.9} roughness={0.4} flatShading />
              </mesh>
            ))}
          </group>
          <group ref={aox}>
            {[["GSH", "#4ade80", -3.5], ["vit C", "#4ade80", 3.5], ["vit E", "#4ade80", 0]].map(([n, c, x]) => (
              <group key={n as string} position={[x as number, 1.2, 1.5]}>
                <mesh castShadow><sphereGeometry args={[0.34, 16, 16]} /><meshStandardMaterial color={c as string} emissive="#16a34a" emissiveIntensity={0.6} /></mesh>
                <Label text={n as string} position={[0, 0.6, 0]} size={0.36} color={c as string} />
              </group>
            ))}
          </group>
          <Label text="ROS (free radicals)" position={[-3.6, 4.4, 0]} size={0.42} color="#f87171" />
        </group>
        <Animator root={root} rosg={rosg} aox={aox} dna={dna} vel={vel} elapsed={elapsed} speed={speed} ros={ros} />
      </SimCanvas>
    </div>
  );
}
