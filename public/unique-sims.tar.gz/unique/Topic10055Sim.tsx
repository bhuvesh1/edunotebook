// Neurophysiology: higher functions — learning, memory, sleep, EEG — a brain
// with a scrolling EEG trace that changes with the selected state, and memory
// consolidation sparks flying from hippocampus to cortex during deep sleep.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "state", label: "Brain state", kind: "select", min: 0, max: 0, step: 1, default: "awake", options: ["awake", "deepsleep", "rem"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Neurophysiology: Sleep, Memory & EEG",
  blurb: "Switch between awake, deep sleep and REM — the EEG changes and memories consolidate while you sleep.",
};

const STATES = {
  awake: { wave: "beta — fast, low voltage", freq: 9, amp: 0.35, color: "#fbbf24" },
  deepsleep: { wave: "delta — slow, high voltage", freq: 1.6, amp: 1.0, color: "#38bdf8" },
  rem: { wave: "theta + dreaming", freq: 5, amp: 0.55, color: "#c084fc" },
} as const;

function Animator({
  pen, sparks, dreamCloud, elapsed, state, speed,
}: {
  pen: React.RefObject<THREE.Mesh>;
  sparks: React.RefObject<THREE.Group>;
  dreamCloud: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  state: keyof typeof STATES;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const s = STATES[state];
    const cyc = (t * 0.8) % 1;
    if (pen.current) {
      pen.current.position.x = -5 + cyc * 10;
      const y = Math.sin(cyc * Math.PI * 2 * s.freq * 2) * s.amp
        + Math.sin(cyc * Math.PI * 2 * s.freq * 5.3) * s.amp * 0.3;
      pen.current.position.y = 1 + y * 0.9;
    }
    if (sparks.current) {
      sparks.current.children.forEach((m, i) => {
        const on = state === "deepsleep";
        const ph = ((t * 0.5 + i / 10) % 1 + 1) % 1;
        // hippocampus -> cortex
        m.position.set(-2.2 + ph * 2.6, 3.4 + Math.sin(ph * Math.PI) * 1.6, 0.8);
        m.visible = on;
      });
    }
    if (dreamCloud.current) {
      dreamCloud.current.visible = state === "rem";
      if (state === "rem") {
        dreamCloud.current.children.forEach((m, i) => {
          m.position.y = 7.6 + Math.sin(t * 2 + i * 1.8) * 0.25;
        });
      }
    }
  });
  return null;
}

export function Topic10055Sim(props: SimProps) {
  const state = (String(props.state ?? "awake") as keyof typeof STATES) in STATES
    ? (String(props.state ?? "awake") as keyof typeof STATES)
    : "awake";
  const speed = Number(props.speed ?? 1);
  const pen = useRef<THREE.Mesh>(null!);
  const sparks = useRef<THREE.Group>(null!);
  const dreamCloud = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const s = STATES[state];

  const eegGeo = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 160; i++) {
      const cyc = i / 160;
      const y = Math.sin(cyc * Math.PI * 2 * s.freq * 2) * s.amp
        + Math.sin(cyc * Math.PI * 2 * s.freq * 5.3) * s.amp * 0.3;
      pts.push(new THREE.Vector3(-5 + cyc * 10, 1 + y * 0.9, 0));
    }
    return new THREE.BufferGeometry().setFromPoints(pts);
  }, [state]);
  const eegLine = useMemo(
    () => new THREE.Line(eegGeo, new THREE.LineBasicMaterial({ color: s.color })),
    [eegGeo, state]
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["EEG", s.wave],
          ["Memory", state === "deepsleep" ? "consolidating → cortex ✍" : state === "rem" ? "dreaming 💭" : "encoding…"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* brain */}
        <group position={[-1.5, 0, 0]}>
          <mesh position={[0, 4.6, 0]} castShadow scale={[1.25, 0.95, 1.05]}>
            <sphereGeometry args={[1.7, 24, 24]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
          </mesh>
          {/* gyri hints */}
          {[-0.8, 0, 0.8].map((x, i) => (
            <mesh key={i} position={[x, 5.6, 0.9]} rotation={[0.4, 0, x * 0.4]}>
              <torusGeometry args={[0.4, 0.09, 8, 16, Math.PI]} />
              <meshStandardMaterial color="#f472b6" roughness={0.5} />
            </mesh>
          ))}
          {/* hippocampus (deep) */}
          <mesh position={[-0.7, 3.7, 0.3]} castShadow scale={[1.6, 0.7, 0.9]}>
            <sphereGeometry args={[0.4, 14, 14]} />
            <meshStandardMaterial color={state === "deepsleep" ? "#38bdf8" : "#a78bfa"}
              emissive={state === "deepsleep" ? "#0c4a6e" : "#4c1d95"} emissiveIntensity={0.6} roughness={0.4} />
          </mesh>
        </group>
        <Label text="hippocampus — memory hub" position={[-2.9, 3.0, 0.3]} size={0.3} color="#c4b5fd" />
        {/* consolidation sparks hippocampus -> cortex */}
        <group ref={sparks}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i} position={[-2.2, 3.4, 0.8]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshBasicMaterial color="#7dd3fc" />
            </mesh>
          ))}
        </group>
        {/* dream cloud in REM */}
        <group ref={dreamCloud} position={[0.5, 0, 0]} visible={false}>
          {[[-0.7, 0], [0, 0.25], [0.7, 0]].map(([x, dy], i) => (
            <mesh key={i} position={[x, 7.6 + dy, 0]} castShadow>
              <sphereGeometry args={[0.55, 14, 14]} />
              <meshStandardMaterial color="#e9d5ff" transparent opacity={0.85} roughness={0.4} />
            </mesh>
          ))}
          <Label text="dreaming…" position={[0.5, 8.7, 0]} size={0.34} color="#d8b4fe" />
        </group>

        {/* EEG monitor */}
        <group position={[3.6, 0, 0]}>
          <mesh position={[0, 1, -0.06]} receiveShadow>
            <planeGeometry args={[10.6, 3.6]} />
            <meshStandardMaterial color="#052e16" roughness={0.9} />
          </mesh>
          {[-0.8, 0, 0.8].map((y, i) => (
            <mesh key={i} position={[0, 1 + y, 0]}>
              <planeGeometry args={[10.4, 0.02]} />
              <meshBasicMaterial color="#166534" transparent opacity={0.5} />
            </mesh>
          ))}
          <primitive object={eegLine} />
          <mesh ref={pen}>
            <sphereGeometry args={[0.1, 8, 8]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
          {/* scalp electrodes */}
          {[-1.6, -0.5, 0.6, 1.7].map((x, i) => (
            <mesh key={i} position={[-4.5 + x, 6.4, 0.4 + (i % 2) * 0.5]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshBasicMaterial color={s.color} />
            </mesh>
          ))}
        </group>
        <Label text={`EEG — ${s.wave}`} position={[3.6, 3.4, 0]} size={0.38} color={s.color} />

        <Animator pen={pen} sparks={sparks} dreamCloud={dreamCloud}
          elapsed={elapsed} state={state} speed={speed} />
      </SimCanvas>
    </div>
  );
}
