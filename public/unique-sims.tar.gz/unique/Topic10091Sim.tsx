"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dtype", label: "Disease", kind: "select", min: 0, max: 0, step: 1, default: "acute lymphoblastic leukemia", options: ["acute lymphoblastic leukemia", "chronic myeloid leukemia", "Hodgkin lymphoma"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Leukemia & Lymphoma",
  blurb: "Blast cells multiply and crowd out healthy cells; in lymphoma the lymph node swells.",
};

function Animator({ root, blasts, node, elapsed, speed, lymph }: { root: RefObject<THREE.Group>; blasts: RefObject<THREE.Group>; node: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; lymph: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (blasts.current) {
      blasts.current.children.forEach((m, i) => {
        const grow = (t * 0.35 + i * 0.07) % 1.2;
        const s = Math.min(1, grow * 1.4);
        m.scale.setScalar(Math.max(0.001, s));
        const a = i * 2.4;
        m.position.set(Math.cos(a) * (1 + i * 0.16), 1.9 + Math.sin(i * 1.7) * 0.9, Math.sin(a) * (1 + i * 0.16));
        m.rotation.y = t + i;
      });
    }
    if (node.current) {
      node.current.visible = lymph;
      const s = 1 + 0.35 * Math.min(1, (t * 0.3) % 1.2);
      node.current.scale.setScalar(s);
    }
  });
  return null;
}

export function Topic10091Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const dtype = String(props.dtype ?? "acute lymphoblastic leukemia");
  const lymph = dtype === "Hodgkin lymphoma";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const blasts = useRef<THREE.Group>(null!);
  const node = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Disease", dtype],
          ["Key finding", lymph ? "Reed\u2013Sternberg cells in node" : dtype.includes("lymphoblastic") ? "lymphoblasts > 20%" : "Philadelphia chromosome t(9;22)"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          {Array.from({ length: 5 }).map((_, i) => (
            <mesh key={i} position={[-4 + (i % 3) * 1.2, 1.2 + Math.floor(i / 3) * 1.4, -2]} scale={[1, 0.45, 1]}>
              <sphereGeometry args={[0.3, 14, 14]} /><meshStandardMaterial color="#dc2626" roughness={0.5} />
            </mesh>
          ))}
          <Label text="normal marrow crowded out" position={[-3.6, 3.4, -2]} size={0.4} color="#f87171" />
          <group ref={blasts}>
            {Array.from({ length: 14 }).map((_, i) => (
              <group key={i}>
                <mesh castShadow>
                  <sphereGeometry args={[0.42, 16, 16]} /><meshStandardMaterial color="#8b5cf6" roughness={0.45} />
                </mesh>
                <mesh><sphereGeometry args={[0.22, 12, 12]} /><meshStandardMaterial color="#4c1d95" roughness={0.5} /></mesh>
              </group>
            ))}
          </group>
          <Label text={lymph ? "lymphoma cells" : "blasts proliferating"} position={[0.5, 3.6, 0]} size={0.45} color="#a78bfa" />
          <mesh ref={node} visible={false} position={[4.2, 1.6, 0]} castShadow>
            <sphereGeometry args={[0.9, 20, 20]} /><meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={0.4} roughness={0.5} />
          </mesh>
          <Label text={lymph ? "swollen lymph node" : dtype} position={[lymph ? 4.2 : 0, lymph ? 0.3 : 4.8, 0]} size={0.45} color={lymph ? "#4ade80" : "#f8fafc"} />
        </group>
        <Animator root={root} blasts={blasts} node={node} elapsed={elapsed} speed={speed} lymph={lymph} />
      </SimCanvas>
    </div>
  );
}
