"use client";

// Diabetes mellitus and dental treatment planning.
// Check the blood sugar on the glucometer before picking up the
// drill: high sugar means infection risk and poor healing.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "sugar", label: "Blood sugar", kind: "slider", min: 70, max: 400, step: 5, default: 180, unit: "mg/dL" },
];

export const UNIQUE_META = {
  title: "Diabetes & Dental Treatment Planning",
  blurb: "Read the glucometer before treatment: high blood sugar means infection risk, poor healing — and a changed plan.",
};

type Ref = { current: THREE.Group | null };

function levelColor(sugar: number) {
  if (sugar < 140) return "#22c55e";
  if (sugar < 250) return "#fbbf24";
  return "#ef4444";
}

function Animator({ mols, drop, elapsed, sugar }: { mols: Ref; drop: Ref; elapsed: { current: number }; sugar: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const e = elapsed.current;
    const w = 0.4 + (sugar / 400) * 1.6;
    mols.current?.children.forEach((m, i) => {
      const a = e * w + (i * 2.4);
      m.position.set(
        -1.9 + Math.cos(a) * (0.7 + (i % 3) * 0.25),
        2.9 + Math.sin(a * 1.3) * 0.45,
        Math.sin(a * 0.7) * 0.7
      );
    });
    if (drop.current) {
      const s = 1 + 0.18 * Math.sin(e * 5);
      drop.current.scale.set(s, s, s);
    }
  });
  return null;
}

export function Topic10563Sim(props: SimProps) {
  const sugar = Number(props.sugar ?? 180);
  const color = levelColor(sugar);
  const status = sugar < 140 ? "Controlled — proceed" : sugar < 250 ? "High — short morning visit" : "Very high — defer elective care";
  const frac = sugar / 400;

  const mols = useRef<THREE.Group>(null!);
  const drop = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Blood sugar", `${sugar} mg/dL`],
          ["Plan", status],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 11]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* glucometer */}
        <group position={[-1.9, 0, 0]}>
          <mesh position={[0, 1.0, 0]} castShadow>
            <boxGeometry args={[0.78, 1.2, 0.3]} />
            <meshStandardMaterial color="#1f2937" roughness={0.5} />
          </mesh>
          <mesh position={[0, 1.12, 0.16]}>
            <planeGeometry args={[0.56, 0.62]} />
            <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.55} />
          </mesh>
          <mesh position={[0.12, 1.75, 0]}>
            <boxGeometry args={[0.14, 0.35, 0.07]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <group ref={drop} position={[0.12, 2.05, 0]}>
            <mesh castShadow>
              <sphereGeometry args={[0.12, 12, 12]} />
              <meshStandardMaterial color="#dc2626" roughness={0.25} />
            </mesh>
          </group>
        </group>

        {/* glucose molecules drifting */}
        <group ref={mols}>
          {Array.from({ length: 12 }).map((_, i) => (
            <mesh key={i}>
              <sphereGeometry args={[0.12, 10, 10]} />
              <meshStandardMaterial color="#fde68a" emissive="#f59e0b" emissiveIntensity={0.4} />
            </mesh>
          ))}
        </group>

        {/* level gauge */}
        <group position={[2.7, 0, 0]}>
          <mesh position={[0, 1.6, 0]} castShadow>
            <boxGeometry args={[0.45, 3.2, 0.45]} />
            <meshStandardMaterial color="#1e293b" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.05 + (3.1 * frac) / 2, 0]}>
            <boxGeometry args={[0.34, Math.max(0.05, 3.1 * frac), 0.34]} />
            <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} />
          </mesh>
        </group>

        {/* tooth awaiting treatment */}
        <group position={[0.9, 0, 0.6]}>
          <mesh position={[0, 0.6, 0]} castShadow>
            <boxGeometry args={[0.62, 0.52, 0.56]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.35} />
          </mesh>
          {[-0.16, 0.16].map((x) => (
            <mesh key={x} position={[x, 0.18, 0]} rotation={[Math.PI, 0, 0]}>
              <coneGeometry args={[0.14, 0.42, 10]} />
              <meshStandardMaterial color="#f1f5f9" roughness={0.4} />
            </mesh>
          ))}
        </group>

        {/* insulin pen */}
        <group position={[-0.1, 0.45, 1.6]} rotation={[0, 0.4, Math.PI / 2]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.1, 0.1, 0.95, 12]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.4} />
          </mesh>
          <mesh position={[0, -0.58, 0]}>
            <coneGeometry args={[0.1, 0.22, 12]} />
            <meshStandardMaterial color="#f97316" roughness={0.4} />
          </mesh>
        </group>

        <Label text="Glucometer" position={[-1.9, 2.75, 0]} size={0.45} color="#e2e8f0" />
        <Label text={`${sugar} mg/dL`} position={[-1.9, 0.25, 0]} size={0.5} color={color} />
        <Label text="Glucose in blood" position={[-1.9, 3.6, 0]} size={0.42} color="#fde68a" />
        <Label text="Tooth to treat" position={[0.9, 1.35, 0.6]} size={0.42} color="#e2e8f0" />
        <Label text="Insulin pen" position={[-0.1, 0.05, 1.6]} size={0.4} color="#fdba74" />
        <Animator mols={mols} drop={drop} elapsed={elapsed} sugar={sugar} />
      </SimCanvas>
    </div>
  );
}
