"use client";
// Ear: hearing loss — types, audiometry, hearing aids.
// An audiogram chart draws its line as the test tone sweeps frequencies;
// then a hearing aid appears behind the ear and lifts the line back up.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "loss", label: "Hearing loss", kind: "select", min: 0, max: 0, step: 1, default: "sensorineural", options: ["conductive", "sensorineural"] },
  { key: "aid", label: "Hearing aid", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Hearing Loss, Audiometry & Hearing Aids",
  blurb: "The audiogram line dips as hearing fades — switch the hearing aid on and watch the line climb back toward normal.",
};

function lossDb(f: number, loss: string) {
  // f: 0..1 across frequencies
  if (loss === "conductive") return 25 + f * 8; // flat loss
  return 10 + f * f * 55; // sloping high-frequency loss
}

function Animator({ marker, elapsed, loss, aid }: { marker: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; loss: string; aid: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = (elapsed.current * 0.35) % 1;
    if (marker.current) {
      const f = t;
      const db = lossDb(f, loss) - (aid === "on" ? 18 : 0);
      marker.current.position.x = -4.5 + f * 8;
      marker.current.position.y = 4.6 - Math.max(4, db) * 0.055;
    }
  });
  return null;
}

export function Topic10186Sim(props: SimProps) {
  const loss = String(props.loss ?? "sensorineural");
  const aid = String(props.aid ?? "on");
  const marker = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const audioLine = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 40; i++) {
      const f = i / 40;
      const db = Math.max(4, lossDb(f, loss) - (aid === "on" ? 18 : 0));
      pts.push(new THREE.Vector3(-4.5 + f * 8, 4.6 - db * 0.055, 0));
    }
    const geo = new THREE.BufferGeometry().setFromPoints(pts);
    return new THREE.Line(geo, new THREE.LineBasicMaterial({ color: aid === "on" ? "#4ade80" : "#f87171" }));
  }, [loss, aid]);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Type", loss], ["Hearing aid", aid], ["Result", aid === "on" ? "line rises = hears better" : "line dips = hears less"]]} />
      <SimCanvas cameraPosition={[0, 3.4, 13]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* audiogram grid */}
        <mesh position={[-0.5, 2.9, -0.2]}>
          <boxGeometry args={[9.4, 4.4, 0.12]} />
          <meshStandardMaterial color="#111c33" roughness={0.9} />
        </mesh>
        {Array.from({ length: 9 }, (_, i) => (
          <mesh key={`v${i}`} position={[-4.5 + i, 2.9, -0.12]}>
            <boxGeometry args={[0.04, 4.2, 0.04]} />
            <meshStandardMaterial color="#24365c" roughness={0.9} />
          </mesh>
        ))}
        {Array.from({ length: 5 }, (_, i) => (
          <mesh key={`h${i}`} position={[-0.5, 1.1 + i, -0.12]}>
            <boxGeometry args={[9.2, 0.04, 0.04]} />
            <meshStandardMaterial color="#24365c" roughness={0.9} />
          </mesh>
        ))}
        <primitive object={audioLine} />
        <mesh ref={marker} position={[-4.5, 4.4, 0]}>
          <sphereGeometry args={[0.18, 12, 12]} />
          <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1} />
        </mesh>
        <Label text="LOUD ↑" position={[-5.6, 4.8, 0]} size={0.45} color="#94a3b8" />
        <Label text="↓ SOFT" position={[-5.6, 1, 0]} size={0.45} color="#94a3b8" />
        <Label text="LOW → HIGH pitch" position={[-0.5, 0.45, 0]} size={0.45} color="#94a3b8" />
        <Label text="AUDIOGRAM" position={[-0.5, 5.6, 0]} size={0.65} color="#93c5fd" />
        {/* ear with hearing aid */}
        <group position={[6.2, 2.6, 0]}>
          <mesh castShadow>
            <torusGeometry args={[0.8, 0.32, 12, 22]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.65} />
          </mesh>
          {aid === "on" && (
            <group>
              <mesh position={[0.35, 1.05, 0]} castShadow>
                <capsuleGeometry args={[0.22, 0.5, 6, 10]} />
                <meshStandardMaterial color="#38bdf8" emissive="#0ea5e9" emissiveIntensity={0.5} roughness={0.4} />
              </mesh>
              <mesh position={[0.1, 0.55, 0.1]}>
                <cylinderGeometry args={[0.05, 0.05, 0.5, 8]} />
                <meshStandardMaterial color="#7dd3fc" roughness={0.4} />
              </mesh>
            </group>
          )}
          <Label text="HEARING AID" position={[0, -1.5, 0]} size={0.5} color={aid === "on" ? "#7dd3fc" : "#64748b"} />
        </group>
        <Animator marker={marker} elapsed={elapsed} loss={loss} aid={aid} />
      </SimCanvas>
    </div>
  );
}
