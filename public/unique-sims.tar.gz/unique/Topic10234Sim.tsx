// Anemias, leukemias, lymphomas & myeloma — inside a blood vessel: red
// discs stream past. Anemia select drops their count and pales them;
// leukemia floods the vessel with white blasts that crowd everything out.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "disorder", label: "Disorder", kind: "select", min: 0, max: 0, step: 1, default: "iron deficiency anemia", options: ["iron deficiency anemia", "megaloblastic anemia", "acute leukemia"] },
  { key: "severity", label: "Severity", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
];

export const UNIQUE_META = {
  title: "Anemias & Leukemias",
  blurb: "Ride inside a blood vessel: anemia thins and pales the red discs, leukemia swarms it with white blasts. Severity drives the takeover.",
};

function Animator({ cells, elapsed, disorder }: {
  cells: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  disorder: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (cells.current) {
      const crowded = disorder === "acute leukemia";
      cells.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        m.position.x += delta * (crowded ? 0.5 : 1.6);
        if (m.position.x > 7) m.position.x = -7;
        // red discs tumble; blasts drift sluggishly
        m.rotation.x = t * (crowded ? 0.5 : 2) + i;
      });
    }
  });
  return null;
}

export function Topic10234Sim(props: SimProps) {
  const disorder = String(props.disorder ?? "iron deficiency anemia");
  const severity = Number(props.severity ?? 60);
  const cells = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const leuk = disorder === "acute leukemia";
  const nRBC = leuk ? Math.round(10 - (severity / 100) * 7) : Math.round(26 - (severity / 100) * 18);
  const nWBC = leuk ? Math.round(4 + (severity / 100) * 22) : 2;

  const rbcList = useMemo(() => {
    return Array.from({ length: 26 }).map((_, i) => ({
      x: -7 + (i * 14) / 26,
      y: ((i * 0.67) % 1.6) - 0.8,
      z: ((i * 0.41) % 1.2) - 0.6,
      pale: (i * 0.37) % 1,
    }));
  }, []);
  const wbcList = useMemo(() => {
    return Array.from({ length: 26 }).map((_, i) => ({
      x: -7 + (i * 14) / 26 + 0.3,
      y: ((i * 0.53) % 1.8) - 0.9,
      z: ((i * 0.71) % 1.2) - 0.6,
    }));
  }, []);

  const hb = leuk ? (9 - (severity / 100) * 4).toFixed(1) : (13 - (severity / 100) * 7).toFixed(1);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Disorder", disorder], ["Hb", `${hb} g/dL`], ["Smear", leuk ? "blasts crowding ⚠" : disorder === "megaloblastic anemia" ? "big fragile RBCs" : "small pale RBCs"]]} />
      <SimCanvas cameraPosition={[0, 1.6, 10]} target={[0, 0.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* vessel wall */}
        <mesh position={[0, 0.8, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[1.7, 1.7, 14.5, 24, 1, true]} />
          <meshStandardMaterial color="#7f1d1d" roughness={0.6} side={THREE.DoubleSide} transparent opacity={0.9} />
        </mesh>

        <group ref={cells}>
          {/* red blood cells: flattened discs */}
          {rbcList.slice(0, nRBC).map((c, i) => (
            <mesh key={`r${i}`} position={[c.x, 0.8 + c.y, c.z]} scale={[1, 0.45, 1]}>
              <sphereGeometry args={[disorder === "megaloblastic anemia" ? 0.42 : 0.32, 16, 12]} />
              <meshStandardMaterial color={disorder === "iron deficiency anemia" && c.pale > 0.4 ? "#fca5a5" : "#dc2626"} roughness={0.4} />
            </mesh>
          ))}
          {/* white blasts */}
          {wbcList.slice(0, nWBC).map((c, i) => (
            <mesh key={`w${i}`} position={[c.x, 0.8 + c.y, c.z]}>
              <sphereGeometry args={[0.4, 14, 12]} />
              <meshStandardMaterial color="#c4b5fd" roughness={0.45} emissive="#5b21b6" emissiveIntensity={0.4} />
            </mesh>
          ))}
        </group>

        <Label text={leuk ? `Leukemia — ${nWBC} blasts swarming ⚠` : `Anemia — only ${nRBC} pale discs left`} position={[0, 3.6, 0]} size={0.52} color={leuk ? "#c4b5fd" : "#fca5a5"} />
        <Label text={leuk ? "Blasts crowd out normal blood → infections, bleeding" : "Few/small red cells → fatigue, pallor"} position={[0, -1.6, 0]} size={0.44} color="#94a3b8" />
        <Animator cells={cells} elapsed={elapsed} disorder={disorder} />
      </SimCanvas>
    </div>
  );
}
