// AKI & CKD — a kidney in cross-section: blood in, urine out. Nephron
// filters glow as they work; the damage slider kills nephrons off (AKI =
// sudden shutdown, CKD = slow scarring), urine flow dwindles and creatinine
// climbs on the monitor.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "damage", label: "Kidney damage", kind: "slider", min: 0, max: 100, step: 5, default: 50, unit: "%" },
  { key: "course", label: "Course", kind: "select", min: 0, max: 0, step: 1, default: "AKI", options: ["AKI", "CKD"] },
];

export const UNIQUE_META = {
  title: "AKI & CKD",
  blurb: "Nephron filters wink out as damage rises — urine flow dwindles and creatinine climbs. AKI strikes suddenly, CKD scars slowly.",
};

function Animator({ nephrons, drip, elapsed, damage }: {
  nephrons: React.RefObject<THREE.Group>;
  drip: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  damage: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (nephrons.current) {
      nephrons.current.children.forEach((c, i) => {
        const alive = i >= Math.round((damage / 100) * nephrons.current!.children.length);
        c.visible = alive;
        if (alive) {
          const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
          m.emissiveIntensity = 0.4 + 0.35 * Math.sin(t * 4 + i * 1.5);
        }
      });
    }
    if (drip.current) {
      const flow = 1 - damage / 110;
      drip.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * (0.4 + flow) + i * 0.25) % 1);
        m.position.y = 0.6 - ph * 1.6;
        m.visible = flow > 0.12;
      });
    }
  });
  return null;
}

export function Topic10232Sim(props: SimProps) {
  const damage = Number(props.damage ?? 50);
  const course = String(props.course ?? "AKI");
  const nephrons = useRef<THREE.Group>(null!);
  const drip = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const alive = 12 - Math.round((damage / 100) * 12);
  const creatinine = (0.9 + (damage / 100) * 7).toFixed(1);
  const urineOut = Math.max(0, Math.round(1500 * (1 - damage / 105)));

  const nephronPos = useMemo(() => {
    return Array.from({ length: 12 }).map((_, i) => ({
      x: ((i * 0.77) % 2.6) - 1.3,
      y: 2.2 + ((i * 0.53) % 2.2),
    }));
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Working nephrons", `${alive}/12`], ["Creatinine", `${creatinine} mg/dL`], ["Urine output", `${urineOut} mL/day`], ["Course", course]]} />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* kidney bean */}
        <mesh position={[0, 2.8, 0]} scale={[1, 1.35, 0.85]} castShadow>
          <sphereGeometry args={[1.9, 30, 24]} />
          <meshStandardMaterial color={course === "CKD" && damage > 50 ? "#7f1d1d" : "#b91c1c"} roughness={course === "CKD" && damage > 50 ? 0.9 : 0.55} />
        </mesh>
        {/* renal pelvis */}
        <mesh position={[0, 1.9, 0.9]} scale={[0.6, 0.9, 0.5]}>
          <sphereGeometry args={[0.7, 16, 12]} />
          <meshStandardMaterial color="#fde68a" roughness={0.5} />
        </mesh>
        {/* nephrons: glowing filter tufts */}
        <group ref={nephrons}>
          {nephronPos.map((p, i) => (
            <mesh key={i} position={[p.x, p.y, 0.75]}>
              <sphereGeometry args={[0.2, 12, 10]} />
              <meshStandardMaterial color="#4ade80" roughness={0.4} emissive="#16a34a" emissiveIntensity={0.5} />
            </mesh>
          ))}
        </group>
        {/* renal artery in */}
        <mesh position={[-2.6, 3.6, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.3, 0.3, 1.8, 14]} />
          <meshStandardMaterial color="#ef4444" roughness={0.5} />
        </mesh>
        {/* ureter out */}
        <mesh position={[0, 0.4, 0.9]} castShadow>
          <cylinderGeometry args={[0.22, 0.26, 2.2, 12]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.5} />
        </mesh>
        {/* urine drips */}
        <group ref={drip}>
          {Array.from({ length: 5 }).map((_, i) => (
            <mesh key={i} position={[0, 0.6, 0.9]}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshBasicMaterial color="#fde047" />
            </mesh>
          ))}
        </group>

        <Label text={course === "AKI" ? "AKI: sudden shutdown — often reversible" : "CKD: slow scarring — irreversible"} position={[0, 5.6, 0]} size={0.5} color={damage > 60 ? "#fca5a5" : "#fde047"} />
        <Label text={damage > 70 ? "Oliguria — almost no urine ⚠" : "Urine still flowing"} position={[0, -1.3, 0]} size={0.48} color={damage > 70 ? "#fca5a5" : "#86efac"} />
        <Animator nephrons={nephrons} drip={drip} elapsed={elapsed} damage={damage} />
      </SimCanvas>
    </div>
  );
}
