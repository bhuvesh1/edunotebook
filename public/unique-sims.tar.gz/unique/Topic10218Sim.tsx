// Asthma, COPD & bronchiectasis — a bronchial tree: trachea splitting into
// bronchi. The airway-narrowing slider thickens walls and drips mucus
// (asthma attack); emphysema toggle pops alveoli at the tips.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "narrow", label: "Airway narrowing", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "view", label: "Show", kind: "select", min: 0, max: 0, step: 1, default: "asthma", options: ["asthma", "COPD/emphysema", "bronchiectasis"] },
];

export const UNIQUE_META = {
  title: "Asthma, COPD & Bronchiectasis",
  blurb: "Squeeze the airways and watch airflow choke (asthma); flip to emphysema to pop the alveoli or bronchiectasis to widen floppy tubes.",
};

function Animator({ air, mucus, elapsed, narrow }: {
  air: React.RefObject<THREE.Group>;
  mucus: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  narrow: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const open = 1 - narrow / 120;
    if (air.current) {
      air.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * (0.9 * open + 0.25) + i * 0.14) % 1);
        // air dots travel down the trachea into bronchi, slowing when narrow
        const top = 5.6, bottom = 0.4;
        m.position.y = top - ph * (top - bottom);
        m.position.x = ph > 0.62 ? (i % 2 === 0 ? -1 : 1) * (ph - 0.62) * 5 : 0;
        ((m as THREE.Mesh).material as THREE.MeshBasicMaterial).opacity = 0.25 + open * 0.6;
      });
    }
    if (mucus.current) {
      mucus.current.children.forEach((c, i) => {
        c.visible = i < Math.round((narrow / 100) * mucus.current!.children.length);
        const m = c as THREE.Mesh;
        m.position.y -= delta * 0.25;
        if (m.position.y < 0.6) m.position.y = 3.4;
      });
    }
  });
  return null;
}

function Bronchus({ x, narrow, view }: { x: number; narrow: number; view: string }) {
  const wallR = view === "bronchiectasis" ? 0.42 : 0.3;
  const innerR = view === "bronchiectasis" ? 0.34 : Math.max(0.06, 0.22 - (narrow / 100) * 0.17);
  return (
    <group position={[x, 0, 0]}>
      <mesh position={[0, 2.2, 0]} rotation={[0, 0, x > 0 ? -0.5 : 0.5]} castShadow>
        <cylinderGeometry args={[wallR, wallR * 1.15, 3.6, 14, 1, true]} />
        <meshStandardMaterial color={narrow > 55 ? "#f87171" : "#f9a8d4"} roughness={0.55} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[0, 2.2, 0]} rotation={[0, 0, x > 0 ? -0.5 : 0.5]}>
        <cylinderGeometry args={[innerR, innerR * 1.15, 3.6, 12, 1, true]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.7} side={THREE.BackSide} />
      </mesh>
      {/* alveoli clusters at tips */}
      {Array.from({ length: 5 }).map((_, i) => (
        <mesh key={i} position={[(x > 0 ? 1 : -1) * (0.7 + (i % 3) * 0.35), 0.5 + (i % 2) * 0.4, (i - 2) * 0.25]}>
          <sphereGeometry args={[view === "COPD/emphysema" ? 0.32 : 0.2, 12, 10]} />
          <meshStandardMaterial color={view === "COPD/emphysema" ? "#94a3b8" : "#fda4af"} roughness={0.6} transparent opacity={view === "COPD/emphysema" ? 0.55 : 0.95} />
        </mesh>
      ))}
    </group>
  );
}

export function Topic10218Sim(props: SimProps) {
  const narrow = Number(props.narrow ?? 55);
  const view = String(props.view ?? "asthma");
  const air = useRef<THREE.Group>(null!);
  const mucus = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const flowPct = Math.round(Math.max(5, 100 - narrow * 0.95));

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Airflow", `${flowPct}%`], ["Wheeze", narrow > 50 ? "audible ⚠" : "none"], ["View", view]]} />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* trachea */}
        <mesh position={[0, 4.4, 0]} castShadow>
          <cylinderGeometry args={[0.55, 0.55, 3.2, 18, 1, true]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.55} side={THREE.DoubleSide} />
        </mesh>
        {/* cartilage rings */}
        {Array.from({ length: 6 }).map((_, i) => (
          <mesh key={i} position={[0, 3.3 + i * 0.45, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.57, 0.06, 8, 20]} />
            <meshStandardMaterial color="#e7e5e4" roughness={0.6} />
          </mesh>
        ))}
        <Bronchus x={-1.7} narrow={narrow} view={view} />
        <Bronchus x={1.7} narrow={narrow} view={view} />

        {/* air dots */}
        <group ref={air}>
          {Array.from({ length: 16 }).map((_, i) => (
            <mesh key={i} position={[0, 5.6, 0]}>
              <sphereGeometry args={[0.11, 10, 10]} />
              <meshBasicMaterial color="#7dd3fc" transparent opacity={0.7} />
            </mesh>
          ))}
        </group>
        {/* mucus plugs dripping when narrowed */}
        <group ref={mucus}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i} position={[(i % 2 === 0 ? -1 : 1) * 1.4, 3.4 - (i % 5) * 0.5, 0.3]}>
              <sphereGeometry args={[0.16, 10, 8]} />
              <meshStandardMaterial color="#a3e635" roughness={0.4} emissive="#3f6212" emissiveIntensity={0.4} />
            </mesh>
          ))}
        </group>

        <Label text="Trachea" position={[0, 6.6, 0]} size={0.5} color="#e2e8f0" />
        <Label text={view === "asthma" ? "Asthma: twitchy airways squeeze + mucus" : view === "COPD/emphysema" ? "Emphysema: alveoli walls destroyed" : "Bronchiectasis: airways widen & scar"} position={[0, -0.4, 0]} size={0.46} color="#fde047" />
        {narrow > 70 && <Label text="Severe attack — blue inhaler NOW" position={[0, 7.4, 0]} size={0.52} color="#fca5a5" />}
        <Animator air={air} mucus={mucus} elapsed={elapsed} narrow={narrow} />
      </SimCanvas>
    </div>
  );
}
