"use client";
// Surgical Therapy: Flap & Osseous Surgery — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Surgical Therapy: Flap & Osseous Surgery",
  blurb: "The gum flap peels back like a curtain, the bone is recontoured, then the flap is stitched home.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const T = 12;
    const ph = (t % T) / T;
    const flap: any = g("flap");
    if (flap) {
      const open = ph < 0.35 ? ph / 0.35 : ph < 0.7 ? 1 : 1 - (ph - 0.7) / 0.3;
      flap.rotation.x = -open * 1.15;
    }
    const def: any = g("bdefect");
    if (def) {
      const fix = ph < 0.35 ? 0 : Math.min(1, (ph - 0.35) / 0.35);
      def.scale.setScalar(Math.max(0.001, 1 - fix));
    }
    const sut: any = g("sutures");
    if (sut) sut.visible = ph > 0.7;
  });
  return null;
}

export function Topic10488Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Phase 1", "Flap reflected"],
          ["Phase 2", "Osseous recontouring"],
          ["Phase 3", "Flap sutured"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1.3, 0]} scale={1.5} />
          <mesh position={[0, 0.3, -0.6]}>
            <boxGeometry args={[4.4, 1.8, 1.8]} />
            <meshStandardMaterial color="#cbb894" roughness={0.9} />
          </mesh>
          <mesh name="bdefect" position={[-1, 1.15, -0.6]}>
            <boxGeometry args={[0.9, 0.6, 1.2]} />
            <meshStandardMaterial color="#6b4f2e" roughness={1} />
          </mesh>
          <group position={[0, 1.9, 1.15]}>
            <mesh name="flap" position={[0, 0.55, 0]}>
              <boxGeometry args={[4.4, 1.1, 0.25]} />
              <meshStandardMaterial color="#e0808f" roughness={0.55} />
            </mesh>
          </group>
          <group name="sutures" visible={false}>
            {[-1.5, -0.5, 0.5, 1.5].map((x, i) => (
              <mesh key={i} position={[x, 2.1, 1.25]} rotation={[0.3, 0, 0.4]}>
                <torusGeometry args={[0.12, 0.03, 8, 14]} />
                <meshStandardMaterial color="#1e293b" roughness={0.5} />
              </mesh>
            ))}
          </group>
          <Label text="Gum flap" position={[3.1, 2.6, 1.1]} size={0.42} color="#e0808f" />
          <Label text="Bone defect" position={[-2.9, 1.2, -0.6]} size={0.42} color="#6b4f2e" />
          <Label text="Sutures" position={[0, 2.9, 1.3]} size={0.42} />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
