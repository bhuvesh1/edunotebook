"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "view", label: "View", kind: "select", min: 0, max: 0, step: 1, default: "bundle", options: ["bundle", "single-rod"] },
  { key: "mineral", label: "Mineralization", kind: "slider", min: 80, max: 99, step: 1, default: 96, unit: "%" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Enamel: structure, composition, defects",
  blurb: "Zoom into enamel — millions of hexagonal rods packed like a honeycomb, 96% mineral, the hardest substance in your body.",
};

// Hexagonal enamel rod
function Rod({ x, z, mineral }: { x: number; z: number; mineral: number }) {
  const m = useRef<THREE.Mesh>(null!);
  const shade = 0.92 + (mineral - 80) / 19 * 0.08;
  return (
    <mesh ref={m} position={[x, 0, z]} castShadow>
      <cylinderGeometry args={[0.42, 0.42, 4.4, 6]} />
      <meshStandardMaterial color={new THREE.Color(shade, shade * 0.98, shade * 0.88)} roughness={0.2} />
    </mesh>
  );
}

function EnamelBundle({ mineral, speed, showLabels }: { mineral: number; speed: number; showLabels: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) g.current.rotation.y = elapsed.current * 0.25;
  });
  const rods = useMemo(() => {
    const arr: [number, number][] = [];
    for (let r = -2; r <= 2; r++)
      for (let c = -2; c <= 2; c++) {
        if (Math.abs(r) + Math.abs(c) > 4) continue;
        arr.push([c * 0.85 + (r % 2) * 0.42, r * 0.74]);
      }
    return arr;
  }, []);
  return (
    <group>
      <group ref={g}>
        {rods.map(([x, z], i) => (
          <Rod key={i} x={x} z={z} mineral={mineral} />
        ))}
        {/* interprismatic sheath lines */}
        {rods.map(([x, z], i) => (
          <mesh key={"s" + i} position={[x, 0, z]}>
            <cylinderGeometry args={[0.45, 0.45, 4.42, 6, 1, true]} />
            <meshBasicMaterial color="#a16207" transparent opacity={0.35} side={THREE.DoubleSide} />
          </mesh>
        ))}
        {/* keyhole cross-section slice at top */}
        <mesh position={[0, 2.25, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[2.6, 32]} />
          <meshBasicMaterial color="#fef9c3" transparent opacity={0.16} />
        </mesh>
      </group>
      {showLabels && (
        <>
          <Text position={[0, 3.6, 0]} fontSize={0.44} color="#fef9c3">Enamel rods (prisms) — honeycomb packing</Text>
          <Text position={[4.4, 0.5, 0]} fontSize={0.4} color="#fde68a">Keyhole cross-section</Text>
        </>
      )}
    </group>
  );
}

function SingleRod({ mineral, speed, showLabels }: { mineral: number; speed: number; showLabels: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) g.current.rotation.y = elapsed.current * 0.6;
  });
  return (
    <group ref={g}>
      {/* one giant rod, cut open to show hydroxyapatite crystals */}
      <mesh castShadow>
        <cylinderGeometry args={[1.3, 1.3, 5, 6]} />
        <meshStandardMaterial color="#fef9c3" roughness={0.2} />
      </mesh>
      {Array.from({ length: 12 }).map((_, i) => (
        <mesh key={i} position={[(Math.random() - 0.5) * 1.8, (Math.random() - 0.5) * 4, (Math.random() - 0.5) * 1.8]} rotation={[Math.random(), Math.random(), 0]} castShadow>
          <octahedronGeometry args={[0.22]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.15} metalness={0.3} />
        </mesh>
      ))}
      {showLabels && (
        <>
          <Text position={[0, 3.8, 0]} fontSize={0.44} color="#fef9c3">One rod — hydroxyapatite crystals inside</Text>
          <Text position={[3.6, -1, 0]} fontSize={0.4} color="#fbbf24">Crystal: Ca₁₀(PO₄)₆(OH)₂</Text>
        </>
      )}
    </group>
  );
}

export function Topic10374Sim(props: SimProps) {
  const view = String(props.view ?? "bundle");
  const mineral = Number(props.mineral ?? 96);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Mineral", `${mineral}% hydroxyapatite`],
          ["Water+organic", `${100 - mineral}%`],
          ["Hardest in body", "enamel ✓"],
          ["Defect", mineral < 90 ? "amelogenesis imperfecta ⚠" : "none"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 11]} target={[0, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.4, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {view === "bundle"
          ? <EnamelBundle mineral={mineral} speed={speed} showLabels={showLabels} />
          : <SingleRod mineral={mineral} speed={speed} showLabels={showLabels} />}
      </SimCanvas>
    </div>
  );
}
