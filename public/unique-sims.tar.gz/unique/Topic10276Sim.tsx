// Obstetrics: preconception & antenatal care — the growing pregnancy.
// A mother-to-be silhouette with the uterus inside. The fetus grows trimester
// by trimester and kicks; antenatal check markers light up around it.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "trimester", label: "Trimester", kind: "select", min: 0, max: 0, step: 1, default: "t2", options: ["t1", "t2", "t3"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Pregnancy: Antenatal Journey",
  blurb: "Follow the baby growing inside the uterus across three trimesters — with antenatal check-ups lighting the way.",
};

function Animator({
  group, fetus, kickL, kickR, checks, elapsed, speed, trimester,
}: {
  group: React.RefObject<THREE.Group>;
  fetus: React.RefObject<THREE.Group>;
  kickL: React.RefObject<THREE.Mesh>;
  kickR: React.RefObject<THREE.Mesh>;
  checks: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  trimester: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
    // fetal kicks — stronger in later trimesters
    const kickAmp = trimester === "t1" ? 0.05 : trimester === "t2" ? 0.18 : 0.3;
    if (kickL.current) kickL.current.rotation.z = 0.6 + Math.max(0, Math.sin(t * 3.1)) * kickAmp * 4;
    if (kickR.current) kickR.current.rotation.z = -0.6 - Math.max(0, Math.sin(t * 3.1 + 1.4)) * kickAmp * 4;
    if (fetus.current) {
      fetus.current.position.y = 1.9 + Math.sin(t * 1.2) * 0.06;
      fetus.current.rotation.z = Math.sin(t * 0.8) * 0.1;
    }
    // antenatal check markers pulse in sequence
    if (checks.current) {
      checks.current.children.forEach((c, i) => {
        const on = ((t * 0.8) % 4) > i;
        ((c as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = on ? 1.2 : 0.1;
      });
    }
  });
  return null;
}

export function Topic10276Sim(props: SimProps) {
  const trimester = String(props.trimester ?? "t2");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const fetus = useRef<THREE.Group>(null!);
  const kickL = useRef<THREE.Mesh>(null!);
  const kickR = useRef<THREE.Mesh>(null!);
  const checks = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const size = trimester === "t1" ? 0.35 : trimester === "t2" ? 0.65 : 1.0;
  const uterusScale = trimester === "t1" ? 0.7 : trimester === "t2" ? 1.0 : 1.3;
  const names: Record<string, string> = { t1: "1st trimester (0–12 wk)", t2: "2nd trimester (13–27 wk)", t3: "3rd trimester (28–40 wk)" };
  const checkNames = ["BP check", "Ultrasound", "Iron + folic acid", "TT vaccine"];

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Stage", names[trimester] ?? trimester], ["Baby size", trimester === "t1" ? "lime 🍋" : trimester === "t2" ? "papaya" : "watermelon 🍉"], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.6, 10.5]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* mother silhouette: head + torso, semi-transparent */}
          <mesh position={[0, 4.9, -0.4]} castShadow>
            <sphereGeometry args={[0.62, 24, 18]} />
            <meshStandardMaterial color="#f5c396" roughness={0.6} transparent opacity={0.6} />
          </mesh>
          <mesh position={[0, 2.9, -0.4]} scale={[1.15, 1.7, 0.85]} castShadow>
            <sphereGeometry args={[1.0, 28, 20]} />
            <meshStandardMaterial color="#f5c396" roughness={0.6} transparent opacity={0.4} />
          </mesh>
          {/* uterus: pear shape, grows with trimester */}
          <mesh position={[0, 1.9, 0.15]} scale={[uterusScale, uterusScale * 1.15, uterusScale * 0.9]} castShadow>
            <sphereGeometry args={[0.85, 28, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.55} />
          </mesh>
          {/* amniotic sac */}
          <mesh position={[0, 1.9, 0.15]} scale={[uterusScale * 0.8, uterusScale * 0.9, uterusScale * 0.7]}>
            <sphereGeometry args={[0.85, 24, 18]} />
            <meshStandardMaterial color="#7dd3fc" roughness={0.2} transparent opacity={0.28} />
          </mesh>
          {/* fetus: curled head + body + kicking legs */}
          <group ref={fetus} position={[0, 1.9, 0.2]} scale={size}>
            <mesh position={[-0.25, 0.35, 0]} castShadow>
              <sphereGeometry args={[0.34, 20, 14]} />
              <meshStandardMaterial color="#fde68a" roughness={0.6} />
            </mesh>
            <mesh position={[0.2, -0.1, 0]} rotation={[0, 0, 1.1]} castShadow>
              <capsuleGeometry args={[0.2, 0.45, 6, 12]} />
              <meshStandardMaterial color="#fde68a" roughness={0.6} />
            </mesh>
            <mesh ref={kickL} position={[0.45, -0.45, 0.1]} rotation={[0, 0, 0.6]} castShadow>
              <capsuleGeometry args={[0.09, 0.35, 6, 10]} />
              <meshStandardMaterial color="#fde68a" roughness={0.6} />
            </mesh>
            <mesh ref={kickR} position={[0.45, -0.45, -0.15]} rotation={[0, 0, -0.6]} castShadow>
              <capsuleGeometry args={[0.09, 0.35, 6, 10]} />
              <meshStandardMaterial color="#fde68a" roughness={0.6} />
            </mesh>
            {/* umbilical cord */}
            <mesh position={[0.05, -0.35, 0]} rotation={[0, 0, 0.4]} castShadow>
              <torusGeometry args={[0.22, 0.06, 8, 16]} />
              <meshStandardMaterial color="#f472b6" roughness={0.5} />
            </mesh>
          </group>
          {/* antenatal check markers */}
          <group ref={checks} position={[-3.4, 2.6, 0]}>
            {checkNames.map((_, i) => (
              <mesh key={i} position={[0, -i * 0.7, 0]} castShadow>
                <sphereGeometry args={[0.22, 14, 10]} />
                <meshStandardMaterial color="#22c55e" emissive="#16a34a" emissiveIntensity={1.2} />
              </mesh>
            ))}
          </group>
          {checkNames.map((n, i) => (
            <Label key={n} text={n} position={[-2.2, 2.6 - i * 0.7, 0]} size={0.44} color="#bbf7d0" />
          ))}
          <Label text="Uterus" position={[1.9, 2.9, 0.15]} size={0.55} color="#f9a8d4" />
          <Label text={trimester === "t1" ? "Tiny embryo" : trimester === "t2" ? "Baby kicks!" : "Almost full term"} position={[0, 0.55, 0.2]} size={0.55} color="#fde68a" />
        </group>
        <Animator group={group} fetus={fetus} kickL={kickL} kickR={kickR} checks={checks} elapsed={elapsed} speed={speed} trimester={trimester} />
      </SimCanvas>
    </div>
  );
}
