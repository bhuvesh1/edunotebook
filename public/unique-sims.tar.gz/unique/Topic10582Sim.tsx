// Topic10582 — Gingival aesthetics: depigmentation, crown lengthening.
// A soft-tissue laser sweeps the gumline. In depigmentation mode it
// vaporises dark melanin spots; in crown-lengthening mode the gum
// margin lifts to reveal longer, even crowns.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "mode", label: "Procedure", kind: "select", min: 0, max: 0, step: 1, default: "depigmentation", options: ["depigmentation", "crown-lengthening"] },
  { key: "power", label: "Laser power", kind: "slider", min: 1, max: 10, step: 1, default: 5, unit: "W" },
];

export const UNIQUE_META = {
  title: "Gingival aesthetics: depigmentation, crown lengthening",
  blurb: "A soft-tissue laser erases dark gum spots or lifts a gummy smile — watch the smile line transform.",
};

const SPOT_XS = [-2.2, -1.4, -0.7, 0.2, 1.0, 1.8, 2.5, -2.9];

function Animator({
  laser,
  spots,
  gumMargin,
  elapsed,
  depig,
  power,
}: {
  laser: RefObject<THREE.Group>;
  spots: RefObject<THREE.Group>;
  gumMargin: RefObject<THREE.Mesh>;
  elapsed: RefObject<number>;
  depig: boolean;
  power: number;
}) {
  // per-spot "remaining pigment" 1 -> 0
  const pigment = useMemo(() => new Float32Array(SPOT_XS.length).fill(1), []);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const beamX = Math.sin(t * 1.1) * 3.1;
    if (laser.current) {
      laser.current.position.x = beamX;
      const glow = laser.current.children[1] as THREE.Mesh;
      const m = glow.material as THREE.MeshStandardMaterial;
      m.opacity = 0.35 + 0.15 * Math.sin(t * 9);
    }
    if (depig && spots.current) {
      spots.current.children.forEach((mesh, i) => {
        const near = Math.abs(SPOT_XS[i] - beamX) < 0.55;
        if (near) pigment[i] = Math.max(0, pigment[i] - delta * power * 0.35);
        const mat = (mesh as THREE.Mesh).material as THREE.MeshStandardMaterial;
        mat.opacity = pigment[i];
        mesh.visible = pigment[i] > 0.02;
      });
    }
    if (!depig && gumMargin.current) {
      // crown lengthening: gum margin rises, teeth look longer
      const target = 0.85;
      gumMargin.current.position.y += (target - gumMargin.current.position.y) * Math.min(1, delta * power * 0.25);
    }
    if (depig && gumMargin.current) {
      gumMargin.current.position.y += (0 - gumMargin.current.position.y) * Math.min(1, delta * 2);
    }
  });
  return null;
}

export function Topic10582Sim(props: SimProps) {
  const mode = String(props.mode ?? "depigmentation");
  const power = Number(props.power ?? 5);
  const depig = mode === "depigmentation";
  const laser = useRef<THREE.Group>(null!);
  const spots = useRef<THREE.Group>(null!);
  const gumMargin = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Procedure", depig ? "Depigmentation" : "Crown lengthening"],
          ["Laser", `${power} W diode`],
          ["Healing", "Bloodless, no stitches"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 11]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* three front teeth */}
        {[-1.6, 0, 1.6].map((x) => (
          <group key={x} position={[x, 2.1, 0]}>
            <mesh castShadow>
              <boxGeometry args={[1.25, 2.0, 0.7]} />
              <meshStandardMaterial color="#fefdf8" roughness={0.3} />
            </mesh>
            <mesh position={[0, -1.4, 0]}>
              <coneGeometry args={[0.4, 1.1, 12]} />
              <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
            </mesh>
          </group>
        ))}

        {/* gum band across the teeth */}
        <mesh position={[0, 1.7, 0.05]}>
          <boxGeometry args={[7.2, 1.5, 1.1]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.65} />
        </mesh>
        {/* movable gum margin (the smile line) */}
        <mesh ref={gumMargin} position={[0, 0, 0.42]}>
          <boxGeometry args={[7.2, 0.5, 0.25]} />
          <meshStandardMaterial color="#ec4899" roughness={0.6} />
        </mesh>

        {/* melanin pigment spots (depigmentation mode) */}
        <group ref={spots}>
          {SPOT_XS.map((x, i) => (
            <mesh key={i} position={[x, 2.05, 0.62]}>
              <sphereGeometry args={[0.24, 12, 12]} />
              <meshStandardMaterial color="#4a2c2a" roughness={0.8} transparent />
            </mesh>
          ))}
        </group>

        {/* diode laser handpiece + beam */}
        <group ref={laser} position={[0, 3.4, 1.6]}>
          <mesh castShadow rotation={[Math.PI / 5, 0, 0]}>
            <cylinderGeometry args={[0.16, 0.22, 1.4, 12]} />
            <meshStandardMaterial color="#1e293b" roughness={0.4} metalness={0.5} />
          </mesh>
          <mesh position={[0, -1.15, 0.25]} rotation={[Math.PI / 5, 0, 0]}>
            <cylinderGeometry args={[0.06, 0.16, 1.5, 10, 1, true]} />
            <meshStandardMaterial color="#f87171" transparent opacity={0.4} emissive="#ef4444" emissiveIntensity={1.4} side={THREE.DoubleSide} />
          </mesh>
        </group>

        <Label text={depig ? "MELANIN SPOTS — laser vaporises them" : "GUMMY SMILE — margin lifts"} position={[0, 4.5, 0]} size={0.42} color="#f9a8d4" />
        <Label text="DIODE LASER — seals as it cuts, bloodless" position={[0, -0.85, 0]} size={0.36} color="#fca5a5" />
        <Label text={depig ? "PINK, EVEN GUMS EMERGE" : "LONGER CROWNS, EVEN SMILE LINE"} position={[0, 0.55, 0]} size={0.36} color="#86efac" />

        <Animator laser={laser} spots={spots} gumMargin={gumMargin} elapsed={elapsed} depig={depig} power={power} />
      </SimCanvas>
    </div>
  );
}
