// app/components/sims/unique/Topic7100Sim.tsx
// Resolution of vectors: the gold vector V splits into its red
// x-component and blue y-component. Slide the angle and watch
// Vx = V·cosθ and Vy = V·sinθ trade off against each other.

"use client";

import { useMemo } from "react";
import * as THREE from "three";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "angle", label: "Angle θ", kind: "slider", min: 0, max: 90, step: 1, default: 35, unit: "°" },
];

export const UNIQUE_META = {
  title: "Resolution of Vectors",
  blurb: "One vector, two shadows: V splits into Vx = V·cosθ along x and Vy = V·sinθ along y.",
};

const V_LEN = 3.4;

function Arrow({
  len, color, phi, from,
}: {
  len: number;
  color: string;
  phi: number;
  from?: [number, number, number];
}) {
  return (
    <group position={from ?? [0, 0, 0]} rotation={[0, 0, phi - Math.PI / 2]}>
      <mesh position={[0, len / 2, 0]}>
        <cylinderGeometry args={[0.09, 0.09, Math.max(len, 0.001), 12]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.45} roughness={0.4} />
      </mesh>
      <mesh position={[0, len + 0.18, 0]}>
        <coneGeometry args={[0.22, 0.4, 14]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.45} roughness={0.4} />
      </mesh>
    </group>
  );
}

export function Topic7100Sim(props: SimProps) {
  const angle = Number(props.angle ?? 35);
  const theta = (angle * Math.PI) / 180;
  const vx = V_LEN * Math.cos(theta);
  const vy = V_LEN * Math.sin(theta);
  const tipX = vx;
  const tipY = vy;

  const projections = useMemo(
    () =>
      new THREE.LineSegments(
        new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(tipX, tipY, 0), new THREE.Vector3(tipX, 0, 0),
          new THREE.Vector3(tipX, tipY, 0), new THREE.Vector3(0, tipY, 0),
        ]),
        new THREE.LineBasicMaterial({ color: "#cbd5e1", transparent: true, opacity: 0.55 })
      ),
    [tipX, tipY]
  );

  const axes = useMemo(
    () =>
      new THREE.LineSegments(
        new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(-0.6, 0, 0), new THREE.Vector3(V_LEN + 0.8, 0, 0),
          new THREE.Vector3(0, -0.6, 0), new THREE.Vector3(0, V_LEN + 0.8, 0),
        ]),
        new THREE.LineBasicMaterial({ color: "#64748b" })
      ),
    []
  );

  // Angle arc at origin.
  const arc = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 24; i++) {
      const a = (i / 24) * theta;
      pts.push(new THREE.Vector3(Math.cos(a) * 0.9, Math.sin(a) * 0.9, 0));
    }
    return new THREE.Line(
      new THREE.BufferGeometry().setFromPoints(pts),
      new THREE.LineBasicMaterial({ color: "#fbbf24" })
    );
  }, [theta]);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["|V|", `${V_LEN.toFixed(1)}`],
          ["Vx = V·cosθ", `${vx.toFixed(2)}`],
          ["Vy = V·sinθ", `${vy.toFixed(2)}`],
          ["θ", `${angle}°`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0.9, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group position={[-1.6, 1.2, 0]}>
          <primitive object={axes} />
          <primitive object={projections} />
          <primitive object={arc} />
          {/* component arrows */}
          <Arrow len={vx} color="#ef4444" phi={0} />
          <Arrow len={vy} color="#3b82f6" phi={Math.PI / 2} />
          {/* the vector itself */}
          <Arrow len={V_LEN} color="#fbbf24" phi={theta} />
          <mesh position={[tipX, tipY, 0]}>
            <sphereGeometry args={[0.13, 14, 14]} />
            <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.8} />
          </mesh>
        </group>
      </SimCanvas>
    </div>
  );
}
