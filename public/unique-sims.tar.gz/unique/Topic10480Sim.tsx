"use client";
// Pathogenesis: Gingivitis to Periodontitis — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Disease stage", kind: "slider", min: 0, max: 3, step: 1, default: 1 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Pathogenesis: Gingivitis to Periodontitis",
  blurb: "Follow the disease down: healthy gum → red and swollen → pocket deepens → bone melts away.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const gum: any = g("disgum");
    if (gum) {
      const c = (gum.material as any).color;
      const r = Math.min(1, p.stage / 2.5);
      c.setRGB(0.88 + r * 0.1, 0.5 - r * 0.32, 0.56 - r * 0.32);
      gum.scale.y = 1 + r * 0.45;
      gum.position.y = 1.55 - p.stage * 0.28;
    }
    const bone: any = g("disbone");
    if (bone) {
      const loss = Math.max(0, p.stage - 1) / 2;
      bone.scale.y = Math.max(0.25, 1 - loss * 0.7);
      bone.position.y = 0.35 - loss * 0.5;
    }
    const th: any = g("distooth");
    if (th) th.rotation.z = p.stage === 3 ? 0.08 * Math.sin(t * 5) : 0;
    const bugs: any = g("bugs");
    if (bugs) bugs.visible = p.stage >= 1;
  });
  return null;
}

export function Topic10480Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const stage = Number(props.stage ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, stage };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", ["Health", "Gingivitis", "Early periodontitis", "Advanced"][stage]],
          ["Pocket", `${2 + stage * 2} mm`],
          ["Bone", stage < 2 ? "Intact" : "Resorbing"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <group name="distooth" position={[0, 1.1, 0]}>
            <Tooth scale={1.5} />
          </group>
          <mesh name="disgum" position={[0, 1.55, 0]}>
            <boxGeometry args={[3.4, 0.9, 2.2]} />
            <meshStandardMaterial color="#e0808f" roughness={0.6} />
          </mesh>
          <mesh name="disbone" position={[0, 0.35, -0.4]}>
            <boxGeometry args={[4.4, 1.8, 1.8]} />
            <meshStandardMaterial color="#cbb894" roughness={0.9} />
          </mesh>
          <group name="bugs" visible={false}>
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <mesh key={i} position={[-1 + i * 0.4, 1.15, 0.9]}>
                <sphereGeometry args={[0.09, 8, 8]} />
                <meshStandardMaterial color="#4d7c0f" roughness={0.9} />
              </mesh>
            ))}
          </group>
          <Label text="Bacteria invade" position={[2.6, 1.1, 0.9]} size={0.4} color="#84cc16" />
          <Label text="Pocket deepens" position={[-2.8, 0.9, 0]} size={0.4} />
          <Label text="Bone resorbs" position={[2.8, -0.3, -0.4]} size={0.4} color="#cbb894" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
