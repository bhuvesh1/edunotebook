// Uveitis & ocular inflammation — the uveal tract (iris + ciliary body)
// reddens and inflammatory cells drift through the anterior chamber.
// Severity slider: redness glow + number of floating cells.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "severity", label: "Inflammation severity", kind: "slider", min: 0, max: 100, step: 5, default: 65, unit: "%" },
  { key: "site", label: "Uveitis type", kind: "select", min: 0, max: 0, step: 1, default: "anterior", options: ["anterior", "intermediate", "posterior"] },
];

export const UNIQUE_META = {
  title: "Uveitis",
  blurb: "The iris and ciliary body inflame — watch white cells drift through the eye and the uvea glow redder with severity.",
};

function Animator({ cells, iris, elapsed, severity }: {
  cells: React.RefObject<THREE.Group>;
  iris: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  severity: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (cells.current) {
      cells.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        // cells drift / swirl slowly in the aqueous
        m.position.x += Math.sin(t * 1.2 + i * 2.3) * 0.006;
        m.position.y += Math.cos(t * 0.9 + i * 1.7) * 0.006;
        m.position.z += Math.sin(t * 1.5 + i) * 0.006;
        m.visible = i < Math.round((severity / 100) * cells.current!.children.length);
      });
    }
    if (iris.current) {
      const mat = iris.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = 0.15 + (severity / 100) * (0.6 + 0.25 * Math.sin(t * 3));
    }
  });
  return null;
}

export function Topic10204Sim(props: SimProps) {
  const severity = Number(props.severity ?? 65);
  const site = String(props.site ?? "anterior");
  const cells = useRef<THREE.Group>(null!);
  const iris = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const cellList = useMemo(() => {
    return Array.from({ length: 40 }).map((_, i) => ({
      x: ((i * 0.83) % 3.4) - 1.7,
      y: 1.6 + ((i * 1.37) % 2.6) - 1.3,
      z: ((i * 0.71) % 1.6) - 0.8,
      s: 0.07 + ((i * 0.31) % 0.08),
    }));
  }, []);

  const siteY = site === "anterior" ? 1.6 : site === "intermediate" ? 1.1 : 0.4;
  const flare = severity > 70 ? "heavy flare ⚠" : severity > 35 ? "moderate flare" : "mild";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Type", site], ["Anterior-chamber cells", `${Math.round((severity / 100) * 40)}+`], ["Flare", flare]]} />
      <SimCanvas cameraPosition={[0, 1.8, 11]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* eyeball shell */}
        <mesh position={[0, 1.2, 0]} castShadow>
          <sphereGeometry args={[2.3, 40, 28, Math.PI * 0.42, Math.PI * 1.55, 0, Math.PI]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.35} side={THREE.DoubleSide} />
        </mesh>
        {/* inflamed iris */}
        <mesh ref={iris} position={[2.18, 1.6, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.72, 0.36, 14, 32]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.45} emissive="#ef4444" emissiveIntensity={0.5} />
        </mesh>
        {/* ciliary body ring */}
        <mesh position={[1.15, 1.6, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[1.45, 0.3, 12, 36]} />
          <meshStandardMaterial color="#991b1b" roughness={0.5} emissive="#ef4444" emissiveIntensity={0.3 + (severity / 100) * 0.5} />
        </mesh>
        {/* choroid glow (posterior) */}
        <mesh position={[0, 1.2, 0]}>
          <sphereGeometry args={[2.0, 28, 20, Math.PI * 0.55, Math.PI * 1.15, Math.PI * 0.25, Math.PI * 0.5]} />
          <meshStandardMaterial color="#7f1d1d" roughness={0.6} side={THREE.DoubleSide} emissive="#dc2626" emissiveIntensity={0.2 + (severity / 100) * 0.4} />
        </mesh>
        {/* inflamed-site spotlight ring */}
        <mesh position={[2.0, siteY, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[1.75, 0.07, 8, 40]} />
          <meshBasicMaterial color="#fbbf24" transparent opacity={0.85} />
        </mesh>

        {/* floating inflammatory cells */}
        <group ref={cells}>
          {cellList.map((c, i) => (
            <mesh key={i} position={[c.x, c.y, c.z]}>
              <sphereGeometry args={[c.s, 10, 10]} />
              <meshStandardMaterial color="#fef3c7" roughness={0.4} emissive="#f59e0b" emissiveIntensity={0.3} />
            </mesh>
          ))}
        </group>

        <Label text="Inflamed iris" position={[2.6, 3.9, 0]} size={0.5} color="#fca5a5" />
        <Label text="Ciliary body" position={[1.15, 3.7, 0]} size={0.5} color="#fca5a5" />
        <Label text="White cells drifting in the eye fluid" position={[-0.6, -1.5, 0]} size={0.45} color="#fde68a" />
        <Label text={site === "anterior" ? "Anterior uveitis — front of eye" : site === "intermediate" ? "Intermediate uveitis — vitreous" : "Posterior uveitis — retina/choroid"} position={[0, 4.6, 0]} size={0.5} color="#fde047" />
        <Animator cells={cells} iris={iris} elapsed={elapsed} severity={severity} />
      </SimCanvas>
    </div>
  );
}
