"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ceramic", label: "Ceramic", kind: "select", min: 0, max: 0, step: 1, default: "zirconia", options: ["feldspathic", "lithium", "zirconia"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Dental ceramics: feldspathic, glass-ceramics, zirconia",
  blurb: "Peel a ceramic crown into layers — glassy feldspathic veneer, strong lithium disilicate, or tough opaque zirconia core.",
};

const CERAMICS: Record<string, { name: string; core: string; coreOp: number; note: string; strength: string }> = {
  feldspathic: { name: "Feldspathic porcelain", core: "#fbcfe8", coreOp: 0.45, note: "glassy, beautiful — veneers only, weak", strength: "~100 MPa" },
  lithium: { name: "Lithium disilicate (e.max)", core: "#fde68a", coreOp: 0.7, note: "needle crystals — strong AND pretty", strength: "~400 MPa" },
  zirconia: { name: "Zirconia", core: "#e7e5e4", coreOp: 1, note: "opaque white armor — molar crowns, bridges", strength: "~1200 MPa" },
};

function CrownLayers({ ceramic, speed, showLabels }: { ceramic: string; speed: number; showLabels: boolean }) {
  const exploded = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const cfg = CERAMICS[ceramic] ?? CERAMICS.zirconia;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (exploded.current) {
      // gentle explode/reassemble breathing
      const e = 0.5 + 0.5 * Math.sin(elapsed.current * 0.8);
      const spread = 0.15 + e * 1.3;
      exploded.current.children.forEach((c, i) => {
        c.position.y = (i - 1) * spread;
      });
      exploded.current.rotation.y = elapsed.current * 0.5;
    }
  });

  return (
    <group>
      <group ref={exploded}>
        {/* 0: core / coping */}
        <mesh castShadow>
          <cylinderGeometry args={[1.15, 1.3, 1.1, 24, 1, true]} />
          <meshStandardMaterial color={cfg.core} transparent opacity={cfg.coreOp} roughness={0.3} side={THREE.DoubleSide} />
        </mesh>
        {/* 1: veneering porcelain */}
        <mesh castShadow>
          <cylinderGeometry args={[1.35, 1.5, 0.9, 24, 1, true]} />
          <meshPhysicalMaterial color="#fecdd3" transparent opacity={0.5} roughness={0.12} side={THREE.DoubleSide} />
        </mesh>
        {/* 2: glaze skin */}
        <mesh>
          <cylinderGeometry args={[1.42, 1.57, 0.5, 24, 1, true]} />
          <meshPhysicalMaterial color="#fff1f2" transparent opacity={0.28} roughness={0.05} side={THREE.DoubleSide} />
        </mesh>
      </group>
      {/* occlusal table */}
      <mesh position={[0, 1.9, 0]} castShadow>
        <sphereGeometry args={[1.42, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshPhysicalMaterial color="#fecdd3" transparent opacity={0.5} roughness={0.12} />
      </mesh>

      {showLabels && (
        <>
          <Text position={[0, 3.6, 0]} fontSize={0.46} color="#fef3c7">{cfg.name}</Text>
          <Text position={[-4.4, 1.2, 0]} fontSize={0.4} color="#e2e8f0" maxWidth={4}>Core — strength {cfg.strength}</Text>
          <Text position={[4.4, 0.2, 0]} fontSize={0.4} color="#fbcfe8" maxWidth={4}>Veneer + glaze — beauty</Text>
          <Text position={[0, -3.4, 0]} fontSize={0.42} color="#e2e8f0" maxWidth={10}>{cfg.note}</Text>
        </>
      )}
    </group>
  );
}

export function Topic10394Sim(props: SimProps) {
  const ceramic = String(props.ceramic ?? "zirconia");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = CERAMICS[ceramic] ?? CERAMICS.zirconia;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Ceramic", cfg.name],
          ["Flexural strength", cfg.strength],
          ["Best for", ceramic === "feldspathic" ? "veneers" : ceramic === "lithium" ? "single crowns" : "molars + bridges"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 0.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -4.2, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <CrownLayers ceramic={ceramic} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
