// Topic10589 — Hard tissue laser applications basics.
// An erbium laser beam drills a decay spot off a molar, layer by layer.
// Debris flies, the dark cavity shrinks, and clean enamel is left
// ready for a filling — no drill vibration.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "energy", label: "Laser energy", kind: "slider", min: 1, max: 10, step: 1, default: 6, unit: "mJ" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Hard tissue laser applications basics",
  blurb: "An erbium laser vaporises tooth decay layer by layer — watch the dark cavity shrink to clean enamel.",
};

function Animator({
  group,
  debris,
  beam,
  elapsed,
  speed,
  active,
}: {
  group: RefObject<THREE.Group>;
  debris: RefObject<THREE.Group>;
  beam: RefObject<THREE.Mesh>;
  elapsed: RefObject<number>;
  speed: number;
  active: boolean;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.5) * 0.4;
    if (beam.current) {
      (beam.current.material as THREE.MeshStandardMaterial).opacity = active
        ? 0.3 + 0.12 * Math.sin(t * 16)
        : 0;
    }
    if (debris.current) {
      debris.current.visible = active;
      debris.current.children.forEach((m, i) => {
        const ph = ((t * 1.4 + i * 0.13) % 1);
        m.position.set(1.05 + ph * 2.2, 2.5 + Math.sin(ph * 9 + i) * 0.5, Math.cos(ph * 7 + i * 2) * 0.8);
        m.scale.setScalar(1 - ph * 0.7);
      });
    }
  });
  return null;
}

export function Topic10589Sim(props: SimProps) {
  const energy = Number(props.energy ?? 6);
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const debris = useRef<THREE.Group>(null!);
  const beam = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const depthLeft = Math.max(0, 4 - energy * 0.42); // mm of decay remaining
  const active = depthLeft > 0.01;
  const cavityScale = 0.25 + (depthLeft / 4) * 0.75;
  const cavityColor = useMemo(
    () => new THREE.Color("#3f2a1d").lerp(new THREE.Color("#fefdf8"), 1 - depthLeft / 4),
    [depthLeft]
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Decay left", `${depthLeft.toFixed(1)} mm`],
          ["Status", active ? "Ablating decay…" : "Clean — ready to fill ✓"],
          ["Anaesthesia", active && energy > 7 ? "Often none needed" : "—"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11.5]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={group}>
          {/* molar */}
          <mesh position={[0, 2.4, 0]} castShadow>
            <cylinderGeometry args={[1.05, 0.9, 1.6, 20]} />
            <meshStandardMaterial color="#fefdf8" roughness={0.3} />
          </mesh>
          {[-0.45, 0.45].map((x) =>
            [-0.45, 0.45].map((z) => (
              <mesh key={`${x}${z}`} position={[x, 3.3, z]} castShadow>
                <coneGeometry args={[0.28, 0.4, 10]} />
                <meshStandardMaterial color="#fefdf8" roughness={0.32} />
              </mesh>
            ))
          )}
          {[-0.45, 0.45].map((x) => (
            <mesh key={x} position={[x, 1.0, 0]} castShadow>
              <coneGeometry args={[0.3, 1.6, 12]} />
              <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
            </mesh>
          ))}
          {/* the decay spot on the tooth's cheek side */}
          <mesh position={[1.02, 2.4, 0]} rotation={[0, Math.PI / 2, 0]} scale={[cavityScale, cavityScale, 1]}>
            <circleGeometry args={[0.55, 20]} />
            <meshStandardMaterial color={cavityColor} roughness={0.9} />
          </mesh>
          {/* gum */}
          <mesh position={[0, 0.75, 0]}>
            <cylinderGeometry args={[2.2, 2.6, 0.9, 24]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.7} />
          </mesh>
        </group>

        {/* erbium laser beam aimed at the cavity */}
        <mesh ref={beam} position={[2.8, 2.4, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.1, 0.1, 3.4, 10, 1, true]} />
          <meshStandardMaterial color="#4ade80" transparent opacity={0.3} emissive="#22c55e" emissiveIntensity={1.8} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[4.6, 2.4, 0]} castShadow rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.35, 0.45, 1.1, 14]} />
          <meshStandardMaterial color="#1e293b" roughness={0.4} metalness={0.5} />
        </mesh>

        {/* decay debris flying off */}
        <group ref={debris}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i} position={[1.2, 2.5, 0]}>
              <tetrahedronGeometry args={[0.09]} />
              <meshStandardMaterial color="#6b4a2f" roughness={0.9} />
            </mesh>
          ))}
        </group>

        <Label text="DECAY — laser ablates it layer by layer" position={[0, 4.6, 0]} size={0.4} color="#fca5a5" />
        <Label text="ERBIUM LASER — no drill, no vibration" position={[4.6, 3.7, 0]} size={0.36} color="#86efac" />
        <Label text="Water spray cools; healthy enamel untouched" position={[0, -0.35, 0]} size={0.34} color="#94a3b8" />

        <Animator group={group} debris={debris} beam={beam} elapsed={elapsed} speed={speed} active={active} />
      </SimCanvas>
    </div>
  );
}
