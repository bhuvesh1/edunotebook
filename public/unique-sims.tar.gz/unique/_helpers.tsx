// app/components/sims/unique/_helpers.tsx
// Shared building blocks for unique topic sims: labels, wires, cells,
// resistors, bulbs, meters, coils, magnets, arrows and animated charge flow.
// All offline/procedural — no external assets.

"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";

/* ---------------- HTML overlay label chip ---------------- */
export function Chip({
  label,
  className = "",
  dot = "#fbbf24",
}: {
  label: string;
  className?: string;
  dot?: string;
}) {
  return (
    <div
      className={`pointer-events-none absolute z-10 flex items-center gap-1.5 ${className}`}
    >
      <span
        className="h-2 w-2 shrink-0 rounded-full"
        style={{ background: dot, boxShadow: `0 0 6px ${dot}` }}
      />
      <span className="rounded-full bg-black/60 px-2.5 py-1 text-[11px] font-semibold text-slate-100 backdrop-blur-sm">
        {label}
      </span>
    </div>
  );
}

/* ---------------- Canvas text sprite (3D label) ---------------- */
export function makeLabelTexture(
  text: string,
  fg = "#ffffff",
  bg = "rgba(2,6,23,0.78)"
): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 128;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = bg;
  ctx.beginPath();
  (ctx as any).roundRect(6, 6, 500, 116, 30);
  ctx.fill();
  ctx.fillStyle = fg;
  ctx.font = "600 54px system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, 256, 68);
  const t = new THREE.CanvasTexture(c);
  t.anisotropy = 4;
  return t;
}

export function Label3D({
  text,
  position = [0, 0, 0] as [number, number, number],
  width = 1.8,
  fg = "#ffffff",
}: {
  text: string;
  position?: [number, number, number];
  width?: number;
  fg?: string;
}) {
  const tex = useMemo(() => makeLabelTexture(text, fg), [text, fg]);
  return (
    <sprite position={position} scale={[width, width / 4, 1]}>
      <spriteMaterial map={tex} transparent depthWrite={false} />
    </sprite>
  );
}

/* ---------------- Animated charge dots along a closed path ---------------- */
export function FlowDots({
  points,
  count = 22,
  speed = 1.6,
  color = "#fde047",
  size = 0.09,
  dir = 1,
}: {
  points: [number, number, number][];
  count?: number;
  speed?: number;
  color?: string;
  size?: number;
  dir?: 1 | -1;
}) {
  const mesh = useRef<THREE.InstancedMesh>(null!);
  const data = useMemo(() => {
    const pts = points.map((p) => new THREE.Vector3(...p));
    const segs: number[] = [0];
    for (let i = 0; i < pts.length; i++) {
      segs.push(segs[i] + pts[i].distanceTo(pts[(i + 1) % pts.length]));
    }
    return { pts, total: segs[segs.length - 1], segs };
  }, [points]);
  const geo = useMemo(() => new THREE.SphereGeometry(size, 10, 10), [size]);
  const mat = useMemo(
    () => new THREE.MeshBasicMaterial({ color, toneMapped: false }),
    [color]
  );
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const t0 = useMemo(() => Math.random() * 100, []);
  const t0Ref = useRef(0);
  useFrame((_, delta) => {
    if (!mesh.current) return;
    t0Ref.current += delta * speed * dir;
    const T = t0Ref.current + t0;
    for (let i = 0; i < count; i++) {
      let d =
        ((T * 1.1 + (i / count) * data.total) % data.total + data.total) %
        data.total;
      let s = 0;
      while (s < data.segs.length - 2 && data.segs[s + 1] < d) s++;
      const a = data.pts[s % data.pts.length];
      const b = data.pts[(s + 1) % data.pts.length];
      const segLen = data.segs[s + 1] - data.segs[s] || 1;
      dummy.position.lerpVectors(a, b, (d - data.segs[s]) / segLen);
      dummy.updateMatrix();
      mesh.current.setMatrixAt(i, dummy.matrix);
    }
    mesh.current.instanceMatrix.needsUpdate = true;
  });
  return <instancedMesh ref={mesh} args={[geo, mat, count]} frustumCulled={false} />;
}

/* ---------------- Wire between two points ---------------- */
export function Wire({
  from,
  to,
  radius = 0.045,
  color = "#8b9bb4",
}: {
  from: [number, number, number];
  to: [number, number, number];
  radius?: number;
  color?: string;
}) {
  const { pos, len, quat } = useMemo(() => {
    const a = new THREE.Vector3(...from);
    const b = new THREE.Vector3(...to);
    const d = b.clone().sub(a);
    const len = d.length();
    const quat = new THREE.Quaternion().setFromUnitVectors(
      new THREE.Vector3(0, 1, 0),
      d.clone().normalize()
    );
    const pos = a.clone().add(b).multiplyScalar(0.5);
    return { pos, len, quat };
  }, [from, to]);
  return (
    <mesh position={pos} quaternion={quat} castShadow>
      <cylinderGeometry args={[radius, radius, len, 10]} />
      <meshStandardMaterial color={color} roughness={0.45} metalness={0.4} />
    </mesh>
  );
}

/* ---------------- 3D arrow ---------------- */
export function Arrow3D({
  from,
  to,
  color = "#f87171",
  radius = 0.05,
  head = 0.22,
}: {
  from: [number, number, number];
  to: [number, number, number];
  color?: string;
  radius?: number;
  head?: number;
}) {
  const { pos, len, quat, tip } = useMemo(() => {
    const a = new THREE.Vector3(...from);
    const b = new THREE.Vector3(...to);
    const d = b.clone().sub(a);
    const len = d.length();
    const dir = d.clone().normalize();
    const quat = new THREE.Quaternion().setFromUnitVectors(
      new THREE.Vector3(0, 1, 0),
      dir
    );
    const shaftLen = Math.max(0.01, len - head);
    const pos = a.clone().add(dir.clone().multiplyScalar(shaftLen / 2));
    const tip = a.clone().add(dir.clone().multiplyScalar(shaftLen + head / 2));
    return { pos, len: shaftLen, quat, tip };
  }, [from, to, head]);
  return (
    <group>
      <mesh position={pos} quaternion={quat}>
        <cylinderGeometry args={[radius, radius, len, 10]} />
        <meshStandardMaterial color={color} roughness={0.4} emissive={color} emissiveIntensity={0.25} />
      </mesh>
      <mesh position={tip} quaternion={quat}>
        <coneGeometry args={[radius * 3.2, head, 12]} />
        <meshStandardMaterial color={color} roughness={0.4} emissive={color} emissiveIntensity={0.25} />
      </mesh>
    </group>
  );
}

/* ---------------- Battery cell ---------------- */
export function Cell({
  position = [0, 0, 0] as [number, number, number],
  height = 1.2,
  radius = 0.32,
  flip = false,
}: {
  position?: [number, number, number];
  height?: number;
  radius?: number;
  flip?: boolean;
}) {
  return (
    <group position={position} rotation={flip ? [Math.PI, 0, 0] : [0, 0, 0]}>
      <mesh castShadow>
        <cylinderGeometry args={[radius, radius, height, 24]} />
        <meshStandardMaterial color="#1d4ed8" roughness={0.35} metalness={0.15} />
      </mesh>
      <mesh position={[0, height / 2 + 0.07, 0]} castShadow>
        <cylinderGeometry args={[radius * 0.34, radius * 0.34, 0.14, 16]} />
        <meshStandardMaterial color="#f59e0b" metalness={0.85} roughness={0.3} />
      </mesh>
      <mesh position={[0, -height / 2 - 0.03, 0]}>
        <cylinderGeometry args={[radius * 0.92, radius * 0.92, 0.07, 24]} />
        <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
      </mesh>
      <Label3D text="+" position={[0, height / 2 + 0.5, 0]} width={0.45} fg="#fbbf24" />
      <Label3D text="−" position={[0, -height / 2 - 0.42, 0]} width={0.45} fg="#94a3b8" />
    </group>
  );
}

/* ---------------- Resistor with color bands ---------------- */
export function Resistor({
  position = [0, 0, 0] as [number, number, number],
  rotation = [0, 0, Math.PI / 2] as [number, number, number],
  bands = ["#ef4444", "#111111", "#b45309"] as string[],
  length = 1.1,
}: {
  position?: [number, number, number];
  rotation?: [number, number, number];
  bands?: string[];
  length?: number;
}) {
  return (
    <group position={position} rotation={rotation}>
      <mesh castShadow>
        <capsuleGeometry args={[0.16, Math.max(0.1, length - 0.32), 6, 14]} />
        <meshStandardMaterial color="#d9a05f" roughness={0.5} />
      </mesh>
      {bands.map((b, i) => (
        <mesh key={i} position={[(i - (bands.length - 1) / 2) * 0.24, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.168, 0.168, 0.1, 14]} />
          <meshStandardMaterial color={b} roughness={0.4} />
        </mesh>
      ))}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * (length / 2 + 0.32), 0, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.032, 0.032, 0.64, 8]} />
          <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.35} />
        </mesh>
      ))}
    </group>
  );
}

/* ---------------- Light bulb ---------------- */
export function Bulb({
  position = [0, 0, 0] as [number, number, number],
  brightness = 1,
  scale = 1,
}: {
  position?: [number, number, number];
  brightness?: number;
  scale?: number;
}) {
  const glowTex = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = c.height = 128;
    const ctx = c.getContext("2d")!;
    const g = ctx.createRadialGradient(64, 64, 4, 64, 64, 64);
    g.addColorStop(0, "rgba(255,220,130,1)");
    g.addColorStop(0.4, "rgba(255,180,80,0.55)");
    g.addColorStop(1, "rgba(255,150,40,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 128, 128);
    return new THREE.CanvasTexture(c);
  }, []);
  const b = Math.max(0, Math.min(1.4, brightness));
  return (
    <group position={position} scale={scale}>
      <mesh castShadow>
        <sphereGeometry args={[0.42, 24, 24]} />
        <meshStandardMaterial color="#e0f2fe" transparent opacity={0.26} roughness={0.12} />
      </mesh>
      <mesh>
        <torusGeometry args={[0.13, 0.04, 8, 18]} />
        <meshStandardMaterial
          color="#fbbf24"
          emissive="#f59e0b"
          emissiveIntensity={0.15 + b * 3}
          toneMapped={false}
        />
      </mesh>
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.13, -0.28, 0]}>
          <cylinderGeometry args={[0.025, 0.025, 0.34, 8]} />
          <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.35} />
        </mesh>
      ))}
      <mesh position={[0, -0.56, 0]}>
        <cylinderGeometry args={[0.17, 0.19, 0.24, 16]} />
        <meshStandardMaterial color="#94a3b8" metalness={0.9} roughness={0.3} />
      </mesh>
      <sprite scale={[2.4, 2.4, 1]}>
        <spriteMaterial map={glowTex} transparent opacity={Math.min(0.95, b * 0.9)} depthWrite={false} />
      </sprite>
    </group>
  );
}

/* ---------------- Analog meter (galvanometer / ammeter / voltmeter) ---------------- */
export function Meter({
  position = [0, 0, 0] as [number, number, number],
  size = 1,
  value = 0,
  label = "V",
  faceColor = "#f8fafc",
}: {
  position?: [number, number, number];
  size?: number;
  value?: number;
  label?: string;
  faceColor?: string;
}) {
  const needle = useRef<THREE.Group>(null!);
  const cur = useRef(0);
  useFrame((_, dt) => {
    const target = THREE.MathUtils.clamp(value, -1, 1);
    cur.current += (target - cur.current) * Math.min(1, dt * 7);
    if (needle.current) needle.current.rotation.z = -cur.current * 1.02;
  });
  const ticks = useMemo(() => {
    const arr: number[] = [];
    for (let i = -5; i <= 5; i++) arr.push((i / 5) * 1.02);
    return arr;
  }, []);
  return (
    <group position={position} scale={size}>
      <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
        <cylinderGeometry args={[0.72, 0.72, 0.3, 32]} />
        <meshStandardMaterial color="#1e293b" roughness={0.5} />
      </mesh>
      <mesh position={[0, 0, 0.16]}>
        <circleGeometry args={[0.6, 32]} />
        <meshStandardMaterial color={faceColor} roughness={0.6} />
      </mesh>
      {ticks.map((a, i) => (
        <mesh
          key={i}
          position={[Math.sin(a) * 0.48, Math.cos(a) * 0.48, 0.17]}
          rotation={[0, 0, -a]}
        >
          <boxGeometry args={[0.035, i % 5 === 0 ? 0.14 : 0.09, 0.01]} />
          <meshStandardMaterial color="#0f172a" />
        </mesh>
      ))}
      <group ref={needle} position={[0, 0, 0.2]}>
        <mesh position={[0, 0.3, 0]}>
          <boxGeometry args={[0.045, 0.62, 0.02]} />
          <meshStandardMaterial color="#dc2626" />
        </mesh>
        <mesh>
          <cylinderGeometry args={[0.07, 0.07, 0.04, 16]} />
          <meshStandardMaterial color="#0f172a" />
        </mesh>
      </group>
      <Label3D text={label} position={[0, -0.98, 0.1]} width={0.55} fg="#e2e8f0" />
    </group>
  );
}

/* ---------------- Wire coil / solenoid (helix tube) ---------------- */
export function Coil({
  position = [0, 0, 0] as [number, number, number],
  rotation = [0, 0, 0] as [number, number, number],
  turns = 8,
  radius = 0.5,
  length = 2,
  color = "#f59e0b",
  tube = 0.06,
}: {
  position?: [number, number, number];
  rotation?: [number, number, number];
  turns?: number;
  radius?: number;
  length?: number;
  color?: string;
  tube?: number;
}) {
  const geo = useMemo(() => {
    class Helix extends THREE.Curve<THREE.Vector3> {
      getPoint(t: number) {
        const a = t * turns * Math.PI * 2;
        return new THREE.Vector3(
          (t - 0.5) * length,
          Math.cos(a) * radius,
          Math.sin(a) * radius
        );
      }
    }
    // @ts-ignore - THREE.Curve constructor is protected but subclass instantiation works at runtime
    return new THREE.TubeGeometry(new Helix(), Math.max(24, turns * 14), tube, 8, false);
  }, [turns, radius, length, tube]);
  return (
    <mesh position={position} rotation={rotation} geometry={geo} castShadow>
      <meshStandardMaterial color={color} metalness={0.65} roughness={0.35} />
    </mesh>
  );
}

/* ---------------- Bar magnet (N red / S blue) ---------------- */
export function BarMagnet({
  position = [0, 0, 0] as [number, number, number],
  rotation = [0, 0, 0] as [number, number, number],
  length = 2.4,
  width = 0.62,
  showLabels = true,
}: {
  position?: [number, number, number];
  rotation?: [number, number, number];
  length?: number;
  width?: number;
  showLabels?: boolean;
}) {
  const h = length / 2;
  return (
    <group position={position} rotation={rotation}>
      <mesh position={[-h / 2, 0, 0]} castShadow>
        <boxGeometry args={[h, width, width]} />
        <meshStandardMaterial color="#2563eb" roughness={0.4} />
      </mesh>
      <mesh position={[h / 2, 0, 0]} castShadow>
        <boxGeometry args={[h, width, width]} />
        <meshStandardMaterial color="#dc2626" roughness={0.4} />
      </mesh>
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[0.08, width * 1.02, width * 1.02]} />
        <meshStandardMaterial color="#e2e8f0" metalness={0.6} roughness={0.4} />
      </mesh>
      {showLabels && (
        <>
          <Label3D text="S" position={[-h / 2, 0, width / 2 + 0.06]} width={0.4} fg="#bfdbfe" />
          <Label3D text="N" position={[h / 2, 0, width / 2 + 0.06]} width={0.4} fg="#fecaca" />
        </>
      )}
    </group>
  );
}

/* ---------------- Circular field line ---------------- */
export function RingLine({
  radius = 1,
  position = [0, 0, 0] as [number, number, number],
  rotation = [0, 0, 0] as [number, number, number],
  color = "#38bdf8",
  opacity = 0.65,
}: {
  radius?: number;
  position?: [number, number, number];
  rotation?: [number, number, number];
  color?: string;
  opacity?: number;
}) {
  const obj = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 72; i++) {
      const a = (i / 72) * Math.PI * 2;
      pts.push(new THREE.Vector3(Math.cos(a) * radius, Math.sin(a) * radius, 0));
    }
    const g = new THREE.BufferGeometry().setFromPoints(pts);
    return new THREE.Line(g, new THREE.LineBasicMaterial({ color, transparent: true, opacity }));
  }, [radius, color, opacity]);
  return <primitive object={obj} position={position} rotation={rotation} />;
}

/* ---------------- Polyline in 3D ---------------- */
export function Line3D({
  points,
  color = "#fbbf24",
  opacity = 0.9,
}: {
  points: [number, number, number][];
  color?: string;
  opacity?: number;
}) {
  const obj = useMemo(() => {
    const g = new THREE.BufferGeometry().setFromPoints(points.map((p) => new THREE.Vector3(...p)));
    return new THREE.Line(g, new THREE.LineBasicMaterial({ color, transparent: true, opacity }));
  }, [points, color, opacity]);
  return <primitive object={obj} />;
}

/* ---------------- Capacitor (two plates) ---------------- */
export function Capacitor({
  position = [0, 0, 0] as [number, number, number],
  rotation = [0, 0, 0] as [number, number, number],
  gap = 0.22,
}: {
  position?: [number, number, number];
  rotation?: [number, number, number];
  gap?: number;
}) {
  return (
    <group position={position} rotation={rotation}>
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * gap, 0, 0]} castShadow>
            <boxGeometry args={[0.06, 0.9, 0.7]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
          </mesh>
          <mesh position={[s * (gap + 0.28), 0, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.035, 0.035, 0.5, 8]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.35} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

/* ---------------- AC source symbol ---------------- */
export function ACSource({
  position = [0, 0, 0] as [number, number, number],
  size = 0.55,
}: {
  position?: [number, number, number];
  size?: number;
}) {
  const wave = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 40; i++) {
      const x = (i / 40 - 0.5) * size * 1.1;
      pts.push(new THREE.Vector3(x, Math.sin((i / 40) * Math.PI * 2) * size * 0.28, 0.02));
    }
    const g = new THREE.BufferGeometry().setFromPoints(pts);
    return new THREE.Line(g, new THREE.LineBasicMaterial({ color: "#fbbf24" }));
  }, [size]);
  return (
    <group position={position}>
      <mesh castShadow>
        <cylinderGeometry args={[size, size, 0.24, 28]} />
        <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
      </mesh>
      <mesh position={[0, 0, 0.13]}>
        <circleGeometry args={[size * 0.82, 28]} />
        <meshStandardMaterial color="#082f49" roughness={0.6} />
      </mesh>
      <primitive object={wave} position={[0, 0, 0.14]} />
      <Label3D text="AC" position={[0, -size - 0.42, 0]} width={0.6} fg="#7dd3fc" />
    </group>
  );
}
