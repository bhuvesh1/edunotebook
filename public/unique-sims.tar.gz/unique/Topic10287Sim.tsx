// Gynecology: fibroids, ovarian cysts and tumors, cervical cancer screening.
// Lumps on the uterus wall (fibroids), a ballooning ovarian cyst, and the
// Pap-smear screening that catches cervical cancer early.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "fibroids", options: ["normal", "fibroids", "ovarian_cyst", "screening"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Fibroids, Ovarian Cysts & Pap Smear",
  blurb: "Lumps growing on the womb, a swelling ovarian cyst — and the simple Pap-smear brush that screens for cervical cancer.",
};

function Animator({
  group, fibroids, cyst, brush, elapsed, speed, condition,
}: {
  group: React.RefObject<THREE.Group>;
  fibroids: React.RefObject<THREE.Group>;
  cyst: React.RefObject<THREE.Mesh>;
  brush: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    if (fibroids.current) {
      fibroids.current.visible = condition === "fibroids";
      fibroids.current.children.forEach((f, i) => {
        (f as THREE.Mesh).scale.setScalar(1 + 0.1 * Math.sin(t * 2 + i * 2.4));
      });
    }
    if (cyst.current) {
      cyst.current.visible = condition === "ovarian_cyst";
      // cyst slowly fills
      const fill = 0.8 + 0.35 * (0.5 + 0.5 * Math.sin(t * 0.6));
      cyst.current.scale.set(fill, fill * 1.25, fill);
    }
    if (brush.current) {
      brush.current.visible = condition === "screening";
      // brush rotates to collect cells
      brush.current.rotation.y = t * 3;
      brush.current.position.z = 0.3 + Math.sin(t * 1.5) * 0.15;
    }
  });
  return null;
}

export function Topic10287Sim(props: SimProps) {
  const condition = String(props.condition ?? "fibroids");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const fibroids = useRef<THREE.Group>(null!);
  const cyst = useRef<THREE.Mesh>(null!);
  const brush = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    normal: "Normal", fibroids: "Uterine fibroids", ovarian_cyst: "Ovarian cyst", screening: "Cervical screening (Pap smear)",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10.5]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* uterus */}
          <mesh position={[0, 2.2, -0.3]} scale={[1.0, 1.15, 0.85]} castShadow>
            <sphereGeometry args={[0.95, 28, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.6} />
          </mesh>
          {/* fibroids: round firm lumps on/in the wall */}
          <group ref={fibroids} visible={false}>
            {[[-0.7, 2.7, 0.1], [0.65, 1.7, 0.15], [0.1, 2.2, 0.5], [-0.3, 1.6, -0.6]].map(([x, y, z], i) => (
              <mesh key={i} position={[x, y, z]} castShadow>
                <sphereGeometry args={[0.3 - (i % 2) * 0.08, 18, 14]} />
                <meshStandardMaterial color="#fbcfe8" roughness={0.35} emissive="#be185d" emissiveIntensity={0.25} />
              </mesh>
            ))}
          </group>
          {/* cervix below */}
          <mesh position={[0, 0.9, -0.3]} castShadow>
            <cylinderGeometry args={[0.3, 0.36, 0.7, 14]} />
            <meshStandardMaterial color={condition === "screening" ? "#fbbf24" : "#f0abfc"} roughness={0.5}
              emissive={condition === "screening" ? "#92400e" : "#000000"} emissiveIntensity={0.5} />
          </mesh>
          {/* ovaries; right one carries the cyst */}
          <mesh position={[-1.7, 2.6, -0.2]} scale={[1, 1.25, 0.8]} castShadow>
            <sphereGeometry args={[0.3, 16, 12]} />
            <meshStandardMaterial color="#fde68a" roughness={0.5} />
          </mesh>
          <group position={[1.7, 2.6, -0.2]}>
            <mesh scale={[1, 1.25, 0.8]} castShadow>
              <sphereGeometry args={[0.3, 16, 12]} />
              <meshStandardMaterial color="#fde68a" roughness={0.5} />
            </mesh>
            <mesh ref={cyst} position={[0, 0.35, 0.2]} visible={false} castShadow>
              <sphereGeometry args={[0.45, 20, 14]} />
              <meshStandardMaterial color="#7dd3fc" roughness={0.2} transparent opacity={0.75} emissive="#0369a1" emissiveIntensity={0.4} />
            </mesh>
          </group>
          {/* Pap smear: speculum + brush at the cervix */}
          {condition === "screening" && (
            <group ref={brush} position={[0, 0.9, 0.3]}>
              <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
                <cylinderGeometry args={[0.05, 0.05, 1.6, 10]} />
                <meshStandardMaterial color="#e2e8f0" roughness={0.4} />
              </mesh>
              <mesh position={[0, 0, 0.85]} castShadow>
                <coneGeometry args={[0.16, 0.35, 12]} />
                <meshStandardMaterial color="#f472b6" roughness={0.5} />
              </mesh>
              {/* collected cells */}
              {[0, 1, 2, 3].map((i) => (
                <mesh key={i} position={[Math.cos(i * 1.7) * 0.3, Math.sin(i * 2.3) * 0.3, 0.6]}>
                  <sphereGeometry args={[0.06, 8, 6]} />
                  <meshBasicMaterial color="#fde68a" />
                </mesh>
              ))}
            </group>
          )}
          <Label text="Uterus" position={[-1.9, 2.9, -0.3]} size={0.55} color="#f9a8d4" />
          <Label text="Ovary" position={[1.7, 3.45, -0.2]} size={0.5} color="#fde68a" />
          <Label text="Cervix" position={[1.15, 0.9, -0.3]} size={0.5} color="#f0abfc" />
          {condition === "fibroids" && <Label text="⚠ Fibroids: benign muscle lumps" position={[0, 0.15, 0]} size={0.55} color="#fbcfe8" />}
          {condition === "ovarian_cyst" && <Label text="⚠ Fluid-filled cyst growing" position={[1.7, 1.5, 0.2]} size={0.55} color="#7dd3fc" />}
          {condition === "screening" && <Label text="🔬 Pap smear collects cells" position={[0, -0.05, 0.4]} size={0.55} color="#fde68a" />}
          {condition === "normal" && <Label text="All clear ✓" position={[0, 0.15, 0]} size={0.55} color="#86efac" />}
        </group>
        <Animator group={group} fibroids={fibroids} cyst={cyst} brush={brush} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
