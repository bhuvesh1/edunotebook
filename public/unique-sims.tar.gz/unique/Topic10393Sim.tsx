"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "layers", label: "Increments placed", kind: "slider", min: 1, max: 3, step: 1, default: 2, unit: "" },
  { key: "cure", label: "Light-cure", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["off", "on"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Composite resins: composition, polymerization, bonding",
  blurb: "Layer tooth-colored composite in 2 mm increments, zap each with blue light, and watch monomers link into a hard polymer network.",
};

const SHADES = ["#fde68a", "#fcd34d", "#fbbf24"];

// polymer chains linking up under cure
function PolymerNet({ cureOn, speed }: { cureOn: boolean; speed: number }) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) {
      g.current.children.forEach((c, i) => {
        const target = cureOn ? 1 : 0.15;
        ((c as THREE.Mesh).material as THREE.MeshBasicMaterial).opacity = THREE.MathUtils.lerp(((c as THREE.Mesh).material as THREE.MeshBasicMaterial).opacity, target, 0.05);
      });
    }
  });
  const links: [number, number][] = [[0, 1], [1, 2], [2, 3], [3, 0], [0, 2], [4, 5], [5, 6], [6, 4]];
  const nodes: [number, number][] = [[-1.4, 0.6], [-0.4, 1.1], [0.7, 0.7], [0.2, -0.3], [1.8, -0.8], [2.6, 0.1], [2.2, -1.4]];
  return (
    <group ref={g} position={[-4.6, 2.8, 0]}>
      {nodes.map(([x, y], i) => (
        <mesh key={i} position={[x, y, 0]}>
          <sphereGeometry args={[0.16, 10, 8]} />
          <meshBasicMaterial color="#93c5fd" transparent opacity={0.15} />
        </mesh>
      ))}
      {links.map(([a, b], i) => {
        const from = new THREE.Vector3(...nodes[a], 0);
        const to = new THREE.Vector3(...nodes[b], 0);
        const mid = from.clone().add(to).multiplyScalar(0.5);
        const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), to.clone().sub(from).normalize());
        return (
          <mesh key={"l" + i} position={mid} quaternion={quat}>
            <cylinderGeometry args={[0.045, 0.045, from.distanceTo(to), 6]} />
            <meshBasicMaterial color="#3b82f6" transparent opacity={0.15} />
          </mesh>
        );
      })}
    </group>
  );
}

function CompositeScene({ layers, cure, speed, showLabels }: { layers: number; cure: string; speed: number; showLabels: boolean }) {
  const beam = useRef<THREE.Mesh>(null!);
  const tip = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const cureOn = cure === "on";

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (beam.current) {
      beam.current.visible = cureOn;
      (beam.current.material as THREE.MeshBasicMaterial).opacity = 0.2 + Math.sin(elapsed.current * 12) * 0.07;
    }
    if (tip.current) tip.current.position.y = 3.4 + Math.sin(elapsed.current * 1.4) * 0.15;
  });

  return (
    <group>
      {/* tooth with box cavity */}
      <group position={[1.4, 0, 0]}>
        <mesh position={[0, 0.4, 0]} castShadow>
          <boxGeometry args={[3, 2.8, 2.8]} />
          <meshStandardMaterial color="#fef9c3" roughness={0.25} />
        </mesh>
        <mesh position={[0, -1.8, 0]} castShadow>
          <cylinderGeometry args={[1.3, 0.5, 3, 16]} />
          <meshStandardMaterial color="#fde68a" roughness={0.4} />
        </mesh>
        {/* etched cavity walls (frosty) */}
        <mesh position={[0, 1.3, 0]}>
          <boxGeometry args={[1.7, 1.3, 1.7]} />
          <meshStandardMaterial color="#e0f2fe" roughness={0.95} transparent opacity={0.5} />
        </mesh>
        {/* bonding agent glint */}
        <mesh position={[0, 0.72, 0]}>
          <boxGeometry args={[1.66, 0.08, 1.66]} />
          <meshBasicMaterial color="#fbbf24" transparent opacity={0.6} />
        </mesh>
        {/* composite increments */}
        {Array.from({ length: 3 }).map((_, i) => (
          <mesh key={i} position={[0, 0.85 + i * 0.42, 0]} visible={i < layers} castShadow>
            <boxGeometry args={[1.62, 0.4, 1.62]} />
            <meshStandardMaterial color={SHADES[i]} roughness={cureOn ? 0.5 : 0.12} />
          </mesh>
        ))}
      </group>

      {/* curing light */}
      <group ref={tip} position={[-1.6, 3.4, 0.6]} rotation={[0.35, 0, -0.5]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.32, 0.42, 1.5, 14]} />
          <meshStandardMaterial color="#1e293b" roughness={0.4} />
        </mesh>
        <mesh position={[0, -0.9, 0]}>
          <cylinderGeometry args={[0.46, 0.46, 0.18, 14]} />
          <meshBasicMaterial color="#3b82f6" />
        </mesh>
        <mesh ref={beam} position={[0, -2.5, 0]} visible={false}>
          <coneGeometry args={[1.2, 3.2, 18, 1, true]} />
          <meshBasicMaterial color="#60a5fa" transparent opacity={0.22} side={THREE.DoubleSide} />
        </mesh>
      </group>

      <PolymerNet cureOn={cureOn} speed={speed} />

      {showLabels && (
        <>
          <Text position={[1.4, 3.4, 0]} fontSize={0.42} color="#fcd34d">Composite — {layers} × 2 mm increments</Text>
          <Text position={[-4.6, 4.6, 0]} fontSize={0.4} color="#93c5fd">Polymerization: monomers → network</Text>
          <Text position={[1.4, -4.2, 0]} fontSize={0.4} color="#e2e8f0" maxWidth={10}>
            {cureOn ? "Blue light (470 nm) fires the photoinitiator — 20 s per layer" : "No cure yet — composite stays soft and shapeable"}
          </Text>
        </>
      )}
    </group>
  );
}

export function Topic10393Sim(props: SimProps) {
  const layers = Math.round(Number(props.layers ?? 2));
  const cure = String(props.cure ?? "on");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Increments", `${layers} / 3`],
          ["Cure", cure === "on" ? "light ON" : "off"],
          ["Made of", "Bis-GMA + silica filler"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0.5, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.6, 0]} receiveShadow>
          <planeGeometry args={[36, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <CompositeScene layers={layers} cure={cure} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
