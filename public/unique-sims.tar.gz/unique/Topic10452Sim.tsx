"use client";
// Irrigation and Intracanal Medicaments — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "flow", label: "Irrigant flow", kind: "slider", min: 0.5, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Irrigation and Intracanal Medicaments",
  blurb: "A syringe bathes the canal in irrigant — watch the blue droplets wash debris down and out the apex.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const tipY = 3.05;
    for (let i = 0; i < 12; i++) {
      const d: any = g("drop" + i);
      if (d) {
        const ph = (t * 1.4 * p.flow + i / 12) % 1;
        d.position.set(0.03 * Math.sin(t * 6 + i), tipY - ph * 2.6, 0.03 * Math.cos(t * 5 + i));
        d.scale.setScalar(0.075 * (1 - ph * 0.4));
      }
    }
    const pool: any = g("pool");
    if (pool) pool.scale.setScalar(0.22 + 0.06 * Math.sin(t * 5));
    const med: any = g("med");
    if (med) {
      const ph = (t * 0.25) % 1;
      med.position.y = 1.2 + ph * 0.6;
      (med.material as any).opacity = 0.85 * (1 - ph);
    }
    group.current.rotation.y = Math.sin(t * 0.25) * 0.25;
  });
  return null;
}

export function Topic10452Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const flow = Number(props.flow ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, flow };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Irrigant", "Sodium hypochlorite"],
          ["Flow", `${(flow * 2).toFixed(1)} mL/min`],
          ["Speed", `${speed.toFixed(1)}×`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1, 0]} scale={1.5} showCanal name="endo" />
          <GumSlab position={[0, 0.1, 0]} scale={1.2} />
          <group position={[1.35, 4.1, 0]} rotation={[0, 0, -0.55]}>
            <mesh>
              <cylinderGeometry args={[0.24, 0.24, 1.3, 16]} />
              <meshStandardMaterial color="#bae6fd" roughness={0.2} transparent opacity={0.75} />
            </mesh>
            <mesh position={[0, 0.35, 0]}>
              <cylinderGeometry args={[0.2, 0.2, 0.5, 16]} />
              <meshStandardMaterial color="#0284c7" roughness={0.4} />
            </mesh>
            <mesh position={[0, -0.95, 0]}>
              <cylinderGeometry args={[0.035, 0.02, 0.7, 8]} />
              <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.25} />
            </mesh>
          </group>
          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((i) => (
            <mesh key={i} name={"drop" + i}>
              <sphereGeometry args={[1, 10, 10]} />
              <meshStandardMaterial color="#38bdf8" roughness={0.15} transparent opacity={0.9} />
            </mesh>
          ))}
          <mesh name="pool" position={[0, 0.35, 0]}>
            <sphereGeometry args={[1, 12, 12]} />
            <meshStandardMaterial color="#0ea5e9" emissive="#0ea5e9" emissiveIntensity={0.5} transparent opacity={0.8} />
          </mesh>
          <mesh name="med" position={[0, 1.2, 0]}>
            <sphereGeometry args={[0.16, 12, 12]} />
            <meshStandardMaterial color="#fde047" emissive="#fde047" emissiveIntensity={0.6} transparent opacity={0.85} />
          </mesh>
          <Label text="Irrigant syringe" position={[2.9, 4.4, 0]} size={0.42} />
          <Label text="Medicament dissolving" position={[-2.4, 1.6, 0]} size={0.42} color="#fde047" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
