// Adverse drug reactions: warning beacons flash on affected organs while ADR
// reports fly to the pharmacovigilance centre.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "rate", label: "ADR report rate", kind: "slider", min: 0.5, max: 3, step: 0.5, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Adverse drug reactions",
  blurb: "Warning beacons flash on affected organs while ADR reports fly to the pharmacovigilance centre.",
};

const BEACONS: { pos: [number, number, number]; label: string }[] = [
  { pos: [-2.0, 1.7, 0.55], label: "liver injury" },
  { pos: [-2.95, 1.15, 0.5], label: "kidney injury" },
  { pos: [-1.95, 2.45, 0.4], label: "skin rash" },
];

function Animator({ beacons, reports, elapsed, rate, setTick }: {
  beacons: React.RefObject<(THREE.Mesh | null)[]>;
  reports: React.RefObject<(THREE.Group | null)[]>;
  elapsed: React.RefObject<number>;
  rate: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * rate;
    const t = elapsed.current;
    beacons.current.forEach((b, i) => {
      if (!b) return;
      const s = 0.7 + Math.abs(Math.sin(t * 3 + i * 2)) * 0.7;
      b.scale.setScalar(s);
      ((b as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = 0.6 + Math.abs(Math.sin(t * 3 + i * 2)) * 1.4;
    });
    reports.current.forEach((r, i) => {
      if (!r) return;
      // fly from patient (x=-1) to ADR centre (x=5)
      const f = (t * 0.35 + i / 6) % 1;
      r.position.set(-1 + f * 6, 1.6 + Math.sin(f * Math.PI) * 1.2, 0.5 - f * 0.5);
      r.rotation.y = t * 4 + i;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(elapsed.current * 10)); }
  });
  return null;
}

export function Topic10107Sim(props: SimProps) {
  const rate = Number(props.rate ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const beacons = useRef<(THREE.Mesh | null)[]>([]);
  const reports = useRef<(THREE.Group | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const filed = Math.floor(elapsed.current * 8);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Reports filed", `${filed}`],
          ["Serious ADRs flagged", `${Math.floor(filed * 0.2)}`],
        ]}
      />
      <SimCanvas cameraPosition={[2, 4, 12]} target={[1.5, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* patient figure */}
        <group position={[-2.5, 0, 0]}>
          <mesh position={[0, 1.6, 0]} castShadow>
            <capsuleGeometry args={[0.55, 1.4, 8, 16]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.6} />
          </mesh>
          <mesh position={[0, 3.05, 0]} castShadow>
            <sphereGeometry args={[0.42, 20, 16]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
        </group>
        {showLabels && <Label text="patient on drug" position={[-2.5, 3.9, 0]} color="#bae6fd" />}

        {/* warning beacons on organs */}
        {BEACONS.map((b, i) => (
          <group key={i}>
            <mesh
              ref={(m) => { beacons.current[i] = m; }}
              position={[b.pos[0], b.pos[1], b.pos[2]]}
            >
              <octahedronGeometry args={[0.28]} />
              <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1} />
            </mesh>
            {showLabels && <Label text={b.label} position={[b.pos[0], b.pos[1] + 0.65, b.pos[2]]} size={0.4} color="#fde68a" />}
          </group>
        ))}

        {/* ADR reporting centre */}
        <group position={[5, 0, 0]}>
          <mesh position={[0, 1.1, 0]} castShadow>
            <boxGeometry args={[2.2, 2.2, 1.6]} />
            <meshStandardMaterial color="#1e3a8a" roughness={0.5} />
          </mesh>
          <mesh position={[0, 2.5, 0]}>
            <boxGeometry args={[2.6, 0.25, 2]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.5} />
          </mesh>
        </group>
        {showLabels && <Label text="Pharmacovigilance centre" position={[5, 3.3, 0]} color="#fde68a" />}

        {/* flying ADR reports */}
        {Array.from({ length: 6 }).map((_, i) => (
          <group key={i} ref={(g) => { reports.current[i] = g; }}>
            <mesh castShadow>
              <boxGeometry args={[0.34, 0.24, 0.06]} />
              <meshStandardMaterial color="#fde047" emissive="#a16207" emissiveIntensity={0.4} />
            </mesh>
          </group>
        ))}

        <Animator beacons={beacons} reports={reports} elapsed={elapsed} rate={rate} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
