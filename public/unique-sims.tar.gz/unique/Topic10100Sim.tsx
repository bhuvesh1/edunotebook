"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "gland", label: "Gland", kind: "select", min: 0, max: 0, step: 1, default: "pancreas", options: ["thyroid", "adrenal", "pituitary", "pancreas"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Endocrine Glands & Hormones",
  blurb: "Four glands release their hormones on demand: thyroid, adrenal, pituitary and pancreatic islets.",
};

function Animator({ root, horm, elapsed, speed, gp }: { root: RefObject<THREE.Group>; horm: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; gp: [number, number, number] }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (horm.current) {
      horm.current.children.forEach((m, i) => {
        const q = (t * 0.55 + i / 8) % 1;
        m.position.set(gp[0] + Math.sin(i * 2.6) * (0.4 + q * 1.6), gp[1] - q * 1.8, gp[2] + Math.cos(i * 1.9) * (0.4 + q * 1.2));
        m.scale.setScalar(1 - q * 0.4);
      });
    }
    if (root.current) root.current.rotation.y = Math.sin(t * 0.2) * 0.1;
  });
  return null;
}

export function Topic10100Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const gland = String(props.gland ?? "pancreas");
  const HORM: Record<string, string> = { "thyroid": "T3 / T4", "adrenal": "cortisol", "pituitary": "GH", "pancreas": "insulin" };
  const GPOS: Record<string, [number, number, number]> = { "thyroid": [-4.2, 2.6, 0], "adrenal": [-1.2, 2.4, 0], "pituitary": [1.8, 3, 0], "pancreas": [4, 1.6, 0] };
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const horm = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Gland", gland],
          ["Hormone", HORM[gland] ?? ""],
          ["Control", "hypothalamus \u2013 pituitary axis"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <group position={[-4.2, 2.6, 0]}>
            <mesh position={[-0.45, 0, 0]} castShadow><sphereGeometry args={[0.5, 18, 18]} /><meshStandardMaterial color={gland === "thyroid" ? "#f472b6" : "#6b7280"} emissive={gland === "thyroid" ? "#ec4899" : "#000000"} emissiveIntensity={0.5} /></mesh>
            <mesh position={[0.45, 0, 0]} castShadow><sphereGeometry args={[0.5, 18, 18]} /><meshStandardMaterial color={gland === "thyroid" ? "#f472b6" : "#6b7280"} emissive={gland === "thyroid" ? "#ec4899" : "#000000"} emissiveIntensity={0.5} /></mesh>
            <mesh><boxGeometry args={[0.5, 0.3, 0.3]} /><meshStandardMaterial color={gland === "thyroid" ? "#f472b6" : "#6b7280"} /></mesh>
            <Label text="thyroid \u2014 T3/T4" position={[0, -1, 0]} size={0.38} color="#f472b6" />
          </group>
          <group position={[-1.2, 2.4, 0]}>
            <mesh position={[0, -0.5, 0]} scale={[1, 1.3, 0.9]}><sphereGeometry args={[0.55, 16, 16]} /><meshStandardMaterial color="#7c2d12" roughness={0.6} /></mesh>
            <mesh position={[0, 0.35, 0]} castShadow><sphereGeometry args={[0.42, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2]} /><meshStandardMaterial color={gland === "adrenal" ? "#facc15" : "#6b7280"} emissive={gland === "adrenal" ? "#eab308" : "#000000"} emissiveIntensity={0.5} /></mesh>
            <Label text="adrenal \u2014 cortisol" position={[0, -1.5, 0]} size={0.38} color="#facc15" />
          </group>
          <group position={[1.8, 3, 0]}>
            <mesh position={[0, -0.5, 0]}><cylinderGeometry args={[0.12, 0.12, 0.9, 10]} /><meshStandardMaterial color="#94a3b8" /></mesh>
            <mesh castShadow><sphereGeometry args={[0.4, 16, 16]} /><meshStandardMaterial color={gland === "pituitary" ? "#38bdf8" : "#6b7280"} emissive={gland === "pituitary" ? "#0284c7" : "#000000"} emissiveIntensity={0.6} /></mesh>
            <Label text="pituitary \u2014 GH" position={[0, -1.3, 0]} size={0.38} color="#38bdf8" />
          </group>
          <group position={[4, 1.6, 0]}>
            <mesh scale={[1.8, 0.7, 0.9]} castShadow><sphereGeometry args={[0.6, 18, 18]} /><meshStandardMaterial color="#fdba74" roughness={0.55} /></mesh>
            {[0, 1, 2, 3].map((i) => (
              <mesh key={i} position={[(i - 1.5) * 0.4, 0.25, 0.25]}>
                <sphereGeometry args={[0.16, 10, 10]} /><meshStandardMaterial color={gland === "pancreas" ? "#fbbf24" : "#6b7280"} emissive={gland === "pancreas" ? "#f59e0b" : "#000000"} emissiveIntensity={0.8} />
              </mesh>
            ))}
            <Label text="pancreas islets \u2014 insulin" position={[0, -1, 0]} size={0.38} color="#fdba74" />
          </group>
          <group ref={horm}>
            {Array.from({ length: 8 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.14, 10, 10]} /><meshStandardMaterial color="#fef08a" emissive="#facc15" emissiveIntensity={1.2} /></mesh>
            ))}
          </group>
          <Label text={`${gland}: releasing ${HORM[gland]}`} position={[0, 4.8, 0]} size={0.48} color="#fef08a" />
        </group>
        <Animator root={root} horm={horm} elapsed={elapsed} speed={speed} gp={GPOS[gland] ?? [0, 2, 0]} />
      </SimCanvas>
    </div>
  );
}
