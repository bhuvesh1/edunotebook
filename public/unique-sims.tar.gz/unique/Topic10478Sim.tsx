"use client";
// Plaque and Calculus Formation — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "days", label: "Days without brushing", kind: "slider", min: 0, max: 7, step: 0.5, default: 3, unit: " days" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Plaque and Calculus Formation",
  blurb: "Skip brushing for a week — green biofilm creeps over the tooth, then hardens into brown calculus.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const n = 14;
    const count = Math.floor(Math.min(1, p.days / 7) * n);
    const hard = Math.min(1, Math.max(0, (p.days - 4) / 3));
    for (let i = 0; i < n; i++) {
      const d: any = g("plq" + i);
      if (d) {
        d.visible = i < count;
        const c = (d.material as any).color;
        c.setRGB(0.35 + hard * 0.35, 0.65 - hard * 0.3, 0.2 - hard * 0.1);
        d.scale.setScalar(0.11 + 0.02 * Math.sin(t * 3 + i));
      }
    }
  });
  return null;
}

export function Topic10478Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const days = Number(props.days ?? 3);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, days };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Day", days.toFixed(1)],
          ["Plaque", `${Math.round(Math.min(1, days / 7) * 100)}% coverage`],
          ["Calculus", days > 4 ? "Hardened — needs scaling" : "Not yet"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1.2, 0]} scale={1.7} />
          <GumSlab position={[0, 0.2, 0]} scale={1.2} />
          {[
            [-0.5, 1.9, 0.55], [0.4, 2.1, 0.5], [0.1, 1.6, 0.62], [-0.2, 2.3, 0.35],
            [0.55, 1.75, 0.4], [-0.65, 1.5, 0.45], [0.25, 2.45, 0.3], [-0.35, 1.35, 0.55],
            [0.6, 2.2, 0.25], [-0.05, 2.0, 0.6], [0.35, 1.4, 0.5], [-0.55, 2.15, 0.3],
            [0.15, 2.6, 0.15], [-0.3, 1.7, -0.5],
          ].map((pt, i) => (
            <mesh key={i} name={"plq" + i} position={[pt[0], pt[1], pt[2]]}>
              <sphereGeometry args={[1, 8, 8]} />
              <meshStandardMaterial color="#59a83c" roughness={0.9} />
            </mesh>
          ))}
          <Label text="Soft plaque (biofilm)" position={[2.6, 2.6, 0]} size={0.42} color="#84cc16" />
          <Label text="Hard calculus" position={[-2.7, 1.2, 0]} size={0.42} color="#a16207" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
