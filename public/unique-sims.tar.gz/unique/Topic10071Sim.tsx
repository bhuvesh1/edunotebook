"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "DNA Replication Fork",
  blurb: "Helicase unzips the double helix while DNA polymerase builds the new leading strand and Okazaki fragments.",
};

function Animator({ root, up, dn, lead, okz, heli, pol, elapsed, speed }: { root: RefObject<THREE.Group>; up: RefObject<THREE.Group>; dn: RefObject<THREE.Group>; lead: RefObject<THREE.Group>; okz: RefObject<THREE.Group>; heli: RefObject<THREE.Mesh>; pol: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const fx = -2.5 + ((t * 0.55) % 1) * 5;
    const sepOf = (x: number) => Math.min(1, Math.max(0, (x - fx) / 1.1));
    const X = (i: number) => -4.2 + i * 0.45;
    if (up.current) up.current.children.forEach((m, i) => {
      const s = sepOf(X(i)); m.position.set(X(i), 1.62 + s * 0.95, 0);
    });
    if (dn.current) dn.current.children.forEach((m, i) => {
      const s = sepOf(X(i)); m.position.set(X(i), 1.38 - s * 0.95, 0);
    });
    if (lead.current) lead.current.children.forEach((m, i) => {
      const done = X(i) < fx - 0.5;
      m.scale.setScalar(done ? 1 : 0.001);
      m.position.set(X(i), 1.38 - sepOf(X(i)) * 0.95 - 0.34, 0);
    });
    if (okz.current) okz.current.children.forEach((m, i) => {
      const gi = Math.floor(i / 3), done = X(gi * 4) < fx - 0.5;
      m.scale.setScalar(done ? 1 : 0.001);
      m.position.set(X(gi * 4) + (i % 3) * 0.4, 1.62 + sepOf(X(gi * 4)) * 0.95 + 0.34, 0);
    });
    if (heli.current) heli.current.position.set(fx, 1.5, 0);
    if (pol.current) { pol.current.position.set(fx - 0.8, 0.9, 0); pol.current.scale.setScalar(1 + 0.12 * Math.sin(t * 9)); }
  });
  return null;
}

export function Topic10071Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const up = useRef<THREE.Group>(null!);
  const dn = useRef<THREE.Group>(null!);
  const lead = useRef<THREE.Group>(null!);
  const okz = useRef<THREE.Group>(null!);
  const heli = useRef<THREE.Mesh>(null!);
  const pol = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["New strand", "5\u2032 \u2192 3\u2032"],
          ["Enzyme", "DNA polymerase III"],
          ["Fork speed", "\u2248 1000 nt/s"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <group ref={up}>
            {Array.from({ length: 14 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.17, 12, 12]} /><meshStandardMaterial color="#60a5fa" roughness={0.4} /></mesh>
            ))}
          </group>
          <group ref={dn}>
            {Array.from({ length: 14 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.17, 12, 12]} /><meshStandardMaterial color="#f472b6" roughness={0.4} /></mesh>
            ))}
          </group>
          <group ref={lead}>
            {Array.from({ length: 14 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.15, 12, 12]} /><meshStandardMaterial color="#4ade80" emissive="#22c55e" emissiveIntensity={0.7} /></mesh>
            ))}
          </group>
          <group ref={okz}>
            {Array.from({ length: 9 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.15, 12, 12]} /><meshStandardMaterial color="#facc15" emissive="#eab308" emissiveIntensity={0.7} /></mesh>
            ))}
          </group>
          <mesh ref={heli} rotation={[0, 0, -Math.PI / 2]} castShadow>
            <coneGeometry args={[0.4, 1.1, 14]} /><meshStandardMaterial color="#fb923c" roughness={0.4} />
          </mesh>
          <mesh ref={pol} castShadow>
            <sphereGeometry args={[0.5, 18, 18]} /><meshStandardMaterial color="#38bdf8" roughness={0.4} />
          </mesh>
          <Label text="helicase" position={[0, 3.3, 0]} size={0.45} color="#fb923c" />
          <Label text="DNA pol III" position={[-3.4, 0.5, 0]} size={0.42} color="#38bdf8" />
          <Label text="leading strand" position={[4.6, 0.5, 0]} size={0.42} color="#4ade80" />
          <Label text="lagging \u2014 Okazaki fragments" position={[4.6, 3.1, 0]} size={0.42} color="#facc15" />
        </group>
        <Animator root={root} up={up} dn={dn} lead={lead} okz={okz} heli={heli} pol={pol} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
