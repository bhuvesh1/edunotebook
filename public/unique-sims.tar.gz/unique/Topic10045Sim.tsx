// GI: saliva, gastric, pancreatic & biliary secretion — the stomach churns a
// food bolus with acid splash, the pancreas drips enzymes, and the gallbladder
// squirts green bile into the duodenum.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "meal", label: "Meal size", kind: "slider", min: 0.3, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "acid", label: "Gastric acid", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "GI: Digestive Secretions",
  blurb: "The stomach churns with acid, the pancreas drips enzymes and the gallbladder squirts bile into the duodenum.",
};

function Animator({
  bolus, acidDrops, enzymes, bile, stomach, elapsed, meal, acid, speed,
}: {
  bolus: React.RefObject<THREE.Group>;
  acidDrops: React.RefObject<THREE.Group>;
  enzymes: React.RefObject<THREE.Group>;
  bile: React.RefObject<THREE.Group>;
  stomach: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  meal: number;
  acid: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (stomach.current) {
      const s = 1 + 0.06 * Math.sin(t * 4);
      stomach.current.scale.set(1 / s, s, 1 / s); // churning
    }
    if (bolus.current) {
      bolus.current.children.forEach((m, i) => {
        m.position.x = Math.sin(t * 3 + i * 2.1) * 0.35;
        m.position.y = 2.2 + Math.cos(t * 3.6 + i * 1.7) * 0.3;
      });
    }
    if (acidDrops.current) {
      acidDrops.current.children.forEach((m, i) => {
        const ph = ((t * 0.8 * acid + i / 8) % 1 + 1) % 1;
        m.position.y = 3.6 - ph * 2.0;
        m.visible = acid > 0.02;
      });
    }
    if (enzymes.current) {
      enzymes.current.children.forEach((m, i) => {
        const ph = ((t * 0.5 * meal + i / 6) % 1 + 1) % 1;
        m.position.y = 3.3 - ph * 1.5;
      });
    }
    if (bile.current) {
      bile.current.children.forEach((m, i) => {
        const ph = ((t * 0.6 * meal + i / 5) % 1 + 1) % 1;
        m.position.x = 3.4 - ph * 1.6;
        m.position.y = 3.1 - ph * 1.0;
      });
    }
  });
  return null;
}

export function Topic10045Sim(props: SimProps) {
  const meal = Number(props.meal ?? 1);
  const acid = Number(props.acid ?? 1);
  const speed = 1;
  const bolus = useRef<THREE.Group>(null!);
  const acidDrops = useRef<THREE.Group>(null!);
  const enzymes = useRef<THREE.Group>(null!);
  const bile = useRef<THREE.Group>(null!);
  const stomach = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Gastric pH", acid > 1.2 ? "~1.5 (very acidic)" : acid < 0.5 ? "~4 (low acid)" : "~2 (normal)"],
          ["Secretions", "HCl • pepsin • lipase • bile"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* esophagus */}
        <mesh position={[-4.5, 5.0, 0]} castShadow>
          <cylinderGeometry args={[0.3, 0.3, 2.4, 12]} />
          <meshStandardMaterial color="#fda4af" roughness={0.5} />
        </mesh>
        <Label text="esophagus" position={[-5.6, 5.6, 0]} size={0.3} color="#fda4af" />

        {/* stomach: J-shaped sack */}
        <mesh ref={stomach} position={[-3.2, 2.6, 0]} castShadow scale={[1.3, 1, 0.9]}>
          <sphereGeometry args={[1.4, 24, 24]} />
          <meshStandardMaterial color="#fb7185" transparent opacity={0.75} roughness={0.4} />
        </mesh>
        {/* food bolus chunks churning inside */}
        <group ref={bolus}>
          {Array.from({ length: 7 }).map((_, i) => (
            <mesh key={i} position={[-3.2, 2.2, 0]} castShadow
              scale={[meal, meal, meal]}>
              <dodecahedronGeometry args={[0.28]} />
              <meshStandardMaterial color="#d97706" roughness={0.6} />
            </mesh>
          ))}
        </group>
        {/* HCl splashing from gastric glands */}
        <group ref={acidDrops}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[-3.2 + ((i * 1.3) % 3 - 1) * 0.5, 3.6, ((i * 0.7) % 2 - 0.5)]}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshBasicMaterial color="#a5f3fc" />
            </mesh>
          ))}
        </group>
        <Label text="stomach — HCl + pepsin churn" position={[-3.2, 4.6, 0]} size={0.38} color="#f8fafc" />

        {/* duodenum C-loop */}
        <mesh position={[0.2, 1.8, 0]} rotation={[0, 0, 0.2]} castShadow>
          <torusGeometry args={[1.5, 0.42, 12, 24, Math.PI * 1.2]} />
          <meshStandardMaterial color="#fda4af" roughness={0.5} />
        </mesh>
        <Label text="duodenum" position={[1.9, 1.0, 0]} size={0.32} color="#fda4af" />

        {/* pancreas: yellow leaf dripping enzymes */}
        <group position={[1.4, 3.3, -0.6]}>
          <mesh rotation={[0, 0, -0.4]} castShadow>
            <capsuleGeometry args={[0.4, 2.2, 6, 12]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.5} />
          </mesh>
          {/* islet + acinar hints */}
          {[-0.6, 0.2, 0.8].map((x, i) => (
            <mesh key={i} position={[x * 0.5, 0.1, 0.42]}>
              <sphereGeometry args={[0.12, 8, 8]} />
              <meshStandardMaterial color="#f59e0b" />
            </mesh>
          ))}
        </group>
        <group ref={enzymes}>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[1.4 + (i % 3 - 1) * 0.4, 3.3, -0.6]}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshBasicMaterial color="#fde68a" />
            </mesh>
          ))}
        </group>
        <Label text="pancreas — enzymes drip" position={[1.4, 4.6, -0.6]} size={0.34} color="#fde68a" />

        {/* liver + gallbladder squirting bile */}
        <mesh position={[4.6, 4.2, -0.8]} castShadow scale={[1.3, 0.8, 0.8]}>
          <sphereGeometry args={[1.1, 18, 18]} />
          <meshStandardMaterial color="#7c2d12" roughness={0.55} />
        </mesh>
        <mesh position={[3.4, 3.3, 0]} castShadow scale={[0.7, 1.1, 0.7]}>
          <sphereGeometry args={[0.42, 14, 14]} />
          <meshStandardMaterial color="#4d7c0f" roughness={0.4} />
        </mesh>
        <group ref={bile}>
          {Array.from({ length: 5 }).map((_, i) => (
            <mesh key={i} position={[3.4, 3.1, 0]}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshBasicMaterial color="#a3e635" />
            </mesh>
          ))}
        </group>
        <Label text="liver" position={[4.6, 5.5, -0.8]} size={0.32} color="#f8fafc" />
        <Label text="gallbladder — bile squirts" position={[3.4, 2.35, 0]} size={0.3} color="#bef264" />

        {/* salivary gland hint */}
        <group position={[-7.2, 3.4, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.55, 14, 14]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
          </mesh>
          <mesh position={[0.7, -0.3, 0]} rotation={[0, 0, -0.8]}>
            <cylinderGeometry args={[0.09, 0.09, 1.2, 8]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
          </mesh>
        </group>
        <Label text="salivary gland — amylase" position={[-7.2, 4.5, 0]} size={0.3} color="#f9a8d4" />

        <Animator bolus={bolus} acidDrops={acidDrops} enzymes={enzymes} bile={bile}
          stomach={stomach} elapsed={elapsed} meal={meal} acid={acid} speed={speed} />
      </SimCanvas>
    </div>
  );
}
