"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "phase", label: "Eruption phase", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.5, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Eruption and shedding: chronology, theories of eruption",
  blurb: "A permanent tooth rises through the gum while the baby tooth's root melts away — drag the phase to replay eruption.",
};

const GUM = "#e88ca0";
const ENAMEL = "#fef9c3";

function EruptionScene({ phase, speed, showLabels }: { phase: number; speed: number; showLabels: boolean }) {
  const tooth = useRef<THREE.Group>(null!);
  const gumFlap = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const eased = phase * phase * (3 - 2 * phase);

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (tooth.current) {
      // eruptive jiggle: tiny up-down as it pushes through
      tooth.current.position.y = THREE.MathUtils.lerp(-3.2, 0.4, eased) + Math.sin(elapsed.current * 6) * 0.03 * (phase > 0.05 && phase < 0.95 ? 1 : 0);
    }
    if (gumFlap.current) {
      // gum parts over the cusp tip
      gumFlap.current.rotation.x = -eased * 1.1;
    }
  });

  const rootLen = THREE.MathUtils.lerp(1.6, 0.25, eased); // root resorbs as it sheds/erupts

  return (
    <group>
      {/* jaw bone */}
      <mesh position={[0, -2.6, 0]} castShadow receiveShadow>
        <boxGeometry args={[6.5, 1.6, 3]} />
        <meshStandardMaterial color="#e7e5e4" roughness={0.7} />
      </mesh>
      {/* gum pad */}
      <mesh position={[0, -1.5, 0]} castShadow>
        <boxGeometry args={[6.5, 0.9, 3]} />
        <meshStandardMaterial color={GUM} roughness={0.6} />
      </mesh>
      {/* gum flap that parts */}
      <mesh ref={gumFlap} position={[0, -1.05, 0.9]} castShadow>
        <boxGeometry args={[1.6, 0.25, 1.4]} />
        <meshStandardMaterial color="#d4698a" roughness={0.6} />
      </mesh>

      {/* erupting tooth */}
      <group ref={tooth} position={[0, -3.2, 0]}>
        {/* crown with cusps */}
        <mesh position={[0, 1.4, 0]} castShadow>
          <boxGeometry args={[1.5, 1.1, 1.3]} />
          <meshStandardMaterial color={ENAMEL} roughness={0.25} />
        </mesh>
        {[[-0.38, -0.35], [0.38, -0.35], [-0.38, 0.35], [0.38, 0.35]].map(([x, z], i) => (
          <mesh key={i} position={[x, 2.2, z]} castShadow>
            <coneGeometry args={[0.3, 0.6, 4]} />
            <meshStandardMaterial color={ENAMEL} roughness={0.25} />
          </mesh>
        ))}
        {/* resorbing root */}
        <mesh position={[0, 0.2, 0]} castShadow>
          <coneGeometry args={[0.42, rootLen, 12]} />
          <meshStandardMaterial color="#fde68a" roughness={0.4} />
        </mesh>
        {/* eruption follicle glow */}
        <mesh position={[0, 0.6, 0]}>
          <sphereGeometry args={[1.35, 20, 14]} />
          <meshBasicMaterial color="#fbbf24" transparent opacity={0.12} />
        </mesh>
      </group>

      {/* eruptive force arrows */}
      {phase > 0.05 && phase < 0.95 && (
        <>
          {[-0.9, 0.9].map((x, i) => (
            <group key={i} position={[x, -2.2, 0]}>
              <mesh>
                <cylinderGeometry args={[0.06, 0.06, 1, 8]} />
                <meshBasicMaterial color="#4ade80" />
              </mesh>
              <mesh position={[0, 0.65, 0]}>
                <coneGeometry args={[0.16, 0.4, 8]} />
                <meshBasicMaterial color="#4ade80" />
              </mesh>
            </group>
          ))}
        </>
      )}

      {showLabels && (
        <>
          <Text position={[-4.6, 0.4, 0]} fontSize={0.4} color="#fef3c7">Crown pushes through gum</Text>
          <Text position={[4.6, -0.6, 0]} fontSize={0.4} color="#fde68a">Root resorbs → tooth sheds</Text>
          <Text position={[0, 3.6, 0]} fontSize={0.44} color="#4ade80" maxWidth={9}>
            {phase < 0.25 ? "Pre-eruptive: root forming" : phase < 0.6 ? "Eruptive: piercing the gum" : "Post-eruptive: in occlusion"}
          </Text>
        </>
      )}
    </group>
  );
}

export function Topic10373Sim(props: SimProps) {
  const phase = Number(props.phase ?? 0.5);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Phase", phase < 0.25 ? "pre-eruptive" : phase < 0.6 ? "eruptive" : "functional"],
          ["Root", `${(1.6 * (1 - phase) + 0.25).toFixed(1)} units (resorbing)`],
          ["First tooth", "~6 months (lower central)"],
        ]}
      />
      <SimCanvas cameraPosition={[6.5, 3.5, 9]} target={[0, -0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.5, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <EruptionScene phase={phase} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
