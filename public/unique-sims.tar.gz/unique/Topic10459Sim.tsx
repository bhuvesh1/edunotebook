"use client";
// Growth of the Craniofacial Complex — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "age", label: "Age", kind: "slider", min: 6, max: 16, step: 1, default: 10, unit: " yrs" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Growth of the Craniofacial Complex",
  blurb: "Drag the age slider and watch the skull grow — the jaw grows down and forward while the cranium expands.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const s = 0.68 + (p.age - 6) * 0.045;
    const skull: any = g("skull");
    if (skull) skull.scale.setScalar(s);
    const jaw: any = g("jawbone");
    if (jaw) {
      const grow = (p.age - 6) / 10;
      jaw.position.set(-0.35 - grow * 0.25, 1.35 - grow * 0.12, 0);
    }
    group.current.rotation.y = Math.sin(t * 0.3) * 0.35;
  });
  return null;
}

export function Topic10459Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const age = Number(props.age ?? 10);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, age };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Age", `${age} years`],
          ["Growth", `${Math.round(70 + (age - 6) * 3)}% of adult size`],
          ["Hot zones", "Maxilla, mandible, vault"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <group name="skull">
            <mesh position={[0, 3.6, 0]}>
              <sphereGeometry args={[1.35, 24, 24]} />
              <meshStandardMaterial color="#e8e0cf" roughness={0.6} />
            </mesh>
            <mesh position={[-0.55, 2.5, 0]}>
              <boxGeometry args={[1.5, 0.7, 1.1]} />
              <meshStandardMaterial color="#ded3ba" roughness={0.6} />
            </mesh>
            <mesh position={[-0.15, 2.15, 0.62]}>
              <sphereGeometry args={[0.14, 12, 12]} />
              <meshStandardMaterial color="#1e293b" roughness={0.3} />
            </mesh>
            <group name="jawbone" position={[-0.35, 1.35, 0]}>
              <mesh>
                <boxGeometry args={[1.9, 0.45, 1]} />
                <meshStandardMaterial color="#d3c7ab" roughness={0.6} />
              </mesh>
              <mesh position={[-0.85, 0.45, 0]}>
                <boxGeometry args={[0.35, 0.8, 0.9]} />
                <meshStandardMaterial color="#d3c7ab" roughness={0.6} />
              </mesh>
            </group>
          </group>
          <Arrow from={[-0.4, 2.9, 0]} to={[-0.9, 2.1, 0]} color="#f472b6" />
          <Arrow from={[0.3, 1.7, 0]} to={[-0.5, 1.1, 0]} color="#38bdf8" />
          <Label text="Cranial vault" position={[1.9, 4.3, 0]} size={0.42} />
          <Label text="Maxilla grows down-forward" position={[-2.6, 2.6, 0]} size={0.42} color="#f472b6" />
          <Label text="Mandible grows most" position={[-2.4, 0.9, 0]} size={0.42} color="#38bdf8" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
