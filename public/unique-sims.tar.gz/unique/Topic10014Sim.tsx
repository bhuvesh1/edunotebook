"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Signal speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Neuroanatomy: spinal tracts, limbic system, autonomic nervous system",
  blurb: "Two nervous systems at once: sensory and motor tracts racing through the cord, and the heart's sympathetic/parasympathetic tug-of-war.",
};

function CordAndANS({ speed }: { speed: number }) {
  const asc = useRef<(THREE.Mesh | null)[]>([]);
  const desc = useRef<(THREE.Mesh | null)[]>([]);
  const heart = useRef<THREE.Mesh>(null!);
  const sym = useRef<THREE.Group>(null!);
  const para = useRef<THREE.Group>(null!);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d * speed;
    asc.current.forEach((m, i) => {
      if (!m) return;
      const k = (t.current * 0.8 + i * 0.2) % 1;
      m.position.y = 0.6 + k * 3.4; // sensory: up to the brain
    });
    desc.current.forEach((m, i) => {
      if (!m) return;
      const k = (t.current * 0.8 + i * 0.25) % 1;
      m.position.y = 4.0 - k * 3.4; // motor: down from the brain
    });
    if (heart.current) heart.current.scale.setScalar(1 + Math.max(0, Math.sin(t.current * 4)) * 0.1);
    if (sym.current) sym.current.children.forEach((c, i) => { c.position.y = 3.4 + Math.sin(t.current * 3 + i) * 0.15; });
    if (para.current) para.current.children.forEach((c, i) => { c.position.y = 3.4 + Math.sin(t.current * 3 + i + Math.PI) * 0.15; });
  });
  return (
    <group>
      {/* === spinal cord cross-section column === */}
      <mesh position={[-2.6, 2.3, 0]} castShadow>
        <cylinderGeometry args={[0.9, 0.9, 4.2, 22]} />
        <meshStandardMaterial color="#fef3c7" roughness={0.55} />
      </mesh>
      {/* central canal */}
      <mesh position={[-2.6, 2.3, 0]}>
        <cylinderGeometry args={[0.14, 0.14, 4.25, 10]} />
        <meshStandardMaterial color="#f59e0b" emissive="#b45309" emissiveIntensity={0.6} />
      </mesh>
      {/* butterfly grey matter */}
      <mesh position={[-2.6, 4.42, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.45, 4]} />
        <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
      </mesh>
      {/* ascending (sensory, blue) tract dots */}
      {Array.from({ length: 5 }).map((_, i) => (
        <mesh key={"a" + i} ref={(m) => { asc.current[i] = m; }} position={[-3.2 + (i % 2) * 0.35, 0.6, 0.55]}>
          <sphereGeometry args={[0.11, 10, 10]} />
          <meshStandardMaterial color="#60a5fa" emissive="#2563eb" emissiveIntensity={1.8} />
        </mesh>
      ))}
      {/* descending (motor, red) tract dots */}
      {Array.from({ length: 5 }).map((_, i) => (
        <mesh key={"d" + i} ref={(m) => { desc.current[i] = m; }} position={[-2.1 - (i % 2) * 0.35, 4.0, 0.55]}>
          <sphereGeometry args={[0.11, 10, 10]} />
          <meshStandardMaterial color="#f87171" emissive="#dc2626" emissiveIntensity={1.8} />
        </mesh>
      ))}
      {/* === limbic/ANS heart panel === */}
      <mesh ref={heart} position={[2.8, 2.2, 0]} castShadow>
        <sphereGeometry args={[0.7, 22, 22]} />
        <meshStandardMaterial color="#dc2626" emissive="#991b1b" emissiveIntensity={0.55} roughness={0.35} />
      </mesh>
      {/* sympathetic chain (red, speeds up) */}
      <group ref={sym} position={[1.4, 0, 0]}>
        {[0, 1, 2].map((i) => (
          <mesh key={i} position={[0, 3.4, -0.5 + i * 0.5]}>
            <sphereGeometry args={[0.16, 12, 12]} />
            <meshStandardMaterial color="#ef4444" emissive="#b91c1c" emissiveIntensity={1.4} />
          </mesh>
        ))}
      </group>
      {/* parasympathetic vagus (blue, slows down) */}
      <group ref={para} position={[4.2, 0, 0]}>
        {[0, 1, 2].map((i) => (
          <mesh key={i} position={[0, 3.4, -0.5 + i * 0.5]}>
            <sphereGeometry args={[0.16, 12, 12]} />
            <meshStandardMaterial color="#60a5fa" emissive="#2563eb" emissiveIntensity={1.4} />
          </mesh>
        ))}
      </group>
      <Arrow from={[1.4, 2.6, 0]} to={[2.2, 2.6, 0]} color="#ef4444" radius={0.08} />
      <Arrow from={[4.2, 2.6, 0]} to={[3.4, 2.6, 0]} color="#60a5fa" radius={0.08} />
    </group>
  );
}

export function Topic10014Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Sensory tracts", "↑ blue"], ["Motor tracts", "↓ red"], ["ANS", "sympathetic ⇄ vagus"]]} />
      <SimCanvas cameraPosition={[0, 3.5, 13]} target={[0.4, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <CordAndANS speed={speed} />
        {showLabels && (
          <>
            <Label text="Spinal cord" position={[-2.6, 5.2, 0]} color="#fef3c7" size={0.5} />
            <Label text="Sympathetic (fight)" position={[0.4, 4.4, 0]} color="#fca5a5" size={0.45} />
            <Label text="Parasympathetic (rest)" position={[5.4, 4.4, 0]} color="#93c5fd" size={0.45} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
