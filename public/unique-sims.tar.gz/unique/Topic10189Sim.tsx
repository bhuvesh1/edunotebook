"use client";
// Nose: rhinitis — allergic, vasomotor; nasal polyps.
// A nose in cross-section: pick allergic rhinitis for a sneeze burst,
// or watch grape-like polyps swell and shrink the airway.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "allergic", options: ["allergic", "vasomotor", "polyps"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Rhinitis & Nasal Polyps",
  blurb: "Sneeze through allergic rhinitis, then watch grape-like polyps grow and block the nasal airway.",
};

const COND_TXT: Record<string, string> = {
  allergic: "Allergic: sneezing, itchy, watery",
  vasomotor: "Vasomotor: runny with weather change",
  polyps: "Polyps: blocked nose, lost smell",
};
const N_SNEEZE = 14;

function Animator({ sneeze, polyps, elapsed, speed, condition }: { sneeze: React.RefObject<THREE.Group>; polyps: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number; condition: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (sneeze.current) {
      sneeze.current.visible = condition === "allergic";
      sneeze.current.children.forEach((p, i) => {
        const ph = (elapsed.current * 1.4 + i / N_SNEEZE) % 1;
        p.position.set(-1.5 - ph * 2.6, 2.6 + Math.sin(ph * 6 + i) * 0.5, (i % 3 - 1) * 0.4);
        const s = 0.4 + ph * 0.9;
        p.scale.set(s, s, s);
      });
    }
    if (polyps.current) {
      polyps.current.visible = condition === "polyps";
      polyps.current.children.forEach((p, i) => {
        const s = 1 + Math.sin(elapsed.current * 2 + i * 1.4) * 0.12;
        p.scale.set(s, s * 1.2, s);
      });
    }
  });
  return null;
}

export function Topic10189Sim(props: SimProps) {
  const condition = String(props.condition ?? "allergic");
  const speed = Number(props.speed ?? 1);
  const sneeze = useRef<THREE.Group>(null!);
  const polyps = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const sneezeMeshes = useMemo(
    () =>
      Array.from({ length: N_SNEEZE }, (_, i) => (
        <mesh key={i} position={[-1.5, 2.6, 0]}>
          <sphereGeometry args={[0.13, 8, 8]} />
          <meshStandardMaterial color="#fef08a" emissive="#facc15" emissiveIntensity={0.8} transparent opacity={0.9} />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", condition], ["Signs", COND_TXT[condition] ?? ""]]} />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* nose: bridge + tip + nostrils */}
        <group position={[1.5, 0, 0]}>
          <mesh position={[0, 3.4, 0]} rotation={[0, 0, 0.12]} castShadow>
            <cylinderGeometry args={[0.5, 0.85, 2.6, 12]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.65} />
          </mesh>
          <mesh position={[-0.15, 2, 0]} castShadow>
            <sphereGeometry args={[0.75, 16, 16]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.65} />
          </mesh>
          {[-0.45, 0.15].map((x) => (
            <mesh key={x} position={[x, 1.55, 0.35]}>
              <sphereGeometry args={[0.2, 10, 10]} />
              <meshStandardMaterial color="#7c2d12" roughness={0.7} />
            </mesh>
          ))}
          {/* nasal passage */}
          <mesh position={[-0.15, 2.9, 0]}>
            <cylinderGeometry args={[0.42, 0.42, 2.2, 12, 1, true]} />
            <meshStandardMaterial color={condition === "polyps" ? "#f87171" : "#f5c9a0"} transparent opacity={0.5} roughness={0.6} side={THREE.DoubleSide} emissive={condition === "polyps" ? "#ef4444" : "#000000"} emissiveIntensity={condition === "polyps" ? 0.3 : 0} />
          </mesh>
          <group ref={polyps} position={[-0.15, 2.9, 0]}>
            {[0.5, 0, -0.5].map((y, i) => (
              <mesh key={y} position={[(i % 2 ? 0.2 : -0.2), y, 0]} castShadow>
                <sphereGeometry args={[0.3, 12, 12]} />
                <meshStandardMaterial color="#f9a8d4" roughness={0.55} emissive="#ec4899" emissiveIntensity={0.25} />
              </mesh>
            ))}
          </group>
          <Label text="NOSE" position={[0, 5.2, 0]} size={0.6} color="#fcd9b8" />
          {condition === "polyps" && (
            <Label text="🍇 POLYPS BLOCK AIRWAY" position={[-0.15, 1, 0]} size={0.55} color="#f9a8d4" />
          )}
        </group>
        {/* sneeze burst */}
        <group ref={sneeze}>{sneezeMeshes}</group>
        {condition === "allergic" && (
          <Label text="ACHOO! 🤧" position={[-3.4, 4, 0]} size={0.7} color="#fef08a" />
        )}
        {/* pollen grains */}
        {(condition === "allergic" || condition === "vasomotor") &&
          Array.from({ length: 8 }, (_, i) => (
            <mesh key={i} position={[-4 + Math.sin(i * 2.7) * 1.6, 3.4 + Math.cos(i * 3.3) * 1.2, -0.5]}>
              <icosahedronGeometry args={[0.14, 0]} />
              <meshStandardMaterial color="#fde68a" emissive="#facc15" emissiveIntensity={0.6} flatShading />
            </mesh>
          ))}
        <Animator sneeze={sneeze} polyps={polyps} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
