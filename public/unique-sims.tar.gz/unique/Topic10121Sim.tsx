// Insulin & thyroid drugs: blood sugar runs high on the glucose meter — an
// insulin injection drives it down into the green zone; the thyroid butterfly
// sets the body's metabolic pace.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "insulin", label: "Insulin dose", kind: "slider", min: 0, max: 40, step: 2, default: 18, unit: "U" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Insulin & thyroid drugs",
  blurb: "Insulin drives high blood sugar down into the green zone; the thyroid butterfly sets metabolic pace.",
};

const N_INS = 10;

function Animator({ bar, ins, syringe, elapsed, insulin, setTick }: {
  bar: React.RefObject<THREE.Mesh>;
  ins: React.RefObject<(THREE.Mesh | null)[]>;
  syringe: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  insulin: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    // glucose cycles high, insulin dose pulls it down
    const base = 0.55 + Math.sin(t * 0.5) * 0.25;
    const drop = (insulin / 40) * 0.5;
    const level = THREE.MathUtils.clamp(base - drop, 0.08, 1);
    if (bar.current) {
      bar.current.scale.y = Math.max(0.02, level);
      bar.current.position.y = 0.4 + level * 1.8;
      const m = bar.current.material as THREE.MeshStandardMaterial;
      const mg = 320 - level * 240; // map to mg/dL roughly
      m.color.set(mg > 180 ? "#ef4444" : mg > 110 ? "#f59e0b" : "#22c55e");
      m.emissive.set(m.color.getHex());
    }
    ins.current.forEach((d, i) => {
      if (!d) return;
      const f = (t * 0.6 + i / N_INS) % 1;
      d.position.set(3.4 - f * 4.6, 2.6 - f * 1.2, 0.6);
      d.visible = insulin > 2;
      ((d as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = Math.max(0, 1 - f * 1.2);
    });
    if (syringe.current) syringe.current.position.y = Math.sin(t * 1.6) * 0.12;
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(level * 100)); }
  });
  return null;
}

export function Topic10121Sim(props: SimProps) {
  const insulin = Number(props.insulin ?? 18);
  const showLabels = String(props.detail ?? "on") === "on";
  const bar = useRef<THREE.Mesh>(null!);
  const ins = useRef<(THREE.Mesh | null)[]>([]);
  const syringe = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const mgdl = Math.round(320 - (tick / 100) * 240);
  const status = mgdl > 180 ? "hyperglycemic" : mgdl > 110 ? "elevated" : "normal";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Blood glucose", `${mgdl} mg/dL`],
          ["Status", status],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* glucose meter column */}
        <group position={[-2.6, 0, 0]}>
          <mesh position={[0, 2.2, 0]}>
            <boxGeometry args={[1.4, 4.4, 1]} />
            <meshStandardMaterial color="#1e293b" roughness={0.5} transparent opacity={0.6} />
          </mesh>
          <mesh ref={bar} position={[0, 2.2, 0]}>
            <boxGeometry args={[1.0, 3.6, 0.7]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.5} />
          </mesh>
          {/* green target zone marker */}
          <mesh position={[0.85, 1.3, 0]}>
            <boxGeometry args={[0.18, 0.9, 0.18]} />
            <meshStandardMaterial color="#22c55e" emissive="#16a34a" emissiveIntensity={0.8} />
          </mesh>
        </group>
        {showLabels && <Label text="blood glucose" position={[-2.6, 5, 0]} color="#fca5a5" />}
        {showLabels && <Label text="target zone" position={[-1.2, 1.3, 0]} size={0.4} color="#86efac" />}

        {/* insulin syringe */}
        <group ref={syringe} position={[3.4, 2.6, 0.6]}>
          <mesh rotation={[0, 0, 1.1]} castShadow>
            <cylinderGeometry args={[0.16, 0.16, 1.4, 12]} />
            <meshStandardMaterial color="#e0f2fe" transparent opacity={0.85} />
          </mesh>
          <mesh position={[-0.62, -0.75, 0]} rotation={[0, 0, 1.1]}>
            <cylinderGeometry args={[0.035, 0.035, 0.7, 8]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.6} roughness={0.3} />
          </mesh>
          <mesh position={[0.35, 0.42, 0]} rotation={[0, 0, 1.1]}>
            <cylinderGeometry args={[0.17, 0.17, 0.5, 12]} />
            <meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={0.5} />
          </mesh>
        </group>
        {showLabels && <Label text={`insulin — ${insulin} U`} position={[3.4, 4.2, 0.6]} color="#7dd3fc" />}

        {/* insulin molecules travelling to the meter */}
        {Array.from({ length: N_INS }).map((_, i) => (
          <mesh key={i} ref={(m) => { ins.current[i] = m; }}>
            <sphereGeometry args={[0.13, 10, 8]} />
            <meshStandardMaterial color="#38bdf8" emissive="#0369a1" emissiveIntensity={1} transparent />
          </mesh>
        ))}

        {/* thyroid butterfly gland */}
        <group position={[-4.8, 2.4, -1.2]}>
          {[-0.45, 0.45].map((x, i) => (
            <mesh key={i} position={[x, 0, 0]} scale={[0.7, 1, 0.4]} castShadow>
              <sphereGeometry args={[0.55, 16, 12]} />
              <meshStandardMaterial color="#c08497" roughness={0.55} />
            </mesh>
          ))}
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.14, 0.14, 0.9, 10]} />
            <meshStandardMaterial color="#a86a7e" roughness={0.55} />
          </mesh>
        </group>
        {showLabels && <Label text="thyroid gland" position={[-4.8, 3.8, -1.2]} size={0.45} color="#f9a8d4" />}

        <Animator bar={bar} ins={ins} syringe={syringe} elapsed={elapsed} insulin={insulin} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
