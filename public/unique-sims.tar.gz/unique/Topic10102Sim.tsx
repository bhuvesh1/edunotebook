"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "day", label: "Healing day", kind: "slider", min: 0, max: 30, step: 1, default: 10, unit: " days" },
];

export const UNIQUE_META = {
  title: "Bone Fracture Healing",
  blurb: "Drag the timeline: a broken bone forms a callus bridge that remodels back into solid bone.",
};

function Animator({ root, callus, elapsed, cal }: { root: RefObject<THREE.Group>; callus: RefObject<THREE.Group>; elapsed: RefObject<number>; cal: number }) {
  useFrame((_, delta) => {
    elapsed.current += 0.016;
    const t = elapsed.current;
    if (callus.current) {
      callus.current.scale.setScalar(Math.max(0.001, cal) * (1 + 0.06 * Math.sin(t * 2.2)));
      callus.current.rotation.y = t * 0.4;
    }
  });
  return null;
}

export function Topic10102Sim(props: SimProps) {
  const day = Number(props.day ?? 10);
  const gap = Math.max(0, 1.1 * (1 - day / 26));
  const cal = day < 3 ? 0 : day < 14 ? (day - 3) / 11 : Math.max(0.25, 1 - (day - 14) / 16 * 0.75);
  const stage = day < 3 ? "hematoma" : day < 14 ? "soft \u2192 hard callus" : "remodeling";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const callus = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Day", `${day}`],
          ["Stage", stage],
          ["Gap", `${gap.toFixed(2)} units`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 3.35 + gap / 2, 0]} castShadow>
            <cylinderGeometry args={[0.5, 0.5, 1.7, 16]} /><meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <mesh position={[0, 4.35 + gap / 2, 0]} castShadow>
            <sphereGeometry args={[0.85, 18, 18]} /><meshStandardMaterial color="#f1f5f9" roughness={0.5} />
          </mesh>
          <mesh position={[0, 1.05 - gap / 2, 0]} castShadow>
            <cylinderGeometry args={[0.5, 0.5, 1.7, 16]} /><meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <mesh position={[0, 0.05 - gap / 2, 0]} castShadow>
            <sphereGeometry args={[0.85, 18, 18]} /><meshStandardMaterial color="#f1f5f9" roughness={0.5} />
          </mesh>
          {day < 3 && (
            <mesh position={[0, 2.2, 0]}><sphereGeometry args={[0.65, 14, 14]} /><meshStandardMaterial color="#7f1d1d" roughness={0.8} /></mesh>
          )}
          <group ref={callus} position={[0, 2.2, 0]}>
            {Array.from({ length: 10 }).map((_, i) => {
              const a = (i / 10) * Math.PI * 2;
              return (
                <mesh key={i} position={[Math.cos(a) * 0.75, (i % 3 - 1) * 0.4, Math.sin(a) * 0.75]}>
                  <sphereGeometry args={[0.3, 12, 12]} /><meshStandardMaterial color="#fde68a" roughness={0.7} />
                </mesh>
              );
            })}
          </group>
          <Label text="fracture line" position={[1.9, 2.2, 0]} size={0.4} color="#f87171" />
          <Label text="callus" position={[-1.9, 2.2, 0]} size={0.4} color="#fde68a" />
          <Label text={`day ${day}: ${stage}`} position={[0, 5.6, 0]} size={0.48} color="#f8fafc" />
        </group>
        <Animator root={root} callus={callus} elapsed={elapsed} cal={cal} />
      </SimCanvas>
    </div>
  );
}
