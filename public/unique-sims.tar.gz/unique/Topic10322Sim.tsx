// Fungal infections: dermatophytosis, candidiasis, pityriasis versicolor.
// Fungi love warm skin: ringworm's advancing red ring, thrush's creamy
// patches, and the scaly light patches of versicolor — with branching hyphae
// underneath.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "infection", label: "Infection", kind: "select", min: 0, max: 0, step: 1, default: "ringworm", options: ["ringworm", "candidiasis", "versicolor"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Fungal Skin: Ringworm & Thrush",
  blurb: "Ringworm's red ring marches outward, thrush coats in creamy white, and branching hyphae feed underneath.",
};

function Animator({
  group, ring, hyphae, elapsed, speed, infection,
}: {
  group: React.RefObject<THREE.Group>;
  ring: React.RefObject<THREE.Mesh>;
  hyphae: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  infection: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.15;
    // ringworm: the ring advances outward and the center clears
    if (ring.current && infection === "ringworm") {
      const r = 0.9 + (0.5 + 0.5 * Math.sin(t * 0.7)) * 0.9;
      ring.current.scale.set(r, 1, r * 0.85);
      (ring.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.3 + 0.3 * Math.sin(t * 3);
    }
    // hyphae writhe as they grow
    if (hyphae.current) {
      hyphae.current.children.forEach((h, i) => {
        h.rotation.z = Math.sin(t * 1.5 + i * 1.2) * 0.15;
      });
    }
  });
  return null;
}

export function Topic10322Sim(props: SimProps) {
  const infection = String(props.infection ?? "ringworm");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const ring = useRef<THREE.Mesh>(null!);
  const hyphae = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    ringworm: "Ringworm (dermatophytosis)", candidiasis: "Candidiasis (thrush)", versicolor: "Pityriasis versicolor",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Infection", names[infection] ?? infection], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10]} target={[0, 1.7, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* skin patch */}
          <mesh position={[0, 1.0, 0]} castShadow receiveShadow>
            <boxGeometry args={[7, 1.4, 4]} />
            <meshStandardMaterial color="#f5c396" roughness={0.7} />
          </mesh>

          {infection === "ringworm" && (
            <>
              {/* advancing red ring with clear center */}
              <mesh ref={ring} position={[0, 1.78, 0]} rotation={[-Math.PI / 2, 0, 0]} castShadow>
                <ringGeometry args={[0.75, 1.05, 36]} />
                <meshStandardMaterial color="#dc2626" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.5} side={THREE.DoubleSide} />
              </mesh>
              {/* scaly edge bumps */}
              {Array.from({ length: 10 }).map((_, i) => {
                const a = (i / 10) * Math.PI * 2;
                return (
                  <mesh key={i} position={[Math.cos(a) * 1.35, 1.85, Math.sin(a) * 1.15]} castShadow>
                    <sphereGeometry args={[0.1, 8, 6]} />
                    <meshStandardMaterial color="#fbbf24" roughness={0.8} />
                  </mesh>
                );
              })}
              <Label text="Ring advances, center clears" position={[0, 0.1, 0]} size={0.55} color="#fca5a5" />
            </>
          )}

          {infection === "candidiasis" && (
            <>
              {/* creamy white patches in a moist fold */}
              {[[-1.2, 0.2], [0.1, -0.3], [1.3, 0.3]].map(([x, z], i) => (
                <mesh key={i} position={[x, 1.8, z]} scale={[1, 0.3, 0.85]} castShadow>
                  <sphereGeometry args={[0.55, 14, 10]} />
                  <meshStandardMaterial color="#fefce8" roughness={0.9} emissive="#a16207" emissiveIntensity={0.2} flatShading />
                </mesh>
              ))}
              <Label text="Creamy white thrush patches" position={[0, 0.1, 0]} size={0.55} color="#fefce8" />
            </>
          )}

          {infection === "versicolor" && (
            <>
              {/* light scaly patches on tanned skin */}
              <mesh position={[0, 1.0, 0]}>
                <boxGeometry args={[7, 1.42, 4]} />
                <meshStandardMaterial color="#c2703e" roughness={0.7} />
              </mesh>
              {[[-1.5, 0.2], [0.2, -0.5], [1.6, 0.4]].map(([x, z], i) => (
                <mesh key={i} position={[x, 1.78, z]} scale={[1, 0.25, 0.8]} castShadow>
                  <sphereGeometry args={[0.5, 14, 10]} />
                  <meshStandardMaterial color="#fde68a" roughness={0.9} transparent opacity={0.85} flatShading />
                </mesh>
              ))}
              <Label text="Pale scaly patches on tan" position={[0, 0.1, 0]} size={0.55} color="#fde68a" />
            </>
          )}

          {/* branching hyphae under the surface */}
          <group ref={hyphae} position={[0, 1.45, 0]}>
            {[-1.5, -0.5, 0.5, 1.5].map((x, i) => (
              <group key={i} position={[x, 0, (i % 2) * 0.8 - 0.4]}>
                <mesh rotation={[0, 0, 0.4]} castShadow>
                  <cylinderGeometry args={[0.035, 0.035, 1.1, 6]} />
                  <meshStandardMaterial color="#a3e635" roughness={0.5} emissive="#3f6212" emissiveIntensity={0.6} />
                </mesh>
                <mesh position={[0.3, 0.35, 0]} rotation={[0, 0, -0.7]} castShadow>
                  <cylinderGeometry args={[0.03, 0.03, 0.6, 6]} />
                  <meshStandardMaterial color="#a3e635" roughness={0.5} emissive="#3f6212" emissiveIntensity={0.6} />
                </mesh>
              </group>
            ))}
          </group>
          <Label text="🍄 Branching hyphae feed below" position={[2.9, 1.45, 0]} size={0.5} color="#bef264" />
        </group>
        <Animator group={group} ring={ring} hyphae={hyphae} elapsed={elapsed} speed={speed} infection={infection} />
      </SimCanvas>
    </div>
  );
}
