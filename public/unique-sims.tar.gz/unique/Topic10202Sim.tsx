// Retinal diseases — diabetic retinopathy (bleeding dots + leaky vessels),
// AMD (yellow drusen spots at the macula), retinal detachment (the retina
// sheet peels off and ripples). Severity slider drives all three.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "severity", label: "Disease severity", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "disease", label: "Show", kind: "select", min: 0, max: 0, step: 1, default: "all", options: ["all", "diabetic retinopathy", "AMD", "detachment"] },
];

export const UNIQUE_META = {
  title: "Retinal Diseases",
  blurb: "A bird's-eye view of the retina: diabetic bleeds, AMD drusen, and a peeling retinal detachment — driven by one severity slider.",
};

function Animator({ flap, bleeds, elapsed, severity }: {
  flap: React.RefObject<THREE.Group>;
  bleeds: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  severity: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (flap.current) {
      // detached retina ripples in the fluid
      flap.current.children.forEach((c, i) => {
        const row = Math.floor(i / 14);
        c.position.z = 0.12 + (severity / 100) * 0.9 * row + 0.08 * Math.sin(t * 3 + row * 1.2 + i * 0.4);
      });
    }
    if (bleeds.current) {
      bleeds.current.children.forEach((c, i) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = 0.3 + 0.35 * Math.sin(t * 2.5 + i * 1.7);
      });
    }
  });
  return null;
}

export function Topic10202Sim(props: SimProps) {
  const severity = Number(props.severity ?? 60);
  const disease = String(props.disease ?? "all");
  const flap = useRef<THREE.Group>(null!);
  const bleeds = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const showDR = disease === "all" || disease === "diabetic retinopathy";
  const showAMD = disease === "all" || disease === "AMD";
  const showDet = disease === "all" || disease === "detachment";

  const bleedSpots = useMemo(() => {
    const n = Math.round(3 + (severity / 100) * 22);
    return Array.from({ length: n }).map((_, i) => {
      const a = (i * 2.4) % (Math.PI * 2);
      const r = 1.2 + ((i * 1.7) % 2.6);
      return { x: Math.cos(a) * r, z: Math.sin(a) * r, s: 0.08 + ((i * 0.37) % 0.16) };
    });
  }, [severity]);

  const drusen = useMemo(() => {
    const n = Math.round(2 + (severity / 100) * 14);
    return Array.from({ length: n }).map((_, i) => {
      const a = (i * 2.9 + 1) % (Math.PI * 2);
      const r = 0.25 + ((i * 0.9) % 0.85);
      return { x: Math.cos(a) * r, z: Math.sin(a) * r, s: 0.06 + ((i * 0.23) % 0.09) };
    });
  }, [severity]);

  const detRows = 5, detCols = 14;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Diabetic bleeds", showDR ? `${bleedSpots.length} spots` : "hidden"], ["Drusen (AMD)", showAMD ? `${drusen.length}` : "hidden"], ["Detachment", showDet ? `${severity}% lifted` : "hidden"]]} />
      <SimCanvas cameraPosition={[0, 9, 5.5]} target={[0, 0.3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* retina bed */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
          <circleGeometry args={[4.6, 48]} />
          <meshStandardMaterial color="#c2410c" roughness={0.7} emissive="#7c2d12" emissiveIntensity={0.3} />
        </mesh>
        {/* macula + optic disc */}
        <mesh position={[0, 0.06, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[0.75, 28]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.5} emissive="#92400e" emissiveIntensity={0.35} />
        </mesh>
        <mesh position={[2.6, 0.06, 0.9]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[0.55, 28]} />
          <meshStandardMaterial color="#fde68a" roughness={0.5} />
        </mesh>
        {/* vessel arcades */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[0.4, 0.05, s * 1.4]} rotation={[-Math.PI / 2, 0, s * 0.5]}>
            <torusGeometry args={[1.9, 0.1, 8, 40, Math.PI * 0.7]} />
            <meshStandardMaterial color="#dc2626" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.4} />
          </mesh>
        ))}

        {/* diabetic retinopathy: bleeding dots */}
        {showDR && (
          <group ref={bleeds}>
            {bleedSpots.map((b, i) => (
              <mesh key={i} position={[b.x, 0.1, b.z]}>
                <sphereGeometry args={[b.s, 10, 8]} />
                <meshStandardMaterial color="#991b1b" roughness={0.4} emissive="#dc2626" emissiveIntensity={0.4} />
              </mesh>
            ))}
          </group>
        )}
        {/* AMD: yellow drusen at the macula */}
        {showAMD &&
          drusen.map((d, i) => (
            <mesh key={i} position={[d.x, 0.09, d.z]}>
              <sphereGeometry args={[d.s, 10, 8]} />
              <meshStandardMaterial color="#facc15" roughness={0.6} emissive="#a16207" emissiveIntensity={0.4} />
            </mesh>
          ))}
        {/* retinal detachment: the sheet lifts and ripples from one edge */}
        {showDet && (
          <group ref={flap}>
            {Array.from({ length: detRows }).map((_, r) =>
              Array.from({ length: detCols }).map((_, c) => (
                <mesh key={`${r}-${c}`} position={[-4.2 + r * 0.75, 0.12, -3.25 + c * 0.5]}>
                  <boxGeometry args={[0.72, 0.06, 0.47]} />
                  <meshStandardMaterial color="#fb923c" roughness={0.6} />
                </mesh>
              ))
            )}
          </group>
        )}

        <Label text="Macula (sharp vision)" position={[0, 0.4, 2.1]} size={0.45} color="#fde047" />
        <Label text="Optic disc (blind spot)" position={[2.6, 0.4, 2.6]} size={0.45} color="#fde68a" />
        {showDR && <Label text="Diabetic bleeds" position={[-3.4, 0.5, -2.6]} size={0.45} color="#fca5a5" />}
        {showAMD && <Label text="Drusen (AMD)" position={[0, 0.5, -2.4]} size={0.45} color="#fde047" />}
        {showDet && <Label text="Detached retina — emergency!" position={[-3.2, 1.6, 1.8]} size={0.45} color="#fca5a5" />}
        <Animator flap={flap} bleeds={bleeds} elapsed={elapsed} severity={severity} />
      </SimCanvas>
    </div>
  );
}
