// Conjunctival disorders — conjunctivitis (the whole white of the eye turns
// pink with injected vessels), pterygium (a wing-shaped growth creeping from
// the corner onto the cornea), trachoma (bumpy follicles). Condition select +
// redness slider.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "redness", label: "Redness / growth", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "conjunctivitis", options: ["conjunctivitis", "pterygium", "trachoma"] },
];

export const UNIQUE_META = {
  title: "Conjunctival Disorders",
  blurb: "Pink eye's injected vessels, a pterygium wing creeping onto the cornea, and trachoma's bumps — one redness slider drives them all.",
};

function Animator({ vessels, elapsed, redness }: { vessels: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; redness: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (vessels.current) {
      vessels.current.children.forEach((c, i) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = (redness / 100) * (0.5 + 0.3 * Math.sin(t * 2.2 + i * 1.4));
        c.visible = i < Math.round((redness / 100) * vessels.current!.children.length);
      });
    }
  });
  return null;
}

export function Topic10206Sim(props: SimProps) {
  const redness = Number(props.redness ?? 60);
  const condition = String(props.condition ?? "conjunctivitis");
  const vessels = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const vesselList = useMemo(() => {
    return Array.from({ length: 26 }).map((_, i) => {
      const a = (i * 2.7) % (Math.PI * 2);
      return { a, r: 1.05 + ((i * 0.53) % 0.75), len: 0.5 + ((i * 0.31) % 0.7) };
    });
  }, []);

  const bumpList = useMemo(() => {
    return Array.from({ length: Math.round(4 + (redness / 100) * 18) }).map((_, i) => ({
      x: ((i * 0.77) % 2.6) - 1.3,
      y: 2.6 + ((i * 0.43) % 0.9),
      s: 0.08 + ((i * 0.19) % 0.07),
    }));
  }, [redness]);

  const pterygLen = (redness / 100) * 1.9;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", condition], ["Severity", `${redness}%`], ["Conjunctiva", condition === "conjunctivitis" ? "injected & pink" : condition === "pterygium" ? "wing growing" : "follicles present"]]} />
      <SimCanvas cameraPosition={[0, 1.8, 10.5]} target={[0, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* eyeball: sclera reddens in conjunctivitis */}
        <mesh position={[0, 1.2, 0]} castShadow>
          <sphereGeometry args={[2.1, 36, 26]} />
          <meshStandardMaterial
            color={condition === "conjunctivitis" ? new THREE.Color("#f8fafc").lerp(new THREE.Color("#fca5a5"), redness / 160) : "#f8fafc"}
            roughness={0.35}
          />
        </mesh>
        {/* injected vessels */}
        {condition === "conjunctivitis" && (
          <group ref={vessels}>
            {vesselList.map((v, i) => (
              <mesh key={i} position={[Math.cos(v.a) * v.r - 0.3, 1.2 + Math.sin(v.a) * v.r * 0.8, 1.55]} rotation={[0, 0, v.a]}>
                <cylinderGeometry args={[0.045, 0.03, v.len, 6]} />
                <meshStandardMaterial color="#dc2626" roughness={0.5} emissive="#991b1b" emissiveIntensity={0.5} />
              </mesh>
            ))}
          </group>
        )}
        {/* trachoma follicles under the lid */}
        {condition === "trachoma" &&
          bumpList.map((b, i) => (
            <mesh key={i} position={[b.x, b.y, 1.2]}>
              <sphereGeometry args={[b.s, 10, 8]} />
              <meshStandardMaterial color="#e7e5e4" roughness={0.7} emissive="#78716c" emissiveIntensity={0.3} />
            </mesh>
          ))}

        {/* cornea + iris */}
        <mesh position={[0, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <sphereGeometry args={[1.95, 36, 20, -Math.PI * 0.24, Math.PI * 0.48, Math.PI * 0.3, Math.PI * 0.4]} />
          <meshStandardMaterial color="#bae6fd" transparent opacity={0.4} roughness={0.15} />
        </mesh>
        <mesh position={[1.95, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.68, 0.32, 14, 32]} />
          <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
        </mesh>

        {/* pterygium: wing-shaped growth from the inner corner onto cornea */}
        {condition === "pterygium" && (
          <group>
            <mesh position={[-1.95 + pterygLen / 2, 1.2, 0.85]} rotation={[0, -Math.PI / 2.6, 0]}>
              <coneGeometry args={[0.55 + pterygLen * 0.25, pterygLen + 0.4, 4]} />
              <meshStandardMaterial color="#fda4af" roughness={0.6} emissive="#9f1239" emissiveIntensity={0.3} />
            </mesh>
            <Label text="Pterygium wing" position={[-1.6 + pterygLen / 2, 2.8, 0.9]} size={0.5} color="#fda4af" />
          </group>
        )}

        <Label text={condition === "conjunctivitis" ? "Conjunctivitis — pink eye" : condition === "pterygium" ? "Pterygium — surfer's eye" : "Trachoma — follicles under lid"} position={[0, 4.4, 0]} size={0.52} color="#fde047" />
        <Label text="The conjunctiva is the thin clear skin over the white of the eye" position={[0, -1.7, 0]} size={0.42} color="#94a3b8" />
        <Animator vessels={vessels} elapsed={elapsed} redness={redness} />
      </SimCanvas>
    </div>
  );
}
