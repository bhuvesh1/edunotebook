// Opioids & anesthetics: red pain signals race up the nerve toward the brain —
// the opioid gate slams shut and blocks them in proportion to the dose.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Opioid dose", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Opioids & anesthetics",
  blurb: "Pain signals race up the nerve — the opioid gate blocks them in proportion to the dose.",
};

const N_PAIN = 10;

function Animator({ pain, gate, elapsed, dose, setTick }: {
  pain: React.RefObject<(THREE.Mesh | null)[]>;
  gate: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  dose: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    let blocked = 0;
    let reached = 0;
    pain.current.forEach((p, i) => {
      if (!p) return;
      const f = (t * 0.45 + i / N_PAIN) % 1;
      const gateX = 0;
      const x = -5 + f * 10;
      const isBlocked = ((i * 61) % 10) / 10 < k && f > 0.5;
      if (isBlocked) {
        blocked++;
        // pile up and fade at the gate
        const g = Math.min(1, (f - 0.5) * 6);
        p.position.set(gateX - g * 0.6, 1.5 + Math.sin(i * 2) * 0.3, 0);
        ((p as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = Math.max(0, 1 - g * 1.3);
        p.visible = g < 0.85;
      } else {
        p.visible = true;
        p.position.set(x, 1.5, 0);
        ((p as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = 1;
        if (f > 0.92) reached++;
      }
      p.rotation.z = -Math.PI / 2;
    });
    if (gate.current) {
      // gate glows stronger with dose
      gate.current.children.forEach((c) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        if (m.emissive) m.emissiveIntensity = 0.3 + k * 1.5;
      });
      gate.current.position.y = 1.5 + Math.sin(t * 3) * 0.05;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(blocked * 10 + reached); }
  });
  return null;
}

export function Topic10115Sim(props: SimProps) {
  const dose = Number(props.dose ?? 60);
  const showLabels = String(props.detail ?? "on") === "on";
  const pain = useRef<(THREE.Mesh | null)[]>([]);
  const gate = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const k = dose / 100;
  const blockedPct = Math.round(k * 100);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Pain signals blocked", `${blockedPct}%`],
          ["Brain feels", blockedPct > 70 ? "no pain" : blockedPct > 30 ? "dull ache" : "sharp pain"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* injury site */}
        <group position={[-5.4, 1.5, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.5, 16, 12]} />
            <meshStandardMaterial color="#f97316" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.55, 0]}>
            <coneGeometry args={[0.18, 0.4, 8]} />
            <meshStandardMaterial color="#ef4444" emissive="#b91c1c" emissiveIntensity={1} />
          </mesh>
        </group>
        {showLabels && <Label text="injury — pain starts" position={[-5.4, 2.8, 0]} size={0.45} color="#fdba74" />}

        {/* nerve fibre */}
        <mesh position={[0, 1.5, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.28, 0.28, 10.5, 14]} />
          <meshStandardMaterial color="#facc15" roughness={0.5} />
        </mesh>
        {showLabels && <Label text="nerve" position={[2.8, 0.75, 0]} size={0.45} color="#fde047" />}

        {/* opioid receptor gate */}
        <group ref={gate} position={[0, 1.5, 0]}>
          <mesh>
            <torusGeometry args={[0.55, 0.14, 10, 20]} />
            <meshStandardMaterial color="#22c55e" emissive="#16a34a" emissiveIntensity={0.8} transparent opacity={0.9} />
          </mesh>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <boxGeometry args={[0.12, 1.0, 0.12]} />
            <meshStandardMaterial color="#22c55e" emissive="#16a34a" emissiveIntensity={0.8} />
          </mesh>
        </group>
        {showLabels && <Label text="opioid receptor gate" position={[0, 2.75, 0]} size={0.45} color="#86efac" />}

        {/* pain signals */}
        {Array.from({ length: N_PAIN }).map((_, i) => (
          <mesh key={i} ref={(m) => { pain.current[i] = m; }}>
            <coneGeometry args={[0.16, 0.45, 10]} />
            <meshStandardMaterial color="#ef4444" emissive="#b91c1c" emissiveIntensity={1.2} transparent />
          </mesh>
        ))}

        {/* brain */}
        <mesh position={[5.6, 1.5, 0]} castShadow>
          <sphereGeometry args={[0.85, 20, 14]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.65} />
        </mesh>
        {showLabels && <Label text="brain" position={[5.6, 2.8, 0]} size={0.45} color="#f9a8d4" />}

        {/* morphine syringe */}
        <group position={[-2.6, 0, 1.8]}>
          <mesh position={[0, 0.7, 0]} rotation={[0, 0, 0.5]} castShadow>
            <cylinderGeometry args={[0.14, 0.14, 1.1, 12]} />
            <meshStandardMaterial color="#e0f2fe" transparent opacity={0.8} />
          </mesh>
          <mesh position={[0.28, 1.15, 0]} rotation={[0, 0, 0.5]}>
            <cylinderGeometry args={[0.03, 0.03, 0.5, 8]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.6} roughness={0.3} />
          </mesh>
        </group>
        {showLabels && <Label text="opioid injection" position={[-2.6, 1.9, 1.8]} size={0.45} color="#7dd3fc" />}

        <Animator pain={pain} gate={gate} elapsed={elapsed} dose={dose} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
