// app/components/sims/unique/Topic10573Sim.tsx
// Implant components and types: exploded stack view — fixture (implant
// screw), abutment, and crown separating and re-assembling.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "explode", label: "Explode view", kind: "slider", min: 0, max: 100, step: 1, default: 60, unit: "%" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Implant Components & Types",
  blurb: "The implant stack pulls apart: fixture in bone, abutment connector, crown on top.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ abut, crown, screw, elapsed, speed, explode }: {
  abut: RefObject<THREE.Group>; crown: RefObject<THREE.Group>; screw: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number; explode: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const e = explode / 100;
    const wob = 0.05 * Math.sin(elapsed.current * 2);
    if (abut.current) abut.current.position.y = e * 2.2 + wob;
    if (crown.current) crown.current.position.y = e * 4.4 + wob * 1.5;
    if (screw.current) screw.current.rotation.y = elapsed.current * 0.4;
  });
  return null;
}

export function Topic10573Sim(props: SimProps) {
  const explode = Number(props.explode ?? 60);
  const speed = Number(props.speed ?? 1);
  const abut = useRef<THREE.Group>(null!);
  const crown = useRef<THREE.Group>(null!);
  const screw = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["1 Fixture", "titanium screw in bone"],
          ["2 Abutment", "connector post"],
          ["3 Crown", "visible tooth"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* bone bed */}
        <mesh position={[0, 0.9, 0]} castShadow receiveShadow>
          <boxGeometry args={[6, 2, 2.4]} />
          <meshStandardMaterial color="#d9b98a" roughness={0.85} />
        </mesh>

        {/* 1 — fixture (endosteal screw) */}
        <group ref={screw} position={[0, 1.7, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.34, 0.24, 1.8, 16]} />
            <meshStandardMaterial color="#9ca3af" metalness={0.85} roughness={0.3} />
          </mesh>
          {[0.6, 0.2, -0.2, -0.6].map((dy, i) => (
            <mesh key={i} position={[0, dy, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.33, 0.055, 8, 20]} />
              <meshStandardMaterial color="#d1d5db" metalness={0.85} roughness={0.3} />
            </mesh>
          ))}
        </group>

        {/* 2 — abutment */}
        <group ref={abut} position={[0, 2.75, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.2, 0.3, 0.7, 14]} />
            <meshStandardMaterial color="#e5e7eb" metalness={0.9} roughness={0.25} />
          </mesh>
          <mesh position={[0, -0.45, 0]}>
            <cylinderGeometry args={[0.12, 0.12, 0.35, 10]} />
            <meshStandardMaterial color="#fbbf24" metalness={0.9} roughness={0.25} />
          </mesh>
        </group>

        {/* 3 — crown */}
        <group ref={crown} position={[0, 3.7, 0]}>
          <mesh castShadow>
            <boxGeometry args={[1.1, 0.9, 1.1]} />
            <meshStandardMaterial color="#ffffff" roughness={0.25} />
          </mesh>
          <mesh position={[0, -0.55, 0]}>
            <boxGeometry args={[0.8, 0.25, 0.8]} />
            <meshStandardMaterial color="#fde68a" roughness={0.4} />
          </mesh>
        </group>

        {/* connecting dashed axis */}
        <mesh position={[1.3, 2.7, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 5.5, 8]} />
          <meshStandardMaterial color="#475569" transparent opacity={0.5} />
        </mesh>

        <Label p={[-2.4, 1.7, 0]} size={0.32} color="#d1d5db">1 · fixture</Label>
        <Label p={[-2.4, 3.1, 0]} size={0.32} color="#e5e7eb">2 · abutment</Label>
        <Label p={[-2.4, 4.5, 0]} size={0.32} color="#ffffff">3 · crown</Label>
        <Label p={[2.2, 0.9, 0]} size={0.3} color="#fde68a">endosteal type (in bone)</Label>

        <Animator abut={abut} crown={crown} screw={screw} elapsed={elapsed} speed={speed} explode={explode} />
      </SimCanvas>
    </div>
  );
}
