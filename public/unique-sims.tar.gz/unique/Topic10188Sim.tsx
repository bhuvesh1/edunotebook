"use client";
// Ear: otosclerosis, facial nerve disorders, ear tumors.
// The tiny stapes bone should vibrate freely — stiffen it with the
// slider and watch sound fade; the facial nerve glows beside it.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "otosclerosis", options: ["otosclerosis", "facial", "tumor"] },
  { key: "stiff", label: "Stapes stiffness", kind: "slider", min: 0, max: 100, step: 5, default: 40, unit: "%" },
];

export const UNIQUE_META = {
  title: "Otosclerosis, Facial Nerve & Ear Tumors",
  blurb: "The stapes is the body's tiniest bone — stiffen it and sound fades; then trace the facial nerve and spot the tumor.",
};

function Animator({ stapes, wave, elapsed, stiff, condition }: { stapes: React.RefObject<THREE.Group>; wave: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; stiff: number; condition: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const amp = condition === "otosclerosis" ? (1 - stiff / 100) * 0.3 : 0.3;
    if (stapes.current) stapes.current.position.x = Math.sin(elapsed.current * 16) * amp;
    if (wave.current) {
      const s = 0.5 + amp * 2.2;
      wave.current.scale.set(s, s, s);
      (wave.current.material as THREE.MeshStandardMaterial).opacity = 0.25 + amp * 1.8;
    }
  });
  return null;
}

export function Topic10188Sim(props: SimProps) {
  const condition = String(props.condition ?? "otosclerosis");
  const stiff = Number(props.stiff ?? 40);
  const stapes = useRef<THREE.Group>(null!);
  const wave = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const hearing = condition === "otosclerosis" ? Math.round(100 - stiff * 0.7) : 100;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", condition], ["Hearing left", `${hearing}%`]]} />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* eardrum */}
        <mesh position={[-3.4, 2.6, 0]} rotation={[0, Math.PI / 2, 0]}>
          <circleGeometry args={[0.6, 20]} />
          <meshStandardMaterial color="#d1d5db" roughness={0.4} side={THREE.DoubleSide} />
        </mesh>
        <Label text="EARDRUM" position={[-3.4, 3.8, 0]} size={0.5} color="#d1d5db" />
        {/* malleus + incus */}
        {[[-2.4], [-1.7]].map(([x], i) => (
          <mesh key={x} position={[x, 2.6, 0]} rotation={[0, 0, 0.3 - i * 0.5]} castShadow>
            <capsuleGeometry args={[0.14, 0.5, 4, 8]} />
            <meshStandardMaterial color="#fef3c7" roughness={0.5} />
          </mesh>
        ))}
        {/* stapes: stirrup shape */}
        <group ref={stapes} position={[-0.8, 2.6, 0]}>
          <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
            <torusGeometry args={[0.3, 0.1, 8, 16, Math.PI]} />
            <meshStandardMaterial color={condition === "otosclerosis" ? "#f59e0b" : "#fef3c7"} emissive={condition === "otosclerosis" ? "#d97706" : "#000000"} emissiveIntensity={condition === "otosclerosis" ? 0.5 : 0} roughness={0.5} />
          </mesh>
          <mesh position={[0, 0.35, 0]}>
            <boxGeometry args={[0.14, 0.4, 0.14]} />
            <meshStandardMaterial color={condition === "otosclerosis" ? "#f59e0b" : "#fef3c7"} roughness={0.5} />
          </mesh>
          <Label text="STAPES (tiny!)" position={[0, 1.1, 0]} size={0.5} color="#fde68a" />
        </group>
        {/* oval window + cochlea */}
        <mesh position={[0.4, 2.6, 0]} rotation={[0, Math.PI / 2, 0]}>
          <circleGeometry args={[0.4, 16]} />
          <meshStandardMaterial color="#93c5fd" roughness={0.4} side={THREE.DoubleSide} />
        </mesh>
        <mesh ref={wave} position={[1.6, 2.6, 0]}>
          <torusGeometry args={[0.5, 0.08, 8, 20]} />
          <meshStandardMaterial color="#7dd3fc" emissive="#38bdf8" emissiveIntensity={0.8} transparent opacity={0.6} />
        </mesh>
        <Label text="TO COCHLEA" position={[1.6, 3.6, 0]} size={0.5} color="#7dd3fc" />
        {/* facial nerve */}
        <group position={[-1.4, 0.9, 0.8]}>
          <mesh rotation={[0, 0, 0.35]} castShadow>
            <cylinderGeometry args={[0.13, 0.13, 3.4, 8]} />
            <meshStandardMaterial color={condition === "facial" ? "#f87171" : "#fbbf24"} emissive={condition === "facial" ? "#ef4444" : "#f59e0b"} emissiveIntensity={condition === "facial" ? 0.9 : 0.25} roughness={0.5} />
          </mesh>
          <Label text="FACIAL NERVE" position={[0, -0.6, 0]} size={0.5} color={condition === "facial" ? "#f87171" : "#fbbf24"} />
        </group>
        {/* tumor */}
        {condition === "tumor" && (
          <group position={[1.2, 1.4, 0.8]}>
            <mesh castShadow>
              <icosahedronGeometry args={[0.55, 1]} />
              <meshStandardMaterial color="#7c3aed" emissive="#8b5cf6" emissiveIntensity={0.5} roughness={0.55} flatShading />
            </mesh>
            <Label text="TUMOR" position={[0, 1.1, 0]} size={0.55} color="#c4b5fd" />
          </group>
        )}
        <Animator stapes={stapes} wave={wave} elapsed={elapsed} stiff={stiff} condition={condition} />
      </SimCanvas>
    </div>
  );
}
