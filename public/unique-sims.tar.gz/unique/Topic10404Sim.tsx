"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "lesion", label: "Lesion type", kind: "select", min: 0, max: 0, step: 1, default: "traumatic", options: ["traumatic", "infective", "immune"] },
  { key: "severity", label: "Severity", kind: "slider", min: 1, max: 3, step: 1, default: 2, unit: "" },
];

export const UNIQUE_META = {
  title: "Oral mucosal lesions: traumatic, infective, immune-mediated",
  blurb: "Cross-section of cheek mucosa with a pulsing lesion — traumatic ulcer, infective plaque or immune-mediated lace pattern.",
};

const INFO: Record<string, { label: string; color: string; note: string }> = {
  traumatic: { label: "Traumatic ulcer", color: "#ef4444", note: "Painful crater with red halo" },
  infective: { label: "Infective lesion (candidiasis)", color: "#fde68a", note: "White curd-like plaques" },
  immune: { label: "Immune-mediated (lichen planus)", color: "#f8fafc", note: "White lace (Wickham striae)" },
};

function Scene({ lesion, severity }: { lesion: string; severity: number }) {
  const pulse = useRef<THREE.Group>(null!);
  const spin = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const info = INFO[lesion] ?? INFO.traumatic;

  useFrame((_, delta) => {
    t.current += delta;
    if (pulse.current) {
      const s = 1 + Math.sin(t.current * 3) * 0.08;
      pulse.current.scale.setScalar(s * (0.7 + severity * 0.25));
    }
    if (spin.current) spin.current.rotation.y = t.current * 0.25;
  });

  return (
    <group ref={spin}>
      {/* connective tissue base */}
      <mesh position={[0, 0.2, 0]} receiveShadow>
        <boxGeometry args={[7, 1.6, 4.5]} />
        <meshStandardMaterial color="#be5a6e" roughness={0.9} />
      </mesh>
      {/* epithelium layer */}
      <mesh position={[0, 1.15, 0]}>
        <boxGeometry args={[7, 0.35, 4.5]} />
        <meshStandardMaterial color="#f4a7b9" roughness={0.6} />
      </mesh>
      <Label text="Epithelium" position={[-3.9, 1.15, 0]} size={0.5} color="#fda4af" />
      <Label text="Connective tissue" position={[-3.9, 0.2, 0]} size={0.5} color="#fda4af" />
      {/* blood vessels */}
      {[-1.5, 0, 1.5].map((x, i) => (
        <mesh key={i} position={[x, 0.35, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.09, 0.09, 6.4, 10]} />
          <meshStandardMaterial color="#dc2626" roughness={0.4} />
        </mesh>
      ))}

      {/* the lesion */}
      <group ref={pulse} position={[0, 1.35, 0]}>
        {lesion === "traumatic" && (
          <>
            <mesh rotation={[-Math.PI / 2, 0, 0]}>
              <circleGeometry args={[0.9, 24]} />
              <meshStandardMaterial color="#7f1d1d" roughness={0.7} />
            </mesh>
            <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
              <ringGeometry args={[0.9, 1.25, 24]} />
              <meshStandardMaterial color="#ef4444" roughness={0.7} />
            </mesh>
          </>
        )}
        {lesion === "infective" && (
          <>
            {[[0, 0], [0.5, 0.3], [-0.5, 0.25], [0.2, -0.45], [-0.35, -0.3]].map(([x, z], i) => (
              <mesh key={i} position={[x, 0.12, z]}>
                <sphereGeometry args={[0.32, 14, 14]} />
                <meshStandardMaterial color="#fef3c7" roughness={0.85} />
              </mesh>
            ))}
          </>
        )}
        {lesion === "immune" && (
          <>
            {[0, 1, 2].map((i) => (
              <mesh key={i} rotation={[-Math.PI / 2, 0, (i * Math.PI) / 3]} position={[0, 0.05 + i * 0.02, 0]}>
                <torusGeometry args={[0.75, 0.05, 8, 32, Math.PI * 1.2]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.6} />
              </mesh>
            ))}
          </>
        )}
      </group>
      <Label text={info.label} position={[0, 2.6, 0]} size={0.6} color={info.color} />
      <Label text={info.note} position={[0, -1.1, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10404Sim(props: SimProps) {
  const lesion = String(props.lesion ?? "traumatic");
  const severity = Number(props.severity ?? 2);
  const info = INFO[lesion] ?? INFO.traumatic;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Lesion", info.label], ["Severity", `${severity}/3`]]} />
      <SimCanvas cameraPosition={[0, 4.5, 9]} target={[0, 0.8, 0]}>
        <Scene lesion={lesion} severity={severity} />
      </SimCanvas>
    </div>
  );
}
