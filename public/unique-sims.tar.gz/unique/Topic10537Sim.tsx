// app/components/sims/unique/Topic10537Sim.tsx
// Dental caries in children: ECC and rampant caries. A row of baby teeth
// develops brown decay spots that spread and darken as the decay slider
// rises; sugary drink bottles pour "sugar" over the teeth.

"use client";

import { useMemo, useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "decay", label: "Decay progress", kind: "slider", min: 0, max: 100, step: 1, default: 45, unit: "%" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Dental Caries in Children: ECC & Rampant Caries",
  blurb: "Sugar feeds the decay spots spreading across baby teeth — watch early white spots turn into brown cavities.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

const SUGAR = 24;

function Animator({ sugar, spots, elapsed, speed, decay }: {
  sugar: RefObject<THREE.InstancedMesh>; spots: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number; decay: number;
}) {
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (sugar.current) {
      for (let i = 0; i < SUGAR; i++) {
        const cyc = (t * 0.7 + i / SUGAR) % 1;
        dummy.position.set(-2.6 + (i % 6) * 0.25, 5.4 - cyc * 3.4, Math.sin(i * 2.1) * 0.5);
        dummy.scale.setScalar(0.08);
        dummy.updateMatrix();
        sugar.current.setMatrixAt(i, dummy.matrix);
      }
      sugar.current.instanceMatrix.needsUpdate = true;
    }
    if (spots.current) {
      const f = decay / 100;
      spots.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
        // spots grow and darken from white-spot to brown cavity
        m.scale.setScalar(Math.max(0.15 + f * 1.1, 0.001));
        mat.color.setHSL(0.09 - f * 0.04, 0.25 + f * 0.5, 0.85 - f * 0.6);
        m.position.y = 2.5 + 0.05 * Math.sin(t * 3 + i);
      });
    }
  });
  return null;
}

// decay spot anchor positions on the teeth row
const SPOT_POS: [number, number, number][] = [
  [-1.9, 2.5, 0.32], [-1.15, 2.62, 0.32], [-0.4, 2.55, 0.32],
  [0.4, 2.62, 0.32], [1.15, 2.5, 0.32], [1.9, 2.6, 0.32],
  [-0.75, 2.3, 0.32], [0.75, 2.3, 0.32],
];

export function Topic10537Sim(props: SimProps) {
  const decay = Number(props.decay ?? 45);
  const speed = Number(props.speed ?? 1);
  const sugar = useRef<THREE.InstancedMesh>(null!);
  const spots = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const stage = decay < 20 ? "sound enamel" : decay < 45 ? "white-spot lesions" : decay < 75 ? "brown cavities forming" : "rampant caries ⚠";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", stage],
          ["Pattern", "ECC: upper front teeth first"],
          ["Prevention", "no bedtime bottle, fluoride"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* row of baby teeth */}
        {[-2.1, -1.4, -0.7, 0, 0.7, 1.4, 2.1].map((x, i) => (
          <group key={i} position={[x, 2.2, 0]}>
            <mesh castShadow>
              <boxGeometry args={[0.62, 0.8, 0.55]} />
              <meshStandardMaterial color="#fefce8" roughness={0.3} />
            </mesh>
            <mesh position={[0, -0.65, 0]} rotation={[Math.PI, 0, 0]}>
              <coneGeometry args={[0.2, 0.6, 8]} />
              <meshStandardMaterial color="#fefce8" roughness={0.35} />
            </mesh>
          </group>
        ))}
        {/* gum */}
        <mesh position={[0, 1.55, -0.1]} castShadow>
          <boxGeometry args={[5.6, 0.6, 0.9]} />
          <meshStandardMaterial color="#e0607a" roughness={0.6} />
        </mesh>

        {/* decay spots spreading */}
        <group ref={spots}>
          {SPOT_POS.map((p, i) => (
            <mesh key={i} position={p}>
              <sphereGeometry args={[0.16, 12, 12]} />
              <meshStandardMaterial color="#fde68a" roughness={0.8} />
            </mesh>
          ))}
        </group>

        {/* sugary bottle pouring */}
        <group position={[-2.6, 5.6, 0]} rotation={[0, 0, -0.5]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.4, 0.4, 1.6, 14]} />
            <meshStandardMaterial color="#f97316" transparent opacity={0.75} roughness={0.3} />
          </mesh>
          <mesh position={[0, 1.0, 0]}>
            <cylinderGeometry args={[0.15, 0.3, 0.5, 10]} />
            <meshStandardMaterial color="#c2410c" roughness={0.4} />
          </mesh>
        </group>
        <instancedMesh ref={sugar} args={[undefined, undefined, SUGAR]}>
          <sphereGeometry args={[1, 8, 8]} />
          <meshStandardMaterial color="#fdba74" roughness={0.5} />
        </instancedMesh>
        <Label p={[-2.6, 6.9, 0]} size={0.3} color="#fdba74">sugary drinks feed decay</Label>

        <Label p={[3.4, 2.6, 0]} size={0.3} color="#b45309">decay spots spread</Label>
        <Label p={[0, 0.6, 0]} size={0.3} color="#e2e8f0">baby (primary) teeth</Label>

        <Animator sugar={sugar} spots={spots} elapsed={elapsed} speed={speed} decay={decay} />
      </SimCanvas>
    </div>
  );
}
