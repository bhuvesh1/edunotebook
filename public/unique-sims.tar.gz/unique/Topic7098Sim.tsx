// app/components/sims/unique/Topic7098Sim.tsx
// Scalars vs vectors: on the left a thermometer shows temperature — a
// scalar, just a number with no direction. On the right a ball carries a
// green velocity arrow — a vector, where both the length (magnitude) and
// the pointing direction matter.

"use client";

import { useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Wind speed", kind: "slider", min: 1, max: 6, step: 0.5, default: 3, unit: "m/s" },
];

export const UNIQUE_META = {
  title: "Scalars and Vectors",
  blurb: "Temperature is a scalar — just a number. Velocity is a vector — a number plus a direction.",
};

function Animator({
  mercury, arrow, speed, temp, bump,
}: {
  mercury: RefObject<THREE.Mesh>;
  arrow: RefObject<THREE.Group>;
  speed: number;
  temp: RefObject<number>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const T = t.current;
    // Scalar: temperature wobbles between 20 and 30 °C — no direction involved.
    const c = 25 + 5 * Math.sin(T * 0.8);
    temp.current = c;
    if (mercury.current) {
      const h = 0.4 + ((c - 20) / 10) * 2.2;
      mercury.current.scale.y = h;
      mercury.current.position.y = 0.9 + h / 2;
    }
    // Vector: arrow length = speed (magnitude), rotation = direction.
    if (arrow.current) {
      arrow.current.rotation.y = T * 0.7;
      const L = 0.8 + speed * 0.45;
      const shaft = arrow.current.children[0] as THREE.Mesh;
      const cone = arrow.current.children[1] as THREE.Mesh;
      shaft.scale.set(1, L, 1);
      shaft.position.set(0, L / 2, 0);
      cone.position.set(0, L + 0.22, 0);
    }
    if (++n.current % 20 === 0) bump();
  });
  return null;
}

export function Topic7098Sim(props: SimProps) {
  const speed = Number(props.speed ?? 3);
  const mercury = useRef<THREE.Mesh>(null!);
  const arrow = useRef<THREE.Group>(null!);
  const temp = useRef(25);
  const [, bump] = useState(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["🌡️ Temperature", `${temp.current.toFixed(1)} °C — scalar`],
          ["💨 Wind velocity", `${speed.toFixed(1)} m/s — vector`],
          ["Scalar", "magnitude only"],
          ["Vector", "magnitude + direction"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5, 14]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* SCALAR station: thermometer */}
        <mesh position={[-4, 0.14, 0]} receiveShadow>
          <cylinderGeometry args={[1.3, 1.5, 0.28, 24]} />
          <meshStandardMaterial color="#1e293b" roughness={0.8} />
        </mesh>
        <mesh position={[-4, 2.6, 0]} castShadow>
          <cylinderGeometry args={[0.35, 0.35, 4.2, 20]} />
          <meshStandardMaterial color="#e2e8f0" transparent opacity={0.35} roughness={0.15} />
        </mesh>
        <mesh ref={mercury} position={[-4, 1.5, 0]}>
          <cylinderGeometry args={[0.2, 0.2, 1, 16]} />
          <meshStandardMaterial color="#ef4444" emissive="#7f1d1d" emissiveIntensity={0.7} roughness={0.4} />
        </mesh>
        <mesh position={[-4, 0.75, 0]} castShadow>
          <sphereGeometry args={[0.42, 20, 20]} />
          <meshStandardMaterial color="#ef4444" emissive="#7f1d1d" emissiveIntensity={0.7} roughness={0.4} />
        </mesh>

        {/* VECTOR station: ball with rotating velocity arrow */}
        <mesh position={[4, 0.14, 0]} receiveShadow>
          <cylinderGeometry args={[1.3, 1.5, 0.28, 24]} />
          <meshStandardMaterial color="#1e293b" roughness={0.8} />
        </mesh>
        <mesh position={[4, 1.1, 0]} castShadow>
          <sphereGeometry args={[0.55, 28, 28]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.4} />
        </mesh>
        <group ref={arrow} position={[4, 1.1, 0]}>
          <mesh>
            <cylinderGeometry args={[0.1, 0.1, 1, 12]} />
            <meshStandardMaterial color="#22c55e" emissive="#15803d" emissiveIntensity={0.6} roughness={0.4} />
          </mesh>
          <mesh>
            <coneGeometry args={[0.26, 0.5, 14]} />
            <meshStandardMaterial color="#22c55e" emissive="#15803d" emissiveIntensity={0.6} roughness={0.4} />
          </mesh>
        </group>
        {/* direction compass ring */}
        <mesh position={[4, 1.1, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[2.4, 0.04, 8, 48]} />
          <meshStandardMaterial color="#475569" roughness={0.6} />
        </mesh>

        <Animator mercury={mercury} arrow={arrow} speed={speed} temp={temp} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
