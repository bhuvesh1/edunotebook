"use client";
// Biomechanics: Leveling, Space Closure, Finishing — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Stage", kind: "select", min: 0, max: 0, step: 1, default: "Leveling", options: ["Leveling", "Space closure", "Finishing"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Biomechanics: Leveling, Space Closure, Finishing",
  blurb: "Three acts of braces: a crooked tooth levels, a gap slides shut, then the wire finishes the smile.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const idx = p.stage === "Leveling" ? 0 : p.stage === "Space closure" ? 1 : 2;
    const crook: any = g("crooked");
    if (crook) {
      crook.rotation.z += (0 - crook.rotation.z) * 0.06;
    }
    const t3: any = g("slide3");
    const t4: any = g("slide4");
    const gapTarget = idx >= 1 ? 0 : 0.9;
    if (t3) t3.position.x += ((1.2 + gapTarget) - t3.position.x) * 0.06;
    if (t4) t4.position.x += ((2.4 + gapTarget * 0.5) - t4.position.x) * 0.06;
    const fw: any = g("finishwire");
    if (fw) fw.visible = idx === 2;
    group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
  });
  return null;
}

export function Topic10470Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const stage = String(props.stage ?? "Leveling");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, stage };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", stage],
          ["Leveling", "Uprights crooked tooth"],
          ["Space closure", "Sliding mechanics"],
          ["Finishing", "Detailing the bite"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          {[-2.4, -1.2].map((x, i) => (
            <mesh key={i} position={[x, 1.2, 0]}>
              <boxGeometry args={[1, 1.6, 1]} />
              <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
            </mesh>
          ))}
          <group name="crooked" position={[0, 1.2, 0]} rotation={[0, 0, 0.55]}>
            <mesh>
              <boxGeometry args={[1, 1.6, 1]} />
              <meshStandardMaterial color="#fbbf24" roughness={0.4} />
            </mesh>
          </group>
          <group name="slide3" position={[2.1, 1.2, 0]}>
            <mesh>
              <boxGeometry args={[1, 1.6, 1]} />
              <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
            </mesh>
          </group>
          <group name="slide4" position={[3.3, 1.2, 0]}>
            <mesh>
              <boxGeometry args={[1, 1.6, 1]} />
              <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
            </mesh>
          </group>
          <group name="finishwire" position={[0, 1.85, 0]} visible={false}>
            <Wire points={[[-2.9, 0, 0.55], [0, 0, 0.6], [2.9, 0, 0.55]]} color="#4ade80" radius={0.05} />
          </group>
          <GumSlab position={[0, 0.1, -0.3]} scale={1.25} />
          <Label text="Crooked tooth levels" position={[0, 2.9, 0]} size={0.42} color="#fbbf24" />
          <Label text="Gap closes" position={[2.7, 2.9, 0]} size={0.42} />
          <Label text={"Stage: " + stage} position={[0, 3.6, 0]} size={0.46} color="#4ade80" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
