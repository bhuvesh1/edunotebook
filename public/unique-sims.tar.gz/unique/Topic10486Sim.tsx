"use client";
// Scaling, Root Planing & Polishing — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "tool", label: "Instrument", kind: "select", min: 0, max: 0, step: 1, default: "Ultrasonic scaler", options: ["Ultrasonic scaler", "Polishing cup"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Scaling, Root Planing & Polishing",
  blurb: "The ultrasonic scaler buzzes calculus off the root — then the polishing cup buffs the tooth to a shine.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const scaler = p.tool === "Ultrasonic scaler";
    const sc: any = g("scalertip");
    if (sc) {
      sc.visible = scaler;
      sc.position.x = -0.75 + 0.06 * Math.sin(t * 40);
      sc.position.y = 0.9 + 0.06 * Math.cos(t * 34);
    }
    const pol: any = g("polcup");
    if (pol) {
      pol.visible = !scaler;
      pol.rotation.y = t * 10;
      pol.position.y = 2.6 + 0.1 * Math.sin(t * 3);
    }
    for (let i = 0; i < 5; i++) {
      const c: any = g("calc" + i);
      if (c) {
        c.scale.setScalar(scaler ? Math.max(0.001, 1 - ((t * 0.6 + i * 0.2) % 1.2)) * 0.22 : 0.001);
      }
    }
    const shine: any = g("shine");
    if (shine) (shine.material as any).opacity = scaler ? 0 : 0.4 + 0.3 * Math.sin(t * 4);
  });
  return null;
}

export function Topic10486Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const tool = String(props.tool ?? "Ultrasonic scaler");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, tool };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Instrument", tool],
          ["Action", tool === "Ultrasonic scaler" ? "Calculus removal" : "Stain removal + shine"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1.2, 0]} scale={1.5} />
          <GumSlab position={[0, 0.2, 0]} scale={1.15} />
          {[[-0.5, 0.5, 0.5], [0.45, 0.35, 0.55], [-0.15, 0.15, 0.62], [0.6, 0.7, 0.35], [-0.62, 0.85, 0.3]].map((pt, i) => (
            <mesh key={i} name={"calc" + i} position={[pt[0], pt[1] + 0.9, pt[2]]}>
              <boxGeometry args={[1, 1, 1]} />
              <meshStandardMaterial color="#92400e" roughness={0.95} />
            </mesh>
          ))}
          <group name="scalertip" position={[-0.75, 0.9, 0.4]}>
            <mesh rotation={[0, 0, 0.9]}>
              <cylinderGeometry args={[0.045, 0.02, 1.1, 8]} />
              <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.25} />
            </mesh>
            <mesh position={[0, 0.7, -0.3]} rotation={[0.5, 0, 0]}>
              <cylinderGeometry args={[0.09, 0.09, 0.7, 10]} />
              <meshStandardMaterial color="#64748b" metalness={0.7} roughness={0.4} />
            </mesh>
          </group>
          <group name="polcup" position={[0, 2.6, 0.5]} visible={false}>
            <mesh rotation={[Math.PI, 0, 0]}>
              <coneGeometry args={[0.3, 0.4, 14, 1, true]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.7} side={2} />
            </mesh>
          </group>
          <mesh name="shine" position={[0, 2.4, 0.4]}>
            <sphereGeometry args={[0.5, 12, 12]} />
            <meshStandardMaterial color="#ffffff" transparent opacity={0} roughness={0.1} />
          </mesh>
          <Label text="Ultrasonic scaler tip" position={[-2.9, 1.6, 0.4]} size={0.42} />
          <Label text="Calculus chunks" position={[2.6, 1.4, 0.4]} size={0.42} color="#92400e" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
