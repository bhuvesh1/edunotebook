// app/components/sims/unique/Topic7090Sim.tsx
// Speed vs velocity: two cars race on parallel lanes. Each car's green
// arrow is its velocity vector — the arrow's length shows the speed
// (magnitude) and it points in the direction of motion.

"use client";

import { useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speedA", label: "Car A speed", kind: "slider", min: 0, max: 6, step: 0.5, default: 3, unit: "m/s" },
];

export const UNIQUE_META = {
  title: "Speed and Velocity",
  blurb: "Two cars, two velocity arrows — arrow length is the speed, the arrow direction is the velocity's direction.",
};

const TRACK = 19; // x wraps in [-9.5, 9.5]

function CarRig({
  car,
  shaft,
  cone,
  color,
  laneZ,
  speed,
  offset,
  bump,
}: {
  car: RefObject<THREE.Group>;
  shaft: RefObject<THREE.Mesh>;
  cone: RefObject<THREE.Mesh>;
  color: string;
  laneZ: number;
  speed: number;
  offset: number;
  bump: () => void;
}) {
  const t = useRef(offset);
  const n = useRef(0);
  const wheels = useRef<THREE.Group>(null!);
  useFrame((_, delta) => {
    t.current += delta * speed;
    const x = -TRACK / 2 + ((t.current % TRACK) + TRACK) % TRACK;
    if (car.current) car.current.position.x = x;
    // Velocity arrow length ∝ speed.
    const L = 0.6 + speed * 0.55;
    if (shaft.current) {
      shaft.current.scale.y = L;
      shaft.current.position.y = L / 2;
    }
    if (cone.current) cone.current.position.y = L + 0.22;
    if (wheels.current) {
      wheels.current.children.forEach((w) => {
        w.rotation.z -= (speed * delta) / 0.32;
      });
    }
    if (++n.current % 25 === 0) bump();
  });
  return (
    <group ref={car} position={[0, 0, laneZ]}>
      <mesh position={[0, 0.72, 0]} castShadow>
        <boxGeometry args={[2.2, 0.66, 1.2]} />
        <meshStandardMaterial color={color} roughness={0.35} metalness={0.4} />
      </mesh>
      <mesh position={[-0.15, 1.3, 0]} castShadow>
        <boxGeometry args={[1.1, 0.55, 1.0]} />
        <meshStandardMaterial color="#bae6fd" roughness={0.2} metalness={0.3} />
      </mesh>
      <group ref={wheels}>
        {[-0.75, 0.75].map((x) =>
          [-0.62, 0.62].map((z) => (
            <mesh key={`${x}${z}`} position={[x, 0.32, z]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[0.32, 0.32, 0.18, 18]} />
              <meshStandardMaterial color="#111827" roughness={0.8} />
            </mesh>
          ))
        )}
      </group>
      {/* velocity vector arrow above the car */}
      <group position={[0, 1.9, 0]} rotation={[0, 0, -Math.PI / 2]}>
        <mesh ref={shaft}>
          <cylinderGeometry args={[0.09, 0.09, 1, 10]} />
          <meshStandardMaterial color="#22c55e" emissive="#15803d" emissiveIntensity={0.5} roughness={0.4} />
        </mesh>
        <mesh ref={cone}>
          <coneGeometry args={[0.24, 0.45, 12]} />
          <meshStandardMaterial color="#22c55e" emissive="#15803d" emissiveIntensity={0.5} roughness={0.4} />
        </mesh>
      </group>
    </group>
  );
}

export function Topic7090Sim(props: SimProps) {
  const speedA = Number(props.speedA ?? 3);
  const speedB = 1.6;
  const carA = useRef<THREE.Group>(null!);
  const carB = useRef<THREE.Group>(null!);
  const shaftA = useRef<THREE.Mesh>(null!);
  const coneA = useRef<THREE.Mesh>(null!);
  const shaftB = useRef<THREE.Mesh>(null!);
  const coneB = useRef<THREE.Mesh>(null!);
  const [, bump] = useState(0);
  const doBump = () => bump((v) => v + 1);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Car A velocity", `${speedA.toFixed(1)} m/s →`],
          ["Car B velocity", `${speedB.toFixed(1)} m/s →`],
          ["🟢 Arrow", "velocity vector"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 7, 15]} target={[0, 1, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* two lanes */}
        {[-1.6, 1.6].map((z) => (
          <mesh key={z} position={[0, 0.05, z]} receiveShadow>
            <boxGeometry args={[21, 0.1, 2.2]} />
            <meshStandardMaterial color="#334155" roughness={0.9} />
          </mesh>
        ))}

        <CarRig car={carA} shaft={shaftA} cone={coneA} color="#f97316" laneZ={-1.6} speed={speedA} offset={0} bump={doBump} />
        <CarRig car={carB} shaft={shaftB} cone={coneB} color="#38bdf8" laneZ={1.6} speed={speedB} offset={9} bump={doBump} />
      </SimCanvas>
    </div>
  );
}
