// Pneumonia, TB & pleural diseases — two lung lobes: one healthy pink and
// inflating, one with yellow consolidation patches (pneumonia) or white
// granuloma nodules (TB). Pleural effusion slider fills fluid around the lung.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "infection", label: "Infection extent", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "disease", label: "Disease", kind: "select", min: 0, max: 0, step: 1, default: "pneumonia", options: ["pneumonia", "tuberculosis", "pleural effusion"] },
];

export const UNIQUE_META = {
  title: "Pneumonia, TB & Pleural Disease",
  blurb: "One lung stays healthy while the other consolidates (pneumonia), grows TB nodules, or drowns in pleural fluid.",
};

function Animator({ lungs, fluid, elapsed, infection, disease }: {
  lungs: React.RefObject<THREE.Group>;
  fluid: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  infection: number;
  disease: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (lungs.current) {
      const [healthy, sick] = lungs.current.children;
      // breathing; sick lung inflates less as infection rises
      const b = (Math.sin(t * 2.2) + 1) / 2;
      const sickAmp = 1 - (infection / 100) * 0.75;
      healthy.scale.set(1 + b * 0.09, 1 + b * 0.13, 1 + b * 0.09);
      sick.scale.set(1 + b * 0.09 * sickAmp, 1 + b * 0.13 * sickAmp, 1 + b * 0.09 * sickAmp);
    }
    if (fluid.current) {
      const target = disease === "pleural effusion" ? 0.15 + (infection / 100) * 0.55 : 0;
      const mat = fluid.current.material as THREE.MeshStandardMaterial;
      mat.opacity += (target - mat.opacity) * Math.min(1, delta * 3);
      fluid.current.visible = mat.opacity > 0.02;
    }
  });
  return null;
}

export function Topic10219Sim(props: SimProps) {
  const infection = Number(props.infection ?? 55);
  const disease = String(props.disease ?? "pneumonia");
  const lungs = useRef<THREE.Group>(null!);
  const fluid = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const patches = useMemo(() => {
    const n = Math.round(2 + (infection / 100) * 12);
    return Array.from({ length: n }).map((_, i) => ({
      x: ((i * 0.61) % 1.3) - 0.65,
      y: ((i * 0.83) % 2.2) - 1.1,
      z: 0.75,
      s: 0.28 + ((i * 0.37) % 0.3),
    }));
  }, [infection]);

  const crackles = infection > 50;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Disease", disease], ["Lung involved", `${infection}%`], ["Breath sounds", disease === "pleural effusion" ? "stony dull, absent" : crackles ? "crackles ⚠" : "clear"]]} />
      <SimCanvas cameraPosition={[0, 2.8, 12]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* trachea */}
        <mesh position={[0, 5.2, 0]}>
          <cylinderGeometry args={[0.4, 0.4, 1.8, 14]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.55} />
        </mesh>

        <group ref={lungs}>
          {/* healthy left lung */}
          <group position={[-2.2, 2.6, 0]}>
            <mesh scale={[1, 1.5, 0.7]} castShadow>
              <sphereGeometry args={[1.15, 24, 18]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
            </mesh>
            <Label text="Healthy" position={[0, 2.4, 0]} size={0.5} color="#86efac" />
          </group>
          {/* diseased right lung */}
          <group position={[2.2, 2.6, 0]}>
            <mesh scale={[1, 1.5, 0.7]} castShadow>
              <sphereGeometry args={[1.15, 24, 18]} />
              <meshStandardMaterial color={disease === "pneumonia" ? "#fda4af" : disease === "tuberculosis" ? "#d6b8a8" : "#f9a8d4"} roughness={0.6} />
            </mesh>
            {/* pneumonia consolidation patches */}
            {disease === "pneumonia" &&
              patches.map((p, i) => (
                <mesh key={i} position={[p.x, p.y, p.z]}>
                  <sphereGeometry args={[p.s, 12, 10]} />
                  <meshStandardMaterial color="#facc15" roughness={0.7} emissive="#a16207" emissiveIntensity={0.35} />
                </mesh>
              ))}
            {/* TB granuloma nodules */}
            {disease === "tuberculosis" &&
              patches.map((p, i) => (
                <mesh key={i} position={[p.x, p.y, p.z * 0.8]}>
                  <sphereGeometry args={[p.s * 0.7, 12, 10]} />
                  <meshStandardMaterial color="#e7e5e4" roughness={0.8} emissive="#78716c" emissiveIntensity={0.3} flatShading />
                </mesh>
              ))}
            <Label text={disease === "pneumonia" ? "Consolidation — air sacs filled with pus" : disease === "tuberculosis" ? "TB granulomas (Ghon focus)" : "Pleural space"} position={[0, 2.4, 0]} size={0.46} color="#fca5a5" />
          </group>
        </group>

        {/* pleural effusion fluid rising around the sick lung */}
        <mesh ref={fluid} position={[2.2, 1.4, 0]} visible={false}>
          <cylinderGeometry args={[1.45, 1.55, 3.4, 24]} />
          <meshStandardMaterial color="#38bdf8" transparent opacity={0} roughness={0.2} />
        </mesh>

        <Label text={disease === "pneumonia" ? "Pneumonia: fever + cough + rusty sputum" : disease === "tuberculosis" ? "TB: night sweats + weight loss + chronic cough" : "Effusion: fluid compresses the lung"} position={[0, -0.6, 0]} size={0.46} color="#fde047" />
        <Animator lungs={lungs} fluid={fluid} elapsed={elapsed} infection={infection} disease={disease} />
      </SimCanvas>
    </div>
  );
}
