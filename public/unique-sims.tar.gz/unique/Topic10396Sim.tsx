"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Processing stage", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.55, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Denture base resins: PMMA, processing, repairs",
  blurb: "A full denture takes shape — pink PMMA base polymerizing around the teeth, then a crack appears and gets repaired.",
};

function DentureScene({ stage, speed, showLabels }: { stage: number; speed: number; showLabels: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const base = useRef<THREE.Mesh>(null!);
  const crack = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) g.current.rotation.y = Math.sin(elapsed.current * 0.35) * 0.2;
    if (base.current) {
      const m = base.current.material as THREE.MeshStandardMaterial;
      // dough → polymerized: glossy pink to matte gum pink
      m.roughness = THREE.MathUtils.lerp(0.12, 0.55, Math.min(1, stage * 1.4));
      m.color.lerpColors(new THREE.Color("#f9a8d4"), new THREE.Color("#e0608a"), Math.min(1, stage * 1.4));
    }
    if (crack.current) {
      crack.current.visible = stage > 0.8;
      (crack.current.material as THREE.MeshBasicMaterial).opacity = stage > 0.8 ? 0.9 : 0;
    }
  });

  return (
    <group ref={g}>
      {/* PMMA base — horseshoe */}
      <mesh ref={base} position={[0, 0, 0]} scale={[1.15, 0.42, 1.15]} castShadow>
        <torusGeometry args={[2.4, 1.05, 16, 44, Math.PI]} />
        <meshStandardMaterial color="#f9a8d4" roughness={0.12} />
      </mesh>
      {/* teeth set in wax → acrylic */}
      {Array.from({ length: 9 }).map((_, i) => {
        const a = Math.PI - (i / 8) * Math.PI;
        const x = Math.cos(a) * 2.4 * 1.15;
        const z = -Math.sin(a) * 2.4 * 1.15 * 0.95 + 0.2;
        const front = i > 2 && i < 6;
        return (
          <mesh key={i} position={[x, 0.75, z]} rotation={[0, -a + Math.PI / 2, 0]} castShadow>
            <boxGeometry args={[front ? 0.62 : 0.85, front ? 0.95 : 0.7, 0.6]} />
            <meshStandardMaterial color="#fffbeb" roughness={0.2} />
          </mesh>
        );
      })}
      {/* crack needing repair */}
      <mesh ref={crack} position={[2.9, 0.25, -0.6]} rotation={[0.3, 0, 1.2]} visible={false}>
        <planeGeometry args={[1.6, 0.09]} />
        <meshBasicMaterial color="#7f1d1d" transparent opacity={0.9} side={THREE.DoubleSide} />
      </mesh>
      {/* repair: fresh self-cure acrylic bead over crack */}
      {stage > 0.9 && (
        <mesh position={[2.9, 0.3, -0.6]} rotation={[0.3, 0, 1.2]} castShadow>
          <capsuleGeometry args={[0.16, 1.5, 6, 12]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.3} />
        </mesh>
      )}
      {/* flask for heat processing */}
      {stage < 0.45 && (
        <group position={[0, 0.2, 0]}>
          <mesh castShadow>
            <boxGeometry args={[7.6, 0.5, 6]} />
            <meshStandardMaterial color="#64748b" metalness={0.6} roughness={0.4} />
          </mesh>
          <mesh position={[0, 2.2, 0]} castShadow>
            <boxGeometry args={[7.6, 0.5, 6]} />
            <meshStandardMaterial color="#64748b" metalness={0.6} roughness={0.4} />
          </mesh>
        </group>
      )}

      {showLabels && (
        <>
          <Text position={[0, 3.6, 0]} fontSize={0.46} color="#f9a8d4">PMMA denture base</Text>
          <Text position={[0, -2.8, 0]} fontSize={0.42} color="#fef3c7" maxWidth={10}>
            {stage < 0.45 ? "Heat-cure: flask in water bath 74 °C, 8 h" : stage < 0.8 ? "Polymerized! Deflask and polish" : "Midline fracture — repair with self-cure acrylic"}
          </Text>
        </>
      )}
    </group>
  );
}

export function Topic10396Sim(props: SimProps) {
  const stage = Number(props.stage ?? 0.55);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", stage < 0.45 ? "heat-curing" : stage < 0.8 ? "finished ✓" : "repair needed"],
          ["Monomer", "methyl methacrylate"],
          ["Cure", "heat 74 °C · 8 h"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 12]} target={[0, 0.3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.4, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <DentureScene stage={stage} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
