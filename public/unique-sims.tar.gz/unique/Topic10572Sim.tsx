// app/components/sims/unique/Topic10572Sim.tsx
// Osseointegration: biology and biomechanics. A titanium implant sits in
// bone; osteoblast cells migrate to the threads over healing time, and
// chewing-load arrows press on the crown.

"use client";

import { useMemo, useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "heal", label: "Healing time", kind: "slider", min: 0, max: 12, step: 1, default: 6, unit: "wk" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Osseointegration: Biology & Biomechanics",
  blurb: "Bone cells crawl onto the implant threads over weeks while chewing forces test the bond.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

const CELLS = 26;

function Animator({ cells, arrows, elapsed, speed, heal }: {
  cells: RefObject<THREE.InstancedMesh>; arrows: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number; heal: number;
}) {
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (cells.current) {
      const frac = heal / 12;
      for (let i = 0; i < CELLS; i++) {
        const a = (i / CELLS) * Math.PI * 2 + i * 0.7;
        // cells start scattered in bone, migrate to implant threads as weeks pass
        const startR = 2.2 + (i % 5) * 0.3;
        const r = startR + (0.42 - startR) * Math.min(frac * 1.4, 1);
        const y = 1.1 + ((i * 53) % 100) / 100 * 1.6;
        dummy.position.set(Math.cos(a) * r, y, Math.sin(a) * r * 0.6);
        const grow = 0.5 + 0.5 * Math.min(frac * 2, 1);
        dummy.scale.setScalar(0.1 * grow);
        dummy.updateMatrix();
        cells.current.setMatrixAt(i, dummy.matrix);
      }
      cells.current.instanceMatrix.needsUpdate = true;
    }
    if (arrows.current) {
      // chewing load pulses downward
      arrows.current.position.y = -0.25 * Math.abs(Math.sin(t * 2.2));
      arrows.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        ((m as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = 0.35 + 0.45 * Math.abs(Math.sin(t * 2.2 + i * 0.5));
      });
    }
  });
  return null;
}

export function Topic10572Sim(props: SimProps) {
  const heal = Number(props.heal ?? 6);
  const speed = Number(props.speed ?? 1);
  const cells = useRef<THREE.InstancedMesh>(null!);
  const arrows = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const frac = heal / 12;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Healing", `${heal} weeks`],
          ["Bone contact", `${Math.round(Math.min(frac * 140, 95))}%`],
          ["Load", "chewing force ↓"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* bone block */}
        <mesh position={[0, 1.1, 0]} castShadow receiveShadow>
          <boxGeometry args={[7, 2.4, 2.2]} />
          <meshStandardMaterial color="#d9b98a" roughness={0.85} />
        </mesh>
        {/* gum */}
        <mesh position={[0, 2.6, 0]} castShadow>
          <boxGeometry args={[7, 0.5, 2.4]} />
          <meshStandardMaterial color="#f472b6" roughness={0.6} />
        </mesh>

        {/* titanium implant */}
        <group position={[0, 0, 0.4]}>
          <mesh position={[0, 1.55, 0]} castShadow>
            <cylinderGeometry args={[0.3, 0.22, 1.7, 16]} />
            <meshStandardMaterial color="#9ca3af" metalness={0.85} roughness={0.3} />
          </mesh>
          {[0.55, 0.18, -0.19, -0.56].map((dy, i) => (
            <mesh key={i} position={[0, 1.55 + dy, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.29, 0.05, 8, 20]} />
              <meshStandardMaterial color="#d1d5db" metalness={0.85} roughness={0.3} />
            </mesh>
          ))}
          <mesh position={[0, 2.75, 0]} castShadow>
            <cylinderGeometry args={[0.2, 0.26, 0.5, 14]} />
            <meshStandardMaterial color="#e5e7eb" metalness={0.9} roughness={0.25} />
          </mesh>
          {/* crown receiving the load */}
          <mesh position={[0, 3.55, 0]} castShadow>
            <boxGeometry args={[1, 0.85, 1]} />
            <meshStandardMaterial color="#ffffff" roughness={0.25} />
          </mesh>
        </group>

        {/* osteoblast cells migrating to the threads */}
        <instancedMesh ref={cells} args={[undefined, undefined, CELLS]} position={[0, 0, 0.4]}>
          <sphereGeometry args={[1, 12, 12]} />
          <meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={0.7} roughness={0.4} />
        </instancedMesh>

        {/* chewing load arrows */}
        <group ref={arrows} position={[0, 4.9, 0.4]}>
          {[-0.35, 0, 0.35].map((x, i) => (
            <mesh key={i} position={[x, 0, 0]}>
              <coneGeometry args={[0.16, 0.6, 12]} />
              <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={0.8} transparent opacity={0.7} />
            </mesh>
          ))}
        </group>

        <Label p={[-3.1, 1.1, 1.2]} size={0.3} color="#fde68a">bone</Label>
        <Label p={[2.6, 1.9, 1.0]} size={0.3} color="#4ade80">osteoblasts → threads</Label>
        <Label p={[1.8, 4.9, 0.6]} size={0.3} color="#fbbf24">chewing load</Label>
        <Label p={[-2.4, 3.55, 1.2]} size={0.3} color="#ffffff">crown</Label>

        <Animator cells={cells} arrows={arrows} elapsed={elapsed} speed={speed} heal={heal} />
      </SimCanvas>
    </div>
  );
}
