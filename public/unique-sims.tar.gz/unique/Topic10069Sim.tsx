"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "One-Carbon Metabolism",
  blurb: "Folate hands a methyl group to homocysteine, making methionine, with vitamin B12 as the courier.",
};

function Animator({ root, me, hcy, hcym, b12, elapsed, speed }: { root: RefObject<THREE.Group>; me: RefObject<THREE.Mesh>; hcy: RefObject<THREE.Group>; hcym: RefObject<THREE.MeshStandardMaterial>; b12: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const p = (t * 0.28) % 1;
    const lerp = (a: number, b: number, q: number) => a + (b - a) * q;
    let hx = 5, mx = 0, my = 2.15, gold = false;
    if (p < 0.3) { const q = p / 0.3; hx = lerp(5, 1.3, q); }
    else if (p < 0.5) { const q = (p - 0.3) / 0.2; hx = 1.3; mx = lerp(0, 1.3, q); my = lerp(2.15, 1.7, q); gold = true; }
    else if (p < 0.8) { const q = (p - 0.5) / 0.3; hx = lerp(1.3, 6, q); mx = hx; my = 1.7; gold = true; }
    if (hcy.current) hcy.current.position.set(hx, 1.6, 0);
    if (me.current) me.current.position.set(mx, my, 0);
    if (hcym.current) hcym.current.color.set(gold ? "#fbbf24" : "#9ca3af");
    if (b12.current) {
      const ba = t * 1.4;
      b12.current.position.set(Math.cos(ba) * 1.7, 1.6 + Math.sin(t * 2) * 0.15, Math.sin(ba) * 1.7);
      b12.current.rotation.y = t * 2;
    }
  });
  return null;
}

export function Topic10069Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const me = useRef<THREE.Mesh>(null!);
  const hcy = useRef<THREE.Group>(null!);
  const hcym = useRef<THREE.MeshStandardMaterial>(null!);
  const b12 = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Methyl donor", "5-CH\u2083-THF (folate)"],
          ["Enzyme", "methionine synthase"],
          ["Cofactor", "methylcobalamin (B\u2081\u2082)"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 11]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 1.6, 0]} castShadow>
            <cylinderGeometry args={[0.75, 0.75, 0.42, 6]} /><meshStandardMaterial color="#22c55e" roughness={0.5} />
          </mesh>
          <Label text="folate (THF)" position={[0, 0.75, 0]} size={0.42} color="#22c55e" />
          <mesh ref={me} castShadow>
            <sphereGeometry args={[0.26, 16, 16]} /><meshStandardMaterial color="#a855f7" emissive="#7e22ce" emissiveIntensity={0.9} />
          </mesh>
          <Label text="CH\u2083" position={[0, 2.75, 0]} size={0.42} color="#a855f7" />
          <group ref={hcy}>
            <mesh castShadow>
              <capsuleGeometry args={[0.3, 0.7, 6, 12]} />
              <meshStandardMaterial ref={hcym} color="#9ca3af" roughness={0.45} />
            </mesh>
            <Label text="homocysteine \u2192 methionine" position={[0, 0.85, 0]} size={0.4} color="#e2e8f0" />
          </group>
          <mesh ref={b12} castShadow>
            <octahedronGeometry args={[0.42]} /><meshStandardMaterial color="#f472b6" roughness={0.35} metalness={0.2} />
          </mesh>
          <Label text="vitamin B\u2081\u2082" position={[0, 3.6, 0]} size={0.42} color="#f472b6" />
        </group>
        <Animator root={root} me={me} hcy={hcy} hcym={hcym} b12={b12} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
