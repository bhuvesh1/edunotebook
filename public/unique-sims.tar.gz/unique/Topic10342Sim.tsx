"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "rate", label: "Compression rate", kind: "slider", min: 60, max: 130, step: 5, default: 110, unit: "/min" },
  { key: "epi", label: "Epinephrine", kind: "select", min: 0, max: 0, step: 1, default: "off", options: ["off", "given"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "CPR and BLS/ACLS, anaphylaxis management",
  blurb: "Chest compressions at 100–120/min with the heart squeezing in time, plus the epinephrine auto-injector for anaphylaxis.",
};

const SKIN = "#f7c9a8";

function Heart({ beat }: { beat: React.RefObject<number> }) {
  const m = useRef<THREE.Mesh>(null!);
  useFrame(() => {
    if (m.current) {
      const s = 1 + Math.max(0, beat.current) * 0.35;
      m.current.scale.set(s, 2 - s > 0 ? 1 / Math.sqrt(s) : 1, s);
    }
  });
  return (
    <mesh ref={m} position={[0, 2.1, 0.2]} castShadow>
      <sphereGeometry args={[0.62, 24, 18]} />
      <meshStandardMaterial color="#dc2626" roughness={0.35} emissive="#7f1d1d" emissiveIntensity={0.5} />
    </mesh>
  );
}

function CPRScene({ rate, epi, speed, showLabels }: { rate: number; epi: string; speed: number; showLabels: boolean }) {
  const hands = useRef<THREE.Group>(null!);
  const sternum = useRef<THREE.Mesh>(null!);
  const ecg = useRef<THREE.Line | null>(null);
  const beat = useRef(0);
  const elapsed = useRef(0);
  const epiGiven = epi === "given";

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const cps = rate / 60; // compressions per second
    const phase = (t * cps) % 1;
    // compression stroke: quick down, release up
    const down = phase < 0.4 ? Math.sin((phase / 0.4) * Math.PI) : 0;
    if (hands.current) hands.current.position.y = 3.9 - down * 0.85;
    if (sternum.current) sternum.current.position.y = 3.05 - down * 0.55;
    beat.current = down;
    // ECG trace sweep
    if (ecg.current) {
      const pos = ecg.current.geometry.attributes.position;
      for (let i = 0; i < pos.count; i++) {
        const x = -6 + (i / (pos.count - 1)) * 12;
        const waveT = ((t * 2) % 12);
        const d = Math.abs(x - (-6 + waveT));
        const spike = d < 0.6 ? (d < 0.15 ? 1.4 : 0.3) * (1 - d / 0.6) : 0;
        pos.setY(i, 0.15 + spike * (epiGiven ? 1 : 0.6));
      }
      pos.needsUpdate = true;
    }
  });

  return (
    <group>
      {/* torso lying on back */}
      <mesh position={[0, 1.8, 0]} scale={[1.15, 0.62, 1.5]} castShadow receiveShadow>
        <sphereGeometry args={[1.7, 28, 20]} />
        <meshStandardMaterial color={SKIN} roughness={0.65} />
      </mesh>
      {/* sternum plate that depresses */}
      <mesh ref={sternum} position={[0, 3.05, 0]}>
        <boxGeometry args={[0.9, 0.25, 1.6]} />
        <meshStandardMaterial color="#fecaca" roughness={0.6} />
      </mesh>
      {/* ribcage hint */}
      {[-1.2, -0.4, 0.4, 1.2].map((z, i) => (
        <mesh key={i} position={[0, 2.35, z]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <torusGeometry args={[1.35, 0.09, 8, 24, Math.PI]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.5} />
        </mesh>
      ))}
      <Heart beat={beat} />
      {/* rescuer hands stacked, pressing */}
      <group ref={hands} position={[0, 3.9, 0]}>
        <mesh castShadow>
          <boxGeometry args={[1.1, 0.35, 0.9]} />
          <meshStandardMaterial color="#d9a06b" roughness={0.6} />
        </mesh>
        <mesh position={[0, 0.35, 0.1]} rotation={[0.25, 0, 0]} castShadow>
          <boxGeometry args={[1.0, 0.32, 0.8]} />
          <meshStandardMaterial color="#cf9660" roughness={0.6} />
        </mesh>
        {/* arms going up */}
        {[-0.3, 0.3].map((x, i) => (
          <mesh key={i} position={[x, 1.2, 0]} rotation={[0, 0, x * 0.4]} castShadow>
            <cylinderGeometry args={[0.22, 0.26, 2.2, 12]} />
            <meshStandardMaterial color="#d9a06b" roughness={0.6} />
          </mesh>
        ))}
      </group>
      {/* epinephrine auto-injector */}
      <group position={[3.4, 1.2, 1.2]} rotation={[0, 0, epiGiven ? -1.2 : -0.4]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.22, 0.22, 1.6, 14]} />
          <meshStandardMaterial color="#f97316" roughness={0.4} />
        </mesh>
        <mesh position={[0, 0.95, 0]}>
          <cylinderGeometry args={[0.24, 0.24, 0.25, 14]} />
          <meshStandardMaterial color="#1e293b" roughness={0.4} />
        </mesh>
        {epiGiven && (
          <mesh position={[0, -1.1, 0]}>
            <coneGeometry args={[0.1, 0.5, 10]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.3} />
          </mesh>
        )}
      </group>
      <ECGLine ecg={ecg} />
      {showLabels && (
        <>
          <Text position={[-3.6, 2.1, 0]} fontSize={0.42} color="#fecaca">Heart squeezes with each push</Text>
          <Text position={[3.4, 2.8, 1.2]} fontSize={0.4} color="#fdba74">Epinephrine 0.3–0.5 mg IM</Text>
          <Text position={[0, 6.4, 0]} fontSize={0.46} color="#fef3c7">Push hard & fast — 5–6 cm deep</Text>
        </>
      )}
    </group>
  );
}

function ECGLine({ ecg }: { ecg: React.MutableRefObject<THREE.Line | null> }) {
  const lineObj = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(120 * 3), 3));
    return new THREE.Line(g, new THREE.LineBasicMaterial({ color: "#4ade80" }));
  }, []);
  return (
    <group position={[-3.4, 5.2, -1.5]}>
      {/* monitor bezel */}
      <mesh>
        <boxGeometry args={[7.4, 2.4, 0.3]} />
        <meshStandardMaterial color="#1e293b" roughness={0.5} />
      </mesh>
      <mesh position={[0, 0, 0.16]}>
        <planeGeometry args={[7, 2]} />
        <meshBasicMaterial color="#020617" />
      </mesh>
      <primitive
        object={lineObj}
        position={[0, 0, 0.2]}
        ref={(o: THREE.Line | null) => { ecg.current = o; }}
      />
    </group>
  );
}

export function Topic10342Sim(props: SimProps) {
  const rate = Number(props.rate ?? 110);
  const epi = String(props.epi ?? "off");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const inRange = rate >= 100 && rate <= 120;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Rate", `${rate}/min ${inRange ? "✓" : "⚠ target 100–120"}`],
          ["Depth", "5–6 cm"],
          ["Epinephrine", epi === "given" ? "0.5 mg IM ✓" : "not given"],
        ]}
      />
      <SimCanvas cameraPosition={[7, 5, 10]} target={[0, 2.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.4, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <CPRScene rate={rate} epi={epi} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
