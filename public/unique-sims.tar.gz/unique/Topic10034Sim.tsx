// Blood: platelets, hemostasis, coagulation, blood groups — a cut vessel where
// platelets swarm to form a plug, a fibrin mesh weaves over it, and an RBC
// wears the selected blood-group antigens.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "injury", label: "Injury size", kind: "slider", min: 0.2, max: 1.5, step: 0.05, default: 1, unit: "×" },
  { key: "group", label: "Blood group", kind: "select", min: 0, max: 0, step: 1, default: "A", options: ["A", "B", "AB", "O"] },
];

export const UNIQUE_META = {
  title: "Blood: Clotting & Blood Groups",
  blurb: "Platelets swarm a cut vessel, fibrin weaves a clot — and an RBC shows the selected blood-group antigens.",
};

const GROUPS: Record<string, { antigens: string[]; donor: string }> = {
  A: { antigens: ["A"], donor: "A, O" },
  B: { antigens: ["B"], donor: "B, O" },
  AB: { antigens: ["A", "B"], donor: "AB, A, B, O" },
  O: { antigens: [], donor: "O only" },
};

function Animator({
  platelets, fibrin, plug, elapsed, injury, speed,
}: {
  platelets: React.RefObject<THREE.Group>;
  fibrin: React.RefObject<THREE.Group>;
  plug: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  injury: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // platelets swarm toward the cut at x=-2.5, y=3.2
    if (platelets.current) {
      platelets.current.children.forEach((m, i) => {
        const ph = ((t * 0.4 + i / 10) % 1 + 1) % 1;
        const sx = -7 + (i % 5) * 0.6;
        const sy = 1.5 + (i % 4) * 0.7;
        m.position.x = sx + (-2.5 - sx) * Math.min(1, ph * 1.6);
        m.position.y = sy + (3.1 - sy) * Math.min(1, ph * 1.6);
        m.rotation.x += delta * 4;
      });
    }
    // fibrin threads fade in over the plug
    if (fibrin.current) {
      const on = 0.45 + 0.4 * Math.sin(t * 1.2);
      fibrin.current.children.forEach((m) => {
        const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
        mat.opacity = on;
      });
    }
    if (plug.current) {
      const s = 1 + 0.05 * Math.sin(t * 5);
      plug.current.scale.setScalar(s);
    }
  });
  return null;
}

export function Topic10034Sim(props: SimProps) {
  const injury = Number(props.injury ?? 1);
  const group = String(props.group ?? "A");
  const speed = 1;
  const platelets = useRef<THREE.Group>(null!);
  const fibrin = useRef<THREE.Group>(null!);
  const plug = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = GROUPS[group] ?? GROUPS.A;

  const fibrinThreads = useMemo(
    () =>
      Array.from({ length: 10 }).map((_, i) => ({
        x: -2.5 + ((i * 1.7) % 3 - 1.5) * 0.8,
        y: 3.1 + ((i * 2.3) % 3 - 1) * 0.35,
        rot: (i * 0.9) % 1.4 - 0.7,
      })),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Hemostasis", "plug → fibrin clot"],
          [`Group ${group} can receive from`, info.donor],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* cut vessel */}
        <group position={[-2.5, 2.2, 0]}>
          <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
            <cylinderGeometry args={[1.3, 1.3, 9, 20, 1, true]} />
            <meshStandardMaterial color="#991b1b" roughness={0.5} side={THREE.DoubleSide} transparent opacity={0.6} />
          </mesh>
          {/* the cut: glowing gash */}
          <mesh position={[0, 1.15, 0]} scale={[injury, 1, 1]}>
            <boxGeometry args={[1.4, 0.3, 0.9]} />
            <meshBasicMaterial color="#fef08a" />
          </mesh>
        </group>
        {/* platelet plug forming at the cut */}
        <group ref={plug} position={[-2.5, 3.25, 0]}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i}
              position={[((i * 1.3) % 3 - 1) * 0.5 * injury, ((i * 2.1) % 3 - 1) * 0.22, ((i * 0.7) % 2 - 0.5) * 0.5]}
              scale={[1.3, 0.5, 1]} castShadow>
              <sphereGeometry args={[0.2, 10, 10]} />
              <meshStandardMaterial color="#fbbf24" roughness={0.5} />
            </mesh>
          ))}
        </group>
        {/* fibrin mesh */}
        <group ref={fibrin}>
          {fibrinThreads.map((f, i) => (
            <mesh key={i} position={[f.x, f.y, 0]} rotation={[0, 0, f.rot]}>
              <cylinderGeometry args={[0.035, 0.035, 1.6 * injury, 6]} />
              <meshStandardMaterial color="#fef9c3" transparent opacity={0.6} roughness={0.6} />
            </mesh>
          ))}
        </group>
        {/* free platelets swarming in */}
        <group ref={platelets}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i} position={[-7, 2, 0]} scale={[1.3, 0.5, 1]}>
              <sphereGeometry args={[0.16, 10, 10]} />
              <meshStandardMaterial color="#fde68a" roughness={0.5} />
            </mesh>
          ))}
        </group>
        <Label text="cut vessel" position={[-2.5, 4.7, 0]} size={0.4} color="#f8fafc" />
        <Label text="platelet plug" position={[-4.6, 3.5, 0]} size={0.32} color="#fde68a" />
        <Label text="fibrin mesh" position={[-0.6, 2.5, 0]} size={0.32} color="#fef9c3" />

        {/* blood group RBC with antigens */}
        <group position={[5.6, 2.2, 0]}>
          <mesh scale={[1, 0.42, 1]} castShadow>
            <sphereGeometry args={[1.0, 22, 22]} />
            <meshStandardMaterial color="#dc2626" roughness={0.4} />
          </mesh>
          {info.antigens.map((ag, i) => (
            <group key={ag} position={[(i - (info.antigens.length - 1) / 2) * 0.9, 0.55, 0]}>
              <mesh castShadow>
                <sphereGeometry args={[0.22, 10, 10]} />
                <meshStandardMaterial color={ag === "A" ? "#4ade80" : "#38bdf8"} roughness={0.4} />
              </mesh>
              <Label text={ag} position={[0, 0.5, 0]} size={0.34} color="#f8fafc" />
            </group>
          ))}
          {info.antigens.length === 0 && (
            <Label text="no A/B antigens (H only)" position={[0, 0.8, 0]} size={0.3} color="#fca5a5" />
          )}
        </group>
        <Label text={`blood group ${group} RBC`} position={[5.6, 4.0, 0]} size={0.4} color="#f8fafc" />
        <Label text={`antibodies in plasma: ${group === "AB" ? "none" : group === "O" ? "anti-A, anti-B" : group === "A" ? "anti-B" : "anti-A"}`}
          position={[5.6, 0.75, 0]} size={0.3} color="#fca5a5" />

        <Animator platelets={platelets} fibrin={fibrin} plug={plug} elapsed={elapsed} injury={injury} speed={speed} />
      </SimCanvas>
    </div>
  );
}
