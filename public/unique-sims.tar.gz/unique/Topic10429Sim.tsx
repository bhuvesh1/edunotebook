"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "vdo", label: "Vertical dimension", kind: "slider", min: -1, max: 1, step: 0.1, default: 0, unit: "mm" },
  { key: "relation", label: "Jaw relation", kind: "select", min: 0, max: 0, step: 1, default: "centric", options: ["centric", "protrusive", "lateral"] },
];

export const UNIQUE_META = {
  title: "Complete dentures: jaw relations — vertical and centric",
  blurb: "Upper and lower denture bases with wax rims — slide the vertical dimension and watch the jaw find centric relation.",
};

function Scene({ vdo, relation }: { vdo: number; relation: string }) {
  const lower = useRef<THREE.Group>(null!);
  const t = useRef(0);

  const offset: [number, number] = relation === "centric" ? [0, 0] : relation === "protrusive" ? [0, 0.7] : [0.55, 0.2];

  useFrame((_, delta) => {
    t.current += delta;
    if (lower.current) {
      // gentle chewing to demonstrate the relation
      const chew = Math.sin(t.current * 1.6) * 0.06;
      lower.current.position.set(offset[0], -0.9 + vdo * 0.5 + chew, offset[1]);
    }
  });

  return (
    <group>
      {/* upper base + occlusal rim */}
      <group position={[0, 1.2, 0]}>
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[2.0, 0.45, 14, 36, Math.PI]} />
          <meshStandardMaterial color="#f472b6" roughness={0.5} />
        </mesh>
        <mesh position={[0, -0.55, 0.35]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[2.0, 0.28, 12, 36, Math.PI]} />
          <meshStandardMaterial color="#fde68a" roughness={0.6} />
        </mesh>
        <Label text="Upper rim" position={[-2.9, 0, 0]} size={0.42} color="#f9a8d4" />
      </group>

      {/* lower base + rim (moves) */}
      <group ref={lower}>
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[2.0, 0.45, 14, 36, Math.PI]} />
          <meshStandardMaterial color="#f472b6" roughness={0.5} />
        </mesh>
        <mesh position={[0, 0.55, -0.35]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[2.0, 0.28, 12, 36, Math.PI]} />
          <meshStandardMaterial color="#fde68a" roughness={0.6} />
        </mesh>
        <Label text="Lower rim" position={[2.9, 0, 0]} size={0.42} color="#f9a8d4" />
      </group>

      {/* vertical dimension arrow */}
      <group position={[3.4, 0.15, 0]}>
        <mesh position={[0, 0.75, 0]}>
          <coneGeometry args={[0.14, 0.3, 10]} />
          <meshStandardMaterial color="#38bdf8" emissive="#38bdf8" emissiveIntensity={0.6} />
        </mesh>
        <mesh position={[0, -0.75, 0]} rotation={[Math.PI, 0, 0]}>
          <coneGeometry args={[0.14, 0.3, 10]} />
          <meshStandardMaterial color="#38bdf8" emissive="#38bdf8" emissiveIntensity={0.6} />
        </mesh>
        <mesh>
          <cylinderGeometry args={[0.05, 0.05, 1.3, 8]} />
          <meshStandardMaterial color="#38bdf8" emissive="#38bdf8" emissiveIntensity={0.6} />
        </mesh>
        <Label text={`VDO ${vdo >= 0 ? "+" : ""}${vdo.toFixed(1)}`} position={[0, 1.35, 0]} size={0.42} color="#7dd3fc" />
      </group>
      {/* nose / chin markers */}
      <mesh position={[0, 3.1, 1.6]}>
        <sphereGeometry args={[0.12, 10, 10]} />
        <meshStandardMaterial color="#f2c9a0" roughness={0.6} />
      </mesh>
      <Label text="Nose tip" position={[0.9, 3.1, 1.6]} size={0.36} color="#e2e8f0" />
      <mesh position={[0, -1.9, 1.6]}>
        <sphereGeometry args={[0.12, 10, 10]} />
        <meshStandardMaterial color="#f2c9a0" roughness={0.6} />
      </mesh>
      <Label text="Chin" position={[0.9, -1.9, 1.6]} size={0.36} color="#e2e8f0" />

      <Label text={`Jaw relation: ${relation}`} position={[0, 4.0, 0]} size={0.6} color="#fde68a" />
      <Label text={relation === "centric" ? "Centric relation — most stable, repeatable" : "Eccentric — rims glide, check contacts"} position={[0, -2.9, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10429Sim(props: SimProps) {
  const vdo = Number(props.vdo ?? 0);
  const relation = String(props.relation ?? "centric");
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["VDO", `${vdo >= 0 ? "+" : ""}${vdo.toFixed(1)} mm`], ["Relation", relation], ["Freeway space", "2–4 mm at rest"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, 0.4, 0]}>
        <Scene vdo={vdo} relation={relation} />
      </SimCanvas>
    </div>
  );
}
