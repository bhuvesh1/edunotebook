"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "gland", label: "Gland", kind: "select", min: 0, max: 0, step: 1, default: "parotid", options: ["parotid", "submandibular", "sublingual"] },
  { key: "disease", label: "Disease", kind: "select", min: 0, max: 0, step: 1, default: "sialadenitis", options: ["sialadenitis", "stone", "tumor"] },
];

export const UNIQUE_META = {
  title: "Salivary gland diseases: sialadenitis, benign and malignant tumors",
  blurb: "The three major salivary glands with saliva flow — inflamed, blocked by a stone, or swollen by a tumour.",
};

const GLANDS: Record<string, { name: string; pos: [number, number, number]; duct: [number, number, number][] }> = {
  parotid: { name: "Parotid gland", pos: [-2.6, 1.2, 0], duct: [[-2.6, 1.2, 0], [-1.4, 0.8, 0.6], [-0.4, 0.6, 0.9]] },
  submandibular: { name: "Submandibular gland", pos: [-1.2, -1.6, 0.9], duct: [[-1.2, -1.6, 0.9], [-0.5, -0.8, 1], [0, -0.2, 1]] },
  sublingual: { name: "Sublingual gland", pos: [0.6, -0.9, 1.2], duct: [[0.6, -0.9, 1.2], [0.6, -0.4, 1.2]] },
};

const DISEASES: Record<string, { name: string; note: string; color: string }> = {
  sialadenitis: { name: "Sialadenitis", note: "Painful swollen infected gland", color: "#ef4444" },
  stone: { name: "Sialolithiasis (stone)", note: "Stone blocks the duct — swelling at mealtimes", color: "#fbbf24" },
  tumor: { name: "Tumour (pleomorphic adenoma)", note: "Painless slow-growing lump", color: "#a78bfa" },
};

function SalivaFlow({ duct, blocked, blockedAt }: { duct: [number, number, number][]; blocked: boolean; blockedAt: number }) {
  const pts = useRef<THREE.Points>(null!);
  const t = useRef(Math.random() * 5);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(16 * 3), 3));
    return g;
  }, []);
  const curve = useMemo(() => new THREE.CatmullRomCurve3(duct.map((p) => new THREE.Vector3(...p))), [duct]);
  useFrame((_, delta) => {
    t.current += delta * 0.8;
    if (!pts.current) return;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < 16; i++) {
      const f = (t.current * 0.5 + i / 16) % 1;
      const p = curve.getPoint(blocked ? Math.min(f, blockedAt) : f);
      pos.setXYZ(i, p.x, p.y, p.z);
    }
    pos.needsUpdate = true;
  });
  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial color="#7dd3fc" size={0.13} transparent opacity={0.95} />
    </points>
  );
}

function Scene({ gland, disease }: { gland: string; disease: string }) {
  const t = useRef(0);
  const inflamed = useRef<THREE.Mesh>(null!);
  const g = GLANDS[gland] ?? GLANDS.parotid;
  const d = DISEASES[disease] ?? DISEASES.sialadenitis;
  const isStone = disease === "stone";
  const isTumor = disease === "tumor";

  useFrame((_, delta) => {
    t.current += delta;
    if (inflamed.current && disease === "sialadenitis") {
      inflamed.current.scale.setScalar(1 + Math.sin(t.current * 4) * 0.07);
    }
  });

  const curve = useMemo(() => new THREE.CatmullRomCurve3(g.duct.map((p) => new THREE.Vector3(...p))), [g]);

  return (
    <group>
      {/* jaw hint */}
      <mesh position={[0.4, -0.2, -0.6]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[2.4, 0.7, 14, 32, Math.PI]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} transparent opacity={0.85} />
      </mesh>

      {Object.entries(GLANDS).map(([key, gg]) => {
        const activeG = key === gland;
        return (
          <group key={key} position={gg.pos}>
            <mesh ref={activeG && disease === "sialadenitis" ? inflamed : undefined}>
              <sphereGeometry args={[activeG ? 0.75 : 0.5, 18, 18]} />
              <meshStandardMaterial
                color={activeG ? (disease === "sialadenitis" ? "#ef4444" : "#eab308") : "#d4a574"}
                roughness={0.55}
                transparent={!activeG}
                opacity={activeG ? 1 : 0.55}
              />
            </mesh>
            {activeG && isTumor && (
              <mesh position={[0.3, 0.3, 0.2]}>
                <sphereGeometry args={[0.45, 16, 16]} />
                <meshStandardMaterial color="#a78bfa" roughness={0.4} />
              </mesh>
            )}
            <Label text={gg.name} position={[0, 1.05, 0]} size={0.45} color={activeG ? "#fde68a" : "#94a3b8"} />
          </group>
        );
      })}

      {/* duct tube */}
      <mesh>
        <tubeGeometry args={[curve, 24, 0.09, 10, false]} />
        <meshStandardMaterial color="#93c5fd" transparent opacity={0.55} roughness={0.3} />
      </mesh>
      <SalivaFlow duct={g.duct} blocked={isStone} blockedAt={0.55} />

      {/* stone blocking duct */}
      {isStone && (
        <group position={curve.getPoint(0.55).toArray()}>
          <mesh>
            <dodecahedronGeometry args={[0.28, 0]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.35} flatShading />
          </mesh>
          <Label text="Stone" position={[0, 0.6, 0]} size={0.45} color="#fbbf24" />
          {/* backed-up swelling */}
          <mesh position={[-0.15, 0.15, 0]}>
            <sphereGeometry args={[0.42, 14, 14]} />
            <meshStandardMaterial color="#7dd3fc" transparent opacity={0.5} roughness={0.3} />
          </mesh>
        </group>
      )}

      <Label text={d.name} position={[0, 3.2, 0]} size={0.65} color={d.color} />
      <Label text={d.note} position={[0, -2.9, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10410Sim(props: SimProps) {
  const gland = String(props.gland ?? "parotid");
  const disease = String(props.disease ?? "sialadenitis");
  const d = DISEASES[disease] ?? DISEASES.sialadenitis;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Gland", (GLANDS[gland] ?? GLANDS.parotid).name], ["Disease", d.name], ["Saliva flow", disease === "stone" ? "Blocked" : "Reduced"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, 0, 0]}>
        <Scene gland={gland} disease={disease} />
      </SimCanvas>
    </div>
  );
}
