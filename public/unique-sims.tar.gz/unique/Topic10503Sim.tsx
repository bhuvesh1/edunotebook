"use client";
// Le Fort Fractures of the Midface — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "frac", label: "Fracture", kind: "select", min: 0, max: 0, step: 1, default: "Le Fort I", options: ["Le Fort I", "Le Fort II", "Le Fort III"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Le Fort Fractures of the Midface",
  blurb: "Three classic break lines across the face — Le Fort I, II or III — and the whole segment shifts.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const lines = [["lf1", "Le Fort I"], ["lf2", "Le Fort II"], ["lf3", "Le Fort III"]];
    lines.forEach(([nm]: any, i: number) => {
      const m: any = g(nm);
      if (m) {
        const on = p.frac === lines[i][1];
        (m.material as any).opacity = on ? 0.85 + 0.15 * Math.sin(t * 4) : 0.18;
      }
    });
    const mid: any = g("midface");
    if (mid) {
      const amt = p.frac === "Le Fort I" ? 0.35 : p.frac === "Le Fort II" ? 0.55 : 0.75;
      mid.position.y = 2.5 - amt * (0.5 + 0.5 * Math.sin(t * 1.2)) * 0.5;
      mid.position.z = amt * (0.5 + 0.5 * Math.sin(t * 1.2)) * 0.35;
    }
  });
  return null;
}

export function Topic10503Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const frac = String(props.frac ?? "Le Fort I");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, frac };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Level", frac],
          ["I", "Above teeth (Guerin)"],
          ["II", "Pyramidal, through nose"],
          ["III", "Craniofacial split"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <mesh position={[0, 4.6, 0]}>
            <sphereGeometry args={[1.5, 24, 24]} />
            <meshStandardMaterial color="#e8e0cf" roughness={0.6} />
          </mesh>
          <group name="midface" position={[0, 2.5, 0]}>
            <mesh position={[0, 0.3, 0.3]}>
              <boxGeometry args={[2, 1.4, 1.4]} />
              <meshStandardMaterial color="#ded3ba" roughness={0.6} />
            </mesh>
            {[-0.6, 0.6].map((x, i) => (
              <mesh key={i} position={[x, 0.5, 1.05]}>
                <sphereGeometry args={[0.22, 12, 12]} />
                <meshStandardMaterial color="#1e293b" roughness={0.3} />
              </mesh>
            ))}
            {[-0.75, -0.25, 0.25, 0.75].map((x, i) => (
              <mesh key={i} position={[x, -0.55, 0.3]}>
                <boxGeometry args={[0.4, 0.5, 0.4]} />
                <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
              </mesh>
            ))}
          </group>
          <mesh name="lf1" position={[0, 2.35, 0.3]}>
            <boxGeometry args={[2.4, 0.09, 1.7]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" transparent opacity={0.2} />
          </mesh>
          <mesh name="lf2" position={[0, 3.1, 0.3]} rotation={[0, 0, 0]}>
            <boxGeometry args={[1.7, 0.09, 1.5]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" transparent opacity={0.2} />
          </mesh>
          <mesh name="lf3" position={[0, 4.1, 0]}>
            <boxGeometry args={[2.9, 0.09, 2.2]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" transparent opacity={0.2} />
          </mesh>
          <Label text="Le Fort I — low" position={[2.6, 2.35, 0.3]} size={0.4} />
          <Label text="Le Fort II — pyramidal" position={[2.6, 3.1, 0.3]} size={0.4} />
          <Label text="Le Fort III — high" position={[2.7, 4.1, 0]} size={0.4} />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
