// Beta-lactam antibiotics: the drug molecules latch onto a bacterium's cell
// wall, crack it open, and the bacterium bursts.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Antibiotic dose", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Beta-lactam antibiotics",
  blurb: "Antibiotic molecules crack the bacterial cell wall open — and the bacterium bursts.",
};

const N_ABX = 10;

function Animator({ wall, inner, abx, frags, elapsed, dose, setTick }: {
  wall: React.RefObject<THREE.Mesh>;
  inner: React.RefObject<THREE.Mesh>;
  abx: React.RefObject<(THREE.Mesh | null)[]>;
  frags: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  dose: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    // damage accumulates with dose, then the wall ruptures on a loop
    const cyc = (t * (0.12 + k * 0.25)) % 1;
    const damage = Math.min(1, cyc * (0.4 + k * 1.6));
    const burst = damage >= 1 ? Math.min(1, (cyc - 1 / (0.4 + k * 1.6)) * 8 + 0.2) : 0;
    if (wall.current) {
      const w = wall.current.material as THREE.MeshStandardMaterial;
      w.opacity = 0.95 - damage * 0.9;
      wall.current.scale.setScalar(1 + burst * 0.6);
    }
    if (inner.current) {
      inner.current.scale.setScalar(Math.max(0.05, 1 - burst * 1.1));
      (inner.current.material as THREE.MeshStandardMaterial).opacity = Math.max(0, 0.95 - burst * 1.2);
    }
    abx.current.forEach((a, i) => {
      if (!a) return;
      const ang = (i / N_ABX) * Math.PI * 2 + t * 0.6;
      const r = 3.2 - damage * 1.4;
      a.position.set(Math.cos(ang) * r, 1.6 + Math.sin(t * 2 + i) * 0.3, Math.sin(ang) * r * 0.7);
      a.rotation.y = t * 3 + i;
    });
    frags.current.forEach((f, i) => {
      if (!f) return;
      f.visible = burst > 0;
      if (burst > 0) {
        const ang = (i / 8) * Math.PI * 2;
        f.position.set(Math.cos(ang) * burst * 2.4, 1.6 + Math.sin(ang * 2) * burst * 1.2, Math.sin(ang) * burst * 1.6);
        ((f as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = Math.max(0, 1 - burst * 1.1);
      }
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(damage * 100)); }
  });
  return null;
}

export function Topic10117Sim(props: SimProps) {
  const dose = Number(props.dose ?? 60);
  const showLabels = String(props.detail ?? "on") === "on";
  const wall = useRef<THREE.Mesh>(null!);
  const inner = useRef<THREE.Mesh>(null!);
  const abx = useRef<(THREE.Mesh | null)[]>([]);
  const frags = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Cell-wall damage", `${tick}%`],
          ["Bacterium", tick >= 100 ? "burst!" : "under attack"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 11]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* bacterium: inner cell + outer wall shell */}
        <mesh ref={inner} position={[0, 1.6, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <capsuleGeometry args={[1.0, 1.6, 8, 20]} />
          <meshStandardMaterial color="#4ade80" roughness={0.5} transparent />
        </mesh>
        <mesh ref={wall} position={[0, 1.6, 0]} rotation={[0, 0, Math.PI / 2]}>
          <capsuleGeometry args={[1.18, 1.6, 8, 20]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.4} transparent opacity={0.95} side={THREE.DoubleSide} />
        </mesh>
        {showLabels && <Label text="cell wall" position={[0, 3.5, 0]} color="#fde047" />}
        {showLabels && <Label text="bacterium" position={[0, -0.2, 0]} color="#86efac" />}

        {/* beta-lactam antibiotic molecules */}
        {Array.from({ length: N_ABX }).map((_, i) => (
          <mesh key={i} ref={(m) => { abx.current[i] = m; }} castShadow>
            <boxGeometry args={[0.3, 0.3, 0.3]} />
            <meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={0.9} />
          </mesh>
        ))}
        {showLabels && <Label text="beta-lactam antibiotic" position={[3.6, 2.9, 0]} size={0.45} color="#7dd3fc" />}

        {/* burst fragments */}
        {Array.from({ length: 8 }).map((_, i) => (
          <mesh key={`f${i}`} ref={(m) => { frags.current[i] = m; }} visible={false}>
            <tetrahedronGeometry args={[0.22]} />
            <meshStandardMaterial color="#4ade80" transparent />
          </mesh>
        ))}

        <Animator wall={wall} inner={inner} abx={abx} frags={frags} elapsed={elapsed} dose={dose} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
