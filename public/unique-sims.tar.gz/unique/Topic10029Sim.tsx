// Embryology: nervous system, eye, ear — the neural tube with an optic vesicle
// ballooning out and invaginating into the optic cup, plus the otic vesicle.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Development stage", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.6, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Embryology: Eye & Ear from Neural Tube",
  blurb: "The optic vesicle balloons out and folds into the optic cup while the otic vesicle forms the inner ear.",
};

function Animator({
  tube, lens, elapsed, speed,
}: {
  tube: React.RefObject<THREE.Group>;
  lens: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (tube.current) tube.current.rotation.y = Math.sin(t * 0.4) * 0.25;
    if (lens.current) {
      const s = 1 + 0.08 * Math.sin(t * 3);
      lens.current.scale.setScalar(s);
    }
  });
  return null;
}

export function Topic10029Sim(props: SimProps) {
  const stage = Number(props.stage ?? 0.6);
  const speed = Number(props.speed ?? 1);
  const tube = useRef<THREE.Group>(null!);
  const lens = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  // optic cup depth grows with stage; lens sinks in as the cup deepens
  const cupDepth = 0.25 + stage * 0.75;
  const lensY = 2.5 - stage * 0.55;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Optic cup", `${Math.round(stage * 100)}% formed`],
          ["Derives from", "neuroectoderm"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 6, 14.5]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={tube}>
          {/* neural tube: forebrain vesicles */}
          <mesh position={[0, 2.5, -2.6]} castShadow>
            <sphereGeometry args={[1.1, 20, 20]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.45} />
          </mesh>
          <mesh position={[0, 1.7, -0.6]} rotation={[Math.PI / 2.4, 0, 0]} castShadow>
            <cylinderGeometry args={[0.5, 0.62, 3.4, 16]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.45} />
          </mesh>
          <Label text="neural tube (forebrain)" position={[0, 4.15, -2.6]} size={0.36} color="#f8fafc" />

          {/* optic stalk + vesicle -> cup on each side */}
          {[-1, 1].map((s) => (
            <group key={s} position={[s * 1.6, 2.5, -2.2]}>
              {/* optic stalk */}
              <mesh position={[-s * 0.7, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
                <cylinderGeometry args={[0.16, 0.2, 1.3, 10]} />
                <meshStandardMaterial color="#0ea5e9" roughness={0.45} />
              </mesh>
              {/* optic cup: sphere that invaginates with stage */}
              <mesh castShadow scale={[1, 1, 1 - cupDepth * 0.45]}>
                <sphereGeometry args={[0.85, 22, 22, 0, Math.PI * 2, 0, Math.PI * (0.62 + stage * 0.3)]} />
                <meshStandardMaterial color="#7dd3fc" roughness={0.35} side={THREE.DoubleSide} />
              </mesh>
              {/* inner neural retina layer */}
              <mesh scale={[0.82, 0.82, 0.82 * (1 - cupDepth * 0.3)]}>
                <sphereGeometry args={[0.85, 18, 18, 0, Math.PI * 2, 0, Math.PI * (0.55 + stage * 0.28)]} />
                <meshStandardMaterial color="#f97316" roughness={0.4} side={THREE.DoubleSide} />
              </mesh>
              {/* lens placode sinking in */}
              <mesh ref={s === -1 ? lens : undefined} position={[s * 0.4, lensY - 2.5, 0.75]}>
                <sphereGeometry args={[0.34, 14, 14]} />
                <meshStandardMaterial color="#e0f2fe" transparent opacity={0.85} roughness={0.15} />
              </mesh>
              <Label text={s === -1 ? "optic cup" : ""} position={[s * 1.6, 3.9, -2.2]} size={0.32} color="#7dd3fc" />
              <Label text={s === 1 ? "lens placode" : ""} position={[s * 1.6 + 1.6, lensY + 0.7, -1.4]} size={0.3} color="#e0f2fe" />
            </group>
          ))}
          <Label text="optic stalk" position={[-3.4, 1.9, -2.2]} size={0.3} color="#7dd3fc" />

          {/* otic vesicle (inner ear) */}
          <group position={[0, 1.9, 1.8]}>
            <mesh castShadow>
              <sphereGeometry args={[0.55, 16, 16]} />
              <meshStandardMaterial color="#c084fc" transparent opacity={0.8} roughness={0.35} />
            </mesh>
            {/* semicircular canal hint */}
            <mesh rotation={[0, Math.PI / 2.4, 0]}>
              <torusGeometry args={[0.34, 0.08, 8, 18]} />
              <meshStandardMaterial color="#a855f7" roughness={0.4} />
            </mesh>
          </group>
          <Label text="otic vesicle (inner ear)" position={[0, 3.0, 2.6]} size={0.34} color="#f8fafc" />
          <Label text="neural retina (inner layer)" position={[3.6, 1.5, -2.2]} size={0.28} color="#fb923c" />
        </group>

        <Animator tube={tube} lens={lens} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
