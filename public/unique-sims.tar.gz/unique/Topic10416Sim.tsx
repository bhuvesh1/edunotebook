"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "route", label: "Route", kind: "select", min: 0, max: 0, step: 1, default: "oral", options: ["oral", "im", "iv"] },
  { key: "dose", label: "Dose", kind: "slider", min: 50, max: 500, step: 50, default: 250, unit: "mg" },
];

export const UNIQUE_META = {
  title: "General pharmacology principles for dental practice",
  blurb: "A capsule dissolves and drug molecules ride the bloodstream — watch absorption, peak and elimination change with the route.",
};

const ROUTES: Record<string, { name: string; onset: number; peak: number; note: string }> = {
  oral: { name: "Oral", onset: 0.35, peak: 0.55, note: "Slow rise — first-pass metabolism" },
  im: { name: "Intramuscular", onset: 0.6, peak: 0.8, note: "Faster — depot in muscle" },
  iv: { name: "Intravenous", onset: 1.0, peak: 1.0, note: "Instant peak — 100% bioavailable" },
};

function MoleculeStream({ speed, count }: { speed: number; count: number }) {
  const pts = useRef<THREE.Points>(null!);
  const t = useRef(Math.random() * 10);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(40 * 3), 3));
    return g;
  }, []);
  useFrame((_, delta) => {
    t.current += delta * speed;
    if (!pts.current) return;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < 40; i++) {
      const f = (t.current * 0.35 + i / 40) % 1;
      const a = f * Math.PI * 6;
      pos.setXYZ(i, -4.5 + f * 9, Math.cos(a) * 0.45, Math.sin(a) * 0.45);
      (pts.current.material as THREE.PointsMaterial).opacity = i < count ? 0.95 : 0.08;
    }
    pos.needsUpdate = true;
  });
  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial color="#fbbf24" size={0.16} transparent />
    </points>
  );
}

function Curve({ onset, peak }: { onset: number; peak: number }) {
  const line = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 60; i++) {
      const x = i / 60;
      const rise = Math.min(1, x / (0.25 / onset + 0.05));
      const y = Math.pow(rise, 1.5) * Math.exp(-(x - 0.25) * 2.2) * peak;
      pts.push(new THREE.Vector3(-3 + x * 6, 0.4 + Math.max(0, y) * 2.4, 0));
    }
    return new THREE.Line(
      new THREE.BufferGeometry().setFromPoints(pts),
      new THREE.LineBasicMaterial({ color: "#38bdf8", linewidth: 2 })
    );
  }, [onset, peak]);
  return <primitive object={line} />;
}

function Scene({ route, dose }: { route: string; dose: number }) {
  const cap = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const r = ROUTES[route] ?? ROUTES.oral;
  const count = Math.round(8 + (dose / 500) * 32);

  useFrame((_, delta) => {
    t.current += delta;
    if (cap.current) {
      cap.current.rotation.y = t.current * 0.8;
      const s = Math.max(0.25, 1 - (t.current % 6) / 6);
      cap.current.scale.setScalar(s);
    }
  });

  return (
    <group>
      {/* blood vessel */}
      <mesh rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.75, 0.75, 9.5, 20, 1, true]} />
        <meshStandardMaterial color="#b91c1c" transparent opacity={0.35} roughness={0.3} side={THREE.DoubleSide} />
      </mesh>
      <mesh rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.6, 0.6, 9.5, 16]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.6} />
      </mesh>
      <Label text="Bloodstream" position={[0, 1.3, 0]} size={0.45} color="#fca5a5" />
      <MoleculeStream speed={0.5 + r.onset} count={count} />

      {/* dissolving capsule */}
      <group ref={cap} position={[-3.4, 2.2, 0]}>
        <mesh position={[-0.22, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.28, 0.28, 0.45, 14]} />
          <meshStandardMaterial color="#f472b6" roughness={0.4} />
        </mesh>
        <mesh position={[0.22, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.28, 0.28, 0.45, 14]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.4} />
        </mesh>
      </group>
      <Label text="Capsule dissolving" position={[-3.4, 3.1, 0]} size={0.45} color="#f9a8d4" />

      {/* concentration-time curve */}
      <group position={[0, -2.2, 0]}>
        <mesh position={[0, 0.35, 0]}>
          <boxGeometry args={[6.4, 0.06, 0.06]} />
          <meshStandardMaterial color="#64748b" />
        </mesh>
        <mesh position={[-3.2, 1.5, 0]}>
          <boxGeometry args={[0.06, 3, 0.06]} />
          <meshStandardMaterial color="#64748b" />
        </mesh>
        <Curve onset={r.onset} peak={r.peak} />
        <Label text="Drug level in blood over time" position={[0, -0.35, 0]} size={0.45} color="#38bdf8" />
        <Label text={r.note} position={[0, -1.0, 0]} size={0.4} color="#94a3b8" />
      </group>
      <Label text={`${r.name} — ${dose} mg`} position={[0, 3.6, 0]} size={0.6} color="#fde68a" />
    </group>
  );
}

export function Topic10416Sim(props: SimProps) {
  const route = String(props.route ?? "oral");
  const dose = Number(props.dose ?? 250);
  const r = ROUTES[route] ?? ROUTES.oral;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Route", r.name], ["Dose", `${dose} mg`], ["Onset", route === "iv" ? "Immediate" : route === "im" ? "15–30 min" : "30–60 min"]]} />
      <SimCanvas cameraPosition={[0, 2, 11]} target={[0, 0.3, 0]}>
        <Scene route={route} dose={dose} />
      </SimCanvas>
    </div>
  );
}
