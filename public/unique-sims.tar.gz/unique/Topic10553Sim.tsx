// app/components/sims/unique/Topic10553Sim.tsx
// Dental manpower: auxiliaries — the dentist, the dental hygienist, and the
// dental technician, each with their signature tool. Select a role to
// spotlight them.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "role", label: "Team member", kind: "select", min: 0, max: 0, step: 1, default: "dentist", options: ["dentist", "hygienist", "technician"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Dental Manpower: Auxiliaries",
  blurb: "Meet the dental team: dentist, hygienist, and technician — each with their tools and their job.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Person({ x, coat, skin, tool }: { x: number; coat: string; skin: string; tool: ReactNode }) {
  return (
    <group position={[x, 0, 0]}>
      {/* legs */}
      <mesh position={[0, 0.6, 0]} castShadow>
        <boxGeometry args={[0.7, 1.2, 0.6]} />
        <meshStandardMaterial color="#1e293b" roughness={0.7} />
      </mesh>
      {/* coat */}
      <mesh position={[0, 1.8, 0]} castShadow>
        <boxGeometry args={[1.1, 1.6, 0.7]} />
        <meshStandardMaterial color={coat} roughness={0.6} />
      </mesh>
      {/* head */}
      <mesh position={[0, 3.0, 0]} castShadow>
        <sphereGeometry args={[0.45, 20, 20]} />
        <meshStandardMaterial color={skin} roughness={0.6} />
      </mesh>
      {/* cap */}
      <mesh position={[0, 3.35, 0]} castShadow>
        <cylinderGeometry args={[0.4, 0.46, 0.25, 14]} />
        <meshStandardMaterial color={coat} roughness={0.6} />
      </mesh>
      {/* arm holding the tool */}
      <mesh position={[0.75, 2.1, 0.2]} rotation={[0, 0, -0.6]} castShadow>
        <cylinderGeometry args={[0.14, 0.14, 1.1, 10]} />
        <meshStandardMaterial color={coat} roughness={0.6} />
      </mesh>
      <group position={[1.15, 1.7, 0.35]}>{tool}</group>
    </group>
  );
}

function Animator({ members, elapsed, speed, active }: {
  members: RefObject<THREE.Group>[]; elapsed: RefObject<number>; speed: number; active: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    members.forEach((m, i) => {
      if (!m.current) return;
      const on = i === active;
      m.current.position.y = on ? 0.15 + 0.08 * Math.sin(elapsed.current * 3) : 0;
      m.current.scale.setScalar(on ? 1.08 : 0.95);
    });
  });
  return null;
}

const INFO = [
  { key: "dentist", coat: "#f8fafc", name: "Dentist", job: "diagnoses & treats disease", tool: "handpiece (drill)" },
  { key: "hygienist", coat: "#7dd3fc", name: "Dental hygienist", job: "scaling, polishing, oral hygiene teaching", tool: "ultrasonic scaler" },
  { key: "technician", coat: "#fbbf24", name: "Dental technician", job: "makes crowns, dentures in the lab", tool: "denture + articulator" },
];

export function Topic10553Sim(props: SimProps) {
  const role = String(props.role ?? "dentist");
  const speed = Number(props.speed ?? 1);
  const m0 = useRef<THREE.Group>(null!);
  const m1 = useRef<THREE.Group>(null!);
  const m2 = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const active = Math.max(INFO.findIndex((i) => i.key === role), 0);
  const info = INFO[active];

  const tools = [
    /* handpiece */
    <group key="t0">
      <mesh castShadow rotation={[0.5, 0, 0]}>
        <cylinderGeometry args={[0.09, 0.09, 0.9, 10]} />
        <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
      </mesh>
      <mesh position={[0, -0.5, 0.15]}>
        <sphereGeometry args={[0.08, 10, 10]} />
        <meshStandardMaterial color="#e2e8f0" metalness={0.9} roughness={0.2} />
      </mesh>
    </group>,
    /* scaler */
    <group key="t1">
      <mesh castShadow rotation={[0.5, 0, 0]}>
        <cylinderGeometry args={[0.11, 0.13, 0.7, 10]} />
        <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
      </mesh>
      <mesh position={[0, -0.45, 0.12]} rotation={[0.9, 0, 0]}>
        <cylinderGeometry args={[0.02, 0.04, 0.4, 8]} />
        <meshStandardMaterial color="#e2e8f0" metalness={0.8} roughness={0.3} />
      </mesh>
    </group>,
    /* denture */
    <group key="t2">
      <mesh castShadow rotation={[0, 0, Math.PI]}>
        <torusGeometry args={[0.32, 0.14, 10, 20, Math.PI]} />
        <meshStandardMaterial color="#fb7185" roughness={0.5} />
      </mesh>
      {[-0.2, 0, 0.2].map((x, i) => (
        <mesh key={i} position={[x, -0.1, 0]}>
          <boxGeometry args={[0.12, 0.18, 0.12]} />
          <meshStandardMaterial color="#ffffff" roughness={0.3} />
        </mesh>
      ))}
    </group>,
  ];

  const xs = [-3.2, 0, 3.2];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Member", info.name],
          ["Does", info.job],
          ["Holds", info.tool],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 14]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {[m0, m1, m2].map((ref, i) => (
          <group key={i} ref={ref}>
            <Person x={xs[i]} coat={INFO[i].coat} skin="#f0b98d" tool={tools[i]} />
            <Text position={[xs[i], 4.2, 0]} fontSize={0.4} color={INFO[i].coat} anchorX="center" anchorY="middle">
              {INFO[i].name}
            </Text>
            <Text position={[xs[i], 0.15, 1.2]} fontSize={0.26} color="#94a3b8" anchorX="center" anchorY="middle">
              {INFO[i].job}
            </Text>
          </group>
        ))}

        <Label p={[0, 5.2, 0]} size={0.36} color="#e2e8f0">the dental team — auxiliaries extend the dentist's reach</Label>

        <Animator members={[m0, m1, m2]} elapsed={elapsed} speed={speed} active={active} />
      </SimCanvas>
    </div>
  );
}
