// app/components/sims/unique/Topic10542Sim.tsx
// Management of traumatic injuries in children: avulsion (tooth knocked
// clean out), luxation (tooth pushed sideways), and crown fracture —
// then the tooth is replanted and splinted.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "inj", label: "Injury", kind: "select", min: 0, max: 0, step: 1, default: "avulsion", options: ["avulsion", "luxation", "fracture"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Traumatic Dental Injuries in Children",
  blurb: "A tooth knocked out, pushed sideways, or broken — then replanted and splinted back into place.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ tooth, elapsed, speed, inj }: {
  tooth: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; inj: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!tooth.current) return;
    // 6-second loop: injury happens, then the tooth is replanted
    const cyc = (t % 6) / 6;
    if (inj === "avulsion") {
      if (cyc < 0.25) {
        // knocked out, lying beside the socket
        tooth.current.position.set(1.8, 0.9, 0.8);
        tooth.current.rotation.z = 1.4;
      } else {
        // replanted: glide back into the socket
        const k = Math.min((cyc - 0.25) / 0.2, 1);
        tooth.current.position.set(1.8 - 1.8 * k, 0.9 + 1.15 * k, 0.8 - 0.8 * k);
        tooth.current.rotation.z = 1.4 * (1 - k);
      }
    } else if (inj === "luxation") {
      if (cyc < 0.25) {
        tooth.current.position.set(0.55, 2.05, 0);
        tooth.current.rotation.z = 0.45;
      } else {
        const k = Math.min((cyc - 0.25) / 0.2, 1);
        tooth.current.position.set(0.55 - 0.55 * k, 2.05, 0);
        tooth.current.rotation.z = 0.45 * (1 - k);
      }
    } else {
      // fracture: broken piece wobbles then is bonded back
      tooth.current.position.set(0, 2.05, 0);
      tooth.current.rotation.z = cyc < 0.25 ? 0.12 * Math.sin(t * 6) : 0.12 * Math.sin(t * 6) * Math.max(1 - (cyc - 0.25) * 4, 0);
    }
  });
  return null;
}

const INFO: Record<string, { name: string; action: string }> = {
  avulsion: { name: "Avulsion — tooth knocked out", action: "hold by crown, rinse, replant FAST (<60 min), splint 2 weeks" },
  luxation: { name: "Luxation — tooth displaced", action: "reposition gently, splint, check pulp vitality" },
  fracture: { name: "Crown fracture", action: "find the fragment — it can be bonded back on" },
};

export function Topic10542Sim(props: SimProps) {
  const inj = String(props.inj ?? "avulsion");
  const speed = Number(props.speed ?? 1);
  const tooth = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = INFO[inj];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Injury", info.name],
          ["Do", info.action],
          ["Don't", "scrub the root / let it dry out"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* gum with an empty socket */}
        <mesh position={[0, 1.2, 0]} castShadow>
          <boxGeometry args={[6, 0.9, 1.6]} />
          <meshStandardMaterial color="#e0607a" roughness={0.6} />
        </mesh>
        {/* socket hole */}
        <mesh position={[0, 1.65, 0]}>
          <boxGeometry args={[0.7, 0.3, 0.7]} />
          <meshStandardMaterial color="#5b1a1a" roughness={0.9} />
        </mesh>
        {/* neighbor teeth */}
        {[-2.2, -1.4, 1.4, 2.2].map((x, i) => (
          <mesh key={i} position={[x, 2.2, 0]} castShadow>
            <boxGeometry args={[0.66, 0.95, 0.6]} />
            <meshStandardMaterial color="#fefce8" roughness={0.3} />
          </mesh>
        ))}

        {/* the injured tooth */}
        <group ref={tooth} position={[1.8, 0.9, 0.8]}>
          <mesh castShadow>
            <boxGeometry args={[0.66, inj === "fracture" ? 0.6 : 0.95, 0.6]} />
            <meshStandardMaterial color="#ffffff" roughness={0.3} />
          </mesh>
          {inj === "fracture" && (
            /* broken fragment lying below */
            <mesh position={[0.15, -0.75, 0.1]} rotation={[0.4, 0, 0.5]} castShadow>
              <boxGeometry args={[0.5, 0.35, 0.45]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.35} />
            </mesh>
          )}
          {inj !== "fracture" && (
            <mesh position={[0, -0.75, 0]} rotation={[Math.PI, 0, 0]}>
              <coneGeometry args={[0.2, 0.7, 8]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.35} />
            </mesh>
          )}
        </group>

        {/* flexible splint wire after replantation */}
        <mesh position={[0, 2.35, 0.36]} castShadow>
          <boxGeometry args={[4.4, 0.08, 0.08]} />
          <meshStandardMaterial color="#38bdf8" metalness={0.6} roughness={0.3} emissive="#0ea5e9" emissiveIntensity={0.4} />
        </mesh>
        <Label p={[0, 2.9, 0.5]} size={0.28} color="#7dd3fc">flexible splint holds it</Label>

        <Label p={[0, 4.2, 0]} size={0.32} color="#e2e8f0">{info.name}</Label>
        <Label p={[0, 0.1, 0]} size={0.3} color="#fde68a">{info.action}</Label>

        <Animator tooth={tooth} elapsed={elapsed} speed={speed} inj={inj} />
      </SimCanvas>
    </div>
  );
}
