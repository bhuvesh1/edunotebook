// Plastic surgery basics: skin grafts, flaps, cleft management.
// A skin wound receives a graft that lands and "takes"; a flap rotates into
// place on its blood-supply pedicle; a cleft lip closes stitch by stitch.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "procedure", label: "Procedure", kind: "select", min: 0, max: 0, step: 1, default: "graft", options: ["graft", "flap", "cleft"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Plastic Surgery: Grafts & Flaps",
  blurb: "Watch a skin graft settle onto a wound, a flap rotate in on its blood supply, or a cleft lip stitch closed.",
};

function Animator({
  group, graft, flap, stitches, elapsed, speed, procedure,
}: {
  group: React.RefObject<THREE.Group>;
  graft: React.RefObject<THREE.Mesh>;
  flap: React.RefObject<THREE.Group>;
  stitches: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  procedure: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    const cyc = (t % 10) / 10; // 10s demo loop
    if (graft.current) {
      graft.current.visible = procedure === "graft";
      // graft floats down and lands on the wound, holds, lifts again
      const land = cyc < 0.35 ? 2.2 - (cyc / 0.35) * 1.75 : cyc < 0.7 ? 0.45 : 0.45 + ((cyc - 0.7) / 0.3) * 1.75;
      graft.current.position.y = land;
      const m = graft.current.material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = cyc > 0.35 && cyc < 0.7 ? 0.25 + 0.2 * Math.sin(t * 6) : 0;
    }
    if (flap.current) {
      flap.current.visible = procedure === "flap";
      const swing = cyc < 0.4 ? (cyc / 0.4) : cyc < 0.75 ? 1 : 1 - (cyc - 0.75) / 0.25;
      flap.current.rotation.y = swing * Math.PI * 0.85;
    }
    if (stitches.current) {
      stitches.current.visible = procedure === "cleft";
      const n = Math.floor(cyc * 8);
      stitches.current.children.forEach((s, i) => { s.visible = i < n; });
    }
  });
  return null;
}

export function Topic10256Sim(props: SimProps) {
  const procedure = String(props.procedure ?? "graft");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const graft = useRef<THREE.Mesh>(null!);
  const flap = useRef<THREE.Group>(null!);
  const stitches = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = { graft: "Skin graft", flap: "Rotation flap", cleft: "Cleft lip repair" };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Procedure", names[procedure] ?? procedure], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* skin bed */}
          <mesh position={[0, 0.6, 0]} castShadow receiveShadow>
            <boxGeometry args={[7, 0.5, 5]} />
            <meshStandardMaterial color="#f5c396" roughness={0.7} />
          </mesh>

          {procedure === "graft" && (
            <>
              {/* open wound: raw red crater */}
              <mesh position={[-1.2, 0.86, 0]} castShadow>
                <cylinderGeometry args={[1.05, 0.85, 0.12, 24]} />
                <meshStandardMaterial color="#b91c1c" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.4} />
              </mesh>
              {/* the graft patch descending */}
              <mesh ref={graft} position={[-1.2, 2.2, 0]} rotation={[0, 0, 0.15]} castShadow>
                <cylinderGeometry args={[1.0, 1.0, 0.08, 24]} />
                <meshStandardMaterial color="#fde68a" roughness={0.6} emissive="#f59e0b" emissiveIntensity={0.3} />
              </mesh>
              <Label text="Donor skin graft" position={[-1.2, 3.3, 0]} size={0.55} color="#fde68a" />
              <Label text="Wound bed" position={[-3.3, 0.9, 0]} size={0.55} color="#fca5a5" />
            </>
          )}

          {procedure === "flap" && (
            <>
              {/* defect to cover */}
              <mesh position={[1.4, 0.86, 0.8]} castShadow>
                <cylinderGeometry args={[0.9, 0.75, 0.12, 24]} />
                <meshStandardMaterial color="#b91c1c" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.4} />
              </mesh>
              {/* pedicle pivot point */}
              <mesh position={[-1.6, 0.9, 0.8]} castShadow>
                <cylinderGeometry args={[0.16, 0.16, 0.3, 12]} />
                <meshStandardMaterial color="#dc2626" roughness={0.5} />
              </mesh>
              {/* rotating flap with its blood vessel */}
              <group ref={flap} position={[-1.6, 1.0, 0.8]}>
                <mesh position={[1.5, 0, 0]} castShadow>
                  <boxGeometry args={[2.6, 0.14, 1.5]} />
                  <meshStandardMaterial color="#fbbf24" roughness={0.6} />
                </mesh>
                <mesh position={[1.5, 0.05, 0]} castShadow>
                  <cylinderGeometry args={[0.07, 0.07, 2.4, 8]} />
                  <meshStandardMaterial color="#dc2626" roughness={0.4} emissive="#7f1d1d" emissiveIntensity={0.5} />
                </mesh>
              </group>
              <Label text="Flap (own blood supply)" position={[-1.6, 2.2, 0.8]} size={0.55} color="#fde68a" />
              <Label text="Defect" position={[1.4, 1.6, 0.8]} size={0.55} color="#fca5a5" />
            </>
          )}

          {procedure === "cleft" && (
            <>
              {/* upper lip with a cleft gap */}
              <mesh position={[-1.1, 1.6, 0]} castShadow>
                <boxGeometry args={[1.9, 0.7, 0.6]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              <mesh position={[1.1, 1.6, 0]} castShadow>
                <boxGeometry args={[1.9, 0.7, 0.6]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              <mesh position={[0, 1.55, 0]} castShadow>
                <boxGeometry args={[0.35, 0.55, 0.5]} />
                <meshStandardMaterial color="#b91c1c" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.5} />
              </mesh>
              {/* stitches appearing one by one */}
              <group ref={stitches}>
                {Array.from({ length: 8 }).map((_, i) => (
                  <mesh key={i} position={[0, 1.9 - i * 0.09, 0.28]} rotation={[Math.PI / 2, 0, 0.5]} castShadow>
                    <torusGeometry args={[0.09, 0.03, 8, 12]} />
                    <meshStandardMaterial color="#e2e8f0" roughness={0.4} />
                  </mesh>
                ))}
              </group>
              <Label text="Cleft gap" position={[0, 2.6, 0]} size={0.55} color="#fca5a5" />
              <Label text="Stitches" position={[1.6, 1.0, 0.4]} size={0.5} color="#e2e8f0" />
            </>
          )}
        </group>
        <Animator group={group} graft={graft} flap={flap} stitches={stitches} elapsed={elapsed} speed={speed} procedure={procedure} />
      </SimCanvas>
    </div>
  );
}
