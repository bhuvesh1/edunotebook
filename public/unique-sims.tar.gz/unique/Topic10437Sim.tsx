"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "type", label: "Restoration type", kind: "select", min: 0, max: 0, step: 1, default: "pfm", options: ["pfm", "allceramic", "zirconia"] },
  { key: "light", label: "Light test", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Dental ceramics and metal-ceramic restorations",
  blurb: "A crown sliced open to show its layers — metal coping, opaque, porcelain — with a light beam testing how lifelike it looks.",
};

const TYPES: Record<string, { name: string; layers: { name: string; color: string; h: number; opacity: number }[]; note: string }> = {
  pfm: {
    name: "Porcelain-fused-to-metal",
    layers: [
      { name: "Metal coping", color: "#9ca3af", h: 0.3, opacity: 1 },
      { name: "Opaque", color: "#f8fafc", h: 0.18, opacity: 1 },
      { name: "Dentin porcelain", color: "#f5d78e", h: 0.4, opacity: 0.95 },
      { name: "Enamel porcelain", color: "#fefce8", h: 0.3, opacity: 0.85 },
    ],
    note: "Strong metal inside — porcelain outside for looks",
  },
  allceramic: {
    name: "All-ceramic (e.max)",
    layers: [
      { name: "Lithium disilicate core", color: "#e0f2fe", h: 0.4, opacity: 0.9 },
      { name: "Dentin porcelain", color: "#f5d78e", h: 0.35, opacity: 0.9 },
      { name: "Enamel porcelain", color: "#fefce8", h: 0.35, opacity: 0.75 },
    ],
    note: "No metal — light passes through like a real tooth",
  },
  zirconia: {
    name: "Zirconia",
    layers: [
      { name: "Zirconia core", color: "#f1f5f9", h: 0.55, opacity: 1 },
      { name: "Layered porcelain", color: "#fef3c7", h: 0.45, opacity: 0.9 },
    ],
    note: "Toughest ceramic — for back teeth",
  },
};

function LightBeam({ on }: { on: boolean }) {
  const beam = useRef<THREE.Mesh>(null!);
  const t = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    if (beam.current) {
      const m = beam.current.material as THREE.MeshStandardMaterial;
      m.opacity = on ? 0.35 + Math.sin(t.current * 3) * 0.08 : 0;
    }
  });
  return (
    <mesh ref={beam} position={[-2.6, 1.4, 0]} rotation={[0, 0, -Math.PI / 2.6]}>
      <cylinderGeometry args={[0.28, 0.5, 3.6, 14, 1, true]} />
      <meshStandardMaterial color="#fef08a" transparent opacity={0.35} roughness={0.2} side={THREE.DoubleSide} />
    </mesh>
  );
}

function Scene({ type, light }: { type: string; light: boolean }) {
  const crown = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const ty = TYPES[type] ?? TYPES.pfm;
  const totalH = useMemo(() => ty.layers.reduce((a, l) => a + l.h, 0), [ty]);

  useFrame((_, delta) => {
    t.current += delta;
    if (crown.current) crown.current.rotation.y = t.current * 0.5;
  });

  let y = -totalH / 2;
  const layerMeshes = ty.layers.map((l, i) => {
    const yy = y + l.h / 2;
    y += l.h;
    return { ...l, yy, i };
  });

  return (
    <group>
      {/* half-crown showing layers */}
      <group ref={crown}>
        {layerMeshes.map((l) => (
          <mesh key={l.i} position={[0, l.yy + 0.4, 0]}>
            <cylinderGeometry args={[0.85 - l.i * 0.06, 0.9 - l.i * 0.06, l.h, 20, 1, false, 0, Math.PI]} />
            <meshStandardMaterial color={l.color} transparent opacity={l.opacity} roughness={0.3} side={THREE.DoubleSide} />
          </mesh>
        ))}
        {/* full back half shell */}
        <mesh position={[0, 0.4, 0]}>
          <cylinderGeometry args={[0.9, 0.95, totalH, 20, 1, false, Math.PI, Math.PI]} />
          <meshStandardMaterial color="#fdfbf3" transparent opacity={0.35} roughness={0.25} side={THREE.DoubleSide} />
        </mesh>
      </group>

      {/* layer labels */}
      {layerMeshes.map((l) => (
        <Label key={l.i} text={l.name} position={[2.1, l.yy + 0.4, 0]} size={0.38} color={l.color === "#9ca3af" ? "#cbd5e1" : "#fefce8"} />
      ))}

      <LightBeam on={light} />
      <Label text="Light translucency test" position={[-3.4, 2.6, 0]} size={0.42} color="#fef08a" />

      <Label text={ty.name} position={[0, 3.2, 0]} size={0.6} color="#fef3c7" />
      <Label text={ty.note} position={[0, -2.4, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10437Sim(props: SimProps) {
  const type = String(props.type ?? "pfm");
  const light = String(props.light ?? "on") === "on";
  const ty = TYPES[type] ?? TYPES.pfm;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Restoration", ty.name], ["Layers", `${ty.layers.length}`], ["Translucency", light ? "Testing" : "Off"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 9]} target={[0, 0.4, 0]}>
        <Scene type={type} light={light} />
      </SimCanvas>
    </div>
  );
}
