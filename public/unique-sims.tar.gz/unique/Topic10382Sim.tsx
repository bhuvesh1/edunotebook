"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "open", label: "Jaw opening", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.45, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Temporomandibular joint: anatomy and histology",
  blurb: "Open and close the jaw — the condyle first rotates, then glides forward over the articular eminence, riding on its disc.",
};

function TMJScene({ open, speed, showLabels }: { open: number; speed: number; showLabels: boolean }) {
  const jaw = useRef<THREE.Group>(null!);
  const disc = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    // gentle auto-chew wobble added on top of the slider
    const wobble = Math.sin(elapsed.current * 2.2) * 0.06;
    const o = THREE.MathUtils.clamp(open + wobble, 0, 1);
    if (jaw.current) {
      // rotation then translation: rotate early, glide late
      const rot = Math.min(o / 0.5, 1) * 0.35 + Math.max(0, (o - 0.5) / 0.5) * 0.25;
      jaw.current.rotation.z = rot;
      jaw.current.position.x = Math.max(0, (o - 0.45) / 0.55) * 0.55;
      jaw.current.position.y = -Math.max(0, (o - 0.45) / 0.55) * 0.3;
    }
    if (disc.current) {
      disc.current.position.x = -2.2 + Math.max(0, (o - 0.45) / 0.55) * 0.5;
    }
  });

  return (
    <group>
      {/* skull: temporal bone with glenoid fossa + articular eminence */}
      <group position={[-1.4, 2.6, 0]}>
        <mesh castShadow>
          <boxGeometry args={[4.4, 3.4, 3.4]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.7} />
        </mesh>
        {/* fossa hollow */}
        <mesh position={[-0.8, -1.75, 0]}>
          <sphereGeometry args={[1.0, 20, 14, 0, Math.PI * 2, 0, Math.PI / 2]} />
          <meshStandardMaterial color="#a8a29e" roughness={0.8} />
        </mesh>
        {/* articular eminence bump */}
        <mesh position={[0.6, -1.7, 0]} castShadow>
          <sphereGeometry args={[0.65, 18, 12]} />
          <meshStandardMaterial color="#d6d3d1" roughness={0.7} />
        </mesh>
      </group>

      {/* articular disc (fibrocartilage) */}
      <mesh ref={disc} position={[-2.2, 0.85, 0]} scale={[1.4, 0.45, 1.2]} castShadow>
        <sphereGeometry args={[0.7, 20, 14]} />
        <meshStandardMaterial color="#f9a8d4" roughness={0.35} />
      </mesh>

      {/* mandible: ramus + body + teeth hint */}
      <group ref={jaw} position={[-2.2, 0.35, 0]}>
        {/* condyle head */}
        <mesh position={[0, 0, 0]} castShadow>
          <sphereGeometry args={[0.5, 20, 14]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.6} />
        </mesh>
        {/* ramus */}
        <mesh position={[-0.5, -1.6, 0]} rotation={[0, 0, 0.25]} castShadow>
          <boxGeometry args={[0.8, 2.6, 1.4]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.7} />
        </mesh>
        {/* body going forward */}
        <mesh position={[1.8, -2.7, 0]} castShadow>
          <boxGeometry args={[4.6, 0.9, 1.4]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.7} />
        </mesh>
        {/* chin */}
        <mesh position={[4.0, -2.5, 0]} castShadow>
          <sphereGeometry args={[0.55, 16, 12]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.7} />
        </mesh>
        {/* lower teeth */}
        {[1.2, 2.0, 2.8].map((x, i) => (
          <mesh key={i} position={[x, -2.05, 0]} castShadow>
            <boxGeometry args={[0.6, 0.5, 1.1]} />
            <meshStandardMaterial color="#fef9c3" roughness={0.25} />
          </mesh>
        ))}
      </group>

      {/* upper teeth (fixed) */}
      {[0.4, 1.2, 2.0, 2.8].map((x, i) => (
        <mesh key={i} position={[x, 0.5, 0]} castShadow>
          <boxGeometry args={[0.6, 0.55, 1.2]} />
          <meshStandardMaterial color="#fef9c3" roughness={0.25} />
        </mesh>
      ))}

      {/* lateral pterygoid muscle pulling condyle forward */}
      <mesh position={[-0.4, 1.5, 1.1]} rotation={[0, 0, -0.5]} castShadow>
        <cylinderGeometry args={[0.28, 0.34, 2.4, 12]} />
        <meshStandardMaterial color="#ef4444" roughness={0.5} />
      </mesh>

      {showLabels && (
        <>
          <Text position={[-4.6, 0.9, 0]} fontSize={0.4} color="#f9a8d4">Articular disc</Text>
          <Text position={[-4.6, -0.3, 0]} fontSize={0.4} color="#e7e5e4">Condyle</Text>
          <Text position={[1.6, 3.6, 0]} fontSize={0.4} color="#e7e5e4">Articular eminence</Text>
          <Text position={[-0.4, 2.9, 1.1]} fontSize={0.36} color="#fca5a5">Lat. pterygoid pulls →</Text>
          <Text position={[1.5, -5.2, 0]} fontSize={0.44} color="#fef3c7" maxWidth={10}>
            {open < 0.4 ? "Early opening: condyle ROTATES in the fossa" : "Wide opening: condyle GLIDES forward under the eminence"}
          </Text>
        </>
      )}
    </group>
  );
}

export function Topic10382Sim(props: SimProps) {
  const open = Number(props.open ?? 0.45);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Opening", `${Math.round(open * 45)} mm`],
          ["Movement", open < 0.4 ? "rotation" : "rotation + translation"],
          ["Disc", "fibrocartilage — no hyaline here"],
        ]}
      />
      <SimCanvas cameraPosition={[1, 3, 13]} target={[0.5, 0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -5.6, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <TMJScene open={open} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
