"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ltype", label: "Lesion", kind: "select", min: 0, max: 0, step: 1, default: "fibroadenoma", options: ["normal", "fibroadenoma", "carcinoma"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Breast Lesions",
  blurb: "Lobules and ducts with a smooth mobile fibroadenoma, or a spiky invasive carcinoma.",
};

function Animator({ root, lump, mass, elapsed, speed, fib, ca }: { root: RefObject<THREE.Group>; lump: RefObject<THREE.Mesh>; mass: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; fib: boolean; ca: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (lump.current) {
      lump.current.visible = fib;
      lump.current.position.x = -1.2 + Math.sin(t * 1.2) * 0.35;
    }
    if (mass.current) {
      mass.current.visible = ca;
      mass.current.rotation.y = t * 0.5;
      mass.current.children.forEach((m, i) => {
        if (i > 0) m.scale.set(1, 0.7 + 0.3 * Math.sin(t * 2 + i * 1.3), 1);
      });
    }
  });
  return null;
}

export function Topic10101Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const ltype = String(props.ltype ?? "fibroadenoma");
  const fib = ltype === "fibroadenoma";
  const ca = ltype === "carcinoma";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const lump = useRef<THREE.Mesh>(null!);
  const mass = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Lesion", ltype],
          ["Nature", fib ? "benign \u2014 mobile, rubbery" : ca ? "malignant \u2014 fixed, irregular" : "none"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 1.6, -1.6]}><boxGeometry args={[9, 3.4, 0.6]} /><meshStandardMaterial color="#7c2d12" roughness={0.8} /></mesh>
          <Label text="chest wall" position={[-4.4, 3.6, -1.6]} size={0.38} color="#a16207" />
          {[[-2.6, 0], [0.2, 0.5], [2.6, -0.3]].map(([x, dz], gi) => (
            <group key={gi} position={[x, 2.1, dz]}>
              {[0, 1, 2, 3, 4].map((i) => (
                <mesh key={i} position={[Math.cos(i * 2.5) * 0.42, Math.sin(i * 2.5) * 0.42, 0]} castShadow>
                  <sphereGeometry args={[0.26, 12, 12]} /><meshStandardMaterial color="#f9a8d4" roughness={0.5} />
                </mesh>
              ))}
              <Label text="lobule" position={[0, -0.75, 0]} size={0.34} color="#f9a8d4" />
            </group>
          ))}
          <mesh position={[0, 1.5, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.14, 0.14, 6.4, 10]} /><meshStandardMaterial color="#fbcfe8" roughness={0.5} />
          </mesh>
          <mesh position={[3.9, 1.5, 0]} rotation={[0, 0, Math.PI / 2]}>
            <coneGeometry args={[0.35, 0.8, 12]} /><meshStandardMaterial color="#f9a8d4" roughness={0.5} />
          </mesh>
          <Label text="ducts \u2192 nipple" position={[2.4, 0.75, 0]} size={0.36} color="#fbcfe8" />
          <mesh ref={lump} visible={false} position={[-1.2, 2.3, 0.6]} castShadow>
            <sphereGeometry args={[0.55, 20, 20]} /><meshStandardMaterial color="#d6a05b" roughness={0.4} />
          </mesh>
          <group ref={mass} visible={false} position={[1.2, 2.2, 0.4]}>
            <mesh castShadow>
              <icosahedronGeometry args={[0.7, 1]} /><meshStandardMaterial color="#991b1b" emissive="#7f1d1d" emissiveIntensity={0.6} roughness={0.55} flatShading />
            </mesh>
            {Array.from({ length: 6 }).map((_, i) => {
              const a = (i / 6) * Math.PI * 2;
              return (
                <mesh key={i} position={[Math.cos(a) * 0.95, Math.sin(a) * 0.7, 0]} rotation={[0, 0, a - Math.PI / 2]}>
                  <coneGeometry args={[0.13, 0.8, 8]} /><meshStandardMaterial color="#7f1d1d" roughness={0.6} />
                </mesh>
              );
            })}
          </group>
          <Label text={fib ? "fibroadenoma \u2014 smooth, mobile" : ca ? "carcinoma \u2014 spiky, fixed, invasive" : "normal breast tissue"} position={[0, 4.3, 0]} size={0.46} color={ltype === "normal" ? "#4ade80" : "#f87171"} />
        </group>
        <Animator root={root} lump={lump} mass={mass} elapsed={elapsed} speed={speed} fib={fib} ca={ca} />
      </SimCanvas>
    </div>
  );
}
