// Sports injuries: ACL tear, meniscal injury, rotator cuff.
// The knee's ACL snaps mid-sprint, the C-shaped meniscus cushion tears, or the
// shoulder's rotator cuff frays — then the replay shows it in slow motion.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "injury", label: "Injury", kind: "select", min: 0, max: 0, step: 1, default: "acl", options: ["acl", "meniscus", "cuff"] },
  { key: "replay", label: "Replay speed", kind: "slider", min: 0.2, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Sports Injuries: ACL, Meniscus, Cuff",
  blurb: "The ACL snaps, the meniscus tears, the rotator cuff frays — watch each injury happen, then replay it.",
};

function Animator({
  group, aclA, aclB, menisc, cuff, elapsed, replay, injury,
}: {
  group: React.RefObject<THREE.Group>;
  aclA: React.RefObject<THREE.Mesh>;
  aclB: React.RefObject<THREE.Mesh>;
  menisc: React.RefObject<THREE.Group>;
  cuff: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  replay: number;
  injury: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * replay;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
    // injury moment every 6s: the structure tears
    const cyc = (t % 6) / 6;
    const tear = cyc < 0.15 ? 0 : cyc < 0.3 ? (cyc - 0.15) / 0.15 : cyc < 0.7 ? 1 : 1 - (cyc - 0.7) / 0.3;
    if (injury === "acl" && aclA.current && aclB.current) {
      aclA.current.rotation.z = 0.5 + tear * 0.9;
      aclB.current.rotation.z = -0.5 - tear * 0.9;
      aclA.current.position.y = 2.35 + tear * 0.18;
      aclB.current.position.y = 2.35 - tear * 0.18;
    }
    if (menisc.current) {
      menisc.current.visible = injury === "meniscus";
      menisc.current.children.forEach((half, i) => {
        half.rotation.y = tear * (i === 0 ? 0.5 : -0.4);
        half.position.x = (i === 0 ? -0.3 : 0.3) + tear * (i === 0 ? -0.25 : 0.25);
      });
    }
    if (cuff.current) {
      cuff.current.visible = injury === "cuff";
      cuff.current.children.forEach((strand, i) => {
        (strand as THREE.Mesh).scale.y = 1 - tear * 0.55;
        (strand as THREE.Mesh).position.y = -tear * 0.2 * (i + 1) * 0.3;
        ((strand as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = tear * (0.5 + 0.4 * Math.sin(t * 5 + i));
      });
    }
  });
  return null;
}

export function Topic10305Sim(props: SimProps) {
  const injury = String(props.injury ?? "acl");
  const replay = Number(props.replay ?? 1);
  const group = useRef<THREE.Group>(null!);
  const aclA = useRef<THREE.Mesh>(null!);
  const aclB = useRef<THREE.Mesh>(null!);
  const menisc = useRef<THREE.Group>(null!);
  const cuff = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = { acl: "ACL tear (knee)", meniscus: "Meniscus tear", cuff: "Rotator cuff tear" };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Injury", names[injury] ?? injury], ["Replay", `${replay.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {(injury === "acl" || injury === "meniscus") && (
            <>
              {/* femur + tibia */}
              <mesh position={[0, 3.3, 0]} castShadow>
                <cylinderGeometry args={[0.3, 0.4, 1.6, 16]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
              <mesh position={[0, 1.1, 0]} castShadow>
                <cylinderGeometry args={[0.3, 0.26, 1.8, 14]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
              {injury === "acl" && (
                <>
                  {/* ACL: two halves that rip apart */}
                  <mesh ref={aclA} position={[-0.08, 2.35, 0]} rotation={[0, 0, 0.5]} castShadow>
                    <cylinderGeometry args={[0.09, 0.09, 0.9, 10]} />
                    <meshStandardMaterial color="#ef4444" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.5} />
                  </mesh>
                  <mesh ref={aclB} position={[0.08, 2.35, 0]} rotation={[0, 0, -0.5]} castShadow>
                    <cylinderGeometry args={[0.09, 0.09, 0.9, 10]} />
                    <meshStandardMaterial color="#ef4444" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.5} />
                  </mesh>
                  {/* PCL behind (intact) */}
                  <mesh position={[0, 2.3, -0.25]} rotation={[0, 0, 0.3]} castShadow>
                    <cylinderGeometry args={[0.09, 0.09, 1.3, 10]} />
                    <meshStandardMaterial color="#fbbf24" roughness={0.5} />
                  </mesh>
                  <Label text="⚡ ACL SNAPS!" position={[0, 0.35, 0]} size={0.65} color="#fca5a5" />
                </>
              )}
              {injury === "meniscus" && (
                <group ref={menisc} visible={false} position={[0, 2.05, 0]}>
                  {[0, 1].map((i) => (
                    <mesh key={i} position={[i === 0 ? -0.3 : 0.3, 0, 0]} castShadow>
                      <torusGeometry args={[0.32, 0.14, 10, 18, Math.PI * 1.4]} />
                      <meshStandardMaterial color="#7dd3fc" roughness={0.4} emissive="#0369a1" emissiveIntensity={0.3} />
                    </mesh>
                  ))}
                </group>
              )}
              <Label text="Femur" position={[-1.6, 3.4, 0]} size={0.5} color="#f8fafc" />
              <Label text="Tibia" position={[-1.6, 1.0, 0]} size={0.5} color="#f8fafc" />
            </>
          )}
          {injury === "cuff" && (
            <>
              {/* humeral head + fraying cuff tendons */}
              <mesh position={[0, 2.2, 0]} castShadow>
                <sphereGeometry args={[0.55, 22, 16]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
              <mesh position={[0, 1.2, 0]} castShadow>
                <cylinderGeometry args={[0.22, 0.24, 1.6, 14]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
              <group ref={cuff} visible={false} position={[0, 2.85, 0]}>
                {[-0.3, 0, 0.3].map((x, i) => (
                  <mesh key={i} position={[x, 0, 0]} castShadow>
                    <boxGeometry args={[0.18, 0.7, 0.12]} />
                    <meshStandardMaterial color="#f472b6" roughness={0.5} emissive="#9d174d" emissiveIntensity={0.4} />
                  </mesh>
                ))}
              </group>
              <Label text="Shoulder ball" position={[-1.6, 2.4, 0]} size={0.5} color="#f8fafc" />
              <Label text="⚡ Cuff tendons fray & tear" position={[0, 0.2, 0]} size={0.6} color="#fca5a5" />
            </>
          )}
          {injury === "meniscus" && <Label text="⚡ C-shaped cushion tears" position={[0, 0.35, 0]} size={0.6} color="#fca5a5" />}
        </group>
        <Animator group={group} aclA={aclA} aclB={aclB} menisc={menisc} cuff={cuff} elapsed={elapsed} replay={replay} injury={injury} />
      </SimCanvas>
    </div>
  );
}
