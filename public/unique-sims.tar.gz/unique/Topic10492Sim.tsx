"use client";
// Dental Implants & Peri-implantitis — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "health", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "Healthy implant", options: ["Healthy implant", "Peri-implantitis"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Dental Implants & Peri-implantitis",
  blurb: "A titanium implant anchored in bone — flip to peri-implantitis and watch the gum redden and bone crater.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const sick = p.health === "Peri-implantitis";
    const gum: any = g("impgum");
    if (gum) {
      (gum.material as any).color.set(sick ? "#c94f5e" : "#e0808f");
      gum.scale.set(sick ? 1.15 : 1, sick ? 1.25 : 1, 1);
    }
    const crater: any = g("impcrater");
    if (crater) crater.visible = sick;
    for (let i = 0; i < 4; i++) {
      const pu: any = g("pus" + i);
      if (pu) {
        pu.visible = sick;
        if (sick) pu.scale.setScalar(0.1 + 0.03 * Math.sin(t * 5 + i));
      }
    }
    const crown: any = g("impcrown");
    if (crown) crown.position.y = 2.9 + (sick ? 0.04 * Math.sin(t * 6) : 0);
  });
  return null;
}

export function Topic10492Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const health = String(props.health ?? "Healthy implant");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, health };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Fixture", "Titanium, threaded"],
          ["Condition", health],
          ["Sign", health === "Healthy implant" ? "Tight pink collar" : "Bleeding, bone crater"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <mesh position={[0, 0.2, 0]}>
            <boxGeometry args={[4.4, 2, 2]} />
            <meshStandardMaterial color="#cbb894" roughness={0.9} />
          </mesh>
          <mesh position={[0, 1.1, 0]}>
            <cylinderGeometry args={[0.34, 0.28, 1.9, 14]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.9} roughness={0.3} />
          </mesh>
          {[0, 1, 2, 3, 4].map((i) => (
            <mesh key={i} position={[0, 0.5 + i * 0.32, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.34, 0.045, 8, 16]} />
              <meshStandardMaterial color="#7d8ca3" metalness={0.9} roughness={0.3} />
            </mesh>
          ))}
          <mesh position={[0, 2.2, 0]}>
            <cylinderGeometry args={[0.16, 0.16, 0.35, 10]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.3} />
          </mesh>
          <group name="impcrown" position={[0, 2.9, 0]}>
            <mesh>
              <cylinderGeometry args={[0.62, 0.5, 0.85, 16]} />
              <meshStandardMaterial color="#faf7ef" roughness={0.25} />
            </mesh>
          </group>
          <mesh name="impgum" position={[0, 1.85, 0]}>
            <torusGeometry args={[0.55, 0.28, 10, 18]} />
            <meshStandardMaterial color="#e0808f" roughness={0.6} />
          </mesh>
          <mesh name="impcrater" position={[0, 1.15, 0]} visible={false}>
            <torusGeometry args={[0.5, 0.16, 8, 16]} />
            <meshStandardMaterial color="#6b4f2e" roughness={1} />
          </mesh>
          {[0, 1, 2, 3].map((i) => (
            <mesh key={i} name={"pus" + i} position={[-0.45 + i * 0.3, 2, 0.45]} visible={false}>
              <sphereGeometry args={[1, 8, 8]} />
              <meshStandardMaterial color="#fde047" roughness={0.4} />
            </mesh>
          ))}
          <Label text="Titanium implant" position={[2.6, 0.8, 0]} size={0.42} color="#94a3b8" />
          <Label text="Crown" position={[-2.4, 2.9, 0]} size={0.42} />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
