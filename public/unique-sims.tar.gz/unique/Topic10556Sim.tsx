"use client";

// Ethics in dental practice: informed consent.
// The patient is told the options, the checklist is completed,
// and a signature is drawn — or consent is refused, which the
// dentist must respect.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "scenario", label: "Scenario", kind: "select", min: 0, max: 0, step: 1, default: "consent", options: ["consent", "refusal"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Informed Consent in Dental Practice",
  blurb: "Explain, check understanding, then sign — or honour a refusal. Consent is the heart of ethical dental practice.",
};

type Ref = { current: THREE.Group | null };

function Animator({ tube, pen, elapsed, speed, boxes }: { tube: { current: THREE.Mesh | null }; pen: Ref; elapsed: { current: number }; speed: number; boxes: Ref }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const e = elapsed.current;
    const cyc = e % 9;
    // checklist ticks in first 4s, signature draws 4s..8s
    const step = Math.floor(cyc);
    boxes.current?.children.forEach((m, i) => {
      const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
      mat.color.set(step > i ? "#22c55e" : "#e2e8f0");
    });
    const frac = Math.min(1, Math.max(0, (cyc - 4) / 4));
    const mesh = tube.current;
    if (mesh) {
      const total = (mesh.userData.total as number) ?? 1;
      mesh.geometry.setDrawRange(0, Math.floor(total * frac));
      const curve = mesh.userData.curve as THREE.CatmullRomCurve3;
      const p = curve.getPoint(Math.min(0.999, frac));
      pen.current?.position.set(p.x, 0.95, p.z + 0.05);
      pen.current && (pen.current.visible = frac < 1 || cyc < 8.5);
    }
  });
  return null;
}

export function Topic10556Sim(props: SimProps) {
  const scenario = String(props.scenario ?? "consent");
  const speed = Number(props.speed ?? 1);
  const consent = scenario === "consent";

  const tube = useRef<THREE.Mesh>(null!);
  const pen = useRef<THREE.Group>(null!);
  const boxes = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const curve = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 44; i++) {
      const t = i / 44;
      pts.push(new THREE.Vector3(-1.35 + t * 1.15, 0.78, 0.62 + 0.09 * Math.sin(i * 0.85) * (1 - t * 0.4)));
    }
    return new THREE.CatmullRomCurve3(pts);
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Scenario", consent ? "Consent given" : "Consent refused"],
          ["Ethical rule", consent ? "Document the signed consent" : "Respect autonomy — do not proceed"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 8.5]} target={[-0.2, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* clipboard + paper */}
        <mesh position={[-0.9, 0.62, 0]} castShadow>
          <boxGeometry args={[1.9, 0.12, 2.7]} />
          <meshStandardMaterial color="#b45309" roughness={0.7} />
        </mesh>
        <mesh position={[-0.9, 0.7, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[1.6, 2.35]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.9} />
        </mesh>
        {/* paper lines */}
        {[-0.55, -0.25, 0.05].map((z, i) => (
          <mesh key={i} position={[-0.9, 0.715, z]} rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[1.2, 0.05]} />
            <meshStandardMaterial color="#cbd5e1" />
          </mesh>
        ))}

        {/* checklist boxes */}
        <group ref={boxes}>
          {[-0.75, -0.45, -0.15].map((z, i) => (
            <mesh key={i} position={[-1.55, 0.78, z]} castShadow>
              <boxGeometry args={[0.2, 0.06, 0.2]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.6} />
            </mesh>
          ))}
        </group>

        {/* signature ink (draws over time) */}
        <mesh
          ref={tube}
          position={[0, 0, 0]}
          onUpdate={(m) => {
            const geo = new THREE.TubeGeometry(curve, 60, 0.028, 6, false);
            m.geometry.dispose();
            m.geometry = geo;
            m.userData.total = geo.index ? geo.index.count : 0;
            m.userData.curve = curve;
          }}
        >
          <meshStandardMaterial color="#1d4ed8" roughness={0.4} />
        </mesh>

        {/* pen */}
        <group ref={pen} position={[-1.35, 0.95, 0.67]} rotation={[0.5, 0, 0.35]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.05, 0.05, 0.75, 10]} />
            <meshStandardMaterial color="#dc2626" roughness={0.4} />
          </mesh>
          <mesh position={[0, -0.42, 0]}>
            <coneGeometry args={[0.05, 0.14, 10]} />
            <meshStandardMaterial color="#1e293b" roughness={0.4} />
          </mesh>
        </group>

        {/* molar beside the form */}
        <group position={[1.7, 0, 0.4]}>
          <mesh position={[0, 0.55, 0]} castShadow>
            <boxGeometry args={[0.6, 0.5, 0.55]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.35} />
          </mesh>
          {[-0.15, 0.15].map((x) => (
            <mesh key={x} position={[x, 0.15, 0]}>
              <coneGeometry args={[0.13, 0.4, 10]} />
              <meshStandardMaterial color="#f1f5f9" roughness={0.4} />
            </mesh>
          ))}
        </group>

        <Label text="INFORMED CONSENT" position={[-0.9, 1.7, -1.05]} size={0.5} color="#e2e8f0" />
        <Label text="diagnosis explained" position={[-0.55, 1.15, -0.75]} size={0.36} color="#94a3b8" />
        <Label text="risks explained" position={[-0.55, 1.15, -0.45]} size={0.36} color="#94a3b8" />
        <Label text="alternatives offered" position={[-0.55, 1.15, -0.15]} size={0.36} color="#94a3b8" />
        {consent ? (
          <Label text="CONSENT SIGNED" position={[-0.9, 1.9, 0.9]} size={0.55} color="#22c55e" />
        ) : (
          <Label text="REFUSED — respect it" position={[-0.9, 1.9, 0.9]} size={0.55} color="#ef4444" />
        )}
        <Animator tube={tube} pen={pen} elapsed={elapsed} speed={speed} boxes={boxes} />
      </SimCanvas>
    </div>
  );
}
