// app/components/sims/unique/Topic7105Sim.tsx
// Relative velocity in two dimensions: two boats cross a harbor. Blue
// and orange arrows are their water-frame velocities; the red dashed
// arrow is boat B's velocity as seen from boat A (v_B − v_A).

"use client";

import { useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "vA", label: "Boat A speed", kind: "slider", min: 0.5, max: 4, step: 0.5, default: 2, unit: "m/s" },
  { key: "vB", label: "Boat B speed", kind: "slider", min: 0.5, max: 4, step: 0.5, default: 2.5, unit: "m/s" },
];

export const UNIQUE_META = {
  title: "Relative Velocity in Two Dimensions",
  blurb: "Two boats cross the harbor — the red arrow is B's velocity as seen from A's deck.",
};

const BOUND = 8;
// Boat A sails east (+x); boat B sails northeast (60°).
const DIR_A = new THREE.Vector2(1, 0);
const DIR_B = new THREE.Vector2(Math.cos(Math.PI / 3), Math.sin(Math.PI / 3));

function Boat({ color, g }: { color: string; g: RefObject<THREE.Group> }) {
  return (
    <group ref={g}>
      <mesh position={[0, 0.35, 0]} castShadow>
        <boxGeometry args={[1.8, 0.5, 0.9]} />
        <meshStandardMaterial color={color} roughness={0.5} />
      </mesh>
      <mesh position={[1.15, 0.35, 0]} rotation={[0, 0, -Math.PI / 2]} castShadow>
        <coneGeometry args={[0.45, 0.7, 4]} />
        <meshStandardMaterial color={color} roughness={0.5} />
      </mesh>
      <mesh position={[-0.3, 0.85, 0]} castShadow>
        <boxGeometry args={[0.7, 0.5, 0.6]} />
        <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
      </mesh>
    </group>
  );
}

/** Flat arrow on the water pointing along `dir` with length ∝ speed. */
function WaterArrow({
  g, color,
}: {
  g: RefObject<THREE.Group>;
  color: string;
}) {
  return (
    <group ref={g} position={[0, 0.15, 0]}>
      <mesh>
        <boxGeometry args={[1, 0.08, 0.16]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} roughness={0.4} />
      </mesh>
      <mesh rotation={[0, 0, -Math.PI / 2]}>
        <coneGeometry args={[0.22, 0.45, 4]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} roughness={0.4} />
      </mesh>
    </group>
  );
}

function aimFlat(
  g: RefObject<THREE.Group>, x: number, z: number,
  dx: number, dz: number, len: number
) {
  if (!g.current) return;
  g.current.position.set(x, 0.15, z);
  g.current.rotation.y = -Math.atan2(dz, dx);
  const shaft = g.current.children[0] as THREE.Mesh;
  const cone = g.current.children[1] as THREE.Mesh;
  shaft.scale.set(Math.max(len, 0.001), 1, 1);
  shaft.position.set(len / 2, 0, 0);
  cone.position.set(len + 0.2, 0, 0);
}

function Animator({
  boatA, boatB, ghost, arA, arB, arR, vA, vB, vrel, bump,
}: {
  boatA: RefObject<THREE.Group>;
  boatB: RefObject<THREE.Group>;
  ghost: RefObject<THREE.Group>;
  arA: RefObject<THREE.Group>;
  arB: RefObject<THREE.Group>;
  arR: RefObject<THREE.Group>;
  vA: number; vB: number;
  vrel: RefObject<number>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const T = t.current;
    // Wrap positions inside the harbor square.
    const wrap1 = (u: number) => -BOUND + ((((u % (2 * BOUND)) + 2 * BOUND) % (2 * BOUND)));
    const ax = wrap1(T * vA * DIR_A.x - 6);
    const az = wrap1(T * vA * DIR_A.y - 2);
    const bx = wrap1(T * vB * DIR_B.x);
    const bz = wrap1(T * vB * DIR_B.y + 3);
    if (boatA.current) {
      boatA.current.position.set(ax, 0, az);
      boatA.current.rotation.y = -Math.atan2(DIR_A.y, DIR_A.x);
    }
    if (boatB.current) {
      boatB.current.position.set(bx, 0, bz);
      boatB.current.rotation.y = -Math.atan2(DIR_B.y, DIR_B.x);
    }
    if (ghost.current) ghost.current.position.set(ax, 0, az + 0.0);
    const rx = vB * DIR_B.x - vA * DIR_A.x;
    const rz = vB * DIR_B.y - vA * DIR_A.y;
    vrel.current = Math.hypot(rx, rz);
    aimFlat(arA, ax, az, DIR_A.x, DIR_A.y, 0.6 + vA * 0.6);
    aimFlat(arB, bx, bz, DIR_B.x, DIR_B.y, 0.6 + vB * 0.6);
    aimFlat(arR, ax, az, rx, rz, 0.6 + vrel.current * 0.6);
    if (++n.current % 20 === 0) bump();
  });
  return null;
}

export function Topic7105Sim(props: SimProps) {
  const vA = Number(props.vA ?? 2);
  const vB = Number(props.vB ?? 2.5);
  const boatA = useRef<THREE.Group>(null!);
  const boatB = useRef<THREE.Group>(null!);
  const ghost = useRef<THREE.Group>(null!);
  const arA = useRef<THREE.Group>(null!);
  const arB = useRef<THREE.Group>(null!);
  const arR = useRef<THREE.Group>(null!);
  const vrel = useRef(0);
  const [, bump] = useState(0);

  const seaGrid = useMemo(() => new THREE.GridHelper(18, 18, "#1d4ed8", "#1e3a8a"), []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["v_A", `${vA.toFixed(1)} m/s east`],
          ["v_B", `${vB.toFixed(1)} m/s NE`],
          ["|v_B − v_A|", `${vrel.current.toFixed(2)} m/s`],
          ["🔴 Red arrow", "B as seen from A"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 12, 10]} target={[0, 0, 0]}>
        {/* sea */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 24]} />
          <meshStandardMaterial color="#0c1f3f" roughness={0.7} />
        </mesh>
        <primitive object={seaGrid} position={[0, 0.03, 0]} />

        <Boat color="#38bdf8" g={boatA} />
        <Boat color="#fb923c" g={boatB} />
        {/* ghost of A: the observer's deck */}
        <group ref={ghost}>
          <mesh position={[0, 0.35, 0]}>
            <boxGeometry args={[1.8, 0.5, 0.9]} />
            <meshStandardMaterial color="#38bdf8" transparent opacity={0.25} roughness={0.5} />
          </mesh>
        </group>

        <WaterArrow g={arA} color="#38bdf8" />
        <WaterArrow g={arB} color="#fb923c" />
        <WaterArrow g={arR} color="#ef4444" />

        <Animator
          boatA={boatA} boatB={boatB} ghost={ghost}
          arA={arA} arB={arB} arR={arR}
          vA={vA} vB={vB} vrel={vrel}
          bump={() => bump((v) => v + 1)}
        />
      </SimCanvas>
    </div>
  );
}
