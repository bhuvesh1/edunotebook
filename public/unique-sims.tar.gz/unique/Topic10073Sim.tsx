"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cycles", label: "Target cycles", kind: "slider", min: 1, max: 8, step: 1, default: 4 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "PCR: Copying DNA",
  blurb: "The thermal cycler loops through denaturation, annealing and extension, doubling DNA every cycle.",
};

function Animator({ root, lamD, lamA, lamE, s1, s2, dots, elapsed, speed }: { root: RefObject<THREE.Group>; lamD: RefObject<THREE.Mesh>; lamA: RefObject<THREE.Mesh>; lamE: RefObject<THREE.Mesh>; s1: RefObject<THREE.Group>; s2: RefObject<THREE.Group>; dots: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const stage = Math.floor(t * 1.1) % 3;
    const setLamp = (r: RefObject<THREE.Mesh>, on: boolean) => {
      if (r.current) (r.current.material as THREE.MeshStandardMaterial).emissiveIntensity = on ? 2.6 : 0.15;
    };
    setLamp(lamD, stage === 0); setLamp(lamA, stage === 1); setLamp(lamE, stage === 2);
    const sep = stage === 0 ? 0.55 : 0.14;
    if (s1.current) s1.current.position.y = 1.9 + sep;
    if (s2.current) s2.current.position.y = 1.9 - sep;
    if (s2.current) s2.current.children.forEach((m, i) => {
      m.scale.setScalar(stage === 2 ? 1 : (i < 2 ? 1 : 0.001));
    });
    if (dots.current) {
      dots.current.children.forEach((m, i) => {
        m.position.y = 0.35 + Math.abs(Math.sin(t * 2 + i)) * 0.12;
      });
    }
  });
  return null;
}

export function Topic10073Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const cycles = Math.round(Number(props.cycles ?? 4));
  const copies = Math.pow(2, cycles);
  const shown = Math.min(copies, 16);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const lamD = useRef<THREE.Mesh>(null!);
  const lamA = useRef<THREE.Mesh>(null!);
  const lamE = useRef<THREE.Mesh>(null!);
  const s1 = useRef<THREE.Group>(null!);
  const s2 = useRef<THREE.Group>(null!);
  const dots = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Target cycles", `${cycles}`],
          ["DNA copies", `${copies}`],
          ["Stages", "95\u00b0C \u00b7 55\u00b0C \u00b7 72\u00b0C"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 0.6, 0]} castShadow>
            <boxGeometry args={[7.4, 1.1, 3]} /><meshStandardMaterial color="#1e293b" roughness={0.6} />
          </mesh>
          {[-2.4, 0, 2.4].map((x, i) => (
            <mesh key={i} position={[x, 1.9, 0]}>
              <cylinderGeometry args={[0.5, 0.42, 1.7, 16, 1, true]} />
              <meshStandardMaterial color="#bae6fd" transparent opacity={0.3} roughness={0.2} side={THREE.DoubleSide} />
            </mesh>
          ))}
          <group ref={s1}>
            {Array.from({ length: 6 }).map((_, i) => (
              <mesh key={i} position={[-0.9 + i * 0.36, 0, 0]}><sphereGeometry args={[0.13, 10, 10]} /><meshStandardMaterial color="#60a5fa" /></mesh>
            ))}
          </group>
          <group ref={s2}>
            {Array.from({ length: 6 }).map((_, i) => (
              <mesh key={i} position={[-0.9 + i * 0.36, 0, 0]}><sphereGeometry args={[0.13, 10, 10]} /><meshStandardMaterial color="#f472b6" /></mesh>
            ))}
          </group>
          <mesh ref={lamD} position={[-2.4, 3.3, 0]}><sphereGeometry args={[0.22, 14, 14]} /><meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.15} /></mesh>
          <mesh ref={lamA} position={[0, 3.3, 0]}><sphereGeometry args={[0.22, 14, 14]} /><meshStandardMaterial color="#facc15" emissive="#facc15" emissiveIntensity={0.15} /></mesh>
          <mesh ref={lamE} position={[2.4, 3.3, 0]}><sphereGeometry args={[0.22, 14, 14]} /><meshStandardMaterial color="#4ade80" emissive="#4ade80" emissiveIntensity={0.15} /></mesh>
          <Label text="95\u00b0C denature" position={[-2.4, 3.95, 0]} size={0.4} color="#ef4444" />
          <Label text="55\u00b0C anneal" position={[0, 3.95, 0]} size={0.4} color="#facc15" />
          <Label text="72\u00b0C extend" position={[2.4, 3.95, 0]} size={0.4} color="#4ade80" />
          <group ref={dots}>
            {Array.from({ length: shown }).map((_, i) => (
              <mesh key={i} position={[-3.4 + (i % 8) * 0.95, 0.35, 2.6 + Math.floor(i / 8) * 0.7]}>
                <sphereGeometry args={[0.2, 12, 12]} /><meshStandardMaterial color="#22d3ee" emissive="#0891b2" emissiveIntensity={0.9} />
              </mesh>
            ))}
          </group>
          <Label text={`2\u207f copies = ${copies}`} position={[0, 0.1, 3.4]} size={0.45} color="#22d3ee" />
        </group>
        <Animator root={root} lamD={lamD} lamA={lamA} lamE={lamE} s1={s1} s2={s2} dots={dots} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
