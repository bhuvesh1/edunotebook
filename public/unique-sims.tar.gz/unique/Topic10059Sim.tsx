// Biomolecules: lipids — a phospholipid bilayer (heads + tails), a triglyceride
// (E-shaped glycerol + 3 fatty acids), and an LDL lipoprotein sphere carrying
// its cholesterol cargo.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "struct", label: "Structure", kind: "select", min: 0, max: 0, step: 1, default: "bilayer", options: ["bilayer", "triglyceride", "ldl"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Biomolecules: Lipids",
  blurb: "The phospholipid bilayer, a triglyceride's E-shape, and an LDL particle ferrying cholesterol.",
};

// one phospholipid: head sphere + two tail cylinders
function Phospholipid({ position, flip = false }: { position: [number, number, number]; flip?: boolean }) {
  const s = flip ? -1 : 1;
  return (
    <group position={position}>
      <mesh position={[0, s * 0.55, 0]} castShadow>
        <sphereGeometry args={[0.26, 12, 12]} />
        <meshStandardMaterial color="#38bdf8" roughness={0.4} />
      </mesh>
      {[-0.1, 0.1].map((x, i) => (
        <mesh key={i} position={[x, 0, 0]} castShadow>
          <cylinderGeometry args={[0.07, 0.05, 0.9, 6]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.55} />
        </mesh>
      ))}
    </group>
  );
}

function Animator({
  spinner, tails, elapsed, speed,
}: {
  spinner: React.RefObject<THREE.Group>;
  tails: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (spinner.current) spinner.current.rotation.y = t * 0.4;
    if (tails.current) {
      tails.current.children.forEach((m, i) => {
        m.rotation.z = Math.sin(t * 3 + i * 1.3) * 0.18;
      });
    }
  });
  return null;
}

export function Topic10059Sim(props: SimProps) {
  const struct = String(props.struct ?? "bilayer");
  const speed = Number(props.speed ?? 1);
  const spinner = useRef<THREE.Group>(null!);
  const tails = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const lipidXs = useMemo(() => Array.from({ length: 11 }).map((_, i) => -4 + i * 0.8), []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Structure", struct === "bilayer" ? "phospholipid bilayer" : struct === "triglyceride" ? "triacylglycerol" : "LDL lipoprotein"],
          ["Property", "hydrophobic tails hide from water"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {struct === "bilayer" && (
          <group position={[0, 2.0, 0]}>
            {/* water above and below */}
            <mesh position={[0, 2.2, 0]}>
              <boxGeometry args={[10, 0.5, 3]} />
              <meshStandardMaterial color="#0369a1" transparent opacity={0.35} roughness={0.2} />
            </mesh>
            <mesh position={[0, -2.2, 0]}>
              <boxGeometry args={[10, 0.5, 3]} />
              <meshStandardMaterial color="#0369a1" transparent opacity={0.35} roughness={0.2} />
            </mesh>
            <group ref={tails}>
              {lipidXs.map((x, i) => (
                <group key={i}>
                  <Phospholipid position={[x, 0.75, 0]} />
                  <Phospholipid position={[x + 0.4, -0.75, 0]} flip />
                </group>
              ))}
            </group>
          </group>
        )}
        {struct === "bilayer" && (
          <>
            <Label text="phospholipid bilayer" position={[0, 5.6, 0]} size={0.42} color="#f8fafc" />
            <Label text="hydrophilic heads (blue) face water" position={[-5.6, 4.4, 0]} size={0.3} color="#7dd3fc" />
            <Label text="hydrophobic tails (yellow) hide inside" position={[5.6, 0.9, 0]} size={0.3} color="#fde68a" />
          </>
        )}

        {struct === "triglyceride" && (
          <group ref={spinner} position={[0, 2.0, 0]}>
            {/* glycerol backbone */}
            <mesh castShadow>
              <boxGeometry args={[0.5, 1.4, 0.5]} />
              <meshStandardMaterial color="#f472b6" roughness={0.45} />
            </mesh>
            {/* 3 fatty acid chains (E shape) */}
            {[-0.5, 0, 0.5].map((y, i) => (
              <group key={i} position={[0.6, y, 0]}>
                <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
                  <cylinderGeometry args={[0.12, 0.12, 2.6, 10]} />
                  <meshStandardMaterial color={i === 1 ? "#fb923c" : "#fbbf24"} roughness={0.55} />
                </mesh>
                {/* kink for unsaturated */}
                {i === 1 && (
                  <mesh position={[1.6, 0.15, 0]} rotation={[0, 0, 0.5]}>
                    <cylinderGeometry args={[0.12, 0.12, 0.8, 10]} />
                    <meshStandardMaterial color="#fb923c" roughness={0.55} />
                  </mesh>
                )}
              </group>
            ))}
          </group>
        )}
        {struct === "triglyceride" && (
          <>
            <Label text="triglyceride — glycerol + 3 fatty acids" position={[0, 4.6, 0]} size={0.4} color="#f8fafc" />
            <Label text="glycerol backbone (pink)" position={[-2.2, 2.0, 0]} size={0.3} color="#f9a8d4" />
            <Label text="kink = unsaturated fatty acid" position={[2.8, 1.3, 0]} size={0.3} color="#fdba74" />
          </>
        )}

        {struct === "ldl" && (
          <group ref={spinner} position={[0, 2.0, 0]}>
            {/* phospholipid monolayer shell */}
            <mesh castShadow>
              <sphereGeometry args={[1.6, 24, 24]} />
              <meshStandardMaterial color="#38bdf8" transparent opacity={0.45} roughness={0.35} />
            </mesh>
            {/* cholesterol + triglyceride cargo */}
            {Array.from({ length: 12 }).map((_, i) => {
              const a = (i / 12) * Math.PI * 2;
              const r = 0.5 + (i % 3) * 0.3;
              return (
                <mesh key={i} position={[Math.cos(a) * r, Math.sin(a * 1.3) * r * 0.8, Math.sin(a) * r * 0.5]} castShadow>
                  <dodecahedronGeometry args={[0.22]} />
                  <meshStandardMaterial color="#fbbf24" roughness={0.5} />
                </mesh>
              );
            })}
            {/* apoB-100 protein belt */}
            <mesh rotation={[Math.PI / 2.3, 0, 0]}>
              <torusGeometry args={[1.62, 0.12, 10, 32]} />
              <meshStandardMaterial color="#c084fc" roughness={0.4} />
            </mesh>
          </group>
        )}
        {struct === "ldl" && (
          <>
            <Label text="LDL — 'bad cholesterol' carrier" position={[0, 4.5, 0]} size={0.42} color="#f8fafc" />
            <Label text="apoB-100 protein belt (purple)" position={[0, 0.1, 0]} size={0.3} color="#d8b4fe" />
            <Label text="cholesterol cargo (yellow)" position={[3.2, 2.4, 0]} size={0.3} color="#fde68a" />
          </>
        )}

        <Animator spinner={spinner} tails={tails} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
