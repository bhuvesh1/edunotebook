"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "arches", label: "Highlight arches", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
  { key: "speed", label: "Rotation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 0.6, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Lower limb: gluteal region, thigh, leg, foot, arches",
  blurb: "The leg's skeleton with the foot's three arches glowing — the springs that carry every step you take.",
};

function Leg({ arches, speed }: { arches: boolean; speed: number }) {
  const g = useRef<THREE.Group>(null!);
  const archMat = useRef<THREE.MeshStandardMaterial>(null!);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d * speed;
    if (g.current) g.current.rotation.y = t.current * 0.7;
    if (archMat.current) archMat.current.emissiveIntensity = arches ? 1.2 + Math.sin(t.current * 3) * 0.5 : 0;
  });
  const bone = { color: "#f5f0e6", roughness: 0.55 };
  return (
    <group ref={g} position={[0, 0.6, 0]}>
      {/* pelvis hint */}
      <mesh position={[0, 5.4, 0]} castShadow>
        <boxGeometry args={[2.6, 1.2, 1.4]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      {/* femur */}
      <mesh position={[0.15, 3.9, 0]} rotation={[0, 0, 0.06]} castShadow>
        <cylinderGeometry args={[0.34, 0.38, 2.6, 14]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      <mesh position={[0.1, 5.15, 0]} castShadow>
        <sphereGeometry args={[0.5, 16, 16]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      {/* knee */}
      <mesh position={[0.23, 2.55, 0.15]} castShadow>
        <sphereGeometry args={[0.28, 14, 14]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      {/* tibia + fibula */}
      <mesh position={[0.28, 1.45, 0]} castShadow>
        <cylinderGeometry args={[0.28, 0.34, 2.0, 14]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      <mesh position={[-0.28, 1.45, 0]} castShadow>
        <cylinderGeometry args={[0.13, 0.15, 1.9, 10]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      {/* ankle + foot */}
      <mesh position={[0.28, 0.35, 0]} castShadow>
        <boxGeometry args={[0.5, 0.3, 0.5]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      <mesh position={[0.28, 0.22, 0.75]} castShadow>
        <boxGeometry args={[0.45, 0.22, 1.4]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      {/* toes */}
      {[0.12, 0.24, 0.36, 0.48].map((x) => (
        <mesh key={x} position={[x, 0.18, 1.6]} castShadow>
          <boxGeometry args={[0.1, 0.12, 0.4]} />
          <meshStandardMaterial {...bone} />
        </mesh>
      ))}
      {/* medial longitudinal arch highlight */}
      <mesh position={[0.1, 0.18, 0.6]} rotation={[0, 0, 0]} castShadow>
        <torusGeometry args={[0.55, 0.09, 10, 20, Math.PI]} />
        <meshStandardMaterial ref={archMat} color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1.2} roughness={0.4} />
      </mesh>
    </group>
  );
}

export function Topic10004Sim(props: SimProps) {
  const arches = String(props.arches ?? "on") === "on";
  const speed = Number(props.speed ?? 0.6);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Bones", "femur · tibia · fibula"], ["Arches", arches ? "highlighted" : "hidden"], ["Longest bone", "femur"]]} />
      <SimCanvas cameraPosition={[6, 4, 11]} target={[0, 3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Leg arches={arches} speed={speed} />
        {showLabels && (
          <>
            <Label text="Femur" position={[-2.6, 4.6, 0]} color="#fef3c7" size={0.5} />
            <Label text="Tibia + fibula" position={[2.6, 2.2, 0]} color="#fef3c7" size={0.5} />
            {arches && <Label text="Foot arches" position={[2.2, 0.9, 1.4]} color="#fcd34d" size={0.5} />}
          </>
        )}
      </SimCanvas>
    </div>
  );
}
