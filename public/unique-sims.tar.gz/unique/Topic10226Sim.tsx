// IBD, malabsorption & IBS — coiled intestines: healthy pink loops vs
// inflamed red ulcerated segments (Crohn's: patchy; UC: continuous from the
// rectum). Inflammation slider spreads the redness; skip lesions pulse.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "inflame", label: "Inflammation", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "disease", label: "Disease", kind: "select", min: 0, max: 0, step: 1, default: "Crohn's", options: ["Crohn's", "ulcerative colitis", "IBS"] },
];

export const UNIQUE_META = {
  title: "IBD & IBS",
  blurb: "Crohn's skip lesions vs ulcerative colitis' continuous red march vs IBS' spasm — inflammation slider spreads the damage.",
};

function Animator({ gut, elapsed, inflame }: {
  gut: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  inflame: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (gut.current) {
      // peristalsis wave ripples through the coils
      gut.current.children.forEach((c, i) => {
        const w = 1 + 0.06 * Math.sin(t * 3 - i * 0.55);
        c.scale.set(c.userData.sx * w, c.userData.sy, c.userData.sz * w);
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        if (m.emissiveIntensity !== undefined && c.userData.hot) {
          m.emissiveIntensity = 0.35 + 0.3 * Math.sin(t * 2.5 + i);
        }
      });
    }
  });
  return null;
}

export function Topic10226Sim(props: SimProps) {
  const inflame = Number(props.inflame ?? 55);
  const disease = String(props.disease ?? "Crohn's");
  const gut = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  // coil layout: 3 rows of loops
  const coils = useMemo(() => {
    const arr: { x: number; y: number; len: number; idx: number }[] = [];
    let idx = 0;
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 4; c++) {
        arr.push({ x: -2.4 + c * 1.6, y: 3.6 - r * 1.5, len: 1.35, idx: idx++ });
      }
    }
    return arr;
  }, []);

  const isHot = (idx: number): boolean => {
    const frac = inflame / 100;
    if (disease === "Crohn's") return idx % 3 === 0 && idx / 12 < frac + 0.3; // patchy skip lesions
    if (disease === "ulcerative colitis") return idx >= 12 * (1 - frac); // continuous from the end (rectum)
    return false; // IBS: no visible inflammation, spasm only
  };

  const spasm = disease === "IBS";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Disease", disease], ["Bowel inflamed", disease === "IBS" ? "none — functional" : `${Math.round(inflame)}%`], ["Pattern", disease === "Crohn's" ? "patchy skip lesions" : disease === "ulcerative colitis" ? "continuous from rectum" : "spasm, no damage"]]} />
      <SimCanvas cameraPosition={[0, 3, 12.5]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={gut}>
          {coils.map((c) => {
            const hot = isHot(c.idx);
            return (
              <mesh key={c.idx} position={[c.x, c.y, 0]} rotation={[0, 0, Math.PI / 2]}
                userData={{ sx: spasm ? 0.82 : 1, sy: 1, sz: spasm ? 0.82 : 1, hot }}>
                <cylinderGeometry args={[0.42, 0.42, c.len, 14]} />
                <meshStandardMaterial color={hot ? "#dc2626" : "#f9a8d4"} roughness={0.55} emissive={hot ? "#7f1d1d" : "#000000"} emissiveIntensity={hot ? 0.4 : 0} />
              </mesh>
            );
          })}
        </group>
        {/* colon frame around the coils */}
        <mesh position={[0, 2.35, -0.9]} castShadow>
          <boxGeometry args={[7.6, 5.4, 0.9]} />
          <meshStandardMaterial color={disease === "ulcerative colitis" && inflame > 40 ? "#f87171" : "#fda4af"} roughness={0.6} />
        </mesh>
        <mesh position={[0, 2.35, -0.35]}>
          <boxGeometry args={[6.2, 4.0, 0.9]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <Label text={disease === "Crohn's" ? "Crohn's: patchy red skip lesions" : disease === "ulcerative colitis" ? "UC: red march from the rectum up" : "IBS: squeezes hard but nothing is damaged"} position={[0, 6.3, 0]} size={0.5} color={disease === "IBS" ? "#fde047" : "#fca5a5"} />
        <Label text="Red = inflamed & ulcerated · malabsorption follows" position={[0, -1.1, 0]} size={0.44} color="#94a3b8" />
        <Animator gut={gut} elapsed={elapsed} inflame={inflame} />
      </SimCanvas>
    </div>
  );
}
