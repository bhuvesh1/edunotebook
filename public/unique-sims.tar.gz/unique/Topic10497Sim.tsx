"use client";
// Local Anesthesia: Nerve Blocks — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "block", label: "Nerve block", kind: "select", min: 0, max: 0, step: 1, default: "IAN block", options: ["IAN block", "PSA block", "Infraorbital block"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Local Anesthesia: Nerve Blocks",
  blurb: "Guide the needle to the target nerve — pick IAN, PSA or infraorbital and watch the numb zone light up.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const targets: any = { "IAN block": [-2.6, 1.9, 0.3], "PSA block": [2.4, 2.6, 0.3], "Infraorbital block": [1.2, 3.1, 0.9] };
    const tp = targets[p.block] || targets["IAN block"];
    const syr: any = g("anessyr");
    if (syr) {
      syr.position.x += (tp[0] + 1.6 - syr.position.x) * 0.05;
      syr.position.y += (tp[1] + 1.1 - syr.position.y) * 0.05;
      syr.position.z += (tp[2] - syr.position.z) * 0.05;
    }
    const zone: any = g("numbzone");
    if (zone) {
      zone.position.set(tp[0], tp[1] - 0.3, tp[2]);
      zone.scale.setScalar(0.8 + 0.15 * Math.sin(t * 3));
    }
    const nerve: any = g("ianerve");
    if (nerve) (nerve.material as any).emissiveIntensity = 0.4 + 0.3 * Math.sin(t * 2.5);
  });
  return null;
}

export function Topic10497Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const block = String(props.block ?? "IAN block");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, block };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Block", block],
          ["Target", block === "IAN block" ? "Mandibular foramen" : block === "PSA block" ? "Maxillary tuberosity" : "Infraorbital foramen"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <mesh position={[0, 0.9, 0]} rotation={[0, 0, Math.PI / 2]}>
            <torusGeometry args={[2, 0.55, 12, 24, Math.PI]} />
            <meshStandardMaterial color="#ded3ba" roughness={0.65} />
          </mesh>
          {[-1.5, -0.5, 0.5, 1.5].map((x, i) => (
            <mesh key={i} position={[x, 2.35, 0]}>
              <boxGeometry args={[0.8, 0.9, 0.8]} />
              <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
            </mesh>
          ))}
          <group name="ianerve">
            <Wire name="ianerve" points={[[-2.6, 1.9, 0.3], [-1, 1.7, 0.2], [0.8, 1.7, 0.2], [2.4, 1.9, 0.3]]} color="#fde047" radius={0.07} />
          </group>
          <group name="anessyr" position={[-1, 3, 0.3]} rotation={[0, 0, -0.9]}>
            <mesh>
              <cylinderGeometry args={[0.2, 0.2, 1.2, 14]} />
              <meshStandardMaterial color="#bae6fd" roughness={0.2} transparent opacity={0.8} />
            </mesh>
            <mesh position={[0, -0.95, 0]}>
              <cylinderGeometry args={[0.03, 0.015, 0.8, 8]} />
              <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.25} />
            </mesh>
          </group>
          <mesh name="numbzone" position={[-2.6, 1.6, 0.3]}>
            <sphereGeometry args={[0.7, 14, 14]} />
            <meshStandardMaterial color="#38bdf8" transparent opacity={0.3} roughness={0.2} />
          </mesh>
          <Label text="Inferior alveolar nerve" position={[0, 1.1, 0.2]} size={0.42} color="#fde047" />
          <Label text="Numb zone" position={[-2.6, 0.6, 0.3]} size={0.4} color="#38bdf8" />
          <Label text={block} position={[0, 3.9, 0]} size={0.46} />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
