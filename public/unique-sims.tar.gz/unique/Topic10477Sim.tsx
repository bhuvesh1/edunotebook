"use client";
// Classification of Periodontal Diseases — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Classification of Periodontal Diseases",
  blurb: "A rotating carousel of the four disease families — gingivitis through necrotizing disease.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const car: any = g("carousel");
    if (car) car.rotation.y = t * 0.35;
    for (let i = 0; i < 4; i++) {
      const card: any = g("card" + i);
      if (card && car) {
        const world = ((i * Math.PI) / 2 + car.rotation.y) % (Math.PI * 2);
        const facing = Math.cos(world);
        card.scale.setScalar(1 + Math.max(0, facing) * 0.18);
      }
    }
  });
  return null;
}

export function Topic10477Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Family 1", "Gingival diseases"],
          ["Family 2", "Chronic periodontitis"],
          ["Family 3", "Aggressive periodontitis"],
          ["Family 4", "Necrotizing diseases"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <group name="carousel">
            {[
              ["Gingivitis", "Gum only, reversible", "#f472b6", "a"],
              ["Chronic perio", "Slow bone loss", "#fb923c", "b"],
              ["Aggressive", "Rapid, young patients", "#ef4444", "c"],
              ["Necrotizing", "Painful, punched-out", "#7c2d12", "d"],
            ].map((c, i) => {
              const a = (i * Math.PI) / 2;
              return (
                <group key={i} name={"card" + i} position={[Math.sin(a) * 3.6, 1.8, Math.cos(a) * 3.6]} rotation={[0, a, 0]}>
                  <mesh>
                    <boxGeometry args={[2.6, 2.6, 0.25]} />
                    <meshStandardMaterial color={c[2]} roughness={0.5} />
                  </mesh>
                  <mesh position={[0, 0.5, 0.2]}>
                    <boxGeometry args={[0.7, 0.9, 0.3]} />
                    <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
                  </mesh>
                  <mesh position={[0, -0.55, 0.2]}>
                    <boxGeometry args={[1.4, 0.5, 0.3]} />
                    <meshStandardMaterial color={i === 0 ? "#e0808f" : i === 3 ? "#431407" : "#c08080"} roughness={0.6} />
                  </mesh>
                  <Label text={c[0]} position={[0, 1.75, 0.2]} size={0.4} />
                  <Label text={c[1]} position={[0, -1.65, 0.2]} size={0.32} />
                </group>
              );
            })}
          </group>
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
