"use client";

// HIV, hepatitis and infection control in dental practice.
// Germs jitter on the tray — run the sterilization cycle and watch
// them die under steam and UV. Standard precautions, every patient.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "steril", label: "Sterilization level", kind: "slider", min: 0, max: 100, step: 5, default: 80, unit: "%" },
  { key: "hazard", label: "Blood-borne hazard", kind: "select", min: 0, max: 0, step: 1, default: "Hepatitis B", options: ["HIV", "Hepatitis B", "Hepatitis C"] },
];

export const UNIQUE_META = {
  title: "Infection Control: HIV & Hepatitis",
  blurb: "Germs on the tray die as sterilization rises — autoclave steam, UV light, mask, gloves: standard precautions for all.",
};

type Ref = { current: THREE.Group | null };

function Animator({ germs, uv, steam, elapsed, steril }: { germs: Ref; uv: { current: THREE.Mesh | null }; steam: Ref; elapsed: { current: number }; steril: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const e = elapsed.current;
    const kill = steril / 100;
    germs.current?.children.forEach((m, i) => {
      const s = Math.max(0.001, 1 - kill);
      m.scale.set(s, s, s);
      m.position.y = 1.35 + Math.sin(e * 3 + i * 1.7) * 0.06 * (1 - kill);
      m.rotation.y = e * (0.5 + (i % 3) * 0.3);
    });
    if (uv.current) {
      const mat = uv.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = 0.8 + 0.7 * Math.abs(Math.sin(e * 4));
    }
    if (steam.current) {
      steam.current.visible = steril > 40;
      steam.current.children.forEach((m, i) => {
        const t = (e * 0.7 + i / 6) % 1;
        m.position.y = 2.6 + t * 1.4;
        const ms = (1 - t) * 0.9 + 0.2;
        m.scale.set(ms, ms, ms);
      });
    }
  });
  return null;
}

export function Topic10567Sim(props: SimProps) {
  const steril = Number(props.steril ?? 80);
  const hazard = String(props.hazard ?? "Hepatitis B");
  const remaining = Math.max(0, 100 - steril);

  const germs = useRef<THREE.Group>(null!);
  const uv = useRef<THREE.Mesh>(null!);
  const steam = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const germPos = useMemo(() => {
    let s = 21;
    const rnd = () => (s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296;
    return Array.from({ length: 14 }, () => [
      -1 + rnd() * 4.4,
      1.35,
      -0.9 + rnd() * 1.8,
    ] as [number, number, number]);
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Hazard", hazard],
          ["Germs remaining", `${remaining.toFixed(0)}%`],
          ["Rule", "Standard precautions — every patient"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 11.5]} target={[0.4, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* work counter */}
        <mesh position={[0.4, 0.55, 0]} receiveShadow castShadow>
          <boxGeometry args={[6.4, 1.1, 3.2]} />
          <meshStandardMaterial color="#334155" roughness={0.8} />
        </mesh>

        {/* autoclave */}
        <group position={[-1.9, 0, 0]}>
          <mesh position={[0, 1.85, 0]} castShadow>
            <boxGeometry args={[1.7, 1.5, 1.5]} />
            <meshStandardMaterial color="#9ca3af" roughness={0.35} metalness={0.6} />
          </mesh>
          <mesh position={[0, 1.85, 0.78]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.5, 0.5, 0.12, 20]} />
            <meshStandardMaterial color="#6b7280" roughness={0.4} metalness={0.5} />
          </mesh>
          <mesh position={[0, 2.62, 0]}>
            <boxGeometry args={[0.5, 0.08, 0.2]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.4} />
          </mesh>
        </group>
        {/* steam */}
        <group ref={steam} position={[-1.9, 0, 0]}>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[(i - 2.5) * 0.25, 2.6, 0]}>
              <sphereGeometry args={[0.16, 10, 10]} />
              <meshStandardMaterial color="#e2e8f0" transparent opacity={0.55} roughness={1} />
            </mesh>
          ))}
        </group>

        {/* UV light bar */}
        <mesh ref={uv} position={[0.9, 3.35, 0]} castShadow>
          <boxGeometry args={[2.6, 0.14, 0.32]} />
          <meshStandardMaterial color="#1e3a8a" emissive="#3b82f6" emissiveIntensity={1} />
        </mesh>

        {/* mask */}
        <group position={[1.7, 1.3, 0.7]}>
          <mesh castShadow>
            <boxGeometry args={[0.72, 0.36, 0.08]} />
            <meshStandardMaterial color="#93c5fd" roughness={0.7} />
          </mesh>
          {[-0.2, 0.2].map((y) => (
            <mesh key={y} position={[0, y, -0.12]}>
              <boxGeometry args={[0.8, 0.03, 0.03]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.7} />
            </mesh>
          ))}
        </group>

        {/* sanitizer bottle */}
        <group position={[2.6, 0, -0.4]}>
          <mesh position={[0, 1.45, 0]} castShadow>
            <cylinderGeometry args={[0.22, 0.22, 0.7, 14]} />
            <meshStandardMaterial color="#e0f2fe" roughness={0.3} />
          </mesh>
          <mesh position={[0, 1.9, 0]}>
            <boxGeometry args={[0.1, 0.22, 0.1]} />
            <meshStandardMaterial color="#0284c7" roughness={0.4} />
          </mesh>
        </group>

        {/* gloves */}
        {[-0.15, 0.35].map((x, i) => (
          <mesh key={i} position={[x, 1.16, 1.0]} rotation={[0, i * 0.4, 0]} castShadow>
            <boxGeometry args={[0.42, 0.08, 0.55]} />
            <meshStandardMaterial color="#fef3c7" roughness={0.7} />
          </mesh>
        ))}

        {/* germs */}
        <group ref={germs}>
          {germPos.map((p, i) => (
            <mesh key={i} position={p} castShadow>
              <icosahedronGeometry args={[0.17, 0]} />
              <meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={0.5} roughness={0.6} />
            </mesh>
          ))}
        </group>

        <Label text="Autoclave (steam)" position={[-1.9, 3.1, 0]} size={0.45} color="#e2e8f0" />
        <Label text="UV light" position={[0.9, 3.75, 0]} size={0.42} color="#93c5fd" />
        <Label text="Mask + gloves" position={[1.7, 0.75, 0.7]} size={0.4} color="#bfdbfe" />
        <Label text="Sanitizer" position={[2.6, 0.75, -0.4]} size={0.4} color="#7dd3fc" />
        {steril >= 100 && (
          <Label text="STERILE — safe to use" position={[0.4, 4.3, 0]} size={0.55} color="#22c55e" />
        )}
        <Animator germs={germs} uv={uv} steam={steam} elapsed={elapsed} steril={steril} />
      </SimCanvas>
    </div>
  );
}
