"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dtype", label: "Disorder", kind: "select", min: 0, max: 0, step: 1, default: "normal", options: ["normal", "ITP", "hemophilia"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Bleeding Disorders & Clotting",
  blurb: "Platelets rush to plug a vessel cut, then fibrin mesh locks the clot; see it fail in ITP and hemophilia.",
};

function Animator({ root, plt, fibr, elapsed, speed, nPlt, noFibrin }: { root: RefObject<THREE.Group>; plt: RefObject<THREE.Group>; fibr: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; nPlt: number; noFibrin: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const q = (t * 0.45) % 1;
    if (plt.current) {
      plt.current.children.forEach((m, i) => {
        const a = i * 2.2;
        const sx = -4.5 + (q * 4.2);
        m.position.set(sx + Math.sin(a) * (1 - q) * 0.8, 2.6 - q * 0.9 + Math.cos(a) * (1 - q) * 0.7, Math.sin(a * 2) * (1 - q) * 0.8);
        m.rotation.x += delta * 3;
      });
    }
    if (fibr.current) {
      fibr.current.visible = !noFibrin;
      fibr.current.children.forEach((m, i) => {
        m.scale.y = q > 0.55 ? 1 : 0.001;
        m.rotation.z = Math.sin(t * 1.5 + i) * 0.2;
      });
    }
  });
  return null;
}

export function Topic10092Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const dtype = String(props.dtype ?? "normal");
  const nPlt = dtype === "ITP" ? 3 : 10;
  const noFibrin = dtype === "hemophilia";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const plt = useRef<THREE.Group>(null!);
  const fibr = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Disorder", dtype],
          ["Defect", dtype === "normal" ? "none" : dtype === "ITP" ? "low platelets" : "factor VIII/IX \u2014 no fibrin"],
          ["Bleeding", dtype === "normal" ? "stops" : "prolonged"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[-2.5, 2, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[1.1, 1.1, 5, 20, 1, true]} />
            <meshStandardMaterial color="#f9a8d4" transparent opacity={0.35} roughness={0.6} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[2.5, 2, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[1.1, 1.1, 5, 20, 1, true]} />
            <meshStandardMaterial color="#f9a8d4" transparent opacity={0.35} roughness={0.6} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[0, 1.1, 0]}><boxGeometry args={[1.2, 0.3, 1.6]} /><meshStandardMaterial color="#ef4444" emissive="#b91c1d" emissiveIntensity={0.6} /></mesh>
          <Label text="vessel cut" position={[0, 0.4, 0]} size={0.42} color="#f87171" />
          <group ref={plt}>
            {Array.from({ length: nPlt }).map((_, i) => (
              <mesh key={i} castShadow>
                <cylinderGeometry args={[0.26, 0.26, 0.12, 12]} />
                <meshStandardMaterial color="#fbbf24" emissive="#d97706" emissiveIntensity={0.4} roughness={0.4} />
              </mesh>
            ))}
          </group>
          <Label text={`platelets (\u00d7${nPlt})`} position={[-4.6, 3.6, 0]} size={0.42} color="#fbbf24" />
          <group ref={fibr} position={[0, 1.7, 0]}>
            {Array.from({ length: 8 }).map((_, i) => (
              <mesh key={i} position={[(i % 4 - 1.5) * 0.5, Math.floor(i / 4) * 0.5 - 0.2, (i % 2) * 0.5 - 0.25]} rotation={[0.4, 0, 0.9 + i * 0.35]}>
                <boxGeometry args={[0.07, 1.5, 0.07]} /><meshStandardMaterial color="#fef3c7" roughness={0.6} />
              </mesh>
            ))}
          </group>
          <Label text={noFibrin ? "no fibrin mesh \u2014 keeps bleeding!" : "fibrin mesh locks the plug"} position={[2.6, 3.4, 0]} size={0.42} color={noFibrin ? "#f87171" : "#fef3c7"} />
        </group>
        <Animator root={root} plt={plt} fibr={fibr} elapsed={elapsed} speed={speed} nPlt={nPlt} noFibrin={noFibrin} />
      </SimCanvas>
    </div>
  );
}
