"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "layer", label: "Highlight layer", kind: "select", min: 0, max: 0, step: 1, default: "cementum", options: ["cementum", "cej", "dentin"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Cementum: types, functions, CEJ",
  blurb: "The tooth's root is wrapped in cementum — find the cementoenamel junction where enamel hands over to cementum.",
};

function CementumTooth({ layer, speed, showLabels }: { layer: string; speed: number; showLabels: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) g.current.rotation.y = elapsed.current * 0.5;
  });
  const hi = (name: string) => (layer === name ? 1.15 : 1);

  return (
    <group ref={g}>
      {/* crown enamel */}
      <mesh position={[0, 1.9, 0]} castShadow scale={hi("dentin")}>
        <boxGeometry args={[2.1, 1.7, 1.9]} />
        <meshStandardMaterial color="#fef9c3" roughness={0.25} />
      </mesh>
      {/* root dentin core */}
      <mesh position={[0, -1.3, 0]} castShadow scale={hi("dentin")}>
        <cylinderGeometry args={[0.95, 0.3, 4.6, 20]} />
        <meshStandardMaterial color="#fde68a" roughness={0.4} />
      </mesh>
      {/* CEMENTUM coating over the root — the star of the show */}
      <mesh position={[0, -1.3, 0]} scale={[hi("cementum"), 1, hi("cementum")]}>
        <cylinderGeometry args={[1.02, 0.36, 4.62, 20, 1, true]} />
        <meshStandardMaterial
          color={layer === "cementum" ? "#fb923c" : "#fdba74"}
          roughness={0.55}
          side={THREE.DoubleSide}
          emissive={layer === "cementum" ? "#7c2d12" : "#000000"}
          emissiveIntensity={0.45}
        />
      </mesh>
      {/* CEJ — the scalloped junction line */}
      <mesh position={[0, 1.02, 0]} scale={hi("cej")}>
        <torusGeometry args={[1.0, layer === "cej" ? 0.09 : 0.05, 10, 32]} />
        <meshBasicMaterial color={layer === "cej" ? "#facc15" : "#a16207"} />
      </mesh>
      {/* Sharpey fiber stubs anchoring into cementum */}
      {Array.from({ length: 16 }).map((_, i) => {
        const a = (i / 16) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 1.25, -1.3 + (i % 4) * 0.9 - 1.2, Math.sin(a) * 1.25]} rotation={[0, -a, 1.1]}>
            <cylinderGeometry args={[0.03, 0.03, 0.5, 6]} />
            <meshBasicMaterial color="#fef3c7" transparent opacity={0.8} />
          </mesh>
        );
      })}
      {/* cementocyte dots inside cementum */}
      {Array.from({ length: 10 }).map((_, i) => {
        const a = (i / 10) * Math.PI * 2;
        return (
          <mesh key={"c" + i} position={[Math.cos(a) * 1.0, -2.6 + (i % 5) * 0.8, Math.sin(a) * 1.0]}>
            <sphereGeometry args={[0.07, 8, 8]} />
            <meshBasicMaterial color="#7c2d12" />
          </mesh>
        );
      })}
      {showLabels && (
        <>
          <Text position={[3.2, 1.9, 0]} fontSize={0.4} color="#fef9c3">Enamel (crown)</Text>
          <Text position={[3.2, 1.02, 0]} fontSize={0.42} color="#facc15">CEJ — cementoenamel junction</Text>
          <Text position={[3.2, -1.3, 0]} fontSize={0.42} color="#fdba74">Cementum coats the root</Text>
          <Text position={[-3.4, -1.3, 0]} fontSize={0.4} color="#fde68a">Dentin core</Text>
          <Text position={[0, 4.2, 0]} fontSize={0.42} color="#fef3c7" maxWidth={10}>
            {layer === "cementum" && "Cementum anchors the tooth — PDL fibers plug into it like velcro."}
            {layer === "cej" && "CEJ: where enamel meets cementum — a common sensitive spot."}
            {layer === "dentin" && "Under the cementum lies dentin — softer than enamel."}
          </Text>
        </>
      )}
    </group>
  );
}

export function Topic10377Sim(props: SimProps) {
  const layer = String(props.layer ?? "cementum");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const names: Record<string, string> = { cementum: "Cementum", cej: "CEJ", dentin: "Dentin core" };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Highlight", names[layer] ?? layer],
          ["Cementum is", "50% mineral — softer than dentin"],
          ["Made by", "cementoblasts"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.5, 11]} target={[0, -0.3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -4.4, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <CementumTooth layer={layer} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
