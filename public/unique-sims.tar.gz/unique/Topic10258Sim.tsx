// Minimally invasive surgery: laparoscopy and endoscopy basics.
// A laparoscope slides through a tiny port into the inflated abdomen, its
// camera light sweeping the organs; switch to endoscope to travel down the
// food pipe instead.

"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "tool", label: "Instrument", kind: "select", min: 0, max: 0, step: 1, default: "laparoscope", options: ["laparoscope", "endoscope"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Keyhole Surgery: Laparoscope & Endoscope",
  blurb: "Tiny camera, tiny cuts — slide a laparoscope into the belly or an endoscope down the food pipe and look around.",
};

function Animator({
  group, scope, light, grasper, elapsed, speed, tool,
}: {
  group: React.RefObject<THREE.Group>;
  scope: React.RefObject<THREE.Group>;
  light: React.RefObject<THREE.SpotLight>;
  grasper: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  tool: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = tool === "laparoscope" ? Math.sin(t * 0.2) * 0.25 : 0;
    if (scope.current) {
      if (tool === "laparoscope") {
        // surgeon sweeps the camera: tip pans side to side, slides in/out
        scope.current.rotation.z = 0.55 + Math.sin(t * 0.7) * 0.35;
        scope.current.position.y = 3.4 + Math.sin(t * 0.45) * 0.35;
      } else {
        // endoscope advances down the esophagus
        const ph = (t % 12) / 12;
        scope.current.position.y = 4.6 - ph * 3.4;
      }
    }
    if (light.current && light.current.target) {
      const tip = new THREE.Vector3();
      scope.current?.getWorldPosition(tip);
      light.current.target.position.copy(tip).add(new THREE.Vector3(0, -1.5, 0));
      light.current.target.updateMatrixWorld();
    }
    if (grasper.current) {
      // jaws open and close rhythmically
      const open = 0.15 + 0.35 * (0.5 + 0.5 * Math.sin(t * 2.2));
      grasper.current.children.forEach((j, i) => {
        j.rotation.z = (i === 0 ? 1 : -1) * open;
      });
    }
  });
  return null;
}

export function Topic10258Sim(props: SimProps) {
  const tool = String(props.tool ?? "laparoscope");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const scope = useRef<THREE.Group>(null!);
  const light = useRef<THREE.SpotLight>(null!);
  const grasper = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const beamGeo = useMemo(() => new THREE.ConeGeometry(0.9, 2.6, 20, 1, true), []);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Instrument", tool === "laparoscope" ? "Laparoscope (belly)" : "Endoscope (food pipe)"], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.8, 10.5]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {tool === "laparoscope" ? (
            <>
              {/* inflated abdominal dome */}
              <mesh position={[0, 1.9, 0]} scale={[1.6, 1.0, 1.2]} castShadow>
                <sphereGeometry args={[2.0, 32, 20, 0, Math.PI * 2, 0, Math.PI / 2]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} transparent opacity={0.5} side={THREE.DoubleSide} />
              </mesh>
              {/* liver inside */}
              <mesh position={[-0.8, 1.9, 0.3]} scale={[1.1, 0.6, 0.8]} castShadow>
                <sphereGeometry args={[0.7, 20, 14]} />
                <meshStandardMaterial color="#7c2d12" roughness={0.5} />
              </mesh>
              {/* bowel loops */}
              <mesh position={[0.8, 1.4, 0.2]} castShadow>
                <torusGeometry args={[0.45, 0.18, 12, 24]} />
                <meshStandardMaterial color="#fcd34d" roughness={0.5} />
              </mesh>
              {/* gallbladder target */}
              <mesh position={[-0.7, 1.5, 0.75]} scale={[0.7, 1, 0.7]} castShadow>
                <sphereGeometry args={[0.28, 16, 12]} />
                <meshStandardMaterial color="#4ade80" roughness={0.4} emissive="#166534" emissiveIntensity={0.5} />
              </mesh>
              {/* port + laparoscope */}
              <mesh position={[-2.2, 3.6, 0.6]} rotation={[0, 0, 0.5]} castShadow>
                <cylinderGeometry args={[0.18, 0.18, 0.5, 12]} />
                <meshStandardMaterial color="#94a3b8" roughness={0.4} metalness={0.6} />
              </mesh>
              <group ref={scope} position={[-2.2, 3.4, 0.6]} rotation={[0, 0, 0.55]}>
                <mesh position={[0, 0.9, 0]} castShadow>
                  <cylinderGeometry args={[0.09, 0.09, 2.6, 12]} />
                  <meshStandardMaterial color="#cbd5e1" roughness={0.3} metalness={0.8} />
                </mesh>
                <mesh position={[0, 2.35, 0]} castShadow>
                  <boxGeometry args={[0.5, 0.7, 0.4]} />
                  <meshStandardMaterial color="#1e293b" roughness={0.4} />
                </mesh>
                {/* camera light beam */}
                <mesh geometry={beamGeo} position={[0, -1.6, 0]} rotation={[Math.PI, 0, 0]}>
                  <meshBasicMaterial color="#fef9c3" transparent opacity={0.16} side={THREE.DoubleSide} depthWrite={false} />
                </mesh>
                <spotLight ref={light} position={[0, -0.4, 0]} angle={0.5} penumbra={0.6} intensity={30} color="#fef9c3" distance={8} />
              </group>
              {/* grasper jaws near gallbladder */}
              <group ref={grasper} position={[0.6, 1.9, 0.9]}>
                <mesh position={[0, 0.5, 0]} rotation={[0, 0, -0.4]} castShadow>
                  <cylinderGeometry args={[0.05, 0.05, 1.2, 8]} />
                  <meshStandardMaterial color="#94a3b8" metalness={0.7} roughness={0.3} />
                </mesh>
                <mesh position={[-0.14, -0.18, 0]} castShadow>
                  <boxGeometry args={[0.28, 0.1, 0.1]} />
                  <meshStandardMaterial color="#64748b" metalness={0.7} roughness={0.3} />
                </mesh>
                <mesh position={[0.14, -0.18, 0]} castShadow>
                  <boxGeometry args={[0.28, 0.1, 0.1]} />
                  <meshStandardMaterial color="#64748b" metalness={0.7} roughness={0.3} />
                </mesh>
              </group>
              <Label text="Laparoscope (camera)" position={[-3.4, 4.6, 0.6]} size={0.5} color="#e2e8f0" />
              <Label text="Tiny 1 cm port" position={[-3.5, 2.9, 0.6]} size={0.5} color="#94a3b8" />
              <Label text="Gallbladder" position={[-0.7, 0.85, 0.75]} size={0.5} color="#86efac" />
            </>
          ) : (
            <>
              {/* throat + esophagus tube */}
              <mesh position={[0, 4.6, 0]} castShadow>
                <sphereGeometry args={[0.55, 20, 14]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              <mesh position={[0, 2.6, 0]} castShadow>
                <cylinderGeometry args={[0.5, 0.5, 4.2, 20, 1, true]} />
                <meshStandardMaterial color="#f0abfc" roughness={0.5} transparent opacity={0.55} side={THREE.DoubleSide} />
              </mesh>
              {/* stomach at the bottom */}
              <mesh position={[0.4, 0.2, 0]} scale={[1, 0.8, 0.8]} castShadow>
                <sphereGeometry args={[0.8, 24, 18]} />
                <meshStandardMaterial color="#fb923c" roughness={0.5} />
              </mesh>
              <group ref={scope} position={[0, 4.6, 0]}>
                <mesh position={[0, 1.1, 0]} castShadow>
                  <cylinderGeometry args={[0.12, 0.12, 3.2, 12]} />
                  <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
                </mesh>
                <mesh position={[0, -0.6, 0]} castShadow>
                  <sphereGeometry args={[0.16, 14, 10]} />
                  <meshStandardMaterial color="#fef9c3" emissive="#facc15" emissiveIntensity={1.2} />
                </mesh>
                <mesh geometry={beamGeo} position={[0, -1.9, 0]} rotation={[Math.PI, 0, 0]}>
                  <meshBasicMaterial color="#fef9c3" transparent opacity={0.16} side={THREE.DoubleSide} depthWrite={false} />
                </mesh>
                <spotLight ref={light} position={[0, -0.6, 0]} angle={0.5} penumbra={0.6} intensity={30} color="#fef9c3" distance={8} />
              </group>
              <Label text="Endoscope tip (light)" position={[1.6, 3.4, 0]} size={0.5} color="#7dd3fc" />
              <Label text="Stomach" position={[1.9, 0.2, 0]} size={0.5} color="#fdba74" />
            </>
          )}
        </group>
        <Animator group={group} scope={scope} light={light} grasper={grasper} elapsed={elapsed} speed={speed} tool={tool} />
      </SimCanvas>
    </div>
  );
}
