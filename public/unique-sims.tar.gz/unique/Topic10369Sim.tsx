"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "age", label: "Child's age", kind: "slider", min: 2, max: 12, step: 0.5, default: 5, unit: " yrs" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Tooth morphology: deciduous dentition",
  blurb: "Baby teeth are smaller, whiter, and spaced apart — drag the age slider to watch them shed as permanent teeth push up from below.",
};

const MILK = "#fffef7";
const PERM = "#fef9c3";
const GUM = "#e88ca0";

// shed ages for the 5 shown teeth (central, lateral, canine, molar1, molar2)
const SHED = [6, 7, 10, 9, 11];

function BabyTooth({ x, kind, shedAge, age, speed }: { x: number; kind: string; shedAge: number; age: number; speed: number }) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const gone = age >= shedAge + 1;
  const wobble = age >= shedAge - 1 && age < shedAge + 1;
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) {
      const target = gone ? 0.001 : 1;
      const s = THREE.MathUtils.lerp(g.current.scale.x, target, 0.06);
      g.current.scale.setScalar(Math.max(s, 0.001));
      g.current.position.y = 0.6 + (wobble ? Math.sin(elapsed.current * 9) * 0.08 : 0);
      g.current.rotation.z = wobble ? Math.sin(elapsed.current * 9) * 0.12 : 0;
    }
  });
  return (
    <group position={[x, 0.6, 0.6]}>
      <group ref={g} scale={[0.72, 0.72, 0.72]}>
        <mesh castShadow>
          <boxGeometry args={[1, 1.05, kind === "molar" ? 0.95 : 0.6]} />
          <meshStandardMaterial color={MILK} roughness={0.2} />
        </mesh>
        {kind === "molar" && (
          <mesh position={[0, 0.62, 0]} castShadow>
            <boxGeometry args={[0.8, 0.3, 0.75]} />
            <meshStandardMaterial color={MILK} roughness={0.2} />
          </mesh>
        )}
        {/* resorbing roots */}
        <mesh position={[0, -1, 0]} castShadow>
          <coneGeometry args={[0.18 * Math.max(0.2, 1 - (age - 4) * 0.25), 1.1, 10]} />
          <meshStandardMaterial color="#fde68a" roughness={0.4} />
        </mesh>
      </group>
    </group>
  );
}

function PermanentTooth({ x, kind, eruptAge, age, speed }: { x: number; kind: string; eruptAge: number; age: number; speed: number }) {
  const g = useRef<THREE.Group>(null!);
  const progress = THREE.MathUtils.clamp((age - eruptAge + 1) / 2.5, 0, 1);
  useFrame(() => {
    if (g.current) {
      const eased = progress * progress * (3 - 2 * progress);
      g.current.position.y = THREE.MathUtils.lerp(-2.6, 0.6, eased);
      g.current.visible = progress > 0.02;
    }
  });
  return (
    <group position={[x, -2.6, 0.6]}>
      <group ref={g} visible={false}>
        <mesh castShadow>
          <boxGeometry args={[1.15, 1.35, kind === "molar" ? 1.15 : 0.6]} />
          <meshStandardMaterial color={PERM} roughness={0.25} />
        </mesh>
        {kind === "molar" &&
          [[-0.3, -0.3], [0.3, -0.3], [-0.3, 0.3], [0.3, 0.3]].map(([cx, cz], i) => (
            <mesh key={i} position={[cx, 0.78, cz]} castShadow>
              <coneGeometry args={[0.26, 0.55, 4]} />
              <meshStandardMaterial color={PERM} roughness={0.25} />
            </mesh>
          ))}
        {[0, 1].map((i) => (
          <mesh key={i} position={[(i - 0.5) * 0.5, -1.6, 0]} castShadow>
            <coneGeometry args={[0.19, 1.5, 10]} />
            <meshStandardMaterial color="#fde68a" roughness={0.4} />
          </mesh>
        ))}
      </group>
    </group>
  );
}

const KIND_OF = ["incisor", "incisor", "canine", "molar", "molar"];

export function Topic10369Sim(props: SimProps) {
  const age = Number(props.age ?? 5);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const shedCount = SHED.filter((s) => age >= s).length;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Age", `${age.toFixed(1)} yrs`],
          ["Baby teeth shed", `${shedCount} / 5`],
          ["Total deciduous", "20 (10 per arch)"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 13]} target={[0, 0.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.4, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* gum with wider baby-tooth spacing */}
        <mesh position={[0, -0.6, 0]} scale={[1.5, 0.5, 1]} castShadow>
          <torusGeometry args={[4.6, 1.5, 16, 48, Math.PI]} />
          <meshStandardMaterial color={GUM} roughness={0.6} />
        </mesh>
        {KIND_OF.map((kind, i) => (
          <BabyTooth key={"b" + i} x={-6.4 + i * 3.2} kind={kind} shedAge={SHED[i]} age={age} speed={speed} />
        ))}
        {KIND_OF.map((kind, i) => (
          <PermanentTooth key={"p" + i} x={-6.4 + i * 3.2} kind={kind} eruptAge={SHED[i]} age={age} speed={speed} />
        ))}
        {showLabels && (
          <>
            <Text position={[0, 3.4, 0]} fontSize={0.44} color="#fef3c7" maxWidth={9}>
              {age < 6 ? "Baby teeth: small, white, spaced out" : "Permanent teeth erupt as roots resorb"}
            </Text>
            <Text position={[-8.2, -1.6, 0]} fontSize={0.4} color="#fde68a">Permanent bud below</Text>
          </>
        )}
      </SimCanvas>
    </div>
  );
}
