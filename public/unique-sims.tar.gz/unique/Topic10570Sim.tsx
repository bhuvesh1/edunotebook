"use client";

// Common surgical conditions: hernias, thyroid swellings, breast lumps.
// Three stations, one highlighted: a hernia bulge that grows when you
// strain, a swollen thyroid, a palpable breast lump.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "hernia", options: ["hernia", "thyroid", "lump"] },
  { key: "strain", label: "Strain / cough", kind: "slider", min: 0, max: 100, step: 5, default: 40, unit: "%" },
];

export const UNIQUE_META = {
  title: "Hernias, Thyroid Swellings & Breast Lumps",
  blurb: "A hernia bulge that grows when you strain, a swollen thyroid gland, a breast lump — know the lumps surgeons see.",
};

type Ref = { current: THREE.Group | null };

function Animator({ bulge, lump, elapsed, strain }: { bulge: Ref; lump: Ref; elapsed: { current: number }; strain: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const e = elapsed.current;
    if (bulge.current) {
      const s = (0.75 + (strain / 100) * 0.75) * (1 + 0.1 * Math.sin(e * 2.6));
      bulge.current.scale.set(s, s, s);
    }
    if (lump.current) {
      const s = 1 + 0.08 * Math.sin(e * 3);
      lump.current.scale.set(s, s, s);
    }
  });
  return null;
}

export function Topic10570Sim(props: SimProps) {
  const condition = String(props.condition ?? "hernia");
  const strain = Number(props.strain ?? 40);

  const bulge = useRef<THREE.Group>(null!);
  const lump = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const dim = (key: string) => (condition === key ? 1 : 0.3);
  const facts: Record<string, string> = {
    hernia: "Inguinal hernia: bowel pushes through the abdominal wall — grows on coughing/straining",
    thyroid: "Goitre: enlarged thyroid in the neck — moves up when you swallow",
    lump: "Breast lump: any new lump needs prompt examination — never ignore it",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", facts[condition].split(":")[0]],
          ["Key fact", facts[condition]],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 13]} target={[0, 2.1, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* hernia station */}
        <group position={[-3.6, 0, 0]} scale={dim("hernia")}>
          <mesh position={[0, 2.1, 0]} castShadow>
            <boxGeometry args={[2.2, 2.6, 0.6]} />
            <meshStandardMaterial color="#eab88f" roughness={0.7} transparent opacity={dim("hernia")} />
          </mesh>
          <mesh position={[0.3, 1.5, 0.1]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.34, 0.34, 0.7, 16]} />
            <meshStandardMaterial color="#7c2d12" roughness={0.8} />
          </mesh>
          <group ref={bulge} position={[0.3, 1.5, 0.6]}>
            <mesh castShadow>
              <sphereGeometry args={[0.5, 20, 20]} />
              <meshStandardMaterial color="#f2a488" roughness={0.55} transparent opacity={dim("hernia")} />
            </mesh>
          </group>
        </group>

        {/* thyroid station */}
        <group position={[0, 0, 0]} scale={dim("thyroid")}>
          <mesh position={[0, 2.6, 0]} castShadow>
            <cylinderGeometry args={[0.45, 0.5, 1.5, 16]} />
            <meshStandardMaterial color="#eab88f" roughness={0.7} transparent opacity={dim("thyroid")} />
          </mesh>
          <mesh position={[0, 3.75, 0]} castShadow>
            <sphereGeometry args={[0.55, 20, 20]} />
            <meshStandardMaterial color="#eab88f" roughness={0.7} transparent opacity={dim("thyroid")} />
          </mesh>
          {[-0.3, 0.3].map((x) => (
            <mesh key={x} position={[x, 2.75, 0.32]} scale={[0.85, 1.25, 0.6]} castShadow>
              <sphereGeometry args={[0.36, 18, 18]} />
              <meshStandardMaterial color="#b45309" roughness={0.55} transparent opacity={dim("thyroid")} />
            </mesh>
          ))}
        </group>

        {/* breast lump station */}
        <group position={[3.6, 0, 0]} scale={dim("lump")}>
          <mesh position={[0, 1.9, 0]} scale={[1, 0.72, 0.72]} castShadow>
            <sphereGeometry args={[0.95, 22, 22]} />
            <meshStandardMaterial color="#eab88f" roughness={0.7} transparent opacity={dim("lump")} />
          </mesh>
          <group ref={lump} position={[0.15, 2.35, 0.52]}>
            <mesh castShadow>
              <sphereGeometry args={[0.28, 16, 16]} />
              <meshStandardMaterial color="#dc2626" roughness={0.5} transparent opacity={dim("lump")} />
            </mesh>
          </group>
        </group>

        <Label text="Inguinal hernia" position={[-3.6, 3.9, 0]} size={0.45} color={condition === "hernia" ? "#fdba74" : "#64748b"} />
        <Label text="Thyroid swelling (goitre)" position={[0, 4.7, 0]} size={0.45} color={condition === "thyroid" ? "#fdba74" : "#64748b"} />
        <Label text="Breast lump" position={[3.6, 3.3, 0]} size={0.45} color={condition === "lump" ? "#fca5a5" : "#64748b"} />
        <Label text={facts[condition]} position={[0, 0.35, 2.5]} size={0.44} color="#fbbf24" />
        <Animator bulge={bulge} lump={lump} elapsed={elapsed} strain={strain} />
      </SimCanvas>
    </div>
  );
}
