// Antimalarials & antiparasitics: a mosquito circles while crescent malaria
// parasites swim in blood and a roundworm wriggles — the drug clears them.
"use client";

import { useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Antiparasitic dose", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Antimalarials & anthelmintics",
  blurb: "A mosquito circles, crescent malaria parasites swim in blood, a worm wriggles — the drug clears them.",
};

const N_PAR = 8;

function Animator({ mozzie, parasites, worm, elapsed, dose, setTick }: {
  mozzie: React.RefObject<THREE.Group>;
  parasites: React.RefObject<(THREE.Mesh | null)[]>;
  worm: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  dose: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    if (mozzie.current) {
      mozzie.current.position.set(Math.cos(t * 0.9) * 3.4, 4.4 + Math.sin(t * 2.2) * 0.3, Math.sin(t * 0.9) * 2);
      mozzie.current.rotation.y = -t * 0.9;
    }
    parasites.current.forEach((p, i) => {
      if (!p) return;
      const alive = ((i * 41) % 10) / 10 > k * 0.9;
      p.visible = alive;
      if (!alive) return;
      const ang = t * 0.8 + i * 0.8;
      p.position.set(-3.2 + Math.cos(ang) * 1.2, 1.4 + Math.sin(ang * 1.4) * 0.5, Math.sin(ang) * 0.9);
      p.rotation.z = ang;
    });
    if (worm.current) {
      const energy = 1 - k * 0.9;
      worm.current.rotation.z = Math.sin(t * (1 + energy * 3)) * 0.35 * energy;
      worm.current.position.y = 1.2 + Math.sin(t * 2) * 0.1 * energy;
      (worm.current.material as THREE.MeshStandardMaterial).opacity = 0.35 + energy * 0.65;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(k * 100)); }
  });
  return null;
}

export function Topic10120Sim(props: SimProps) {
  const dose = Number(props.dose ?? 60);
  const showLabels = String(props.detail ?? "on") === "on";
  const mozzie = useRef<THREE.Group>(null!);
  const parasites = useRef<(THREE.Mesh | null)[]>([]);
  const worm = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const wormCurve = useMemo(
    () => new THREE.CatmullRomCurve3([
      new THREE.Vector3(-1.2, 0, 0),
      new THREE.Vector3(-0.4, 0.5, 0.2),
      new THREE.Vector3(0.4, -0.3, -0.2),
      new THREE.Vector3(1.2, 0.2, 0),
    ]),
    []
  );
  const wormGeo = useMemo(() => new THREE.TubeGeometry(wormCurve, 32, 0.16, 10), [wormCurve]);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Parasites cleared", `${tick}%`],
          ["Worm", tick > 70 ? "paralysed" : tick > 30 ? "weakening" : "active"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* mosquito */}
        <group ref={mozzie}>
          <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
            <capsuleGeometry args={[0.14, 0.7, 6, 10]} />
            <meshStandardMaterial color="#475569" roughness={0.5} />
          </mesh>
          {[-0.5, 0.5].map((s, i) => (
            <mesh key={i} position={[0, 0.18, s * 0.3]} rotation={[0.4 * s, 0, 0.5]}>
              <planeGeometry args={[0.9, 0.35]} />
              <meshStandardMaterial color="#cbd5e1" transparent opacity={0.55} side={THREE.DoubleSide} />
            </mesh>
          ))}
          <mesh position={[0.5, 0.05, 0]} rotation={[0, 0, -Math.PI / 2]}>
            <cylinderGeometry args={[0.03, 0.01, 0.5, 6]} />
            <meshStandardMaterial color="#94a3b8" />
          </mesh>
        </group>
        {showLabels && <Label text="mosquito vector" position={[0, 5.4, 0]} color="#cbd5e1" />}

        {/* blood pool with malaria crescents */}
        <mesh position={[-3.2, 1.1, 0]} scale={[1.6, 0.5, 1.2]} castShadow>
          <sphereGeometry args={[1, 20, 14]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.4} transparent opacity={0.75} />
        </mesh>
        {Array.from({ length: N_PAR }).map((_, i) => (
          <mesh key={i} ref={(m) => { parasites.current[i] = m; }}>
            <torusGeometry args={[0.22, 0.09, 8, 16, Math.PI * 1.2]} />
            <meshStandardMaterial color="#facc15" emissive="#a16207" emissiveIntensity={0.9} />
          </mesh>
        ))}
        {showLabels && <Label text="malaria parasites (crescents)" position={[-3.2, 2.7, 0]} size={0.45} color="#fde047" />}

        {/* roundworm */}
        <mesh ref={worm} geometry={wormGeo} position={[3.4, 1.2, 0]} castShadow>
          <meshStandardMaterial color="#f5d0a9" roughness={0.55} transparent />
        </mesh>
        {showLabels && <Label text="roundworm" position={[3.4, 2.6, 0]} size={0.45} color="#f5d0a9" />}

        {/* drug tablet */}
        <group position={[0, 0, 2.6]}>
          <mesh position={[0, 0.35, 0]} castShadow>
            <cylinderGeometry args={[0.3, 0.3, 0.16, 20]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.35} />
          </mesh>
          <mesh position={[0, 0.35, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <boxGeometry args={[0.45, 0.06, 0.02]} />
            <meshStandardMaterial color="#38bdf8" />
          </mesh>
        </group>
        {showLabels && <Label text="antimalarial tablet" position={[0, 1.3, 2.6]} size={0.45} color="#7dd3fc" />}

        <Animator mozzie={mozzie} parasites={parasites} worm={worm} elapsed={elapsed} dose={dose} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
