// Lower limb fractures: hip fractures, femoral shaft, tibial, ankle.
// The leg skeleton with its danger zones — the fragile hip of the elderly,
// the strong femoral shaft, the shin, and the twist-prone ankle.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "site", label: "Fracture site", kind: "select", min: 0, max: 0, step: 1, default: "hip", options: ["hip", "femoral_shaft", "tibia", "ankle"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Leg Fractures: Hip to Ankle",
  blurb: "The leg's weak spots — the elderly hip that snaps in a fall, the femur shaft, the shin, and the ankle.",
};

const SITES: Record<string, { pos: [number, number, number]; label: string; note: string }> = {
  hip: { pos: [-0.55, 3.9, 0.2], label: "Hip (femoral neck)", note: "Elderly fall → needs surgery fast" },
  femoral_shaft: { pos: [0, 2.6, 0], label: "Femoral shaft", note: "High-energy crash — big blood loss" },
  tibia: { pos: [0.1, 1.3, 0.1], label: "Tibial shaft", note: "Just under the skin — open fractures" },
  ankle: { pos: [0.1, 0.35, 0.1], label: "Ankle (malleoli)", note: "Twisting injury — unstable" },
};

function Animator({
  group, marker, legLow, elapsed, speed, site,
}: {
  group: React.RefObject<THREE.Group>;
  marker: React.RefObject<THREE.Mesh>;
  legLow: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  site: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    if (marker.current) {
      marker.current.position.set(...SITES[site].pos);
      marker.current.scale.setScalar(1 + 0.3 * Math.sin(t * 5));
    }
    // hip fracture: leg shortens and rotates outward
    if (legLow.current) {
      const isHip = site === "hip";
      legLow.current.position.y = isHip ? -0.35 - 0.05 * Math.sin(t * 2) : 0;
      legLow.current.rotation.y = isHip ? 0.5 : 0;
    }
  });
  return null;
}

export function Topic10297Sim(props: SimProps) {
  const site = String(props.site ?? "hip");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const marker = useRef<THREE.Mesh>(null!);
  const legLow = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Site", SITES[site].label], ["Note", SITES[site].note], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10.5]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* pelvis */}
          <mesh position={[0, 4.4, 0]} scale={[1.6, 1.0, 1.1]} castShadow>
            <sphereGeometry args={[0.8, 20, 14]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
          </mesh>
          {/* femoral head + neck */}
          <mesh position={[-0.45, 3.95, 0.15]} castShadow>
            <sphereGeometry args={[0.3, 16, 12]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <mesh position={[-0.28, 3.8, 0.1]} rotation={[0, 0, 1.0]} castShadow>
            <cylinderGeometry args={[0.14, 0.14, 0.55, 12]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          {/* everything below the hip moves as one piece (shortens in hip fracture) */}
          <group ref={legLow}>
            {/* femur shaft */}
            <mesh position={[0, 2.7, 0]} castShadow>
              <cylinderGeometry args={[0.2, 0.23, 2.0, 16]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.5} />
            </mesh>
            {/* knee */}
            <mesh position={[0.05, 1.65, 0.05]} castShadow>
              <sphereGeometry args={[0.28, 16, 12]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.5} />
            </mesh>
            {/* tibia + fibula */}
            <mesh position={[0.1, 0.95, 0.08]} castShadow>
              <cylinderGeometry args={[0.17, 0.15, 1.35, 14]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.5} />
            </mesh>
            <mesh position={[-0.2, 0.95, -0.05]} castShadow>
              <cylinderGeometry args={[0.08, 0.08, 1.35, 10]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
            </mesh>
            {/* ankle + foot */}
            <mesh position={[0.1, 0.25, 0.08]} castShadow>
              <sphereGeometry args={[0.2, 14, 10]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.5} />
            </mesh>
            <mesh position={[0.35, 0.12, 0.15]} castShadow>
              <boxGeometry args={[0.7, 0.22, 0.35]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.5} />
            </mesh>
          </group>
          {/* pulsing fracture marker */}
          <mesh ref={marker} position={SITES[site].pos}>
            <torusGeometry args={[0.32, 0.11, 10, 18]} />
            <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={1.2} />
          </mesh>
          <Label text="Pelvis" position={[-1.9, 4.6, 0]} size={0.5} color="#e2e8f0" />
          <Label text="Femur" position={[1.5, 2.9, 0]} size={0.5} color="#f8fafc" />
          <Label text="Tibia & fibula" position={[1.6, 1.0, 0]} size={0.5} color="#f8fafc" />
          <Label text={SITES[site].label} position={[-2.4, SITES[site].pos[1] + 0.5, 0]} size={0.55} color="#fca5a5" />
          <Label text={SITES[site].note} position={[-2.4, SITES[site].pos[1] - 0.1, 0]} size={0.45} color="#fde68a" />
        </group>
        <Animator group={group} marker={marker} legLow={legLow} elapsed={elapsed} speed={speed} site={site} />
      </SimCanvas>
    </div>
  );
}
