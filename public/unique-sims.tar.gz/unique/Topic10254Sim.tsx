// Vascular surgery: varicose veins, DVT, peripheral arterial disease.
// A leg vein segment with one-way valves. Blood cells flow upward; watch veins
// bulge into varicose knots, a clot form in DVT, or the artery narrow in PAD.

"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "varicose", options: ["healthy", "varicose", "dvt", "pad"] },
  { key: "flow", label: "Blood flow", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Leg Veins: Varicose, DVT, PAD",
  blurb: "Blood cells flow up the leg vein through one-way valves — see varicose bulges, a DVT clot, or a narrowed artery.",
};

const N_CELLS = 26;

function Animator({
  group, cells, valveL, valveR, clot, elapsed, flow, condition,
}: {
  group: React.RefObject<THREE.Group>;
  cells: React.RefObject<THREE.Group>;
  valveL: React.RefObject<THREE.Mesh>;
  valveR: React.RefObject<THREE.Mesh>;
  clot: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  flow: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * flow;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // valves flutter as blood passes
    const flap = 0.5 + 0.28 * Math.sin(t * 6);
    if (valveL.current) valveL.current.rotation.z = 0.6 - flap;
    if (valveR.current) valveR.current.rotation.z = -0.6 + flap;
    // blood cells rise; they slow and swirl at the clot
    if (cells.current) {
      cells.current.children.forEach((c, i) => {
        const ph = ((t * 0.35 + i / N_CELLS) % 1);
        const y = -3.2 + ph * 6.8;
        const stuck = condition === "dvt" && y > 0.9 && y < 1.6;
        c.position.set(Math.sin(i * 2.3 + t * 2) * (stuck ? 0.42 : 0.3), y, Math.cos(i * 1.7) * 0.3);
        c.rotation.x = t * 3 + i;
      });
    }
    if (clot.current) {
      clot.current.visible = condition === "dvt";
      clot.current.scale.setScalar(1 + 0.1 * Math.sin(t * 3));
    }
  });
  return null;
}

export function Topic10254Sim(props: SimProps) {
  const condition = String(props.condition ?? "varicose");
  const flow = Number(props.flow ?? 1);
  const group = useRef<THREE.Group>(null!);
  const cells = useRef<THREE.Group>(null!);
  const valveL = useRef<THREE.Mesh>(null!);
  const valveR = useRef<THREE.Mesh>(null!);
  const clot = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const isVaricose = condition === "varicose";
  const isDvt = condition === "dvt";
  const isPad = condition === "pad";

  const bulges = useMemo(() => [
    { y: -1.2, s: 1.55 }, { y: 0.2, s: 1.35 }, { y: 1.8, s: 1.6 },
  ], []);

  const names: Record<string, string> = { healthy: "Healthy vein", varicose: "Varicose veins", dvt: "DVT — deep vein clot", pad: "PAD — narrowed artery" };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Flow", `${flow.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 1.6, 9.5]} target={[0, 0.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* vein wall: straight tube, or wavy bulging tube for varicose */}
          {isVaricose ? (
            bulges.map((b, i) => (
              <mesh key={i} position={[0, b.y, 0]} scale={[b.s, 1.1, b.s]} castShadow>
                <sphereGeometry args={[0.55, 20, 14]} />
                <meshStandardMaterial color="#7c3aed" roughness={0.45} transparent opacity={0.9} />
              </mesh>
            ))
          ) : (
            <mesh position={[0, 0.4, 0]} castShadow>
              <cylinderGeometry args={[isPad ? 0.28 : 0.55, isPad ? 0.28 : 0.55, 7.2, 20, 1, true]} />
              <meshStandardMaterial color={isPad ? "#ef4444" : "#3b82f6"} roughness={0.45} transparent opacity={0.55} side={THREE.DoubleSide} />
            </mesh>
          )}
          {/* artery segment for PAD: plaque narrowing */}
          {isPad && (
            <mesh position={[0, 0.4, 0]} castShadow>
              <cylinderGeometry args={[0.55, 0.55, 7.2, 20, 1, true]} />
              <meshStandardMaterial color="#f87171" roughness={0.45} transparent opacity={0.35} side={THREE.DoubleSide} />
            </mesh>
          )}
          {isPad && (
            <mesh position={[0, 0.6, 0]} castShadow>
              <torusGeometry args={[0.42, 0.22, 12, 20]} />
              <meshStandardMaterial color="#fbbf24" roughness={0.6} />
            </mesh>
          )}
          {/* one-way valve leaflets */}
          <mesh ref={valveL} position={[-0.28, -0.9, 0]} castShadow>
            <boxGeometry args={[0.5, 0.06, 0.4]} />
            <meshStandardMaterial color="#93c5fd" roughness={0.4} />
          </mesh>
          <mesh ref={valveR} position={[0.28, -0.9, 0]} castShadow>
            <boxGeometry args={[0.5, 0.06, 0.4]} />
            <meshStandardMaterial color="#93c5fd" roughness={0.4} />
          </mesh>
          {/* DVT clot stuck to the wall */}
          <mesh ref={clot} position={[0.3, 1.25, 0.15]} visible={false} castShadow>
            <icosahedronGeometry args={[0.34, 1]} />
            <meshStandardMaterial color="#7f1d1d" roughness={0.7} flatShading emissive="#450a0a" emissiveIntensity={0.5} />
          </mesh>
          {/* red blood cells */}
          <group ref={cells}>
            {Array.from({ length: N_CELLS }).map((_, i) => (
              <mesh key={i} castShadow>
                <cylinderGeometry args={[0.14, 0.14, 0.06, 14]} />
                <meshStandardMaterial color="#dc2626" roughness={0.4} />
              </mesh>
            ))}
          </group>
          <Label text={isVaricose ? "Twisted varicose bulges" : isDvt ? "Deep vein" : isPad ? "Artery" : "Vein"} position={[-2.1, 2.4, 0]} size={0.5} color="#c4b5fd" />
          <Label text="One-way valve" position={[1.9, -0.9, 0]} size={0.5} color="#bfdbfe" />
          {isDvt && <Label text="⚠ Blood clot (DVT)" position={[1.6, 1.9, 0.2]} size={0.55} color="#fca5a5" />}
          {isPad && <Label text="⚠ Plaque narrowing" position={[-1.9, 0.6, 0]} size={0.55} color="#fde68a" />}
          {isVaricose && <Label text="⚠ Weak valves → pooling" position={[0, -2.6, 0]} size={0.5} color="#fca5a5" />}
        </group>
        <Animator group={group} cells={cells} valveL={valveL} valveR={valveR} clot={clot} elapsed={elapsed} flow={flow} condition={condition} />
      </SimCanvas>
    </div>
  );
}
