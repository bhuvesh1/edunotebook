"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Nerve pulse speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Neuroanatomy: brainstem, cerebellum, cranial nerves",
  blurb: "Below the cerebrum: the brainstem's 12 cranial nerves fire signals out to the face and body, beside the little brain.",
};

const NERVES: [number, number, number][] = [
  [1.6, -0.6, 0.6], [1.9, -1.2, -0.2], [1.5, -1.8, 0.5],
  [-1.6, -0.6, 0.6], [-1.9, -1.2, -0.2], [-1.5, -1.8, 0.5],
];

function Hindbrain({ speed }: { speed: number }) {
  const pulses = useRef<(THREE.Mesh | null)[]>([]);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d * speed;
    pulses.current.forEach((m, i) => {
      if (!m) return;
      const [ex, ey, ez] = NERVES[i];
      const k = (t.current * 0.7 + i * 0.17) % 1;
      m.position.set(ex * k, 2.2 + ey * k, ez * k);
    });
  });
  return (
    <group position={[0, 0.6, 0]}>
      {/* cerebrum hint above */}
      <mesh position={[0, 5.6, 0]} castShadow>
        <sphereGeometry args={[1.6, 24, 18]} />
        <meshStandardMaterial color="#f9a8d4" roughness={0.6} transparent opacity={0.35} />
      </mesh>
      {/* brainstem: midbrain, pons, medulla */}
      <mesh position={[0, 3.9, 0]} castShadow>
        <cylinderGeometry args={[0.5, 0.55, 1.0, 14]} />
        <meshStandardMaterial color="#f472b6" roughness={0.5} />
      </mesh>
      <mesh position={[0, 3.0, 0]} castShadow>
        <sphereGeometry args={[0.62, 16, 16]} />
        <meshStandardMaterial color="#ec4899" roughness={0.5} />
      </mesh>
      <mesh position={[0, 2.1, 0]} castShadow>
        <cylinderGeometry args={[0.55, 0.4, 1.1, 14]} />
        <meshStandardMaterial color="#db2777" roughness={0.5} />
      </mesh>
      {/* cerebellum: two ridged hemispheres */}
      {[-0.85, 0.85].map((x) => (
        <group key={x} position={[x, 3.1, -1.15]}>
          <mesh castShadow>
            <sphereGeometry args={[0.75, 18, 14]} />
            <meshStandardMaterial color="#c084fc" roughness={0.55} />
          </mesh>
          {[-0.3, 0, 0.3].map((y) => (
            <mesh key={y} position={[0, y, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.62, 0.05, 8, 20]} />
              <meshStandardMaterial color="#7e22ce" roughness={0.6} />
            </mesh>
          ))}
        </group>
      ))}
      {/* cranial nerve lines radiating from the stem */}
      {NERVES.map((e, i) => (
        <mesh key={i} position={[e[0] / 2, 2.2 + e[1] / 2, e[2] / 2]} rotation={[0, 0, Math.atan2(e[1], e[0]) + Math.PI / 2]}>
          <cylinderGeometry args={[0.045, 0.045, Math.sqrt(e[0] * e[0] + e[1] * e[1]), 8]} />
          <meshStandardMaterial color="#fde68a" roughness={0.5} />
        </mesh>
      ))}
      {/* travelling nerve pulses */}
      {NERVES.map((_, i) => (
        <mesh key={i} ref={(m) => { pulses.current[i] = m; }} position={[0, 2.2, 0]}>
          <sphereGeometry args={[0.12, 10, 10]} />
          <meshStandardMaterial color="#fef08a" emissive="#facc15" emissiveIntensity={2} />
        </mesh>
      ))}
    </group>
  );
}

export function Topic10012Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Cranial nerves", "12 pairs"], ["Stem", "midbrain·pons·medulla"], ["Little brain", "cerebellum"]]} />
      <SimCanvas cameraPosition={[0, 4, 12]} target={[0, 3.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Hindbrain speed={speed} />
        {showLabels && (
          <>
            <Label text="Brainstem" position={[-2.6, 3.6, 0.6]} color="#f9a8d4" size={0.5} />
            <Label text="Cerebellum" position={[3.0, 4.2, -1.2]} color="#d8b4fe" size={0.5} />
            <Label text="Cranial nerves" position={[-3.0, 1.4, 0]} color="#fde68a" size={0.5} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
