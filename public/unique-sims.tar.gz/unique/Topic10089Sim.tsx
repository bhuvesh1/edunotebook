"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ttype", label: "Tumor", kind: "select", min: 0, max: 0, step: 1, default: "malignant", options: ["benign", "malignant"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Benign vs Malignant Tumors",
  blurb: "A benign lump sits quietly in its capsule while a malignant tumor invades and seeds metastases to a lymph node.",
};

function Animator({ root, tend, seeds, node, elapsed, speed, mal }: { root: RefObject<THREE.Group>; tend: RefObject<THREE.Group>; seeds: RefObject<THREE.Group>; node: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; mal: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (tend.current) {
      tend.current.visible = mal;
      tend.current.children.forEach((m, i) => {
        const s = 0.6 + 0.4 * Math.sin(t * 2 + i * 1.4);
        m.scale.set(1, s, 1);
      });
    }
    if (seeds.current) {
      seeds.current.visible = mal;
      seeds.current.children.forEach((m, i) => {
        const q = (t * 0.35 + i / 5) % 1;
        m.position.set(2.2 + q * 2.6, 1.8 + Math.sin(q * Math.PI) * 1.2, (i % 2) * 0.6 - 0.3);
      });
    }
    if (node.current) {
      const s = mal ? 1 + 0.25 * Math.sin(t * 3) : 1;
      node.current.scale.setScalar(s);
      (node.current.material as THREE.MeshStandardMaterial).emissiveIntensity = mal ? 0.9 : 0.1;
    }
  });
  return null;
}

export function Topic10089Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const ttype = String(props.ttype ?? "malignant");
  const mal = ttype === "malignant";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const tend = useRef<THREE.Group>(null!);
  const seeds = useRef<THREE.Group>(null!);
  const node = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Tumor", ttype],
          ["Spread", mal ? "invasion + metastasis" : "none \u2014 encapsulated"],
          ["Growth", mal ? "rapid, anaplastic" : "slow, well-differentiated"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[-2.6, 1.8, 0]} castShadow>
            <sphereGeometry args={[1.05, 24, 24]} /><meshStandardMaterial color="#4ade80" roughness={0.4} />
          </mesh>
          <mesh position={[-2.6, 1.8, 0]} rotation={[Math.PI / 2.4, 0, 0]}>
            <torusGeometry args={[1.25, 0.14, 12, 32]} /><meshStandardMaterial color="#bbf7d0" roughness={0.5} />
          </mesh>
          <Label text="benign \u2014 encapsulated" position={[-2.6, 3.5, 0]} size={0.42} color="#4ade80" />
          <mesh position={[2.2, 1.8, 0]} castShadow>
            <icosahedronGeometry args={[1.1, 1]} /><meshStandardMaterial color="#ef4444" emissive="#7f1d1d" emissiveIntensity={0.5} roughness={0.5} flatShading />
          </mesh>
          <group ref={tend} position={[2.2, 1.8, 0]}>
            {Array.from({ length: 6 }).map((_, i) => {
              const a = (i / 6) * Math.PI * 2;
              return (
                <mesh key={i} position={[Math.cos(a) * 1.5, Math.sin(a) * 0.9, Math.sin(a) * 0.8]} rotation={[0, 0, a - Math.PI / 2]}>
                  <coneGeometry args={[0.16, 1.1, 8]} /><meshStandardMaterial color="#b91c1c" roughness={0.6} />
                </mesh>
              );
            })}
          </group>
          <Label text="malignant \u2014 invading" position={[2.2, 3.6, 0]} size={0.42} color="#f87171" />
          <group ref={seeds}>
            {Array.from({ length: 5 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.16, 10, 10]} /><meshStandardMaterial color="#fca5a5" emissive="#ef4444" emissiveIntensity={0.8} /></mesh>
            ))}
          </group>
          <mesh ref={node} position={[5.4, 1.4, 0]} castShadow>
            <sphereGeometry args={[0.6, 18, 18]} /><meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={0.1} roughness={0.5} />
          </mesh>
          <Label text="lymph node \u2014 metastasis" position={[5.4, 0.4, 0]} size={0.4} color="#4ade80" />
        </group>
        <Animator root={root} tend={tend} seeds={seeds} node={node} elapsed={elapsed} speed={speed} mal={mal} />
      </SimCanvas>
    </div>
  );
}
