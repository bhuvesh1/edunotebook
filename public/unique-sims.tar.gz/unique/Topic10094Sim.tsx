"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "years", label: "Plaque age", kind: "slider", min: 0, max: 40, step: 1, default: 15, unit: " yrs" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Atherosclerosis & Heart Disease",
  blurb: "Cross-section of an artery wall: LDL invades the intima, foam cells gather, and a fibrous-capped plaque grows over decades.",
};

function Animator({ root, ldl, plq, cap, elapsed, speed, pg }: { root: RefObject<THREE.Group>; ldl: RefObject<THREE.Group>; plq: RefObject<THREE.Group>; cap: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; pg: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (ldl.current) {
      ldl.current.children.forEach((m, i) => {
        const q = (t * (0.25 + pg * 0.4) + i / 8) % 1;
        const a = Math.PI * 0.72;
        m.position.set(Math.cos(a) * (2.6 - q * 1.1), 2 + Math.sin(a) * (2.6 - q * 1.1), 0);
        m.scale.setScalar(1 - q * 0.3);
      });
    }
    if (plq.current) plq.current.scale.setScalar(0.25 + pg * 1.05);
    if (cap.current) {
      cap.current.visible = pg > 0.25;
      (cap.current.material as THREE.MeshStandardMaterial).opacity = 0.35 + 0.2 * Math.sin(t * 2);
    }
  });
  return null;
}

export function Topic10094Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const years = Number(props.years ?? 15);
  const pg = years / 40;
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const ldl = useRef<THREE.Group>(null!);
  const plq = useRef<THREE.Group>(null!);
  const cap = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Plaque age", `${years} yrs`],
          ["Stage", years < 10 ? "fatty streak" : years < 25 ? "fibrous plaque" : "complicated lesion"],
          ["Lumen", years > 28 ? "critically narrowed" : "patent"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.6, 11]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 2, 0]}>
            <torusGeometry args={[2.5, 0.3, 14, 48]} /><meshStandardMaterial color="#7f1d1d" roughness={0.6} />
          </mesh>
          <mesh position={[0, 2, 0]}>
            <torusGeometry args={[2.05, 0.34, 14, 48]} /><meshStandardMaterial color="#ef4444" roughness={0.55} />
          </mesh>
          <mesh position={[0, 2, 0]}>
            <torusGeometry args={[1.6, 0.24, 14, 48]} /><meshStandardMaterial color="#f9a8d4" roughness={0.55} />
          </mesh>
          <Label text="adventitia" position={[2.9, 4.3, 0]} size={0.38} color="#f87171" />
          <Label text="media" position={[2.35, 3.9, 0]} size={0.38} color="#ef4444" />
          <Label text="intima" position={[-2.9, 3.5, 0]} size={0.38} color="#f9a8d4" />
          <group ref={ldl}>
            {Array.from({ length: 8 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.14, 10, 10]} /><meshStandardMaterial color="#facc15" emissive="#eab308" emissiveIntensity={0.7} /></mesh>
            ))}
          </group>
          <Label text="LDL invading" position={[-3.6, 1, 0]} size={0.4} color="#facc15" />
          <group ref={plq} position={[-1.15, 2.75, 0]}>
            {Array.from({ length: 8 }).map((_, i) => (
              <mesh key={i} position={[Math.sin(i * 2.6) * 0.5, Math.cos(i * 1.9) * 0.35, Math.sin(i * 3.4) * 0.4]}>
                <sphereGeometry args={[0.3, 12, 12]} /><meshStandardMaterial color="#eab308" roughness={0.75} />
              </mesh>
            ))}
            <Label text="foam cells" position={[0, 0.9, 0]} size={0.36} color="#fde68a" />
          </group>
          <mesh ref={cap} position={[-1.15, 3.35, 0]} rotation={[0, 0, 0.5]}>
            <torusGeometry args={[0.75, 0.12, 10, 24, Math.PI * 0.9]} />
            <meshStandardMaterial color="#fef3c7" transparent opacity={0.4} roughness={0.5} />
          </mesh>
          <Label text="fibrous cap" position={[-1.15, 4.35, 0]} size={0.38} color="#fef3c7" />
        </group>
        <Animator root={root} ldl={ldl} plq={plq} cap={cap} elapsed={elapsed} speed={speed} pg={pg} />
      </SimCanvas>
    </div>
  );
}
