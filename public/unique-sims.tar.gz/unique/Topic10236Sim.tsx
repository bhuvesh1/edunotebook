// Rheumatoid arthritis, SLE, spondyloarthropathies & gout — a knee joint:
// femur meets tibia with cartilage between. The inflammation slider erodes
// cartilage, reddens the synovium, and (in gout mode) grows uric-acid crystal
// spikes. The joint stiffens and bends less.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "inflame", label: "Joint inflammation", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "disease", label: "Disease", kind: "select", min: 0, max: 0, step: 1, default: "rheumatoid arthritis", options: ["rheumatoid arthritis", "gout", "osteoarthritis"] },
];

export const UNIQUE_META = {
  title: "Arthritis & Gout",
  blurb: "A knee joint inflames and its cartilage erodes — flip to gout to grow needle crystals, and bend the knee to feel the stiffness.",
};

function Animator({ shin, elapsed, inflame }: {
  shin: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  inflame: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (shin.current) {
      // gentle knee bend; stiffer (smaller) when inflamed
      const range = 0.45 - (inflame / 100) * 0.32;
      shin.current.rotation.x = -0.12 - (Math.sin(t * 1.4) * 0.5 + 0.5) * range;
    }
  });
  return null;
}

export function Topic10236Sim(props: SimProps) {
  const inflame = Number(props.inflame ?? 60);
  const disease = String(props.disease ?? "rheumatoid arthritis");
  const shin = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const f = inflame / 100;
  const cartilageH = 0.34 - f * 0.24; // erodes away
  const gout = disease === "gout";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Disease", disease], ["Cartilage", `${Math.round((cartilageH / 0.34) * 100)}% left`], ["Bend", f > 0.7 ? "stiff ⚠" : "mobile"]]} />
      <SimCanvas cameraPosition={[0, 2.6, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* femur (thigh bone) */}
        <mesh position={[0, 4.6, 0]} castShadow>
          <cylinderGeometry args={[0.55, 0.62, 3.4, 16]} />
          <meshStandardMaterial color="#fefce8" roughness={0.5} />
        </mesh>
        <mesh position={[0, 2.95, 0]} scale={[1.25, 0.8, 1.1]}>
          <sphereGeometry args={[0.75, 20, 16]} />
          <meshStandardMaterial color="#fefce8" roughness={0.5} />
        </mesh>
        {/* cartilage cap (erodes) */}
        <mesh position={[0, 2.42, 0]} scale={[1.2, 1, 1.05]}>
          <cylinderGeometry args={[0.68, 0.68, Math.max(0.04, cartilageH), 18]} />
          <meshStandardMaterial color={f > 0.6 ? "#f87171" : "#7dd3fc"} roughness={0.35} transparent opacity={0.9} />
        </mesh>
        {/* inflamed synovium */}
        <mesh position={[0, 2.5, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.95, 0.12 + f * 0.22, 10, 28]} />
          <meshStandardMaterial color="#ef4444" roughness={0.55} emissive="#7f1d1d" emissiveIntensity={0.3 + f * 0.5} />
        </mesh>
        {/* gout crystals */}
        {gout && (
          <group position={[0, 2.5, 0]}>
            {Array.from({ length: Math.round(4 + f * 12) }).map((_, i) => {
              const a = (i * 2.4) % (Math.PI * 2);
              return (
                <mesh key={i} position={[Math.cos(a) * 0.6, ((i * 0.37) % 0.5) - 0.25, Math.sin(a) * 0.6]} rotation={[a, i, 0]}>
                  <coneGeometry args={[0.05, 0.5 + f * 0.4, 6]} />
                  <meshStandardMaterial color="#fefce8" roughness={0.3} emissive="#a16207" emissiveIntensity={0.3} />
                </mesh>
              );
            })}
          </group>
        )}

        {/* tibia (shin) — bends at the knee */}
        <group ref={shin} position={[0, 2.2, 0]}>
          <mesh position={[0, -1.8, 0]} castShadow>
            <cylinderGeometry args={[0.5, 0.58, 3.6, 16]} />
            <meshStandardMaterial color="#fefce8" roughness={0.5} />
          </mesh>
        </group>

        <Label text={gout ? "Gout — uric acid needle crystals ⚠" : disease === "rheumatoid arthritis" ? "RA — immune system attacks the joint" : "Osteoarthritis — wear and tear"} position={[0, 6.6, 0]} size={0.52} color={gout ? "#fde047" : "#fca5a5"} />
        <Label text={f > 0.7 ? "Bone grinding on bone — stiff & painful" : "Cartilage cushions the joint"} position={[0, -1.4, 0]} size={0.46} color={f > 0.7 ? "#fca5a5" : "#86efac"} />
        <Animator shin={shin} elapsed={elapsed} inflame={inflame} />
      </SimCanvas>
    </div>
  );
}
