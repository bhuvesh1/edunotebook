"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "tumor", label: "Tumor", kind: "select", min: 0, max: 0, step: 1, default: "melanoma", options: ["bcc", "scc", "melanoma"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Skin tumors: basal cell, squamous cell, melanoma",
  blurb: "Three skin cancers side by side — pearly BCC nodule, ulcerated SCC crater, dark irregular melanoma — with the ABCDE warning signs.",
};

const SKIN = "#e8a87c";
const DERMIS = "#d9826b";

function Lesion({
  kind, position, active, speed, showLabels, label,
}: {
  kind: string; position: [number, number, number]; active: boolean; speed: number; showLabels: boolean; label: string;
}) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) {
      const target = active ? 1.45 : 1;
      const s = THREE.MathUtils.lerp(g.current.scale.x, target, 0.08);
      g.current.scale.setScalar(s * (1 + Math.sin(elapsed.current * 2) * 0.015));
      g.current.rotation.y = elapsed.current * 0.25 * speed;
    }
  });
  return (
    <group position={position}>
      <group ref={g}>
        {kind === "bcc" && (
          <group>
            {/* pearly nodule with rolled edge */}
            <mesh position={[0, 0.5, 0]} castShadow>
              <sphereGeometry args={[0.85, 28, 18, 0, Math.PI * 2, 0, Math.PI / 2]} />
              <meshStandardMaterial color="#f9c5b0" roughness={0.25} />
            </mesh>
            <mesh position={[0, 0.16, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.85, 0.14, 12, 32]} />
              <meshStandardMaterial color="#e8a08a" roughness={0.3} />
            </mesh>
            {/* telangiectasia threads */}
            {[-0.4, 0, 0.4].map((x, i) => (
              <mesh key={i} position={[x, 0.62, 0.45]} rotation={[0.4, 0, x]}>
                <cylinderGeometry args={[0.02, 0.02, 0.6, 6]} />
                <meshBasicMaterial color="#ef4444" />
              </mesh>
            ))}
          </group>
        )}
        {kind === "scc" && (
          <group>
            {/* raised crater with central ulcer */}
            <mesh position={[0, 0.35, 0]} castShadow>
              <cylinderGeometry args={[0.95, 1.05, 0.7, 28]} />
              <meshStandardMaterial color="#e0765f" roughness={0.55} />
            </mesh>
            <mesh position={[0, 0.72, 0]} castShadow>
              <cylinderGeometry args={[0.5, 0.62, 0.18, 24]} />
              <meshStandardMaterial color="#7f1d1d" roughness={0.9} />
            </mesh>
            {/* scaly crust ring */}
            <mesh position={[0, 0.78, 0]} rotation={[-Math.PI / 2, 0, 0]}>
              <ringGeometry args={[0.55, 0.8, 24]} />
              <meshStandardMaterial color="#fcd9b8" roughness={0.9} side={THREE.DoubleSide} />
            </mesh>
          </group>
        )}
        {kind === "melanoma" && (
          <group>
            {/* asymmetric dark irregular plaque */}
            <mesh position={[0, 0.42, 0]} scale={[1.15, 0.6, 0.9]} rotation={[0, 0.4, 0]} castShadow>
              <sphereGeometry args={[0.9, 28, 18, 0, Math.PI * 2, 0, Math.PI / 2]} />
              <meshStandardMaterial color="#292524" roughness={0.45} />
            </mesh>
            {/* color variegation patches */}
            <mesh position={[0.3, 0.72, 0.2]} scale={[0.5, 0.3, 0.45]} castShadow>
              <sphereGeometry args={[0.5, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
              <meshStandardMaterial color="#7c2d12" roughness={0.5} />
            </mesh>
            <mesh position={[-0.35, 0.7, -0.15]} scale={[0.4, 0.28, 0.4]} castShadow>
              <sphereGeometry args={[0.5, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
              <meshStandardMaterial color="#451a03" roughness={0.5} />
            </mesh>
            {/* irregular border ring */}
            <mesh position={[0, 0.1, 0]} rotation={[-Math.PI / 2, 0, 0]}>
              <ringGeometry args={[0.95, 1.25, 18]} />
              <meshBasicMaterial color="#ef4444" transparent opacity={0.5} side={THREE.DoubleSide} />
            </mesh>
          </group>
        )}
      </group>
      {active && (
        <mesh position={[0, 0.08, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[1.5, 1.7, 40]} />
          <meshBasicMaterial color="#facc15" transparent opacity={0.9} side={THREE.DoubleSide} />
        </mesh>
      )}
      {showLabels && (
        <Text position={[0, 2.1, 0]} fontSize={0.46} color={active ? "#facc15" : "#e2e8f0"}>{label}</Text>
      )}
    </group>
  );
}

export function Topic10332Sim(props: SimProps) {
  const tumor = String(props.tumor ?? "melanoma");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const info: Record<string, [string, string]> = {
    bcc: ["Basal cell carcinoma", "pearly nodule + telangiectasia"],
    scc: ["Squamous cell carcinoma", "ulcerated crater + crust"],
    melanoma: ["Melanoma", "ABCDE — dark, irregular"],
  };
  const [tname, tsign] = info[tumor] ?? info.melanoma;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Selected", tname],
          ["Key sign", tsign],
          ["ABCDE", "Asymmetry Border Color Diameter Evolving"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 12]} target={[0, 0.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.55, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* shared skin slab */}
        <mesh position={[0, -0.85, 0]} castShadow receiveShadow>
          <boxGeometry args={[13, 1.6, 4.5]} />
          <meshStandardMaterial color={DERMIS} roughness={0.85} />
        </mesh>
        <mesh position={[0, 0.08, 0]} castShadow>
          <boxGeometry args={[13, 0.5, 4.5]} />
          <meshStandardMaterial color={SKIN} roughness={0.7} />
        </mesh>
        <Lesion kind="bcc" position={[-4.2, 0.32, 0]} active={tumor === "bcc"} speed={speed} showLabels={showLabels} label="BCC — pearly" />
        <Lesion kind="scc" position={[0, 0.32, 0]} active={tumor === "scc"} speed={speed} showLabels={showLabels} label="SCC — ulcerated" />
        <Lesion kind="melanoma" position={[4.2, 0.32, 0]} active={tumor === "melanoma"} speed={speed} showLabels={showLabels} label="Melanoma — dark, irregular" />
      </SimCanvas>
    </div>
  );
}
