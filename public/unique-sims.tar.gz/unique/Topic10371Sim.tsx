"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Development stage", kind: "slider", min: 1, max: 5, step: 1, default: 3, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Development of face, palate, tongue, oral cavity",
  blurb: "Watch the embryo's face assemble: frontonasal, maxillary and mandibular processes migrate and fuse to form lips, palate and tongue.",
};

const STAGES = [
  "Week 4 — five swellings appear",
  "Week 5 — processes approach",
  "Week 6 — maxillary + medial nasal fuse → upper lip",
  "Week 7 — palatal shelves elevate",
  "Week 8 — face complete",
];

function FaceDevelopment({ stage, speed, showLabels }: { stage: number; speed: number; showLabels: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) g.current.rotation.y = Math.sin(elapsed.current * 0.3) * 0.15;
  });
  const s = stage; // 1..5
  // process centers lerp toward the midline as stage grows
  const spread = THREE.MathUtils.lerp(2.6, 0.9, (s - 1) / 4);
  const topY = THREE.MathUtils.lerp(1.6, 2.5, (s - 1) / 4);

  const blob = (color: string, p: [number, number, number], r: number, key: string) => (
    <mesh key={key} position={p} castShadow>
      <sphereGeometry args={[r, 20, 14]} />
      <meshStandardMaterial color={color} roughness={0.45} />
    </mesh>
  );

  return (
    <group ref={g}>
      {/* embryo head sphere (translucent scaffold) */}
      <mesh castShadow>
        <sphereGeometry args={[3.4, 28, 20]} />
        <meshPhysicalMaterial color="#f7c9a8" transparent opacity={0.28} roughness={0.3} />
      </mesh>
      {/* stomodeum (mouth pit) */}
      <mesh position={[0, -0.6, 2.9]}>
        <sphereGeometry args={[0.7 - (s - 1) * 0.08, 16, 12]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.6} />
      </mesh>
      {/* frontonasal process */}
      {blob("#4ade80", [0, topY + 0.7, 2.2], 1.05, "fn")}
      {/* nasal placodes */}
      {[-1, 1].map((x) => blob("#22d3ee", [x * spread * 0.55, topY - 0.2, 2.9], 0.42, "np" + x))}
      {/* maxillary processes */}
      {[-1, 1].map((x) => blob("#60a5fa", [x * spread, 0.4, 2.5], 0.95, "mx" + x))}
      {/* mandibular processes */}
      {[-1, 1].map((x) => blob("#fbbf24", [x * spread * 0.85, -1.7, 2.2], 1.0, "md" + x))}
      {/* tongue bud appears from stage 3 */}
      {s >= 3 && blob("#f87171", [0, -1.2, 2.6], 0.55, "tongue")}
      {/* palatal shelves fusing at stage 4+ */}
      {s >= 4 &&
        [-1, 1].map((x) =>
          blob("#fb923c", [(x * spread * 0.3) / 2, 0.1, 2.4], 0.6, "pal" + x)
        )}
      {showLabels && (
        <>
          <Text position={[0, -4.6, 0]} fontSize={0.44} color="#fef3c7" maxWidth={11}>{STAGES[s - 1]}</Text>
          <Text position={[4.6, 3.4, 0]} fontSize={0.38} color="#4ade80">Frontonasal</Text>
          <Text position={[4.6, 2.4, 0]} fontSize={0.38} color="#60a5fa">Maxillary</Text>
          <Text position={[4.6, 1.4, 0]} fontSize={0.38} color="#fbbf24">Mandibular</Text>
          <Text position={[4.6, 0.4, 0]} fontSize={0.38} color="#22d3ee">Nasal placode</Text>
        </>
      )}
    </group>
  );
}

export function Topic10371Sim(props: SimProps) {
  const stage = Math.round(Number(props.stage ?? 3));
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", `${stage} / 5`],
          ["Event", ["—", "5 swellings", "approach", "lip fusion", "palate fusion", "complete"][stage]],
          ["Cleft risk", stage >= 3 && stage <= 4 ? "fusion window ⚠" : "—"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.5, 12]} target={[0, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -5.2, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <FaceDevelopment stage={stage} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
