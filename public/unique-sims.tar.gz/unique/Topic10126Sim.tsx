// Immunosuppressants: spiky T-cells swarm a transplanted kidney — the
// immunosuppressant drug raises a shield that holds the attack back.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Immunosuppression", kind: "slider", min: 0, max: 100, step: 5, default: 65, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Immunosuppressants",
  blurb: "T-cells swarm a transplanted kidney — the drug raises a shield that holds the rejection attack back.",
};

const N_T = 10;

function Animator({ tcells, shield, kidney, elapsed, dose, setTick }: {
  tcells: React.RefObject<(THREE.Group | null)[]>;
  shield: React.RefObject<THREE.Mesh>;
  kidney: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  dose: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    const shieldR = 1.6 + k * 1.6; // shield radius grows with dose
    if (shield.current) {
      shield.current.scale.setScalar(shieldR / 2.4);
      (shield.current.material as THREE.MeshStandardMaterial).opacity = 0.12 + k * 0.22;
      shield.current.rotation.y = t * 0.4;
    }
    let hits = 0;
    tcells.current.forEach((g, i) => {
      if (!g) return;
      // T-cells orbit in, bounce off the shield
      const ang = t * (0.5 + (1 - k) * 0.4) + i * (Math.PI * 2 / N_T);
      const r = shieldR + 0.5 + Math.sin(t * 2 + i * 3) * 0.5;
      const x = Math.cos(ang) * r;
      const z = Math.sin(ang) * r * 0.7;
      g.position.set(x, 1.5 + Math.sin(t * 1.7 + i) * 0.4, z);
      g.rotation.y = -ang;
      // a few slip through when the shield is weak
      const slip = k < 0.35 && ((i * 53) % 10) / 10 > k * 2;
      if (slip) {
        hits++;
        g.position.set(x * 0.25, 1.5, z * 0.25);
      }
      g.children.forEach((c, ci) => {
        if (ci > 0) c.rotation.z = t * 3 + ci;
      });
    });
    if (kidney.current) {
      const m = kidney.current.material as THREE.MeshStandardMaterial;
      // kidney pales as it takes hits
      m.color.setHSL(0.0, 0.65 - hits * 0.06, 0.42 - hits * 0.03);
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(hits); }
  });
  return null;
}

export function Topic10126Sim(props: SimProps) {
  const dose = Number(props.dose ?? 65);
  const showLabels = String(props.detail ?? "on") === "on";
  const tcells = useRef<(THREE.Group | null)[]>([]);
  const shield = useRef<THREE.Mesh>(null!);
  const kidney = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const status = tick === 0 ? "graft protected" : tick < 3 ? "mild attack" : "rejection!";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["T-cells hitting graft", `${tick}`],
          ["Status", status],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 12]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* transplanted kidney */}
        <mesh ref={kidney} position={[0, 1.5, 0]} scale={[0.85, 1.25, 0.85]} castShadow>
          <sphereGeometry args={[0.9, 24, 18]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.5} />
        </mesh>
        {showLabels && <Label text="transplanted kidney" position={[0, 3.3, 0]} color="#fca5a5" />}

        {/* drug shield */}
        <mesh ref={shield} position={[0, 1.5, 0]}>
          <sphereGeometry args={[2.4, 24, 18]} />
          <meshStandardMaterial color="#38bdf8" transparent opacity={0.2} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
        {showLabels && <Label text="immunosuppressant shield" position={[0, 4.4, 0]} size={0.45} color="#7dd3fc" />}

        {/* attacking T-cells: spiky blue spheres */}
        {Array.from({ length: N_T }).map((_, i) => (
          <group key={i} ref={(g) => { tcells.current[i] = g; }}>
            <mesh castShadow>
              <sphereGeometry args={[0.3, 14, 10]} />
              <meshStandardMaterial color="#3b82f6" emissive="#1d4ed8" emissiveIntensity={0.7} />
            </mesh>
            {Array.from({ length: 6 }).map((_, s) => {
              const a = (s / 6) * Math.PI * 2;
              return (
                <mesh key={s} position={[Math.cos(a) * 0.36, Math.sin(a) * 0.36, 0]}>
                  <coneGeometry args={[0.07, 0.25, 6]} />
                  <meshStandardMaterial color="#93c5fd" emissive="#3b82f6" emissiveIntensity={0.6} />
                </mesh>
              );
            })}
          </group>
        ))}
        {showLabels && <Label text="attacking T-cells" position={[-4.2, 2.8, 0]} size={0.45} color="#93c5fd" />}

        {/* drug capsule */}
        <group position={[4.4, 0, 1.4]}>
          <mesh position={[0, 0.55, 0]} castShadow>
            <capsuleGeometry args={[0.24, 0.4, 8, 16]} />
            <meshStandardMaterial color="#facc15" roughness={0.3} />
          </mesh>
        </group>
        {showLabels && <Label text="immunosuppressant" position={[4.4, 1.6, 1.4]} size={0.45} color="#fde047" />}

        <Animator tcells={tcells} shield={shield} kidney={kidney} elapsed={elapsed} dose={dose} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
