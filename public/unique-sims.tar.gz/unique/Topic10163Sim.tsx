"use client";
// Toxicology: agricultural poisons — organophosphates, aluminium phosphide.
// Crop rows in a field; a sprayer puffs pesticide droplets while a
// warning sign explains the classic "garlic smell" clue of ALP.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "poison", label: "Poison", kind: "select", min: 0, max: 0, step: 1, default: "op", options: ["op", "alp"] },
  { key: "spray", label: "Spray rate", kind: "slider", min: 0, max: 100, step: 5, default: 50, unit: "%" },
];

export const UNIQUE_META = {
  title: "Agricultural Poisons: Organophosphates & Aluminium Phosphide",
  blurb: "A sprayer mists the crop rows — learn the garlic-smell clue of aluminium phosphide and the SLUDGE signs of OP poisoning.",
};

const N_DROP = 30;

function Animator({ drops, nozzle, elapsed, spray }: { drops: React.RefObject<THREE.Group>; nozzle: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; spray: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (nozzle.current) nozzle.current.rotation.z = Math.sin(elapsed.current * 1.6) * 0.35;
    if (drops.current) {
      const on = spray / 100;
      drops.current.children.forEach((d, i) => {
        const ph = (elapsed.current * (0.5 + on) + i * 0.37) % 1;
        const spread = (i % 5) - 2;
        d.position.set(2.2 + Math.sin(elapsed.current * 1.6) * 0.6 + spread * 0.45, 3.4 - ph * 3.1, (i % 3 - 1) * 0.5);
        d.visible = ph < on;
      });
    }
  });
  return null;
}

export function Topic10163Sim(props: SimProps) {
  const poison = String(props.poison ?? "op");
  const spray = Number(props.spray ?? 50);
  const drops = useRef<THREE.Group>(null!);
  const nozzle = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const isOP = poison === "op";
  const clue = isOP ? "OP clue: SLUDGE signs (salivation, tears)" : "ALP clue: garlic / rotten-fish smell";
  const dropColor = isOP ? "#a3e635" : "#e2e8f0";

  const dropMeshes = useMemo(
    () =>
      Array.from({ length: N_DROP }, (_, i) => (
        <mesh key={i} position={[2, 3, 0]}>
          <sphereGeometry args={[0.09, 8, 8]} />
          <meshStandardMaterial color={dropColor} transparent opacity={0.85} roughness={0.3} />
        </mesh>
      )),
    [dropColor]
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Poison", isOP ? "Organophosphate" : "Aluminium phosphide"], ["Clue", clue]]} />
      <SimCanvas cameraPosition={[0, 4, 14]} target={[0, 1.5, 0]}>
        {/* soil */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#3f2d1e" roughness={1} />
        </mesh>
        {/* crop rows */}
        {[-2.4, -1.2, 0, 1.2, 2.4].map((z) =>
          [-4.5, -3, -1.5, 0, 1.5, 3, 4.5].map((x) => (
            <mesh key={`${x}${z}`} position={[x, 0.55, z]} castShadow>
              <coneGeometry args={[0.32, 1.1, 8]} />
              <meshStandardMaterial color="#4d7c0f" roughness={0.8} />
            </mesh>
          ))
        )}
        <Label text="CROP FIELD" position={[-5.6, 1.8, 2.4]} size={0.55} color="#a3e635" />
        {/* sprayer */}
        <group position={[2.2, 0, -2.8]}>
          <mesh position={[0, 1.1, 0]} castShadow>
            <boxGeometry args={[1.6, 1.4, 1.2]} />
            <meshStandardMaterial color="#f59e0b" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.35, 0]}>
            <boxGeometry args={[1.8, 0.5, 1.4]} />
            <meshStandardMaterial color="#78350f" roughness={0.8} />
          </mesh>
          {[[-0.7], [0.7]].map(([x]) => (
            <mesh key={x} position={[x, 0.35, 0.75]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[0.35, 0.35, 0.2, 14]} />
              <meshStandardMaterial color="#1e293b" roughness={0.9} />
            </mesh>
          ))}
          <group ref={nozzle} position={[0, 2.6, 0]}>
            <mesh position={[0, 0.9, 0]} rotation={[0, 0, 0.5]}>
              <cylinderGeometry args={[0.08, 0.08, 1.8, 8]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.6} roughness={0.4} />
            </mesh>
          </group>
          <Label text="SPRAYER" position={[0, 4.4, 0]} size={0.55} color="#fbbf24" />
        </group>
        <group ref={drops}>{dropMeshes}</group>
        {/* warning sign */}
        <group position={[-4.6, 0, -2.6]}>
          <mesh position={[0, 1, 0]}>
            <cylinderGeometry args={[0.08, 0.08, 2, 8]} />
            <meshStandardMaterial color="#64748b" roughness={0.7} />
          </mesh>
          <mesh position={[0, 2.4, 0]} castShadow>
            <boxGeometry args={[2.6, 1.4, 0.1]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.7} />
          </mesh>
          <Label text="⚠ POISON" position={[0, 2.4, 0.15]} size={0.5} color="#1e293b" />
          <Label text="KEEP AWAY" position={[0, 1.75, 0.15]} size={0.4} color="#1e293b" />
        </group>
        <Animator drops={drops} nozzle={nozzle} elapsed={elapsed} spray={spray} />
      </SimCanvas>
    </div>
  );
}
