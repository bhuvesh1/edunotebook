"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "gland", label: "Gland", kind: "select", min: 0, max: 0, step: 1, default: "parotid", options: ["parotid", "submandibular", "sublingual"] },
  { key: "flow", label: "Saliva flow", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Salivary glands: major and minor, histology, saliva",
  blurb: "The three major salivary glands on a head profile — pick one and watch saliva droplets stream down its duct into the mouth.",
};

const GLANDS: Record<string, { name: string; pos: [number, number, number]; duct: [number, number, number][]; color: string; note: string }> = {
  parotid: {
    name: "Parotid gland", pos: [-2.6, 4.6, 0.6], duct: [[-2.2, 4.6, 0.6], [-1.2, 4.0, 1.2], [-0.4, 3.4, 1.5]],
    color: "#fbbf24", note: "Stensen's duct → opens by upper 2nd molar",
  },
  submandibular: {
    name: "Submandibular gland", pos: [-1.4, 1.6, 0.4], duct: [[-1.4, 2.2, 0.4], [-0.9, 2.9, 1.0], [-0.3, 3.3, 1.4]],
    color: "#60a5fa", note: "Wharton's duct → floor of mouth",
  },
  sublingual: {
    name: "Sublingual gland", pos: [-0.5, 2.4, 0.8], duct: [[-0.5, 2.7, 0.8], [-0.4, 3.0, 1.2], [-0.2, 3.2, 1.4]],
    color: "#4ade80", note: "many tiny ducts → under the tongue",
  },
};

// saliva droplets streaming along a duct path
function SalivaStream({ path, flow, speed }: { path: [number, number, number][]; flow: number; speed: number }) {
  const pts = useRef<THREE.Points>(null!);
  const elapsed = useRef(0);
  const N = 40;
  const curve = new THREE.CatmullRomCurve3(path.map((p) => new THREE.Vector3(...p)));
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (!pts.current) return;
    pts.current.visible = flow > 0.05;
    const p = pts.current.geometry.attributes.position;
    for (let i = 0; i < N; i++) {
      const t = ((elapsed.current * 0.35 * flow + i / N) % 1 + 1) % 1;
      const v = curve.getPointAt(t);
      p.setXYZ(i, v.x, v.y, v.z);
    }
    p.needsUpdate = true;
  });
  return (
    <points ref={pts}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[new Float32Array(N * 3), 3]} />
      </bufferGeometry>
      <pointsMaterial color="#7dd3fc" size={0.16} transparent opacity={0.95} />
    </points>
  );
}

function GlandModel({ gland, flow, speed, showLabels }: { gland: string; flow: number; speed: number; showLabels: boolean }) {
  const active = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const cfg = GLANDS[gland] ?? GLANDS.parotid;
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (active.current) {
      const s = 1 + Math.sin(elapsed.current * 2.5) * 0.05 * flow;
      active.current.scale.setScalar(s);
    }
  });

  return (
    <group>
      {/* head profile scaffold */}
      <mesh position={[-0.4, 3.4, -0.6]} castShadow>
        <sphereGeometry args={[2.6, 28, 20]} />
        <meshPhysicalMaterial color="#f7c9a8" transparent opacity={0.32} roughness={0.4} />
      </mesh>
      {/* jaw hint */}
      <mesh position={[0.4, 1.9, 0.2]} rotation={[0, 0, -0.4]} castShadow>
        <boxGeometry args={[2.6, 0.7, 1.8]} />
        <meshPhysicalMaterial color="#f7c9a8" transparent opacity={0.32} roughness={0.4} />
      </mesh>
      {/* mouth opening target */}
      <mesh position={[-0.2, 3.3, 1.5]}>
        <sphereGeometry args={[0.3, 14, 10]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.6} />
      </mesh>

      {Object.entries(GLANDS).map(([key, g]) => {
        const isActive = key === gland;
        const acini = Array.from({ length: 9 }).map((_, i) => {
          const a = (i / 9) * Math.PI * 2;
          return [g.pos[0] + Math.cos(a) * 0.55, g.pos[1] + Math.sin(a) * 0.5, g.pos[2] + (i % 3 - 1) * 0.3] as [number, number, number];
        });
        return (
          <group key={key}>
            {/* acini cluster */}
            {acini.map((p, i) => (
              <mesh key={i} position={p} ref={isActive && i === 0 ? active : undefined} castShadow>
                <sphereGeometry args={[0.3, 14, 10]} />
                <meshStandardMaterial
                  color={g.color}
                  roughness={0.4}
                  transparent
                  opacity={isActive ? 1 : 0.35}
                  emissive={isActive ? g.color : "#000000"}
                  emissiveIntensity={isActive ? 0.35 : 0}
                />
              </mesh>
            ))}
            {/* duct */}
            <mesh position={[(g.pos[0] + g.duct[2][0]) / 2, (g.pos[1] + g.duct[2][1]) / 2, (g.pos[2] + g.duct[2][2]) / 2]} rotation={[0.4, 0, 1.1]}>
              <cylinderGeometry args={[0.09, 0.13, 2.2, 10]} />
              <meshStandardMaterial color={g.color} transparent opacity={isActive ? 0.9 : 0.3} roughness={0.4} />
            </mesh>
            {showLabels && (
              <Text position={[g.pos[0] - 1.4, g.pos[1] + 0.9, g.pos[2]]} fontSize={0.38} color={isActive ? "#fef3c7" : "#94a3b8"}>
                {g.name}
              </Text>
            )}
          </group>
        );
      })}

      <SalivaStream path={cfg.duct} flow={flow} speed={speed} />

      {/* saliva composition puffs at mouth */}
      {flow > 0.05 &&
        Array.from({ length: 6 }).map((_, i) => (
          <mesh key={i} position={[-0.2 + (Math.random() - 0.5) * 0.5, 3.0 - (i % 3) * 0.3, 1.5 + (Math.random() - 0.5) * 0.4]}>
            <sphereGeometry args={[0.09, 8, 8]} />
            <meshBasicMaterial color="#bae6fd" transparent opacity={0.8} />
          </mesh>
        ))}

      {showLabels && (
        <Text position={[0, 7.6, 0]} fontSize={0.44} color="#fef3c7" maxWidth={11}>{cfg.name}: {cfg.note}</Text>
      )}
    </group>
  );
}

export function Topic10381Sim(props: SimProps) {
  const gland = String(props.gland ?? "parotid");
  const flow = Number(props.flow ?? 1);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = GLANDS[gland] ?? GLANDS.parotid;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Gland", cfg.name],
          ["Saliva/day", "~1–1.5 L"],
          ["Contents", "amylase · lysozyme · IgA · mucin"],
        ]}
      />
      <SimCanvas cameraPosition={[6.5, 4.5, 10]} target={[-0.5, 3.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.6, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <GlandModel gland={gland} flow={flow} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
