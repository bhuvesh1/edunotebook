// Hepatitis & cirrhosis — a liver that scars as the fibrosis slider rises:
// smooth red-brown → lumpy hobnail nodules, shrinking, with ascites fluid
// pooling below and spider angiomas on the surface.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "fibrosis", label: "Fibrosis (scarring)", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "cause", label: "Cause", kind: "select", min: 0, max: 0, step: 1, default: "alcohol", options: ["alcohol", "viral hepatitis", "fatty liver"] },
];

export const UNIQUE_META = {
  title: "Hepatitis & Cirrhosis",
  blurb: "A smooth healthy liver scars into lumpy cirrhosis — nodules rise, the liver shrinks, and ascites fluid pools in the belly.",
};

function Animator({ liver, elapsed, fibrosis }: {
  liver: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  fibrosis: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (liver.current) {
      // the damaged liver throbs dully
      const s = 1 + (fibrosis / 100) * 0.015 * Math.sin(t * 2);
      liver.current.scale.set(s, s, s);
    }
  });
  return null;
}

export function Topic10227Sim(props: SimProps) {
  const fibrosis = Number(props.fibrosis ?? 60);
  const cause = String(props.cause ?? "alcohol");
  const liver = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const f = fibrosis / 100;
  const shrink = 1 - f * 0.18;
  const nodules = useMemo(() => {
    const n = Math.round(f * 26);
    return Array.from({ length: n }).map((_, i) => ({
      x: ((i * 0.73) % 3.6) - 1.8,
      y: 2.4 + ((i * 0.47) % 1.6),
      z: 0.85 + ((i * 0.31) % 0.35),
      s: 0.14 + ((i * 0.19) % 0.14),
    }));
  }, [fibrosis]);
  const cirrhotic = fibrosis > 55;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Cause", cause], ["Stage", fibrosis < 30 ? "hepatitis (inflamed)" : fibrosis < 60 ? "fibrosis" : "CIRRHOSIS ⚠"], ["Complications", cirrhotic ? "ascites + varices risk" : "none yet"]]} />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={liver} scale={[shrink, shrink, shrink]}>
          {/* liver: big right lobe + smaller left */}
          <mesh position={[0.9, 2.9, 0]} scale={[1.7, 1.05, 1.0]} castShadow>
            <sphereGeometry args={[1.25, 30, 22]} />
            <meshStandardMaterial color={cirrhotic ? "#92400e" : "#b45309"} roughness={cirrhotic ? 0.95 : 0.5} />
          </mesh>
          <mesh position={[-1.7, 3.0, 0]} scale={[0.85, 0.8, 0.8]}>
            <sphereGeometry args={[1.25, 24, 18]} />
            <meshStandardMaterial color={cirrhotic ? "#92400e" : "#b45309"} roughness={cirrhotic ? 0.95 : 0.5} />
          </mesh>
          {/* hobnail nodules */}
          {nodules.map((n, i) => (
            <mesh key={i} position={[n.x, n.y, n.z]}>
              <sphereGeometry args={[n.s, 12, 10]} />
              <meshStandardMaterial color="#d6a05c" roughness={0.9} />
            </mesh>
          ))}
          {/* spider angiomas */}
          {cirrhotic &&
            [[1.4, 3.6], [-0.6, 3.3]].map(([x, y], i) => (
              <group key={i} position={[x, y, 1.05]}>
                <mesh>
                  <sphereGeometry args={[0.09, 8, 8]} />
                  <meshBasicMaterial color="#ef4444" />
                </mesh>
                {Array.from({ length: 6 }).map((_, j) => {
                  const a = (j / 6) * Math.PI * 2;
                  return (
                    <mesh key={j} position={[Math.cos(a) * 0.22, Math.sin(a) * 0.22, 0]} rotation={[0, 0, a]}>
                      <cylinderGeometry args={[0.02, 0.02, 0.35, 6]} />
                      <meshBasicMaterial color="#ef4444" />
                    </mesh>
                  );
                })}
              </group>
            ))}
        </group>

        {/* gallbladder tucked under */}
        <mesh position={[0.2, 1.7, 0.6]}>
          <sphereGeometry args={[0.4, 16, 12]} />
          <meshStandardMaterial color="#4d7c0f" roughness={0.5} />
        </mesh>

        {/* ascites fluid in the belly */}
        {cirrhotic && (
          <mesh position={[0, -0.5, 0]}>
            <cylinderGeometry args={[3.4, 3.8, 1.6, 28]} />
            <meshStandardMaterial color="#38bdf8" transparent opacity={0.35 + f * 0.25} roughness={0.2} />
          </mesh>
        )}

        <Label text={cirrhotic ? "Cirrhosis — hard, lumpy, shrunken" : fibrosis > 25 ? "Fibrosis building up" : "Healthy smooth liver"} position={[0, 5.4, 0]} size={0.52} color={cirrhotic ? "#fca5a5" : "#86efac"} />
        {cirrhotic && <Label text="Ascites — fluid in the belly" position={[0, -1.8, 0]} size={0.48} color="#7dd3fc" />}
        <Label text="Hepatitis B vaccine prevents a top cause" position={[0, -2.9, 0]} size={0.42} color="#94a3b8" />
        <Animator liver={liver} elapsed={elapsed} fibrosis={fibrosis} />
      </SimCanvas>
    </div>
  );
}
