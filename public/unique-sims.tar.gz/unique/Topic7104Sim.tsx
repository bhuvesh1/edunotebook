// app/components/sims/unique/Topic7104Sim.tsx
// Motion in a plane with constant acceleration: a ball rolls off a cliff
// with horizontal velocity and gravity bends its path into a parabola.
// Green arrow: vx stays constant. Orange arrow: vy grows downward.

"use client";

import { useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Horizontal speed", kind: "slider", min: 1, max: 6, step: 0.5, default: 3, unit: "m/s" },
];

export const UNIQUE_META = {
  title: "Motion in a Plane, Constant Acceleration",
  blurb: "Roll off a cliff: horizontal velocity stays constant while gravity grows the downward velocity.",
};

const G = 9.8;
const CLIFF_H = 5.5;
const EDGE_X = -4;

function Animator({
  ball, vxShaft, vxCone, vyShaft, vyCone, trail, trailGeo, v0, state, bump,
}: {
  ball: RefObject<THREE.Mesh>;
  vxShaft: RefObject<THREE.Mesh>;
  vxCone: RefObject<THREE.Mesh>;
  vyShaft: RefObject<THREE.Mesh>;
  vyCone: RefObject<THREE.Mesh>;
  trail: RefObject<THREE.Line>;
  trailGeo: THREE.BufferGeometry;
  v0: number;
  state: RefObject<{ x: number; y: number }>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const fallT = Math.sqrt((2 * CLIFF_H) / G);
    const T = t.current % (fallT + 1.0);
    const ft = Math.min(T, fallT);
    const x = EDGE_X + v0 * ft;
    const y = 0.4 + CLIFF_H - 0.5 * G * ft * ft;
    state.current = { x: x - EDGE_X, y: y - 0.4 };
    if (ball.current) ball.current.position.set(x, y, 0);
    // Trail: parabola points.
    const pos = trailGeo.attributes.position as THREE.BufferAttribute;
    const TN = 60;
    for (let i = 0; i < TN; i++) {
      const f = (i / (TN - 1)) * ft;
      pos.setXYZ(i, EDGE_X + v0 * f, 0.4 + CLIFF_H - 0.5 * G * f * f, 0);
    }
    pos.needsUpdate = true;
    if (trail.current) trail.current.geometry.setDrawRange(0, ft > 0.01 ? 60 : 0);
    // vx constant, vy = gt downward.
    const vy = G * ft;
    const setArrow = (
      shaft: RefObject<THREE.Mesh>, cone: RefObject<THREE.Mesh>,
      L: number, dirX: number, dirY: number
    ) => {
      if (shaft.current) {
        shaft.current.scale.set(1, Math.max(L, 0.001), 1);
        shaft.current.position.set((dirX * L) / 2, (dirY * L) / 2, 0);
      }
      if (cone.current) {
        cone.current.position.set(dirX * (L + 0.18), dirY * (L + 0.18), 0);
        cone.current.rotation.z = dirX === 1 ? -Math.PI / 2 : Math.PI;
      }
    };
    setArrow(vxShaft, vxCone, 0.5 + v0 * 0.4, 1, 0);
    setArrow(vyShaft, vyCone, 0.3 + vy * 0.22, 0, -1);
    if (ball.current) {
      // Move arrows with the ball: arrows live in a group positioned at ball.
    }
    if (++n.current % 15 === 0) bump();
  });
  return null;
}

export function Topic7104Sim(props: SimProps) {
  const v0 = Number(props.speed ?? 3);
  const ball = useRef<THREE.Mesh>(null!);
  const arrows = useRef<THREE.Group>(null!);
  const vxShaft = useRef<THREE.Mesh>(null!);
  const vxCone = useRef<THREE.Mesh>(null!);
  const vyShaft = useRef<THREE.Mesh>(null!);
  const vyCone = useRef<THREE.Mesh>(null!);
  const trail = useRef<THREE.Line>(null!);
  const state = useRef({ x: 0, y: CLIFF_H });
  const [, bump] = useState(0);

  const trailGeo = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(60 * 3), 3));
    return geo;
  }, []);

  // Keep arrows glued to the ball each frame via a second tiny animator.
  function Glue() {
    useFrame(() => {
      if (ball.current && arrows.current) arrows.current.position.copy(ball.current.position);
    });
    return null;
  }

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["vx (horizontal)", `${v0.toFixed(1)} m/s — constant`],
          ["vy (vertical)", "grows: vy = gt"],
          ["🟢 Green", "vx arrow"],
          ["🟠 Orange", "vy arrow"],
        ]}
      />
      <SimCanvas cameraPosition={[1, 4.5, 13]} target={[0, 2.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* cliff */}
        <mesh position={[EDGE_X - 2.5, CLIFF_H / 2, 0]} castShadow receiveShadow>
          <boxGeometry args={[5, CLIFF_H, 4]} />
          <meshStandardMaterial color="#57534e" roughness={0.95} />
        </mesh>
        <mesh position={[EDGE_X - 2.5, CLIFF_H + 0.15, 0]} receiveShadow>
          <boxGeometry args={[5.4, 0.3, 4.4]} />
          <meshStandardMaterial color="#78716c" roughness={0.9} />
        </mesh>

        <primitive object={new THREE.Line(trailGeo, new THREE.LineBasicMaterial({ color: "#fbbf24" }))} ref={trail} />

        <mesh ref={ball} position={[EDGE_X, 0.4 + CLIFF_H, 0]} castShadow>
          <sphereGeometry args={[0.36, 26, 26]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.35} />
        </mesh>

        {/* velocity component arrows, glued to the ball */}
        <group ref={arrows}>
          <mesh ref={vxShaft}>
            <cylinderGeometry args={[0.08, 0.08, 1, 10]} />
            <meshStandardMaterial color="#22c55e" emissive="#15803d" emissiveIntensity={0.6} roughness={0.4} />
          </mesh>
          <mesh ref={vxCone}>
            <coneGeometry args={[0.2, 0.4, 12]} />
            <meshStandardMaterial color="#22c55e" emissive="#15803d" emissiveIntensity={0.6} roughness={0.4} />
          </mesh>
          <mesh ref={vyShaft}>
            <cylinderGeometry args={[0.08, 0.08, 1, 10]} />
            <meshStandardMaterial color="#fb923c" emissive="#c2410c" emissiveIntensity={0.6} roughness={0.4} />
          </mesh>
          <mesh ref={vyCone}>
            <coneGeometry args={[0.2, 0.4, 12]} />
            <meshStandardMaterial color="#fb923c" emissive="#c2410c" emissiveIntensity={0.6} roughness={0.4} />
          </mesh>
        </group>

        <Animator
          ball={ball} vxShaft={vxShaft} vxCone={vxCone} vyShaft={vyShaft} vyCone={vyCone}
          trail={trail} trailGeo={trailGeo} v0={v0} state={state}
          bump={() => bump((v) => v + 1)}
        />
        <Glue />
      </SimCanvas>
    </div>
  );
}
