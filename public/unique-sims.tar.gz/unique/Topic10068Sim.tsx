"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Urea Cycle",
  blurb: "Nitrogen travels the 5-enzyme urea cycle; urea exits at arginase to be excreted by the kidney.",
};

const USTEPS: [string, string][] = [["CPS-I","#f472b6"],["OTC","#fb923c"],["ASS","#facc15"],["ASL","#4ade80"],["Arginase","#38bdf8"]];

function Animator({ root, trav, urea, nh3, elapsed, speed }: { root: RefObject<THREE.Group>; trav: RefObject<THREE.Mesh>; urea: RefObject<THREE.Mesh>; nh3: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const a = t * 0.7;
    if (trav.current) trav.current.position.set(Math.cos(a) * 2.6, 1.8, Math.sin(a) * 2.6);
    if (urea.current) {
      const q = (t * 0.7) % 1;
      const a4 = (4 / 5) * Math.PI * 2;
      urea.current.position.set(Math.cos(a4) * (2.6 + q * 3), 1.8 + q * 0.8, Math.sin(a4) * (2.6 + q * 3));
    }
    if (nh3.current) {
      nh3.current.children.forEach((m, i) => {
        const r = (t * 0.9 + i / 2) % 1;
        m.position.set(3.4 - r * 1.4, 1.8 + Math.sin(r * 5) * 0.2, 0.6 - i * 0.5);
      });
    }
  });
  return null;
}

export function Topic10068Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const trav = useRef<THREE.Mesh>(null!);
  const urea = useRef<THREE.Mesh>(null!);
  const nh3 = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Net", "2 NH\u2083 + CO\u2082 \u2192 urea"],
          ["ATP cost", "4 high-energy phosphates"],
          ["Site", "liver (mitochondria + cytosol)"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 11]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          {USTEPS.map(([name, color], i) => {
            const a = (i / 5) * Math.PI * 2;
            return (
              <group key={name}>
                <mesh position={[Math.cos(a) * 2.6, 1.8, Math.sin(a) * 2.6]} castShadow>
                  <boxGeometry args={[0.95, 0.95, 0.95]} /><meshStandardMaterial color={color} roughness={0.5} />
                </mesh>
                <Label text={name} position={[Math.cos(a) * 2.6, 2.75, Math.sin(a) * 2.6]} size={0.4} color={color} />
              </group>
            );
          })}
          <mesh ref={trav}>
            <sphereGeometry args={[0.22, 14, 14]} /><meshStandardMaterial color="#ffffff" emissive="#38bdf8" emissiveIntensity={2.2} />
          </mesh>
          <mesh ref={urea} castShadow>
            <sphereGeometry args={[0.3, 16, 16]} /><meshStandardMaterial color="#22d3ee" emissive="#0891b2" emissiveIntensity={1} />
          </mesh>
          <group ref={nh3}>
            {[0, 1].map((i) => (
              <mesh key={i}><sphereGeometry args={[0.16, 10, 10]} /><meshStandardMaterial color="#c4b5fd" emissive="#8b5cf6" emissiveIntensity={0.8} /></mesh>
            ))}
          </group>
          <Label text="NH\u2083 + CO\u2082 in" position={[4.3, 2.6, 0]} size={0.42} color="#c4b5fd" />
          <Label text="urea \u2192 kidney" position={[-0.4, 3.6, -3.4]} size={0.42} color="#22d3ee" />
        </group>
        <Animator root={root} trav={trav} urea={urea} nh3={nh3} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
