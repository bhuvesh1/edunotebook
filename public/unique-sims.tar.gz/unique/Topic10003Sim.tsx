"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "elbow", label: "Elbow flexion", kind: "slider", min: 0, max: 140, step: 5, default: 45, unit: "°" },
  { key: "speed", label: "Motion speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Upper limb: pectoral region, axilla, arm, forearm, hand",
  blurb: "The arm's skeleton on the move: humerus, radius and ulna swing at the elbow while the hand follows.",
};

function Arm({ elbow, speed }: { elbow: number; speed: number }) {
  const fore = useRef<THREE.Group>(null!);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d * speed;
    const base = (elbow * Math.PI) / 180;
    if (fore.current) fore.current.rotation.z = base * 0.75 + Math.sin(t.current * 1.4) * base * 0.25;
  });
  const bone = { color: "#f5f0e6", roughness: 0.55 };
  return (
    <group position={[-1.5, 1.4, 0]}>
      {/* clavicle + scapula hint */}
      <mesh position={[1.4, 3.4, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <cylinderGeometry args={[0.14, 0.14, 2.0, 10]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      {/* humerus */}
      <mesh position={[0, 2.2, 0]} castShadow>
        <cylinderGeometry args={[0.3, 0.34, 2.6, 14]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      <mesh position={[0, 3.55, 0]} castShadow>
        <sphereGeometry args={[0.45, 16, 16]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      {/* elbow */}
      <mesh position={[0, 0.85, 0]} castShadow>
        <sphereGeometry args={[0.34, 16, 16]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      {/* forearm: radius + ulna */}
      <group ref={fore} position={[0, 0.85, 0]}>
        <mesh position={[0.18, -1.1, 0]} castShadow>
          <cylinderGeometry args={[0.16, 0.2, 2.2, 12]} />
          <meshStandardMaterial {...bone} />
        </mesh>
        <mesh position={[-0.18, -1.1, 0]} castShadow>
          <cylinderGeometry args={[0.14, 0.18, 2.2, 12]} />
          <meshStandardMaterial {...bone} />
        </mesh>
        {/* wrist + hand */}
        <mesh position={[0, -2.35, 0]} castShadow>
          <boxGeometry args={[0.55, 0.25, 0.35]} />
          <meshStandardMaterial {...bone} />
        </mesh>
        <mesh position={[0, -2.85, 0]} castShadow>
          <boxGeometry args={[0.7, 0.7, 0.28]} />
          <meshStandardMaterial {...bone} />
        </mesh>
        {[-0.24, -0.08, 0.08, 0.24].map((x) => (
          <mesh key={x} position={[x, -3.45, 0]} castShadow>
            <cylinderGeometry args={[0.06, 0.05, 0.6, 8]} />
            <meshStandardMaterial {...bone} />
          </mesh>
        ))}
        <mesh position={[0.42, -2.95, 0]} rotation={[0, 0, -0.5]} castShadow>
          <cylinderGeometry args={[0.06, 0.05, 0.5, 8]} />
          <meshStandardMaterial {...bone} />
        </mesh>
      </group>
    </group>
  );
}

export function Topic10003Sim(props: SimProps) {
  const elbow = Number(props.elbow ?? 45);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Elbow", elbow + "°"], ["Bones", "30 per limb"], ["Joint", "hinge"]]} />
      <SimCanvas cameraPosition={[6, 3.5, 11]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Arm elbow={elbow} speed={speed} />
        {showLabels && (
          <>
            <Label text="Humerus" position={[-3.2, 4.6, 0]} color="#fef3c7" size={0.5} />
            <Label text="Radius + ulna" position={[2.4, 1.6, 0]} color="#fef3c7" size={0.5} />
            <Label text="Hand" position={[2.6, -1.4, 0]} color="#fef3c7" size={0.5} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
