// Audiology & cochlear implants — the ear in cutaway: pinna, ear canal,
// eardrum, the three ossicles (hammer/anvil/stirrup), the snail-shaped
// cochlea with an implant electrode threaded in. Sound rings travel in;
// ossicles vibrate; implant pulses glow.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "loss", label: "Hearing loss", kind: "slider", min: 0, max: 100, step: 5, default: 70, unit: "%" },
  { key: "implant", label: "Cochlear implant", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Audiology & Cochlear Implants",
  blurb: "Sound waves travel the ear canal, shake the tiny bones, and a cochlear implant's electrode turns sound into nerve pulses.",
};

function Animator({ ossicles, rings, implant, elapsed, loss }: {
  ossicles: React.RefObject<THREE.Group>;
  rings: React.RefObject<THREE.Group>;
  implant: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  loss: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const vib = (1 - loss / 130);
    if (ossicles.current) {
      ossicles.current.children.forEach((c, i) => {
        c.rotation.z = Math.sin(t * 22 + i * 1.2) * 0.1 * vib;
      });
    }
    if (rings.current) {
      rings.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * 0.7 + i * 0.2) % 1);
        m.position.x = -6 + ph * 3.4;
        m.scale.setScalar(0.4 + ph * 1.1);
        ((m as THREE.Mesh).material as THREE.MeshBasicMaterial).opacity = 0.65 * (1 - ph * 0.5);
      });
    }
    if (implant.current) {
      implant.current.children.forEach((c, i) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = 0.4 + 0.6 * Math.max(0, Math.sin(t * 8 - i * 0.9));
      });
    }
  });
  return null;
}

export function Topic10197Sim(props: SimProps) {
  const loss = Number(props.loss ?? 70);
  const implantOn = String(props.implant ?? "on") === "on";
  const ossicles = useRef<THREE.Group>(null!);
  const rings = useRef<THREE.Group>(null!);
  const implant = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const heard = implantOn ? "implant restores nerve signal ✓" : loss > 60 ? "severe loss — faint sound" : "muffled";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Hearing loss", `${loss}%`], ["Implant", implantOn ? "ON" : "OFF"], ["Result", heard]]} />
      <SimCanvas cameraPosition={[0, 2.6, 12]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* pinna */}
        <mesh position={[-4.6, 2.6, 0]} scale={[0.7, 1.25, 0.5]} castShadow>
          <torusGeometry args={[1.0, 0.42, 14, 28]} />
          <meshStandardMaterial color="#f5d0b8" roughness={0.6} />
        </mesh>
        {/* ear canal */}
        <mesh position={[-3.0, 2.4, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.5, 0.42, 2.6, 16]} />
          <meshStandardMaterial color="#e8b08a" roughness={0.6} side={THREE.DoubleSide} />
        </mesh>
        {/* eardrum */}
        <mesh position={[-1.65, 2.4, 0]} rotation={[0, Math.PI / 2, 0]}>
          <circleGeometry args={[0.5, 20]} />
          <meshStandardMaterial color="#fde68a" roughness={0.4} emissive="#a16207" emissiveIntensity={0.3} side={THREE.DoubleSide} />
        </mesh>
        {/* ossicles: malleus, incus, stapes */}
        <group ref={ossicles}>
          <mesh position={[-1.2, 2.5, 0]} rotation={[0, 0, 0.5]}>
            <boxGeometry args={[0.16, 0.9, 0.16]} />
            <meshStandardMaterial color="#fefce8" roughness={0.4} />
          </mesh>
          <mesh position={[-0.65, 2.6, 0]} rotation={[0, 0, -0.4]}>
            <boxGeometry args={[0.16, 0.7, 0.16]} />
            <meshStandardMaterial color="#fefce8" roughness={0.4} />
          </mesh>
          <mesh position={[-0.2, 2.62, 0]}>
            <torusGeometry args={[0.16, 0.07, 8, 16]} />
            <meshStandardMaterial color="#fefce8" roughness={0.4} />
          </mesh>
        </group>
        {/* cochlea: snail spiral */}
        <group position={[0.9, 2.2, 0]}>
          {[1.35, 1.0, 0.68, 0.4].map((r, i) => (
            <mesh key={i} position={[i * 0.18, -i * 0.05, 0]} rotation={[0, 0, i * 0.9]}>
              <torusGeometry args={[r, 0.2, 10, 28, Math.PI * 1.7]} />
              <meshStandardMaterial color="#c084fc" roughness={0.45} />
            </mesh>
          ))}
        </group>
        {/* implant: processor behind ear + electrode threaded into cochlea */}
        {implantOn && (
          <group ref={implant}>
            <mesh position={[-4.9, 4.3, 0]}>
              <boxGeometry args={[0.7, 0.9, 0.5]} />
              <meshStandardMaterial color="#38bdf8" roughness={0.4} emissive="#0c4a6e" emissiveIntensity={0.6} />
            </mesh>
            <mesh position={[-2.2, 3.6, 0]} rotation={[0, 0, Math.PI / 2.8]}>
              <cylinderGeometry args={[0.06, 0.06, 5.4, 8]} />
              <meshStandardMaterial color="#38bdf8" roughness={0.4} emissive="#0c4a6e" emissiveIntensity={0.8} />
            </mesh>
            {[0.7, 1.15, 1.6].map((x, i) => (
              <mesh key={i} position={[x, 2.2 + Math.sin(i * 2) * 0.25, 0]}>
                <sphereGeometry args={[0.13, 10, 10]} />
                <meshStandardMaterial color="#38bdf8" emissive="#38bdf8" emissiveIntensity={0.8} roughness={0.3} />
              </mesh>
            ))}
            <Label text="Implant electrode → stimulates nerve" position={[0.4, 4.4, 0]} size={0.48} color="#7dd3fc" />
          </group>
        )}
        {/* auditory nerve */}
        <mesh position={[2.6, 2.0, 0]} rotation={[0, 0, Math.PI / 2.3]}>
          <cylinderGeometry args={[0.2, 0.24, 2.6, 12]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.5} />
        </mesh>

        {/* incoming sound rings */}
        <group ref={rings}>
          {Array.from({ length: 5 }).map((_, i) => (
            <mesh key={i} position={[-6, 2.4, 0]} rotation={[0, Math.PI / 2, 0]}>
              <torusGeometry args={[0.5, 0.06, 8, 28]} />
              <meshBasicMaterial color="#fde047" transparent opacity={0.6} />
            </mesh>
          ))}
        </group>

        <Label text="Pinna" position={[-4.6, 4.6, 0]} size={0.48} color="#e2e8f0" />
        <Label text="Ossicles: hammer · anvil · stirrup" position={[-0.7, 3.9, 0]} size={0.48} color="#fefce8" />
        <Label text="Cochlea (snail)" position={[0.9, 0.9, 0]} size={0.48} color="#d8b4fe" />
        <Animator ossicles={ossicles} rings={rings} implant={implant} elapsed={elapsed} loss={loss} />
      </SimCanvas>
    </div>
  );
}
