"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dx", label: "Diagnosis", kind: "select", min: 0, max: 0, step: 1, default: "irreversible", options: ["healthy", "reversible", "irreversible", "necrosis"] },
  { key: "speed", label: "Pulse speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Pulp biology: diagnosis of pulp and periapical diseases",
  blurb: "Tooth sliced open — enamel, dentin, living pulp with nerves — and a periapical lesion blooming at the root tip as disease worsens.",
};

const DX: Record<string, { name: string; pulp: string; glow: number; lesion: number; note: string; color: string }> = {
  healthy: { name: "Healthy pulp", pulp: "#fca5a5", glow: 0, lesion: 0, note: "Vital — responds normally to cold", color: "#86efac" },
  reversible: { name: "Reversible pulpitis", pulp: "#fb7185", glow: 0.4, lesion: 0.25, note: "Sharp short pain — filling saves it", color: "#fde68a" },
  irreversible: { name: "Irreversible pulpitis", pulp: "#e11d48", glow: 1.2, lesion: 0.55, note: "Lingering pain — needs root canal", color: "#fb923c" },
  necrosis: { name: "Pulp necrosis", pulp: "#57534e", glow: 0, lesion: 1, note: "Dead pulp — abscess at the root tip", color: "#f87171" },
};

function Scene({ dx, speed }: { dx: string; speed: number }) {
  const t = useRef(0);
  const pulp = useRef<THREE.Mesh>(null!);
  const lesion = useRef<THREE.Mesh>(null!);
  const d = DX[dx] ?? DX.irreversible;

  useFrame((_, delta) => {
    t.current += delta * speed;
    if (pulp.current) {
      const m = pulp.current.material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = d.glow * (0.7 + Math.sin(t.current * 4) * 0.3);
    }
    if (lesion.current) {
      lesion.current.scale.setScalar(Math.max(0.01, d.lesion) * (1 + Math.sin(t.current * 2.5) * 0.06));
      lesion.current.visible = d.lesion > 0.01;
    }
  });

  return (
    <group>
      {/* tooth half-section: enamel shell */}
      <mesh position={[0, 0.7, 0]}>
        <cylinderGeometry args={[1.0, 1.15, 1.5, 20, 1, false, 0, Math.PI]} />
        <meshStandardMaterial color="#fdfbf3" roughness={0.2} side={THREE.DoubleSide} />
      </mesh>
      {/* dentin */}
      <mesh position={[0, 0.7, 0]}>
        <cylinderGeometry args={[0.78, 0.9, 1.35, 18, 1, false, 0, Math.PI]} />
        <meshStandardMaterial color="#f5d78e" roughness={0.5} side={THREE.DoubleSide} />
      </mesh>
      {/* pulp chamber + canal */}
      <mesh ref={pulp} position={[0, 0.35, 0]}>
        <cylinderGeometry args={[0.24, 0.18, 2.1, 12]} />
        <meshStandardMaterial color={d.pulp} emissive="#ef4444" emissiveIntensity={d.glow} roughness={0.5} />
      </mesh>
      <mesh ref={pulp} position={[0, 1.15, 0]}>
        <sphereGeometry args={[0.34, 14, 14]} />
        <meshStandardMaterial color={d.pulp} emissive="#ef4444" emissiveIntensity={d.glow} roughness={0.5} />
      </mesh>
      {/* nerve fibres */}
      {[0.2, -0.2].map((x, i) => (
        <mesh key={i} position={[x, -0.5, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 1.4, 6]} />
          <meshStandardMaterial color="#facc15" roughness={0.4} />
        </mesh>
      ))}
      {/* root */}
      <mesh position={[0, -0.9, 0]}>
        <cylinderGeometry args={[0.62, 0.4, 1.5, 16, 1, false, 0, Math.PI]} />
        <meshStandardMaterial color="#e8dcc8" roughness={0.5} side={THREE.DoubleSide} />
      </mesh>

      {/* periapical lesion at apex */}
      <mesh ref={lesion} position={[0, -1.85, 0]}>
        <sphereGeometry args={[0.55, 16, 16]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.7} transparent opacity={0.85} />
      </mesh>
      {d.lesion > 0.01 && <Label text="Periapical lesion" position={[1.7, -1.85, 0]} size={0.42} color="#fca5a5" />}

      <Label text="Enamel" position={[1.9, 1.3, 0]} size={0.4} color="#fefce8" />
      <Label text="Dentin" position={[1.9, 0.7, 0]} size={0.4} color="#fde68a" />
      <Label text="Pulp (nerve + vessels)" position={[1.9, 0.1, 0]} size={0.4} color={d.pulp === "#57534e" ? "#a8a29e" : "#fca5a5"} />

      {/* cold test spray */}
      {dx !== "necrosis" && (
        <group position={[-2.2, 2.2, 0]}>
          <mesh rotation={[0, 0, -0.6]}>
            <cylinderGeometry args={[0.18, 0.22, 0.9, 10]} />
            <meshStandardMaterial color="#7dd3fc" roughness={0.4} />
          </mesh>
          <Label text="Cold test" position={[0, 0.9, 0]} size={0.4} color="#7dd3fc" />
        </group>
      )}

      <Label text={d.name} position={[0, 3.3, 0]} size={0.6} color={d.color} />
      <Label text={d.note} position={[0, -2.9, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10448Sim(props: SimProps) {
  const dx = String(props.dx ?? "irreversible");
  const speed = Number(props.speed ?? 1);
  const d = DX[dx] ?? DX.irreversible;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Diagnosis", d.name], ["Pulp", dx === "necrosis" ? "Non-vital" : "Vital"], ["Treatment", dx === "healthy" ? "None" : dx === "reversible" ? "Filling" : "Root canal"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 9]} target={[0, 0.2, 0]}>
        <Scene dx={dx} speed={speed} />
      </SimCanvas>
    </div>
  );
}
