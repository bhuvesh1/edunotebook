// Special senses: vision, hearing, taste, smell — four working mini-models in
// one scene: light focusing in the eye, sound waves spiralling into the
// cochlea, taste buds on a tongue, and odor molecules rising to the nose.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "sense", label: "Sense to spotlight", kind: "select", min: 0, max: 0, step: 1, default: "all", options: ["all", "vision", "hearing", "taste", "smell"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Special Senses: 4-in-1",
  blurb: "Light focuses in the eye, sound spirals into the cochlea, taste buds fire, and odors rise to the nose.",
};

function Animator({
  lightRays, soundWaves, odor, tongue, elapsed, speed,
}: {
  lightRays: React.RefObject<THREE.Group>;
  soundWaves: React.RefObject<THREE.Group>;
  odor: React.RefObject<THREE.Group>;
  tongue: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (lightRays.current) {
      lightRays.current.children.forEach((m, i) => {
        const mat = (m as THREE.Mesh).material as THREE.MeshBasicMaterial;
        mat.opacity = 0.4 + 0.35 * Math.sin(t * 5 - i * 0.8);
      });
    }
    if (soundWaves.current) {
      soundWaves.current.children.forEach((m, i) => {
        const ph = ((t * 0.6 + i / 6) % 1 + 1) % 1;
        m.position.x = -6.5 + ph * 4.2;
        m.scale.setScalar(0.5 + ph * 1.1);
        const mat = (m as THREE.Mesh).material as THREE.MeshBasicMaterial;
        mat.opacity = 0.7 - ph * 0.4;
      });
    }
    if (odor.current) {
      odor.current.children.forEach((m, i) => {
        const ph = ((t * 0.35 + i / 8) % 1 + 1) % 1;
        m.position.y = 0.8 + ph * 2.4;
        m.position.x = 5.6 + Math.sin(t * 2 + i * 2.1) * 0.4;
      });
    }
    if (tongue.current) {
      tongue.current.children.forEach((m, i) => {
        const s = 1 + 0.25 * Math.max(0, Math.sin(t * 3 + i * 1.4));
        m.scale.setScalar(s);
      });
    }
  });
  return null;
}

export function Topic10056Sim(props: SimProps) {
  const sense = String(props.sense ?? "all");
  const speed = Number(props.speed ?? 1);
  const lightRays = useRef<THREE.Group>(null!);
  const soundWaves = useRef<THREE.Group>(null!);
  const odor = useRef<THREE.Group>(null!);
  const tongue = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const dim = (s: string) => (sense === "all" || sense === s ? 1 : 0.22);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Spotlight", sense === "all" ? "all four senses" : sense],
          ["Transduction", "stimulus → receptor → brain"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 17]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[44, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* VISION: eye focusing light */}
         <group position={[-8, 2.4, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[1.2, 22, 22]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.25} transparent opacity={dim("vision")} />
          </mesh>
          <mesh position={[0.5, 0, 0]} scale={[0.55, 1, 1]}>
            <sphereGeometry args={[0.45, 16, 16]} />
            <meshStandardMaterial color="#38bdf8" transparent opacity={0.85 * dim("vision")} roughness={0.15} />
          </mesh>
          <mesh position={[-0.9, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
            <circleGeometry args={[0.65, 18]} />
            <meshBasicMaterial color="#f97316" transparent opacity={dim("vision")} />
          </mesh>
        </group>
        <group ref={lightRays}>
          {[-0.5, -0.15, 0.2, 0.55].map((dy, i) => (
            <mesh key={i} position={[-10.6, 2.4 + dy, 0]} rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.04, 0.04, 2.6 - Math.abs(dy) * 2, 8]} />
              <meshBasicMaterial color="#fef08a" transparent opacity={0.6 * dim("vision")} />
            </mesh>
          ))}
        </group>
        <Label text="👁 vision — lens → retina" position={[-8, 4.4, 0]} size={0.36} color="#f8fafc" />

        {/* HEARING: ear canal -> eardrum -> ossicles -> cochlea spiral */}
         <group position={[-2.6, 0, 0]}>
          {/* pinna */}
          <mesh position={[0, 2.4, 0]} castShadow scale={[1, 1.3, 0.5]}>
            <torusGeometry args={[0.7, 0.28, 10, 20]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.55} transparent opacity={dim("hearing")} />
          </mesh>
          {/* canal */}
          <mesh position={[1.0, 2.4, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
            <cylinderGeometry args={[0.3, 0.3, 1.6, 12]} />
            <meshStandardMaterial color="#f0abfc" roughness={0.5} transparent opacity={dim("hearing")} />
          </mesh>
          {/* eardrum */}
          <mesh position={[1.85, 2.4, 0]} rotation={[0, Math.PI / 2, 0]}>
            <circleGeometry args={[0.3, 16]} />
            <meshStandardMaterial color="#fda4af" transparent opacity={dim("hearing")} side={THREE.DoubleSide} />
          </mesh>
          {/* ossicles: malleus, incus, stapes */}
          {[2.3, 2.65, 3.0].map((x, i) => (
            <mesh key={i} position={[x, 2.4 + (i === 1 ? 0.12 : 0), 0]} castShadow>
              <boxGeometry args={[0.14, 0.4 - i * 0.08, 0.14]} />
              <meshStandardMaterial color="#e7e5e4" roughness={0.5} transparent opacity={dim("hearing")} />
            </mesh>
          ))}
          {/* cochlea: snail spiral */}
          <mesh position={[3.9, 2.4, 0]} castShadow>
            <torusGeometry args={[0.45, 0.2, 10, 24, Math.PI * 1.75]} />
            <meshStandardMaterial color="#c084fc" roughness={0.45} transparent opacity={dim("hearing")} />
          </mesh>
          <mesh position={[3.9, 2.4, 0]}>
            <sphereGeometry args={[0.16, 10, 10]} />
            <meshStandardMaterial color="#a855f7" transparent opacity={dim("hearing")} />
          </mesh>
        </group>
        <group ref={soundWaves}>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[-6.5, 2.4, 0]}>
              <torusGeometry args={[0.4, 0.05, 8, 20]} />
              <meshBasicMaterial color="#7dd3fc" transparent opacity={0.6 * dim("hearing")} />
            </mesh>
          ))}
        </group>
        <Label text="👂 hearing — eardrum → ossicles → cochlea" position={[-2.6, 4.2, 0]} size={0.34} color="#f8fafc" />
        <Label text="cochlea (snail)" position={[3.9, 1.4, 0]} size={0.3} color="#d8b4fe" />

        {/* TASTE: tongue with papillae/taste buds */}
         <group position={[2.2, 0, 0]}>
          <mesh position={[0, 1.0, 0]} castShadow scale={[1.5, 0.55, 1.1]}>
            <sphereGeometry args={[0.9, 18, 18]} />
            <meshStandardMaterial color="#f87171" roughness={0.5} transparent opacity={dim("taste")} />
          </mesh>
          <group ref={tongue}>
            {[[-0.7, 1.35], [-0.2, 1.5], [0.35, 1.42], [0.8, 1.3]].map(([x, y], i) => (
              <mesh key={i} position={[x, y, 0.2]}>
                <sphereGeometry args={[0.13, 10, 10]} />
                <meshStandardMaterial color="#fecaca" emissive="#dc2626"
                  emissiveIntensity={0.4 * dim("taste")} roughness={0.4} transparent opacity={dim("taste")} />
              </mesh>
            ))}
          </group>
        </group>
        <Label text="👅 taste — buds: sweet/salt/sour/bitter/umami" position={[2.2, 2.6, 0]} size={0.32} color="#f8fafc" />

        {/* SMELL: nose with odor molecules rising to olfactory epithelium */}
         <group position={[5.6, 0, 0]}>
          <mesh position={[0, 2.2, 0]} castShadow scale={[0.8, 1.2, 0.9]}>
            <coneGeometry args={[0.6, 1.6, 12]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.55} transparent opacity={dim("smell")} />
          </mesh>
          {/* olfactory epithelium */}
          <mesh position={[0, 3.1, 0]}>
            <boxGeometry args={[0.7, 0.18, 0.6]} />
            <meshStandardMaterial color="#fbbf24" emissive="#92400e"
              emissiveIntensity={0.5 * dim("smell")} roughness={0.4} transparent opacity={dim("smell")} />
          </mesh>
          {/* flower source of odor */}
          <mesh position={[-0.9, 0.5, 0.6]} castShadow>
            <sphereGeometry args={[0.3, 12, 12]} />
            <meshStandardMaterial color="#f472b6" roughness={0.5} transparent opacity={dim("smell")} />
          </mesh>
          <mesh position={[-0.9, 0.1, 0.6]}>
            <cylinderGeometry args={[0.05, 0.05, 0.5, 6]} />
            <meshStandardMaterial color="#4ade80" transparent opacity={dim("smell")} />
          </mesh>
        </group>
        <group ref={odor}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[5.6, 0.8, 0]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshBasicMaterial color="#f0abfc" transparent opacity={0.8 * dim("smell")} />
            </mesh>
          ))}
        </group>
        <Label text="👃 smell — odor → olfactory epithelium" position={[5.6, 4.1, 0]} size={0.32} color="#f8fafc" />

        <Animator lightRays={lightRays} soundWaves={soundWaves} odor={odor} tongue={tongue}
          elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
