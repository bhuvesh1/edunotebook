// Community ophthalmology — blindness prevention & eye donation. A donor
// cornea flies from a donor eye to a blind eye and it lights up; a shield
// ring shows prevention (screening/vitamin A/glasses). Awareness slider
// speeds up the donations.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "awareness", label: "Donation awareness", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "labels", label: "Labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Blindness Prevention & Eye Donation",
  blurb: "One donor cornea restores sight to a blind eye — raise awareness and watch more donations fly across.",
};

function Animator({ grafts, elapsed, awareness }: {
  grafts: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  awareness: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (grafts.current) {
      const n = grafts.current.children.length;
      grafts.current.children.forEach((c, i) => {
        const period = 7 - (awareness / 100) * 4;
        const ph = ((t + i * period * 0.7) % period) / period;
        // arc from donor (left) to recipient (right)
        c.position.x = -4 + ph * 8;
        c.position.y = 3.4 + Math.sin(ph * Math.PI) * 1.6;
        c.position.z = 0;
        c.visible = i < Math.max(1, Math.round((awareness / 100) * n));
      });
    }
  });
  return null;
}

function BigEye({ x, blind, glow }: { x: number; blind: boolean; glow: number }) {
  return (
    <group position={[x, 1.6, 0]}>
      <mesh castShadow>
        <sphereGeometry args={[1.7, 32, 26]} />
        <meshStandardMaterial color={blind ? "#94a3b8" : "#f8fafc"} roughness={0.35} />
      </mesh>
      <mesh position={[1.68, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
        <torusGeometry args={[0.58, 0.28, 12, 28]} />
        <meshStandardMaterial color={blind ? "#64748b" : "#0ea5e9"} roughness={0.4} emissive={blind ? "#000" : "#0c4a6e"} emissiveIntensity={glow} />
      </mesh>
      <mesh position={[1.66, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
        <circleGeometry args={[0.32, 20]} />
        <meshStandardMaterial color="#020617" roughness={0.9} />
      </mesh>
      {/* prevention shield ring */}
      {!blind && (
        <mesh position={[0, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[2.25, 0.09, 10, 48]} />
          <meshStandardMaterial color="#22c55e" roughness={0.4} emissive="#14532d" emissiveIntensity={0.6} />
        </mesh>
      )}
    </group>
  );
}

export function Topic10213Sim(props: SimProps) {
  const awareness = Number(props.awareness ?? 60);
  const showLabels = String(props.labels ?? "on") === "on";
  const grafts = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const restored = Math.max(1, Math.round((awareness / 100) * 4));

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Donor corneas this cycle", `${restored}`], ["Blindness prevented", awareness > 50 ? "screening + vitamin A + glasses" : "low coverage"], ["Pledge", "eyes can be donated after death"]]} />
      <SimCanvas cameraPosition={[0, 2.4, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <BigEye x={-4} blind={true} glow={0} />
        <BigEye x={4} blind={false} glow={0.4 + (awareness / 100) * 0.4} />

        {/* flying donor corneas */}
        <group ref={grafts}>
          {Array.from({ length: 4 }).map((_, i) => (
            <mesh key={i} rotation={[Math.PI / 2.4, 0, 0.4]}>
              <cylinderGeometry args={[0.5, 0.5, 0.08, 24]} />
              <meshStandardMaterial color="#7dd3fc" transparent opacity={0.95} roughness={0.1} emissive="#0ea5e9" emissiveIntensity={0.5} />
            </mesh>
          ))}
        </group>

        {showLabels && (
          <>
            <Label text="Donor eye" position={[-4, 4.1, 0]} size={0.52} color="#7dd3fc" />
            <Label text="Recipient sees again ✓" position={[4, 4.1, 0]} size={0.52} color="#86efac" />
            <Label text="Prevention shield: screening · vitamin A · spectacles" position={[0, -1.5, 0]} size={0.44} color="#86efac" />
            <Label text="1 donor can give sight to 2 people" position={[0, 5.2, 0]} size={0.5} color="#fde047" />
          </>
        )}
        <Animator grafts={grafts} elapsed={elapsed} awareness={awareness} />
      </SimCanvas>
    </div>
  );
}
