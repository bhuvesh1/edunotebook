// app/components/sims/unique/Topic10505Sim.tsx
// Odontogenic infections: fascial spaces of the neck. A head-and-neck model
// shows the submandibular spaces glowing red and swelling bilaterally
// (Ludwig's angina) as infection severity rises.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "severity", label: "Infection severity", kind: "slider", min: 0, max: 3, step: 1, default: 2, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Odontogenic Infections & Ludwig's Angina",
  blurb: "Watch infection spread into the submandibular spaces — bilateral swelling of Ludwig's angina grows with severity.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ left, right, elapsed, speed, severity }: {
  left: RefObject<THREE.Mesh>; right: RefObject<THREE.Mesh>;
  elapsed: RefObject<number>; speed: number; severity: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const pulse = 1 + 0.12 * Math.sin(elapsed.current * 3);
    const s = (0.25 + severity * 0.45) * pulse;
    for (const m of [left.current, right.current]) {
      if (!m) continue;
      m.scale.setScalar(Math.max(s, 0.001));
      const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = 0.4 + severity * 0.5 + 0.25 * Math.sin(elapsed.current * 3);
    }
  });
  return null;
}

const SKIN = "#f0b98d";
const BONE = "#e8dcc3";

export function Topic10505Sim(props: SimProps) {
  const severity = Number(props.severity ?? 2);
  const speed = Number(props.speed ?? 1);
  const left = useRef<THREE.Mesh>(null!);
  const right = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const stageName = ["No infection", "Localised abscess", "Space infection", "Ludwig's angina"][severity];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", stageName],
          ["● Swelling", "infected space"],
          ["Note", severity >= 3 ? "BILATERAL — airway risk!" : "monitor spread"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.6, 11]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* neck */}
        <mesh position={[0, 0.9, 0]} castShadow>
          <cylinderGeometry args={[0.85, 1, 1.8, 24]} />
          <meshStandardMaterial color={SKIN} roughness={0.7} />
        </mesh>
        {/* head */}
        <mesh position={[0, 3.1, 0]} castShadow>
          <sphereGeometry args={[1.55, 32, 32]} />
          <meshStandardMaterial color={SKIN} roughness={0.7} />
        </mesh>
        {/* jaw line */}
        <mesh position={[0, 1.95, 0.9]} castShadow>
          <boxGeometry args={[2.1, 0.5, 0.9]} />
          <meshStandardMaterial color={BONE} roughness={0.6} />
        </mesh>
        {/* teeth hint */}
        <mesh position={[0, 2.35, 1.35]}>
          <boxGeometry args={[1.5, 0.28, 0.2]} />
          <meshStandardMaterial color="#ffffff" roughness={0.3} />
        </mesh>
        {/* infected molar (source) */}
        <mesh position={[0.55, 2.1, 1.15]}>
          <boxGeometry args={[0.34, 0.4, 0.3]} />
          <meshStandardMaterial color="#7c2d12" emissive="#7c2d12" emissiveIntensity={0.4} roughness={0.5} />
        </mesh>
        <Label p={[1.5, 2.1, 1.3]} size={0.26} color="#fca5a5">infected molar</Label>

        {/* submandibular spaces (left/right) */}
        {[-1, 1].map((s) => (
          <mesh
            key={s}
            ref={s < 0 ? left : right}
            position={[s * 0.95, 1.55, 0.55]}
            castShadow
          >
            <sphereGeometry args={[0.62, 24, 24]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={1.2} transparent opacity={0.85} roughness={0.4} />
          </mesh>
        ))}
        <Label p={[-2.35, 1.55, 0.55]} size={0.28} color="#fca5a5">submandibular space</Label>
        <Label p={[2.35, 1.55, 0.55]} size={0.28} color="#fca5a5">submandibular space</Label>

        {/* sublingual space */}
        <mesh position={[0, 2.0, 1.05]}>
          <sphereGeometry args={[0.3 + severity * 0.12, 16, 16]} />
          <meshStandardMaterial color="#f87171" emissive="#ef4444" emissiveIntensity={0.8} transparent opacity={0.8} />
        </mesh>
        <Label p={[0, 2.75, 1.4]} size={0.26} color="#fca5a5">floor of mouth raised</Label>

        <Animator left={left} right={right} elapsed={elapsed} speed={speed} severity={severity} />
      </SimCanvas>
    </div>
  );
}
