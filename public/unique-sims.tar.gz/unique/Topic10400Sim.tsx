"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "anomaly", label: "Anomaly", kind: "select", min: 0, max: 0, step: 1, default: "supernumerary", options: ["supernumerary", "fusion", "microdontia", "dens"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Developmental anomalies: teeth, jaws, oral soft tissues",
  blurb: "When tooth development goes off-script: an extra tooth, two teeth fused into one, a tiny peg tooth, or a tooth inside a tooth.",
};

const INFO: Record<string, { name: string; note: string }> = {
  supernumerary: { name: "Supernumerary — mesiodens", note: "extra tooth between the front teeth — most common extra" },
  fusion: { name: "Fusion", note: "two tooth buds join → one big tooth, two roots" },
  microdontia: { name: "Microdontia — peg lateral", note: "tiny cone-shaped tooth — common in upper laterals" },
  dens: { name: "Dens invaginatus", note: "'tooth within a tooth' — enamel folds inward" },
};

function MiniTooth({ pos, scale = 1, color = "#fef9c3" }: { pos: [number, number, number]; scale?: number; color?: string }) {
  return (
    <group position={pos} scale={scale}>
      <mesh castShadow>
        <boxGeometry args={[0.9, 1, 0.8]} />
        <meshStandardMaterial color={color} roughness={0.25} />
      </mesh>
      <mesh position={[0, -0.9, 0]} castShadow>
        <coneGeometry args={[0.22, 1, 10]} />
        <meshStandardMaterial color="#fde68a" roughness={0.4} />
      </mesh>
    </group>
  );
}

function AnomalyScene({ anomaly, speed, showLabels }: { anomaly: string; speed: number; showLabels: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = INFO[anomaly] ?? INFO.supernumerary;
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) g.current.rotation.y = Math.sin(elapsed.current * 0.3) * 0.15;
  });

  return (
    <group ref={g}>
      {/* gum base */}
      <mesh position={[0, -1.2, 0]} castShadow>
        <boxGeometry args={[8.4, 1.2, 2.4]} />
        <meshStandardMaterial color="#e88ca0" roughness={0.6} />
      </mesh>
      {/* normal neighbors */}
      <MiniTooth pos={[-2.6, 0, 0]} />
      <MiniTooth pos={[2.6, 0, 0]} />

      {anomaly === "supernumerary" && (
        <group>
          <MiniTooth pos={[-0.9, 0, 0]} />
          <MiniTooth pos={[0.9, 0, 0]} />
          {/* the extra mesiodens, conical, behind */}
          <group position={[0, 0.1, 0.9]}>
            <mesh castShadow>
              <coneGeometry args={[0.42, 1.4, 12]} />
              <meshStandardMaterial color="#fde68a" roughness={0.3} emissive="#b45309" emissiveIntensity={0.35} />
            </mesh>
          </group>
        </group>
      )}
      {anomaly === "fusion" && (
        <group position={[0, 0, 0]}>
          {/* one wide crown */}
          <mesh castShadow>
            <boxGeometry args={[2.2, 1.1, 0.9]} />
            <meshStandardMaterial color="#fef9c3" roughness={0.25} emissive="#b45309" emissiveIntensity={0.25} />
          </mesh>
          {/* groove line showing the join */}
          <mesh position={[0, 0.1, 0.46]}>
            <planeGeometry args={[0.08, 1]} />
            <meshBasicMaterial color="#92400e" />
          </mesh>
          {/* two roots */}
          {[-0.5, 0.5].map((x, i) => (
            <mesh key={i} position={[x, -1, 0]} castShadow>
              <coneGeometry args={[0.24, 1.1, 10]} />
              <meshStandardMaterial color="#fde68a" roughness={0.4} />
            </mesh>
          ))}
        </group>
      )}
      {anomaly === "microdontia" && (
        <group position={[0, 0.15, 0]} scale={0.55}>
          <mesh castShadow>
            <coneGeometry args={[0.55, 1.5, 10]} />
            <meshStandardMaterial color="#fef9c3" roughness={0.25} emissive="#b45309" emissiveIntensity={0.3} />
          </mesh>
          {/* gap markers */}
          {[-1.4, 1.4].map((x, i) => (
            <mesh key={i} position={[x, -0.5, 0]} rotation={[0, 0, 0.5]}>
              <planeGeometry args={[1.2, 0.12]} />
              <meshBasicMaterial color="#f87171" transparent opacity={0.8} side={THREE.DoubleSide} />
            </mesh>
          ))}
        </group>
      )}
      {anomaly === "dens" && (
        <group position={[0, 0, 0]}>
          <mesh castShadow>
            <boxGeometry args={[1.1, 1.2, 1]} />
            <meshStandardMaterial color="#fef9c3" roughness={0.25} />
          </mesh>
          {/* invaginated enamel fold going inward */}
          <mesh position={[0, 0.3, 0]} castShadow>
            <coneGeometry args={[0.3, 1.1, 12]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.3} emissive="#b45309" emissiveIntensity={0.5} side={THREE.DoubleSide} />
          </mesh>
          {/* cutaway window */}
          <mesh position={[0, 0.3, 0.51]}>
            <planeGeometry args={[0.7, 1.2]} />
            <meshBasicMaterial color="#0f172a" transparent opacity={0.55} />
          </mesh>
          <mesh position={[0, -1, 0]} castShadow>
            <coneGeometry args={[0.24, 1.1, 10]} />
            <meshStandardMaterial color="#fde68a" roughness={0.4} />
          </mesh>
        </group>
      )}

      {showLabels && (
        <>
          <Text position={[0, 2.6, 0]} fontSize={0.46} color="#fbbf24">{info.name}</Text>
          <Text position={[0, -3.2, 0]} fontSize={0.42} color="#fef3c7" maxWidth={10}>{info.note}</Text>
        </>
      )}
    </group>
  );
}

export function Topic10400Sim(props: SimProps) {
  const anomaly = String(props.anomaly ?? "supernumerary");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const info = INFO[anomaly] ?? INFO.supernumerary;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Anomaly", info.name],
          ["Cause", "disturbed bud/cap/bell stage"],
          ["Fix", anomaly === "microdontia" ? "build up with composite" : "extract / monitor"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.6, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <AnomalyScene anomaly={anomaly} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
