"use client";
// Dental Traumatology: Fractures, Luxations, Avulsion — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Dental Traumatology: Fractures, Luxations, Avulsion",
  blurb: "Three injured teeth side by side: a cracked tooth wobbling, a knocked-sideways tooth, and one knocked clean out.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const fr: any = g("frac");
    if (fr) fr.rotation.z = 0.1 * Math.sin(t * 4);
    const av: any = g("avul");
    if (av) av.position.y = 2.6 + 0.25 * Math.sin(t * 2);
    const ar: any = g("replant");
    if (ar) (ar.material as any).opacity = 0.4 + 0.3 * Math.sin(t * 3);
    group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
  });
  return null;
}

export function Topic10456Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Injury 1", "Crown fracture"],
          ["Injury 2", "Lateral luxation"],
          ["Injury 3", "Avulsion (knocked out)"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <GumSlab position={[0, 0.1, 0]} scale={1.4} />
          <group name="frac" position={[-3.2, 1, 0]}>
            <Tooth scale={1.3} />
            {[[0.1, 0.3, 0.3], [-0.12, 0.05, -0.25], [0.08, -0.15, 0.2]].map((c, i) => (
              <mesh key={i} position={[c[0], c[1] + 0.2, c[2]]} rotation={[0, 0, c[2]]}>
                <boxGeometry args={[0.07, 0.5, 0.05]} />
                <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.8} />
              </mesh>
            ))}
          </group>
          <Label text="Fracture" position={[-3.2, 3.3, 0]} size={0.42} color="#ef4444" />
          <group position={[0, 1, 0]}>
            <Tooth tilt={0.38} scale={1.3} />
            <mesh position={[0.75, 0.4, 0]} rotation={[0, 0, 0.3]}>
              <boxGeometry args={[0.08, 0.08, 0.08]} />
              <meshStandardMaterial color="#fbbf24" transparent opacity={0.9} />
            </mesh>
          </group>
          <Arrow from={[1.35, 1.6, 0]} to={[0.35, 1.35, 0]} color="#fbbf24" />
          <Label text="Luxation" position={[0, 3.3, 0]} size={0.42} color="#fbbf24" />
          <mesh position={[3.2, 0.45, 0]}>
            <cylinderGeometry args={[0.5, 0.55, 0.5, 14]} />
            <meshStandardMaterial color="#1e293b" roughness={1} />
          </mesh>
          <group name="avul" position={[3.2, 2.6, 0]}>
            <Tooth scale={1.3} />
          </group>
          <mesh name="replant" position={[3.2, 1.6, 0]}>
            <cylinderGeometry args={[0.06, 0.06, 1.2, 8]} />
            <meshStandardMaterial color="#22c55e" transparent opacity={0.5} />
          </mesh>
          <Label text="Avulsion — replant fast!" position={[3.2, 3.9, 0]} size={0.42} color="#22c55e" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
