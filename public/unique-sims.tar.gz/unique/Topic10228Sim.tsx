// Pancreatitis & gallbladder disease — the pancreas reddens and swells
// (inflammation slider); gallstones tumble inside the green gallbladder and
// one lodges in the bile duct, turning the scene yellow (jaundice).
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stones", label: "Gallstones", kind: "slider", min: 0, max: 10, step: 1, default: 5, unit: "" },
  { key: "pancreas", label: "Pancreas", kind: "select", min: 0, max: 0, step: 1, default: "pancreatitis", options: ["pancreatitis", "healthy"] },
];

export const UNIQUE_META = {
  title: "Pancreatitis & Gallstones",
  blurb: "Gallstones tumble in the gallbladder and one jams the bile duct (jaundice!); beside it the pancreas burns red with pancreatitis.",
};

function Animator({ stones, elapsed }: {
  stones: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (stones.current) {
      stones.current.children.forEach((c, i) => {
        // stones tumble slowly in bile
        c.rotation.x = t * (0.4 + i * 0.1);
        c.rotation.y = t * (0.3 + i * 0.13);
        c.position.y += Math.sin(t * 2 + i * 2.2) * 0.004;
      });
    }
  });
  return null;
}

export function Topic10228Sim(props: SimProps) {
  const stoneCount = Math.round(Number(props.stones ?? 5));
  const inflamed = String(props.pancreas ?? "pancreatitis") === "pancreatitis";
  const stones = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const ductBlocked = stoneCount >= 4;
  const jaundice = ductBlocked;

  const stonePos: [number, number, number][] = [
    [2.6, 2.2, 0.5], [3.1, 1.9, 0.3], [2.9, 2.5, 0.7], [2.4, 1.8, 0.6],
    [3.3, 2.3, 0.5], [2.7, 2.0, 0.9], [3.0, 2.7, 0.4], [2.5, 2.4, 0.4],
    [3.2, 2.1, 0.8], [2.8, 1.7, 0.5],
  ];

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Gallstones", `${stoneCount}`], ["Bile duct", ductBlocked ? "BLOCKED ⚠" : "open"], ["Pancreas", inflamed ? "pancreatitis — severe pain" : "healthy"], ["Skin", jaundice ? "JAUNDICED (yellow)" : "normal"]]} />
      <SimCanvas cameraPosition={[0, 3, 12.5]} target={[0.4, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color={jaundice ? "#1c1917" : "#0f172a"} roughness={1} />
        </mesh>

        {/* pancreas: elongated, inflamed */}
        <mesh position={[-1.6, 2.6, 0]} rotation={[0, 0, 0.12]} scale={[2.2, 0.75, 0.7]} castShadow>
          <sphereGeometry args={[0.9, 24, 18]} />
          <meshStandardMaterial color={inflamed ? "#dc2626" : "#f9a8d4"} roughness={0.55} emissive={inflamed ? "#7f1d1d" : "#000"} emissiveIntensity={inflamed ? 0.5 : 0} />
        </mesh>
        <Label text={inflamed ? "Pancreas — inflamed (amylase/lipase ↑)" : "Pancreas — healthy"} position={[-1.6, 4.2, 0]} size={0.5} color={inflamed ? "#fca5a5" : "#86efac"} />

        {/* gallbladder: green pear */}
        <mesh position={[2.85, 2.15, 0.55]} scale={[1, 1.35, 1]} castShadow>
          <sphereGeometry args={[0.75, 22, 18]} />
          <meshStandardMaterial color="#4d7c0f" transparent opacity={0.75} roughness={0.4} />
        </mesh>
        {/* tumbling stones */}
        <group ref={stones}>
          {stonePos.slice(0, stoneCount).map((p, i) => (
            <mesh key={i} position={p}>
              <dodecahedronGeometry args={[0.2 + (i % 3) * 0.05, 0]} />
              <meshStandardMaterial color="#d6a05c" roughness={0.85} flatShading />
            </mesh>
          ))}
        </group>
        {/* cystic + common bile duct */}
        <mesh position={[1.6, 1.6, 0.4]} rotation={[0, 0, Math.PI / 3]}>
          <cylinderGeometry args={[0.16, 0.16, 1.6, 12, 1, true]} />
          <meshStandardMaterial color={ductBlocked ? "#facc15" : "#a3e635"} roughness={0.5} side={THREE.DoubleSide} />
        </mesh>
        {/* lodged stone */}
        {ductBlocked && (
          <mesh position={[1.85, 1.35, 0.4]}>
            <dodecahedronGeometry args={[0.24, 0]} />
            <meshStandardMaterial color="#d6a05c" roughness={0.85} flatShading emissive="#a16207" emissiveIntensity={0.4} />
          </mesh>
        )}
        {ductBlocked && <Label text="Stone in bile duct → obstructive jaundice" position={[1.7, 0.5, 0.4]} size={0.48} color="#fde047" />}

        {/* duodenum */}
        <mesh position={[0.9, 1.0, 0.2]} rotation={[0, 0, Math.PI / 2.4]}>
          <cylinderGeometry args={[0.35, 0.35, 2.0, 14, 1, true]} />
          <meshStandardMaterial color="#fda4af" roughness={0.55} side={THREE.DoubleSide} />
        </mesh>

        <Label text="Gallbladder — stores bile" position={[2.85, 3.9, 0.55]} size={0.5} color="#bef264" />
        <Label text="Gallstone pain: right upper belly after fatty food" position={[0.4, -1.1, 0]} size={0.44} color="#94a3b8" />
        <Animator stones={stones} elapsed={elapsed} />
      </SimCanvas>
    </div>
  );
}
