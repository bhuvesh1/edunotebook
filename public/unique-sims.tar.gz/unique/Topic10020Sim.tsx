// Histology: urinary + reproductive — a nephron with glomerulus and winding
// tubule carrying filtrate, beside a sperm racing a crowd toward a waiting ovum.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "gfr", label: "Filtration (GFR)", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Histology: Nephron & Gametes",
  blurb: "Watch filtrate flow through the nephron's tubule while sperm swim toward the ovum.",
};

function Animator({
  filtrate, spermGroup, spermTails, ovumGlow, elapsed, gfr, speed,
}: {
  filtrate: React.RefObject<THREE.Group>;
  spermGroup: React.RefObject<THREE.Group>;
  spermTails: React.RefObject<THREE.Group>;
  ovumGlow: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  gfr: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (filtrate.current) {
      filtrate.current.children.forEach((m, i) => {
        const ph = ((t * 0.3 * gfr + i / 10) % 1 + 1) % 1;
        // travel along an S path: glomerulus -> tubule -> loop -> collecting duct
        const path = m.userData.path as THREE.Vector3[];
        const idx = Math.min(path.length - 2, Math.floor(ph * (path.length - 1)));
        const f = ph * (path.length - 1) - idx;
        m.position.lerpVectors(path[idx], path[idx + 1], f);
        m.visible = gfr > 0.02;
      });
    }
    if (spermGroup.current) {
      spermGroup.current.children.forEach((m, i) => {
        const sp = 1.4 + (i % 3) * 0.35;
        const ph = ((t * 0.12 * sp + i * 0.13) % 1 + 1) % 1;
        m.position.x = 2.6 + ph * 3.4;
        m.position.y = 1.5 + Math.sin(t * 4 + i * 2.1) * 0.22;
      });
    }
    if (spermTails.current) {
      spermTails.current.children.forEach((m, i) => {
        m.rotation.z = Math.sin(t * 14 + i * 2.5) * 0.5;
      });
    }
    if (ovumGlow.current) {
      const s = 1 + 0.05 * Math.sin(t * 2);
      ovumGlow.current.scale.setScalar(s);
    }
  });
  return null;
}

export function Topic10020Sim(props: SimProps) {
  const gfr = Number(props.gfr ?? 1);
  const speed = Number(props.speed ?? 1);
  const filtrate = useRef<THREE.Group>(null!);
  const spermGroup = useRef<THREE.Group>(null!);
  const spermTails = useRef<THREE.Group>(null!);
  const ovumGlow = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  // filtrate path through the nephron (sampled points)
  const nephronPath = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    const add = (x: number, y: number) => pts.push(new THREE.Vector3(x, y, 0));
    add(-7.2, 3.4);
    for (let i = 1; i <= 6; i++) add(-7.2 + i * 0.55, 3.4 - i * 0.28); // PCT
    for (let i = 1; i <= 8; i++) add(-3.9, 1.72 - i * 0.32);            // loop down
    for (let i = 1; i <= 8; i++) add(-3.9 + 0.35, -0.86 + i * 0.3);     // loop up
    for (let i = 1; i <= 6; i++) add(-3.55 + i * 0.55, 1.54 + Math.sin(i) * 0.25); // DCT
    for (let i = 1; i <= 6; i++) add(-0.25 + 0.35, 1.6 - i * 0.5);      // collecting duct
    return pts;
  }, []);

  const tubuleCurve = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(nephronPath);
    return new THREE.Mesh(
      new THREE.TubeGeometry(curve, 120, 0.16, 10, false),
      new THREE.MeshStandardMaterial({ color: "#fbbf24", roughness: 0.45 })
    );
  }, [nephronPath]);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["GFR", `${(125 * gfr).toFixed(0)} mL/min`],
          ["Nephron", "glomerulus → tubule"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* NEPHRON */}
        {/* glomerulus: tuft of red capillaries */}
        <group position={[-7.2, 3.4, 0]}>
          {Array.from({ length: 9 }).map((_, i) => {
            const a = (i / 9) * Math.PI * 2;
            return (
              <mesh key={i} position={[Math.cos(a) * 0.28, Math.sin(a) * 0.28, 0]}
                rotation={[0, 0, a]} castShadow>
                <torusGeometry args={[0.22, 0.09, 8, 14]} />
                <meshStandardMaterial color="#dc2626" roughness={0.4} />
              </mesh>
            );
          })}
          {/* Bowman's capsule */}
          <mesh>
            <sphereGeometry args={[0.72, 20, 20, 0, Math.PI * 2, 0, Math.PI * 0.62]} />
            <meshStandardMaterial color="#fef3c7" transparent opacity={0.55} roughness={0.3} side={THREE.DoubleSide} />
          </mesh>
        </group>
        {/* afferent / efferent arterioles */}
        <mesh position={[-8.2, 3.0, 0]} rotation={[0, 0, 0.6]}>
          <cylinderGeometry args={[0.1, 0.1, 1.2, 8]} />
          <meshStandardMaterial color="#ef4444" />
        </mesh>
        <mesh position={[-6.3, 3.0, 0]} rotation={[0, 0, -0.6]}>
          <cylinderGeometry args={[0.08, 0.08, 1.0, 8]} />
          <meshStandardMaterial color="#f87171" />
        </mesh>
        <primitive object={tubuleCurve} />
        {/* filtrate droplets travelling the tubule */}
        <group ref={filtrate}>
          {Array.from({ length: 10 }).map((_, i) => {
            const p = nephronPath[0].clone();
            return (
              <mesh key={i} position={p} ref={(m) => { if (m) m.userData.path = nephronPath; }}>
                <sphereGeometry args={[0.12, 10, 10]} />
                <meshStandardMaterial color="#fef08a" emissive="#a16207" emissiveIntensity={0.6} />
              </mesh>
            );
          })}
        </group>
        <Label text="glomerulus" position={[-7.2, 4.6, 0]} size={0.4} color="#f8fafc" />
        <Label text="Bowman's capsule" position={[-8.9, 4.0, 0]} size={0.3} color="#fde68a" />
        <Label text="loop of Henle" position={[-5.3, -0.6, 0]} size={0.32} color="#fde68a" />
        <Label text="collecting duct" position={[0.6, 0.3, 0]} size={0.32} color="#fde68a" />

        {/* GAMETES */}
        {/* ovum with zona pellucida */}
        <group position={[7.4, 1.5, 0]}>
          <mesh ref={ovumGlow} castShadow>
            <sphereGeometry args={[1.0, 24, 24]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.35} />
          </mesh>
          <mesh>
            <sphereGeometry args={[1.18, 24, 24]} />
            <meshStandardMaterial color="#fce7f3" transparent opacity={0.28} roughness={0.2} />
          </mesh>
          <mesh position={[0.25, 0.25, 0.7]}>
            <sphereGeometry args={[0.3, 12, 12]} />
            <meshStandardMaterial color="#831843" />
          </mesh>
        </group>
        <Label text="ovum + zona pellucida" position={[7.4, 3.15, 0]} size={0.36} color="#f8fafc" />
        {/* racing sperm */}
        <group ref={spermGroup}>
          {Array.from({ length: 5 }).map((_, i) => (
            <group key={i} position={[2.6, 1.5, 0]}>
              <mesh rotation={[0, 0, -Math.PI / 2]} castShadow>
                <coneGeometry args={[0.18, 0.5, 12]} />
                <meshStandardMaterial color="#67e8f9" roughness={0.4} />
              </mesh>
            </group>
          ))}
        </group>
        <group ref={spermTails}>
          {Array.from({ length: 5 }).map((_, i) => (
            <mesh key={i} position={[2.6, 1.5, 0]}>
              <boxGeometry args={[1.1, 0.05, 0.05]} />
              <meshStandardMaterial color="#22d3ee" />
            </mesh>
          ))}
        </group>
        <Label text="sperm racing to fertilize" position={[4.2, 0.5, 0]} size={0.32} color="#a5f3fc" />

        <Animator filtrate={filtrate} spermGroup={spermGroup} spermTails={spermTails}
          ovumGlow={ovumGlow} elapsed={elapsed} gfr={gfr} speed={speed} />
      </SimCanvas>
    </div>
  );
}
