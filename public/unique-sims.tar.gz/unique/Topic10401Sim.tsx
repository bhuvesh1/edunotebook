"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Caries stage", kind: "slider", min: 0, max: 3, step: 1, default: 1, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Dental caries: etiology, classification, histopathology",
  blurb: "Bacteria feast on sugar and drill acid tunnels — follow decay from a white spot in enamel to an aching pulp.",
};

const STAGES = [
  { name: "Sound tooth", note: "enamel intact — fluoride + brushing keep it this way" },
  { name: "White spot — enamel caries", note: "chalky demineralization, still reversible!" },
  { name: "Dentin caries", note: "decay races through soft dentin toward the pulp" },
  { name: "Pulp involvement", note: "bacteria hit the nerve — irreversible pulpitis, toothache!" },
];

// acid-attack bacteria dots
function Bacteria({ speed, active }: { speed: number; active: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (!g.current) return;
    g.current.children.forEach((c, i) => {
      c.position.x = -0.8 + Math.sin(elapsed.current * 1.3 + i * 2.1) * 0.7;
      c.position.y = 2.6 + Math.cos(elapsed.current * 1.7 + i * 1.3) * 0.25;
      const s = active ? 1 + Math.sin(elapsed.current * 6 + i) * 0.2 : 0.6;
      c.scale.setScalar(s);
    });
  });
  return (
    <group ref={g} position={[0, 0, 0]}>
      {Array.from({ length: 12 }).map((_, i) => (
        <group key={i} position={[-0.8, 2.6, 0.4]}>
          <mesh castShadow>
            <sphereGeometry args={[0.16, 10, 8]} />
            <meshStandardMaterial color="#a3e635" roughness={0.5} emissive="#3f6212" emissiveIntensity={0.5} />
          </mesh>
          {/* flagella */}
          <mesh position={[0.14, 0.1, 0]} rotation={[0, 0, -1]}>
            <cylinderGeometry args={[0.02, 0.02, 0.4, 6]} />
            <meshBasicMaterial color="#a3e635" />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function CariesScene({ stage, speed, showLabels }: { stage: number; speed: number; showLabels: boolean }) {
  const decay = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = STAGES[stage];

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (decay.current) {
      decay.current.children.forEach((c, i) => {
        ((c as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = 0.25 + Math.sin(elapsed.current * 2.5 + i) * 0.12;
      });
    }
  });

  // decay geometry per stage: [size, depth-y, color]
  const decaySpec = [
    null,
    { s: 0.7, y: 2.05, c: "#fefce8" },
    { s: 1.05, y: 1.35, c: "#b45309" },
    { s: 1.3, y: 0.45, c: "#7c2d12" },
  ][stage];

  return (
    <group>
      {/* tooth */}
      <group position={[0, 0, 0]}>
        <mesh position={[0, 1.3, 0]} castShadow>
          <boxGeometry args={[2.8, 2.6, 2.6]} />
          <meshStandardMaterial color="#fef9c3" roughness={0.25} />
        </mesh>
        {/* dentin core visible in cutaway */}
        <mesh position={[0, 0.9, 0]}>
          <boxGeometry args={[2.2, 1.8, 2.0]} />
          <meshStandardMaterial color="#fde68a" roughness={0.4} />
        </mesh>
        {/* pulp */}
        <mesh position={[0, -0.15, 0]}>
          <sphereGeometry args={[0.55, 16, 12]} />
          <meshStandardMaterial color={stage === 3 ? "#ef4444" : "#f87171"} roughness={0.4} emissive="#7f1d1d" emissiveIntensity={stage === 3 ? 0.9 : 0.4} />
        </mesh>
        <mesh position={[0, -1.8, 0]} castShadow>
          <cylinderGeometry args={[1.2, 0.4, 3.2, 16]} />
          <meshStandardMaterial color="#fde68a" roughness={0.4} />
        </mesh>
        {/* decay lesion */}
        {decaySpec && (
          <group ref={decay} position={[0, decaySpec.y, 0.9]}>
            <mesh castShadow>
              <sphereGeometry args={[decaySpec.s, 20, 14]} />
              <meshStandardMaterial color={decaySpec.c} roughness={0.85} emissive="#7c2d12" emissiveIntensity={0.25} />
            </mesh>
            {/* undermined enamel shell */}
            <mesh position={[0, 0.35, 0.35]}>
              <sphereGeometry args={[decaySpec.s * 0.75, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
              <meshStandardMaterial color="#fef9c3" roughness={0.3} transparent opacity={0.85} />
            </mesh>
          </group>
        )}
        {/* pain bolts at pulpitis */}
        {stage === 3 &&
          [-0.5, 0, 0.5].map((x, i) => (
            <mesh key={i} position={[x, 1.2 + (i % 2) * 0.7, 1.6]} rotation={[0, 0, 0.4]}>
              <coneGeometry args={[0.14, 0.7, 6]} />
              <meshBasicMaterial color="#facc15" />
            </mesh>
          ))}
      </group>

      <Bacteria speed={speed} active={stage > 0} />

      {/* sugar cubes feeding the bacteria */}
      {[0, 1].map((i) => (
        <mesh key={i} position={[-2.6 + i * 1.1, 2.4, -0.6]} rotation={[0.4, 0.5, 0.2]} castShadow>
          <boxGeometry args={[0.55, 0.55, 0.55]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.6} />
        </mesh>
      ))}

      {showLabels && (
        <>
          <Text position={[0, 4.2, 0]} fontSize={0.46} color={stage === 0 ? "#86efac" : "#fbbf24"}>{info.name}</Text>
          <Text position={[0, -4.4, 0]} fontSize={0.42} color="#fef3c7" maxWidth={10}>{info.note}</Text>
          <Text position={[-4.2, 2.4, -0.6]} fontSize={0.38} color="#e2e8f0">Sugar → acid → decay</Text>
        </>
      )}
    </group>
  );
}

export function Topic10401Sim(props: SimProps) {
  const stage = Math.round(Number(props.stage ?? 1));
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const info = STAGES[stage];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", info.name],
          ["Reversible?", stage <= 1 ? "yes ✓ (fluoride)" : "no — needs filling"],
          ["Culprits", "S. mutans + sugar + time"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 0.3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.8, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <CariesScene stage={stage} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
