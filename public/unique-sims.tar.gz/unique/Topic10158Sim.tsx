"use client";
// Infanticide, abortion, MTP Act.
// A pregnancy timeline (weeks 0–24): a marker slides along and a shield
// lights up to show what the MTP Act allows at each stage.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "weeks", label: "Pregnancy weeks", kind: "slider", min: 0, max: 24, step: 1, default: 10, unit: "wk" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "MTP Act: The Legal Timeline of Pregnancy",
  blurb: "Slide through the weeks of pregnancy and see what India's MTP Act permits at each stage — with the baby always protected.",
};

function Animator({ marker, shield, elapsed, speed, weeks }: { marker: React.RefObject<THREE.Group>; shield: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; speed: number; weeks: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (marker.current) {
      marker.current.position.y = 0.9 + Math.sin(elapsed.current * 3) * 0.12;
    }
    if (shield.current) {
      const ok = weeks <= 20;
      const s = 1 + Math.sin(elapsed.current * 2.5) * 0.06;
      shield.current.scale.set(s, s, s);
      (shield.current.material as THREE.MeshStandardMaterial).emissiveIntensity = ok ? 0.8 : 0.15;
    }
  });
  return null;
}

export function Topic10158Sim(props: SimProps) {
  const weeks = Number(props.weeks ?? 10);
  const speed = Number(props.speed ?? 1);
  const marker = useRef<THREE.Group>(null!);
  const shield = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const x = -5.5 + (weeks / 24) * 11;
  const rule = weeks <= 12 ? "MTP allowed: 1 doctor's opinion" : weeks <= 20 ? "MTP allowed: 2 doctors' opinion" : weeks <= 24 ? "MTP: only special categories" : "Beyond legal limit";
  const ruleColor = weeks <= 20 ? "#22c55e" : "#f59e0b";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Weeks", `${weeks}`], ["MTP Act", rule]]} />
      <SimCanvas cameraPosition={[0, 3.6, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* timeline rail 0..24 weeks */}
        <mesh position={[0, 0.9, 0]}>
          <boxGeometry args={[11.6, 0.18, 0.6]} />
          <meshStandardMaterial color="#334155" roughness={0.8} />
        </mesh>
        {Array.from({ length: 25 }, (_, w) => (
          <group key={w}>
            <mesh position={[-5.5 + (w / 24) * 11, 0.9, 0]}>
              <boxGeometry args={[w % 4 === 0 ? 0.09 : 0.05, w % 4 === 0 ? 0.7 : 0.4, 0.1]} />
              <meshStandardMaterial color={w % 4 === 0 ? "#94a3b8" : "#475569"} roughness={0.7} />
            </mesh>
            {w % 4 === 0 && (
              <Label text={`${w}w`} position={[-5.5 + (w / 24) * 11, 0.15, 0]} size={0.42} color="#94a3b8" />
            )}
          </group>
        ))}
        {/* legal zone colouring */}
        <mesh position={[-5.5 + (20 / 24) * 11 / 2, 0.9, 0]}>
          <boxGeometry args={[(20 / 24) * 11, 0.2, 0.62]} />
          <meshStandardMaterial color="#22c55e" transparent opacity={0.3} emissive="#22c55e" emissiveIntensity={0.3} />
        </mesh>
        {/* week marker */}
        <group ref={marker} position={[x, 0.9, 0]}>
          <mesh position={[0, 0.85, 0]} castShadow>
            <coneGeometry args={[0.35, 0.7, 4]} />
            <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.6} />
          </mesh>
          <mesh position={[0, 1.5, 0]}>
            <sphereGeometry args={[0.22, 14, 14]} />
            <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.6} />
          </mesh>
        </group>
        {/* growing baby icon */}
        <group position={[-5.5, 3.2, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.35 + weeks * 0.022, 18, 18]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
          </mesh>
          <Label text="BABY" position={[0, 1.3, 0]} size={0.55} color="#f9a8d4" />
        </group>
        {/* protective shield */}
        <group position={[5.5, 3.2, 0]}>
          <mesh ref={shield} castShadow>
            <sphereGeometry args={[0.9, 4, 3]} />
            <meshStandardMaterial color="#38bdf8" transparent opacity={0.4} roughness={0.2} emissive="#0ea5e9" emissiveIntensity={0.8} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[0, 0, 0]}>
            <sphereGeometry args={[0.4, 16, 16]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
          <Label text="PROTECTED BY LAW" position={[0, 1.5, 0]} size={0.5} color={ruleColor} />
        </group>
        <Label text="MTP ACT TIMELINE" position={[0, 5.4, 0]} size={0.7} color="#93c5fd" />
        <Animator marker={marker} shield={shield} elapsed={elapsed} speed={speed} weeks={weeks} />
      </SimCanvas>
    </div>
  );
}
