// Gynecology: menstrual disorders — menorrhagia, dysmenorrhea, amenorrhea.
// The uterus builds its lining each cycle, then sheds it. Watch a normal
// cycle, a flooding heavy bleed, painful cramp squeezes, or no cycle at all.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "disorder", label: "Disorder", kind: "select", min: 0, max: 0, step: 1, default: "normal", options: ["normal", "menorrhagia", "dysmenorrhea", "amenorrhea"] },
  { key: "cycle", label: "Cycle speed", kind: "slider", min: 0.3, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Menstrual Cycle Disorders",
  blurb: "The womb's lining grows and sheds each month — see normal flow, heavy flooding, painful cramps, or a missing period.",
};

const N_FLOW = 24;

function Animator({
  group, lining, flow, uterus, elapsed, cycle, disorder,
}: {
  group: React.RefObject<THREE.Group>;
  lining: React.RefObject<THREE.Mesh>;
  flow: React.RefObject<THREE.Group>;
  uterus: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  cycle: number;
  disorder: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * cycle;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    const cyc = (t % 10) / 10; // one full cycle every 10s
    const shedding = cyc > 0.6 && cyc < 0.9;
    // lining grows, then thins as it sheds
    if (lining.current) {
      const grow = disorder === "amenorrhea" ? 0.25 : cyc < 0.6 ? 0.4 + (cyc / 0.6) * 0.6 : 1 - ((cyc - 0.6) / 0.3) * 0.75;
      lining.current.scale.set(1, Math.max(0.2, grow), 1);
      (lining.current.material as THREE.MeshStandardMaterial).emissiveIntensity = shedding ? 0.5 : 0.1;
    }
    // menstrual flow particles
    if (flow.current) {
      const active = shedding && disorder !== "amenorrhea";
      flow.current.visible = active;
      const n = disorder === "menorrhagia" ? N_FLOW : Math.floor(N_FLOW / 2);
      flow.current.children.forEach((d, i) => {
        d.visible = i < n;
        const ph = ((t * (disorder === "menorrhagia" ? 1.6 : 0.9) + i / N_FLOW) % 1);
        d.position.set(Math.sin(i * 2.9) * 0.3, 1.5 - ph * 1.8, 0.1);
      });
    }
    // dysmenorrhea: painful cramp squeezes
    if (uterus.current) {
      const cramp = disorder === "dysmenorrhea" ? 0.5 + 0.5 * Math.sin(t * 5) : 0;
      uterus.current.scale.set(1 - cramp * 0.1, 1.15 - cramp * 0.06, 0.85);
      (uterus.current.material as THREE.MeshStandardMaterial).emissive.set(disorder === "dysmenorrhea" ? "#7f1d1d" : "#000000");
      (uterus.current.material as THREE.MeshStandardMaterial).emissiveIntensity = cramp * 0.7;
    }
  });
  return null;
}

export function Topic10285Sim(props: SimProps) {
  const disorder = String(props.disorder ?? "normal");
  const cycle = Number(props.cycle ?? 1);
  const group = useRef<THREE.Group>(null!);
  const lining = useRef<THREE.Mesh>(null!);
  const flow = useRef<THREE.Group>(null!);
  const uterus = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    normal: "Normal cycle", menorrhagia: "Menorrhagia (heavy bleeding)",
    dysmenorrhea: "Dysmenorrhea (painful cramps)", amenorrhea: "Amenorrhea (no periods)",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Disorder", names[disorder] ?? disorder], ["Cycle", `${cycle.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* uterus */}
          <mesh ref={uterus} position={[0, 2.2, 0]} scale={[1.0, 1.15, 0.85]} castShadow>
            <sphereGeometry args={[0.95, 28, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.6} />
          </mesh>
          {/* endometrial lining inside */}
          <mesh ref={lining} position={[0, 2.2, 0]} scale={[0.72, 1, 0.62]} castShadow>
            <sphereGeometry args={[0.9, 24, 18]} />
            <meshStandardMaterial color="#dc2626" roughness={0.55} emissive="#7f1d1d" emissiveIntensity={0.1} />
          </mesh>
          {/* cervix + vagina canal below */}
          <mesh position={[0, 0.85, 0]} castShadow>
            <cylinderGeometry args={[0.28, 0.35, 1.1, 14]} />
            <meshStandardMaterial color="#f0abfc" roughness={0.5} />
          </mesh>
          {/* ovaries releasing an egg */}
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 1.7, 2.6, 0]} scale={[1, 1.25, 0.8]} castShadow>
              <sphereGeometry args={[0.3, 16, 12]} />
              <meshStandardMaterial color="#fde68a" roughness={0.5} />
            </mesh>
          ))}
          <mesh position={[1.1, 2.9, 0.2]} castShadow>
            <sphereGeometry args={[0.12, 12, 10]} />
            <meshStandardMaterial color="#fef9c3" emissive="#facc15" emissiveIntensity={1} />
          </mesh>
          {/* menstrual flow */}
          <group ref={flow} visible={false}>
            {Array.from({ length: N_FLOW }).map((_, i) => (
              <mesh key={i}>
                <sphereGeometry args={[0.1, 8, 6]} />
                <meshBasicMaterial color="#ef4444" />
              </mesh>
            ))}
          </group>
          {/* pain bolts for dysmenorrhea */}
          {disorder === "dysmenorrhea" && (
            <>
              {[-0.7, 0, 0.7].map((x, i) => (
                <mesh key={i} position={[x, 3.4, 0.3]} rotation={[0, 0, 0.4]}>
                  <coneGeometry args={[0.14, 0.5, 4]} />
                  <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1.2} />
                </mesh>
              ))}
            </>
          )}
          <Label text="Uterus" position={[-2.0, 2.6, 0]} size={0.55} color="#f9a8d4" />
          <Label text="Lining (endometrium)" position={[1.9, 2.0, 0]} size={0.5} color="#fca5a5" />
          <Label text="Egg released" position={[1.9, 3.2, 0.2]} size={0.45} color="#fef9c3" />
          {disorder === "menorrhagia" && <Label text="⚠ Flooding — too much blood" position={[0, -0.15, 0.2]} size={0.55} color="#fca5a5" />}
          {disorder === "dysmenorrhea" && <Label text="⚡ Painful cramps" position={[0, 0.6, 0.3]} size={0.55} color="#fde68a" />}
          {disorder === "amenorrhea" && <Label text="No lining, no period" position={[0, 0.6, 0.2]} size={0.55} color="#94a3b8" />}
        </group>
        <Animator group={group} lining={lining} flow={flow} uterus={uterus} elapsed={elapsed} cycle={cycle} disorder={disorder} />
      </SimCanvas>
    </div>
  );
}
