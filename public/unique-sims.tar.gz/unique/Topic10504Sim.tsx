"use client";
// Fracture Fixation: Plates, Arch Bars, IMF — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "method", label: "Method", kind: "select", min: 0, max: 0, step: 1, default: "Miniplate", options: ["Miniplate", "Arch bar", "IMF (wired shut)"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Fracture Fixation: Plates, Arch Bars, IMF",
  blurb: "Hold the broken jaw together — a titanium miniplate with screws, an arch bar, or wiring the jaws shut.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const mp: any = g("miniplate");
    if (mp) mp.visible = p.method === "Miniplate";
    const ab: any = g("archbar");
    if (ab) ab.visible = p.method === "Arch bar";
    const imf: any = g("imf");
    if (imf) imf.visible = p.method === "IMF (wired shut)";
    for (let i = 0; i < 4; i++) {
      const s: any = g("screw" + i);
      if (s) s.rotation.y = p.method === "Miniplate" ? t * 3 : 0;
    }
    const stab: any = g("stable");
    if (stab) (stab.material as any).opacity = 0.5 + 0.3 * Math.sin(t * 2);
  });
  return null;
}

export function Topic10504Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const method = String(props.method ?? "Miniplate");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, method };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Method", method],
          ["Miniplate", "Titanium + 4 screws"],
          ["Arch bar", "Bar + wire ties"],
          ["IMF", "Jaws wired together"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <mesh position={[-1.3, 1.6, 0]}>
            <boxGeometry args={[2.2, 1.1, 1.1]} />
            <meshStandardMaterial color="#ded3ba" roughness={0.65} />
          </mesh>
          <mesh position={[1.3, 1.6, 0]}>
            <boxGeometry args={[2.2, 1.1, 1.1]} />
            <meshStandardMaterial color="#ded3ba" roughness={0.65} />
          </mesh>
          <mesh position={[0, 1.6, 0]}>
            <boxGeometry args={[0.14, 1.15, 1.15]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.5} transparent opacity={0.7} />
          </mesh>
          {[-1.3, 1.3].map((bx, bi) => (
            <group key={bi}>
              {[-0.7, 0, 0.7].map((dx, i) => (
                <mesh key={i} position={[bx + dx, 2.5, 0]}>
                  <boxGeometry args={[0.55, 0.6, 0.55]} />
                  <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
                </mesh>
              ))}
            </group>
          ))}
          <group name="miniplate" position={[0, 1.6, 0.62]}>
            <mesh>
              <boxGeometry args={[1.7, 0.4, 0.1]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.9} roughness={0.3} />
            </mesh>
            {[[-0.6, 0], [0.6, 0], [-0.6, 0], [0.6, 0]].map((sxy, i) => (
              <mesh key={i} name={"screw" + i} position={[sxy[0], i < 2 ? 0.1 : -0.1, 0.08]}>
                <cylinderGeometry args={[0.07, 0.07, 0.12, 8]} />
                <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.25} />
              </mesh>
            ))}
          </group>
          <group name="archbar" position={[0, 2.5, 0.35]} visible={false}>
            <Wire points={[[-2.4, 0, 0], [-0.8, 0.05, 0], [0.8, 0.05, 0], [2.4, 0, 0]]} color="#94a3b8" radius={0.06} />
            {[-1.6, -0.5, 0.5, 1.6].map((x, i) => (
              <mesh key={i} position={[x, 0, 0]} rotation={[0.4, 0, 0]}>
                <torusGeometry args={[0.14, 0.03, 8, 12]} />
                <meshStandardMaterial color="#64748b" metalness={0.8} roughness={0.35} />
              </mesh>
            ))}
          </group>
          <group name="imf" visible={false}>
            <mesh position={[0, 3.4, 0]}>
              <boxGeometry args={[4.4, 0.8, 1]} />
              <meshStandardMaterial color="#d3c7ab" roughness={0.6} />
            </mesh>
            {[-1.5, -0.5, 0.5, 1.5].map((x, i) => (
              <mesh key={i} position={[x, 2.95, 0.3]}>
                <cylinderGeometry args={[0.035, 0.035, 1.1, 8]} />
                <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
              </mesh>
            ))}
            <Label text="Jaws wired shut" position={[0, 4.1, 0]} size={0.42} color="#94a3b8" />
          </group>
          <mesh name="stable" position={[0, 0.5, 0]}>
            <boxGeometry args={[3.6, 0.12, 0.12]} />
            <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.7} transparent opacity={0.6} />
          </mesh>
          <Label text="Fracture line" position={[2.2, 1.6, 0]} size={0.42} color="#ef4444" />
          <Label text="Stable fixation" position={[0, 0.1, 0]} size={0.42} color="#22c55e" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
