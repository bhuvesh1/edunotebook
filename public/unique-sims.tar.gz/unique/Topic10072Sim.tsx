"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Transcription & Translation",
  blurb: "RNA polymerase copies DNA into mRNA; a ribosome reads it while tRNAs deliver amino acids to grow a protein.",
};

function Animator({ root, pol, mrna, trna, prot, elapsed, speed }: { root: RefObject<THREE.Group>; pol: RefObject<THREE.Mesh>; mrna: RefObject<THREE.Group>; trna: RefObject<THREE.Mesh>; prot: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const px = -4 + ((t * 0.5) % 1) * 4.4;
    if (pol.current) pol.current.position.set(px, 1.05, 0);
    if (mrna.current) {
      mrna.current.children.forEach((m, i) => {
        const bx = -4 + i * 0.42;
        const made = px > bx;
        m.scale.setScalar(made ? 1 : 0.001);
        const j = Math.max(0, i - 6);
        m.position.set(bx + j * 0.28, 1.9 + j * 0.16, 0);
      });
    }
    if (trna.current) {
      trna.current.position.set(2.6, 3.7 - Math.abs(Math.sin(t * 2.2)) * 0.9, 0);
      trna.current.rotation.y = t * 1.5;
    }
    if (prot.current) {
      const n = (t * 1.1) % 12;
      prot.current.children.forEach((m, i) => {
        m.scale.setScalar(n > i ? 1 : 0.001);
      });
    }
  });
  return null;
}

export function Topic10072Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const pol = useRef<THREE.Mesh>(null!);
  const mrna = useRef<THREE.Group>(null!);
  const trna = useRef<THREE.Mesh>(null!);
  const prot = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Step 1", "transcription: DNA \u2192 mRNA"],
          ["Step 2", "translation: mRNA \u2192 protein"],
          ["Start codon", "AUG"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          {[-4, -3.58, -3.16, -2.74, -2.32, -1.9, -1.48, -1.06, -0.64, -0.22].map((x, i) => (
            <group key={i}>
              <mesh position={[x, 1.28, 0]}><sphereGeometry args={[0.16, 12, 12]} /><meshStandardMaterial color="#a78bfa" roughness={0.4} /></mesh>
              <mesh position={[x, 0.82, 0]}><sphereGeometry args={[0.16, 12, 12]} /><meshStandardMaterial color="#7c3aed" roughness={0.4} /></mesh>
            </group>
          ))}
          <Label text="DNA template" position={[-2.2, 0.2, 0]} size={0.42} color="#a78bfa" />
          <mesh ref={pol} castShadow>
            <sphereGeometry args={[0.55, 20, 20]} /><meshStandardMaterial color="#4ade80" roughness={0.4} />
          </mesh>
          <Label text="RNA polymerase" position={[-4.4, 2.3, 0]} size={0.42} color="#4ade80" />
          <group ref={mrna}>
            {Array.from({ length: 12 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.15, 12, 12]} /><meshStandardMaterial color="#f472b6" emissive="#ec4899" emissiveIntensity={0.6} /></mesh>
            ))}
          </group>
          <Label text="mRNA" position={[1.4, 3.6, 0]} size={0.42} color="#f472b6" />
          <mesh position={[2.6, 2.75, 0]} castShadow>
            <sphereGeometry args={[0.62, 20, 20]} /><meshStandardMaterial color="#8b5cf6" roughness={0.45} />
          </mesh>
          <mesh position={[2.6, 2.05, 0]} castShadow>
            <sphereGeometry args={[0.42, 18, 18]} /><meshStandardMaterial color="#a78bfa" roughness={0.45} />
          </mesh>
          <Label text="ribosome" position={[2.6, 1.35, 0]} size={0.42} color="#a78bfa" />
          <mesh ref={trna} castShadow>
            <boxGeometry args={[0.34, 0.5, 0.34]} /><meshStandardMaterial color="#facc15" roughness={0.4} />
          </mesh>
          <Label text="tRNA" position={[3.7, 3.9, 0]} size={0.42} color="#facc15" />
          <group ref={prot}>
            {Array.from({ length: 10 }).map((_, i) => (
              <mesh key={i} position={[3.5 + i * 0.36, 2.5 - i * 0.1, 0]} castShadow>
                <sphereGeometry args={[0.17, 12, 12]} /><meshStandardMaterial color="#38bdf8" roughness={0.4} />
              </mesh>
            ))}
          </group>
          <Label text="protein chain" position={[5.6, 1.6, 0]} size={0.42} color="#38bdf8" />
        </group>
        <Animator root={root} pol={pol} mrna={mrna} trna={trna} prot={prot} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
