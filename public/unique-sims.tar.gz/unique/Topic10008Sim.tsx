"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Jaw speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Head and neck: scalp, face, cranial fossae, orbit, nasal cavity, oral cavity",
  blurb: "The skull up close: eye orbits, nasal cavity and a working jaw with teeth — open and close it.",
};

function Skull({ speed }: { speed: number }) {
  const jaw = useRef<THREE.Group>(null!);
  const g = useRef<THREE.Group>(null!);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d * speed;
    if (g.current) g.current.rotation.y = Math.sin(t.current * 0.4) * 0.35;
    if (jaw.current) jaw.current.rotation.z = (Math.sin(t.current * 2.2) * 0.5 + 0.5) * 0.38;
  });
  const bone = { color: "#f5f0e6", roughness: 0.55 };
  return (
    <group ref={g} position={[0, 1.2, 0]}>
      {/* cranium */}
      <mesh position={[0, 3.4, -0.2]} castShadow>
        <sphereGeometry args={[1.5, 26, 22]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      {/* face bones */}
      <mesh position={[0, 2.1, 0.85]} castShadow>
        <boxGeometry args={[1.9, 1.3, 0.9]} />
        <meshStandardMaterial {...bone} />
      </mesh>
      {/* orbits */}
      {[-0.55, 0.55].map((x) => (
        <mesh key={x} position={[x, 2.75, 1.25]}>
          <sphereGeometry args={[0.42, 18, 18]} />
          <meshStandardMaterial color="#1c1917" roughness={1} />
        </mesh>
      ))}
      {/* nasal cavity */}
      <mesh position={[0, 2.15, 1.32]} castShadow>
        <coneGeometry args={[0.22, 0.5, 4]} />
        <meshStandardMaterial color="#1c1917" roughness={1} />
      </mesh>
      {/* cheekbones */}
      {[-0.95, 0.95].map((x) => (
        <mesh key={x} position={[x, 2.35, 0.9]} castShadow>
          <boxGeometry args={[0.45, 0.3, 0.5]} />
          <meshStandardMaterial {...bone} />
        </mesh>
      ))}
      {/* upper teeth */}
      {Array.from({ length: 6 }).map((_, i) => (
        <mesh key={i} position={[-0.5 + i * 0.2, 1.55, 1.15]} castShadow>
          <boxGeometry args={[0.14, 0.22, 0.14]} />
          <meshStandardMaterial color="#ffffff" roughness={0.3} />
        </mesh>
      ))}
      {/* mandible (jaw) that opens */}
      <group ref={jaw} position={[-1.1, 1.75, 0.3]}>
        <mesh position={[1.1, -0.35, 0.75]} castShadow>
          <boxGeometry args={[2.0, 0.4, 0.7]} />
          <meshStandardMaterial {...bone} />
        </mesh>
        {Array.from({ length: 6 }).map((_, i) => (
          <mesh key={"t" + i} position={[0.6 + i * 0.2, -0.08, 1.05]} castShadow>
            <boxGeometry args={[0.14, 0.22, 0.14]} />
            <meshStandardMaterial color="#ffffff" roughness={0.3} />
          </mesh>
        ))}
        <mesh position={[0.15, 0.15, 0.55]} rotation={[0, 0, 0.5]} castShadow>
          <boxGeometry args={[0.3, 1.0, 0.4]} />
          <meshStandardMaterial {...bone} />
        </mesh>
      </group>
    </group>
  );
}

export function Topic10008Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Bones", "22 skull bones"], ["Orbits", "2"], ["Jaw", "mandible moves"]]} />
      <SimCanvas cameraPosition={[0, 3.5, 11]} target={[0, 3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Skull speed={speed} />
        {showLabels && (
          <>
            <Label text="Orbit (eye socket)" position={[-2.8, 4.4, 0.6]} color="#e7e5e4" size={0.5} />
            <Label text="Nasal cavity" position={[2.4, 3.2, 0.8]} color="#e7e5e4" size={0.5} />
            <Label text="Mandible" position={[2.6, 1.6, 0]} color="#fef3c7" size={0.5} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
