"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "system", label: "Numbering system", kind: "select", min: 0, max: 0, step: 1, default: "fdi", options: ["fdi", "universal", "palmer"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Tooth numbering systems: FDI, Universal, Palmer",
  blurb: "Same 32 teeth, three ways to name them — switch systems and watch every label change: FDI two-digits, Universal 1–32, Palmer symbols.",
};

const ENAMEL = "#fef9c3";
const GUM = "#e88ca0";

function labelFor(system: string, quadrant: number, pos: number): string {
  // quadrant: 0=UR,1=UL,2=LL,3=LR ; pos 1..8 (central→molar)
  if (system === "fdi") return `${quadrant + 1}${pos}`;
  if (system === "universal") {
    // UR: 8..1 (central→molar), UL: 9..16, LL: 24..17, LR: 25..32
    const idx = [9 - pos, 8 + pos, 25 - pos, 24 + pos][quadrant];
    return `${idx}`;
  }
  // palmer: quadrant symbol + number
  const sym = ["┘", "└", "┌", "┐"][quadrant];
  return `${sym}${pos}`;
}

function Arch({ upper, system, showLabels }: { upper: boolean; system: string; showLabels: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (g.current) g.current.rotation.y = Math.sin(elapsed.current * 0.25) * 0.06;
  });
  const y = upper ? 1.1 : -1.5;
  const quads = upper ? [0, 1] : [2, 3];
  return (
    <group ref={g} position={[0, y, 0]}>
      {/* gum ridge */}
      <mesh scale={[1, 0.45, 1]} castShadow>
        <torusGeometry args={[4.4, 1.25, 14, 40, Math.PI]} />
        <meshStandardMaterial color={GUM} roughness={0.6} />
      </mesh>
      {quads.map((q) =>
        Array.from({ length: 8 }).map((_, i) => {
          const pos = i + 1;
          // position along half-arch
          const a = Math.PI - (q % 2 === 0 ? (i / 8) * Math.PI * 0.5 : Math.PI - ((i / 8) * Math.PI * 0.5));
          const x = Math.cos(a) * 4.4;
          const z = -Math.sin(a) * 4.4 * 0.9 + 0.4;
          const isMolar = pos > 5;
          return (
            <group key={`${q}-${pos}`} position={[x, 0.5, z]}>
              <mesh castShadow>
                <boxGeometry args={[isMolar ? 0.95 : 0.72, 0.85, isMolar ? 0.95 : 0.6]} />
                <meshStandardMaterial color={ENAMEL} roughness={0.25} />
              </mesh>
              {showLabels && (
                <Text position={[0, 0.95, 0]} fontSize={0.4} color="#1e293b" anchorX="center">
                  {labelFor(system, q, pos)}
                </Text>
              )}
            </group>
          );
        })
      )}
      {showLabels && (
        <Text position={[-7.6, 0.4, 0]} fontSize={0.46} color="#fef3c7">{upper ? "Upper" : "Lower"}</Text>
      )}
    </group>
  );
}

export function Topic10370Sim(props: SimProps) {
  const system = String(props.system ?? "fdi");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const names: Record<string, string> = { fdi: "FDI (two-digit)", universal: "Universal (1–32)", palmer: "Palmer (symbols)" };
  const logic: Record<string, string> = {
    fdi: "quadrant + position, e.g. 11 = upper-right central",
    universal: "1–16 upper, 17–32 lower",
    palmer: "┘└┌┐ symbol + number 1–8",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["System", names[system] ?? system],
          ["Logic", logic[system] ?? ""],
          ["Teeth", "32 permanent"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 15]} target={[0, -0.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -4.4, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Arch upper system={system} showLabels={showLabels} />
        <Arch upper={false} system={system} showLabels={showLabels} />
        {showLabels && (
          <Text position={[0, 4.6, 0]} fontSize={0.44} color="#facc15">
            {system === "fdi" ? "Upper-right central = 11" : system === "universal" ? "Upper-right third molar = 1" : "Upper-right central = ┘1"}
          </Text>
        )}
      </SimCanvas>
    </div>
  );
}
