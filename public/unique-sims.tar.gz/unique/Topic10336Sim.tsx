"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "technique", label: "Technique", kind: "select", min: 0, max: 0, step: 1, default: "spinal", options: ["spinal", "epidural", "nerve-block"] },
  { key: "depth", label: "Needle advance", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.55, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Regional anesthesia: spinal, epidural, nerve blocks",
  blurb: "Advance the needle through the lumbar spine — spinal hits the CSF sac, epidural stays outside it, nerve block targets a peripheral nerve.",
};

const BONE = "#e7e5e4";
const SKIN = "#f7c9a8";
const CSF = "#38bdf8";
const CORD = "#fbbf24";

// depths (needle tip y at full advance) for each technique
const TARGETS: Record<string, { tip: number; spreadColor: string; name: string; note: string }> = {
  spinal: { tip: 1.15, spreadColor: "#38bdf8", name: "Spinal", note: "drug INTO the CSF sac" },
  epidural: { tip: 1.62, spreadColor: "#a78bfa", name: "Epidural", note: "drug OUTSIDE the dura" },
  "nerve-block": { tip: 0.0, spreadColor: "#4ade80", name: "Nerve block", note: "drug around the nerve" },
};

function Vertebra({ y }: { y: number }) {
  return (
    <group position={[0, y, 0]}>
      {/* body */}
      <mesh castShadow>
        <cylinderGeometry args={[0.95, 0.95, 0.85, 20]} />
        <meshStandardMaterial color={BONE} roughness={0.6} />
      </mesh>
      {/* spinous process pointing back */}
      <mesh position={[0, 0, -1.35]} rotation={[Math.PI / 2.4, 0, 0]} castShadow>
        <boxGeometry args={[0.32, 0.32, 1.6]} />
        <meshStandardMaterial color={BONE} roughness={0.6} />
      </mesh>
      {/* lamina arch */}
      <mesh position={[0, 0.1, -0.75]} castShadow>
        <torusGeometry args={[0.75, 0.22, 10, 20, Math.PI]} />
        <meshStandardMaterial color={BONE} roughness={0.6} />
      </mesh>
    </group>
  );
}

function SpineModel({ technique, depth, speed, showLabels }: { technique: string; depth: number; speed: number; showLabels: boolean }) {
  const needle = useRef<THREE.Group>(null!);
  const spread = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const cfg = TARGETS[technique] ?? TARGETS.spinal;
  const isNerve = technique === "nerve-block";

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (isNerve) return;
    const startY = 6.4;
    const y = THREE.MathUtils.lerp(startY, cfg.tip, depth);
    if (needle.current) needle.current.position.y = y + Math.sin(elapsed.current * 1.5) * 0.03;
    if (spread.current) {
      const placed = depth > 0.85;
      const s = placed ? Math.min(1, (depth - 0.85) / 0.15) * (1 + Math.sin(elapsed.current * 2) * 0.08) : 0.001;
      spread.current.scale.setScalar(Math.max(s, 0.001));
    }
  });

  return (
    <group>
      {!isNerve && (
        <>
          {/* skin of the back */}
          <mesh position={[0, 5.2, -2.6]} castShadow>
            <boxGeometry args={[6, 5, 0.5]} />
            <meshStandardMaterial color={SKIN} roughness={0.7} />
          </mesh>
          {[3.4, 1.9, 0.4].map((y, i) => (
            <Vertebra key={i} y={y} />
          ))}
          {/* dural sac with CSF */}
          <mesh position={[0, 1.9, -0.15]}>
            <capsuleGeometry args={[0.5, 2.6, 8, 16]} />
            <meshPhysicalMaterial color={CSF} transparent opacity={0.45} roughness={0.15} />
          </mesh>
          {/* spinal cord inside */}
          <mesh position={[0, 2.35, -0.15]}>
            <cylinderGeometry args={[0.18, 0.22, 2.4, 12]} />
            <meshStandardMaterial color={CORD} roughness={0.4} />
          </mesh>
          {/* epidural space ring */}
          <mesh position={[0, 1.9, -0.15]} rotation={[0, 0, 0]}>
            <torusGeometry args={[0.62, 0.06, 8, 24]} />
            <meshBasicMaterial color="#a78bfa" transparent opacity={0.5} />
          </mesh>
          {/* needle assembly */}
          <group ref={needle} position={[0, 6.4, -0.15]}>
            <mesh position={[0, 0.6, 0]} castShadow>
              <cylinderGeometry args={[0.09, 0.05, 3.6, 10]} />
              <meshStandardMaterial color="#cbd5e1" metalness={0.85} roughness={0.25} />
            </mesh>
            <mesh position={[0, 2.6, 0]} castShadow>
              <boxGeometry args={[0.7, 0.7, 0.7]} />
              <meshStandardMaterial color="#f97316" roughness={0.5} />
            </mesh>
            {/* syringe barrel */}
            <mesh position={[0, 3.4, 0]} rotation={[0, 0, 0]} castShadow>
              <cylinderGeometry args={[0.28, 0.28, 1.2, 14]} />
              <meshPhysicalMaterial color="#e0f2fe" transparent opacity={0.6} roughness={0.1} />
            </mesh>
            <mesh position={[0, 3.4, 0]}>
              <cylinderGeometry args={[0.2, 0.2, 0.6, 14]} />
              <meshStandardMaterial color={cfg.spreadColor} transparent opacity={0.8} roughness={0.2} />
            </mesh>
          </group>
          {/* anesthetic spread blob */}
          <mesh ref={spread} position={[0, cfg.tip + 0.35, -0.15]} scale={[0.001, 0.001, 0.001]}>
            <sphereGeometry args={[1, 24, 16]} />
            <meshStandardMaterial color={cfg.spreadColor} transparent opacity={0.55} emissive={cfg.spreadColor} emissiveIntensity={0.5} />
          </mesh>
          {showLabels && (
            <>
              <Text position={[3.4, 4.6, -0.15]} fontSize={0.4} color="#fef3c7">Needle</Text>
              <Text position={[3.2, 2.5, -0.15]} fontSize={0.4} color="#7dd3fc">CSF sac (dura)</Text>
              <Text position={[-3.2, 1.9, -0.15]} fontSize={0.4} color="#fbbf24">Spinal cord</Text>
              <Text position={[0, 6.9, -0.15]} fontSize={0.42} color="#fdba74" maxWidth={5}>{cfg.note}</Text>
            </>
          )}
        </>
      )}
      {isNerve && <NerveBlock speed={speed} showLabels={showLabels} depth={depth} />}
    </group>
  );
}

function NerveBlock({ speed, showLabels, depth }: { speed: number; showLabels: boolean; depth: number }) {
  const spread = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (spread.current) {
      const s = depth > 0.7 ? 1 + Math.sin(elapsed.current * 2) * 0.08 : 0.001;
      spread.current.scale.setScalar(Math.max(s, 0.001));
    }
  });
  return (
    <group>
      {/* arm cross-section */}
      <mesh castShadow>
        <cylinderGeometry args={[1.9, 1.9, 4.5, 28]} />
        <meshStandardMaterial color={SKIN} roughness={0.7} />
      </mesh>
      {/* nerve bundle */}
      <mesh position={[0.7, 0.6, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.3, 0.3, 4.7, 14]} />
        <meshStandardMaterial color={CORD} roughness={0.35} emissive="#b45309" emissiveIntensity={0.3} />
      </mesh>
      {/* artery + vein */}
      <mesh position={[-0.6, -0.4, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.22, 0.22, 4.7, 12]} />
        <meshStandardMaterial color="#ef4444" roughness={0.4} />
      </mesh>
      {/* needle from the side */}
      <group position={[3.4 - depth * 2.2, 1.4, 0]} rotation={[0, 0, 1.1]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.07, 0.04, 2.6, 10]} />
          <meshStandardMaterial color="#cbd5e1" metalness={0.85} roughness={0.25} />
        </mesh>
      </group>
      {/* anesthetic cuff around nerve */}
      <mesh ref={spread} position={[0.7, 0.6, 0]} scale={[0.001, 0.001, 0.001]}>
        <sphereGeometry args={[0.75, 20, 14]} />
        <meshStandardMaterial color="#4ade80" transparent opacity={0.55} emissive="#4ade80" emissiveIntensity={0.5} />
      </mesh>
      {showLabels && (
        <>
          <Text position={[0.7, 2.8, 0]} fontSize={0.42} color="#fde68a">Nerve</Text>
          <Text position={[-0.6, -2.6, 0]} fontSize={0.42} color="#fca5a5">Artery — avoid!</Text>
        </>
      )}
    </group>
  );
}

export function Topic10336Sim(props: SimProps) {
  const technique = String(props.technique ?? "spinal");
  const depth = Number(props.depth ?? 0.55);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = TARGETS[technique] ?? TARGETS.spinal;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Technique", cfg.name],
          ["Target", technique === "spinal" ? "Subarachnoid" : technique === "epidural" ? "Epidural space" : "Perineural"],
          ["Needle", depth > 0.85 ? "at target ✓" : "advancing…"],
        ]}
      />
      <SimCanvas cameraPosition={technique === "nerve-block" ? [0, 2.5, 9] : [5.5, 4, 10]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.6, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <SpineModel technique={technique} depth={depth} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
