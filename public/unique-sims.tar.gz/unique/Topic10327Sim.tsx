"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "disease", label: "Disease", kind: "select", min: 0, max: 0, step: 1, default: "pemphigus", options: ["pemphigus", "bullous pemphigoid"] },
  { key: "size", label: "Blister size", kind: "slider", min: 0.5, max: 1.6, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Blistering diseases: pemphigus vs bullous pemphigoid",
  blurb: "Skin cross-section showing where each blister splits: pemphigus splits INSIDE the epidermis, bullous pemphigoid splits BELOW it.",
};

const SKIN = "#f7c9a8";
const EPIDERMIS = "#e8a87c";
const DERMIS = "#d9826b";

function SkinBlock({ showLabels }: { showLabels: boolean }) {
  return (
    <group>
      {/* dermis base */}
      <mesh position={[0, -1.1, 0]} castShadow receiveShadow>
        <boxGeometry args={[8, 2.2, 4]} />
        <meshStandardMaterial color={DERMIS} roughness={0.85} />
      </mesh>
      {/* epidermis sheet */}
      <mesh position={[0, 0.1, 0]} castShadow>
        <boxGeometry args={[8, 0.5, 4]} />
        <meshStandardMaterial color={EPIDERMIS} roughness={0.7} />
      </mesh>
      {/* skin surface film */}
      <mesh position={[0, 0.36, 0]}>
        <boxGeometry args={[8, 0.02, 4]} />
        <meshStandardMaterial color={SKIN} roughness={0.5} />
      </mesh>
      {showLabels && (
        <>
          <Text position={[-4.9, 0.1, 0]} fontSize={0.42} color="#fef3c7">Epidermis</Text>
          <Text position={[-4.9, -1.1, 0]} fontSize={0.42} color="#fef3c7">Dermis</Text>
        </>
      )}
    </group>
  );
}

// Autoantibodies drifting toward the split plane.
function Antibodies({ plane, speed }: { plane: number; speed: number }) {
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const pts = useMemo(() => {
    const arr: number[] = [];
    for (let i = 0; i < 26; i++) arr.push((Math.random() - 0.5) * 7, Math.random() * 2.4 - 0.6, (Math.random() - 0.5) * 3);
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(arr, 3));
    return g;
  }, []);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (group.current) {
      group.current.children.forEach((c, i) => {
        c.position.y = plane + Math.sin(elapsed.current * 2 + i) * 0.35;
      });
    }
  });
  return (
    <group ref={group}>
      {Array.from({ length: 26 }).map((_, i) => (
        <mesh key={i} position={[(Math.random() - 0.5) * 7, plane, (Math.random() - 0.5) * 3]}>
          <sphereGeometry args={[0.07, 8, 8]} />
          <meshStandardMaterial color="#facc15" emissive="#facc15" emissiveIntensity={0.8} />
        </mesh>
      ))}
      <points geometry={pts} visible={false} />
    </group>
  );
}

function Blister({ disease, size, speed, showLabels }: { disease: string; size: number; speed: number; showLabels: boolean }) {
  const dome = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const pemphigus = disease === "pemphigus";
  // intraepidermal (inside epidermis layer, y≈0.1) vs subepidermal (lifting epidermis from below, y≈-0.15)
  const y = pemphigus ? 0.18 : -0.18;
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const pulse = 1 + Math.sin(elapsed.current * 2.2) * 0.06;
    if (dome.current) dome.current.scale.set(size * pulse, size * 0.72 * pulse, size * pulse);
  });
  return (
    <group position={[0.4, y, 0]}>
      {/* fluid-filled blister dome */}
      <mesh ref={dome} castShadow>
        <sphereGeometry args={[1.35, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshPhysicalMaterial color="#fde68a" transparent opacity={0.75} roughness={0.15} transmission={0.4} />
      </mesh>
      {/* blister fluid highlight */}
      <mesh position={[0, 0.25 * size, 0]}>
        <sphereGeometry args={[0.85 * size, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial color="#fbbf24" transparent opacity={0.5} roughness={0.2} />
      </mesh>
      {/* split-plane indicator */}
      <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[3.2, 3.2]} />
        <meshBasicMaterial color="#ef4444" transparent opacity={0.45} side={THREE.DoubleSide} />
      </mesh>
      {showLabels && (
        <Text position={[2.6, 1.35 * size, 0]} fontSize={0.44} color="#fecaca" maxWidth={4}>
          {pemphigus ? "Split INSIDE epidermis" : "Split BELOW epidermis"}
        </Text>
      )}
      <Antibodies plane={pemphigus ? 0.1 : -0.15} speed={speed} />
    </group>
  );
}

export function Topic10327Sim(props: SimProps) {
  const disease = String(props.disease ?? "pemphigus");
  const size = Number(props.size ?? 1);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const split = disease === "pemphigus" ? "Intraepidermal" : "Subepidermal";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Disease", disease === "pemphigus" ? "Pemphigus" : "Bullous pemphigoid"],
          ["Split level", split],
          ["Flaccid bullae", disease === "pemphigus" ? "yes" : "tense"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 11]} target={[0, 0.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.25, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <SkinBlock showLabels={showLabels} />
        <Blister disease={disease} size={size} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
