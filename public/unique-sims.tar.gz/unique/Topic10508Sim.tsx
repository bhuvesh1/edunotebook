// app/components/sims/unique/Topic10508Sim.tsx
// TMJ disorders: side-view skull with a hinged mandible. Normal disc motion,
// disc displacement (click), and ankylosis (fused, nearly immobile joint).

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "normal", options: ["normal", "disc-displacement", "ankylosis"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "TMJ Disorders & Ankylosis",
  blurb: "Open and close the jaw: smooth in health, clicking with disc displacement, locked shut in ankylosis.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ jaw, joint, elapsed, speed, cond }: {
  jaw: RefObject<THREE.Group>; joint: RefObject<THREE.Mesh>;
  elapsed: RefObject<number>; speed: number; cond: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    let open = 0;
    if (cond === "normal") {
      open = 0.28 * (0.5 - 0.5 * Math.cos(t * 1.6)); // smooth open/close
    } else if (cond === "disc-displacement") {
      // opens with a sudden click (jump) mid-way
      const c = 0.5 - 0.5 * Math.cos(t * 1.6);
      open = 0.22 * c + (c > 0.45 && c < 0.75 ? 0.1 : 0);
    } else {
      open = 0.015 * Math.abs(Math.sin(t * 1.6)); // ankylosis: fused, barely moves
    }
    if (jaw.current) jaw.current.rotation.z = -open;
    if (joint.current) {
      const mat = joint.current.material as THREE.MeshStandardMaterial;
      if (cond === "ankylosis") {
        mat.color.set("#ef4444");
        mat.emissive.set("#ef4444");
        mat.emissiveIntensity = 0.6 + 0.3 * Math.sin(t * 4);
      } else if (cond === "disc-displacement") {
        mat.color.set("#fbbf24");
        mat.emissive.set("#f59e0b");
        mat.emissiveIntensity = 0.5;
      } else {
        mat.color.set("#a3e635");
        mat.emissive.set("#65a30d");
        mat.emissiveIntensity = 0.3;
      }
    }
  });
  return null;
}

const BONE = "#e8dcc3";
const NAMES: Record<string, string> = {
  normal: "Normal TMJ",
  "disc-displacement": "Disc displacement with reduction (click)",
  ankylosis: "TMJ ankylosis (bony fusion)",
};

export function Topic10508Sim(props: SimProps) {
  const cond = String(props.cond ?? "normal");
  const speed = Number(props.speed ?? 1);
  const jaw = useRef<THREE.Group>(null!);
  const joint = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", NAMES[cond] ?? cond],
          ["Mouth opening", cond === "ankylosis" ? "≈ 0 mm (locked)" : cond === "disc-displacement" ? "limited + click" : "40–50 mm"],
          ["● Joint", cond === "ankylosis" ? "fused red" : cond === "disc-displacement" ? "displaced disc" : "healthy"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 12]} target={[0, 2.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* cranium (side view, facing +x) */}
        <mesh position={[-0.2, 3.6, 0]} castShadow>
          <sphereGeometry args={[1.45, 32, 32]} />
          <meshStandardMaterial color={BONE} roughness={0.6} />
        </mesh>
        {/* maxilla (fixed upper jaw) */}
        <mesh position={[0.85, 2.55, 0]} castShadow>
          <boxGeometry args={[1.2, 0.7, 1.1]} />
          <meshStandardMaterial color={BONE} roughness={0.6} />
        </mesh>
        {/* upper teeth */}
        {[0.45, 0.75, 1.05, 1.3].map((x, i) => (
          <mesh key={i} position={[x, 2.05, 0]} castShadow>
            <boxGeometry args={[0.22, 0.35, 0.5]} />
            <meshStandardMaterial color="#ffffff" roughness={0.3} />
          </mesh>
        ))}
        {/* zygomatic arch hint */}
        <mesh position={[-0.35, 2.95, 0]} rotation={[0, 0, 0.15]} castShadow>
          <boxGeometry args={[1.6, 0.18, 0.5]} />
          <meshStandardMaterial color={BONE} roughness={0.6} />
        </mesh>

        {/* TMJ joint marker (in front of ear region) */}
        <mesh ref={joint} position={[-0.85, 2.75, 0.62]}>
          <sphereGeometry args={[0.24, 20, 20]} />
          <meshStandardMaterial color="#a3e635" emissive="#65a30d" emissiveIntensity={0.3} roughness={0.4} />
        </mesh>
        <Label p={[-0.85, 3.35, 0.7]} size={0.28} color="#fde68a">TMJ</Label>

        {/* mandible: hinged group, pivot at the joint */}
        <group position={[-0.85, 2.75, 0]}>
          <group ref={jaw}>
            {/* ramus */}
            <mesh position={[-0.1, -0.55, 0]} castShadow>
              <boxGeometry args={[0.55, 1.5, 0.7]} />
              <meshStandardMaterial color={BONE} roughness={0.6} />
            </mesh>
            {/* body of mandible reaching forward */}
            <mesh position={[0.85, -1.15, 0]} castShadow>
              <boxGeometry args={[2.1, 0.55, 0.75]} />
              <meshStandardMaterial color={BONE} roughness={0.6} />
            </mesh>
            {/* chin */}
            <mesh position={[1.95, -1.0, 0]} castShadow>
              <sphereGeometry args={[0.32, 16, 16]} />
              <meshStandardMaterial color={BONE} roughness={0.6} />
            </mesh>
            {/* lower teeth */}
            {[1.15, 1.45, 1.72].map((x, i) => (
              <mesh key={i} position={[x, -0.72, 0]} castShadow>
                <boxGeometry args={[0.2, 0.32, 0.45]} />
                <meshStandardMaterial color="#ffffff" roughness={0.3} />
              </mesh>
            ))}
            {/* articular disc */}
            <mesh position={[-0.05, 0.05, 0.62]}>
              <sphereGeometry args={[0.13, 14, 14]} />
              <meshStandardMaterial color="#93c5fd" roughness={0.4} />
            </mesh>
          </group>
        </group>

        <Label p={[2.2, 0.9, 0]} size={0.28} color="#e2e8f0">mandible swings on the TMJ</Label>

        <Animator jaw={jaw} joint={joint} elapsed={elapsed} speed={speed} cond={cond} />
      </SimCanvas>
    </div>
  );
}
