"use client";
// Thermal injuries: burns, electrocution, lightning.
// Three skin layers stacked; pick the burn degree and watch the heat
// reach deeper, or switch the cause to electric blue / lightning white.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "degree", label: "Burn degree", kind: "select", min: 0, max: 0, step: 1, default: "second", options: ["first", "second", "third"] },
  { key: "cause", label: "Cause", kind: "select", min: 0, max: 0, step: 1, default: "fire", options: ["fire", "electric", "lightning"] },
];

export const UNIQUE_META = {
  title: "Thermal Injuries: Burns, Electrocution, Lightning",
  blurb: "Peel into the skin's three layers and see how deep each burn degree reaches — fire, electric or lightning.",
};

const LAYERS = [
  { name: "Epidermis (outer skin)", color: "#fcd9b8", y: 3.3, depth: 1 },
  { name: "Dermis (with nerves)", color: "#f0a58e", y: 2.45, depth: 2 },
  { name: "Fat + muscle", color: "#e8b04b", y: 1.6, depth: 3 },
];
const DEGREE_N: Record<string, number> = { first: 1, second: 2, third: 3 };
const DEGREE_TXT: Record<string, string> = {
  first: "1st: red, painful, heals",
  second: "2nd: blisters, deeper",
  third: "3rd: full thickness, numb",
};

function Animator({ flames, elapsed }: { flames: React.RefObject<THREE.Group>; elapsed: React.RefObject<number> }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (flames.current) {
      flames.current.children.forEach((f, i) => {
        const s = 1 + Math.sin(elapsed.current * 9 + i * 2.1) * 0.18;
        f.scale.set(s, 1 + Math.sin(elapsed.current * 7 + i) * 0.28, s);
      });
    }
  });
  return null;
}

export function Topic10156Sim(props: SimProps) {
  const degree = String(props.degree ?? "second");
  const cause = String(props.cause ?? "fire");
  const flames = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const d = DEGREE_N[degree] ?? 2;
  const flameColor = cause === "electric" ? "#60a5fa" : cause === "lightning" ? "#f8fafc" : "#fb923c";
  const causeIcon = cause === "electric" ? "⚡ ELECTRIC" : cause === "lightning" ? "🌩 LIGHTNING" : "🔥 FIRE";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Degree", degree], ["Cause", cause], ["Damage", DEGREE_TXT[degree] ?? ""]]} />
      <SimCanvas cameraPosition={[0, 3.4, 12]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* skin layers */}
        <group position={[-1.5, 0, 0]}>
          {LAYERS.map((l) => {
            const burned = l.depth <= d;
            return (
              <group key={l.name}>
                <mesh position={[0, l.y, 0]} castShadow>
                  <boxGeometry args={[4.6, 0.8, 2.6]} />
                  <meshStandardMaterial color={burned ? "#7c2d12" : l.color} roughness={0.75} emissive={burned ? "#ef4444" : "#000000"} emissiveIntensity={burned ? 0.35 : 0} />
                </mesh>
                <Label text={l.name} position={[3.4, l.y, 0]} size={0.5} color={burned ? "#f87171" : "#e2e8f0"} />
              </group>
            );
          })}
          {/* burn-depth marker */}
          <mesh position={[-2.9, 3.3 - (d - 1) * 0.85 - 0.4 * (d === 3 ? 0.4 : 0), 0]}>
            <boxGeometry args={[0.35, d * 0.85, 2.9]} />
            <meshStandardMaterial color="#ef4444" transparent opacity={0.55} emissive="#ef4444" emissiveIntensity={0.6} />
          </mesh>
          <Label text="BURN DEPTH" position={[-2.9, 4.5, 0]} size={0.55} color="#f87171" />
        </group>
        {/* flame / spark source */}
        <group position={[3.8, 0, 0]}>
          <group ref={flames}>
            {[0, 1, 2].map((i) => (
              <mesh key={i} position={[(i - 1) * 0.55, 1.15, 0]} castShadow>
                <coneGeometry args={[0.42, 1.5, 12]} />
                <meshStandardMaterial color={flameColor} emissive={flameColor} emissiveIntensity={0.9} transparent opacity={0.92} />
              </mesh>
            ))}
          </group>
          <mesh position={[0, 0.3, 0]}>
            <cylinderGeometry args={[0.9, 1.1, 0.6, 16]} />
            <meshStandardMaterial color="#78350f" roughness={0.9} />
          </mesh>
          <Label text={causeIcon} position={[0, 2.9, 0]} size={0.65} color={flameColor} />
        </group>
        <Animator flames={flames} elapsed={elapsed} />
      </SimCanvas>
    </div>
  );
}
