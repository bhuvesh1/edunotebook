// Antigens & antibodies: Y-shaped antibodies swarm a spiky pathogen, lock onto
// its red antigens, and neutralize it one epitope at a time.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ab", label: "Antibody count", kind: "slider", min: 2, max: 12, step: 1, default: 8, unit: "" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Antigens & antibodies",
  blurb: "Y-shaped antibodies swarm the pathogen, lock onto its antigens, and neutralize it.",
};

const N_AB = 12;
const N_AG = 8;

function YShape({ color }: { color: string }) {
  return (
    <group>
      <mesh position={[0, -0.3, 0]}>
        <cylinderGeometry args={[0.07, 0.07, 0.6, 8]} />
        <meshStandardMaterial color={color} roughness={0.4} />
      </mesh>
      <mesh position={[-0.16, 0.12, 0]} rotation={[0, 0, 0.6]}>
        <cylinderGeometry args={[0.07, 0.07, 0.55, 8]} />
        <meshStandardMaterial color={color} roughness={0.4} />
      </mesh>
      <mesh position={[0.16, 0.12, 0]} rotation={[0, 0, -0.6]}>
        <cylinderGeometry args={[0.07, 0.07, 0.55, 8]} />
        <meshStandardMaterial color={color} roughness={0.4} />
      </mesh>
    </group>
  );
}

function Animator({ abs, ags, patho, elapsed, count, setTick }: {
  abs: React.RefObject<(THREE.Group | null)[]>;
  ags: React.RefObject<(THREE.Mesh | null)[]>;
  patho: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  count: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (patho.current) {
      patho.current.rotation.y = t * 0.5;
      patho.current.position.y = 1.6 + Math.sin(t * 1.2) * 0.12;
    }
    let bound = 0;
    abs.current.forEach((g, i) => {
      if (!g) return;
      const active = i < count;
      g.visible = active;
      if (!active) return;
      const ai = i % N_AG;
      const aa = (ai / N_AG) * Math.PI * 2;
      // fly in from afar, then dock onto antigen slot ai
      const cyc = Math.min(1, t * 0.35 - i * 0.12);
      const docked = cyc >= 1;
      if (docked) bound++;
      const sx = -4.5 + (i % 4) * 0.8;
      const tx = Math.cos(aa) * 1.35;
      const tz = Math.sin(aa) * 1.35;
      const e = cyc * cyc;
      g.position.set(sx + (tx - sx) * e, 3.4 + (1.6 + Math.sin(aa * 2) * 0.4 - 3.4) * e + 1.6 * (1 - e) * 0, tz * e);
      g.position.y = 3.4 * (1 - e) + (1.6 + Math.cos(aa * 1.5) * 0.5) * e;
      g.lookAt(0, 1.6, 0);
      const ag = ags.current[ai];
      if (ag && docked) {
        (ag.material as THREE.MeshStandardMaterial).emissiveIntensity = 1.4;
        ag.scale.setScalar(1 + Math.sin(t * 5) * 0.1);
      }
    });
    ags.current.forEach((ag, i) => {
      if (!ag) return;
      const isBound = i < Math.min(count, N_AG) && t * 0.35 - (i % count) * 0.12 > 1;
      if (!isBound) {
        (ag.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.5 + Math.sin(t * 2 + i) * 0.25;
        ag.scale.setScalar(1);
      }
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(bound); }
  });
  return null;
}

export function Topic10145Sim(props: SimProps) {
  const count = Math.round(Number(props.ab ?? 8));
  const showLabels = String(props.detail ?? "on") === "on";
  const abs = useRef<(THREE.Group | null)[]>([]);
  const ags = useRef<(THREE.Mesh | null)[]>([]);
  const patho = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const neut = Math.min(100, Math.round((tick / N_AG) * 100));

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Antibodies bound", `${tick}/${N_AG}`],
          ["Neutralization", `${neut}%`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* pathogen with antigens */}
        <group ref={patho} position={[0, 1.6, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[1.1, 22, 16]} />
            <meshStandardMaterial color="#65a30d" roughness={0.5} />
          </mesh>
          {Array.from({ length: N_AG }).map((_, i) => {
            const a = (i / N_AG) * Math.PI * 2;
            return (
              <mesh
                key={i}
                ref={(m) => { ags.current[i] = m; }}
                position={[Math.cos(a) * 1.2, Math.sin(a * 2) * 0.5, Math.sin(a) * 1.2]}
              >
                <coneGeometry args={[0.16, 0.4, 8]} />
                <meshStandardMaterial color="#ef4444" emissive="#b91c1c" emissiveIntensity={0.6} />
              </mesh>
            );
          })}
        </group>
        {showLabels && <Label text="pathogen" position={[0, 0.15, 0]} color="#bef264" />}
        {showLabels && <Label text="antigens (red spikes)" position={[0, 3.3, 0]} color="#fca5a5" />}

        {/* antibodies */}
        {Array.from({ length: N_AB }).map((_, i) => (
          <group key={i} ref={(g) => { abs.current[i] = g; }}>
            <YShape color="#38bdf8" />
          </group>
        ))}
        {showLabels && <Label text={`Y-shaped antibodies ×${count}`} position={[-4.4, 3.9, 0]} size={0.45} color="#7dd3fc" />}

        {/* B-cell factory */}
        <group position={[4.6, 1.2, -0.6]}>
          <mesh scale={[1.2, 1, 1]} castShadow>
            <sphereGeometry args={[0.8, 18, 14]} />
            <meshStandardMaterial color="#a855f7" roughness={0.5} />
          </mesh>
        </group>
        {showLabels && <Label text="B-cell — antibody factory" position={[4.6, 2.7, -0.6]} size={0.4} color="#d8b4fe" />}

        <Animator abs={abs} ags={ags} patho={patho} elapsed={elapsed} count={count} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
