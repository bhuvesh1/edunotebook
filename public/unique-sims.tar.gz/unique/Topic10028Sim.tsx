// Embryology: face, palate, tongue, teeth — facial prominences swell and fuse
// into a face, while a tooth bud grows through bud → cap → bell stages.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "fuse", label: "Prominence fusion", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.65, unit: "" },
  { key: "toothstage", label: "Tooth stage", kind: "select", min: 0, max: 0, step: 1, default: "bell", options: ["bud", "cap", "bell"] },
];

export const UNIQUE_META = {
  title: "Embryology: Face & Tooth Development",
  blurb: "Facial prominences fuse around the stomodeum while a tooth bud grows from bud to cap to bell.",
};

function Animator({
  tooth, elapsed, speed,
}: {
  tooth: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (tooth.current) tooth.current.rotation.y = t * 0.5;
  });
  return null;
}

export function Topic10028Sim(props: SimProps) {
  const fuse = Number(props.fuse ?? 0.65);
  const toothstage = String(props.toothstage ?? "bell");
  const tooth = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  // prominence positions converge as fuse -> 1
  const prom = useMemo(() => {
    const c = 1 - fuse;
    return {
      frontonasal: [0, 3.6 - fuse * 0.6, 0] as [number, number, number],
      maxillaryL: [-2.3 * c - 1.0, 2.0, 0.3] as [number, number, number],
      maxillaryR: [2.3 * c + 1.0, 2.0, 0.3] as [number, number, number],
      mandibularL: [-1.9 * c - 0.8, 0.7, 0.4] as [number, number, number],
      mandibularR: [1.9 * c + 0.8, 0.7, 0.4] as [number, number, number],
      nasalL: [-0.55 * c - 0.35, 2.9, 0.6] as [number, number, number],
      nasalR: [0.55 * c + 0.35, 2.9, 0.6] as [number, number, number],
    };
  }, [fuse]);

  const P = ([x, y, z]: [number, number, number], r: number, color: string, key: string) => (
    <mesh key={key} position={[x, y, z]} castShadow>
      <sphereGeometry args={[r, 18, 18]} />
      <meshStandardMaterial color={color} roughness={0.5} />
    </mesh>
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Fusion", `${Math.round(fuse * 100)}%`],
          ["Tooth", `${toothstage} stage`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5, 14]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* FACE: prominences around the stomodeum */}
        <group>
          {P(prom.frontonasal, 1.15, "#fda4af", "fn")}
          {P(prom.maxillaryL, 0.85, "#fb7185", "mxl")}
          {P(prom.maxillaryR, 0.85, "#fb7185", "mxr")}
          {P(prom.mandibularL, 0.8, "#f43f5e", "mdl")}
          {P(prom.mandibularR, 0.8, "#f43f5e", "mdr")}
          {P(prom.nasalL, 0.4, "#f9a8d4", "nl")}
          {P(prom.nasalR, 0.4, "#f9a8d4", "nr")}
          {/* stomodeum (primitive mouth) */}
          <mesh position={[0, 1.45, 1.0]}>
            <sphereGeometry args={[0.32 * (1 - fuse * 0.4), 12, 12]} />
            <meshStandardMaterial color="#7f1d1d" roughness={0.5} />
          </mesh>
          {/* tongue swelling */}
          <mesh position={[0, 1.1, 0.9]} scale={[1.4, 0.6, 0.8]} castShadow>
            <sphereGeometry args={[0.4, 12, 12]} />
            <meshStandardMaterial color="#f87171" roughness={0.5} />
          </mesh>
        </group>
        <Label text="frontonasal prominence" position={[0, 5.0, 0]} size={0.34} color="#f8fafc" />
        <Label text="maxillary prominence" position={[-3.6, 2.6, 0.3]} size={0.3} color="#fda4af" />
        <Label text="mandibular prominence" position={[-3.4, 0.35, 0.4]} size={0.3} color="#fda4af" />
        <Label text="nasal placode" position={[1.7, 3.3, 0.6]} size={0.3} color="#f9a8d4" />
        <Label text="stomodeum" position={[1.6, 1.45, 1.2]} size={0.3} color="#fca5a5" />
        <Label text="tongue swelling" position={[-1.8, 1.0, 1.0]} size={0.3} color="#fca5a5" />

        {/* TOOTH: bud / cap / bell */}
        <group position={[6.2, 0, 0]}>
          <group ref={tooth} position={[0, 1.9, 0]}>
            {toothstage === "bud" && (
              <mesh castShadow>
                <sphereGeometry args={[0.7, 18, 18]} />
                <meshStandardMaterial color="#fef3c7" roughness={0.4} />
              </mesh>
            )}
            {toothstage === "cap" && (
              <group>
                <mesh castShadow>
                  <sphereGeometry args={[0.85, 20, 20, 0, Math.PI * 2, 0, Math.PI * 0.62]} />
                  <meshStandardMaterial color="#fef3c7" roughness={0.4} side={THREE.DoubleSide} />
                </mesh>
                <mesh position={[0, -0.25, 0]}>
                  <sphereGeometry args={[0.45, 14, 14]} />
                  <meshStandardMaterial color="#f59e0b" roughness={0.45} />
                </mesh>
              </group>
            )}
            {toothstage === "bell" && (
              <group>
                <mesh castShadow>
                  <sphereGeometry args={[0.9, 20, 20, 0, Math.PI * 2, 0, Math.PI * 0.72]} />
                  <meshStandardMaterial color="#fef3c7" roughness={0.4} side={THREE.DoubleSide} />
                </mesh>
                <mesh position={[0, -0.35, 0]}>
                  <sphereGeometry args={[0.5, 14, 14]} />
                  <meshStandardMaterial color="#f59e0b" roughness={0.45} />
                </mesh>
                {/* cervical loop + enamel knot */}
                <mesh position={[0, -0.62, 0]}>
                  <torusGeometry args={[0.5, 0.09, 8, 18]} />
                  <meshStandardMaterial color="#b45309" roughness={0.5} />
                </mesh>
                <mesh position={[0, 0.25, 0]}>
                  <sphereGeometry args={[0.16, 10, 10]} />
                  <meshStandardMaterial color="#dc2626" roughness={0.4} />
                </mesh>
              </group>
            )}
          </group>
          {/* dental lamina base */}
          <mesh position={[0, 0.55, 0]} castShadow>
            <boxGeometry args={[2.6, 0.5, 1.6]} />
            <meshStandardMaterial color="#fda4af" roughness={0.55} />
          </mesh>
        </group>
        <Label text={`tooth — ${toothstage} stage`} position={[6.2, 3.6, 0]} size={0.38} color="#f8fafc" />
        <Label text="enamel organ" position={[7.8, 2.2, 0]} size={0.3} color="#fde68a" />
        <Label text="dental papilla" position={[7.6, 1.15, 0]} size={0.3} color="#fdba74" />
        {toothstage === "bell" && (
          <Label text="enamel knot" position={[6.2, 2.75, 0]} size={0.28} color="#fca5a5" />
        )}

        <Animator tooth={tooth} elapsed={elapsed} speed={1} />
      </SimCanvas>
    </div>
  );
}
