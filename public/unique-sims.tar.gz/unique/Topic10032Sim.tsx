// General physiology: cell, membrane transport, homeostasis — a cell with a
// phospholipid bilayer, channel proteins and pumps; molecules cross by the
// selected transport mode while a homeostasis gauge stays balanced.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "mode", label: "Transport mode", kind: "select", min: 0, max: 0, step: 1, default: "diffusion", options: ["diffusion", "facilitated", "active"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Physiology: Membrane Transport",
  blurb: "Molecules cross the phospholipid bilayer by diffusion, facilitated diffusion, or active transport — pick the mode.",
};

const MODES = {
  diffusion: { desc: "down the gradient — no energy", color: "#4ade80", via: "bilayer" },
  facilitated: { desc: "via channel protein", color: "#38bdf8", via: "channel" },
  active: { desc: "against gradient — needs ATP", color: "#fbbf24", via: "pump" },
} as const;

function Animator({
  molecules, pump, elapsed, mode, speed,
}: {
  molecules: React.RefObject<THREE.Group>;
  pump: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  mode: keyof typeof MODES;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (molecules.current) {
      molecules.current.children.forEach((m, i) => {
        const dir = mode === "active" ? -1 : 1; // active pumps OUT->IN (uphill)
        const ph = ((t * 0.3 + i / 9) % 1 + 1) % 1;
        // cross the membrane plane at y=0; x depends on transport route
        const lane = m.userData.lane as number;
        m.position.y = dir > 0 ? 2.6 - ph * 5.2 : -2.6 + ph * 5.2;
        if (mode === "diffusion") m.position.x = lane * 2.6;
        else m.position.x = THREE.MathUtils.lerp(m.position.x, 0, 0.06);
        m.rotation.x += delta * 3;
        m.rotation.y += delta * 2;
      });
    }
    if (pump.current && mode === "active") {
      pump.current.rotation.z = t * 4;
    }
  });
  return null;
}

export function Topic10032Sim(props: SimProps) {
  const mode = (String(props.mode ?? "diffusion") as keyof typeof MODES) in MODES
    ? (String(props.mode ?? "diffusion") as keyof typeof MODES)
    : "diffusion";
  const speed = Number(props.speed ?? 1);
  const molecules = useRef<THREE.Group>(null!);
  const pump = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const info = MODES[mode];

  // phospholipid bilayer: two rows of spheres (heads) with tail cylinders
  const lipids = useMemo(() => Array.from({ length: 13 }).map((_, i) => -4.8 + i * 0.8), []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Mode", `${mode} — ${info.desc}`],
          ["Homeostasis", "intracellular K⁺ high ✓"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 14]} target={[0, 0.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* bilayer */}
        <group>
          {lipids.map((x, i) => (
            <group key={i} position={[x, 0, 0]}>
              {/* outer leaflet */}
              <mesh position={[0, 0.42, 0]} castShadow>
                <sphereGeometry args={[0.22, 10, 10]} />
                <meshStandardMaterial color="#38bdf8" roughness={0.4} />
              </mesh>
              <mesh position={[0, 0.1, 0]}>
                <cylinderGeometry args={[0.07, 0.07, 0.5, 6]} />
                <meshStandardMaterial color="#7dd3fc" roughness={0.5} />
              </mesh>
              {/* inner leaflet */}
              <mesh position={[0, -0.42, 0]} castShadow>
                <sphereGeometry args={[0.22, 10, 10]} />
                <meshStandardMaterial color="#38bdf8" roughness={0.4} />
              </mesh>
              <mesh position={[0, -0.1, 0]}>
                <cylinderGeometry args={[0.07, 0.07, 0.5, 6]} />
                <meshStandardMaterial color="#7dd3fc" roughness={0.5} />
              </mesh>
            </group>
          ))}
          {/* channel protein */}
          <mesh position={[-1.6, 0, 0]} castShadow>
            <cylinderGeometry args={[0.3, 0.3, 1.5, 12, 1, true]} />
            <meshStandardMaterial color="#a78bfa" roughness={0.4} side={THREE.DoubleSide} />
          </mesh>
          {/* carrier pump */}
          <mesh ref={pump} position={[1.6, 0, 0]} castShadow>
            <boxGeometry args={[0.7, 1.6, 0.7]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.45} />
          </mesh>
          <mesh position={[1.6, 0.55, 0]}>
            <sphereGeometry args={[0.14, 8, 8]} />
            <meshBasicMaterial color="#fef08a" />
          </mesh>
        </group>
        <Label text="extracellular" position={[-6.2, 3.4, 0]} size={0.4} color="#f8fafc" />
        <Label text="intracellular" position={[-6.2, -3.4, 0]} size={0.4} color="#f8fafc" />
        <Label text="phospholipid bilayer" position={[4.6, 0.9, 0]} size={0.32} color="#7dd3fc" />
        <Label text="channel protein" position={[-3.6, 0.9, 0]} size={0.3} color="#c4b5fd" />
        <Label text="Na⁺/K⁺ pump (ATP)" position={[3.9, -0.9, 0]} size={0.3} color="#fde68a" />

        {/* molecules crossing */}
        <group ref={molecules}>
          {Array.from({ length: 9 }).map((_, i) => (
            <mesh key={i} position={[0, 2.6, 0]} ref={(m) => { if (m) m.userData.lane = (i % 5) - 2; }} castShadow>
              <octahedronGeometry args={[0.2]} />
              <meshStandardMaterial color={info.color} emissive={info.color} emissiveIntensity={0.4} roughness={0.4} />
            </mesh>
          ))}
        </group>
        <Arrow from={[-0.9, 3.2, 0]} to={[-0.9, -3.2, 0]} color={info.color} radius={0.06} />

        {/* homeostasis gauge */}
        <group position={[7.6, 0, 0]}>
          <mesh castShadow>
            <torusGeometry args={[1.1, 0.18, 10, 28]} />
            <meshStandardMaterial color="#475569" roughness={0.5} />
          </mesh>
          <mesh position={[0.55, 0.55, 0]} rotation={[0, 0, Math.PI / 4]}>
            <boxGeometry args={[0.12, 1.15, 0.12]} />
            <meshStandardMaterial color="#4ade80" roughness={0.4} />
          </mesh>
          <mesh position={[0, 0, 0]}>
            <sphereGeometry args={[0.18, 10, 10]} />
            <meshStandardMaterial color="#e2e8f0" />
          </mesh>
        </group>
        <Label text="homeostasis: set point held" position={[7.6, 1.9, 0]} size={0.34} color="#86efac" />

        <Animator molecules={molecules} pump={pump} elapsed={elapsed} mode={mode} speed={speed} />
      </SimCanvas>
    </div>
  );
}
