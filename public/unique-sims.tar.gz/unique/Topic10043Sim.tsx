// Renal: GFR, tubular reabsorption & secretion — glomerulus filters plasma into
// Bowman's capsule; filtrate glows down the tubule while solute arrows are
// reabsorbed back into peritubular capillaries.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "gfr", label: "GFR", kind: "slider", min: 0, max: 200, step: 5, default: 125, unit: "mL/min" },
  { key: "adh", label: "ADH level", kind: "slider", min: 0, max: 1.5, step: 0.05, default: 0.5, unit: "×" },
];

export const UNIQUE_META = {
  title: "Renal: GFR & Tubular Transport",
  blurb: "The glomerulus filters 125 mL/min; follow the glowing filtrate as solutes are reabsorbed into the blood.",
};

function Animator({
  filtrate, reabs, secreted, elapsed, gfr, speed,
}: {
  filtrate: React.RefObject<THREE.Group>;
  reabs: React.RefObject<THREE.Group>;
  secreted: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  gfr: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const rate = gfr / 125;
    if (filtrate.current) {
      filtrate.current.children.forEach((m, i) => {
        const path = m.userData.path as THREE.Vector3[];
        const ph = ((t * 0.25 * rate + i / 12) % 1 + 1) % 1;
        const idx = Math.min(path.length - 2, Math.floor(ph * (path.length - 1)));
        const f = ph * (path.length - 1) - idx;
        m.position.lerpVectors(path[idx], path[idx + 1], f);
        m.visible = gfr > 2;
      });
    }
    const pulse = (grp: React.RefObject<THREE.Group>, dirn: number) => {
      if (!grp.current) return;
      grp.current.children.forEach((m, i) => {
        const ph = ((t * 0.5 * rate + i / 6) % 1 + 1) % 1;
        m.position.x = m.userData.x0 + dirn * ph * 1.6;
        const mat = (m as THREE.Mesh).material as THREE.MeshBasicMaterial;
        mat.opacity = 0.35 + 0.45 * Math.sin(ph * Math.PI);
      });
    };
    pulse(reabs, 1);
    pulse(secreted, -1);
  });
  return null;
}

export function Topic10043Sim(props: SimProps) {
  const gfr = Number(props.gfr ?? 125);
  const adh = Number(props.adh ?? 0.5);
  const speed = 1;
  const filtrate = useRef<THREE.Group>(null!);
  const reabs = useRef<THREE.Group>(null!);
  const secreted = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const tubulePath = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    const add = (x: number, y: number) => pts.push(new THREE.Vector3(x, y, 0));
    add(-5.4, 3.6);
    for (let i = 1; i <= 5; i++) add(-5.4 + i * 0.6, 3.6 - i * 0.3);  // PCT
    for (let i = 1; i <= 7; i++) add(-2.4, 2.1 - i * 0.42);           // descending limb
    for (let i = 1; i <= 7; i++) add(-2.4 + 0.4, -0.84 + i * 0.4);    // ascending limb
    for (let i = 1; i <= 5; i++) add(-2.0 + i * 0.62, 1.96 - i * 0.12); // DCT
    for (let i = 1; i <= 5; i++) add(1.1, 1.36 - i * 0.55);            // collecting duct
    return pts;
  }, []);

  const tubuleTube = useMemo(
    () =>
      new THREE.Mesh(
        new THREE.TubeGeometry(new THREE.CatmullRomCurve3(tubulePath), 120, 0.17, 10, false),
        new THREE.MeshStandardMaterial({ color: "#fbbf24", roughness: 0.45 })
      ),
    [tubulePath]
  );

  const urineOut = Math.max(0.5, 1.5 - adh * 0.9) * (gfr / 125);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["GFR", `${gfr} mL/min`],
          ["Urine output", `${urineOut.toFixed(2)}× baseline`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[-1, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* glomerulus */}
        <group position={[-5.4, 3.6, 0]}>
          {Array.from({ length: 10 }).map((_, i) => {
            const a = (i / 10) * Math.PI * 2;
            return (
              <mesh key={i} position={[Math.cos(a) * 0.3, Math.sin(a) * 0.3, 0]} rotation={[0, 0, a]} castShadow>
                <torusGeometry args={[0.24, 0.1, 8, 14]} />
                <meshStandardMaterial color="#dc2626" roughness={0.4} />
              </mesh>
            );
          })}
          <mesh>
            <sphereGeometry args={[0.78, 20, 20, 0, Math.PI * 2, 0, Math.PI * 0.62]} />
            <meshStandardMaterial color="#fef3c7" transparent opacity={0.5} roughness={0.3} side={THREE.DoubleSide} />
          </mesh>
        </group>
        {/* afferent (wide) / efferent (narrow) arterioles */}
        <mesh position={[-6.5, 3.2, 0]} rotation={[0, 0, 0.6]}>
          <cylinderGeometry args={[0.14, 0.14, 1.3, 8]} />
          <meshStandardMaterial color="#ef4444" />
        </mesh>
        <mesh position={[-4.4, 3.2, 0]} rotation={[0, 0, -0.6]}>
          <cylinderGeometry args={[0.1, 0.1, 1.1, 8]} />
          <meshStandardMaterial color="#f87171" />
        </mesh>
        <primitive object={tubuleTube} />
        {/* filtrate droplets */}
        <group ref={filtrate}>
          {Array.from({ length: 12 }).map((_, i) => (
            <mesh key={i} position={tubulePath[0]} ref={(m) => { if (m) m.userData.path = tubulePath; }}>
              <sphereGeometry args={[0.12, 10, 10]} />
              <meshStandardMaterial color="#fef08a" emissive="#a16207" emissiveIntensity={0.6} />
            </mesh>
          ))}
        </group>
        <Label text="glomerulus" position={[-5.4, 5.0, 0]} size={0.4} color="#f8fafc" />
        <Label text="afferent arteriole (wide)" position={[-7.6, 2.5, 0]} size={0.28} color="#fca5a5" />
        <Label text="efferent (narrow)" position={[-3.4, 2.5, 0]} size={0.28} color="#fca5a5" />
        <Label text="proximal tubule" position={[-3.9, 3.4, 0]} size={0.3} color="#fde68a" />
        <Label text="loop of Henle" position={[-3.8, -1.2, 0]} size={0.3} color="#fde68a" />
        <Label text="distal tubule" position={[0.4, 2.3, 0]} size={0.3} color="#fde68a" />
        <Label text="collecting duct" position={[2.0, 0.2, 0]} size={0.3} color="#fde68a" />

        {/* peritubular capillary bed */}
        <mesh position={[-3.2, 0.6, -1.4]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.5, 0.5, 9, 14]} />
          <meshStandardMaterial color="#991b1b" transparent opacity={0.5} roughness={0.5} />
        </mesh>
        {/* reabsorption arrows: tubule -> blood */}
        <group ref={reabs}>
          {[-2.4, -1.4, -0.4].map((x, i) => (
            <mesh key={i} position={[x, 1.9, -0.7]} ref={(m) => { if (m) m.userData.x0 = x; }}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshBasicMaterial color="#4ade80" transparent opacity={0.6} />
            </mesh>
          ))}
        </group>
        {/* secretion: blood -> tubule */}
        <group ref={secreted}>
          {[-1.9, -0.9].map((x, i) => (
            <mesh key={i} position={[x, 2.5, -0.7]} ref={(m) => { if (m) m.userData.x0 = x; }}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshBasicMaterial color="#f472b6" transparent opacity={0.6} />
            </mesh>
          ))}
        </group>
        <Arrow from={[-1.4, 1.9, -0.7]} to={[0.4, 1.0, -1.3]} color="#4ade80" radius={0.06} />
        <Label text="reabsorption → blood" position={[-1.4, 0.9, -1.8]} size={0.3} color="#86efac" />
        <Arrow from={[-0.9, 2.5, -1.3]} to={[-2.5, 2.6, -0.7]} color="#f472b6" radius={0.06} />
        <Label text="secretion → tubule" position={[-0.9, 3.1, -1.6]} size={0.3} color="#f9a8d4" />
        <Label text={`ADH ${adh > 1 ? "high: water reabsorbed" : adh < 0.4 ? "low: dilute urine" : "moderate"}`}
          position={[3.4, 3.6, 0]} size={0.32} color="#7dd3fc" />

        <Animator filtrate={filtrate} reabs={reabs} secreted={secreted} elapsed={elapsed} gfr={gfr} speed={speed} />
      </SimCanvas>
    </div>
  );
}
