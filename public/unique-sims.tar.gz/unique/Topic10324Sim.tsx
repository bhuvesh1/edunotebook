// Psoriasis and papulosquamous disorders.
// Thick red plaques armored with silvery scales. Skin cells race to the
// surface 10× too fast and pile up — calm them with treatment.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "severity", label: "Severity", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.7, unit: "" },
  { key: "treatment", label: "Treatment", kind: "select", min: 0, max: 0, step: 1, default: "none", options: ["none", "cream", "light"] },
];

export const UNIQUE_META = {
  title: "Psoriasis: Silvery Plaques",
  blurb: "Red plaques with silvery scales — skin cells rushing up 10× too fast. Watch treatment calm them down.",
};

const N_CELLS = 18;

function Animator({
  group, plaques, cells, elapsed, severity, treatment,
}: {
  group: React.RefObject<THREE.Group>;
  plaques: React.RefObject<THREE.Group>;
  cells: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  severity: number;
  treatment: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.15;
    // treatment shrinks the plaques
    const calm = treatment === "none" ? 1 : treatment === "cream" ? 0.55 : 0.3;
    if (plaques.current) {
      plaques.current.children.forEach((p, i) => {
        const s = (0.5 + severity * 0.8) * calm * (1 + 0.06 * Math.sin(t * 2 + i * 2));
        (p as THREE.Mesh).scale.set(s, 0.5 * calm + 0.2, s * 0.85);
      });
    }
    // skin cells stream upward; treatment slows the rush
    if (cells.current) {
      const rush = treatment === "none" ? 1.4 : treatment === "cream" ? 0.7 : 0.35;
      cells.current.children.forEach((c, i) => {
        const ph = ((t * rush * 0.5 + i / N_CELLS) % 1);
        const lane = i % 3;
        c.position.set(-1.6 + lane * 1.6, 0.6 + ph * 1.6, 0.4);
        (c as THREE.Mesh).scale.setScalar(0.5 + ph * 0.7);
      });
    }
  });
  return null;
}

export function Topic10324Sim(props: SimProps) {
  const severity = Number(props.severity ?? 0.7);
  const treatment = String(props.treatment ?? "none");
  const group = useRef<THREE.Group>(null!);
  const plaques = useRef<THREE.Group>(null!);
  const cells = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const treatLabel = treatment === "none" ? "No treatment" : treatment === "cream" ? "Steroid cream" : "Light therapy";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Severity", `${Math.round(severity * 100)}%`], ["Treatment", treatLabel]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10]} target={[0, 1.7, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* skin patch */}
          <mesh position={[0, 1.0, 0]} castShadow receiveShadow>
            <boxGeometry args={[7, 1.4, 4]} />
            <meshStandardMaterial color="#f5c396" roughness={0.7} />
          </mesh>
          {/* psoriatic plaques: red base + silvery scale armor */}
          <group ref={plaques}>
            {[[-1.9, 0.2], [0, -0.5], [1.8, 0.3]].map(([x, z], i) => (
              <group key={i} position={[x, 1.75, z]}>
                <mesh scale={[1, 0.35, 0.85]} castShadow>
                  <sphereGeometry args={[0.75, 18, 12]} />
                  <meshStandardMaterial color="#dc2626" roughness={0.6} emissive="#7f1d1d" emissiveIntensity={0.5} />
                </mesh>
                {/* silvery scales: overlapping flakes */}
                {Array.from({ length: 7 }).map((_, j) => {
                  const a = (j / 7) * Math.PI * 2;
                  return (
                    <mesh key={j} position={[Math.cos(a) * 0.4, 0.28 + (j % 2) * 0.08, Math.sin(a) * 0.35]}
                      rotation={[0.4, a, 0]} castShadow>
                      <boxGeometry args={[0.3, 0.04, 0.22]} />
                      <meshStandardMaterial color="#e2e8f0" roughness={0.9} metalness={0.15} />
                    </mesh>
                  );
                })}
              </group>
            ))}
          </group>
          {/* skin cells rushing to the surface */}
          <group ref={cells}>
            {Array.from({ length: N_CELLS }).map((_, i) => (
              <mesh key={i}>
                <sphereGeometry args={[0.09, 8, 6]} />
                <meshBasicMaterial color="#fda4af" transparent opacity={0.85} />
              </mesh>
            ))}
          </group>
          {/* light therapy lamp */}
          {treatment === "light" && (
            <group position={[0, 4.2, 0]}>
              <mesh castShadow>
                <boxGeometry args={[3.5, 0.25, 1.2]} />
                <meshStandardMaterial color="#1e293b" roughness={0.4} />
              </mesh>
              <mesh position={[0, -0.2, 0]}>
                <planeGeometry args={[3.2, 1.0]} />
                <meshBasicMaterial color="#a5f3fc" transparent opacity={0.9} />
              </mesh>
            </group>
          )}
          <Label text="🔴 Red plaque" position={[-1.9, 2.7, 0.2]} size={0.5} color="#fca5a5" />
          <Label text="⬜ Silvery scales" position={[1.8, 2.7, 0.3]} size={0.5} color="#e2e8f0" />
          <Label text="Cells rush up 10× too fast" position={[-3.0, 1.4, 0.4]} size={0.45} color="#fda4af" />
          {treatment !== "none" && <Label text="✨ Treatment calming plaques" position={[0, 0.1, 0]} size={0.55} color="#86efac" />}
        </group>
        <Animator group={group} plaques={plaques} cells={cells} elapsed={elapsed} severity={severity} treatment={treatment} />
      </SimCanvas>
    </div>
  );
}
