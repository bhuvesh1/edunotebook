"use client";
// Myofunctional Appliances: Activator, Twin Block — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "appliance", label: "Appliance", kind: "select", min: 0, max: 0, step: 1, default: "Twin block", options: ["Twin block", "Activator", "Frankel"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Myofunctional Appliances: Activator, Twin Block",
  blurb: "The lower jaw is postured forward by the appliance — watch the twin-block ramps guide it into a new bite.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const mand: any = g("mandible");
    if (mand) mand.position.z = 0.55 * (0.5 + 0.5 * Math.sin(t * 1.1));
    const ramp: any = g("ramps");
    if (ramp) (ramp.material as any).emissiveIntensity = 0.3 + 0.25 * Math.sin(t * 2);
    group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
  });
  return null;
}

export function Topic10468Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const appliance = String(props.appliance ?? "Twin block");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, appliance };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Appliance", appliance],
          ["Action", "Postures mandible forward"],
          ["Use", "Growing children"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <mesh position={[0, 3.4, -0.4]}>
            <boxGeometry args={[4.4, 1, 2.4]} />
            <meshStandardMaterial color="#f1e9d2" roughness={0.5} />
          </mesh>
          <Label text="Upper jaw (fixed)" position={[-3.2, 3.4, 0]} size={0.4} />
          <group name="mandible" position={[0, 1.6, 0]}>
            <mesh>
              <boxGeometry args={[4.4, 1, 2.4]} />
              <meshStandardMaterial color="#e9e2cc" roughness={0.5} />
            </mesh>
            <Label text="Lower jaw advances" position={[3.2, 1.6, 0]} size={0.4} color="#38bdf8" />
          </group>
          <group name="ramps">
            <mesh position={[-1.4, 2.55, 0]} rotation={[0, 0, 0.5]}>
              <boxGeometry args={[1.4, 0.35, 1.6]} />
              <meshStandardMaterial color="#f472b6" emissive="#f472b6" roughness={0.5} />
            </mesh>
            <mesh position={[1.4, 2.55, 0]} rotation={[0, 0, -0.5]}>
              <boxGeometry args={[1.4, 0.35, 1.6]} />
              <meshStandardMaterial color="#f472b6" emissive="#f472b6" roughness={0.5} />
            </mesh>
          </group>
          <Arrow from={[0, 1.6, 2.2]} to={[0, 1.6, 0.9]} color="#38bdf8" />
          <Label text={appliance + " ramps"} position={[0, 3.1, 1.4]} size={0.42} color="#f472b6" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
