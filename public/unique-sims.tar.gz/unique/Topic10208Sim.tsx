// Lacrimal system — the tear drainage path: tears pool at the inner corner,
// enter the puncta → canaliculi → lacrimal sac → nasolacrimal duct → nose.
// Droplets flow along the path; a blockage slider (dacryocystitis) jams the
// sac and it swells red.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "blockage", label: "Duct blockage", kind: "slider", min: 0, max: 100, step: 5, default: 40, unit: "%" },
  { key: "labels", label: "Labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Lacrimal System",
  blurb: "Follow a tear's journey from the eye's corner down the duct to the nose — then block the duct and watch the sac swell (dacryocystitis).",
};

// the drainage path as a 3D curve
function useTearPath() {
  return useMemo(() => {
    const pts = [
      new THREE.Vector3(-0.4, 2.5, 1.9),   // inner corner (puncta)
      new THREE.Vector3(-1.4, 2.35, 1.75), // canaliculus
      new THREE.Vector3(-2.0, 1.9, 1.55),  // lacrimal sac
      new THREE.Vector3(-2.15, 0.7, 1.4),  // nasolacrimal duct
      new THREE.Vector3(-2.0, -0.9, 1.3),  // into the nose
    ];
    return new THREE.CatmullRomCurve3(pts);
  }, []);
}

function Animator({ drops, curve, elapsed, blockage }: {
  drops: React.RefObject<THREE.Group>;
  curve: THREE.CatmullRomCurve3;
  elapsed: React.RefObject<number>;
  blockage: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const limit = 1 - (blockage / 100) * 0.85; // drops can't pass the block
    if (drops.current) {
      drops.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * 0.28 + i * 0.13) % 1);
        const clamped = Math.min(ph, limit);
        const p = curve.getPoint(clamped);
        m.position.copy(p);
        m.visible = blockage < 95 || ph < limit;
      });
    }
  });
  return null;
}

export function Topic10208Sim(props: SimProps) {
  const blockage = Number(props.blockage ?? 40);
  const showLabels = String(props.labels ?? "on") === "on";
  const drops = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const curve = useTearPath();

  const tubeGeo = useMemo(() => new THREE.TubeGeometry(curve, 40, 0.14, 10, false), [curve]);
  const blocked = blockage > 60;
  const sacScale = 1 + (blockage / 100) * 0.9;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Tears draining", blockage > 85 ? "none — overflow" : `${Math.round(100 - blockage)}%`], ["Sac", blocked ? "swollen + infected ⚠" : "normal"], ["Symptom", blocked ? "epiphora (watery eye)" : "clear"]]} />
      <SimCanvas cameraPosition={[0, 2, 11]} target={[-0.8, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* face hint: eyeball + nose ridge */}
        <mesh position={[0.8, 1.8, 0]} castShadow>
          <sphereGeometry args={[1.6, 32, 24]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.35} />
        </mesh>
        <mesh position={[2.2, 1.8, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.55, 0.26, 12, 28]} />
          <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
        </mesh>
        <mesh position={[-2.2, 0.6, 1.3]} rotation={[0, 0, 0.2]}>
          <boxGeometry args={[0.9, 2.6, 1.6]} />
          <meshStandardMaterial color="#f5d0b8" roughness={0.6} />
        </mesh>

        {/* the duct tubing */}
        <mesh>
          <primitive object={tubeGeo} attach="geometry" />
          <meshStandardMaterial color="#7dd3fc" transparent opacity={0.5} roughness={0.2} />
        </mesh>
        {/* lacrimal sac — swells and reddens when blocked */}
        <mesh position={[-2.0, 1.9, 1.55]} scale={[sacScale, sacScale * 1.25, sacScale]}>
          <sphereGeometry args={[0.34, 16, 14]} />
          <meshStandardMaterial color={blocked ? "#dc2626" : "#38bdf8"} roughness={0.4} emissive={blocked ? "#7f1d1d" : "#0c4a6e"} emissiveIntensity={0.5} />
        </mesh>
        {/* blockage plug */}
        {blockage > 25 && (
          <mesh position={[-2.08, 1.15, 1.48]}>
            <sphereGeometry args={[0.16 + (blockage / 100) * 0.14, 12, 10]} />
            <meshStandardMaterial color="#78350f" roughness={1} />
          </mesh>
        )}

        {/* flowing tears */}
        <group ref={drops}>
          {Array.from({ length: 9 }).map((_, i) => (
            <mesh key={i}>
              <sphereGeometry args={[0.1, 10, 10]} />
              <meshBasicMaterial color="#7dd3fc" />
            </mesh>
          ))}
        </group>

        {/* overflowing tears down the cheek when blocked */}
        {blockage > 55 && (
          <mesh position={[-0.2, 1.1, 1.95]} rotation={[0, 0, 0.15]}>
            <cylinderGeometry args={[0.07, 0.1, 1.6, 8]} />
            <meshBasicMaterial color="#7dd3fc" transparent opacity={0.7} />
          </mesh>
        )}

        {showLabels && (
          <>
            <Label text="Puncta (tear entry)" position={[-0.4, 3.4, 1.9]} size={0.45} color="#7dd3fc" />
            <Label text="Lacrimal sac" position={[-3.6, 2.1, 1.55]} size={0.45} color={blocked ? "#fca5a5" : "#7dd3fc"} />
            <Label text="Nasolacrimal duct → nose" position={[-2.15, -1.6, 1.4]} size={0.45} color="#7dd3fc" />
            {blocked && <Label text="Dacryocystitis — infected swollen sac ⚠" position={[-2.0, 3.3, 1.55]} size={0.48} color="#fca5a5" />}
          </>
        )}
        <Animator drops={drops} curve={curve} elapsed={elapsed} blockage={blockage} />
      </SimCanvas>
    </div>
  );
}
