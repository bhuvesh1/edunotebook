// Histology: muscle tissue, nervous tissue — striated skeletal muscle fibres
// plus a motor neuron whose myelin-sheathed axon carries a travelling
// action-potential flash to its synaptic terminals.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "conduction", label: "Conduction speed", kind: "slider", min: 0.2, max: 3, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Histology: Muscle & Nervous Tissue",
  blurb: "Striated muscle fibres beside a motor neuron — watch the action potential flash travel down the myelinated axon.",
};

function Animator({
  impulse, wavefront, muscle, elapsed, conduction, speed,
}: {
  impulse: React.RefObject<THREE.Mesh>;
  wavefront: React.RefObject<THREE.Mesh>;
  muscle: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  conduction: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // impulse travels axon from x=-2.2 to x=5.4
    const ph = ((t * 0.45 * conduction) % 1 + 1) % 1;
    const x = -2.2 + ph * 7.6;
    if (impulse.current) {
      impulse.current.position.x = x;
      const s = 0.9 + 0.25 * Math.sin(t * 20);
      impulse.current.scale.setScalar(s);
    }
    // muscle twitch: brief contraction when wave "arrives"
    if (muscle.current) {
      const tw = Math.max(0, Math.sin((t * 0.45 * conduction * Math.PI * 2) % (Math.PI * 2) - 5.6));
      muscle.current.scale.x = 1 - 0.06 * Math.max(0, tw);
    }
    if (wavefront.current) {
      (wavefront.current.material as THREE.MeshBasicMaterial).opacity = 0.25 + 0.15 * Math.sin(t * 6);
    }
  });
  return null;
}

export function Topic10017Sim(props: SimProps) {
  const conduction = Number(props.conduction ?? 1);
  const speed = Number(props.speed ?? 1);
  const impulse = useRef<THREE.Mesh>(null!);
  const wavefront = useRef<THREE.Mesh>(null!);
  const muscle = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  // striation segments for one muscle fibre
  const striae = useMemo(() => Array.from({ length: 24 }).map((_, i) => i), []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Impulse speed", `${conduction.toFixed(1)}×`],
          ["Fibre type", "skeletal, striated"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5, 15]} target={[1, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* skeletal muscle fibres: long cylinders with dark/light striation bands */}
        <group ref={muscle} position={[-3, 0, -1.2]}>
          {[-0.9, 0, 0.9].map((z, fi) => (
            <group key={fi} position={[0, 1.6, z]}>
              {striae.map((i) => (
                <mesh key={i} position={[-5.4 + i * 0.47, 0, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
                  <cylinderGeometry args={[0.34, 0.34, 0.42, 14]} />
                  <meshStandardMaterial color={i % 2 ? "#b91c1c" : "#ef4444"} roughness={0.5} />
                </mesh>
              ))}
              {/* peripheral nuclei */}
              {[-3, 0, 3].map((x, ni) => (
                <mesh key={ni} position={[x, 0.3, 0]} scale={[1.4, 0.7, 0.7]}>
                  <sphereGeometry args={[0.14, 10, 10]} />
                  <meshStandardMaterial color="#7f1d1d" />
                </mesh>
              ))}
            </group>
          ))}
        </group>
        <Label text="skeletal muscle fibre" position={[-3, 3.1, -1.2]} size={0.4} color="#f8fafc" />
        <Label text="striations" position={[-6.5, 1.1, -1.2]} size={0.3} color="#fca5a5" />

        {/* motor neuron */}
        <group position={[0, 0, 1.6]}>
          {/* dendrites */}
          {[0.5, 1.1, -0.4, 2.0, 2.6].map((a, i) => (
            <mesh key={i} position={[-3.6 + Math.cos(a) * 0.9, 1.5 + Math.sin(a) * 0.9, 0]}
              rotation={[0, 0, a + Math.PI / 2]}>
              <cylinderGeometry args={[0.06, 0.1, 1.0, 8]} />
              <meshStandardMaterial color="#fbbf24" roughness={0.5} />
            </mesh>
          ))}
          {/* cell body */}
          <mesh position={[-3.2, 1.5, 0]} castShadow>
            <sphereGeometry args={[0.55, 20, 20]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.45} />
          </mesh>
          <mesh position={[-3.2, 1.5, 0.35]}>
            <sphereGeometry args={[0.22, 12, 12]} />
            <meshStandardMaterial color="#92400e" />
          </mesh>
          {/* axon */}
          <mesh position={[1.6, 1.5, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
            <cylinderGeometry args={[0.14, 0.14, 7.8, 12]} />
            <meshStandardMaterial color="#f59e0b" roughness={0.45} />
          </mesh>
          {/* myelin sheath segments with nodes of Ranvier gaps */}
          {[-1.1, 0.5, 2.1, 3.7].map((x, i) => (
            <mesh key={i} position={[x, 1.5, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
              <capsuleGeometry args={[0.26, 1.0, 6, 12]} />
              <meshStandardMaterial color="#e0e7ff" roughness={0.35} />
            </mesh>
          ))}
          {/* axon terminals */}
          {[4.6, 5.2, 5.8].map((x, i) => (
            <mesh key={i} position={[x, 1.5 + (i - 1) * 0.35, 0]} castShadow>
              <sphereGeometry args={[0.2, 12, 12]} />
              <meshStandardMaterial color="#fbbf24" roughness={0.45} />
            </mesh>
          ))}
          {/* travelling action potential flash */}
          <mesh ref={impulse} position={[-2.2, 1.5, 0]}>
            <sphereGeometry args={[0.26, 14, 14]} />
            <meshBasicMaterial color="#fef08a" />
          </mesh>
          <mesh ref={wavefront} position={[-2.2, 1.5, 0]} visible={false}>
            <sphereGeometry args={[0.4, 12, 12]} />
            <meshBasicMaterial color="#fef08a" transparent opacity={0.3} />
          </mesh>
        </group>
        <Label text="motor neuron" position={[-3.2, 0.55, 1.6]} size={0.4} color="#f8fafc" />
        <Label text="myelin sheath" position={[0.5, 2.35, 1.6]} size={0.32} color="#e0e7ff" />
        <Label text="node of Ranvier" position={[2.9, 2.35, 1.6]} size={0.3} color="#fde68a" />
        <Label text="action potential" position={[1.6, 0.6, 1.6]} size={0.32} color="#fef08a" />
        <Arrow from={[-1.5, 1.0, 1.6]} to={[4.4, 1.0, 1.6]} color="#fbbf24" radius={0.05} />

        <Animator impulse={impulse} wavefront={wavefront} muscle={muscle} elapsed={elapsed} conduction={conduction} speed={speed} />
      </SimCanvas>
    </div>
  );
}
