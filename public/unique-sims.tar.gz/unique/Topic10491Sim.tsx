"use client";
// Gum Disease and Whole-Body Health — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Focus link", kind: "select", min: 0, max: 0, step: 1, default: "Heart (CVD)", options: ["Heart (CVD)", "Diabetes", "Pregnancy"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Gum Disease and Whole-Body Health",
  blurb: "An inflamed tooth sends inflammatory signals streaming to the heart, pancreas and beyond.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const orbs = [["orbHeart", "Heart (CVD)"], ["orbDia", "Diabetes"], ["orbPreg", "Pregnancy"]];
    orbs.forEach(([nm]: any, i: number) => {
      const o: any = g(nm);
      if (o) {
        const focus = p.cond === orbs[i][1];
        o.scale.setScalar(focus ? 1.15 + 0.06 * Math.sin(t * 4) : 0.95);
      }
    });
    for (let i = 0; i < 9; i++) {
      const s: any = g("sig" + i);
      if (s) {
        const target = i % 3;
        const tx = [-3.4, 0, 3.4][target];
        const ph = (t * 0.5 + i / 9) % 1;
        s.position.set(tx * ph, 1.2 + ph * 1.6, 0);
        s.scale.setScalar(0.09);
        (s.material as any).opacity = 0.9 * (1 - ph * 0.5);
      }
    }
    const inf: any = g("inflamed");
    if (inf) inf.rotation.z = 0.06 * Math.sin(t * 4);
  });
  return null;
}

export function Topic10491Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const cond = String(props.cond ?? "Heart (CVD)");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, cond };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Heart link", "↑ CVD risk"],
          ["Diabetes link", "Two-way worsening"],
          ["Pregnancy link", "↑ preterm risk"],
          ["Focused", cond],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <group name="inflamed" position={[0, 1.1, 0]}>
            <Tooth scale={1.4} infected />
            <mesh position={[0, 0.75, 0]}>
              <boxGeometry args={[2.8, 0.8, 2]} />
              <meshStandardMaterial color="#c94f5e" roughness={0.6} />
            </mesh>
          </group>
          <Label text="Inflamed gum" position={[0, -0.3, 0]} size={0.42} color="#ef4444" />
          <group name="orbHeart" position={[-3.4, 3.2, 0]}>
            <mesh>
              <sphereGeometry args={[0.65, 16, 16]} />
              <meshStandardMaterial color="#ef4444" roughness={0.35} />
            </mesh>
            <mesh position={[0.18, 0.45, 0]}>
              <sphereGeometry args={[0.4, 14, 14]} />
              <meshStandardMaterial color="#ef4444" roughness={0.35} />
            </mesh>
            <mesh position={[-0.18, 0.45, 0]}>
              <sphereGeometry args={[0.4, 14, 14]} />
              <meshStandardMaterial color="#ef4444" roughness={0.35} />
            </mesh>
            <Label text="Heart — CVD" position={[0, 1.35, 0]} size={0.42} color="#ef4444" />
          </group>
          <group name="orbDia" position={[0, 3.6, 0]}>
            <mesh>
              <sphereGeometry args={[0.6, 16, 16]} />
              <meshStandardMaterial color="#38bdf8" roughness={0.35} />
            </mesh>
            <mesh position={[0, 0.1, 0.45]}>
              <coneGeometry args={[0.22, 0.5, 12]} />
              <meshStandardMaterial color="#e0f2fe" roughness={0.3} />
            </mesh>
            <Label text="Diabetes" position={[0, 1.3, 0]} size={0.42} color="#38bdf8" />
          </group>
          <group name="orbPreg" position={[3.4, 3.2, 0]}>
            <mesh>
              <sphereGeometry args={[0.6, 16, 16]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.35} />
            </mesh>
            <mesh position={[0, -0.15, 0.4]}>
              <sphereGeometry args={[0.3, 12, 12]} />
              <meshStandardMaterial color="#f472b6" roughness={0.35} />
            </mesh>
            <Label text="Pregnancy" position={[0, 1.3, 0]} size={0.42} color="#f9a8d4" />
          </group>
          {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <mesh key={i} name={"sig" + i}>
              <sphereGeometry args={[1, 8, 8]} />
              <meshStandardMaterial color="#fb7185" emissive="#fb7185" emissiveIntensity={0.6} transparent opacity={0.9} />
            </mesh>
          ))}
          <Label text="Inflammatory signals" position={[0, 2.4, 0]} size={0.4} color="#fb7185" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
