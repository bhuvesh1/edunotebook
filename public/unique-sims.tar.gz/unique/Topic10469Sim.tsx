"use client";
// Fixed Appliances: Brackets, Bands, Archwires — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stiffness", label: "Wire stiffness", kind: "slider", min: 0.2, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Fixed Appliances: Brackets, Bands, Archwires",
  blurb: "Every tooth wears a bracket, one springy archwire runs through them all — feel it vibrate as it straightens teeth.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const wire: any = g("archwire");
    if (wire) wire.position.y = 1.75 + 0.05 * Math.sin(t * 9) * p.stiffness;
    const band: any = g("molarband");
    if (band) band.rotation.y = t * 0.6;
    group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
  });
  return null;
}

export function Topic10469Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const stiffness = Number(props.stiffness ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, stiffness };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Brackets", "5 bonded"],
          ["Archwire", "NiTi, continuous"],
          ["Wire stiffness", `${stiffness.toFixed(1)}×`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          {[-2.4, -1.2, 0, 1.2, 2.4].map((x, i) => (
            <group key={i} position={[x, 1.2, 0]}>
              <mesh>
                <boxGeometry args={[1, 1.6, 1]} />
                <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
              </mesh>
              <mesh position={[0, 0.15, 0.55]}>
                <boxGeometry args={[0.34, 0.34, 0.2]} />
                <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
              </mesh>
              <mesh position={[0, 0.15, 0.62]}>
                <boxGeometry args={[0.36, 0.1, 0.06]} />
                <meshStandardMaterial color="#64748b" metalness={0.85} roughness={0.3} />
              </mesh>
            </group>
          ))}
          <mesh name="molarband" position={[3.4, 1.2, 0]} rotation={[0, 0, 0]}>
            <torusGeometry args={[0.62, 0.09, 10, 20]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
          </mesh>
          <group name="archwire" position={[0, 1.75, 0]}>
            <Wire points={[[-3.4, 0, 0.62], [-1.2, 0, 0.68], [1.2, 0, 0.68], [3.4, 0, 0.62]]} color="#e2e8f0" radius={0.05} />
          </group>
          <GumSlab position={[0, 0.1, -0.3]} scale={1.25} />
          <Label text="Bracket" position={[-2.4, 2.9, 0.6]} size={0.42} />
          <Label text="Archwire" position={[0, 2.7, 0.7]} size={0.42} color="#e2e8f0" />
          <Label text="Molar band" position={[3.4, 2.6, 0]} size={0.42} />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
