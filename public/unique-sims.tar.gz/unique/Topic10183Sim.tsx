"use client";
// Disaster management, biomedical waste management.
// An emergency kit beside three colour-coded biomedical waste bins —
// pick the waste type and its bin lid flips open to receive it.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "waste", label: "Waste type", kind: "select", min: 0, max: 0, step: 1, default: "infectious", options: ["infectious", "sharps", "general"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Disaster Kit & Biomedical Waste Bins",
  blurb: "The emergency kit stands ready while each colour-coded bin opens for its own waste — red, yellow or blue, never mixed.",
};

const WASTE: Record<string, { color: string; bin: string; item: string }> = {
  infectious: { color: "#ef4444", bin: "RED bin", item: "soiled dressings" },
  sharps: { color: "#fbbf24", bin: "YELLOW bin", item: "needles & blades" },
  general: { color: "#38bdf8", bin: "BLUE bin", item: "paper & packaging" },
};

function Animator({ lids, item, elapsed, speed, waste }: { lids: React.RefObject<THREE.Group>; item: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; speed: number; waste: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const order = ["infectious", "sharps", "general"];
    if (lids.current) {
      lids.current.children.forEach((lid, i) => {
        const open = order[i] === waste;
        const target = open ? -1.1 : 0;
        lid.rotation.z += (target - lid.rotation.z) * 0.1;
      });
    }
    if (item.current) {
      const t = (elapsed.current * 0.7) % 1;
      const xs = { infectious: -3.2, sharps: 0, general: 3.2 } as Record<string, number>;
      item.current.position.set(xs[waste] ?? 0, 4.4 - t * 3.1, 0);
      item.current.visible = t < 0.92;
    }
  });
  return null;
}

export function Topic10183Sim(props: SimProps) {
  const waste = String(props.waste ?? "infectious");
  const speed = Number(props.speed ?? 1);
  const lids = useRef<THREE.Group>(null!);
  const item = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const info = WASTE[waste] ?? WASTE.infectious;
  const order = ["infectious", "sharps", "general"];

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Waste", info.item], ["Goes in", info.bin]]} />
      <SimCanvas cameraPosition={[0, 3.8, 14]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* emergency kit */}
        <group position={[-5.6, 0, -2.5]}>
          <mesh position={[0, 0.9, 0]} castShadow>
            <boxGeometry args={[2.6, 1.6, 1.8]} />
            <meshStandardMaterial color="#dc2626" roughness={0.6} />
          </mesh>
          <mesh position={[0, 1.85, 0]}>
            <torusGeometry args={[0.5, 0.12, 8, 18, Math.PI]} />
            <meshStandardMaterial color="#7f1d1d" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.95, 0.92]}>
            <boxGeometry args={[0.9, 0.28, 0.06]} />
            <meshStandardMaterial color="#ffffff" roughness={0.5} />
          </mesh>
          <mesh position={[0, 0.95, 0.92]}>
            <boxGeometry args={[0.28, 0.9, 0.06]} />
            <meshStandardMaterial color="#ffffff" roughness={0.5} />
          </mesh>
          <Label text="⛑ EMERGENCY KIT" position={[0, 2.9, 0]} size={0.6} color="#f87171" />
        </group>
        {/* three bins */}
        {order.map((k, i) => (
          <group key={k} position={[(i - 1) * 3.2, 0, 0]}>
            <mesh position={[0, 1, 0]} castShadow>
              <cylinderGeometry args={[0.85, 0.7, 1.9, 14]} />
              <meshStandardMaterial color={WASTE[k].color} roughness={0.65} />
            </mesh>
            <Label text={WASTE[k].bin} position={[0, 0.25, 0]} size={0.5} color="#f8fafc" />
          </group>
        ))}
        {/* lids as one group for the animator */}
        <group ref={lids} position={[0, 0, 0]}>
          {order.map((k, i) => (
            <group key={k} position={[(i - 1) * 3.2 + 0.85, 2.05, 0]}>
              <mesh position={[-0.85, 0, 0]}>
                <cylinderGeometry args={[0.92, 0.92, 0.14, 14]} />
                <meshStandardMaterial color="#1e293b" roughness={0.6} />
              </mesh>
            </group>
          ))}
        </group>
        {/* falling waste item */}
        <mesh ref={item} position={[0, 4.4, 0]} castShadow>
          <boxGeometry args={[0.5, 0.5, 0.5]} />
          <meshStandardMaterial color={info.color} emissive={info.color} emissiveIntensity={0.5} roughness={0.6} />
        </mesh>
        <Label text="BIOMEDICAL WASTE SEGREGATION" position={[0, 5.8, 0]} size={0.65} color="#93c5fd" />
        <Animator lids={lids} item={item} elapsed={elapsed} speed={speed} waste={waste} />
      </SimCanvas>
    </div>
  );
}
