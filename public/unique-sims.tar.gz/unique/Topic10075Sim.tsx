"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Minerals: Iron, Calcium & Trace Elements",
  blurb: "A calcium bone column, iron-rich red cells in orbit, and a ring of essential trace elements.",
};

const TRACE: [string, string][] = [["Zn","#a3e635"],["Mg","#4ade80"],["Se","#facc15"],["I","#c084fc"],["Cu","#fb923c"],["F","#38bdf8"]];

function Animator({ root, rbc, trace, elapsed, speed }: { root: RefObject<THREE.Group>; rbc: RefObject<THREE.Group>; trace: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (rbc.current) {
      rbc.current.children.forEach((m, i) => {
        const a = t * 0.5 + (i / 8) * Math.PI * 2;
        m.position.set(Math.cos(a) * 3, 1.9 + Math.sin(t * 1.6 + i) * 0.25, Math.sin(a) * 3);
        m.rotation.y = a;
      });
    }
    if (trace.current) trace.current.rotation.y = -t * 0.25;
  });
  return null;
}

export function Topic10075Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const rbc = useRef<THREE.Group>(null!);
  const trace = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Ca\u00b2\u207a", "bone \u00b7 teeth"],
          ["Fe\u00b2\u207a", "hemoglobin in RBC"],
          ["Trace", "Zn \u00b7 Mg \u00b7 Se \u00b7 I \u00b7 Cu \u00b7 F"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          {Array.from({ length: 5 }).map((_, i) => (
            <mesh key={i} position={[0, 0.7 + i * 0.62, 0]} castShadow>
              <cylinderGeometry args={[0.55, 0.55, 0.5, 14]} /><meshStandardMaterial color="#f8fafc" roughness={0.55} />
            </mesh>
          ))}
          <Label text="Ca\u00b2\u207a \u2014 bone" position={[0, 4.3, 0]} color="#f8fafc" />
          <group ref={rbc}>
            {Array.from({ length: 8 }).map((_, i) => (
              <mesh key={i} scale={[1, 0.45, 1]}>
                <sphereGeometry args={[0.34, 16, 16]} />
                <meshStandardMaterial color="#dc2626" emissive="#7f1d1d" emissiveIntensity={0.5} roughness={0.5} />
              </mesh>
            ))}
          </group>
          <Label text="Fe\u00b2\u207a \u2014 hemoglobin" position={[3.6, 3.1, 0]} size={0.42} color="#f87171" />
          <group ref={trace}>
            {TRACE.map(([name, color], i) => {
              const a = (i / 6) * Math.PI * 2;
              return (
                <group key={name} position={[Math.cos(a) * 4.6, 1.6, Math.sin(a) * 4.6]}>
                  <mesh castShadow><sphereGeometry args={[0.26, 14, 14]} /><meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} /></mesh>
                  <Label text={name} position={[0, 0.55, 0]} size={0.4} color={color} />
                </group>
              );
            })}
          </group>
          <Label text="trace elements" position={[-4.9, 0.6, 0]} size={0.42} color="#94a3b8" />
        </group>
        <Animator root={root} rbc={rbc} trace={trace} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
