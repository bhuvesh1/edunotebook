"use client";

// Medical emergencies in the dental office.
// Syncope, anaphylaxis and asthma each need a different first
// response — the 3D scene rehearses the right move for each.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "emergency", label: "Emergency", kind: "select", min: 0, max: 0, step: 1, default: "syncope", options: ["syncope", "anaphylaxis", "asthma"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Medical Emergencies in the Dental Office",
  blurb: "Syncope, anaphylaxis or asthma — rehearse the correct first response for each emergency in the dental chair.",
};

type P = [number, number, number];
type Ref = { current: THREE.Group | null };

const FACE: P = [-0.85, 1.75, 0];

function Animator({ back, injector, inhaler, mask, beacon, elapsed, emergency, speed }: {
  back: Ref; injector: Ref; inhaler: Ref; mask: Ref; beacon: { current: THREE.Mesh | null };
  elapsed: { current: number }; emergency: string; speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const e = elapsed.current;
    // backrest: flat for syncope, reclined otherwise
    if (back.current) {
      const target = emergency === "syncope" ? -0.06 : -0.55;
      back.current.rotation.z += (target - back.current.rotation.z) * Math.min(1, delta * 2);
    }
    // adrenaline auto-injector pulses for anaphylaxis
    if (injector.current) {
      const s = emergency === "anaphylaxis" ? 1 + 0.15 * Math.sin(e * 6) : 1;
      injector.current.scale.set(s, s, s);
      injector.current.visible = emergency === "anaphylaxis";
    }
    // inhaler + oxygen mask fly to the face for asthma
    const asthma = emergency === "asthma";
    if (inhaler.current) {
      const t: P = asthma ? [FACE[0] - 0.15, FACE[1] - 0.1, 0.35] : [2.2, 1.55, 0.2];
      inhaler.current.position.lerp(new THREE.Vector3(...t), Math.min(1, delta * 2));
    }
    if (mask.current) {
      const t: P = asthma ? [FACE[0], FACE[1], 0.18] : [2.95, 1.35, -0.55];
      mask.current.position.lerp(new THREE.Vector3(...t), Math.min(1, delta * 2));
    }
    // beacon flashes
    if (beacon.current) {
      const mat = beacon.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = 0.6 + 0.6 * Math.abs(Math.sin(e * 5));
    }
  });
  return null;
}

export function Topic10561Sim(props: SimProps) {
  const emergency = String(props.emergency ?? "syncope");
  const speed = Number(props.speed ?? 1);

  const back = useRef<THREE.Group>(null!);
  const injector = useRef<THREE.Group>(null!);
  const inhaler = useRef<THREE.Group>(null!);
  const mask = useRef<THREE.Group>(null!);
  const beacon = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const actions: Record<string, string> = {
    syncope: "Lay the chair flat, raise the legs, give air",
    anaphylaxis: "Adrenaline IM at once, call emergency services",
    asthma: "Stop treatment — inhaler + oxygen, sit upright",
  };
  const names: Record<string, string> = {
    syncope: "Syncope (faint)",
    anaphylaxis: "Anaphylaxis",
    asthma: "Asthma attack",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Emergency", names[emergency]],
          ["First response", actions[emergency]],
        ]}
      />
      <SimCanvas cameraPosition={[6.5, 4.5, 10]} target={[0.3, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* dental chair */}
        <mesh position={[0.2, 0.45, 0]} castShadow>
          <boxGeometry args={[0.9, 0.9, 0.9]} />
          <meshStandardMaterial color="#475569" roughness={0.6} />
        </mesh>
        <mesh position={[0.35, 1.02, 0]} castShadow>
          <boxGeometry args={[1.9, 0.26, 1.1]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.5} />
        </mesh>
        <group ref={back} position={[-0.6, 1.1, 0]} rotation={[0, 0, -0.55]}>
          <mesh position={[-0.75, 0, 0]} castShadow>
            <boxGeometry args={[1.5, 0.26, 1.1]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.5} />
          </mesh>
          <mesh position={[-1.65, 0.15, 0]}>
            <boxGeometry args={[0.45, 0.35, 0.8]} />
            <meshStandardMaterial color="#0ea5e9" roughness={0.5} />
          </mesh>
        </group>

        {/* patient */}
        <mesh position={[0.35, 1.42, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.3, 0.3, 1.7, 14]} />
          <meshStandardMaterial color="#eab88f" roughness={0.7} />
        </mesh>
        <mesh position={FACE} castShadow>
          <sphereGeometry args={[0.3, 18, 18]} />
          <meshStandardMaterial color="#eab88f" roughness={0.7} />
        </mesh>

        {/* emergency kit with red cross */}
        <group position={[2.2, 0, 0]}>
          <mesh position={[0, 1.05, 0]} castShadow>
            <boxGeometry args={[0.95, 0.6, 0.6]} />
            <meshStandardMaterial color="#dc2626" roughness={0.5} />
          </mesh>
          <mesh position={[0, 1.05, 0.31]}>
            <boxGeometry args={[0.4, 0.13, 0.03]} />
            <meshStandardMaterial color="#f8fafc" />
          </mesh>
          <mesh position={[0, 1.05, 0.31]}>
            <boxGeometry args={[0.13, 0.4, 0.03]} />
            <meshStandardMaterial color="#f8fafc" />
          </mesh>
          <mesh position={[0, 0.35, 0]} castShadow>
            <boxGeometry args={[1.1, 0.7, 0.7]} />
            <meshStandardMaterial color="#64748b" roughness={0.7} />
          </mesh>
        </group>

        {/* adrenaline auto-injector */}
        <group ref={injector} position={[2.2, 1.75, 0.45]} visible={false}>
          <mesh castShadow>
            <cylinderGeometry args={[0.09, 0.09, 0.55, 12]} />
            <meshStandardMaterial color="#f97316" roughness={0.4} />
          </mesh>
          <mesh position={[0, -0.35, 0]}>
            <coneGeometry args={[0.09, 0.16, 12]} />
            <meshStandardMaterial color="#1e293b" roughness={0.4} />
          </mesh>
        </group>

        {/* inhaler */}
        <group ref={inhaler} position={[2.2, 1.55, 0.2]}>
          <mesh castShadow>
            <boxGeometry args={[0.16, 0.42, 0.16]} />
            <meshStandardMaterial color="#2563eb" roughness={0.4} />
          </mesh>
          <mesh position={[0.1, 0.14, 0]}>
            <boxGeometry args={[0.24, 0.12, 0.14]} />
            <meshStandardMaterial color="#93c5fd" roughness={0.4} />
          </mesh>
        </group>

        {/* oxygen tank + mask */}
        <mesh position={[2.95, 0.85, -0.9]} castShadow>
          <cylinderGeometry args={[0.32, 0.32, 1.4, 16]} />
          <meshStandardMaterial color="#16a34a" roughness={0.45} metalness={0.3} />
        </mesh>
        <group ref={mask} position={[2.95, 1.35, -0.55]}>
          <mesh rotation={[0, 0, 0.6]}>
            <coneGeometry args={[0.22, 0.3, 14, 1, true]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.5} side={THREE.DoubleSide} />
          </mesh>
        </group>

        {/* flashing beacon */}
        <mesh position={[-2.6, 1.1, 0]} castShadow>
          <cylinderGeometry args={[0.08, 0.12, 2.2, 10]} />
          <meshStandardMaterial color="#475569" roughness={0.6} />
        </mesh>
        <mesh ref={beacon} position={[-2.6, 2.35, 0]}>
          <sphereGeometry args={[0.2, 14, 14]} />
          <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={1} />
        </mesh>

        <Label text={actions[emergency]} position={[0.3, 3.6, 0]} size={0.5} color="#fbbf24" />
        <Label text="emergency kit" position={[2.2, 0.15, 0.9]} size={0.4} color="#fca5a5" />
        <Label text="oxygen" position={[2.95, 0.05, -0.9]} size={0.4} color="#86efac" />
        <Animator back={back} injector={injector} inhaler={inhaler} mask={mask} beacon={beacon} elapsed={elapsed} emergency={emergency} speed={speed} />
      </SimCanvas>
    </div>
  );
}
