// Infectious diseases — HIV/AIDS, malaria, dengue, typhoid. A pathogen
// gallery: the HIV spiky ball, the malaria parasite bursting a red cell,
// the dengue mosquito, and typhoid's rod bacteria. Select one to spotlight
// it; each animates in its own way.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "bug", label: "Pathogen", kind: "select", min: 0, max: 0, step: 1, default: "HIV", options: ["HIV", "malaria", "dengue mosquito", "typhoid"] },
  { key: "load", label: "Pathogen load", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
];

export const UNIQUE_META = {
  title: "HIV, Malaria, Dengue, Typhoid",
  blurb: "Meet the culprits up close: spiky HIV, malaria bursting red cells, the dengue mosquito, and typhoid rods — load slider multiplies them.",
};

function Animator({ stage, elapsed, bug }: {
  stage: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  bug: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (stage.current) {
      stage.current.rotation.y = t * 0.35;
      stage.current.children.forEach((c, i) => {
        if (bug === "malaria") {
          // parasites pulse as they burst out
          c.scale.setScalar(1 + 0.15 * Math.sin(t * 5 + i * 1.9));
        }
        if (bug === "dengue mosquito") {
          // wings buzz
          if (i > 2) c.rotation.z = Math.sin(t * 40 + i) * 0.5;
        }
      });
    }
  });
  return null;
}

export function Topic10237Sim(props: SimProps) {
  const bug = String(props.bug ?? "HIV");
  const load = Number(props.load ?? 55);
  const stage = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const n = Math.max(1, Math.round((load / 100) * 9));

  const spikes = useMemo(() => {
    return Array.from({ length: 26 }).map((_, i) => {
      const a = (i * 2.4) % (Math.PI * 2);
      const b = ((i * 1.3) % Math.PI) - Math.PI / 2;
      return { x: Math.cos(a) * Math.cos(b), y: Math.sin(b), z: Math.sin(a) * Math.cos(b) };
    });
  }, []);

  const facts: Record<string, string> = {
    HIV: "HIV kills CD4 cells → AIDS · ART controls it",
    malaria: "Plasmodium bursts red cells → cyclical fever",
    "dengue mosquito": "Aedes bite → breakbone fever, low platelets",
    typhoid: "Salmonella Typhi → contaminated food/water",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Pathogen", bug], ["Load", `${load}%`], ["Key fact", facts[bug]]]} />
      <SimCanvas cameraPosition={[0, 2.4, 11]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={stage} position={[0, 2.2, 0]}>
          {bug === "HIV" && (
            <group>
              <mesh castShadow>
                <sphereGeometry args={[1.1, 26, 20]} />
                <meshStandardMaterial color="#8b5cf6" roughness={0.5} />
              </mesh>
              {spikes.map((s, i) => (
                <mesh key={i} position={[s.x * 1.35, s.y * 1.35, s.z * 1.35]} rotation={[0, 0, Math.atan2(s.y, s.x)]}>
                  <coneGeometry args={[0.09, 0.55, 8]} />
                  <meshStandardMaterial color="#c4b5fd" roughness={0.4} emissive="#5b21b6" emissiveIntensity={0.4} />
                </mesh>
              ))}
              <Label text="HIV — spiky virus" position={[0, 2.3, 0]} size={0.55} color="#c4b5fd" />
            </group>
          )}
          {bug === "malaria" && (
            <group>
              <mesh scale={[1, 0.45, 1]} castShadow>
                <sphereGeometry args={[1.3, 24, 18]} />
                <meshStandardMaterial color="#dc2626" roughness={0.45} transparent opacity={0.85} />
              </mesh>
              {Array.from({ length: n }).map((_, i) => (
                <mesh key={i} position={[Math.cos(i * 2.4) * 1.5, Math.sin(i * 2.4) * 0.7, Math.sin(i * 1.7) * 1.2]}>
                  <dodecahedronGeometry args={[0.22, 0]} />
                  <meshStandardMaterial color="#facc15" roughness={0.5} emissive="#a16207" emissiveIntensity={0.5} flatShading />
                </mesh>
              ))}
              <Label text="Malaria parasites bursting a red cell" position={[0, 2.3, 0]} size={0.55} color="#fde047" />
            </group>
          )}
          {bug === "dengue mosquito" && (
            <group>
              <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
                <capsuleGeometry args={[0.32, 1.4, 8, 14]} />
                <meshStandardMaterial color="#1c1917" roughness={0.6} />
              </mesh>
              {[0.3, -0.3].map((z, i) => (
                <mesh key={i} position={[0, 0.5, z]} rotation={[0.5, 0, 0]}>
                  <boxGeometry args={[1.6, 0.06, 0.7]} />
                  <meshStandardMaterial color="#a8a29e" transparent opacity={0.7} roughness={0.4} />
                </mesh>
              ))}
              {Array.from({ length: 6 }).map((_, i) => (
                <mesh key={`l${i}`} position={[(i % 3 - 1) * 0.4, -0.4, (i < 3 ? -1 : 1) * 0.3]} rotation={[0.4, 0, (i % 3 - 1) * 0.5]}>
                  <cylinderGeometry args={[0.03, 0.03, 0.9, 6]} />
                  <meshStandardMaterial color="#1c1917" roughness={0.7} />
                </mesh>
              ))}
              <Label text="Aedes mosquito — dengue vector" position={[0, 2.3, 0]} size={0.55} color="#e7e5e4" />
            </group>
          )}
          {bug === "typhoid" && (
            <group>
              {Array.from({ length: n }).map((_, i) => (
                <mesh key={i} position={[Math.cos(i * 2.2) * 1.4, Math.sin(i * 1.9) * 1.2, Math.sin(i * 2.6) * 1.4]} rotation={[i, i * 1.3, 0]} castShadow>
                  <capsuleGeometry args={[0.22, 0.9, 6, 12]} />
                  <meshStandardMaterial color="#4ade80" roughness={0.5} emissive="#14532d" emissiveIntensity={0.3} />
                </mesh>
              ))}
              <Label text="Salmonella Typhi rods" position={[0, 2.3, 0]} size={0.55} color="#86efac" />
            </group>
          )}
        </group>

        <Label text={facts[bug]} position={[0, -1.2, 0]} size={0.46} color="#fde047" />
        <Animator stage={stage} elapsed={elapsed} bug={bug} />
      </SimCanvas>
    </div>
  );
}
