// Upper limb fractures: clavicle, humerus, forearm, Colles', hand injuries.
// The arm skeleton with the classic break points. Colles' fracture shows its
// famous "dinner fork" deformity at the wrist.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "site", label: "Fracture site", kind: "select", min: 0, max: 0, step: 1, default: "colles", options: ["clavicle", "humerus", "forearm", "colles", "hand"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Arm Fractures: Collarbone to Wrist",
  blurb: "The arm's break points — collarbone, humerus, forearm, the dinner-fork wrist of Colles', and hand bones.",
};

const SITES: Record<string, { pos: [number, number, number]; label: string; note: string }> = {
  clavicle: { pos: [-1.15, 4.35, 0.3], label: "Clavicle (collarbone)", note: "Falls on the shoulder — most common" },
  humerus: { pos: [-1.9, 3.3, 0], label: "Humerus shaft", note: "Watch the radial nerve!" },
  forearm: { pos: [-1.9, 2.1, 0], label: "Radius + ulna", note: "Both bones often break together" },
  colles: { pos: [-1.9, 1.25, 0], label: "Colles' fracture", note: "Dinner-fork deformity at wrist" },
  hand: { pos: [-1.9, 0.45, 0.15], label: "Hand (metacarpal)", note: "Boxer's fracture of the 5th" },
};

function Animator({
  group, marker, frag, elapsed, speed, site,
}: {
  group: React.RefObject<THREE.Group>;
  marker: React.RefObject<THREE.Mesh>;
  frag: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  site: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    if (marker.current) {
      marker.current.position.set(...SITES[site].pos);
      marker.current.scale.setScalar(1 + 0.3 * Math.sin(t * 5));
    }
    // Colles': wrist fragment tilts into the fork deformity
    if (frag.current) {
      frag.current.visible = site === "colles";
      const tilt = site === "colles" ? 0.5 + 0.12 * Math.sin(t * 1.5) : 0;
      frag.current.rotation.z = tilt;
    }
  });
  return null;
}

function Bone({ length, r = 0.16 }: { length: number; r?: number }) {
  return (
    <mesh castShadow>
      <cylinderGeometry args={[r, r * 1.1, length, 14]} />
      <meshStandardMaterial color="#f8fafc" roughness={0.5} />
    </mesh>
  );
}

export function Topic10296Sim(props: SimProps) {
  const site = String(props.site ?? "colles");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const marker = useRef<THREE.Mesh>(null!);
  const frag = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Site", SITES[site].label], ["Note", SITES[site].note], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10.5]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* shoulder + clavicle */}
          <mesh position={[0, 4.5, 0]} castShadow>
            <sphereGeometry args={[0.55, 18, 14]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <group position={[-0.65, 4.35, 0.3]} rotation={[0, 0.3, 0.08]}>
            <group rotation={[0, 0, Math.PI / 2]}>
              <Bone length={1.5} r={0.11} />
            </group>
          </group>
          {/* humerus */}
          <group position={[-1.9, 3.35, 0]}>
            <Bone length={1.9} r={0.17} />
          </group>
          {/* elbow */}
          <mesh position={[-1.9, 2.35, 0]} castShadow>
            <sphereGeometry args={[0.24, 14, 10]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          {/* radius + ulna */}
          <group position={[-2.05, 1.7, 0.12]}>
            <Bone length={1.3} r={0.12} />
          </group>
          <group position={[-1.75, 1.7, -0.12]}>
            <Bone length={1.3} r={0.1} />
          </group>
          {/* wrist fragment that tilts (Colles') */}
          <group ref={frag} position={[-1.9, 1.25, 0]} visible={false}>
            <group position={[0, -0.28, 0]}>
              <Bone length={0.55} r={0.13} />
            </group>
          </group>
          {/* hand: palm + fingers hint */}
          <group position={[-1.9, 0.5, 0.1]}>
            <mesh castShadow>
              <boxGeometry args={[0.5, 0.6, 0.18]} />
              <meshStandardMaterial color="#f8fafc" roughness={0.5} />
            </mesh>
            {[-0.18, -0.06, 0.06, 0.18].map((x, i) => (
              <mesh key={i} position={[x, -0.45, 0]} castShadow>
                <cylinderGeometry args={[0.045, 0.045, 0.35, 8]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
            ))}
          </group>
          {/* pulsing fracture marker */}
          <mesh ref={marker} position={SITES[site].pos}>
            <torusGeometry args={[0.3, 0.1, 10, 18]} />
            <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={1.2} />
          </mesh>
          <Label text="Clavicle" position={[-0.4, 4.85, 0.3]} size={0.45} color="#e2e8f0" />
          <Label text="Humerus" position={[-2.75, 3.35, 0]} size={0.45} color="#e2e8f0" />
          <Label text="Radius & ulna" position={[-2.85, 1.9, 0]} size={0.45} color="#e2e8f0" />
          <Label text={SITES[site].label} position={[0.9, SITES[site].pos[1] + 0.55, 0]} size={0.55} color="#fca5a5" />
          <Label text={SITES[site].note} position={[0.9, SITES[site].pos[1] - 0.05, 0]} size={0.45} color="#fde68a" />
        </group>
        <Animator group={group} marker={marker} frag={frag} elapsed={elapsed} speed={speed} site={site} />
      </SimCanvas>
    </div>
  );
}
