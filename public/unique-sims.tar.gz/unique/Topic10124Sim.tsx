// GI drugs: the stomach churns with bubbling orange acid — an antacid tablet
// drops in and neutralizes it, calming the burn.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "acid", label: "Acid level", kind: "slider", min: 0, max: 100, step: 5, default: 70, unit: "%" },
  { key: "drug", label: "Treatment", kind: "select", min: 0, max: 0, step: 1, default: "antacid", options: ["antacid", "PPI"] },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "GI drugs: antacids & PPIs",
  blurb: "The stomach churns with bubbling acid — an antacid tablet drops in and neutralizes the burn.",
};

const N_BUB = 16;

function Animator({ bubbles, acidMesh, tablet, elapsed, acid, drug, setTick }: {
  bubbles: React.RefObject<(THREE.Mesh | null)[]>;
  acidMesh: React.RefObject<THREE.Mesh>;
  tablet: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  acid: number;
  drug: string;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    // antacid neutralizes fast, PPI suppresses production steadily
    const neutral = drug === "antacid" ? 0.75 : 0.55;
    const level = THREE.MathUtils.clamp((acid / 100) * (1 - neutral * (0.5 + 0.5 * Math.sin(t * 0.6) * 0 + 1) * 0.9), 0.05, 1);
    const lvl = THREE.MathUtils.clamp((acid / 100) - neutral * 0.55, 0.05, 1);
    void level;
    bubbles.current.forEach((b, i) => {
      if (!b) return;
      const active = ((i * 29) % 10) / 10 < lvl;
      b.visible = active;
      if (!active) return;
      const f = (t * (0.5 + lvl) + i / N_BUB) % 1;
      b.position.set(Math.sin(i * 2.3) * 0.9, 0.7 + f * 1.3, Math.cos(i * 1.7) * 0.6);
      const s = 0.5 + f * 0.9;
      b.scale.setScalar(0.06 + s * 0.1);
      const m = b.material as THREE.MeshStandardMaterial;
      m.color.set(lvl > 0.5 ? "#fb923c" : "#a7f3d0");
      m.emissive.set(m.color.getHex());
    });
    if (acidMesh.current) {
      const am = acidMesh.current.material as THREE.MeshStandardMaterial;
      am.color.set(lvl > 0.5 ? "#c2410c" : "#6ee7b7");
      am.emissive.set(am.color.getHex());
      am.emissiveIntensity = 0.25 + lvl * 0.5;
    }
    if (tablet.current) {
      // tablet drops in, dissolves, respawns
      const f = (t * 0.25) % 1;
      tablet.current.position.y = 4.2 - f * 3.4;
      const ds = Math.max(0.05, 1 - Math.max(0, f - 0.55) * 2.2);
      tablet.current.scale.setScalar(ds);
      tablet.current.rotation.y = t * 2;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(lvl * 100)); }
  });
  return null;
}

export function Topic10124Sim(props: SimProps) {
  const acid = Number(props.acid ?? 70);
  const drug = String(props.drug ?? "antacid");
  const showLabels = String(props.detail ?? "on") === "on";
  const bubbles = useRef<(THREE.Mesh | null)[]>([]);
  const acidMesh = useRef<THREE.Mesh>(null!);
  const tablet = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const ph = (1.5 + (1 - tick / 100) * 5).toFixed(1);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stomach pH", ph],
          ["Burn", tick > 55 ? "severe" : tick > 25 ? "mild" : "soothed"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 11]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* stomach sac */}
        <mesh position={[0, 1.5, 0]} scale={[1.5, 1.15, 1]} castShadow>
          <sphereGeometry args={[1.3, 24, 18]} />
          <meshStandardMaterial color="#f4a7b9" roughness={0.55} transparent opacity={0.85} />
        </mesh>
        <mesh position={[-0.9, 2.9, 0]} rotation={[0, 0, 0.4]}>
          <cylinderGeometry args={[0.35, 0.45, 1.2, 12]} />
          <meshStandardMaterial color="#f4a7b9" roughness={0.55} />
        </mesh>
        {showLabels && <Label text="stomach" position={[0, 3.9, 0]} color="#f9a8d4" />}

        {/* acid pool */}
        <mesh ref={acidMesh} position={[0, 0.95, 0]} scale={[1.15, 0.5, 0.8]}>
          <sphereGeometry args={[1, 18, 12]} />
          <meshStandardMaterial color="#c2410c" emissive="#c2410c" emissiveIntensity={0.4} transparent opacity={0.85} />
        </mesh>

        {/* acid bubbles */}
        {Array.from({ length: N_BUB }).map((_, i) => (
          <mesh key={i} ref={(m) => { bubbles.current[i] = m; }}>
            <sphereGeometry args={[1, 10, 8]} />
            <meshStandardMaterial color="#fb923c" emissive="#fb923c" emissiveIntensity={0.9} transparent opacity={0.9} />
          </mesh>
        ))}
        {showLabels && <Label text={`gastric acid — pH ${ph}`} position={[2.4, 1.2, 0]} size={0.45} color="#fdba74" />}

        {/* antacid / PPI tablet */}
        <group ref={tablet}>
          <mesh castShadow>
            <cylinderGeometry args={[0.32, 0.32, 0.18, 20]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.3} />
          </mesh>
          <mesh position={[0, 0.1, 0]}>
            <boxGeometry args={[0.4, 0.03, 0.12]} />
            <meshStandardMaterial color={drug === "antacid" ? "#38bdf8" : "#a855f7"} />
          </mesh>
        </group>
        {showLabels && <Label text={drug === "antacid" ? "antacid tablet" : "PPI capsule"} position={[-2.6, 4.4, 0]} size={0.45} color="#7dd3fc" />}

        <Animator bubbles={bubbles} acidMesh={acidMesh} tablet={tablet} elapsed={elapsed} acid={acid} drug={drug} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
