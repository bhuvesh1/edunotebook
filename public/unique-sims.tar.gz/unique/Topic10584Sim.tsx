// Topic10584 — Age estimation: dental methods.
// Drag the age slider and one molar tells the life story: roots grow
// in childhood, the wisdom tooth erupts at ~18, cusps wear flat and
// the tooth darkens into old age.

"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "age", label: "Person's age", kind: "slider", min: 6, max: 60, step: 1, default: 18, unit: "yrs" },
];

export const UNIQUE_META = {
  title: "Age estimation: dental methods",
  blurb: "One tooth reveals a lifetime — roots grow, wisdom teeth erupt, cusps wear down with age.",
};

function stageFor(age: number): string {
  if (age < 9) return "Erupting molar, roots forming";
  if (age < 13) return "Roots complete, full crown";
  if (age < 20) return "Wisdom tooth erupting";
  if (age < 35) return "Adult — sharp cusps";
  if (age < 50) return "Attrition — cusps wearing flat";
  return "Heavy wear, gum recession";
}

function Animator({
  group,
  wisdom,
  elapsed,
}: {
  group: RefObject<THREE.Group>;
  wisdom: RefObject<THREE.Group>;
  elapsed: RefObject<number>;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.4) * 0.55;
    if (wisdom.current && wisdom.current.visible) {
      wisdom.current.position.y = wisdom.current.userData.baseY + Math.sin(t * 2.2) * 0.05;
    }
  });
  return null;
}

export function Topic10584Sim(props: SimProps) {
  const age = Number(props.age ?? 18);
  const group = useRef<THREE.Group>(null!);
  const wisdom = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
  const erupt = clamp01((age - 5) / 3); // tooth rises out of gum
  const rootGrow = clamp01((age - 6) / 6); // roots lengthen
  const wear = clamp01((age - 30) / 30); // cusps flatten
  const wisdomIn = clamp01((age - 17) / 2); // third molar erupts
  const recede = clamp01((age - 48) / 12); // gum recession
  const dark = clamp01((age - 25) / 35); // staining with age

  const crownH = 1.5 - wear * 0.55;
  const crownColor = new THREE.Color("#fefdf8").lerp(new THREE.Color("#b8956a"), dark * 0.75);
  const toothY = 1.4 + erupt * 1.2;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Age", `${age} yrs`],
          ["Stage", stageFor(age)],
          ["Wisdom tooth", wisdomIn > 0.9 ? "Erupted" : wisdomIn > 0 ? "Erupting" : "Not formed"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={group}>
          {/* gum bed */}
          <mesh position={[0, 0.8 - recede * 0.5, 0]}>
            <cylinderGeometry args={[2.4, 2.8, 1.0, 24]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.7} />
          </mesh>

          {/* the molar: crown */}
          <mesh position={[0, toothY + crownH / 2, 0]} castShadow>
            <cylinderGeometry args={[1.0, 0.85, crownH, 20]} />
            <meshStandardMaterial color={crownColor} roughness={0.3 + wear * 0.3} />
          </mesh>
          {/* cusps — flatten as wear grows */}
          {[-0.45, 0.45].map((x) =>
            [-0.45, 0.45].map((z) => (
              <mesh key={`${x}${z}`} position={[x, toothY + crownH + 0.12 * (1 - wear), z]} castShadow>
                <coneGeometry args={[0.28, 0.4 * (1 - wear) + 0.05, 10]} />
                <meshStandardMaterial color={crownColor} roughness={0.35} />
              </mesh>
            ))
          )}
          {/* roots — grow long in childhood */}
          {[-0.45, 0.45].map((x) => (
            <mesh key={x} position={[x, toothY - (0.4 + rootGrow * 0.9), 0]} castShadow>
              <coneGeometry args={[0.3, 0.8 + rootGrow * 1.8, 12]} />
              <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
            </mesh>
          ))}

          {/* wisdom tooth erupting behind */}
          <group
            ref={wisdom}
            position={[1.9, 1.6 + wisdomIn * 0.9, -0.4]}
            visible={wisdomIn > 0.02}
            userData={{ baseY: 1.6 + wisdomIn * 0.9 }}
          >
            <mesh castShadow>
              <cylinderGeometry args={[0.7, 0.6, 1.0 * wisdomIn + 0.15, 16]} />
              <meshStandardMaterial color="#fefdf8" roughness={0.32} />
            </mesh>
          </group>
        </group>

        <Label text={`AGE ${age} — ${stageFor(age).toUpperCase()}`} position={[0, 5.2, 0]} size={0.44} color="#fde68a" />
        <Label text={age >= 17 ? "WISDOM TOOTH (3rd molar) erupts ~18" : "WISDOM TOOTH still forming"} position={[3.4, 3.2, -0.4]} size={0.34} color={age >= 17 ? "#86efac" : "#94a3b8"} />
        <Label text={age >= 30 ? "WEAR: cusps flattening — attrition = age clue" : "ROOTS: length & apex closure = childhood age clue"} position={[0, -0.15, 0]} size={0.36} color="#e0f2fe" />

        <Animator group={group} wisdom={wisdom} elapsed={elapsed} />
      </SimCanvas>
    </div>
  );
}
