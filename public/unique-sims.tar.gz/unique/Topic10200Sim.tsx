// Cataract — types, diagnosis, surgical management. Two eyes side by side:
// a clear lens (rays converge crisply) versus a cloudy, yellowing cataract
// lens (rays scatter). Severity slider clouds the lens; the cloudy patch pulses.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "severity", label: "Cataract severity", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "labels", label: "Labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Cataract",
  blurb: "A clear lens focuses light sharply; a cataractous lens clouds over and scatters it. Drag severity to watch vision fade.",
};

function Animator({ cloudy, elapsed }: { cloudy: React.RefObject<THREE.Group>; elapsed: React.RefObject<number> }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (cloudy.current) {
      // the cataract shimmers / slowly swirls
      cloudy.current.rotation.y = t * 0.25;
      cloudy.current.children.forEach((c, i) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        if (m.transparent) m.opacity = 0.45 + 0.18 * Math.sin(t * 2 + i * 2.1);
      });
    }
  });
  return null;
}

function Eye({ x, cloudy, severity, showLabels }: { x: number; cloudy: boolean; severity: number; showLabels: boolean }) {
  const op = cloudy ? 0.25 + (severity / 100) * 0.7 : 0;
  const tint = new THREE.Color("#7dd3fc").lerp(new THREE.Color("#a3a380"), cloudy ? severity / 100 : 0);
  const retinaGlow = cloudy ? 1 - severity / 140 : 1;
  return (
    <group position={[x, 1.2, 0]}>
      <mesh castShadow>
        <sphereGeometry args={[2.0, 36, 26]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.35} />
      </mesh>
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[1.72, 28, 20, Math.PI * 0.55, Math.PI * 1.15, Math.PI * 0.25, Math.PI * 0.5]} />
        <meshStandardMaterial color="#f97316" roughness={0.6} side={THREE.DoubleSide} emissive="#7c2d12" emissiveIntensity={0.35 * retinaGlow} />
      </mesh>
      <mesh position={[1.35, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
        <torusGeometry args={[0.66, 0.3, 14, 32]} />
        <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
      </mesh>
      {/* lens: clear blue vs cloudy */}
      <mesh position={[1.0, 0, 0]} scale={[0.55, 1, 1]} castShadow>
        <sphereGeometry args={[0.6, 24, 18]} />
        <meshStandardMaterial color={cloudy ? "#b8b28a" : "#7dd3fc"} transparent={cloudy} opacity={cloudy ? 0.95 : 0.75} roughness={cloudy ? 0.9 : 0.15} />
      </mesh>
      {cloudy && (
        <group position={[1.0, 0, 0]}>
          {[-0.3, 0.05, 0.35].map((dy, i) => (
            <mesh key={i} position={[0, dy, (i - 1) * 0.3]} scale={[0.5, 0.8, 0.8]}>
              <sphereGeometry args={[0.42, 14, 12]} />
              <meshStandardMaterial color="#d6cf9f" transparent opacity={0.5 + (severity / 100) * 0.35} roughness={1} />
            </mesh>
          ))}
        </group>
      )}
      {/* light rays: crisp vs scattered */}
      {[-0.9, 0, 0.9].map((dy, i) =>
        cloudy ? (
          <group key={i}>
            {[-0.5, 0, 0.5].map((dz, j) => (
              <mesh key={j} position={[2.6, dy + dz * 0.6 - 0.2, dz * 1.4]} rotation={[0, 0, -0.5 + dz * 0.5]}>
                <cylinderGeometry args={[0.04, 0.04, 1.9, 6]} />
                <meshBasicMaterial color="#fef9c3" transparent opacity={0.35} />
              </mesh>
            ))}
          </group>
        ) : (
          <mesh key={i} position={[-1.4, dy, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.05, 0.05, 5.2, 8]} />
            <meshBasicMaterial color="#fde047" transparent opacity={0.75} />
          </mesh>
        )
      )}
      {showLabels && <Label text={cloudy ? `Cataract (${severity}%)` : "Healthy lens"} position={[0, 2.9, 0]} size={0.52} color={cloudy ? "#fca5a5" : "#86efac"} />}
    </group>
  );
}

export function Topic10200Sim(props: SimProps) {
  const severity = Number(props.severity ?? 60);
  const showLabels = String(props.labels ?? "on") === "on";
  const cloudy = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const vision = severity < 25 ? "near normal" : severity < 55 ? "hazy" : severity < 85 ? "foggy" : "near blind";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Vision with cataract", vision], ["Fix", "surgical lens replacement"]]} />
      <SimCanvas cameraPosition={[0, 1.8, 13]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group>
          <Eye x={-3.4} cloudy={false} severity={severity} showLabels={showLabels} />
        </group>
        <group ref={cloudy}>
          <Eye x={3.4} cloudy={true} severity={severity} showLabels={showLabels} />
        </group>
        {showLabels && (
          <Label text="Cataract = cloudy lens — surgery swaps in a clear artificial one" position={[0, -1.9, 0]} size={0.44} color="#94a3b8" />
        )}
        <Animator cloudy={cloudy} elapsed={elapsed} />
      </SimCanvas>
    </div>
  );
}
