// Biomolecules: carbohydrates — glucose as a Haworth hexagon ring, an amylose
// starch helix, and cellulose's straight chain; glycosidic bonds link the units.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "mol", label: "Molecule", kind: "select", min: 0, max: 0, step: 1, default: "glucose", options: ["glucose", "starch", "cellulose"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Biomolecules: Carbohydrates",
  blurb: "Glucose's hexagon ring links into starch's energy helix or cellulose's straight structural chain.",
};

const MOLS = {
  glucose: { formula: "C₆H₁₂O₆", note: "monosaccharide — instant energy" },
  starch: { formula: "(C₆H₁₀O₅)n", note: "α-1,4 helix — plant energy store" },
  cellulose: { formula: "(C₆H₁₀O₅)n", note: "β-1,4 straight chain — plant fibre" },
} as const;

// glucose Haworth ring: 5 C (grey) + 1 O (red) in a hexagon
function GlucoseRing({ position = [0, 0, 0] as [number, number, number], scale = 1 }: { position?: [number, number, number]; scale?: number }) {
  const atoms = useMemo(() => {
    const arr: { p: [number, number, number]; c: string; oh: [number, number] }[] = [];
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const isO = i === 5;
      arr.push({
        p: [Math.cos(a) * 0.8, Math.sin(a) * 0.8, 0],
        c: isO ? "#ef4444" : "#94a3b8",
        oh: [Math.cos(a) * 1.35, Math.sin(a) * 1.35],
      });
    }
    return arr;
  }, []);
  return (
    <group position={position} scale={scale}>
      {atoms.map((at, i) => (
        <group key={i}>
          <mesh position={at.p} castShadow>
            <sphereGeometry args={[0.28, 14, 14]} />
            <meshStandardMaterial color={at.c} roughness={0.4} />
          </mesh>
          {/* bond to next */}
          <mesh position={[(at.p[0] + atoms[(i + 1) % 6].p[0]) / 2, (at.p[1] + atoms[(i + 1) % 6].p[1]) / 2, 0]}
            rotation={[0, 0, Math.atan2(atoms[(i + 1) % 6].p[1] - at.p[1], atoms[(i + 1) % 6].p[0] - at.p[0]) + Math.PI / 2]}>
            <cylinderGeometry args={[0.07, 0.07, 0.8, 8]} />
            <meshStandardMaterial color="#cbd5e1" roughness={0.5} />
          </mesh>
          {/* -OH group */}
          <mesh position={[at.oh[0], at.oh[1], 0]}>
            <sphereGeometry args={[0.16, 10, 10]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.4} />
          </mesh>
        </group>
      ))}
      {/* CH2OH arm */}
      <mesh position={[0.8, -1.35, 0]}>
        <sphereGeometry args={[0.2, 10, 10]} />
        <meshStandardMaterial color="#38bdf8" roughness={0.4} />
      </mesh>
      <mesh position={[0.8, -1.05, 0]}>
        <cylinderGeometry args={[0.06, 0.06, 0.5, 6]} />
        <meshStandardMaterial color="#cbd5e1" />
      </mesh>
    </group>
  );
}

function Animator({
  spinner, elapsed, speed,
}: {
  spinner: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (spinner.current) spinner.current.rotation.y = t * 0.5;
  });
  return null;
}

export function Topic10058Sim(props: SimProps) {
  const mol = (String(props.mol ?? "glucose") as keyof typeof MOLS) in MOLS
    ? (String(props.mol ?? "glucose") as keyof typeof MOLS)
    : "glucose";
  const speed = Number(props.speed ?? 1);
  const spinner = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = MOLS[mol];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          [mol[0].toUpperCase() + mol.slice(1), info.formula],
          ["Role", info.note],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={spinner} position={[0, 2.0, 0]}>
          {mol === "glucose" && <GlucoseRing scale={1.6} />}
          {mol === "starch" && (
            <group>
              {/* amylose helix of glucose rings */}
              {Array.from({ length: 7 }).map((_, i) => {
                const a = i * 0.9;
                return (
                  <group key={i} position={[Math.cos(a) * 1.3, i * 0.75 - 2.2, Math.sin(a) * 1.3]}
                    rotation={[0, -a, 0]}>
                    <GlucoseRing scale={0.75} />
                    {i < 6 && (
                      <mesh position={[0, 0.45, 0]}>
                        <cylinderGeometry args={[0.06, 0.06, 0.7, 6]} />
                        <meshStandardMaterial color="#fbbf24" roughness={0.5} />
                      </mesh>
                    )}
                  </group>
                );
              })}
            </group>
          )}
          {mol === "cellulose" && (
            <group>
              {/* straight β-1,4 chain, alternating flipped */}
              {Array.from({ length: 6 }).map((_, i) => (
                <group key={i} position={[(i - 2.5) * 1.9, 0, 0]} rotation={[0, 0, i % 2 ? Math.PI : 0]}>
                  <GlucoseRing scale={0.8} />
                  {i < 5 && (
                    <mesh position={[0.95, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
                      <cylinderGeometry args={[0.06, 0.06, 0.9, 6]} />
                      <meshStandardMaterial color="#4ade80" roughness={0.5} />
                    </mesh>
                  )}
                </group>
              ))}
              {/* hydrogen bonds between chains */}
              {[-1.5, 0.5].map((x, i) => (
                <mesh key={i} position={[x, 1.1, 0]}>
                  <boxGeometry args={[3.4, 0.05, 0.05]} />
                  <meshBasicMaterial color="#7dd3fc" transparent opacity={0.6} />
                </mesh>
              ))}
            </group>
          )}
        </group>

        <Label text={mol === "glucose" ? "glucose — Haworth ring" : mol === "starch" ? "starch (amylose) — α-1,4 helix" : "cellulose — β-1,4 straight chain"}
          position={[0, 5.4, 0]} size={0.4} color="#f8fafc" />
        <Label text="C (grey) • O ring (red) • –OH (blue)" position={[0, 4.7, 0]} size={0.3} color="#94a3b8" />
        {mol === "starch" && (
          <Label text="α-1,4 glycosidic bonds (yellow)" position={[0, -0.9, 0]} size={0.3} color="#fde68a" />
        )}
        {mol === "cellulose" && (
          <Label text="β-1,4 bonds + H-bonds → strong fibre" position={[0, -1.4, 0]} size={0.3} color="#86efac" />
        )}
        {mol === "glucose" && (
          <Label text="–CH₂OH arm" position={[2.6, 0.4, 0]} size={0.3} color="#7dd3fc" />
        )}

        <Animator spinner={spinner} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
