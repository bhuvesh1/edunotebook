// Medical genetics: chromosomal disorders & inheritance — X-shaped duplicated
// chromosomes, a 3D Punnett square showing dominant/recessive inheritance, and
// trisomy 21 highlighted.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "trait", label: "Trait", kind: "select", min: 0, max: 0, step: 1, default: "dominant", options: ["dominant", "recessive"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Genetics: Chromosomes & Inheritance",
  blurb: "X-shaped chromosomes, a Punnett square for dominant vs recessive traits, and trisomy 21.",
};

// one duplicated chromosome (two sister chromatids = X shape)
function Chromosome({ scale = 1, color = "#c084fc", highlight = false }: { scale?: number; color?: string; highlight?: boolean }) {
  return (
    <group scale={scale}>
      {[0.35, -0.35].map((a) => (
        <group key={a} rotation={[0, 0, a]}>
          <mesh position={[0, 0.45, 0]} castShadow>
            <capsuleGeometry args={[0.14, 0.7, 6, 10]} />
            <meshStandardMaterial color={color} emissive={highlight ? "#7c3aed" : "#000000"}
              emissiveIntensity={highlight ? 0.8 : 0} roughness={0.4} />
          </mesh>
          <mesh position={[0, -0.45, 0]} castShadow>
            <capsuleGeometry args={[0.14, 0.7, 6, 10]} />
            <meshStandardMaterial color={color} emissive={highlight ? "#7c3aed" : "#000000"}
              emissiveIntensity={highlight ? 0.8 : 0} roughness={0.4} />
          </mesh>
        </group>
      ))}
      <mesh>
        <sphereGeometry args={[0.16, 10, 10]} />
        <meshStandardMaterial color={highlight ? "#fef08a" : "#7c3aed"} />
      </mesh>
    </group>
  );
}

function Animator({
  spinner, tri, elapsed, speed,
}: {
  spinner: React.RefObject<THREE.Group>;
  tri: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (spinner.current) spinner.current.rotation.y = t * 0.4;
    if (tri.current) {
      tri.current.children.forEach((m, i) => {
        m.position.y = 1 + Math.sin(t * 2 + i * 2.1) * 0.15;
      });
    }
  });
  return null;
}

export function Topic10031Sim(props: SimProps) {
  const trait = String(props.trait ?? "dominant");
  const speed = Number(props.speed ?? 1);
  const spinner = useRef<THREE.Group>(null!);
  const tri = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const dominant = trait === "dominant";
  // Punnett square Aa x Aa
  const genotypes: [string, boolean][] = useMemo(
    () =>
      dominant
        ? [["AA", true], ["Aa", true], ["Aa", true], ["aa", false]]
        : [["AA", false], ["Aa", false], ["Aa", false], ["aa", true]],
    [dominant]
  );
  const risk = dominant ? "75%" : "25%";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Cross", "Aa × Aa"],
          [`Affected risk (${trait})`, risk],
        ]}
      />
      <SimCanvas cameraPosition={[0, 6, 16]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* chromosome pair display */}
        <group ref={spinner} position={[-7.5, 2.2, 0]}>
          <group position={[-0.7, 0, 0]}><Chromosome /></group>
          <group position={[0.7, 0, 0]}><Chromosome /></group>
        </group>
        <Label text="homologous pair" position={[-7.5, 4.2, 0]} size={0.36} color="#f8fafc" />
        <Label text="sister chromatids" position={[-7.5, 0.7, 0]} size={0.3} color="#d8b4fe" />

        {/* 3D Punnett square */}
        <group position={[0.5, 0, 0]}>
          {/* board */}
          <mesh position={[0, 0.4, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
            <planeGeometry args={[4.4, 4.4]} />
            <meshStandardMaterial color="#1e293b" roughness={0.8} />
          </mesh>
          {[0, 1, 2].map((i) => (
            <group key={i}>
              <mesh position={[-2.2 + i * 2.2, 0.42, 0]} rotation={[-Math.PI / 2, 0, 0]}>
                <planeGeometry args={[0.08, 4.4]} />
                <meshBasicMaterial color="#64748b" />
              </mesh>
              <mesh position={[0, 0.42, -2.2 + i * 2.2]} rotation={[-Math.PI / 2, 0, 0]}>
                <planeGeometry args={[4.4, 0.08]} />
                <meshBasicMaterial color="#64748b" />
              </mesh>
            </group>
          ))}
          {/* parent gamete labels */}
          <Label text="A" position={[-1.1, 0.45, -2.9]} size={0.4} color="#fde68a" />
          <Label text="a" position={[1.1, 0.45, -2.9]} size={0.4} color="#fde68a" />
          <Label text="A" position={[-2.9, 0.45, -1.1]} size={0.4} color="#fde68a" />
          <Label text="a" position={[-2.9, 0.45, 1.1]} size={0.4} color="#fde68a" />
          {/* offspring cells: green = affected, grey = carrier/unaffected */}
          {genotypes.map(([g, affected], i) => {
            const cx = -1.1 + (i % 2) * 2.2;
            const cz = -1.1 + Math.floor(i / 2) * 2.2;
            return (
              <group key={i} position={[cx, 0.45, cz]}>
                <mesh position={[0, 0.35, 0]} castShadow>
                  <boxGeometry args={[1.9, 0.7, 1.9]} />
                  <meshStandardMaterial color={affected ? "#4ade80" : "#475569"}
                    emissive={affected ? "#14532d" : "#000000"} emissiveIntensity={0.5} roughness={0.5} />
                </mesh>
                <Label text={g} position={[0, 1.0, 0]} size={0.45} color="#f8fafc" />
              </group>
            );
          })}
        </group>
        <Label text={`Punnett square — ${trait} trait`} position={[0.5, 3.6, 0]} size={0.4} color="#f8fafc" />
        <Label text={`affected: ${risk}`} position={[0.5, -0.9, 0]} size={0.34} color="#86efac" />

        {/* trisomy 21 */}
        <group position={[7.8, 0, 0]}>
          <group ref={tri} position={[0, 1.0, 0]}>
            <group position={[-0.75, 0, 0]}><Chromosome scale={0.8} color="#94a3b8" /></group>
            <group position={[0, 0, 0]}><Chromosome scale={0.8} color="#94a3b8" /></group>
            <group position={[0.75, 0, 0]}><Chromosome scale={0.8} highlight /></group>
          </group>
          <Label text="trisomy 21" position={[0, 3.1, 0]} size={0.42} color="#f8fafc" />
          <Label text="extra copy — Down syndrome" position={[0, -0.6, 0]} size={0.3} color="#fde68a" />
        </group>

        <Animator spinner={spinner} tri={tri} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
