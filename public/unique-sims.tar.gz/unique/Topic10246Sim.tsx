// Colorectal — hemorrhoids, fissure, fistula & colorectal cancer. The anal
// canal in cutaway: swollen hemorrhoid cushions, a fissure tear, a fistula
// tunnel, or a cancerous polyp growing in the rectum. Condition select +
// severity slider.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "severity", label: "Severity", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "hemorrhoids", options: ["hemorrhoids", "anal fissure", "fistula", "colorectal cancer"] },
];

export const UNIQUE_META = {
  title: "Colorectal Disorders",
  blurb: "Inside the anal canal: swollen hemorrhoid cushions, a painful fissure tear, a fistula tunnel — or a cancerous polyp. Pick one.",
};

function Animator({ lesion, elapsed, severity }: {
  lesion: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  severity: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (lesion.current) {
      lesion.current.children.forEach((c, i) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = (severity / 100) * (0.3 + 0.3 * Math.sin(t * 3 + i * 2));
      });
    }
  });
  return null;
}

export function Topic10246Sim(props: SimProps) {
  const severity = Number(props.severity ?? 55);
  const condition = String(props.condition ?? "hemorrhoids");
  const lesion = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const f = severity / 100;

  const notes: Record<string, string> = {
    hemorrhoids: "Swollen veins — painless bleeding, itching",
    "anal fissure": "Tear from hard stool — severe pain on passing stool",
    fistula: "Infected tunnel — needs surgery",
    "colorectal cancer": "Polyp → cancer — screen after 45",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", condition], ["Note", notes[condition]]]} />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* rectum */}
        <mesh position={[0, 3.4, 0]} castShadow>
          <cylinderGeometry args={[1.1, 1.25, 3.4, 20, 1, true]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.55} side={THREE.DoubleSide} />
        </mesh>
        {/* anal canal */}
        <mesh position={[0, 1.3, 0]} castShadow>
          <cylinderGeometry args={[0.7, 0.8, 1.8, 18, 1, true]} />
          <meshStandardMaterial color="#fda4af" roughness={0.55} side={THREE.DoubleSide} />
        </mesh>
        {/* dentate line marker */}
        <mesh position={[0, 2.0, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.78, 0.05, 8, 24]} />
          <meshBasicMaterial color="#fde047" transparent opacity={0.6} />
        </mesh>

        <group ref={lesion}>
          {condition === "hemorrhoids" && (
            <group>
              {[0, 1, 2].map((i) => {
                const a = (i / 3) * Math.PI * 2;
                return (
                  <mesh key={i} position={[Math.cos(a) * 0.55, 1.15, Math.sin(a) * 0.55]} scale={[1, 1 + f, 1]}>
                    <sphereGeometry args={[0.32, 14, 12]} />
                    <meshStandardMaterial color="#7c3aed" roughness={0.5} emissive="#4c1d95" emissiveIntensity={0.4} />
                  </mesh>
                );
              })}
              <Label text="Hemorrhoids — swollen cushions" position={[0, -0.2, 0]} size={0.5} color="#c4b5fd" />
            </group>
          )}
          {condition === "anal fissure" && (
            <group>
              <mesh position={[0.45, 1.0, 0.35]} rotation={[0, 0, 0.35]} scale={[1, 1 + f * 0.8, 1]}>
                <boxGeometry args={[0.14, 1.1, 0.3]} />
                <meshStandardMaterial color="#dc2626" roughness={0.6} emissive="#7f1d1d" emissiveIntensity={0.5} />
              </mesh>
              <Label text="Fissure — a paper-cut-like tear" position={[1.8, 0.9, 0.35]} size={0.5} color="#fca5a5" />
            </group>
          )}
          {condition === "fistula" && (
            <group>
              <mesh position={[1.3, 1.1, 0]} rotation={[0, 0, Math.PI / 2.5]}>
                <cylinderGeometry args={[0.16, 0.16, 2.0, 10]} />
                <meshStandardMaterial color="#facc15" roughness={0.5} emissive="#a16207" emissiveIntensity={0.4} />
              </mesh>
              <mesh position={[2.1, 0.6, 0]}>
                <sphereGeometry args={[0.28, 12, 10]} />
                <meshStandardMaterial color="#facc15" roughness={0.5} emissive="#a16207" emissiveIntensity={0.5} />
              </mesh>
              <Label text="Fistula — infected tunnel to the skin" position={[1.5, 2.4, 0]} size={0.5} color="#fde047" />
            </group>
          )}
          {condition === "colorectal cancer" && (
            <group>
              <mesh position={[-0.5, 3.6, 0.4]} scale={[1 + f, 1 + f * 1.3, 1 + f]}>
                <dodecahedronGeometry args={[0.4, 1]} />
                <meshStandardMaterial color="#7f1d1d" roughness={0.6} emissive="#dc2626" emissiveIntensity={0.35} flatShading />
              </mesh>
              <Label text="Malignant polyp — bleeding, change in bowel habit" position={[-0.5, 5.3, 0.4]} size={0.5} color="#fca5a5" />
            </group>
          )}
        </group>

        <Label text={notes[condition]} position={[0, -1.4, 0]} size={0.44} color="#94a3b8" />
        <Animator lesion={lesion} elapsed={elapsed} severity={severity} />
      </SimCanvas>
    </div>
  );
}
