"use client";
// Exodontia Complications — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "comp", label: "Complication", kind: "select", min: 0, max: 0, step: 1, default: "Dry socket", options: ["Dry socket", "Root fracture", "Displacement into sinus"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Exodontia Complications",
  blurb: "Three things that can go wrong: a painful dry socket, a snapped root tip, or a tooth pushed into the sinus.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const names = ["cDry", "cFrac", "cDisp"];
    const sel = p.comp === "Dry socket" ? 0 : p.comp === "Root fracture" ? 1 : 2;
    names.forEach((nm, i) => {
      const m: any = g(nm);
      if (m) m.scale.setScalar(i === sel ? 1.06 + 0.02 * Math.sin(t * 3) : 0.94);
    });
    for (let i = 0; i < 3; i++) {
      const b: any = g("pain" + i);
      if (b) (b.material as any).opacity = sel === 0 ? 0.5 + 0.4 * Math.sin(t * 6 + i * 2) : 0;
    }
  });
  return null;
}

export function Topic10496Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const comp = String(props.comp ?? "Dry socket");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, comp };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Dry socket", "Lost clot, day 2–3"],
          ["Root fracture", "Tip left behind"],
          ["Displacement", "Into maxillary sinus"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <group name="cDry" position={[-3.4, 1, 0]}>
            <GumSlab position={[0, 0, 0]} scale={0.55} />
            <mesh position={[0, 0.35, 0]}>
              <cylinderGeometry args={[0.45, 0.5, 0.45, 12]} />
              <meshStandardMaterial color="#3b1d0e" roughness={1} />
            </mesh>
            {[0, 1, 2].map((i) => (
              <mesh key={i} name={"pain" + i} position={[-0.4 + i * 0.4, 1.6 + (i % 2) * 0.3, 0]}>
                <coneGeometry args={[0.09, 0.4, 6]} />
                <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.8} transparent opacity={0.6} />
              </mesh>
            ))}
            <Label text="Dry socket: empty, painful" position={[0, 2.6, 0]} size={0.4} color="#ef4444" />
          </group>
          <group name="cFrac" position={[0, 1, 0]}>
            <GumSlab position={[0, 0, 0]} scale={0.55} />
            <group position={[0.15, 1.9, 0]} rotation={[0, 0, 0.5]}>
              <mesh>
                <cylinderGeometry args={[0.55, 0.45, 0.7, 12]} />
                <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
              </mesh>
            </group>
            <mesh position={[-0.1, 0.3, 0]}>
              <coneGeometry args={[0.18, 0.7, 10]} />
              <meshStandardMaterial color="#e6dabd" roughness={0.6} />
            </mesh>
            <Label text="Root fracture: tip retained" position={[0, 2.9, 0]} size={0.4} color="#fbbf24" />
          </group>
          <group name="cDisp" position={[3.4, 1, 0]}>
            <mesh position={[0, 2.6, -0.3]}>
              <boxGeometry args={[2.2, 1.2, 1.6]} />
              <meshStandardMaterial color="#94a3b8" roughness={0.7} transparent opacity={0.6} />
            </mesh>
            <GumSlab position={[0, 0, 0]} scale={0.55} />
            <group position={[0, 1.9, 0]}>
              <Tooth scale={0.85} />
            </group>
            <Arrow from={[0, 1, 0.3]} to={[0, 2.2, -0.1]} color="#ef4444" />
            <Label text="Displaced into sinus" position={[0, 3.6, -0.3]} size={0.4} color="#94a3b8" />
          </group>
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
