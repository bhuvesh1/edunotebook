"use client";
// Mucogingival Surgery: Grafts & Frenectomy — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "proc", label: "Procedure", kind: "select", min: 0, max: 0, step: 1, default: "Connective tissue graft", options: ["Connective tissue graft", "Frenectomy"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Mucogingival Surgery: Grafts & Frenectomy",
  blurb: "A pink graft patch covers the exposed root — or snip the tight lip frenum and watch it release.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const graftMode = p.proc === "Connective tissue graft";
    const patch: any = g("graftpatch");
    if (patch) {
      patch.visible = graftMode;
      const T = 8;
      const ph = (t % T) / T;
      patch.position.z = graftMode ? 0.9 - Math.min(1, ph / 0.5) * 0.55 : 0.9;
    }
    const fr: any = g("frenum");
    if (fr) {
      fr.visible = !graftMode;
      const T = 8;
      const ph = (t % T) / T;
      const cut = ph > 0.4 ? Math.min(1, (ph - 0.4) / 0.2) : 0;
      fr.scale.y = Math.max(0.15, 1 - cut * 0.8);
      (fr.material as any).color.set(cut > 0.5 ? "#f4a7b9" : "#e0808f");
    }
    const mg: any = g("mgmargin");
    if (mg) {
      mg.visible = graftMode;
      mg.position.y = 1.5 - (graftMode ? 0.9 : 0);
    }
  });
  return null;
}

export function Topic10490Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const proc = String(props.proc ?? "Connective tissue graft");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, proc };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Procedure", proc],
          ["Goal", proc === "Connective tissue graft" ? "Cover exposed root" : "Release tight frenum"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1.2, 0]} scale={1.5} />
          <mesh name="mgmargin" position={[0, 0.6, 0]}>
            <boxGeometry args={[2.6, 0.9, 2]} />
            <meshStandardMaterial color="#e0808f" roughness={0.6} />
          </mesh>
          <mesh name="graftpatch" position={[0, 0.9, 0.9]}>
            <boxGeometry args={[1.4, 1.3, 0.18]} />
            <meshStandardMaterial color="#f4a7b9" roughness={0.5} />
          </mesh>
          <mesh name="frenum" position={[0, 2.6, 0.8]} visible={false}>
            <boxGeometry args={[0.28, 1.6, 0.2]} />
            <meshStandardMaterial color="#e0808f" roughness={0.6} />
          </mesh>
          <mesh position={[0, 3.6, 0.8]}>
            <boxGeometry args={[3.4, 0.7, 0.5]} />
            <meshStandardMaterial color="#e0808f" roughness={0.6} />
          </mesh>
          <Label text="Exposed root" position={[2.4, 0.4, 0]} size={0.42} />
          <Label text="Graft patch" position={[-2.4, 0.9, 0.9]} size={0.42} color="#f4a7b9" />
          <Label text="Tight frenum" position={[2.4, 2.6, 0.8]} size={0.42} />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
