// app/components/sims/unique/Topic7094Sim.tsx
// Free fall under gravity: a bowling ball and a feather are dropped from
// the same height at the same time. The ball plummets; the feather
// drifts down slowly, swaying — air resistance matters. The slider tunes
// how thick the air feels for the feather.

"use client";

import { useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "air", label: "Air resistance", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.6, unit: "" },
];

export const UNIQUE_META = {
  title: "Free Fall Under Gravity",
  blurb: "Bowling ball vs feather, dropped together — gravity pulls both, but air slows the feather.",
};

const H = 6.2;
const G = 9.8;

function DropAnimator({
  ball,
  feather,
  air,
  state,
  bump,
}: {
  ball: RefObject<THREE.Mesh>;
  feather: RefObject<THREE.Group>;
  air: number;
  state: RefObject<{ tb: number; tf: number }>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    // Ball: near-true free fall. Feather: strong drag → slow terminal fall + sway.
    const ballFall = Math.sqrt((2 * H) / G);
    const featherFall = ballFall * (1 + air * 4);
    const cycle = featherFall + 1.4;
    const T = t.current % cycle;
    const sb = T <= ballFall ? 0.5 * G * T * T : H;
    const sf = T <= featherFall ? H * (T / featherFall) : H;
    state.current = { tb: Math.min(T, ballFall), tf: Math.min(T, featherFall) };
    if (ball.current) ball.current.position.y = 0.45 + H - sb;
    if (feather.current) {
      feather.current.position.y = 0.35 + H - sf;
      feather.current.position.x = 2.2 + Math.sin(T * 3) * 0.5 * Math.min(1, T / featherFall + 0.2);
      feather.current.rotation.z = Math.sin(T * 3) * 0.5;
      feather.current.rotation.y = T * 1.2;
    }
    if (++n.current % 12 === 0) bump();
  });
  return null;
}

export function Topic7094Sim(props: SimProps) {
  const air = Number(props.air ?? 0.6);
  const ball = useRef<THREE.Mesh>(null!);
  const feather = useRef<THREE.Group>(null!);
  const state = useRef({ tb: 0, tf: 0 });
  const [, bump] = useState(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Ball fall time", `${state.current.tb.toFixed(2)} s`],
          ["Feather fall time", `${state.current.tf.toFixed(2)} s`],
          ["⚫ Ball", "heavy — near free fall"],
          ["🪶 Feather", "light — air drag wins"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 13]} target={[0, 3.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* drop platform */}
        <mesh position={[0, 0.4 + H + 0.55, 0]} castShadow>
          <boxGeometry args={[7.5, 0.3, 1.6]} />
          <meshStandardMaterial color="#475569" roughness={0.6} metalness={0.4} />
        </mesh>
        {[-2.2, 2.2].map((x) => (
          <primitive
            key={x}
            object={
              new THREE.Line(
                new THREE.BufferGeometry().setFromPoints([
                  new THREE.Vector3(x, 0.2, 0),
                  new THREE.Vector3(x, 0.4 + H + 0.4, 0),
                ]),
                new THREE.LineBasicMaterial({ color: "#475569", transparent: true, opacity: 0.4 })
              )
            }
          />
        ))}

        {/* bowling ball */}
        <mesh ref={ball} position={[-2.2, 0.45 + H, 0]} castShadow>
          <sphereGeometry args={[0.45, 28, 28]} />
          <meshStandardMaterial color="#1f2937" roughness={0.3} metalness={0.4} />
        </mesh>

        {/* feather: flat vane + shaft */}
        <group ref={feather} position={[2.2, 0.35 + H, 0]}>
          <mesh castShadow>
            <boxGeometry args={[0.08, 0.9, 0.5]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.8} />
          </mesh>
          <mesh position={[0, -0.65, 0]}>
            <cylinderGeometry args={[0.03, 0.03, 0.5, 8]} />
            <meshStandardMaterial color="#cbd5e1" roughness={0.8} />
          </mesh>
        </group>

        <DropAnimator ball={ball} feather={feather} air={air} state={state} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
