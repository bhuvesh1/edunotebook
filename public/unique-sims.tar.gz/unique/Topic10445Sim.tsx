"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "step", label: "Step", kind: "select", min: 0, max: 0, step: 1, default: "condense", options: ["triturate", "condense", "carve", "polish"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Amalgam restorations: indications, technique",
  blurb: "The classic silver filling step by step — mix the capsule, condense the amalgam, carve the tooth's grooves, then polish.",
};

const STEPS: Record<string, { name: string; note: string; color: string }> = {
  triturate: { name: "Trituration", note: "Capsule shaken — alloy + mercury mix", color: "#e2e8f0" },
  condense: { name: "Condensation", note: "Plugger packs amalgam into the cavity", color: "#cbd5e1" },
  carve: { name: "Carving", note: "Carver sculpts cusps and grooves", color: "#fde68a" },
  polish: { name: "Polishing (next visit)", note: "Smooth shiny silver — kinder to opposing tooth", color: "#fef3c7" },
};

function Scene({ step, speed }: { step: string; speed: number }) {
  const plugger = useRef<THREE.Group>(null!);
  const capsule = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const st = STEPS[step] ?? STEPS.condense;

  useFrame((_, delta) => {
    t.current += delta * speed;
    if (plugger.current) plugger.current.position.y = 2.6 + Math.sin(t.current * 4) * 0.5;
    if (capsule.current) {
      capsule.current.rotation.z = Math.sin(t.current * 8) * 0.4;
      capsule.current.position.x = Math.sin(t.current * 8) * 0.15;
    }
  });

  return (
    <group>
      {/* tooth with cavity */}
      <mesh position={[0, 0.6, 0]}>
        <cylinderGeometry args={[1.05, 1.25, 1.5, 20]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.25} />
      </mesh>
      <mesh position={[0, -0.9, 0]}>
        <coneGeometry args={[0.85, 1.5, 18]} />
        <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
      </mesh>
      {/* cavity hole */}
      <mesh position={[0, 1.28, 0]}>
        <cylinderGeometry args={[0.5, 0.55, 0.35, 14]} />
        <meshStandardMaterial color="#475569" roughness={0.9} />
      </mesh>
      {/* amalgam fill (appears from condense on) */}
      {step !== "triturate" && (
        <mesh position={[0, 1.32, 0]}>
          <cylinderGeometry args={[0.52, 0.55, 0.3, 14]} />
          <meshStandardMaterial color="#aeb6c2" metalness={0.85} roughness={step === "polish" ? 0.15 : 0.5} />
        </mesh>
      )}
      {/* carved grooves */}
      {(step === "carve" || step === "polish") && (
        <group position={[0, 1.48, 0]}>
          <mesh rotation={[0, 0.4, 0]}>
            <boxGeometry args={[0.9, 0.04, 0.08]} />
            <meshStandardMaterial color="#6b7280" metalness={0.7} roughness={0.5} />
          </mesh>
          <mesh rotation={[0, -0.4, 0]}>
            <boxGeometry args={[0.9, 0.04, 0.08]} />
            <meshStandardMaterial color="#6b7280" metalness={0.7} roughness={0.5} />
          </mesh>
        </group>
      )}

      {/* amalgam capsule shaking */}
      {step === "triturate" && (
        <group ref={capsule} position={[-2.2, 2.2, 0]}>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <capsuleGeometry args={[0.3, 0.7, 8, 14]} />
            <meshStandardMaterial color="#f472b6" roughness={0.4} />
          </mesh>
          <Label text="Amalgam capsule" position={[0, 0.9, 0]} size={0.42} color="#f9a8d4" />
        </group>
      )}
      {/* plugger condensing */}
      {step === "condense" && (
        <group ref={plugger} position={[0, 2.6, 0]}>
          <mesh position={[0, 0.5, 0]}>
            <cylinderGeometry args={[0.12, 0.12, 1.2, 10]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
          </mesh>
          <mesh position={[0, -0.25, 0]}>
            <cylinderGeometry args={[0.16, 0.13, 0.35, 10]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.3} />
          </mesh>
          <Label text="Condenser — pack it tight!" position={[0, 1.5, 0]} size={0.42} color="#e2e8f0" />
        </group>
      )}
      {/* carver */}
      {step === "carve" && (
        <group position={[1.6, 2.2, 0.4]} rotation={[0, 0, -0.5]}>
          <mesh position={[0, 0.5, 0]}>
            <cylinderGeometry args={[0.07, 0.07, 1.1, 8]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
          </mesh>
          <mesh position={[0, -0.2, 0]} rotation={[0, 0, 0.6]}>
            <boxGeometry args={[0.08, 0.4, 0.05]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.3} />
          </mesh>
          <Label text="Carver" position={[0, 1.4, 0]} size={0.4} color="#e2e8f0" />
        </group>
      )}

      <Label text="Back teeth — strong & cheap" position={[-2.8, 0.6, 0]} size={0.42} color="#94a3b8" />
      <Label text={st.name} position={[0, 3.6, 0]} size={0.65} color={st.color} />
      <Label text={st.note} position={[0, -2.4, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10445Sim(props: SimProps) {
  const step = String(props.step ?? "condense");
  const speed = Number(props.speed ?? 1);
  const st = STEPS[step] ?? STEPS.condense;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Step", st.name], ["Material", "Silver amalgam"], ["Use", "Posterior load-bearing"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 9]} target={[0, 0.5, 0]}>
        <Scene step={step} speed={speed} />
      </SimCanvas>
    </div>
  );
}
