// app/components/sims/unique/Topic10547Sim.tsx
// Dental public health: the three levels of prevention as a pyramid —
// primary (keep disease away), secondary (catch it early), tertiary
// (rehabilitate). Selecting a level spotlights its tier.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "level", label: "Prevention level", kind: "select", min: 0, max: 0, step: 1, default: "primary", options: ["primary", "secondary", "tertiary"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Dental Public Health: Levels of Prevention",
  blurb: "A three-tier pyramid of prevention — stop disease, catch it early, or restore what was lost.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ tiers, elapsed, speed, active }: {
  tiers: RefObject<THREE.Group>[]; elapsed: RefObject<number>; speed: number; active: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    tiers.forEach((g, i) => {
      if (!g.current) return;
      const on = i === active;
      g.current.position.y = g.current.userData.by + (on ? 0.25 + 0.08 * Math.sin(elapsed.current * 2.5) : 0);
      g.current.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.isMesh) ((m as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = on ? 0.7 : 0.1;
      });
    });
  });
  return null;
}

const INFO = [
  { key: "primary", color: "#4ade80", title: "PRIMARY prevention", eg: "fluoride, sealants, diet counseling, brushing", goal: "disease never starts" },
  { key: "secondary", color: "#fbbf24", title: "SECONDARY prevention", eg: "screening camps, X-rays, early fillings", goal: "catch it early, treat simply" },
  { key: "tertiary", color: "#f87171", title: "TERTIARY prevention", eg: "root canals, crowns, dentures, rehab", goal: "restore function, limit disability" },
];

export function Topic10547Sim(props: SimProps) {
  const level = String(props.level ?? "primary");
  const speed = Number(props.speed ?? 1);
  const t0 = useRef<THREE.Group>(null!);
  const t1 = useRef<THREE.Group>(null!);
  const t2 = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const active = Math.max(INFO.findIndex((i) => i.key === level), 0);
  const info = INFO[active];

  // pyramid tiers: wide base (primary) to narrow top (tertiary)
  const tiers = [
    { w: 7.2, y: 0.75, label: "PRIMARY", eg: "fluoride · sealants · diet" },
    { w: 4.8, y: 2.05, label: "SECONDARY", eg: "screening · early fillings" },
    { w: 2.4, y: 3.05, label: "TERTIARY", eg: "crowns · dentures · rehab" },
  ];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Level", info.title],
          ["Examples", info.eg],
          ["Goal", info.goal],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {[t0, t1, t2].map((ref, i) => (
          <group key={i} ref={ref} position={[0, 0, 0]} userData={{ by: 0 }}>
            <mesh position={[0, tiers[i].y, 0]} castShadow>
              <boxGeometry args={[tiers[i].w, 1.1, 3.2]} />
              <meshStandardMaterial color={INFO[i].color} emissive={INFO[i].color} emissiveIntensity={0.1} roughness={0.5} />
            </mesh>
            <Text position={[0, tiers[i].y, 1.65]} fontSize={0.42} color="#0f172a" anchorX="center" anchorY="middle">
              {tiers[i].label}
            </Text>
            <Text position={[0, tiers[i].y - 0.42, 1.65]} fontSize={0.22} color="#0f172a" anchorX="center" anchorY="middle">
              {tiers[i].eg}
            </Text>
          </group>
        ))}

        {/* tooth shield on the primary tier */}
        <mesh position={[-4.4, 0.75, 0]} castShadow>
          <boxGeometry args={[0.9, 1.1, 0.7]} />
          <meshStandardMaterial color="#ffffff" roughness={0.3} />
        </mesh>
        <mesh position={[-4.4, 0.75, 0.45]} scale={[1, 1.2, 0.4]}>
          <torusGeometry args={[0.45, 0.1, 8, 20]} />
          <meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={0.5} />
        </mesh>

        <Label p={[4.6, 0.75, 0]} size={0.28} color="#4ade80">cheapest, widest reach</Label>
        <Label p={[3.4, 2.05, 0]} size={0.28} color="#fbbf24">find it early</Label>
        <Label p={[2.2, 3.05, 0]} size={0.28} color="#f87171">repair damage</Label>

        <Animator tiers={[t0, t1, t2]} elapsed={elapsed} speed={speed} active={active} />
      </SimCanvas>
    </div>
  );
}
