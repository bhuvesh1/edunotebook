"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "file", label: "File size", kind: "select", min: 0, max: 0, step: 1, default: "15", options: ["10", "15", "20", "25", "30"] },
  { key: "speed", label: "Pecking speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Access cavity preparation, working length determination",
  blurb: "Root canal in action — the file pecks down the canal through the access cavity until the apex locator beeps green at the tip.",
};

function Scene({ file, speed }: { file: string; speed: number }) {
  const endo = useRef<THREE.Group>(null!);
  const beep = useRef<THREE.Mesh>(null!);
  const t = useRef(0);
  const fileNum = Number(file);
  const depth = 0.55 + fileNum * 0.012;

  useFrame((_, delta) => {
    t.current += delta * speed;
    if (endo.current) {
      // pecking motion down the canal
      const f = (Math.sin(t.current * 2.2) + 1) / 2;
      endo.current.position.y = 2.9 - f * depth * 2.2;
      endo.current.rotation.y = t.current * 6;
    }
    if (beep.current) {
      const atApex = ((Math.sin(t.current * 2.2) + 1) / 2) > 0.92;
      const m = beep.current.material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = atApex ? 2 + Math.sin(t.current * 20) * 1.2 : 0.15;
    }
  });

  return (
    <group>
      {/* tooth with access cavity on top */}
      <mesh position={[0, 0.7, 0]}>
        <cylinderGeometry args={[1.0, 1.15, 1.5, 20]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.25} />
      </mesh>
      {/* access cavity hole */}
      <mesh position={[0, 1.42, 0]}>
        <cylinderGeometry args={[0.34, 0.3, 0.25, 14]} />
        <meshStandardMaterial color="#1e293b" roughness={1} />
      </mesh>
      <Label text="Access cavity" position={[1.7, 1.5, 0]} size={0.4} color="#94a3b8" />
      {/* root with canal */}
      <mesh position={[0, -0.9, 0]}>
        <coneGeometry args={[0.72, 1.6, 18]} />
        <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
      </mesh>
      <mesh position={[0, -0.85, 0]}>
        <cylinderGeometry args={[0.09, 0.05, 1.7, 8]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.7} />
      </mesh>
      <Label text="Root canal" position={[1.7, -0.85, 0]} size={0.4} color="#fca5a5" />
      {/* apex */}
      <mesh position={[0, -1.72, 0]}>
        <sphereGeometry args={[0.09, 10, 10]} />
        <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={0.8} />
      </mesh>
      <Label text="Apex (root tip)" position={[1.7, -1.72, 0]} size={0.4} color="#fbbf24" />

      {/* endodontic file pecking down */}
      <group ref={endo} position={[0, 2.9, 0]}>
        <mesh position={[0, 0.7, 0]}>
          <cylinderGeometry args={[0.09, 0.09, 0.5, 8]} />
          <meshStandardMaterial color={fileNum <= 15 ? "#e2e8f0" : fileNum <= 25 ? "#fbbf24" : "#f87171"} roughness={0.4} />
        </mesh>
        {/* fluted file shaft */}
        <mesh position={[0, -0.6, 0]}>
          <cylinderGeometry args={[0.035, 0.018, 2.0, 8]} />
          <meshStandardMaterial color="#cbd5e1" metalness={0.85} roughness={0.3} />
        </mesh>
        {/* rubber stop */}
        <mesh position={[0, 0.1, 0]}>
          <cylinderGeometry args={[0.12, 0.12, 0.08, 10]} />
          <meshStandardMaterial color="#ef4444" roughness={0.5} />
        </mesh>
        <Label text={`K-file #${file}`} position={[1.3, 0.9, 0]} size={0.42} color="#e2e8f0" />
      </group>

      {/* apex locator */}
      <group position={[-2.8, 0.4, 0]}>
        <mesh>
          <boxGeometry args={[1.1, 1.4, 0.5]} />
          <meshStandardMaterial color="#1e293b" roughness={0.5} />
        </mesh>
        <mesh ref={beep} position={[0, 0.35, 0.28]}>
          <circleGeometry args={[0.22, 16]} />
          <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.3} />
        </mesh>
        <Label text="Apex locator" position={[0, 1.1, 0]} size={0.4} color="#86efac" />
        <Label text="BEEP at 0.0 = working length!" position={[0, -1.0, 0]} size={0.38} color="#86efac" />
      </group>
      {/* wire from locator to file */}
      <mesh position={[-1.4, 1.6, 0]} rotation={[0, 0, 1.1]}>
        <cylinderGeometry args={[0.025, 0.025, 3.0, 6]} />
        <meshStandardMaterial color="#475569" roughness={0.6} />
      </mesh>

      <Label text="Working length: file tip = apex" position={[0, -2.7, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10450Sim(props: SimProps) {
  const file = String(props.file ?? "15");
  const speed = Number(props.speed ?? 1);
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["File", `K-file #${file}`], ["Working length", "Apex − 0.5–1 mm"], ["Locator", "0.0 reading = apex"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 9]} target={[0, 0.3, 0]}>
        <Scene file={file} speed={speed} />
      </SimCanvas>
    </div>
  );
}
