// Neonatology: normal newborn care, APGAR, neonatal resuscitation.
// A newborn rests in a warm incubator, chest rising with each breath. Score
// the APGAR, or switch to resuscitation and watch the bag-mask ventilate.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "step", label: "Step", kind: "select", min: 0, max: 0, step: 1, default: "apgar", options: ["care", "apgar", "resuscitation"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Newborn Care & Resuscitation",
  blurb: "A baby in the warmer breathes on its own — score the 5 APGAR signs, then watch bag-mask resuscitation bring breathing back.",
};

// APGAR: Appearance, Pulse, Grimace, Activity, Respiration — each 0-2
const APGAR = ["Appearance", "Pulse", "Grimace", "Activity", "Respiration"];

function Animator({
  group, chest, bag, mask, apgarDots, elapsed, speed, step,
}: {
  group: React.RefObject<THREE.Group>;
  chest: React.RefObject<THREE.Mesh>;
  bag: React.RefObject<THREE.Mesh>;
  mask: React.RefObject<THREE.Group>;
  apgarDots: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  step: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
    // breathing: fast for newborn (40-60/min), absent until resuscitation works
    const resusc = step === "resuscitation";
    const cyc = (t % 12) / 12;
    const breathing = step === "care" ? 1 : step === "apgar" ? 1 : cyc > 0.3 ? 1 : 0;
    const breathRate = step === "care" ? 2.6 : 1.8;
    if (chest.current) {
      const b = breathing ? 0.5 + 0.5 * Math.sin(t * breathRate * Math.PI * 2 * 0.5) : 0.08;
      chest.current.scale.set(1 + b * 0.14, 1 + b * 0.1, 1 + b * 0.14);
    }
    if (bag.current) {
      bag.current.visible = resusc;
      bag.current.scale.setScalar(1 - 0.28 * (0.5 + 0.5 * Math.sin(t * 4)));
    }
    if (mask.current) {
      mask.current.visible = resusc;
      mask.current.position.y = 3.15 + Math.sin(t * 4) * 0.04;
    }
    if (apgarDots.current) {
      apgarDots.current.visible = step === "apgar";
      const lit = Math.floor((t % 10) / 2);
      apgarDots.current.children.forEach((d, i) => {
        const m = (d as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = i <= lit ? 1.2 : 0.05;
      });
    }
  });
  return null;
}

export function Topic10259Sim(props: SimProps) {
  const step = String(props.step ?? "apgar");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const chest = useRef<THREE.Mesh>(null!);
  const bag = useRef<THREE.Mesh>(null!);
  const mask = useRef<THREE.Group>(null!);
  const apgarDots = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = { care: "Normal newborn care", apgar: "APGAR scoring", resuscitation: "Neonatal resuscitation" };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Step", names[step] ?? step], ["APGAR", step === "apgar" ? "2+2+2+2+1 = 9" : "—"], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 3.0, 10]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* incubator: transparent box + base */}
          <mesh position={[0, 0.7, 0]} castShadow>
            <boxGeometry args={[5.2, 0.5, 3.4]} />
            <meshStandardMaterial color="#334155" roughness={0.5} />
          </mesh>
          <mesh position={[0, 2.0, 0]}>
            <boxGeometry args={[5.2, 2.4, 3.4]} />
            <meshStandardMaterial color="#7dd3fc" roughness={0.1} transparent opacity={0.18} />
          </mesh>
          {/* radiant warmer glow */}
          <mesh position={[0, 3.25, 0]} castShadow>
            <boxGeometry args={[4.6, 0.18, 2.8]} />
            <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={step === "care" ? 1.4 : 0.7} />
          </mesh>
          {/* baby body */}
          <mesh ref={chest} position={[0, 1.35, 0]} scale={[1, 0.75, 0.7]} castShadow>
            <sphereGeometry args={[0.72, 24, 18]} />
            <meshStandardMaterial color="#f5c396" roughness={0.6} />
          </mesh>
          <mesh position={[-1.35, 1.5, 0]} castShadow>
            <sphereGeometry args={[0.52, 24, 18]} />
            <meshStandardMaterial color="#f5c396" roughness={0.6} />
          </mesh>
          {/* tiny limbs */}
          {[[-0.7, 1.1, 0.55], [0.7, 1.1, 0.55]].map(([x, y, z], i) => (
            <mesh key={i} position={[x, y, z]} rotation={[0, 0, i === 0 ? 0.7 : -0.7]} castShadow>
              <capsuleGeometry args={[0.13, 0.5, 6, 10]} />
              <meshStandardMaterial color="#f5c396" roughness={0.6} />
            </mesh>
          ))}
          {/* APGAR scoreboard dots */}
          <group ref={apgarDots} position={[3.6, 2.2, 0]} visible={false}>
            {APGAR.map((name, i) => (
              <group key={name} position={[0, -i * 0.62, 0]}>
                <mesh castShadow>
                  <sphereGeometry args={[0.2, 14, 10]} />
                  <meshStandardMaterial color="#22c55e" emissive="#16a34a" emissiveIntensity={1.2} />
                </mesh>
              </group>
            ))}
            {APGAR.map((name, i) => (
              <Label key={name} text={name} position={[1.55, 2.2 - i * 0.62, 0]} size={0.42} color="#bbf7d0" />
            ))}
          </group>
          {/* resuscitation bag + mask */}
          <mesh ref={bag} position={[-2.9, 3.4, 0]} visible={false} castShadow>
            <sphereGeometry args={[0.55, 20, 14]} />
            <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
          </mesh>
          <group ref={mask} position={[-1.35, 3.15, 0]} visible={false}>
            <mesh castShadow>
              <coneGeometry args={[0.42, 0.5, 18]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.4} transparent opacity={0.85} />
            </mesh>
            <mesh position={[-1.2, 0.6, 0]} rotation={[0, 0, 1.2]} castShadow>
              <cylinderGeometry args={[0.09, 0.09, 1.6, 10]} />
              <meshStandardMaterial color="#94a3b8" roughness={0.4} />
            </mesh>
          </group>
          <Label text="Radiant warmer" position={[0, 3.85, 0]} size={0.5} color="#fde68a" />
          {step === "apgar" && <Label text="APGAR: 5 signs × 0–2" position={[-3.2, 3.4, 0]} size={0.5} color="#bbf7d0" />}
          {step === "resuscitation" && <Label text="Bag-mask: squeeze!" position={[-2.9, 4.25, 0]} size={0.55} color="#7dd3fc" />}
          {step === "care" && <Label text="Skin-to-skin warmth" position={[-3.1, 2.4, 0]} size={0.5} color="#fde68a" />}
        </group>
        <Animator group={group} chest={chest} bag={bag} mask={mask} apgarDots={apgarDots} elapsed={elapsed} speed={speed} step={step} />
      </SimCanvas>
    </div>
  );
}
