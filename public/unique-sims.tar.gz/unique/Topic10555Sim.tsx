// app/components/sims/unique/Topic10555Sim.tsx
// Biostatistics for dental research: a bell curve of sample data, the mean
// marker, and bars that settle as the sample size grows — bigger samples,
// tighter estimates.

"use client";

import { useMemo, useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "n", label: "Sample size (n)", kind: "slider", min: 10, max: 500, step: 10, default: 100, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Biostatistics for Dental Research",
  blurb: "Sample data piles into a bell curve — grow the sample and watch the estimate tighten around the true mean.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

const BINS = 21;
const DOTS = 120;

function Animator({ dots, mean, ci, elapsed, speed, n }: {
  dots: RefObject<THREE.InstancedMesh>; mean: RefObject<THREE.Mesh>; ci: RefObject<THREE.Mesh>;
  elapsed: RefObject<number>; speed: number; n: number;
}) {
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (dots.current) {
      const active = Math.round((n / 500) * DOTS);
      for (let i = 0; i < DOTS; i++) {
        if (i < active) {
          // deterministic pseudo-normal scatter, gently jiggling
          const u = ((i * 2654435761) % 1000) / 1000;
          const v = ((i * 40503) % 1000) / 1000;
          const x = (u + v + ((i * 97) % 1000) / 1000) / 3; // ~normal 0..1
          const bin = Math.floor(x * BINS);
          const stack = (i * 13) % 7;
          dummy.position.set(
            -5 + (bin / (BINS - 1)) * 10 + Math.sin(t * 2 + i) * 0.03,
            0.5 + stack * 0.28,
            Math.cos(t * 1.5 + i * 0.7) * 0.05
          );
          dummy.scale.setScalar(0.11);
        } else {
          dummy.position.set(0, -10, 0);
          dummy.scale.setScalar(0.001);
        }
        dummy.updateMatrix();
        dots.current.setMatrixAt(i, dummy.matrix);
      }
      dots.current.instanceMatrix.needsUpdate = true;
    }
    if (mean.current) {
      mean.current.position.y = 0.4 + 0.15 * Math.sin(t * 2);
    }
    if (ci.current) {
      // confidence interval narrows as 1/sqrt(n)
      const w = 3.2 / Math.sqrt(n / 10);
      ci.current.scale.x = Math.max(w, 0.05);
    }
  });
  return null;
}

export function Topic10555Sim(props: SimProps) {
  const n = Number(props.n ?? 100);
  const speed = Number(props.speed ?? 1);
  const dots = useRef<THREE.InstancedMesh>(null!);
  const mean = useRef<THREE.Mesh>(null!);
  const ci = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  // smooth bell curve outline
  const curve = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 60; i++) {
      const x = -5 + (i / 60) * 10;
      const y = 0.45 + 2.6 * Math.exp(-((x / 2.4) ** 2));
      pts.push(new THREE.Vector3(x, y, 0));
    }
    return new THREE.BufferGeometry().setFromPoints(pts);
  }, []);

  const curveLine = useMemo(
    () => new THREE.Line(curve, new THREE.LineBasicMaterial({ color: "#38bdf8" })),
    [curve]
  );

  const se = (1 / Math.sqrt(n)).toFixed(3);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Sample size", `n = ${n}`],
          ["Std. error", `≈ ${se} (∝ 1/√n)`],
          ["Lesson", "bigger n → tighter estimate"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 14]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* axis */}
        <mesh position={[0, 0.3, 0]}>
          <boxGeometry args={[11, 0.12, 0.5]} />
          <meshStandardMaterial color="#475569" roughness={0.6} />
        </mesh>
        <Label p={[0, 0.75, 0.4]} size={0.3} color="#94a3b8">DMFT score →</Label>

        {/* bell curve outline */}
        <primitive object={curveLine} />

        {/* sample dots piling into the histogram */}
        <instancedMesh ref={dots} args={[undefined, undefined, DOTS]}>
          <sphereGeometry args={[1, 10, 10]} />
          <meshStandardMaterial color="#38bdf8" emissive="#0ea5e9" emissiveIntensity={0.5} roughness={0.4} />
        </instancedMesh>

        {/* true mean marker */}
        <mesh ref={mean} position={[0, 0.4, 0]}>
          <boxGeometry args={[0.12, 3.4, 0.12]} />
          <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1} />
        </mesh>
        <Label p={[0, 4.3, 0]} size={0.3} color="#fbbf24">true mean</Label>

        {/* 95% confidence interval bar — shrinks with n */}
        <mesh ref={ci} position={[0, 1.1, 0.6]}>
          <boxGeometry args={[1, 0.14, 0.14]} />
          <meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={0.8} transparent opacity={0.85} />
        </mesh>
        <Label p={[0, 1.7, 0.8]} size={0.28} color="#4ade80">95% CI shrinks as n grows</Label>

        <Label p={[0, 5.4, 0]} size={0.36} color="#e2e8f0">the bell curve of dental data</Label>

        <Animator dots={dots} mean={mean} ci={ci} elapsed={elapsed} speed={speed} n={n} />
      </SimCanvas>
    </div>
  );
}
