"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "material", label: "Material", kind: "select", min: 0, max: 0, step: 1, default: "titanium", options: ["titanium", "pmma", "nickel"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Biocompatibility: standards and specifications",
  blurb: "Drop a dental material into living tissue — titanium gets a friendly cell hug, nickel triggers an angry immune swarm.",
};

const MATS: Record<string, { name: string; color: string; reaction: "good" | "ok" | "bad"; std: string }> = {
  titanium: { name: "Titanium", color: "#cbd5e1", reaction: "good", std: "ISO 10993 ✓ · forms TiO₂ layer" },
  pmma: { name: "PMMA acrylic", color: "#f9a8d4", reaction: "ok", std: "ISO 10993 ✓ · residual monomer irritates" },
  nickel: { name: "Nickel alloy", color: "#a8a29e", reaction: "bad", std: "⚠ ion release · allergy risk" },
};

// immune/tissue cells drifting; behavior depends on reaction
function Cells({ reaction, speed }: { reaction: "good" | "ok" | "bad"; speed: number }) {
  const g = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const N = 26;
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (!g.current) return;
    g.current.children.forEach((c, i) => {
      const a = (i / N) * Math.PI * 2 + elapsed.current * 0.25;
      const hug = reaction === "good" ? 1.55 : reaction === "ok" ? 2.1 : 1.9;
      const r = hug + Math.sin(elapsed.current * 2 + i * 1.7) * (reaction === "bad" ? 0.45 : 0.15);
      c.position.set(Math.cos(a) * r, 0.6 + Math.sin(elapsed.current * 1.5 + i) * 0.5, Math.sin(a) * r * 0.8);
      const s = reaction === "bad" ? 1 + Math.sin(elapsed.current * 5 + i) * 0.25 : 1;
      c.scale.setScalar(s);
    });
  });
  return (
    <group ref={g}>
      {Array.from({ length: N }).map((_, i) => (
        <mesh key={i}>
          <sphereGeometry args={[0.17, 12, 10]} />
          <meshStandardMaterial
            color={reaction === "good" ? "#4ade80" : reaction === "ok" ? "#facc15" : "#ef4444"}
            roughness={0.4}
            emissive={reaction === "good" ? "#14532d" : reaction === "ok" ? "#713f12" : "#7f1d1d"}
            emissiveIntensity={0.6}
          />
        </mesh>
      ))}
    </group>
  );
}

function BiocompatScene({ material, speed, showLabels }: { material: string; speed: number; showLabels: boolean }) {
  const sample = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const cfg = MATS[material] ?? MATS.titanium;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (sample.current) {
      sample.current.position.y = 0.6 + Math.sin(elapsed.current * 1.2) * 0.12;
      sample.current.rotation.y = elapsed.current * 0.4;
    }
  });

  const verdict =
    cfg.reaction === "good"
      ? "Cells attach happily — osseointegration begins"
      : cfg.reaction === "ok"
        ? "Tolerated, but unreacted monomer can irritate tissue"
        : "Immune swarm! Nickel ions provoke inflammation";

  return (
    <group>
      {/* tissue bed */}
      <mesh position={[0, -1.2, 0]} castShadow receiveShadow>
        <boxGeometry args={[9, 2, 6]} />
        <meshStandardMaterial color="#e88ca0" roughness={0.7} />
      </mesh>
      {/* capillary network hint */}
      {[-1.5, 0, 1.5].map((x, i) => (
        <mesh key={i} position={[x, -0.15, (i % 2) * 1.2 - 0.6]} rotation={[0, 0.4 * i, Math.PI / 2]}>
          <cylinderGeometry args={[0.09, 0.09, 5, 8]} />
          <meshStandardMaterial color="#ef4444" roughness={0.4} />
        </mesh>
      ))}
      {/* test sample disc */}
      <group ref={sample}>
        <mesh castShadow>
          <cylinderGeometry args={[1.1, 1.1, 0.5, 28]} />
          <meshStandardMaterial color={cfg.color} metalness={material === "titanium" ? 0.85 : 0.1} roughness={0.3} />
        </mesh>
        {/* oxide halo for titanium */}
        {material === "titanium" && (
          <mesh>
            <torusGeometry args={[1.25, 0.08, 8, 32]} />
            <meshBasicMaterial color="#7dd3fc" transparent opacity={0.7} />
          </mesh>
        )}
      </group>
      <Cells reaction={cfg.reaction} speed={speed} />
      {showLabels && (
        <>
          <Text position={[0, 2.9, 0]} fontSize={0.46} color="#fef3c7">{cfg.name} sample</Text>
          <Text position={[0, -3.4, 0]} fontSize={0.42} color={cfg.reaction === "good" ? "#86efac" : cfg.reaction === "ok" ? "#fde68a" : "#fca5a5"} maxWidth={10}>
            {verdict}
          </Text>
          <Text position={[-5.6, 2.2, 0]} fontSize={0.36} color="#e2e8f0" maxWidth={4}>Living tissue</Text>
        </>
      )}
    </group>
  );
}

export function Topic10384Sim(props: SimProps) {
  const material = String(props.material ?? "titanium");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = MATS[material] ?? MATS.titanium;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Material", cfg.name],
          ["Standard", cfg.std],
          ["Verdict", cfg.reaction === "good" ? "biocompatible ✓" : cfg.reaction === "ok" ? "acceptable" : "cytotoxic ⚠"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 12]} target={[0, 0.3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.3, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <BiocompatScene material={material} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
