"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "device", label: "Airway device", kind: "select", min: 0, max: 0, step: 1, default: "ett", options: ["ett", "lma"] },
  { key: "insert", label: "Insert device", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.7, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Airway management: intubation, LMA, difficult airway",
  blurb: "Slide an endotracheal tube past the vocal cords — or seat an LMA mask over the larynx — then watch the chest rise with each breath.",
};

const SKIN = "#f7c9a8";
const CARTILAGE = "#e0f2fe";

// Trachea with cartilage C-rings
function Trachea() {
  return (
    <group position={[0, 1.2, 0]}>
      {Array.from({ length: 9 }).map((_, i) => (
        <mesh key={i} position={[0, -i * 0.42, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <torusGeometry args={[0.55, 0.11, 10, 22, Math.PI * 1.7]} />
          <meshStandardMaterial color={CARTILAGE} roughness={0.4} />
        </mesh>
      ))}
      {/* esophagus behind */}
      <mesh position={[0, -1.9, -0.75]}>
        <cylinderGeometry args={[0.32, 0.32, 3.6, 14]} />
        <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
      </mesh>
    </group>
  );
}

// Vocal cords
function Cords() {
  return (
    <group position={[0, 4.6, 0]}>
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.28, 0, 0]} rotation={[0, 0, s * 0.5]} castShadow>
          <boxGeometry args={[0.5, 0.1, 0.7]} />
          <meshStandardMaterial color="#fecaca" roughness={0.5} />
        </mesh>
      ))}
    </group>
  );
}

function AirwayScene({ device, insert, speed, showLabels }: { device: string; insert: number; speed: number; showLabels: boolean }) {
  const tube = useRef<THREE.Group>(null!);
  const chest = useRef<THREE.Mesh>(null!);
  const air = useRef<THREE.Points>(null!);
  const elapsed = useRef(0);
  const ett = device === "ett";

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // device slides down the airway
    if (tube.current) {
      const restY = ett ? 9.4 : 8.2;
      const targetY = ett ? 4.6 : 5.4;
      tube.current.position.y = THREE.MathUtils.lerp(restY, targetY, insert);
    }
    // chest rises with ventilation
    const breath = Math.max(0, Math.sin(t * 1.6));
    if (chest.current) chest.current.scale.set(1 + breath * 0.06 * insert, 1 + breath * 0.1 * insert, 1 + breath * 0.06 * insert);
    if (air.current) {
      const p = air.current.geometry.attributes.position;
      for (let i = 0; i < p.count; i++) {
        let y = p.getY(i) - delta * speed * 3 * insert;
        if (y < 0.4) y = ett ? 4.6 : 5.4;
        p.setY(i, y);
      }
      p.needsUpdate = true;
    }
  });

  return (
    <group>
      {/* head: cranium + face */}
      <mesh position={[0, 7.2, -0.2]} castShadow>
        <sphereGeometry args={[1.55, 28, 22]} />
        <meshStandardMaterial color={SKIN} roughness={0.65} />
      </mesh>
      {/* jaw/chin */}
      <mesh position={[0, 5.9, 0.9]} castShadow>
        <boxGeometry args={[1.5, 0.9, 1.4]} />
        <meshStandardMaterial color={SKIN} roughness={0.65} />
      </mesh>
      {/* open mouth cavity */}
      <mesh position={[0, 6.05, 1.35]}>
        <boxGeometry args={[0.9, 0.5, 0.4]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.9} />
      </mesh>
      {/* tongue */}
      <mesh position={[0, 5.85, 1.1]} scale={[1, 0.4, 1.4]}>
        <sphereGeometry args={[0.45, 16, 12]} />
        <meshStandardMaterial color="#f87171" roughness={0.5} />
      </mesh>
      {/* pharynx column down to larynx */}
      <mesh position={[0, 5.2, 0.1]}>
        <cylinderGeometry args={[0.62, 0.6, 1.8, 16]} />
        <meshStandardMaterial color="#fecdd3" transparent opacity={0.65} roughness={0.4} />
      </mesh>
      <Cords />
      <Trachea />
      {/* bronchi split + lungs */}
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * 0.7, -0.6, 0]} rotation={[0, 0, s * 0.7]} castShadow>
            <cylinderGeometry args={[0.22, 0.22, 1.4, 12]} />
            <meshStandardMaterial color={CARTILAGE} roughness={0.4} />
          </mesh>
          <mesh ref={s === -1 ? chest : undefined} position={[s * 1.7, -1.9, 0]} castShadow>
            <sphereGeometry args={[1.05, 22, 16]} />
            <meshStandardMaterial color="#f9a8d4" transparent opacity={0.85} roughness={0.55} />
          </mesh>
        </group>
      ))}

      {/* the airway device */}
      <group ref={tube}>
        {ett ? (
          <group>
            <mesh castShadow>
              <cylinderGeometry args={[0.22, 0.22, 4.6, 14]} />
              <meshPhysicalMaterial color="#e0f2fe" transparent opacity={0.75} roughness={0.15} />
            </mesh>
            {/* bevel tip */}
            <mesh position={[0, -2.35, 0]} rotation={[0, 0, 0.3]}>
              <cylinderGeometry args={[0.22, 0.18, 0.3, 14]} />
              <meshStandardMaterial color="#bae6fd" roughness={0.3} />
            </mesh>
            {/* inflated cuff */}
            {insert > 0.75 && (
              <mesh position={[0, -1.9, 0]} castShadow>
                <sphereGeometry args={[0.42, 18, 12]} />
                <meshStandardMaterial color="#7dd3fc" transparent opacity={0.8} roughness={0.3} />
              </mesh>
            )}
            {/* connector */}
            <mesh position={[0, 2.5, 0]} castShadow>
              <cylinderGeometry args={[0.3, 0.3, 0.5, 14]} />
              <meshStandardMaterial color="#f97316" roughness={0.5} />
            </mesh>
          </group>
        ) : (
          <group>
            <mesh castShadow>
              <cylinderGeometry args={[0.3, 0.3, 2.6, 14]} />
              <meshPhysicalMaterial color="#e0f2fe" transparent opacity={0.75} roughness={0.15} />
            </mesh>
            {/* LMA mask bowl sealing over larynx */}
            <mesh position={[0, -1.7, 0]} scale={[1, 0.7, 1.2]} castShadow>
              <sphereGeometry args={[0.75, 20, 14]} />
              <meshStandardMaterial color="#fdba74" roughness={0.4} />
            </mesh>
            <mesh position={[0, -1.7, 0.1]} scale={[1, 0.55, 1]}>
              <torusGeometry args={[0.5, 0.16, 10, 22]} />
              <meshStandardMaterial color="#fb923c" roughness={0.4} />
            </mesh>
          </group>
        )}
      </group>

      {/* ventilated air column */}
      <points ref={air}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[new Float32Array(Array.from({ length: 30 }, () => [(Math.random() - 0.5) * 0.4, Math.random() * 5 + 0.5, (Math.random() - 0.5) * 0.4]).reduce((a, b) => a.concat(b), [] as number[])), 3]} />
        </bufferGeometry>
        <pointsMaterial color="#7dd3fc" size={0.12} transparent opacity={0.9} />
      </points>

      {showLabels && (
        <>
          <Text position={[2.9, 4.6, 0]} fontSize={0.4} color="#fecaca">Vocal cords</Text>
          <Text position={[2.9, 1.2, 0]} fontSize={0.4} color="#bae6fd">Trachea (C-rings)</Text>
          <Text position={[-3.1, -1.9, 0]} fontSize={0.4} color="#f9a8d4">Lungs rise with breath</Text>
          <Text position={[0, 9.6, 0]} fontSize={0.42} color="#fdba74">{ett ? "Endotracheal tube — through the cords" : "LMA — mask seals over larynx"}</Text>
        </>
      )}
    </group>
  );
}

export function Topic10338Sim(props: SimProps) {
  const device = String(props.device ?? "ett");
  const insert = Number(props.insert ?? 0.7);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const placed = device === "ett" ? insert > 0.75 : insert > 0.55;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Device", device === "ett" ? "ETT" : "LMA"],
          ["Position", placed ? "seated ✓" : "inserting…"],
          ["Ventilation", placed ? `${Math.round(12 * speed)}/min` : "—"],
        ]}
      />
      <SimCanvas cameraPosition={[6, 4.5, 11]} target={[0, 3.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.4, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <AirwayScene device={device} insert={insert} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
