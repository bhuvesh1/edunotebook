"use client";
// Radiographic Bone-Loss Assessment — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "loss", label: "Bone loss", kind: "slider", min: 0, max: 70, step: 5, default: 30, unit: " %" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Radiographic Bone-Loss Assessment",
  blurb: "An X-ray film of the tooth — drag the slider and watch the bone level sink away from the neck of the tooth.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const bl: any = g("boneline");
    if (bl) bl.position.y = 1.9 - (p.loss / 70) * 1.6;
    const sh: any = g("bonshade");
    if (sh) {
      sh.scale.y = Math.max(0.05, 1 - p.loss / 85);
      sh.position.y = 0.4 - (p.loss / 70) * 0.8;
    }
    const cej: any = g("cej");
    if (cej) (cej.material as any).opacity = 0.5 + 0.4 * Math.sin(t * 2);
  });
  return null;
}

export function Topic10485Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const loss = Number(props.loss ?? 30);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, loss };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Bone loss", `${loss}%`],
          ["Severity", loss < 15 ? "Mild" : loss < 35 ? "Moderate" : "Severe"],
          ["Landmark", "CEJ to bone crest"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <mesh position={[0, 1.6, -1.2]}>
            <boxGeometry args={[6.4, 4.6, 0.15]} />
            <meshStandardMaterial color="#0a0f1e" roughness={0.9} />
          </mesh>
          <group position={[0, 1.2, -0.9]}>
            <Tooth scale={1.5} enamel="#e8f4ff" />
          </group>
          <mesh name="bonshade" position={[-1.6, 0.4, -0.95]}>
            <boxGeometry args={[2.2, 2.4, 0.1]} />
            <meshStandardMaterial color="#d7e3f4" transparent opacity={0.55} roughness={0.8} />
          </mesh>
          <mesh name="bonshade2" position={[1.6, 0.4, -0.95]}>
            <boxGeometry args={[2.2, 2.4, 0.1]} />
            <meshStandardMaterial color="#d7e3f4" transparent opacity={0.55} roughness={0.8} />
          </mesh>
          <mesh name="boneline" position={[0, 1.4, -0.8]}>
            <boxGeometry args={[5.6, 0.07, 0.07]} />
            <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.7} />
          </mesh>
          <mesh name="cej" position={[0, 1.9, -0.8]}>
            <boxGeometry args={[1.5, 0.06, 0.06]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.7} transparent opacity={0.7} />
          </mesh>
          <Label text="X-ray film" position={[-3.6, 3.9, -1.2]} size={0.42} />
          <Label text="CEJ (red)" position={[2.6, 2.2, -0.8]} size={0.4} color="#ef4444" />
          <Label text="Bone crest (yellow)" position={[-3.4, 0.9, -0.8]} size={0.4} color="#fbbf24" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
