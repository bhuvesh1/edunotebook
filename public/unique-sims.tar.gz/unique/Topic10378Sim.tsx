"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "bite", label: "Bite force", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.4, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Periodontal ligament: structure and functions",
  blurb: "The tooth hangs in its socket on thousands of tiny ligament fibers — bite down and watch them stretch and cushion the load.",
};

// Fiber anchor data: angle around root, height, direction tilt
function useFibers() {
  return useMemo(() => {
    const arr: { a: number; y: number; tilt: number }[] = [];
    for (let i = 0; i < 64; i++) {
      const a = (i / 64) * Math.PI * 2 + (i % 3) * 0.1;
      const y = -2.6 + (i % 8) * 0.62;
      // fiber groups: crestal (up), horizontal, oblique (down-out), apical
      const tilt = y > -0.8 ? -0.7 : y > -2.2 ? 0.15 : 0.75;
      arr.push({ a, y, tilt });
    }
    return arr;
  }, []);
}

function PDLScene({ bite, speed, showLabels }: { bite: number; speed: number; showLabels: boolean }) {
  const tooth = useRef<THREE.Group>(null!);
  const fibers = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const list = useFibers();

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    // rhythmic chewing: tooth pumps down, fibers stretch
    const chew = 0.5 + 0.5 * Math.sin(elapsed.current * 3.2);
    const press = bite * chew;
    if (tooth.current) tooth.current.position.y = -press * 0.35;
    if (fibers.current) {
      fibers.current.children.forEach((f, i) => {
        const base = 0.85;
        f.scale.y = base + press * 0.5;
        ((f as THREE.Mesh).material as THREE.MeshBasicMaterial).opacity = 0.55 + press * 0.4;
      });
    }
  });

  return (
    <group>
      {/* alveolar bone socket */}
      <mesh position={[0, -1.6, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[2.3, 2.0, 4.4, 28, 1, true]} />
        <meshStandardMaterial color="#e7e5e4" roughness={0.75} side={THREE.DoubleSide} />
      </mesh>
      {/* bone base */}
      <mesh position={[0, -3.9, 0]} castShadow>
        <cylinderGeometry args={[2.6, 2.6, 0.6, 28]} />
        <meshStandardMaterial color="#d6d3d1" roughness={0.75} />
      </mesh>
      {/* gum collar */}
      <mesh position={[0, 0.75, 0]} castShadow>
        <torusGeometry args={[1.55, 0.55, 12, 28]} />
        <meshStandardMaterial color="#e88ca0" roughness={0.6} />
      </mesh>

      {/* the tooth, suspended */}
      <group ref={tooth}>
        <mesh position={[0, 2.1, 0]} castShadow>
          <boxGeometry args={[2, 1.6, 1.8]} />
          <meshStandardMaterial color="#fef9c3" roughness={0.25} />
        </mesh>
        <mesh position={[0, -1.4, 0]} castShadow>
          <cylinderGeometry args={[1.1, 0.4, 4.4, 18]} />
          <meshStandardMaterial color="#fdba74" roughness={0.5} />
        </mesh>
      </group>

      {/* PDL fibers spanning the gap */}
      <group ref={fibers}>
        {list.map((f, i) => {
          const r0 = 1.15;
          const r1 = 2.15;
          const x0 = Math.cos(f.a) * r0, z0 = Math.sin(f.a) * r0;
          const x1 = Math.cos(f.a) * r1, z1 = Math.sin(f.a) * r1;
          const y1 = f.y + f.tilt * 0.9;
          const from = new THREE.Vector3(x0, f.y, z0);
          const to = new THREE.Vector3(x1, y1, z1);
          const mid = from.clone().add(to).multiplyScalar(0.5);
          const len = from.distanceTo(to);
          const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), to.clone().sub(from).normalize());
          return (
            <mesh key={i} position={mid} quaternion={quat}>
              <cylinderGeometry args={[0.028, 0.028, len, 5]} />
              <meshBasicMaterial color="#fef3c7" transparent opacity={0.55} />
            </mesh>
          );
        })}
      </group>

      {/* force arrows on the crown when biting */}
      {bite > 0.05 && (
        <group position={[0, 3.6, 0]}>
          <mesh>
            <cylinderGeometry args={[0.08, 0.08, 1.1, 8]} />
            <meshBasicMaterial color="#f87171" />
          </mesh>
          <mesh position={[0, -0.7, 0]} rotation={[Math.PI, 0, 0]}>
            <coneGeometry args={[0.2, 0.45, 8]} />
            <meshBasicMaterial color="#f87171" />
          </mesh>
        </group>
      )}

      {showLabels && (
        <>
          <Text position={[3.9, -1.4, 0]} fontSize={0.4} color="#fef3c7" maxWidth={4}>PDL fibers — shock absorbers</Text>
          <Text position={[-3.9, -1.6, 0]} fontSize={0.4} color="#e7e5e4">Alveolar bone</Text>
          <Text position={[0, 4.9, 0]} fontSize={0.44} color="#fef3c7" maxWidth={10}>
            {bite < 0.15 ? "At rest the tooth floats in its socket" : "Biting: fibers stretch, cushion, and signal pressure"}
          </Text>
        </>
      )}
    </group>
  );
}

export function Topic10378Sim(props: SimProps) {
  const bite = Number(props.bite ?? 0.4);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Bite force", `${Math.round(bite * 100)}%`],
          ["PDL width", "0.15–0.38 mm"],
          ["Jobs", "support · cushion · proprioception"],
        ]}
      />
      <SimCanvas cameraPosition={[7, 3, 10]} target={[0, -0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -4.3, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <PDLScene bite={bite} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
