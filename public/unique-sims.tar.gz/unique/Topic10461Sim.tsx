"use client";
// Malocclusion: Angle's Classification — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cls", label: "Angle's class", kind: "select", min: 0, max: 0, step: 1, default: "Class I", options: ["Class I", "Class II", "Class III"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Malocclusion: Angle's Classification",
  blurb: "Pick Class I, II or III and watch the upper and lower tooth rows slide into that bite relationship.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const up: any = g("upper");
    const lo: any = g("lower");
    const tU = p.cls === "Class II" ? 0.85 : 0;
    const tL = p.cls === "Class III" ? 0.85 : 0;
    if (up) up.position.x += (tU - up.position.x) * 0.08;
    if (lo) lo.position.x += (tL - lo.position.x) * 0.08;
    group.current.rotation.y = Math.sin(t * 0.2) * 0.15;
  });
  return null;
}

export function Topic10461Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const cls = String(props.cls ?? "Class I");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, cls };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Class", cls],
          ["Molar relation", cls === "Class I" ? "Normal" : cls === "Class II" ? "Lower back (overjet)" : "Lower forward (underbite)"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <group name="upper" position={[0, 0, 0]}>
            {[-2, -1, 0, 1, 2].map((i) => (
              <mesh key={i} position={[i * 0.95, 2.6, 0]}>
                <boxGeometry args={[0.8, 1, 0.8]} />
                <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
              </mesh>
            ))}
            <Label text="Upper teeth" position={[-3.4, 2.6, 0]} size={0.42} />
          </group>
          <group name="lower" position={[0, 0, 0]}>
            {[-2, -1, 0, 1, 2].map((i) => (
              <mesh key={i} position={[i * 0.95, 1.35, 0]}>
                <boxGeometry args={[0.8, 1, 0.8]} />
                <meshStandardMaterial color="#e9e2cc" roughness={0.4} />
              </mesh>
            ))}
            <Label text="Lower teeth" position={[3.4, 1.35, 0]} size={0.42} />
          </group>
          <Label text="Class I: cusps meet evenly" position={[0, 3.9, 0]} size={0.42} color="#22c55e" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
