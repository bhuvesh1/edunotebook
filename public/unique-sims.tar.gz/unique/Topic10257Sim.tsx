// Pediatric surgery basics: common congenital anomalies.
// A newborn with simplified internal organs. Select an anomaly to see the
// defect highlighted: disconnected esophagus, blocked duodenum (double bubble),
// or abdominal organs herniated into the chest.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "anomaly", label: "Anomaly", kind: "select", min: 0, max: 0, step: 1, default: "duodenal_atresia", options: ["normal", "esophageal_atresia", "duodenal_atresia", "diaphragmatic_hernia"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Newborn: Congenital Anomalies",
  blurb: "See inside a newborn's body — a disconnected food pipe, a blocked intestine's double bubble, or organs herniated into the chest.",
};

function Animator({
  group, marker, elapsed, speed,
}: {
  group: React.RefObject<THREE.Group>;
  marker: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    if (marker.current) {
      marker.current.children.forEach((m, i) => {
        (m as THREE.Mesh).scale.setScalar(1 + 0.25 * Math.sin(t * 4 + i * 2));
      });
    }
  });
  return null;
}

export function Topic10257Sim(props: SimProps) {
  const anomaly = String(props.anomaly ?? "duodenal_atresia");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const marker = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    normal: "Normal newborn anatomy",
    esophageal_atresia: "Esophageal atresia + TEF",
    duodenal_atresia: "Duodenal atresia (double bubble)",
    diaphragmatic_hernia: "Diaphragmatic hernia",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Anomaly", names[anomaly] ?? anomaly], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.6, 10]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* baby: head + torso (semi-transparent so organs show) */}
          <mesh position={[0, 4.3, 0]} castShadow>
            <sphereGeometry args={[0.85, 28, 20]} />
            <meshStandardMaterial color="#f5c396" roughness={0.6} transparent opacity={0.55} />
          </mesh>
          <mesh position={[0, 2.2, 0]} scale={[1, 1.5, 0.8]} castShadow>
            <sphereGeometry args={[1.15, 28, 20]} />
            <meshStandardMaterial color="#f5c396" roughness={0.6} transparent opacity={0.35} />
          </mesh>
          {/* lungs */}
          {[-0.55, 0.55].map((x) => (
            <mesh key={x} position={[x, 2.9, 0.15]} scale={[0.7, 1.0, 0.55]} castShadow>
              <sphereGeometry args={[0.5, 20, 14]} />
              <meshStandardMaterial color="#fda4af" roughness={0.5} />
            </mesh>
          ))}
          {/* esophagus: full tube, or two blind ends (atresia) */}
          {anomaly === "esophageal_atresia" ? (
            <>
              <mesh position={[0, 3.7, 0.35]} castShadow>
                <cylinderGeometry args={[0.11, 0.13, 0.8, 12]} />
                <meshStandardMaterial color="#f0abfc" roughness={0.5} />
              </mesh>
              <mesh position={[0, 2.55, 0.35]} castShadow>
                <cylinderGeometry args={[0.13, 0.11, 0.5, 12]} />
                <meshStandardMaterial color="#f0abfc" roughness={0.5} />
              </mesh>
              {/* fistula to windpipe */}
              <mesh position={[0.14, 3.05, 0.3]} rotation={[0, 0, 1.1]} castShadow>
                <cylinderGeometry args={[0.06, 0.06, 0.5, 8]} />
                <meshStandardMaterial color="#ef4444" roughness={0.5} />
              </mesh>
            </>
          ) : (
            <mesh position={[0, 3.15, 0.35]} castShadow>
              <cylinderGeometry args={[0.11, 0.11, 2.1, 12]} />
              <meshStandardMaterial color="#f0abfc" roughness={0.5} />
            </mesh>
          )}
          {/* stomach: single bubble, or double bubble when duodenum blocked */}
          <mesh position={[-0.35, 1.9, 0.35]} scale={[1, 0.85, 0.7]} castShadow>
            <sphereGeometry args={[0.42, 20, 14]} />
            <meshStandardMaterial color={anomaly === "diaphragmatic_hernia" ? "#f0abfc" : "#fb923c"} roughness={0.5} />
          </mesh>
          {anomaly === "duodenal_atresia" && (
            <mesh position={[0.35, 1.9, 0.35]} scale={[1, 0.85, 0.7]} castShadow>
              <sphereGeometry args={[0.4, 20, 14]} />
              <meshStandardMaterial color="#fb923c" roughness={0.5} emissive="#c2410c" emissiveIntensity={0.4} />
            </mesh>
          )}
          {/* intestines coil */}
          <mesh position={[0, 1.15, 0.3]} castShadow>
            <torusGeometry args={[0.42, 0.16, 12, 24]} />
            <meshStandardMaterial color="#fcd34d" roughness={0.5} />
          </mesh>
          {/* hernia: bowel loops pushed up into the chest */}
          {anomaly === "diaphragmatic_hernia" && (
            <>
              <mesh position={[0.5, 2.9, 0.35]} castShadow>
                <torusGeometry args={[0.3, 0.14, 12, 20]} />
                <meshStandardMaterial color="#fcd34d" roughness={0.5} emissive="#a16207" emissiveIntensity={0.5} />
              </mesh>
              <mesh position={[-0.2, 2.45, 0.35]} rotation={[0.4, 0, 0.4]} castShadow>
                <torusGeometry args={[0.26, 0.13, 12, 20]} />
                <meshStandardMaterial color="#fcd34d" roughness={0.5} emissive="#a16207" emissiveIntensity={0.5} />
              </mesh>
            </>
          )}
          {/* pulsing defect markers */}
          <group ref={marker}>
            {anomaly === "esophageal_atresia" && (
              <mesh position={[0, 3.25, 0.7]}>
                <sphereGeometry args={[0.22, 14, 10]} />
                <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={1} transparent opacity={0.85} />
              </mesh>
            )}
            {anomaly === "duodenal_atresia" && (
              <mesh position={[0, 1.9, 0.7]}>
                <sphereGeometry args={[0.24, 14, 10]} />
                <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={1} transparent opacity={0.85} />
              </mesh>
            )}
            {anomaly === "diaphragmatic_hernia" && (
              <mesh position={[0.3, 2.7, 0.7]}>
                <sphereGeometry args={[0.24, 14, 10]} />
                <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={1} transparent opacity={0.85} />
              </mesh>
            )}
          </group>
          <Label text="Windpipe" position={[1.6, 3.4, 0.3]} size={0.5} color="#bae6fd" />
          <Label text="Stomach" position={[-1.7, 1.9, 0.35]} size={0.5} color="#fdba74" />
          {anomaly === "duodenal_atresia" && <Label text="⚠ Double bubble: blocked duodenum" position={[0, 0.7, 0.4]} size={0.55} color="#fca5a5" />}
          {anomaly === "esophageal_atresia" && <Label text="⚠ Food pipe ends blindly" position={[1.9, 2.9, 0.4]} size={0.55} color="#fca5a5" />}
          {anomaly === "diaphragmatic_hernia" && <Label text="⚠ Bowel in the chest!" position={[1.8, 2.2, 0.4]} size={0.55} color="#fca5a5" />}
          {anomaly === "normal" && <Label text="All connected ✓" position={[0, 0.75, 0.4]} size={0.55} color="#86efac" />}
        </group>
        <Animator group={group} marker={marker} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
