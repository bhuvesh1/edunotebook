// Endocrine: pituitary & thyroid — the pituitary (pea under the brain) pulses
// TSH; the butterfly thyroid answers with T3/T4; high thyroid hormone feeds
// back to quiet the pituitary.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "tsh", label: "TSH drive", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "feedback", label: "Negative feedback", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Endocrine: Pituitary → Thyroid Axis",
  blurb: "The pituitary pulses TSH, the thyroid answers with T3/T4 — and negative feedback keeps the loop balanced.",
};

function Animator({
  tshPulses, t4pulses, pituitary, thyroid, elapsed, tsh, feedback, speed,
}: {
  tshPulses: React.RefObject<THREE.Group>;
  t4pulses: React.RefObject<THREE.Group>;
  pituitary: React.RefObject<THREE.Mesh>;
  thyroid: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  tsh: number;
  feedback: boolean;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // feedback: high T4 output damps TSH pulse rate
    const effTsh = feedback ? tsh / (1 + 0.6 * tsh) : tsh;
    if (tshPulses.current) {
      tshPulses.current.children.forEach((m, i) => {
        const ph = ((t * 0.4 * effTsh + i / 6) % 1 + 1) % 1;
        m.position.y = 4.6 - ph * 4.4;
        m.visible = effTsh > 0.02;
      });
    }
    if (t4pulses.current) {
      t4pulses.current.children.forEach((m, i) => {
        const ph = ((t * 0.35 * tsh + i / 8) % 1 + 1) % 1;
        const a = ph * Math.PI * 2;
        m.position.x = 2.6 + Math.cos(a) * 1.6;
        m.position.y = 1.6 + Math.sin(a) * 1.2;
        m.visible = tsh > 0.02;
      });
    }
    if (pituitary.current) {
      const s = 1 + 0.14 * Math.sin(t * 3 * effTsh);
      pituitary.current.scale.setScalar(s);
    }
    if (thyroid.current) {
      const s = 1 + 0.06 * Math.sin(t * 2.4);
      thyroid.current.scale.setScalar(s);
    }
  });
  return null;
}

export function Topic10047Sim(props: SimProps) {
  const tsh = Number(props.tsh ?? 1);
  const feedback = String(props.feedback ?? "on") === "on";
  const speed = 1;
  const tshPulses = useRef<THREE.Group>(null!);
  const t4pulses = useRef<THREE.Group>(null!);
  const pituitary = useRef<THREE.Mesh>(null!);
  const thyroid = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const effTsh = feedback ? tsh / (1 + 0.6 * tsh) : tsh;
  const axisState = tsh < 0.4 ? "hypothyroid pattern (low drive)" : tsh > 1.5 && !feedback ? "hyperthyroid pattern (no brake)" : "euthyroid ✓";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Axis state", axisState],
          ["Feedback", feedback ? "T3/T4 ⊣ pituitary ✓" : "disabled"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5, 14]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* brain + pituitary */}
        <group position={[-3.5, 0, 0]}>
          <mesh position={[0, 5.6, 0]} castShadow scale={[1.25, 0.9, 1]}>
            <sphereGeometry args={[1.5, 22, 22]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
          </mesh>
          {/* hypothalamus */}
          <mesh position={[0, 4.55, 0]}>
            <sphereGeometry args={[0.3, 12, 12]} />
            <meshStandardMaterial color="#c084fc" roughness={0.45} />
          </mesh>
          <Label text="hypothalamus (TRH)" position={[-2.2, 4.55, 0]} size={0.28} color="#d8b4fe" />
          {/* pituitary stalk + gland */}
          <mesh position={[0, 4.1, 0]} castShadow>
            <cylinderGeometry args={[0.12, 0.12, 0.7, 8]} />
            <meshStandardMaterial color="#f472b6" roughness={0.5} />
          </mesh>
          <mesh ref={pituitary} position={[0, 3.6, 0]} castShadow>
            <sphereGeometry args={[0.42, 16, 16]} />
            <meshStandardMaterial color="#e879f9" emissive="#701a75" emissiveIntensity={0.5} roughness={0.4} />
          </mesh>
        </group>
        <Label text="pituitary gland" position={[-3.5, 2.85, 0]} size={0.38} color="#f8fafc" />
        <Label text="brain" position={[-3.5, 7.2, 0]} size={0.32} color="#f9a8d4" />

        {/* TSH pulses travelling down */}
        <group ref={tshPulses}>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[-3.5, 4.6, 0]}>
              <sphereGeometry args={[0.12, 8, 8]} />
              <meshBasicMaterial color="#e879f9" />
            </mesh>
          ))}
        </group>
        <Arrow from={[-2.6, 3.4, 0]} to={[-0.4, 2.2, 0]} color="#e879f9" radius={0.06} />
        <Label text="TSH" position={[-1.5, 3.3, 0]} size={0.36} color="#f0abfc" />

        {/* thyroid: butterfly in the neck */}
        <group position={[2.6, 0, 0]}>
          {/* trachea */}
          <mesh position={[0, 1.6, -0.5]} castShadow>
            <cylinderGeometry args={[0.4, 0.4, 3.2, 12]} />
            <meshStandardMaterial color="#c084fc" roughness={0.5} />
          </mesh>
          <group ref={thyroid}>
            {[-1, 1].map((s) => (
              <mesh key={s} position={[s * 0.75, 1.6, 0.1]} castShadow scale={[1, 1.35, 0.7]}>
                <sphereGeometry args={[0.55, 16, 16]} />
                <meshStandardMaterial color="#f472b6" roughness={0.45} />
              </mesh>
            ))}
            <mesh position={[0, 2.3, 0.1]} rotation={[0, 0, Math.PI / 2]} castShadow>
              <cylinderGeometry args={[0.16, 0.16, 1.0, 8]} />
              <meshStandardMaterial color="#f472b6" roughness={0.45} />
            </mesh>
          </group>
        </group>
        {/* T3/T4 released into circulation */}
        <group ref={t4pulses}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[2.6, 1.6, 0]}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshBasicMaterial color="#fbbf24" />
            </mesh>
          ))}
        </group>
        <Label text="thyroid (butterfly)" position={[2.6, 0.35, 0]} size={0.38} color="#f8fafc" />
        <Label text="T3 / T4 released" position={[5.2, 1.6, 0]} size={0.32} color="#fde68a" />

        {/* negative feedback arrow back up */}
        {feedback && (
          <group>
            <Arrow from={[4.6, 2.8, 0]} to={[-2.4, 4.9, 0]} color="#4ade80" radius={0.05} />
            <Label text="negative feedback ⊣" position={[1.2, 4.6, 0]} size={0.32} color="#86efac" />
          </group>
        )}

        <Animator tshPulses={tshPulses} t4pulses={t4pulses} pituitary={pituitary}
          thyroid={thyroid} elapsed={elapsed} tsh={tsh} feedback={feedback} speed={speed} />
      </SimCanvas>
    </div>
  );
}
