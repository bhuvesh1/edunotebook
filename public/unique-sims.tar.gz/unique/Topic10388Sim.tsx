"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "product", label: "Gypsum product", kind: "select", min: 0, max: 0, step: 1, default: "stone", options: ["plaster", "stone", "die-stone"] },
  { key: "pour", label: "Pour progress", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.55, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Gypsum products: plaster, stone, die materials",
  blurb: "Pour mixed gypsum into an impression — plaster for study models, dense die stone for precision crowns.",
};

const PRODS: Record<string, { name: string; color: string; use: string; wp: string }> = {
  plaster: { name: "Plaster (Type II)", color: "#fefce8", use: "study models, articulators", wp: "W:P ≈ 0.45–0.50" },
  stone: { name: "Dental stone (Type III)", color: "#fde68a", use: "working casts", wp: "W:P ≈ 0.28–0.30" },
  "die-stone": { name: "Die stone (Type IV/V)", color: "#fdba74", use: "precision dies for crowns", wp: "W:P ≈ 0.22–0.24" },
};

function GypsumScene({ product, pour, speed, showLabels }: { product: string; pour: number; speed: number; showLabels: boolean }) {
  const stream = useRef<THREE.Mesh>(null!);
  const level = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const cfg = PRODS[product] ?? PRODS.stone;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (stream.current) {
      stream.current.visible = pour > 0.02 && pour < 0.98;
      stream.current.scale.y = 1 + Math.sin(elapsed.current * 25) * 0.04;
    }
    if (level.current) {
      const h = Math.max(0.02, pour * 1.7);
      level.current.scale.y = h;
      level.current.position.y = -1.05 + h / 2;
    }
  });

  return (
    <group>
      {/* rubber mixing bowl */}
      <mesh position={[-4.2, 3.4, 0]} castShadow>
        <cylinderGeometry args={[1.5, 1.0, 1.4, 24, 1, true]} />
        <meshStandardMaterial color="#f97316" roughness={0.6} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[-4.2, 2.75, 0]}>
        <circleGeometry args={[1.0, 24]} />
        <meshStandardMaterial color="#c2410c" roughness={0.7} />
      </mesh>
      {/* spatula stirring */}
      <group position={[-4.2, 3.9, 0]} rotation={[0.3, 0, 0.5 + Math.sin(elapsed.current * 0) * 0]}>
        <Stirrer speed={speed} />
      </group>

      {/* impression mold (inverted arch) */}
      <group position={[1.2, 0, 0]}>
        <mesh castShadow>
          <boxGeometry args={[5.4, 0.5, 4.2]} />
          <meshStandardMaterial color="#94a3b8" metalness={0.6} roughness={0.4} />
        </mesh>
        {/* mold cavity walls */}
        {[-2.45, 2.45].map((x, i) => (
          <mesh key={"x" + i} position={[x, 0.85, 0]} castShadow>
            <boxGeometry args={[0.5, 1.7, 4.2]} />
            <meshStandardMaterial color="#cbd5e1" roughness={0.5} />
          </mesh>
        ))}
        {[-1.85, 1.85].map((z, i) => (
          <mesh key={"z" + i} position={[0, 0.85, z]} castShadow>
            <boxGeometry args={[4.4, 1.7, 0.5]} />
            <meshStandardMaterial color="#cbd5e1" roughness={0.5} />
          </mesh>
        ))}
        {/* rising gypsum level */}
        <mesh ref={level} position={[0, -1.05, 0]}>
          <boxGeometry args={[4.4, 1, 3.2]} />
          <meshStandardMaterial color={cfg.color} roughness={0.85} />
        </mesh>
        {/* tooth sockets pressed into the setting top */}
        {pour > 0.6 &&
          Array.from({ length: 5 }).map((_, i) => (
            <mesh key={i} position={[-1.6 + i * 0.8, 0.75 + pour * 0.9, 0]} castShadow>
              <boxGeometry args={[0.55, 0.5, 0.55]} />
              <meshStandardMaterial color="#fef9c3" roughness={0.25} />
            </mesh>
          ))}
      </group>

      {/* pour stream from bowl */}
      <mesh ref={stream} position={[-1.6, 2.6, 0]} rotation={[0, 0, 0.7]} castShadow>
        <cylinderGeometry args={[0.16, 0.22, 4.4, 10]} />
        <meshStandardMaterial color={cfg.color} roughness={0.6} />
      </mesh>

      {showLabels && (
        <>
          <Text position={[-4.2, 5.2, 0]} fontSize={0.42} color="#fdba74">Mixing bowl — spatulate 1 min</Text>
          <Text position={[1.2, 3.4, 0]} fontSize={0.42} color="#fef3c7">{cfg.name}</Text>
          <Text position={[1.2, -2.4, 0]} fontSize={0.4} color="#e2e8f0" maxWidth={10}>
            {pour < 0.5 ? "Pour slowly — vibrate out air bubbles" : "Setting: gypsum crystals interlock (exothermic!)"}
          </Text>
          <Text position={[6.8, 0.6, 0]} fontSize={0.38} color="#fde68a" maxWidth={4}>{cfg.wp} — {cfg.use}</Text>
        </>
      )}
    </group>
  );
}

function Stirrer({ speed }: { speed: number }) {
  const s = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (s.current) s.current.rotation.y = elapsed.current * 3;
  });
  return (
    <group ref={s}>
      <mesh castShadow>
        <cylinderGeometry args={[0.09, 0.09, 2.2, 8]} />
        <meshStandardMaterial color="#e7e5e4" roughness={0.4} />
      </mesh>
      <mesh position={[0, -1.2, 0]}>
        <boxGeometry args={[0.5, 0.7, 0.12]} />
        <meshStandardMaterial color="#d6d3d1" roughness={0.4} />
      </mesh>
    </group>
  );
}

export function Topic10388Sim(props: SimProps) {
  const product = String(props.product ?? "stone");
  const pour = Number(props.pour ?? 0.55);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = PRODS[product] ?? PRODS.stone;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Product", cfg.name],
          ["Water:powder", cfg.wp],
          ["Use", cfg.use],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 13]} target={[0, 0.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.2, 0]} receiveShadow>
          <planeGeometry args={[36, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <GypsumScene product={product} pour={pour} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
