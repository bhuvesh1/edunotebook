// Rabies, polio & oncogenic viruses: after the bite, rabies virions climb the
// nerve fibre relentlessly toward the brain — speed depends on the bite's
// distance.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dist", label: "Bite distance from brain", kind: "slider", min: 1, max: 10, step: 1, default: 6, unit: "" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Rabies, polio & oncogenic viruses",
  blurb: "After the bite, rabies virions climb the nerve toward the brain — wash the wound, vaccinate fast.",
};

const N_RAB = 9;

function Animator({ rab, brain, elapsed, dist, setTick }: {
  rab: React.RefObject<(THREE.Mesh | null)[]>;
  brain: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  dist: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const speed = 11 - dist; // closer bite = faster arrival
    let arrived = 0;
    rab.current.forEach((r, i) => {
      if (!r) return;
      const f = (t * 0.06 * speed + i / N_RAB) % 1;
      // travel along the nerve from leg (x=-5) to brain (x=4.5)
      r.position.set(-5 + f * 9.5, 1.1 + Math.sin(f * Math.PI) * 0.9, Math.sin(i * 2.2) * 0.25);
      r.rotation.y = t * 4 + i;
      if (f > 0.96) arrived++;
    });
    if (brain.current) {
      const m = brain.current.material as THREE.MeshStandardMaterial;
      const infected = arrived > 0;
      m.emissive.set(infected ? "#ef4444" : "#000000");
      m.emissiveIntensity = infected ? 0.5 + Math.sin(t * 6) * 0.3 : 0;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(arrived); }
  });
  return null;
}

export function Topic10140Sim(props: SimProps) {
  const dist = Number(props.dist ?? 6);
  const showLabels = String(props.detail ?? "on") === "on";
  const rab = useRef<(THREE.Mesh | null)[]>([]);
  const brain = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const days = Math.round(dist * 9);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Incubation ≈", `${days} days`],
          ["Virions at brain", `${tick}`],
          ["Action", "wash wound + PEP vaccine NOW"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 13]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* leg with bite wound */}
        <mesh position={[-5, 1.1, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <capsuleGeometry args={[0.4, 1.6, 8, 12]} />
          <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
        </mesh>
        <mesh position={[-5, 1.55, 0.25]}>
          <sphereGeometry args={[0.18, 10, 8]} />
          <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={0.9} />
        </mesh>
        {showLabels && <Label text="animal bite wound" position={[-5, 2.4, 0]} size={0.45} color="#fca5a5" />}

        {/* nerve fibre to the brain */}
        <mesh position={[-0.25, 1.35, 0]} rotation={[0, 0, Math.PI / 2 - 0.12]} castShadow>
          <cylinderGeometry args={[0.14, 0.14, 9.8, 10]} />
          <meshStandardMaterial color="#facc15" roughness={0.5} />
        </mesh>
        {showLabels && <Label text="peripheral nerve — virus climbs" position={[-0.25, 0.6, 0]} size={0.45} color="#fde047" />}

        {/* rabies virions: bullet-shaped */}
        {Array.from({ length: N_RAB }).map((_, i) => (
          <group key={i} ref={(m) => { rab.current[i] = m as unknown as THREE.Mesh; }}>
            <mesh rotation={[0, 0, -Math.PI / 2]} castShadow>
              <capsuleGeometry args={[0.13, 0.3, 6, 10]} />
              <meshStandardMaterial color="#a78bfa" emissive="#6d28d9" emissiveIntensity={0.9} />
            </mesh>
          </group>
        ))}
        {showLabels && <Label text="rabies virions (bullet-shaped)" position={[-2.6, 2.9, 0]} size={0.45} color="#c4b5fd" />}

        {/* brain */}
        <mesh ref={brain} position={[4.6, 2.2, 0]} castShadow>
          <sphereGeometry args={[1.0, 22, 16]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
        </mesh>
        {showLabels && <Label text="brain — encephalitis" position={[4.6, 3.7, 0]} color="#f9a8d4" />}

        {/* vaccine syringe */}
        <group position={[1.8, 0, 2.2]}>
          <mesh position={[0, 0.8, 0]} rotation={[0, 0, 0.6]} castShadow>
            <cylinderGeometry args={[0.15, 0.15, 1.2, 12]} />
            <meshStandardMaterial color="#e0f2fe" transparent opacity={0.85} />
          </mesh>
          <mesh position={[0.32, 1.25, 0]} rotation={[0, 0, 0.6]}>
            <cylinderGeometry args={[0.035, 0.035, 0.5, 8]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.6} roughness={0.3} />
          </mesh>
        </group>
        {showLabels && <Label text="PEP vaccine — before symptoms!" position={[1.8, 2, 2.2]} size={0.4} color="#7dd3fc" />}

        <Animator rab={rab} brain={brain} elapsed={elapsed} dist={dist} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
