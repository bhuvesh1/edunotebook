"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "TCA Cycle (Krebs)",
  blurb: "Acetyl-CoA feeds the spinning 8-step citric-acid cycle while CO2 bubbles off and a pulse marks each turn.",
};

const STEPS: [string, string][] = [["Citrate","#4ade80"],["Isocitrate","#a3e635"],["\u03b1-Ketoglutarate","#facc15"],["Succinyl-CoA","#fb923c"],["Succinate","#f87171"],["Fumarate","#e879f9"],["Malate","#60a5fa"],["Oxaloacetate","#38bdf8"]];

function Animator({ root, pulse, acoa, co2, elapsed, speed }: { root: RefObject<THREE.Group>; pulse: RefObject<THREE.Mesh>; acoa: RefObject<THREE.Group>; co2: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (root.current) root.current.rotation.y = Math.sin(t * 0.25) * 0.2;
    const pa = t * 0.8;
    if (pulse.current) pulse.current.position.set(Math.cos(pa) * 3, 1.8, Math.sin(pa) * 3);
    if (acoa.current) {
      const q = (t * 0.5) % 1;
      acoa.current.position.set(7 - q * 4.4, 1.8, 0);
      acoa.current.visible = q < 0.92;
    }
    if (co2.current) {
      co2.current.children.forEach((m, i) => {
        const r = (t * 0.6 + i / 4) % 1;
        const a = (2 / 8) * Math.PI * 2;
        m.position.set(Math.cos(a) * 3 + (i % 2) * 0.3 - 0.15, 1.8 + r * 2.2, Math.sin(a) * 3);
      });
    }
  });
  return null;
}

export function Topic10064Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const pulse = useRef<THREE.Mesh>(null!);
  const acoa = useRef<THREE.Group>(null!);
  const co2 = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Steps", "8"],
          ["Yield / turn", "3 NADH \u00b7 FADH\u2082 \u00b7 GTP"],
          ["Site", "mitochondrial matrix"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 11]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          {STEPS.map(([name, color], i) => {
            const a = (i / 8) * Math.PI * 2;
            const mid = a + Math.PI / 8;
            return (
              <group key={name}>
                <mesh position={[Math.cos(a) * 3, 1.8, Math.sin(a) * 3]} castShadow>
                  <sphereGeometry args={[0.42, 20, 20]} /><meshStandardMaterial color={color} roughness={0.4} />
                </mesh>
                {(i % 2 === 0) && <Label text={name} position={[Math.cos(a) * 3, 2.7, Math.sin(a) * 3]} size={0.4} color={color} />}
                <group position={[Math.cos(mid) * 3, 1.8, Math.sin(mid) * 3]} rotation={[0, -(mid + Math.PI / 2), 0]}>
                  <mesh rotation={[0, 0, -Math.PI / 2]} position={[0.25, 0, 0]}>
                    <coneGeometry args={[0.14, 0.4, 10]} /><meshStandardMaterial color="#94a3b8" />
                  </mesh>
                </group>
              </group>
            );
          })}
          <mesh ref={pulse}>
            <sphereGeometry args={[0.2, 14, 14]} /><meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={2.5} />
          </mesh>
          <group ref={acoa}>
            <mesh><sphereGeometry args={[0.3, 16, 16]} /><meshStandardMaterial color="#4ade80" emissive="#22c55e" emissiveIntensity={1} /></mesh>
            <Label text="acetyl-CoA" position={[0, 0.7, 0]} size={0.4} color="#4ade80" />
          </group>
          <group ref={co2}>
            {Array.from({ length: 4 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.14, 10, 10]} /><meshStandardMaterial color="#9ca3af" transparent opacity={0.85} /></mesh>
            ))}
          </group>
          <Label text="CO\u2082 released" position={[2.6, 4.4, 1.4]} size={0.4} color="#9ca3af" />
        </group>
        <Animator root={root} pulse={pulse} acoa={acoa} co2={co2} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
