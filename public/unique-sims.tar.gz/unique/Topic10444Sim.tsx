"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "bclass", label: "Black's class", kind: "select", min: 0, max: 0, step: 1, default: "I", options: ["I", "II", "III", "IV", "V", "VI"] },
  { key: "cut", label: "Cutting progress", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
];

export const UNIQUE_META = {
  title: "Cavity preparation: principles, Black's classification",
  blurb: "G.V. Black's six cavity classes drawn on a tooth — the bur cuts the glowing outline deeper as you slide progress.",
};

const CLASSES: Record<string, { name: string; outline: [number, number, number]; shape: string; note: string }> = {
  I: { name: "Class I", outline: [0, 1.42, 0], shape: "pit", note: "Pits & fissures of molars" },
  II: { name: "Class II", outline: [0.75, 1.1, 0], shape: "box", note: "Back teeth, side surface + top" },
  III: { name: "Class III", outline: [0, 0.9, 0.95], shape: "slot", note: "Front teeth sides, no edge" },
  IV: { name: "Class IV", outline: [0, 1.15, 0.95], shape: "corner", note: "Front tooth corner broken" },
  V: { name: "Class V", outline: [0, 0.15, 0.95], shape: "cervical", note: "Near the gumline" },
  VI: { name: "Class VI", outline: [0, 1.0, -0.95], shape: "cusp", note: "Cusp tips worn down" },
};

function Scene({ bclass, cut }: { bclass: string; cut: number }) {
  const bur = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const c = CLASSES[bclass] ?? CLASSES.I;
  const depth = (cut / 100) * 0.5;

  useFrame((_, delta) => {
    t.current += delta;
    if (bur.current) {
      bur.current.position.x = c.outline[0] + 0.9 + Math.sin(t.current * 2) * 0.2;
      bur.current.position.y = c.outline[1] + 1.2;
      bur.current.rotation.y = t.current * 25;
    }
  });

  return (
    <group>
      {/* molar */}
      <mesh position={[0, 0.6, 0]}>
        <cylinderGeometry args={[1.05, 1.25, 1.5, 20]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.25} />
      </mesh>
      {/* cusps */}
      {[[-0.5, -0.5], [0.5, -0.5], [-0.5, 0.5], [0.5, 0.5]].map(([x, z], i) => (
        <mesh key={i} position={[x, 1.45, z]}>
          <coneGeometry args={[0.3, 0.35, 4]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.3} flatShading />
        </mesh>
      ))}
      <mesh position={[0, -0.9, 0]}>
        <coneGeometry args={[0.85, 1.5, 18]} />
        <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
      </mesh>

      {/* glowing outline of the class */}
      <mesh position={c.outline}>
        {c.shape === "pit" && <cylinderGeometry args={[0.32, 0.32, 0.12 + depth, 14]} />}
        {c.shape === "box" && <boxGeometry args={[0.6, 0.5 + depth, 0.7]} />}
        {c.shape === "slot" && <boxGeometry args={[0.4, 0.6 + depth, 0.3]} />}
        {c.shape === "corner" && <boxGeometry args={[0.5, 0.55 + depth, 0.35]} />}
        {c.shape === "cervical" && <boxGeometry args={[0.7, 0.4 + depth, 0.3]} />}
        {c.shape === "cusp" && <cylinderGeometry args={[0.3, 0.35, 0.3 + depth, 12]} />}
        <meshStandardMaterial color="#38bdf8" emissive="#0ea5e9" emissiveIntensity={1.1} transparent opacity={0.85} />
      </mesh>

      {/* bur cutting */}
      <group ref={bur} position={[c.outline[0] + 0.9, c.outline[1] + 1.2, c.outline[2]]}>
        <mesh position={[0, 0.45, 0]}>
          <cylinderGeometry args={[0.08, 0.08, 0.9, 8]} />
          <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
        </mesh>
        <mesh position={[0, -0.15, 0]}>
          <cylinderGeometry args={[0.12, 0.09, 0.45, 10]} />
          <meshStandardMaterial color="#fde047" metalness={0.5} roughness={0.4} />
        </mesh>
      </group>

      {/* class legend chips */}
      <group position={[0, -2.5, 0]}>
        {Object.keys(CLASSES).map((k, i) => (
          <mesh key={k} position={[-2.5 + i, 0, 0]}>
            <boxGeometry args={[0.8, 0.4, 0.15]} />
            <meshStandardMaterial color={k === bclass ? "#38bdf8" : "#334155"} emissive={k === bclass ? "#0ea5e9" : "#000"} emissiveIntensity={k === bclass ? 0.7 : 0} roughness={0.5} />
          </mesh>
        ))}
        <Label text="I   II   III   IV   V   VI" position={[0, -0.55, 0]} size={0.4} color="#e2e8f0" />
      </group>

      <Label text={`Black's ${c.name}`} position={[0, 3.3, 0]} size={0.65} color="#7dd3fc" />
      <Label text={`${c.note} · cut ${cut}% deep`} position={[0, -3.4, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10444Sim(props: SimProps) {
  const bclass = String(props.bclass ?? "I");
  const cut = Number(props.cut ?? 60);
  const c = CLASSES[bclass] ?? CLASSES.I;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Class", c.name], ["Site", c.note], ["Depth", `${cut}%`]]} />
      <SimCanvas cameraPosition={[0, 2, 9.5]} target={[0, 0.4, 0]}>
        <Scene bclass={bclass} cut={cut} />
      </SimCanvas>
    </div>
  );
}
