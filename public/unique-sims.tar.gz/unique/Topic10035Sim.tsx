// Nerve & muscle: action potential, synapse, NMJ — a depolarization wave races
// down the axon, vesicles fuse at the terminal and acetylcholine sparkles
// cross the synaptic cleft to the muscle fibre.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "freq", label: "Firing frequency", kind: "slider", min: 0.2, max: 3, step: 0.1, default: 1, unit: "Hz" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Nerve & Muscle: Action Potential & Synapse",
  blurb: "A depolarization wave races down the axon; vesicles burst and acetylcholine crosses the synaptic cleft.",
};

function Animator({
  wave, ach, vesicles, muscle, elapsed, freq, speed,
}: {
  wave: React.RefObject<THREE.Mesh>;
  ach: React.RefObject<THREE.Group>;
  vesicles: React.RefObject<THREE.Group>;
  muscle: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  freq: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const cyc = (t * freq) % 1; // one firing cycle
    // wave travels axon x: -6 -> 1.5
    const wx = -6 + Math.min(1, cyc / 0.45) * 7.5;
    if (wave.current) {
      wave.current.position.x = wx;
      wave.current.visible = cyc < 0.5;
    }
    // ACh released when wave arrives, drifts down across cleft
    if (ach.current) {
      ach.current.children.forEach((m, i) => {
        const rel = Math.max(0, (cyc - 0.45) / 0.3);
        const ph = (rel * 2 + i / 8) % 1;
        m.position.y = 1.55 - ph * 1.1;
        m.position.x = 1.5 + Math.sin(i * 2.4) * 0.3;
        m.visible = rel > 0 && rel < 1.6;
      });
    }
    if (vesicles.current) {
      vesicles.current.children.forEach((m, i) => {
        const burst = cyc > 0.45 && cyc < 0.55;
        m.position.y = 1.75 + (burst ? 0.12 * Math.sin(t * 30 + i) : 0);
      });
    }
    if (muscle.current) {
      const twitch = Math.max(0, Math.sin((cyc - 0.6) * Math.PI * 3));
      muscle.current.scale.x = 1 - 0.12 * Math.max(0, twitch) * (cyc > 0.6 ? 1 : 0);
    }
  });
  return null;
}

export function Topic10035Sim(props: SimProps) {
  const freq = Number(props.freq ?? 1);
  const speed = Number(props.speed ?? 1);
  const wave = useRef<THREE.Mesh>(null!);
  const ach = useRef<THREE.Group>(null!);
  const vesicles = useRef<THREE.Group>(null!);
  const muscle = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Resting potential", "−70 mV"],
          ["Peak", "+30 mV → ACh release"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5, 15]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* axon with myelin */}
        <mesh position={[-2.25, 2.6, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.16, 0.16, 7.5, 12]} />
          <meshStandardMaterial color="#f59e0b" roughness={0.45} />
        </mesh>
        {[-4.2, -2.6, -1.0].map((x, i) => (
          <mesh key={i} position={[x, 2.6, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
            <capsuleGeometry args={[0.3, 1.0, 6, 12]} />
            <meshStandardMaterial color="#e0e7ff" roughness={0.35} />
          </mesh>
        ))}
        {/* depolarization wave */}
        <mesh ref={wave} position={[-6, 2.6, 0]}>
          <sphereGeometry args={[0.3, 14, 14]} />
          <meshBasicMaterial color="#fef08a" />
        </mesh>
        <Label text="action potential (+30 mV)" position={[-2.2, 3.6, 0]} size={0.34} color="#fef08a" />
        <Arrow from={[-5.5, 3.1, 0]} to={[-0.5, 3.1, 0]} color="#fbbf24" radius={0.05} />

        {/* presynaptic terminal with vesicles */}
        <mesh position={[1.5, 2.0, 0]} castShadow>
          <sphereGeometry args={[0.55, 16, 16]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.45} />
        </mesh>
        <group ref={vesicles}>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[1.5 + Math.cos(i * 2.1) * 0.25, 1.75 + Math.sin(i * 1.7) * 0.18, Math.sin(i * 2.6) * 0.25]}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshStandardMaterial color="#fef9c3" roughness={0.4} />
            </mesh>
          ))}
        </group>
        {/* synaptic cleft */}
        <mesh position={[1.5, 1.05, 0]}>
          <boxGeometry args={[1.3, 0.25, 1.0]} />
          <meshStandardMaterial color="#1e293b" roughness={0.8} />
        </mesh>
        {/* ACh molecules crossing */}
        <group ref={ach}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[1.5, 1.55, 0]}>
              <sphereGeometry args={[0.08, 8, 8]} />
              <meshBasicMaterial color="#a5f3fc" />
            </mesh>
          ))}
        </group>
        <Label text="synaptic vesicles (ACh)" position={[3.4, 2.5, 0]} size={0.32} color="#fde68a" />
        <Label text="synaptic cleft" position={[3.4, 1.0, 0]} size={0.32} color="#94a3b8" />

        {/* muscle fibre below (NMJ) */}
        <mesh ref={muscle} position={[1.5, -0.1, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.7, 0.7, 5.5, 18]} />
          <meshStandardMaterial color="#ef4444" roughness={0.5} />
        </mesh>
        {[-0.5, 1.5, 3.5].map((x, i) => (
          <mesh key={i} position={[x, 0.65, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.72, 0.72, 0.1, 18]} />
            <meshStandardMaterial color="#b91c1c" roughness={0.5} />
          </mesh>
        ))}
        <Label text="neuromuscular junction" position={[1.5, -1.35, 0]} size={0.36} color="#f8fafc" />
        <Label text="muscle fibre twitches" position={[5.2, -0.1, 0]} size={0.3} color="#fca5a5" />

        <Animator wave={wave} ach={ach} vesicles={vesicles} muscle={muscle} elapsed={elapsed} freq={freq} speed={speed} />
      </SimCanvas>
    </div>
  );
}
