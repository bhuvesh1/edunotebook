"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "scheme", label: "Occlusion scheme", kind: "select", min: 0, max: 0, step: 1, default: "balanced", options: ["balanced", "lingualized", "monoplane"] },
  { key: "move", label: "Jaw movement", kind: "select", min: 0, max: 0, step: 1, default: "open", options: ["open", "lateral", "protrusive"] },
];

export const UNIQUE_META = {
  title: "Complete dentures: occlusion — balanced, lingualized; teeth arrangement",
  blurb: "Denture teeth on an articulator — open, slide sideways or forward and see which teeth touch in each occlusion scheme.",
};

const SCHEMES: Record<string, { name: string; note: string; color: string }> = {
  balanced: { name: "Balanced occlusion", note: "Teeth touch on both sides in every movement", color: "#86efac" },
  lingualized: { name: "Lingualized occlusion", note: "Upper palatal cusps sit in lower fossae", color: "#7dd3fc" },
  monoplane: { name: "Monoplane (flat)", note: "Flat teeth — no cusps, kind to ridges", color: "#fde68a" },
};

function TeethRow({ y, upper, scheme }: { y: number; upper: boolean; scheme: string }) {
  const teeth: { x: number; z: number }[] = [];
  const n = 7;
  for (let i = 0; i < n; i++) {
    const a = Math.PI * (0.12 + (0.76 * i) / (n - 1));
    teeth.push({ x: Math.cos(a) * 1.9, z: Math.sin(a) * 1.9 });
  }
  return (
    <group position={[0, y, 0]}>
      {teeth.map((tt, i) => (
        <group key={i} position={[tt.x, 0, tt.z]} rotation={[0, -Math.atan2(tt.z, tt.x) + Math.PI / 2, 0]}>
          <mesh position={[0, upper ? -0.28 : 0.28, 0]}>
            {scheme === "monoplane" ? (
              <boxGeometry args={[0.42, 0.3, 0.5]} />
            ) : (
              <coneGeometry args={[0.26, 0.55, 4]} />
            )}
            <meshStandardMaterial color="#fdfbf3" roughness={0.25} />
          </mesh>
          {scheme === "lingualized" && upper && (
            <mesh position={[0, -0.42, 0.1]}>
              <sphereGeometry args={[0.12, 10, 10]} />
              <meshStandardMaterial color="#7dd3fc" emissive="#0ea5e9" emissiveIntensity={0.7} />
            </mesh>
          )}
        </group>
      ))}
    </group>
  );
}

function Scene({ scheme, move }: { scheme: string; move: string }) {
  const lower = useRef<THREE.Group>(null!);
  const arm = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const s = SCHEMES[scheme] ?? SCHEMES.balanced;

  useFrame((_, delta) => {
    t.current += delta;
    if (lower.current) {
      if (move === "open") lower.current.position.y = -0.85 - (Math.sin(t.current * 1.4) * 0.5 + 0.5) * 0.9;
      else if (move === "lateral") lower.current.position.set(Math.sin(t.current * 1.4) * 0.55, -0.85, 0);
      else lower.current.position.set(0, -0.85, Math.sin(t.current * 1.4) * 0.55);
    }
    if (arm.current) arm.current.rotation.x = move === "open" ? -(Math.sin(t.current * 1.4) * 0.5 + 0.5) * 0.35 : 0;
  });

  return (
    <group>
      {/* articulator frame */}
      <mesh position={[0, -2.2, 0]}>
        <boxGeometry args={[5.4, 0.3, 4]} />
        <meshStandardMaterial color="#475569" metalness={0.4} roughness={0.5} />
      </mesh>
      {[-2.4, 2.4].map((x) => (
        <mesh key={x} position={[x, -0.4, -1.6]}>
          <boxGeometry args={[0.3, 3.6, 0.3]} />
          <meshStandardMaterial color="#64748b" metalness={0.5} roughness={0.45} />
        </mesh>
      ))}
      <group ref={arm}>
        <mesh position={[0, 1.5, -1.6]}>
          <boxGeometry args={[5.1, 0.3, 0.3]} />
          <meshStandardMaterial color="#64748b" metalness={0.5} roughness={0.45} />
        </mesh>
      </group>
      <Label text="Articulator" position={[-3.2, -2.2, 0]} size={0.4} color="#94a3b8" />

      {/* upper denture fixed */}
      <group position={[0, 0.6, 0.3]}>
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[1.9, 0.4, 12, 32, Math.PI]} />
          <meshStandardMaterial color="#f472b6" roughness={0.5} />
        </mesh>
        <TeethRow y={-0.35} upper scheme={scheme} />
      </group>
      {/* lower denture moves */}
      <group ref={lower} position={[0, -0.85, 0.3]}>
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[1.9, 0.4, 12, 32, Math.PI]} />
          <meshStandardMaterial color="#f472b6" roughness={0.5} />
        </mesh>
        <TeethRow y={0.35} upper={false} scheme={scheme} />
      </group>

      {/* contact flashes */}
      {move !== "open" &&
        [-1, 1].map((x) => (
          <mesh key={x} position={[x * 1.5, -0.15, 1.6]}>
            <sphereGeometry args={[0.12 + Math.sin(t.current * 6) * 0.03, 10, 10]} />
            <meshStandardMaterial color={s.color} emissive={s.color} emissiveIntensity={1.5} />
          </mesh>
        ))}

      <Label text={s.name} position={[0, 3.4, 0]} size={0.6} color={s.color} />
      <Label text={`${s.note} · movement: ${move}`} position={[0, -3.0, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10430Sim(props: SimProps) {
  const scheme = String(props.scheme ?? "balanced");
  const move = String(props.move ?? "open");
  const s = SCHEMES[scheme] ?? SCHEMES.balanced;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Scheme", s.name], ["Movement", move], ["Contacts", move === "open" ? "—" : "Bilateral"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, 0, 0]}>
        <Scene scheme={scheme} move={move} />
      </SimCanvas>
    </div>
  );
}
