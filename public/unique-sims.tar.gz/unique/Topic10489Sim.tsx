"use client";
// Regenerative Therapy: GTR & Bone Grafts — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Regenerative Therapy: GTR & Bone Grafts",
  blurb: "Bone graft granules fill the defect, a membrane keeps gum out — then new bone grows back in.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const T = 14;
    const ph = (t % T) / T;
    for (let i = 0; i < 8; i++) {
      const gr: any = g("graft" + i);
      if (gr) {
        const drop = Math.min(1, Math.max(0, (ph - i * 0.03) / 0.25));
        gr.position.y = 3.2 - drop * 2.1;
        gr.visible = ph > 0.05;
      }
    }
    const mem: any = g("membrane");
    if (mem) {
      mem.visible = ph > 0.3;
      (mem.material as any).opacity = 0.35 + 0.1 * Math.sin(t * 2);
    }
    const nb: any = g("newbone");
    if (nb) {
      const grow = Math.min(1, Math.max(0, (ph - 0.55) / 0.4));
      nb.scale.y = Math.max(0.001, grow);
      nb.visible = grow > 0;
    }
  });
  return null;
}

export function Topic10489Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Step 1", "Graft granules placed"],
          ["Step 2", "Barrier membrane"],
          ["Step 3", "New bone fills in"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1.3, 0]} scale={1.5} />
          <mesh position={[-1.5, 0.35, -0.5]}>
            <boxGeometry args={[2.4, 1.9, 1.8]} />
            <meshStandardMaterial color="#cbb894" roughness={0.9} />
          </mesh>
          <mesh position={[1.5, 0.35, -0.5]}>
            <boxGeometry args={[2.4, 1.9, 1.8]} />
            <meshStandardMaterial color="#cbb894" roughness={0.9} />
          </mesh>
          {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
            <mesh key={i} name={"graft" + i} position={[-0.5 + (i % 4) * 0.33, 3.2, -0.5 + Math.floor(i / 4) * 0.4]}>
              <sphereGeometry args={[0.16, 8, 8]} />
              <meshStandardMaterial color="#e7d3a7" roughness={0.95} />
            </mesh>
          ))}
          <mesh name="membrane" position={[0, 1.75, -0.5]} visible={false}>
            <boxGeometry args={[2.6, 0.08, 1.9]} />
            <meshStandardMaterial color="#f8fafc" transparent opacity={0.35} roughness={0.3} />
          </mesh>
          <mesh name="newbone" position={[0, 0.35, -0.5]} visible={false}>
            <boxGeometry args={[2.2, 1.9, 1.7]} />
            <meshStandardMaterial color="#d9c69c" roughness={0.85} />
          </mesh>
          <Label text="Graft granules" position={[2.8, 3.2, -0.5]} size={0.42} color="#e7d3a7" />
          <Label text="Barrier membrane" position={[-2.9, 1.75, -0.5]} size={0.42} />
          <Label text="New bone" position={[0, -0.9, -0.5]} size={0.42} color="#d9c69c" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
