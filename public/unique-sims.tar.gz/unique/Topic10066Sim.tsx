"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Fatty-Acid Beta-Oxidation",
  blurb: "A fatty-acid chain feeds into the mitochondrion, acetyl-CoA units pinch off one by one, while cholesterol spins nearby.",
};

function Animator({ root, fa, ac, chol, elapsed, speed }: { root: RefObject<THREE.Group>; fa: RefObject<THREE.Group>; ac: RefObject<THREE.Group>; chol: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (fa.current) fa.current.position.x = 2.6 - ((t * 0.55) % 1) * 5.4;
    if (ac.current) {
      ac.current.children.forEach((m, i) => {
        const q = (t * 0.45 + i / 4) % 1;
        m.position.set(-2 + q * 5, 1.8 + Math.sin(q * Math.PI) * 1.1, 0);
      });
    }
    if (chol.current) chol.current.rotation.y = t * 1.2;
  });
  return null;
}

export function Topic10066Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const fa = useRef<THREE.Group>(null!);
  const ac = useRef<THREE.Group>(null!);
  const chol = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Acetyl-CoA / palmitate", "8"],
          ["Process", "\u03b2-oxidation spiral"],
          ["Site", "mitochondrial matrix"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[-3, 1.8, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
            <capsuleGeometry args={[0.95, 2.2, 8, 16]} />
            <meshStandardMaterial color="#fb923c" transparent opacity={0.35} roughness={0.5} />
          </mesh>
          <Label text="mitochondrion" position={[-3, 3.3, 0]} size={0.42} color="#fb923c" />
          <group ref={fa}>
            {Array.from({ length: 10 }).map((_, i) => (
              <mesh key={i} position={[i * 0.36, (i % 2 === 0 ? 0.2 : -0.2), 0]} castShadow>
                <sphereGeometry args={[0.22, 12, 12]} /><meshStandardMaterial color="#9ca3af" roughness={0.5} />
              </mesh>
            ))}
            <Label text="fatty acid" position={[1.6, 0.9, 0]} size={0.42} color="#9ca3af" />
          </group>
          <group ref={ac}>
            {Array.from({ length: 4 }).map((_, i) => (
              <mesh key={i} castShadow><sphereGeometry args={[0.24, 14, 14]} /><meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={0.8} /></mesh>
            ))}
          </group>
          <Label text="acetyl-CoA" position={[3.4, 3.4, 0]} size={0.42} color="#38bdf8" />
          {Array.from({ length: 6 }).map((_, i) => {
            const a = (i / 6) * Math.PI * 2;
            return (
              <mesh key={i} position={[3 + Math.cos(a), 1.8 + Math.sin(a), 0]}>
                <sphereGeometry args={[0.2, 12, 12]} /><meshStandardMaterial color="#c084fc" roughness={0.5} />
              </mesh>
            );
          })}
          <Label text="TCA" position={[3, 0.7, 0]} size={0.4} color="#c084fc" />
          <group ref={chol} position={[3.6, 4.1, -1.5]}>
            {[0, 1, 2, 3].map((i) => (
              <mesh key={i} position={[i * 0.5 - 0.75, 0, 0]}>
                <torusGeometry args={[0.3, 0.11, 10, 20]} /><meshStandardMaterial color="#fbbf24" roughness={0.35} metalness={0.3} />
              </mesh>
            ))}
            <Label text="cholesterol" position={[0, 0.8, 0]} size={0.4} color="#fbbf24" />
          </group>
        </group>
        <Animator root={root} fa={fa} ac={ac} chol={chol} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
