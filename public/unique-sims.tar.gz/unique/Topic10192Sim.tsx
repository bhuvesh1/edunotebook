"use client";
// Throat: tonsillitis, adenoids, peritonsillar abscess.
// Peer into an open mouth: two tonsils swell redder and bigger with
// the slider, and an abscess bulge appears beside one.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "tonsillitis", options: ["tonsillitis", "adenoids", "abscess"] },
  { key: "swell", label: "Swelling", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
];

export const UNIQUE_META = {
  title: "Tonsillitis, Adenoids & Peritonsillar Abscess",
  blurb: "Look inside the open mouth: tonsils swell red in tonsillitis, adenoids block the nose above, and an abscess bulges to one side.",
};

function Animator({ tonsils, elapsed, swell }: { tonsils: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; swell: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (tonsils.current) {
      tonsils.current.children.forEach((t, i) => {
        const s = 1 + (swell / 100) * 0.7 + Math.sin(elapsed.current * 2.5 + i * 2) * 0.05;
        t.scale.set(s, s, s);
      });
    }
  });
  return null;
}

export function Topic10192Sim(props: SimProps) {
  const condition = String(props.condition ?? "tonsillitis");
  const swell = Number(props.swell ?? 55);
  const tonsils = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const red = Math.min(1, 0.25 + swell / 130);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", condition], ["Throat", swell > 66 ? "very sore" : swell > 33 ? "sore" : "mild"]]} />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* open mouth */}
        <group position={[0, 2.6, 0]}>
          <mesh castShadow>
            <torusGeometry args={[2.1, 0.55, 14, 28]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.65} />
          </mesh>
          <mesh position={[0, 0, -0.7]}>
            <circleGeometry args={[2, 28]} />
            <meshStandardMaterial color="#7f1d1d" roughness={0.8} />
          </mesh>
          {/* tongue */}
          <mesh position={[0, -0.9, -0.2]} castShadow>
            <capsuleGeometry args={[0.55, 1, 6, 12]} />
            <meshStandardMaterial color="#f87171" roughness={0.6} />
          </mesh>
          {/* uvula */}
          <mesh position={[0, 1.35, -0.5]}>
            <capsuleGeometry args={[0.14, 0.35, 4, 8]} />
            <meshStandardMaterial color="#fca5a5" roughness={0.6} />
          </mesh>
          {/* tonsils */}
          <group ref={tonsils}>
            {[-1.15, 1.15].map((x) => (
              <mesh key={x} position={[x, 0.35, -0.4]} castShadow>
                <sphereGeometry args={[0.5, 16, 16]} />
                <meshStandardMaterial color={new THREE.Color(1, 0.55 - red * 0.35, 0.5 - red * 0.35)} roughness={0.55} emissive="#ef4444" emissiveIntensity={red * 0.5} />
              </mesh>
            ))}
          </group>
          <Label text="TONSILS" position={[-1.15, 1.5, 0.6]} size={0.5} color="#fca5a5" />
          {/* adenoids (above, behind nose) */}
          {condition === "adenoids" && (
            <group position={[0, 2.6, -0.6]}>
              <mesh castShadow>
                <icosahedronGeometry args={[0.55, 1]} />
                <meshStandardMaterial color="#fb923c" emissive="#f97316" emissiveIntensity={0.5} roughness={0.6} flatShading />
              </mesh>
              <Label text="ADENOIDS" position={[0, 1.1, 0]} size={0.5} color="#fdba74" />
            </group>
          )}
          {/* peritonsillar abscess bulge */}
          {condition === "abscess" && (
            <group position={[1.9, 0.7, -0.3]}>
              <mesh castShadow>
                <sphereGeometry args={[0.62, 16, 16]} />
                <meshStandardMaterial color="#fde047" emissive="#eab308" emissiveIntensity={0.55} roughness={0.45} />
              </mesh>
              <Label text="ABSCESS (pus pocket)" position={[0.6, 1.2, 0.6]} size={0.5} color="#fde047" />
            </group>
          )}
          <Label text="OPEN MOUTH" position={[0, 3.1, 0.6]} size={0.55} color="#fcd9b8" />
        </group>
        <Animator tonsils={tonsils} elapsed={elapsed} swell={swell} />
      </SimCanvas>
    </div>
  );
}
