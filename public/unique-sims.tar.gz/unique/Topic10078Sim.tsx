"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Acid-base state", kind: "select", min: 0, max: 0, step: 1, default: "normal", options: ["normal", "metabolic acidosis", "respiratory alkalosis", "metabolic alkalosis"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Arterial Blood Gas & pH",
  blurb: "Swing the pH needle across acidosis and alkalosis while H+, bicarbonate and CO2 particles shift.",
};

function Animator({ root, needle, hp, co2, cur, elapsed, speed, ph, cond }: { root: RefObject<THREE.Group>; needle: RefObject<THREE.Mesh>; hp: RefObject<THREE.Group>; co2: RefObject<THREE.Group>; cur: RefObject<number>; elapsed: RefObject<number>; speed: number; ph: number; cond: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    cur.current += (ph - cur.current) * Math.min(1, delta * 2.5);
    if (needle.current) {
      const ang = ((cur.current - 6.8) / 1.2) * Math.PI - Math.PI / 2;
      needle.current.rotation.z = -ang + Math.PI / 2;
    }
    if (hp.current) {
      const nH = cond === "metabolic acidosis" ? 14 : cond === "normal" ? 7 : 4;
      hp.current.children.forEach((m, i) => {
        m.visible = i < nH;
        const a = t * 1.2 + i * 0.9;
        m.position.set(-4.5 + (i % 5) * 0.55, 1 + Math.floor(i / 5) * 0.55 + Math.sin(a) * 0.12, 1.8);
      });
    }
    if (co2.current) {
      co2.current.children.forEach((m, i) => {
        const r = (t * (cond === "respiratory alkalosis" ? 1.1 : 0.5) + i / 6) % 1;
        m.position.set(3.4 + Math.sin(i * 2.5) * 0.5, 0.4 + r * 3, 1.8);
      });
    }
  });
  return null;
}

export function Topic10078Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const cond = String(props.cond ?? "normal");
  const PH: Record<string, number> = { "normal": 7.4, "metabolic acidosis": 7.18, "respiratory alkalosis": 7.56, "metabolic alkalosis": 7.52 };
  const ph = PH[cond] ?? 7.4;
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const needle = useRef<THREE.Mesh>(null!);
  const hp = useRef<THREE.Group>(null!);
  const co2 = useRef<THREE.Group>(null!);
  const cur = useRef(7.4);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["pH", ph.toFixed(2)],
          ["State", cond],
          ["Equation", "Henderson\u2013Hasselbalch"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[-1, 2.2, 0]} rotation={[0, 0, 0]}>
            <torusGeometry args={[2.2, 0.16, 12, 40, Math.PI]} />
            <meshStandardMaterial color="#475569" roughness={0.5} />
          </mesh>
          {[6.8, 7.0, 7.2, 7.4, 7.6, 7.8].map((v) => {
            const a = ((v - 6.8) / 1.2) * Math.PI;
            return (
              <group key={v} position={[-1 + Math.cos(a) * 2.2, 2.2 + Math.sin(a) * 2.2, 0]}>
                <mesh><boxGeometry args={[0.08, 0.3, 0.08]} /><meshStandardMaterial color={v === 7.4 ? "#4ade80" : "#94a3b8"} /></mesh>
                <Label text={v.toFixed(1)} position={[0, 0.5, 0]} size={0.32} color="#94a3b8" />
              </group>
            );
          })}
          <mesh ref={needle} position={[-1, 2.2, 0.1]}>
            <boxGeometry args={[0.1, 2, 0.06]} />
            <meshStandardMaterial color="#f87171" emissive="#ef4444" emissiveIntensity={0.6} />
          </mesh>
          <mesh position={[-1, 2.2, 0.15]}><sphereGeometry args={[0.18, 12, 12]} /><meshStandardMaterial color="#f8fafc" /></mesh>
          <Label text="pH" position={[-1, 0.9, 0]} size={0.5} color="#f8fafc" />
          <group ref={hp}>
            {Array.from({ length: 14 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.16, 10, 10]} /><meshStandardMaterial color="#ef4444" emissive="#b91c1d" emissiveIntensity={0.8} /></mesh>
            ))}
          </group>
          <Label text="H\u207a" position={[-3.4, 2.9, 1.8]} size={0.45} color="#f87171" />
          <group ref={co2}>
            {Array.from({ length: 6 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.18, 10, 10]} /><meshStandardMaterial color="#9ca3af" transparent opacity={0.8} /></mesh>
            ))}
          </group>
          <Label text="CO\u2082" position={[3.4, 3.9, 1.8]} size={0.45} color="#9ca3af" />
          {[0, 1, 2, 3, 4].map((i) => (
            <mesh key={i} position={[1.6 + i * 0.5, 1.2, -1.6]}>
              <boxGeometry args={[0.4, 0.4, 0.14]} /><meshStandardMaterial color="#60a5fa" roughness={0.4} />
            </mesh>
          ))}
          <Label text="HCO\u2083\u207b" position={[2.6, 0.5, -1.6]} size={0.42} color="#60a5fa" />
          <Label text={cond} position={[-1, 5.2, 0]} size={0.5} color={ph < 7.35 ? "#f87171" : ph > 7.45 ? "#facc15" : "#4ade80"} />
        </group>
        <Animator root={root} needle={needle} hp={hp} co2={co2} cur={cur} elapsed={elapsed} speed={speed} ph={ph} cond={cond} />
      </SimCanvas>
    </div>
  );
}
