"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "force", label: "Pulling force", kind: "slider", min: 0, max: 100, step: 1, default: 45, unit: " N" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Physical properties: stress, strain, hardness, wear",
  blurb: "Stretch a material bar in a tensile tester — watch stress and strain climb, and feel where elastic snap-back turns into permanent bend.",
};

// stress–strain curve drawn as a line that fills with force
function StressCurve({ force }: { force: number }) {
  const line = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    const n = 60;
    for (let i = 0; i <= n; i++) {
      const x = (i / n) * 5;
      // elastic slope then yield plateau then strain hardening
      const y = x < 2 ? x * 1.2 : x < 3.2 ? 2.4 + (x - 2) * 0.15 : 2.58 + (x - 3.2) * 0.9;
      pts.push(new THREE.Vector3(x, Math.min(y, 4.4), 0));
    }
    const g = new THREE.BufferGeometry().setFromPoints(pts);
    return new THREE.Line(g, new THREE.LineBasicMaterial({ color: "#38bdf8" }));
  }, []);
  const dot = useRef<THREE.Mesh>(null!);
  const x = (force / 100) * 5;
  const y = x < 2 ? x * 1.2 : x < 3.2 ? 2.4 + (x - 2) * 0.15 : Math.min(2.58 + (x - 3.2) * 0.9, 4.4);
  useFrame(() => {
    if (dot.current) dot.current.position.set(x, y, 0);
  });
  return (
    <group position={[-7.5, -3.4, 2.5]}>
      <primitive object={line} />
      {/* yield point marker */}
      <mesh position={[2, 2.4, 0]}>
        <sphereGeometry args={[0.12, 10, 10]} />
        <meshBasicMaterial color="#facc15" />
      </mesh>
      <mesh ref={dot}>
        <sphereGeometry args={[0.16, 12, 10]} />
        <meshBasicMaterial color="#ef4444" />
      </mesh>
    </group>
  );
}

function TensileScene({ force, speed, showLabels }: { force: number; speed: number; showLabels: boolean }) {
  const bar = useRef<THREE.Mesh>(null!);
  const neck = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const strain = force / 100; // 0..1
  const yielded = force > 55;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (bar.current) {
      // stretch with slight vibration under load
      const wob = Math.sin(elapsed.current * 30) * 0.008 * strain;
      bar.current.scale.set(1 - strain * 0.12, 1 + strain * 0.55 + wob, 1 - strain * 0.12);
    }
    if (neck.current) {
      neck.current.visible = yielded;
      const s = yielded ? 1 - (force - 55) / 45 * 0.35 : 1;
      neck.current.scale.set(s, 1, s);
    }
  });

  const stress = (force * 2.4).toFixed(0); // MPa-ish

  return (
    <group>
      {/* tester frame */}
      {[-3.4, 3.4].map((x, i) => (
        <mesh key={i} position={[x, 0.5, 0]} castShadow>
          <boxGeometry args={[0.7, 7, 0.7]} />
          <meshStandardMaterial color="#475569" metalness={0.6} roughness={0.4} />
        </mesh>
      ))}
      <mesh position={[0, 4.2, 0]} castShadow>
        <boxGeometry args={[7.5, 0.7, 0.9]} />
        <meshStandardMaterial color="#475569" metalness={0.6} roughness={0.4} />
      </mesh>
      {/* grips */}
      {[-1, 1].map((s, i) => (
        <mesh key={i} position={[s * 1.6, s > 0 ? 2.6 : -1.6, 0]} castShadow>
          <boxGeometry args={[1.4, 0.8, 1.2]} />
          <meshStandardMaterial color="#1e293b" metalness={0.7} roughness={0.35} />
        </mesh>
      ))}
      {/* test bar */}
      <mesh ref={bar} position={[0, 0.5, 0]} castShadow>
        <boxGeometry args={[1.1, 3.6, 1.1]} />
        <meshStandardMaterial color={yielded ? "#f97316" : "#38bdf8"} roughness={0.3} metalness={0.5} />
      </mesh>
      {/* necking zone glow when yielded */}
      <mesh ref={neck} position={[0, 0.5, 0]} visible={false}>
        <boxGeometry args={[1.14, 1.2, 1.14]} />
        <meshBasicMaterial color="#ef4444" transparent opacity={0.4} />
      </mesh>
      {/* force arrows pulling apart */}
      <group position={[0, 3.6, 0]}>
        <mesh>
          <cylinderGeometry args={[0.09, 0.09, 1.2, 8]} />
          <meshBasicMaterial color="#4ade80" />
        </mesh>
        <mesh position={[0, 0.8, 0]}>
          <coneGeometry args={[0.22, 0.5, 8]} />
          <meshBasicMaterial color="#4ade80" />
        </mesh>
      </group>
      <group position={[0, -2.6, 0]} rotation={[Math.PI, 0, 0]}>
        <mesh>
          <cylinderGeometry args={[0.09, 0.09, 1.2, 8]} />
          <meshBasicMaterial color="#4ade80" />
        </mesh>
        <mesh position={[0, 0.8, 0]}>
          <coneGeometry args={[0.22, 0.5, 8]} />
          <meshBasicMaterial color="#4ade80" />
        </mesh>
      </group>

      <StressCurve force={force} />

      {showLabels && (
        <>
          <Text position={[4.9, 0.5, 0]} fontSize={0.42} color={yielded ? "#fdba74" : "#7dd3fc"}>
            {yielded ? "PLASTIC — won't spring back!" : "ELASTIC — springs back"}
          </Text>
          <Text position={[-7.5, 1.8, 2.5]} fontSize={0.4} color="#7dd3fc">Stress–strain curve (yellow dot = yield)</Text>
          <Text position={[0, 5.6, 0]} fontSize={0.44} color="#fef3c7">Tensile tester — pull the bar</Text>
        </>
      )}
    </group>
  );
}

export function Topic10385Sim(props: SimProps) {
  const force = Number(props.force ?? 45);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const strain = (force * 0.55).toFixed(1);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Force", `${force} N`],
          ["Stress", `${(force * 2.4).toFixed(0)} MPa`],
          ["Strain", `${strain}%`],
          ["Zone", force > 55 ? "plastic ⚠" : "elastic ✓"],
        ]}
      />
      <SimCanvas cameraPosition={[9, 3.5, 11]} target={[0, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.6, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <TensileScene force={force} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
