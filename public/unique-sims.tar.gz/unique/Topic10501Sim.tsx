"use client";
// Soft Tissue & Dentoalveolar Fractures — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "sev", label: "Injury severity", kind: "slider", min: 0.3, max: 1.5, step: 0.1, default: 0.8, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Soft Tissue & Dentoalveolar Fractures",
  blurb: "A cut lip, a wobbling tooth — the splint wire holds the injured teeth steady while they heal.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const lac: any = g("lacer");
    if (lac) lac.scale.x = 0.5 + p.sev * 0.9;
    const inj: any = g("injtooth");
    if (inj) {
      inj.rotation.z = 0.18 * p.sev + 0.03 * p.sev * Math.sin(t * 5);
      inj.position.y = 1.2 - 0.15 * p.sev;
    }
    const bleed: any = g("bleed");
    if (bleed) (bleed.material as any).opacity = 0.3 + 0.3 * p.sev * (0.6 + 0.4 * Math.sin(t * 4));
  });
  return null;
}

export function Topic10501Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const sev = Number(props.sev ?? 0.8);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, sev };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Laceration", `${(sev * 12).toFixed(0)} mm lip cut`],
          ["Tooth", "Subluxated, splinted"],
          ["Splint", "Wire + composite, 2 weeks"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <mesh position={[0, 3.1, 0.9]} rotation={[0, 0, 0]}>
            <torusGeometry args={[1.7, 0.42, 12, 24, Math.PI]} />
            <meshStandardMaterial color="#e0808f" roughness={0.55} />
          </mesh>
          <group name="lacer" position={[-0.4, 3.35, 1.15]}>
            {[0, 1, 2].map((i) => (
              <mesh key={i} position={[i * 0.28 - 0.28, (i % 2) * 0.08, 0]} rotation={[0, 0, 0.2 * (i - 1)]}>
                <boxGeometry args={[0.34, 0.09, 0.06]} />
                <meshStandardMaterial color="#b91c1c" emissive="#b91c1c" emissiveIntensity={0.5} />
              </mesh>
            ))}
          </group>
          <mesh name="bleed" position={[-0.4, 3.1, 1.2]}>
            <sphereGeometry args={[0.3, 10, 10]} />
            <meshStandardMaterial color="#dc2626" transparent opacity={0.4} roughness={0.3} />
          </mesh>
          {[-1.2, 1.2].map((x, i) => (
            <mesh key={i} position={[x, 1.2, 0]}>
              <boxGeometry args={[1, 1.5, 1]} />
              <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
            </mesh>
          ))}
          <group name="injtooth" position={[0, 1.2, 0]}>
            <Tooth scale={1.15} />
          </group>
          <Wire points={[[-1.7, 1.5, 0.55], [0, 1.55, 0.6], [1.7, 1.5, 0.55]]} color="#94a3b8" radius={0.05} />
          <GumSlab position={[0, 0.15, -0.3]} scale={1.1} />
          <Label text="Lip laceration" position={[-2.7, 3.6, 0.9]} size={0.42} color="#b91c1c" />
          <Label text="Splinted tooth" position={[0, 2.9, 0]} size={0.42} color="#94a3b8" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
