"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "combo", label: "Drug combination", kind: "select", min: 0, max: 0, step: 1, default: "metro_alcohol", options: ["metro_alcohol", "nsaid_warfarin", "erythro_statin"] },
  { key: "severity", label: "Interaction severity", kind: "slider", min: 1, max: 5, step: 1, default: 3, unit: "" },
];

export const UNIQUE_META = {
  title: "Drug interactions relevant to dental patients",
  blurb: "Two pills collide over the liver's enzyme factory — watch drug levels spike and the warning triangle flash for risky combos.",
};

const COMBOS: Record<string, { a: string; b: string; colorA: string; colorB: string; effect: string; note: string; danger: string }> = {
  metro_alcohol: { a: "Metronidazole", b: "Alcohol", colorA: "#38bdf8", colorB: "#fbbf24", effect: "Disulfiram-like reaction", note: "Enzyme blocked → toxic buildup", danger: "Severe nausea, flushing" },
  nsaid_warfarin: { a: "NSAID (ibuprofen)", b: "Warfarin", colorA: "#34d399", colorB: "#f87171", effect: "Bleeding risk ↑↑", note: "Displaces warfarin + blocks platelets", danger: "Dangerous bleeding" },
  erythro_statin: { a: "Erythromycin", b: "Statin", colorA: "#a78bfa", colorB: "#fb923c", effect: "Statin level spikes", note: "CYP3A4 blocked in the liver", danger: "Muscle breakdown risk" },
};

function Scene({ combo, severity }: { combo: string; severity: number }) {
  const t = useRef(0);
  const warn = useRef<THREE.Mesh>(null!);
  const level = useRef<THREE.Mesh>(null!);
  const c = COMBOS[combo] ?? COMBOS.metro_alcohol;

  useFrame((_, delta) => {
    t.current += delta;
    if (warn.current) {
      const m = warn.current.material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = 0.6 + Math.sin(t.current * 5) * 0.5;
    }
    if (level.current) {
      const target = 0.3 + severity * 0.32;
      level.current.scale.y += (target - level.current.scale.y) * 0.05;
    }
  });

  return (
    <group>
      {/* liver enzyme factory */}
      <group position={[0, -0.6, -0.5]}>
        <mesh scale={[2.2, 1.1, 1.4]}>
          <sphereGeometry args={[1, 20, 20]} />
          <meshStandardMaterial color="#b45309" roughness={0.6} />
        </mesh>
        <Label text="Liver (CYP enzymes)" position={[0, 1.5, 0]} size={0.5} color="#fdba74" />
        {/* blocked enzyme X */}
        <group position={[0, 0.1, 1.5]}>
          <mesh rotation={[0, 0, Math.PI / 4]}>
            <boxGeometry args={[0.9, 0.16, 0.1]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.8} />
          </mesh>
          <mesh rotation={[0, 0, -Math.PI / 4]}>
            <boxGeometry args={[0.9, 0.16, 0.1]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.8} />
          </mesh>
          <Label text="Enzyme blocked" position={[0, 0.75, 0]} size={0.4} color="#fca5a5" />
        </group>
      </group>

      {/* pill A */}
      <group position={[-2.4, 2.2, 0.5]}>
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <capsuleGeometry args={[0.3, 0.6, 8, 14]} />
          <meshStandardMaterial color={c.colorA} roughness={0.35} />
        </mesh>
        <Label text={c.a} position={[0, 0.85, 0]} size={0.45} color={c.colorA} />
      </group>
      {/* pill B */}
      <group position={[2.4, 2.2, 0.5]}>
        <mesh>
          <cylinderGeometry args={[0.42, 0.42, 0.22, 18]} />
          <meshStandardMaterial color={c.colorB} roughness={0.35} />
        </mesh>
        <Label text={c.b} position={[0, 0.85, 0]} size={0.45} color={c.colorB} />
      </group>
      {/* collision sparks */}
      <mesh position={[0, 2.2, 0.5]}>
        <icosahedronGeometry args={[0.3 + Math.sin(t.current * 6) * 0.06, 0]} />
        <meshStandardMaterial color="#fde047" emissive="#fde047" emissiveIntensity={1.4} flatShading />
      </mesh>

      {/* drug level meter */}
      <group position={[-3.2, -0.6, 1.2]}>
        <mesh position={[0, 1, 0]}>
          <boxGeometry args={[0.5, 3.4, 0.5]} />
          <meshStandardMaterial color="#1e293b" roughness={0.6} />
        </mesh>
        <mesh ref={level} position={[0, -0.7, 0]}>
          <boxGeometry args={[0.4, 3.2, 0.4]} />
          <meshStandardMaterial color={severity >= 4 ? "#ef4444" : "#fbbf24"} roughness={0.4} />
        </mesh>
        <Label text="Drug level in blood" position={[0, 3.1, 0]} size={0.42} color="#fde68a" />
      </group>

      {/* warning triangle */}
      <group position={[3.2, -0.4, 1.2]}>
        <mesh ref={warn}>
          <coneGeometry args={[0.7, 1.2, 3]} />
          <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1} flatShading />
        </mesh>
        <Label text="!" position={[0, 0.1, 0.55]} size={0.6} color="#451a03" />
        <Label text={c.effect} position={[0, -1.1, 0]} size={0.45} color="#fbbf24" />
      </group>

      <Label text={`${c.a} + ${c.b}`} position={[0, 3.6, 0]} size={0.6} color="#fecaca" />
      <Label text={`${c.note} — ${c.danger}`} position={[0, -2.9, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10426Sim(props: SimProps) {
  const combo = String(props.combo ?? "metro_alcohol");
  const severity = Number(props.severity ?? 3);
  const c = COMBOS[combo] ?? COMBOS.metro_alcohol;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Combination", `${c.a} + ${c.b}`], ["Effect", c.effect], ["Severity", `${severity}/5`]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, 0.5, 0]}>
        <Scene combo={combo} severity={severity} />
      </SimCanvas>
    </div>
  );
}
