"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "flexion", label: "Flexion angle", kind: "slider", min: 0, max: 120, step: 5, default: 60, unit: "°" },
  { key: "speed", label: "Motion speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Joints: classification, types of synovial joints",
  blurb: "A hinge joint in action: two bones swing on one axis inside the synovial capsule, cushioned by cartilage.",
};

function Hinge({ flexion, speed }: { flexion: number; speed: number }) {
  const lower = useRef<THREE.Group>(null!);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d * speed;
    const base = (flexion * Math.PI) / 180;
    if (lower.current) lower.current.rotation.z = -(base * 0.55 + (Math.sin(t.current * 1.6) * 0.5 + 0.5) * base * 0.45);
  });
  const boneMat = { color: "#f5f0e6", roughness: 0.55 };
  return (
    <group position={[0, 1.2, 0]}>
      {/* upper bone (femur) */}
      <mesh position={[0, 2.6, 0]} castShadow>
        <cylinderGeometry args={[0.4, 0.45, 3.4, 16]} />
        <meshStandardMaterial {...boneMat} />
      </mesh>
      <mesh position={[0, 1.0, 0]} castShadow>
        <sphereGeometry args={[0.62, 18, 18]} />
        <meshStandardMaterial {...boneMat} />
      </mesh>
      {/* cartilage caps */}
      <mesh position={[0, 0.55, 0]}>
        <sphereGeometry args={[0.5, 16, 16]} />
        <meshStandardMaterial color="#93c5fd" roughness={0.4} transparent opacity={0.9} />
      </mesh>
      {/* hinge pin axis */}
      <mesh position={[0, 0.35, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <cylinderGeometry args={[0.14, 0.14, 1.4, 12]} />
        <meshStandardMaterial color="#94a3b8" metalness={0.6} roughness={0.4} />
      </mesh>
      {/* synovial capsule */}
      <mesh position={[0, 0.35, 0]}>
        <sphereGeometry args={[0.85, 20, 20]} />
        <meshStandardMaterial color="#fde68a" roughness={0.3} transparent opacity={0.3} />
      </mesh>
      {/* lower bone (tibia) swinging */}
      <group ref={lower} position={[0, 0.35, 0]}>
        <mesh position={[0, -1.9, 0]} castShadow>
          <cylinderGeometry args={[0.36, 0.4, 3.4, 16]} />
          <meshStandardMaterial {...boneMat} />
        </mesh>
        <mesh position={[0, -0.35, 0]} castShadow>
          <boxGeometry args={[0.9, 0.7, 0.8]} />
          <meshStandardMaterial {...boneMat} />
        </mesh>
        <mesh position={[0, -3.7, 0]} castShadow>
          <boxGeometry args={[0.8, 0.5, 1.1]} />
          <meshStandardMaterial {...boneMat} />
        </mesh>
      </group>
      {/* ligament straps */}
      {[-0.5, 0.5].map((z) => (
        <mesh key={z} position={[0.55, 0.2, z]} rotation={[0, 0, 0.25]}>
          <boxGeometry args={[0.16, 1.6, 0.22]} />
          <meshStandardMaterial color="#f87171" roughness={0.7} />
        </mesh>
      ))}
    </group>
  );
}

export function Topic10001Sim(props: SimProps) {
  const flexion = Number(props.flexion ?? 60);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Joint", "hinge (knee-like)"], ["Flexion", flexion + "°"], ["Capsule", "synovial"]]} />
      <SimCanvas cameraPosition={[6, 3.5, 10]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Hinge flexion={flexion} speed={speed} />
        {showLabels && (
          <>
            <Label text="Cartilage" position={[-2.2, 2.2, 0]} color="#bfdbfe" size={0.5} />
            <Label text="Synovial capsule" position={[2.6, 1.4, 0]} color="#fde68a" size={0.5} />
            <Label text="Ligaments" position={[2.4, 0.2, 0]} color="#fca5a5" size={0.5} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
