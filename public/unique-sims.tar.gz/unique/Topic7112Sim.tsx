// app/components/sims/unique/Topic7112Sim.tsx
// Law of inertia: a puck gets one push on frictionless ice, then the
// push arrow vanishes (F = 0) — and the puck glides on at perfectly
// constant velocity forever. No force needed to keep moving.

"use client";

import { useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Push speed", kind: "slider", min: 1, max: 5, step: 0.5, default: 2.5, unit: "m/s" },
];

export const UNIQUE_META = {
  title: "Law of Inertia and Inertial Frames",
  blurb: "One push on frictionless ice, then zero force — the puck keeps gliding at constant velocity.",
};

function Animator({
  puck, pushArrow, speed, phase, bump,
}: {
  puck: RefObject<THREE.Group>;
  pushArrow: RefObject<THREE.Group>;
  speed: number;
  phase: RefObject<string>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const T = t.current;
    // 1 s push, then coast; loop every 9 s.
    const cycle = 9;
    const ct = T % cycle;
    const pushing = ct < 1;
    const x = pushing ? -7.5 + 0.5 * speed * ct * ct : -7.5 + 0.5 * speed + speed * (ct - 1);
    phase.current = pushing ? "pushing (F applied)" : "coasting (F = 0)";
    if (x > 9) {
      t.current = 0;
      return;
    }
    if (puck.current) puck.current.position.x = x;
    if (pushArrow.current) {
      pushArrow.current.visible = pushing;
      pushArrow.current.position.set(x - 1.6, 0.55, 0);
    }
    if (++n.current % 20 === 0) bump();
  });
  return null;
}

export function Topic7112Sim(props: SimProps) {
  const speed = Number(props.speed ?? 2.5);
  const puck = useRef<THREE.Group>(null!);
  const pushArrow = useRef<THREE.Group>(null!);
  const phase = useRef("pushing");
  const [, bump] = useState(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Phase", phase.current],
          ["Velocity", `${speed.toFixed(1)} m/s — constant`],
          ["Net force", phase.current.startsWith("coast") ? "0 N" : "> 0 N"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 14]} target={[0, 0.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* frictionless ice */}
        <mesh position={[0, 0.05, 0]} receiveShadow>
          <boxGeometry args={[21, 0.1, 4]} />
          <meshStandardMaterial color="#7dd3fc" roughness={0.05} metalness={0.55} />
        </mesh>

        {/* puck */}
        <group ref={puck} position={[-7.5, 0, 0]}>
          <mesh position={[0, 0.45, 0]} castShadow>
            <cylinderGeometry args={[0.7, 0.7, 0.5, 24]} />
            <meshStandardMaterial color="#f43f5e" roughness={0.35} />
          </mesh>
          <mesh position={[0, 0.72, 0]}>
            <cylinderGeometry args={[0.4, 0.4, 0.06, 24]} />
            <meshStandardMaterial color="#fecdd3" roughness={0.4} />
          </mesh>
        </group>

        {/* push arrow (visible only during the push) */}
        <group ref={pushArrow}>
          <mesh rotation={[0, 0, -Math.PI / 2]} position={[0.6, 0, 0]}>
            <cylinderGeometry args={[0.12, 0.12, 1.2, 12]} />
            <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.7} roughness={0.4} />
          </mesh>
          <mesh rotation={[0, 0, -Math.PI / 2]} position={[1.4, 0, 0]}>
            <coneGeometry args={[0.3, 0.6, 14]} />
            <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.7} roughness={0.4} />
          </mesh>
        </group>

        <Animator puck={puck} pushArrow={pushArrow} speed={speed} phase={phase} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
