// Topic10579 — Tooth whitening: in-office and at-home bleaching.
// A stained tooth gets peroxide gel + fizzing bubbles. In-office mode
// adds a curing light that speeds whitening; the shade marches A4 -> B1.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "method", label: "Whitening method", kind: "select", min: 0, max: 0, step: 1, default: "in-office", options: ["in-office", "at-home"] },
  { key: "time", label: "Treatment time", kind: "slider", min: 0, max: 100, step: 1, default: 60, unit: "%" },
];

export const UNIQUE_META = {
  title: "Tooth whitening: in-office and at-home bleaching",
  blurb: "Peroxide gel fizzes stains away — compare the chairside light boost with slow at-home trays.",
};

const SHADES = ["A4", "A3", "A2.5", "A2", "A1", "B1"];
const STAINED = new THREE.Color("#d9a441");
const WHITE = new THREE.Color("#fefdf8");

function Animator({
  bubbles,
  beam,
  elapsed,
  rate,
}: {
  bubbles: RefObject<THREE.Group>;
  beam: RefObject<THREE.Mesh>;
  elapsed: RefObject<number>;
  rate: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (bubbles.current) {
      bubbles.current.children.forEach((m, i) => {
        const speed = 0.9 * rate;
        const y = 0.4 + ((t * speed + i * 0.35) % 2.4);
        m.position.set(
          Math.sin(t * 2 + i * 2.1) * 0.5,
          y,
          Math.cos(t * 1.7 + i * 1.3) * 0.35
        );
        m.scale.setScalar(0.5 + 0.5 * Math.abs(Math.sin(t * 3 + i)));
      });
    }
    if (beam.current) {
      const mat = beam.current.material as THREE.MeshStandardMaterial;
      mat.opacity = 0.28 + 0.12 * Math.sin(t * 6);
    }
  });
  return null;
}

export function Topic10579Sim(props: SimProps) {
  const method = String(props.method ?? "in-office");
  const time = Number(props.time ?? 60);
  const office = method === "in-office";
  // in-office light roughly doubles the whitening effect
  const whiten = Math.min(1, (time / 100) * (office ? 1.7 : 1));
  const shadeIdx = Math.min(SHADES.length - 1, Math.floor(whiten * SHADES.length));
  const bubbles = useRef<THREE.Group>(null!);
  const beam = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const toothColor = useMemo(() => {
    const c = new THREE.Color();
    return c.copy(STAINED).lerp(WHITE, whiten);
  }, [whiten]);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Shade", SHADES[shadeIdx]],
          ["Method", office ? "In-office" : "At-home"],
          ["Whitening", `${Math.round(whiten * 100)}%`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 1.7, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* the tooth: crown + root */}
        <mesh position={[0, 2.1, 0]} castShadow>
          <cylinderGeometry args={[0.85, 0.68, 1.7, 20]} />
          <meshStandardMaterial color={toothColor} roughness={0.28} />
        </mesh>
        <mesh position={[0, 0.75, 0]} castShadow>
          <coneGeometry args={[0.6, 1.3, 18]} />
          <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
        </mesh>
        {/* gum base */}
        <mesh position={[0, 0.55, 0]}>
          <cylinderGeometry args={[1.9, 2.3, 0.7, 24]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.7} />
        </mesh>

        {/* whitening gel layer hugging the crown */}
        <mesh position={[0, 2.1, 0]}>
          <cylinderGeometry args={[0.98, 0.8, 1.75, 20, 1, true]} />
          <meshStandardMaterial color="#60a5fa" roughness={0.2} transparent opacity={0.45} emissive="#1d4ed8" emissiveIntensity={0.35} side={THREE.DoubleSide} />
        </mesh>

        {/* peroxide bubbles fizzing off the gel */}
        <group ref={bubbles}>
          {Array.from({ length: 16 }).map((_, i) => (
            <mesh key={i} position={[0, 0.5, 0]}>
              <sphereGeometry args={[0.07, 8, 8]} />
              <meshStandardMaterial color="#bfdbfe" transparent opacity={0.85} roughness={0.1} />
            </mesh>
          ))}
        </group>

        {/* in-office curing light beam */}
        {office && (
          <>
            <mesh ref={beam} position={[2.6, 2.4, 0]} rotation={[0, 0, Math.PI / 2.6]}>
              <cylinderGeometry args={[0.35, 0.7, 4.5, 14, 1, true]} />
              <meshStandardMaterial color="#93c5fd" transparent opacity={0.3} emissive="#3b82f6" emissiveIntensity={1.2} side={THREE.DoubleSide} />
            </mesh>
            <mesh position={[4.4, 3.4, 0]} castShadow>
              <cylinderGeometry args={[0.5, 0.6, 1.2, 14]} />
              <meshStandardMaterial color="#334155" roughness={0.4} metalness={0.5} />
            </mesh>
            <Label text="CURING LIGHT — speeds bleaching" position={[4.4, 4.7, 0]} size={0.38} color="#93c5fd" />
          </>
        )}

        <Label text={`SHADE ${SHADES[shadeIdx]} — ${whiten >= 0.99 ? "dazzling white!" : "stains lifting..."}`} position={[0, 4.3, 0]} size={0.42} color="#fef3c7" />
        <Label text="PEROXIDE GEL + OXYGEN BUBBLES" position={[0, -0.7, 0]} size={0.38} color="#bfdbfe" />
        {!office && (
          <Label text="AT-HOME TRAY — slower, worn overnight" position={[3.4, 1.2, 0]} size={0.36} color="#94a3b8" />
        )}

        <Animator bubbles={bubbles} beam={beam} elapsed={elapsed} rate={office ? 1.8 : 1} />
      </SimCanvas>
    </div>
  );
}
