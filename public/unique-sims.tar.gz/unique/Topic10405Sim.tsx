"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "disorder", label: "Disorder", kind: "select", min: 0, max: 0, step: 1, default: "leukoplakia", options: ["leukoplakia", "erythroplakia", "osmf", "lichenplanus"] },
  { key: "severity", label: "Severity", kind: "slider", min: 0.5, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Potentially malignant disorders",
  blurb: "Four warning patches of the mouth — leukoplakia, erythroplakia, OSMF and lichen planus — on a rotating mucosa dome.",
};

const INFO: Record<string, { name: string; color: string; risk: string }> = {
  leukoplakia: { name: "Leukoplakia", color: "#f1f5f9", risk: "White patch — cannot be scraped off" },
  erythroplakia: { name: "Erythroplakia", color: "#ef4444", risk: "Fiery red velvety patch — highest risk" },
  osmf: { name: "Oral submucous fibrosis", color: "#fcd34d", risk: "Pale fibrotic bands — stiff mouth" },
  lichenplanus: { name: "Lichen planus", color: "#e2e8f0", risk: "White lace (Wickham striae)" },
};

const ORDER = ["leukoplakia", "erythroplakia", "osmf", "lichenplanus"];
const ANGLES = [Math.PI / 4, (3 * Math.PI) / 4, (5 * Math.PI) / 4, (7 * Math.PI) / 4];

function Patch({ kind, angle, active, severity }: { kind: string; angle: number; active: boolean; severity: number }) {
  const x = Math.cos(angle) * 2.1;
  const z = Math.sin(angle) * 2.1;
  const s = active ? severity : 0.75;
  return (
    <group position={[x, 1.9, z]} rotation={[0, -angle + Math.PI / 2, 0]} scale={s}>
      {kind === "leukoplakia" && (
        <mesh rotation={[-Math.PI / 2.4, 0, 0]}>
          <dodecahedronGeometry args={[0.75, 0]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.85} flatShading />
        </mesh>
      )}
      {kind === "erythroplakia" && (
        <mesh rotation={[-Math.PI / 2.4, 0, 0]}>
          <circleGeometry args={[0.7, 24]} />
          <meshStandardMaterial color="#dc2626" roughness={0.35} />
        </mesh>
      )}
      {kind === "osmf" && (
        <group>
          {[-0.4, 0, 0.4].map((o, i) => (
            <mesh key={i} position={[o, 0.1, 0]} rotation={[-Math.PI / 2.6, 0, 0]}>
              <boxGeometry args={[0.14, 1.3, 0.06]} />
              <meshStandardMaterial color="#fde68a" roughness={0.7} />
            </mesh>
          ))}
        </group>
      )}
      {kind === "lichenplanus" && (
        <group>
          {[0, 1, 2].map((i) => (
            <mesh key={i} rotation={[-Math.PI / 2.4, 0, (i * Math.PI) / 3]} position={[0, 0.05 * i, 0]}>
              <torusGeometry args={[0.55, 0.045, 8, 24, Math.PI]} />
              <meshStandardMaterial color="#ffffff" roughness={0.5} />
            </mesh>
          ))}
        </group>
      )}
      {active && <Label text={INFO[kind].name} position={[0, 1.1, 0]} size={0.55} color={INFO[kind].color} />}
    </group>
  );
}

function Scene({ disorder, severity }: { disorder: string; severity: number }) {
  const group = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const info = INFO[disorder] ?? INFO.leukoplakia;

  useFrame((_, delta) => {
    t.current += delta;
    if (group.current) group.current.rotation.y = t.current * 0.3;
  });

  return (
    <group ref={group}>
      {/* mucosa dome */}
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[3, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2.4]} />
        <meshStandardMaterial color="#e0788a" roughness={0.55} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[0, -0.35, 0]}>
        <cylinderGeometry args={[3.1, 3.3, 0.7, 32]} />
        <meshStandardMaterial color="#b4536a" roughness={0.8} />
      </mesh>
      {ORDER.map((k, i) => (
        <Patch key={k} kind={k} angle={ANGLES[i]} active={k === disorder} severity={severity} />
      ))}
      <Label text={info.name} position={[0, 4.4, 0]} size={0.65} color={info.color} />
      <Label text={info.risk} position={[0, -1.4, 0]} size={0.45} color="#fecaca" />
    </group>
  );
}

export function Topic10405Sim(props: SimProps) {
  const disorder = String(props.disorder ?? "leukoplakia");
  const severity = Number(props.severity ?? 1);
  const info = INFO[disorder] ?? INFO.leukoplakia;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Disorder", info.name], ["Malignant potential", disorder === "erythroplakia" ? "Very high" : "Moderate–high"]]} />
      <SimCanvas cameraPosition={[0, 4.5, 9]} target={[0, 1.5, 0]}>
        <Scene disorder={disorder} severity={severity} />
      </SimCanvas>
    </div>
  );
}
