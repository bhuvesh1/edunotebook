"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "donor", label: "Donor group", kind: "select", min: 0, max: 0, step: 1, default: "A", options: ["A", "B", "AB", "O"] },
  { key: "recip", label: "Recipient group", kind: "select", min: 0, max: 0, step: 1, default: "O", options: ["A", "B", "AB", "O"] },
];

export const UNIQUE_META = {
  title: "Blood Transfusion Reactions",
  blurb: "Match donor and recipient blood groups: compatible cells flow freely, mismatched cells clump in agglutination.",
};

const AGH = "#f87171";

function Animator({ root, cells, drip, elapsed, mismatch }: { root: RefObject<THREE.Group>; cells: RefObject<THREE.Group>; drip: RefObject<THREE.Group>; elapsed: RefObject<number>; mismatch: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += 0.016;
    const t = elapsed.current;
    if (drip.current) {
      drip.current.children.forEach((m, i) => {
        const r = (t * 0.8 + i / 4) % 1;
        m.position.set(3.4, 2.6 - r * 1.8, 0);
      });
    }
    if (cells.current) {
      cells.current.children.forEach((m, i) => {
        if (mismatch) {
          const a = i * 2.4;
          m.position.lerp(new THREE.Vector3(Math.cos(a) * 0.8, 1.7 + Math.sin(a * 2) * 0.5, Math.sin(a) * 0.8), 0.04);
          m.rotation.y += 0.02;
        } else {
          const p = (t * 0.3 + i / 8) % 1;
          m.position.set(-5 + p * 9, 1.7 + Math.sin(i * 2 + t * 2) * 0.35, Math.cos(i * 1.5) * 1.2);
          m.rotation.y = t + i;
        }
      });
    }
  });
  return null;
}

export function Topic10093Sim(props: SimProps) {
  const donor = String(props.donor ?? "A");
  const recip = String(props.recip ?? "O");
  const anti: Record<string, string[]> = { "A": ["B"], "B": ["A"], "AB": [], "O": ["A", "B"] };
  const donorAg = donor === "O" ? [] : donor === "AB" ? ["A", "B"] : [donor];
  const mismatch = donorAg.some((a) => (anti[recip] ?? []).includes(a));
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const cells = useRef<THREE.Group>(null!);
  const drip = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Donor", donor],
          ["Recipient", recip],
          ["Result", mismatch ? "AGGLUTINATION \u2014 hemolysis!" : "compatible \u2014 safe"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[3.4, 3.4, -1.5]} castShadow>
            <boxGeometry args={[1.4, 2, 0.7]} /><meshStandardMaterial color="#fecaca" transparent opacity={0.5} roughness={0.3} />
          </mesh>
          <mesh position={[3.4, 3.4, -1.5]}><boxGeometry args={[1.1, 1.2, 0.5]} /><meshStandardMaterial color="#dc2626" roughness={0.4} /></mesh>
          <Label text={`donor ${donor}`} position={[3.4, 4.8, -1.5]} size={0.45} color="#f87171" />
          <group ref={drip}>
            {Array.from({ length: 4 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.1, 8, 8]} /><meshStandardMaterial color="#dc2626" /></mesh>
            ))}
          </group>
          <group ref={cells}>
            {Array.from({ length: 8 }).map((_, i) => (
              <group key={i} position={[-4 + i, 1.7, 0]}>
                <mesh scale={[1, 0.45, 1]}>
                  <sphereGeometry args={[0.34, 16, 16]} /><meshStandardMaterial color="#dc2626" roughness={0.5} />
                </mesh>
                {donorAg.includes("A") && (
                  <mesh position={[0, 0.42, 0]}><coneGeometry args={[0.09, 0.3, 8]} /><meshStandardMaterial color="#f87171" emissive="#ef4444" emissiveIntensity={0.8} /></mesh>
                )}
                {donorAg.includes("B") && (
                  <mesh position={[0.25, 0.35, 0.15]}><coneGeometry args={[0.09, 0.3, 8]} /><meshStandardMaterial color="#60a5fa" emissive="#3b82f6" emissiveIntensity={0.8} /></mesh>
                )}
              </group>
            ))}
          </group>
          <Label text={donorAg.length ? `${donorAg.join("/")} antigen${donorAg.length > 1 ? "s" : ""} on RBC` : "no A/B antigens (O)"} position={[-3.4, 3.2, 0]} size={0.4} color="#fca5a5" />
          <Label text={mismatch ? `\u26a0 ${donor} \u2192 ${recip}: AGGLUTINATION` : `${donor} \u2192 ${recip}: compatible`} position={[0, 4.6, 0]} size={0.5} color={mismatch ? "#ef4444" : "#4ade80"} />
        </group>
        <Animator root={root} cells={cells} drip={drip} elapsed={elapsed} mismatch={mismatch} />
      </SimCanvas>
    </div>
  );
}
