// Breast surgery: benign breast disease vs breast cancer.
// A breast cross-section showing milk ducts and lobules, with a smooth benign
// lump or a spiky malignant mass plus involved axillary lymph nodes.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "cancer", options: ["healthy", "benign", "cancer"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Breast: Benign Lump vs Cancer",
  blurb: "Look inside the breast at ducts and lobules — compare a smooth benign lump with a spiky cancer spreading to lymph nodes.",
};

function Animator({
  group, lump, nodes, elapsed, speed, condition,
}: {
  group: React.RefObject<THREE.Group>;
  lump: React.RefObject<THREE.Mesh>;
  nodes: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.3) * 0.3;
    const pulse = 0.5 + 0.5 * Math.sin(t * 3);
    if (lump.current) {
      lump.current.visible = condition !== "healthy";
      const s = 1 + (condition === "benign" ? pulse * 0.05 : pulse * 0.14);
      lump.current.scale.set(s, s, s);
      if (condition === "benign") lump.current.position.y = 1.6 + Math.sin(t * 1.5) * 0.08;
    }
    if (nodes.current) {
      nodes.current.visible = condition === "cancer";
      nodes.current.children.forEach((n, i) => {
        (n as THREE.Mesh).scale.setScalar(1 + 0.18 * Math.sin(t * 4 + i * 1.7));
      });
    }
  });
  return null;
}

export function Topic10250Sim(props: SimProps) {
  const condition = String(props.condition ?? "cancer");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const lump = useRef<THREE.Mesh>(null!);
  const nodes = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const isCancer = condition === "cancer";
  const isBenign = condition === "benign";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", isCancer ? "Breast cancer" : isBenign ? "Benign (fibroadenoma)" : "Healthy"], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 9]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* chest wall */}
          <mesh position={[-1.4, 1.8, -1.6]} castShadow>
            <boxGeometry args={[0.7, 4.4, 4.2]} />
            <meshStandardMaterial color="#7c2d12" roughness={0.8} />
          </mesh>
          {/* breast tissue: hemisphere */}
          <mesh position={[0.2, 1.8, 0]} rotation={[0, 0, -Math.PI / 2]} castShadow>
            <sphereGeometry args={[1.7, 32, 24, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <meshStandardMaterial color="#f5c396" roughness={0.6} transparent opacity={0.85} />
          </mesh>
          {/* nipple */}
          <mesh position={[2.05, 1.8, 0]} rotation={[0, 0, -Math.PI / 2]} castShadow>
            <cylinderGeometry args={[0.22, 0.3, 0.35, 16]} />
            <meshStandardMaterial color="#c2703e" roughness={0.6} />
          </mesh>
          {/* milk ducts radiating from nipple */}
          {[-0.7, -0.35, 0, 0.35, 0.7].map((dy, i) => (
            <mesh key={i} position={[0.9, 1.8 + dy, 0]} rotation={[0, 0, Math.PI / 2 + dy * 0.35]} castShadow>
              <cylinderGeometry args={[0.07, 0.1, 2.1, 10]} />
              <meshStandardMaterial color="#65a30d" roughness={0.5} />
            </mesh>
          ))}
          {/* lobules: small grape clusters */}
          {[[-0.5, 2.7], [-0.6, 1.1], [0.1, 2.9], [0.2, 0.9], [-1.0, 1.9]].map(([x, y], i) => (
            <group key={i} position={[x, y, 0.5]}>
              {[0, 1, 2].map((j) => (
                <mesh key={j} position={[Math.cos(j * 2.1) * 0.18, Math.sin(j * 2.1) * 0.18, 0]} castShadow>
                  <sphereGeometry args={[0.16, 14, 12]} />
                  <meshStandardMaterial color="#4d7c0f" roughness={0.5} />
                </mesh>
              ))}
            </group>
          ))}
          {/* lump: smooth sphere (benign) or spiky icosahedron (cancer) */}
          <mesh ref={lump} position={[0.3, 1.6, 0.9]} castShadow visible={false}>
            {isBenign ? <sphereGeometry args={[0.42, 24, 18]} /> : <icosahedronGeometry args={[0.45, 1]} />}
            <meshStandardMaterial
              color={isBenign ? "#fbbf24" : "#b91c1c"}
              roughness={0.4}
              emissive={isBenign ? "#92400e" : "#7f1d1d"}
              emissiveIntensity={0.35}
              flatShading={isCancer}
            />
          </mesh>
          {/* axillary lymph nodes (armpit, upper left) */}
          <group ref={nodes} position={[-2.2, 3.9, 0.6]} visible={false}>
            {[0, 1, 2].map((i) => (
              <mesh key={i} position={[i * 0.45 - 0.45, (i % 2) * 0.35, 0]} castShadow>
                <sphereGeometry args={[0.24, 16, 12]} />
                <meshStandardMaterial color="#ef4444" roughness={0.4} emissive="#991b1b" emissiveIntensity={0.6} />
              </mesh>
            ))}
          </group>
          <Label text="Milk ducts" position={[0.9, 3.3, 0]} size={0.5} color="#bef264" />
          <Label text="Lobules" position={[-0.7, 0.35, 0.6]} size={0.5} color="#bef264" />
          {isBenign && <Label text="Smooth benign lump" position={[0.3, 2.45, 0.9]} size={0.5} color="#fde68a" />}
          {isCancer && <Label text="⚠ Spiky cancer mass" position={[0.3, 2.5, 0.9]} size={0.5} color="#fca5a5" />}
          {isCancer && <Label text="Lymph nodes" position={[-2.2, 4.6, 0.6]} size={0.5} color="#fca5a5" />}
        </group>
        <Animator group={group} lump={lump} nodes={nodes} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
