// Head & neck: neck swellings & salivary gland disorders. A neck column with
// a chain of lymph nodes (they swell with the infection slider), the parotid
// and submandibular salivary glands, and a stone blocking a salivary duct.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "swelling", label: "Node swelling", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "gland", label: "Gland problem", kind: "select", min: 0, max: 0, step: 1, default: "none", options: ["none", "parotid stone", "submandibular stone"] },
];

export const UNIQUE_META = {
  title: "Neck Swellings & Salivary Glands",
  blurb: "Lymph-node chains swell with infection; a stone jams a salivary duct and the gland balloons behind it.",
};

function Animator({ nodes, elapsed, swelling }: {
  nodes: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  swelling: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (nodes.current) {
      nodes.current.children.forEach((c, i) => {
        // swollen nodes throb
        const throb = swelling > 40 ? 1 + 0.12 * Math.sin(t * 4 + i * 1.8) : 1;
        c.scale.setScalar(throb);
      });
    }
  });
  return null;
}

export function Topic10195Sim(props: SimProps) {
  const swelling = Number(props.swelling ?? 55);
  const gland = String(props.gland ?? "none");
  const nodes = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const nodeScale = 0.7 + (swelling / 100) * 1.1;
  const nodeList = useMemo(() => {
    return Array.from({ length: 7 }).map((_, i) => ({
      y: 3.4 - i * 0.62,
      x: 1.05 + (i % 2) * 0.15,
    }));
  }, []);

  const stoneAtParotid = gland === "parotid stone";
  const stoneAtSubmand = gland === "submandibular stone";
  const glandSwollen = gland !== "none";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Lymph nodes", swelling > 60 ? "markedly enlarged ⚠" : swelling > 25 ? "mildly enlarged" : "normal"], ["Salivary gland", gland === "none" ? "normal" : `${gland} — gland swollen`], ["Key exam", "feel along the neck chain"]]} />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* head + neck column */}
        <mesh position={[0, 6.4, 0]} castShadow>
          <sphereGeometry args={[1.5, 28, 22]} />
          <meshStandardMaterial color="#f5d0b8" roughness={0.65} />
        </mesh>
        <mesh position={[0, 2.9, 0]} castShadow>
          <cylinderGeometry args={[1.0, 1.15, 4.6, 24]} />
          <meshStandardMaterial color="#f5d0b8" roughness={0.65} />
        </mesh>
        {/* jaw line */}
        <mesh position={[0, 4.9, 0.7]} rotation={[Math.PI / 2.3, 0, 0]}>
          <boxGeometry args={[2.2, 0.5, 1.1]} />
          <meshStandardMaterial color="#f5d0b8" roughness={0.65} />
        </mesh>

        {/* lymph node chain */}
        <group ref={nodes}>
          {nodeList.map((n, i) => (
            <mesh key={i} position={[n.x, n.y, 0.75]} scale={[nodeScale, nodeScale, nodeScale]}>
              <sphereGeometry args={[0.3, 14, 12]} />
              <meshStandardMaterial color={swelling > 60 ? "#ef4444" : "#22c55e"} roughness={0.5} emissive={swelling > 60 ? "#7f1d1d" : "#14532d"} emissiveIntensity={0.45} />
            </mesh>
          ))}
        </group>

        {/* parotid gland (in front of ear) */}
        <mesh position={[-1.15, 5.9, 0.4]} scale={stoneAtParotid && glandSwollen ? [1.5, 1.5, 1.5] : [1, 1, 1]}>
          <sphereGeometry args={[0.55, 18, 14]} />
          <meshStandardMaterial color={stoneAtParotid ? "#f87171" : "#f9a8d4"} roughness={0.55} />
        </mesh>
        {/* submandibular gland (under jaw) */}
        <mesh position={[0.75, 4.35, 0.75]} scale={stoneAtSubmand && glandSwollen ? [1.5, 1.5, 1.5] : [1, 1, 1]}>
          <sphereGeometry args={[0.45, 18, 14]} />
          <meshStandardMaterial color={stoneAtSubmand ? "#f87171" : "#f9a8d4"} roughness={0.55} />
        </mesh>
        {/* salivary ducts */}
        <mesh position={[-0.5, 5.5, 0.85]} rotation={[0, 0, Math.PI / 2.4]}>
          <cylinderGeometry args={[0.07, 0.07, 1.3, 8]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
        </mesh>
        <mesh position={[0.45, 4.75, 0.95]} rotation={[0, 0, -Math.PI / 3]}>
          <cylinderGeometry args={[0.07, 0.07, 1.0, 8]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
        </mesh>
        {/* the stone */}
        {gland !== "none" && (
          <mesh position={stoneAtParotid ? [-0.5, 5.5, 0.85] : [0.45, 4.75, 0.95]}>
            <dodecahedronGeometry args={[0.22, 0]} />
            <meshStandardMaterial color="#a8a29e" roughness={0.9} flatShading />
          </mesh>
        )}

        <Label text="Lymph node chain" position={[2.9, 2.2, 0.75]} size={0.5} color={swelling > 60 ? "#fca5a5" : "#86efac"} />
        <Label text="Parotid gland" position={[-2.9, 6.3, 0.4]} size={0.48} color="#f9a8d4" />
        <Label text="Submandibular gland" position={[2.8, 4.5, 0.75]} size={0.48} color="#f9a8d4" />
        {gland !== "none" && <Label text="Stone blocks the duct → painful meal-time swelling" position={[0, 0.9, 0]} size={0.46} color="#fde047" />}
        <Animator nodes={nodes} elapsed={elapsed} swelling={swelling} />
      </SimCanvas>
    </div>
  );
}
