// Histology: respiratory/GI/liver — a breathing alveolar cluster, intestinal
// villi with capillary loops, and a hexagonal liver lobule with a central vein.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "breath", label: "Breathing rate", kind: "slider", min: 0.2, max: 2.5, step: 0.1, default: 1, unit: "×" },
  { key: "organ", label: "Highlight organ", kind: "select", min: 0, max: 0, step: 1, default: "all", options: ["all", "lung", "intestine", "liver"] },
];

export const UNIQUE_META = {
  title: "Histology: Lung, Intestine & Liver",
  blurb: "Alveoli inflate with each breath, villi soak up nutrients, and the liver lobule radiates around its central vein.",
};

function Animator({
  alveoli, breathAir, elapsed, breath,
}: {
  alveoli: React.RefObject<THREE.Group>;
  breathAir: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  breath: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const b = 0.5 + 0.5 * Math.sin(t * breath * Math.PI * 2);
    const s = 0.82 + 0.36 * b; // alveoli inflate/deflate
    if (alveoli.current) alveoli.current.children.forEach((m) => m.scale.setScalar(s));
    if (breathAir.current) {
      breathAir.current.scale.set(0.4 + 0.6 * b, 1, 0.4 + 0.6 * b);
      (breathAir.current.material as THREE.MeshBasicMaterial).opacity = 0.12 + 0.18 * b;
    }
  });
  return null;
}

export function Topic10019Sim(props: SimProps) {
  const breath = Number(props.breath ?? 1);
  const organ = String(props.organ ?? "all");
  const alveoli = useRef<THREE.Group>(null!);
  const breathAir = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const alveolusPos = useMemo(
    () =>
      [
        [0, 0, 0], [0.85, 0.3, 0.2], [-0.8, 0.35, -0.15], [0.4, 0.95, -0.3],
        [-0.35, 0.9, 0.35], [0.1, -0.75, 0.2], [-0.6, -0.5, 0.5], [0.7, -0.45, -0.4],
      ] as [number, number, number][],
    []
  );
  const villi = useMemo(() => Array.from({ length: 7 }).map((_, i) => -3 + i * 1), []);
  const liverSides = useMemo(() => Array.from({ length: 6 }).map((_, i) => (i / 6) * Math.PI * 2), []);

  const dim = (name: string) => (organ === "all" || organ === name ? 1 : 0.25);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Breathing", breath > 0.2 ? "inspiration ↔ expiration" : "paused"],
          ["Liver lobule", "hexagonal, central vein"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 6, 16]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* LUNG: bronchiole feeding an alveolar cluster */}
         <group position={[-7, 2, 0]}>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.35, 0.45, 3.4, 14]} />
            <meshStandardMaterial color="#c084fc" roughness={0.5} transparent opacity={dim("lung")} />
          </mesh>
          <group position={[2.0, 0, 0]} ref={alveoli}>
            {alveolusPos.map((p, i) => (
              <mesh key={i} position={p} castShadow>
                <sphereGeometry args={[0.5, 16, 16]} />
                <meshStandardMaterial color="#f9a8d4" roughness={0.4} transparent opacity={dim("lung") * 0.92} />
              </mesh>
            ))}
          </group>
          {/* inhaled air shimmer */}
          <mesh ref={breathAir} position={[0.4, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.5, 0.5, 3.2, 12]} />
            <meshBasicMaterial color="#bae6fd" transparent opacity={0.15} />
          </mesh>
        </group>
        <Label text="alveoli (lung)" position={[-6.6, 4.3, 0]} size={0.4} color="#f8fafc" />
        <Label text="bronchiole" position={[-9.4, 3.2, 0]} size={0.3} color="#d8b4fe" />

        {/* INTESTINE: villi with capillary loops */}
         <group position={[0, 0, 0]}>
          <mesh position={[0, 0.55, 0]} castShadow>
            <boxGeometry args={[8.4, 1.1, 2.2]} />
            <meshStandardMaterial color="#fb7185" roughness={0.55} transparent opacity={dim("intestine")} />
          </mesh>
          {villi.map((x, i) => (
            <group key={i} position={[x, 1.6, 0]}>
              <mesh castShadow>
                <coneGeometry args={[0.32, 1.5, 12]} />
                <meshStandardMaterial color="#fda4af" roughness={0.5} transparent opacity={dim("intestine")} />
              </mesh>
              <mesh position={[0, -0.3, 0]} rotation={[0, 0, Math.PI]}>
                <torusGeometry args={[0.14, 0.05, 8, 12, Math.PI]} />
                <meshStandardMaterial color="#dc2626" transparent opacity={dim("intestine")} />
              </mesh>
            </group>
          ))}
        </group>
        <Label text="intestinal villi" position={[0, 3.6, 0]} size={0.4} color="#f8fafc" />
        <Label text="capillary loop" position={[3.35, 1.35, 0]} size={0.3} color="#fda4af" />

        {/* LIVER: hexagonal lobule around central vein */}
         <group position={[7.6, 1.9, 0]}>
          {liverSides.map((a, i) => (
            <mesh key={i}
              position={[Math.cos(a) * 1.55, 0, Math.sin(a) * 1.55]}
              rotation={[0, -a + Math.PI / 2, 0]}>
              <boxGeometry args={[1.55, 1.9, 0.16]} />
              <meshStandardMaterial color="#92400e" roughness={0.6} transparent opacity={dim("liver")} />
            </mesh>
          ))}
          <mesh rotation={[0, 0, 0]} castShadow>
            <cylinderGeometry args={[0.32, 0.32, 2.2, 14]} />
            <meshStandardMaterial color="#3b82f6" emissive="#1e3a8a" emissiveIntensity={0.5} transparent opacity={dim("liver")} />
          </mesh>
          {Array.from({ length: 6 }).map((_, i) => {
            const a = (i / 6) * Math.PI * 2 + Math.PI / 6;
            return (
              <mesh key={i} position={[Math.cos(a) * 0.95, 0, Math.sin(a) * 0.95]}
                rotation={[0, 0, Math.PI / 2]}>
                <cylinderGeometry args={[0.07, 0.07, 1.1, 8]} />
                <meshStandardMaterial color="#fbbf24" transparent opacity={dim("liver")} />
              </mesh>
            );
          })}
        </group>
        <Label text="liver lobule" position={[7.6, 4.1, 0]} size={0.4} color="#f8fafc" />
        <Label text="central vein" position={[7.6, 0.45, 1.6]} size={0.3} color="#93c5fd" />
        <Label text="hepatocyte cords" position={[9.9, 2.5, 0]} size={0.28} color="#fde68a" />

        <Animator alveoli={alveoli} breathAir={breathAir} elapsed={elapsed} breath={breath} />
      </SimCanvas>
    </div>
  );
}
