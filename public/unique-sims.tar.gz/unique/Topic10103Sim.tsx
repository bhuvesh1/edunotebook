"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "demyelination", options: ["normal", "demyelination", "Alzheimer\u2019s", "brain tumor"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Neuron, Myelin & Brain Disease",
  blurb: "An action potential races down a myelinated axon; strip the myelin, add plaques, or grow a tumor.",
};

function Animator({ root, mye, sig, plq, tumr, elapsed, speed, demy, alz, tum }: { root: RefObject<THREE.Group>; mye: RefObject<THREE.Group>; sig: RefObject<THREE.Mesh>; plq: RefObject<THREE.Group>; tumr: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; demy: boolean; alz: boolean; tum: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (mye.current) {
      mye.current.children.forEach((m) => {
        m.scale.setScalar(demy ? 0.12 : 1);
      });
    }
    if (sig.current) {
      const v = demy ? 0.18 : 0.55;
      const q = (t * v) % 1;
      sig.current.position.set(-2.2 + q * 7.4, 2, 0);
      (sig.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 1.5 + Math.sin(t * 10) * 0.8;
    }
    if (plq.current) {
      plq.current.visible = alz;
      plq.current.rotation.y = t * 0.3;
    }
    if (tumr.current) {
      tumr.current.visible = tum;
      tumr.current.scale.setScalar(1 + 0.1 * Math.sin(t * 2));
    }
  });
  return null;
}

export function Topic10103Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const cond = String(props.cond ?? "demyelination");
  const demy = cond === "demyelination";
  const alz = cond === "Alzheimer\u2019s";
  const tum = cond === "brain tumor";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const mye = useRef<THREE.Group>(null!);
  const sig = useRef<THREE.Mesh>(null!);
  const plq = useRef<THREE.Group>(null!);
  const tumr = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", cond],
          ["Conduction", demy ? "slow \u2014 saltatory lost" : alz ? "synapses failing" : tum ? "compressed" : "fast saltatory"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[-3.4, 2, 0]} castShadow>
            <sphereGeometry args={[0.8, 22, 22]} /><meshStandardMaterial color="#fbbf24" roughness={0.45} />
          </mesh>
          {[-0.6, 0, 0.6].map((dy, i) => (
            <mesh key={i} position={[-4.1, 2 + dy, 0]} rotation={[0, 0, 1.1 + dy]}>
              <cylinderGeometry args={[0.09, 0.14, 1.1, 8]} /><meshStandardMaterial color="#f59e0b" roughness={0.55} />
            </mesh>
          ))}
          <Label text="cell body + dendrites" position={[-3.4, 3.3, 0]} size={0.4} color="#fbbf24" />
          <mesh position={[1.4, 2, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
            <cylinderGeometry args={[0.22, 0.22, 7.6, 12]} /><meshStandardMaterial color="#fde68a" roughness={0.5} />
          </mesh>
          <group ref={mye}>
            {[-1.4, 0, 1.4, 2.8].map((x, i) => (
              <mesh key={i} position={[x, 2, 0]} rotation={[0, Math.PI / 2, 0]}>
                <torusGeometry args={[0.42, 0.2, 12, 20]} /><meshStandardMaterial color="#38bdf8" roughness={0.45} />
              </mesh>
            ))}
          </group>
          <Label text="myelin sheath" position={[0.7, 2.9, 0]} size={0.4} color="#38bdf8" />
          <mesh ref={sig}>
            <sphereGeometry args={[0.2, 12, 12]} /><meshStandardMaterial color="#fef08a" emissive="#facc15" emissiveIntensity={1.5} />
          </mesh>
          <Label text="action potential" position={[1.4, 1.2, 0]} size={0.38} color="#fef08a" />
          <group ref={plq} visible={false} position={[-3.4, 2, 0]}>
            {[0, 1, 2, 3, 4].map((i) => (
              <mesh key={i} position={[Math.cos(i * 2.4) * 1.3, Math.sin(i * 1.8) * 0.9, Math.sin(i * 3) * 1.1]}>
                <dodecahedronGeometry args={[0.3]} /><meshStandardMaterial color="#a8a29e" roughness={0.8} flatShading />
              </mesh>
            ))}
            <Label text="amyloid plaques" position={[0, 1.7, 0]} size={0.38} color="#d6d3d1" />
          </group>
          <mesh ref={tumr} visible={false} position={[3.4, 2.3, 0]} castShadow>
            <icosahedronGeometry args={[0.85, 1]} /><meshStandardMaterial color="#7c3aed" emissive="#5b21b6" emissiveIntensity={0.6} roughness={0.55} flatShading />
          </mesh>
          <Label text={demy ? "demyelination \u2014 signal crawls" : alz ? "Alzheimer\u2019s \u2014 plaques + tangles" : tum ? "tumor compressing axon" : "healthy myelinated neuron"} position={[0, 4.6, 0]} size={0.46} color={cond === "normal" ? "#4ade80" : "#f87171"} />
        </group>
        <Animator root={root} mye={mye} sig={sig} plq={plq} tumr={tumr} elapsed={elapsed} speed={speed} demy={demy} alz={alz} tum={tum} />
      </SimCanvas>
    </div>
  );
}
