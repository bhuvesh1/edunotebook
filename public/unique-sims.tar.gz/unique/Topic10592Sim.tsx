// Topic10592 — Denture care in elderly, root caries.
// A full denture soaks in fizzy cleanser — bubbles lift the stains
// away. Beside it, a natural tooth shows root caries: decay creeping
// in where the gum has receded with age.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "soak", label: "Soaking time", kind: "slider", min: 0, max: 100, step: 5, default: 65, unit: "%" },
];

export const UNIQUE_META = {
  title: "Denture care in elderly, root caries",
  blurb: "A denture fizzes clean in its nightly soak — while a natural root shows the caries age brings.",
};

function Animator({
  bubbles,
  denture,
  elapsed,
}: {
  bubbles: RefObject<THREE.Group>;
  denture: RefObject<THREE.Group>;
  elapsed: RefObject<number>;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (bubbles.current) {
      bubbles.current.children.forEach((m, i) => {
        const y = 0.6 + ((t * (0.7 + (i % 3) * 0.25) + i * 0.55) % 2.6);
        m.position.set(
          Math.sin(t * 1.5 + i * 2.4) * 0.9,
          y,
          Math.cos(t * 1.2 + i * 1.8) * 0.9
        );
        m.scale.setScalar(0.6 + 0.5 * Math.abs(Math.sin(t * 2 + i)));
      });
    }
    if (denture.current) {
      denture.current.rotation.y = Math.sin(t * 0.6) * 0.35;
      denture.current.position.y = 1.9 + Math.sin(t * 1.1) * 0.08;
    }
  });
  return null;
}

export function Topic10592Sim(props: SimProps) {
  const soak = Number(props.soak ?? 65);
  const bubbles = useRef<THREE.Group>(null!);
  const denture = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const clean = soak / 100;
  const toothWhite = useMemo(
    () => new THREE.Color("#c9a227").lerp(new THREE.Color("#fefdf8"), clean),
    [clean]
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Cleanliness", `${Math.round(clean * 100)}%`],
          ["Routine", "Brush daily, soak nightly"],
          ["Root caries risk", "High after 60"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* glass of denture cleanser */}
        <mesh position={[-2.6, 1.55, 0]}>
          <cylinderGeometry args={[1.7, 1.5, 2.9, 24, 1, true]} />
          <meshStandardMaterial color="#7dd3fc" transparent opacity={0.22} roughness={0.1} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[-2.6, 0.18, 0]}>
          <cylinderGeometry args={[1.5, 1.5, 0.25, 24]} />
          <meshStandardMaterial color="#7dd3fc" transparent opacity={0.3} roughness={0.15} />
        </mesh>
        {/* blue cleanser water */}
        <mesh position={[-2.6, 1.5, 0]}>
          <cylinderGeometry args={[1.55, 1.4, 2.4, 24]} />
          <meshStandardMaterial color="#0ea5e9" transparent opacity={0.35} roughness={0.2} />
        </mesh>

        {/* the denture soaking inside */}
        <group ref={denture} position={[-2.6, 1.9, 0]}>
          <mesh castShadow rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.85, 0.32, 12, 24, Math.PI]} />
            <meshStandardMaterial color="#f472b6" roughness={0.55} />
          </mesh>
          {Array.from({ length: 7 }).map((_, i) => {
            const a = Math.PI - (i / 6) * Math.PI;
            return (
              <mesh key={i} position={[Math.cos(a) * 0.85, 0.42, Math.sin(a) * 0.85]} castShadow>
                <boxGeometry args={[0.3, 0.42, 0.3]} />
                <meshStandardMaterial color={toothWhite} roughness={0.3} />
              </mesh>
            );
          })}
        </group>

        {/* fizzing cleanser bubbles */}
        <group ref={bubbles}>
          {Array.from({ length: 18 }).map((_, i) => (
            <mesh key={i} position={[-2.6, 0.8, 0]}>
              <sphereGeometry args={[0.08, 8, 8]} />
              <meshStandardMaterial color="#e0f2fe" transparent opacity={0.8} roughness={0.1} />
            </mesh>
          ))}
        </group>

        {/* natural tooth with root caries */}
        <group position={[2.8, 0, 0]}>
          <mesh position={[0, 2.3, 0]} castShadow>
            <cylinderGeometry args={[0.8, 0.65, 1.5, 18]} />
            <meshStandardMaterial color="#fefdf8" roughness={0.3} />
          </mesh>
          <mesh position={[0, 0.9, 0]} castShadow>
            <coneGeometry args={[0.55, 1.4, 16]} />
            <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
          </mesh>
          {/* receded gum */}
          <mesh position={[0, 1.15, 0]}>
            <cylinderGeometry args={[1.5, 1.7, 0.5, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.7} />
          </mesh>
          {/* the root caries lesion */}
          <mesh position={[0.45, 0.85, 0.25]} rotation={[0, 0.6, 0]}>
            <circleGeometry args={[0.3, 16]} />
            <meshStandardMaterial color="#5b3a1e" roughness={0.95} />
          </mesh>
        </group>

        <Label text="DENTURE — nightly fizzy soak lifts stains" position={[-2.6, 4.6, 0]} size={0.4} color="#7dd3fc" />
        <Label text="ROOT CARIES — gum recedes, root decays" position={[2.8, 4.1, 0]} size={0.4} color="#fca5a5" />
        <Label text="Elderly tip: fluoride toothpaste protects exposed roots" position={[0, -0.35, 0]} size={0.36} color="#86efac" />

        <Animator bubbles={bubbles} denture={denture} elapsed={elapsed} />
      </SimCanvas>
    </div>
  );
}
