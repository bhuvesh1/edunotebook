"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "bpm", label: "Heart rate", kind: "slider", min: 40, max: 140, step: 5, default: 72, unit: " bpm" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Thorax: thoracic wall, lungs, pleura, mediastinum, heart, great vessels",
  blurb: "Inside the ribcage: the heart beats between two breathing lungs, with the great vessels arching above.",
};

function Thorax({ bpm }: { bpm: number }) {
  const heart = useRef<THREE.Group>(null!);
  const lungL = useRef<THREE.Mesh>(null!);
  const lungR = useRef<THREE.Mesh>(null!);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d;
    const beat = 60 / bpm;
    const hp = (t.current % beat) / beat;
    const pulse = Math.max(0, Math.sin(hp * Math.PI * 2)) ** 2;
    if (heart.current) heart.current.scale.setScalar(1 + pulse * 0.16);
    const br = 1 + Math.sin(t.current * 1.7) * 0.1;
    if (lungL.current) lungL.current.scale.set(br, 1, br);
    if (lungR.current) lungR.current.scale.set(br, 1, br);
  });
  return (
    <group position={[0, 0.8, 0]}>
      {/* ribcage: 6 ribs */}
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <mesh key={i} position={[0, 4.4 - i * 0.55, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <torusGeometry args={[1.55 - i * 0.09, 0.09, 10, 30]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.6} />
        </mesh>
      ))}
      {/* sternum */}
      <mesh position={[0, 3.0, 1.5]} castShadow>
        <boxGeometry args={[0.35, 2.8, 0.25]} />
        <meshStandardMaterial color="#f5f0e6" roughness={0.55} />
      </mesh>
      {/* spine hint */}
      <mesh position={[0, 3.0, -1.5]} castShadow>
        <boxGeometry args={[0.4, 3.4, 0.4]} />
        <meshStandardMaterial color="#d6d3d1" roughness={0.6} />
      </mesh>
      {/* lungs */}
      <mesh ref={lungL} position={[-0.85, 3.2, 0]}>
        <sphereGeometry args={[0.62, 18, 18]} />
        <meshStandardMaterial color="#fda4af" roughness={0.6} transparent opacity={0.92} />
      </mesh>
      <mesh ref={lungR} position={[0.85, 3.2, 0]}>
        <sphereGeometry args={[0.62, 18, 18]} />
        <meshStandardMaterial color="#fda4af" roughness={0.6} transparent opacity={0.92} />
      </mesh>
      {/* heart in the mediastinum */}
      <group ref={heart} position={[0, 2.9, 0.35]}>
        <mesh castShadow>
          <sphereGeometry args={[0.5, 20, 20]} />
          <meshStandardMaterial color="#dc2626" emissive="#991b1b" emissiveIntensity={0.55} roughness={0.35} />
        </mesh>
        <mesh position={[0.1, 0.45, 0]}>
          <sphereGeometry args={[0.22, 14, 14]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.4} />
        </mesh>
      </group>
      {/* aorta arch */}
      <mesh position={[0, 3.9, 0.3]} rotation={[0, 0, 0]} castShadow>
        <torusGeometry args={[0.42, 0.13, 10, 20, Math.PI]} />
        <meshStandardMaterial color="#ef4444" roughness={0.4} />
      </mesh>
      {/* vena cava / pulmonary trunk hints */}
      {[-0.3, 0.3].map((x) => (
        <mesh key={x} position={[x, 3.6, 0.1]} castShadow>
          <cylinderGeometry args={[0.11, 0.11, 1.0, 10]} />
          <meshStandardMaterial color={x > 0 ? "#3b82f6" : "#ef4444"} roughness={0.4} />
        </mesh>
      ))}
    </group>
  );
}

export function Topic10005Sim(props: SimProps) {
  const bpm = Number(props.bpm ?? 72);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Heart", bpm + " bpm"], ["Ribs", "12 pairs"], ["Cavity", "thoracic"]]} />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 3.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Thorax bpm={bpm} />
        {showLabels && (
          <>
            <Label text="Ribcage" position={[-3.2, 5.4, 0]} color="#e7e5e4" size={0.5} />
            <Label text="Heart" position={[2.4, 3.9, 0.6]} color="#fca5a5" size={0.5} />
            <Label text="Lungs" position={[-2.8, 3.4, 0]} color="#fda4af" size={0.5} />
            <Label text="Aorta" position={[1.6, 5.0, 0]} color="#f87171" size={0.45} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
