"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "arch", label: "Arch", kind: "select", min: 0, max: 0, step: 1, default: "upper", options: ["upper", "lower"] },
  { key: "stage", label: "Step", kind: "select", min: 0, max: 0, step: 1, default: "impression", options: ["examination", "impression", "tray"] },
];

export const UNIQUE_META = {
  title: "Complete dentures: diagnosis, treatment planning, impressions",
  blurb: "A toothless gum ridge meets its impression tray — the tray presses up, pink material captures every detail of the ridge.",
};

const STEPS: Record<string, { name: string; note: string }> = {
  examination: { name: "Examination", note: "Check ridge shape, saliva, muscle tone" },
  impression: { name: "Primary impression", note: "Alginate in a stock tray — the first copy" },
  tray: { name: "Custom tray + final impression", note: "Border-moulded tray — the master cast" },
};

function Scene({ arch, stage }: { arch: string; stage: string }) {
  const tray = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const st = STEPS[stage] ?? STEPS.impression;
  const upper = arch === "upper";

  useFrame((_, delta) => {
    t.current += delta;
    if (tray.current) {
      if (stage === "impression") {
        // press up and down
        const f = (Math.sin(t.current * 1.4) + 1) / 2;
        tray.current.position.y = (upper ? -1.6 : 1.6) + (upper ? 1 : -1) * f * 1.35;
      } else {
        tray.current.position.y = (upper ? -1.6 : 1.6) + Math.sin(t.current) * 0.08;
      }
    }
  });

  return (
    <group rotation={[0, 0, upper ? 0 : Math.PI]}>
      {/* edentulous ridge (gum arch, no teeth) */}
      <mesh position={[0, 1.2, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[2.2, 0.62, 16, 40, Math.PI]} />
        <meshStandardMaterial color="#e0788a" roughness={0.55} />
      </mesh>
      {/* palate */}
      {upper && (
        <mesh position={[0, 1.2, -0.4]} rotation={[Math.PI / 2.6, 0, 0]}>
          <sphereGeometry args={[1.9, 20, 12, 0, Math.PI * 2, 0, Math.PI / 3]} />
          <meshStandardMaterial color="#d98a94" roughness={0.6} side={THREE.DoubleSide} />
        </mesh>
      )}
      <Label text={upper ? "Upper ridge (no teeth)" : "Lower ridge (no teeth)"} position={[-3.4, 1.2, 0]} size={0.45} color="#fda4af" />

      {/* impression tray */}
      <group ref={tray} position={[0, upper ? -1.6 : 1.6, 0]}>
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[2.2, 0.5, 12, 32, Math.PI]} />
          <meshStandardMaterial color="#94a3b8" metalness={0.5} roughness={0.45} />
        </mesh>
        <mesh position={[0, 0, -1.9]} rotation={[0.4, 0, 0]}>
          <boxGeometry args={[0.5, 0.18, 1.4]} />
          <meshStandardMaterial color="#64748b" metalness={0.5} roughness={0.45} />
        </mesh>
        {/* impression material */}
        <mesh position={[0, 0.35, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[2.2, 0.34, 12, 32, Math.PI]} />
          <meshStandardMaterial color={stage === "tray" ? "#f472b6" : "#f9a8d4"} roughness={0.35} />
        </mesh>
        <Label text={stage === "tray" ? "Custom tray" : "Stock tray + alginate"} position={[0, -1.0, 0]} size={0.42} color="#e2e8f0" />
      </group>

      {stage === "examination" && (
        <group position={[2.8, 2.6, 0]}>
          <mesh rotation={[0, 0, -0.6]}>
            <boxGeometry args={[0.12, 1.6, 0.12]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.7} roughness={0.35} />
          </mesh>
          <mesh position={[0.35, -0.7, 0]} rotation={[0, 0, -0.6]}>
            <circleGeometry args={[0.3, 16]} />
            <meshStandardMaterial color="#e0f2fe" transparent opacity={0.6} roughness={0.2} side={THREE.DoubleSide} />
          </mesh>
          <Label text="Mouth mirror exam" position={[0, 1.1, 0]} size={0.4} color="#bae6fd" />
        </group>
      )}

      <Label text={st.name} position={[0, 3.8, 0]} size={0.65} color="#f9a8d4" />
      <Label text={st.note} position={[0, -3.2, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10428Sim(props: SimProps) {
  const arch = String(props.arch ?? "upper");
  const stage = String(props.stage ?? "impression");
  const st = STEPS[stage] ?? STEPS.impression;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Arch", arch === "upper" ? "Maxillary" : "Mandibular"], ["Step", st.name], ["Material", stage === "tray" ? "Zinc-oxide eugenol" : "Alginate"]]} />
      <SimCanvas cameraPosition={[0, 2.5, 10]} target={[0, 0.6, 0]}>
        <Scene arch={arch} stage={stage} />
      </SimCanvas>
    </div>
  );
}
