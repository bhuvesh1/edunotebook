"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "agent", label: "Agent", kind: "select", min: 0, max: 0, step: 1, default: "nystatin", options: ["nystatin", "fluconazole", "acyclovir"] },
  { key: "day", label: "Treatment day", kind: "slider", min: 0, max: 14, step: 1, default: 0, unit: "d" },
];

export const UNIQUE_META = {
  title: "Antifungals and antivirals in oral infections",
  blurb: "White fungal threads on the tongue melt away day by day as the antifungal — or antiviral — takes effect.",
};

const INFO: Record<string, { name: string; target: string; color: string; note: string }> = {
  nystatin: { name: "Nystatin suspension", target: "fungal", color: "#fde68a", note: "Swish & swallow — topical for thrush" },
  fluconazole: { name: "Fluconazole", target: "fungal", color: "#fdba74", note: "Systemic — for stubborn candidiasis" },
  acyclovir: { name: "Acyclovir", target: "viral", color: "#7dd3fc", note: "For herpes labialis / herpetic gingivostomatitis" },
};

function Hyphae({ remaining }: { remaining: number }) {
  const group = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const threads = useMemo(() => {
    const arr: { p: [number, number, number]; r: [number, number, number]; l: number }[] = [];
    for (let i = 0; i < 22; i++) {
      arr.push({
        p: [(Math.random() - 0.5) * 3.6, 0.25 + Math.random() * 0.15, (Math.random() - 0.5) * 2.2],
        r: [Math.random() * 0.8, 0, Math.random() * Math.PI],
        l: 0.5 + Math.random() * 0.7,
      });
    }
    return arr;
  }, []);
  useFrame((_, delta) => {
    t.current += delta;
    if (group.current) group.current.rotation.y = Math.sin(t.current * 0.4) * 0.15;
  });
  const show = Math.ceil(threads.length * remaining);
  return (
    <group ref={group}>
      {threads.slice(0, show).map((h, i) => (
        <group key={i} position={h.p} rotation={h.r}>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.035, 0.035, h.l, 6]} />
            <meshStandardMaterial color="#fefce8" roughness={0.8} />
          </mesh>
          <mesh position={[h.l / 2, 0, 0]} rotation={[0, 0, 0.7]}>
            <cylinderGeometry args={[0.03, 0.03, h.l * 0.5, 6]} />
            <meshStandardMaterial color="#fefce8" roughness={0.8} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function ViralBlister({ remaining }: { remaining: number }) {
  const blisters = [[-0.8, 0.5], [0, 0.7], [0.8, 0.5], [-0.4, 0.1], [0.4, 0.1]];
  const show = Math.ceil(blisters.length * remaining);
  return (
    <group position={[0, 0, 2.05]}>
      {blisters.slice(0, show).map(([x, y], i) => (
        <mesh key={i} position={[x, y, 0]}>
          <sphereGeometry args={[0.22, 12, 12]} />
          <meshStandardMaterial color="#f87171" roughness={0.3} transparent opacity={0.85} />
        </mesh>
      ))}
    </group>
  );
}

function Scene({ agent, day }: { agent: string; day: number }) {
  const info = INFO[agent] ?? INFO.nystatin;
  const remaining = Math.max(0, 1 - day / 12);
  const drops = useRef<THREE.Group>(null!);
  const t = useRef(0);

  useFrame((_, delta) => {
    t.current += delta;
    if (drops.current) {
      drops.current.children.forEach((c, i) => {
        c.position.y = 2.6 - ((t.current * 0.9 + i * 0.25) % 2.2);
      });
    }
  });

  return (
    <group>
      {/* lips */}
      <mesh position={[0, 0.35, 1.9]}>
        <torusGeometry args={[1.85, 0.4, 14, 32]} />
        <meshStandardMaterial color="#c2556a" roughness={0.5} />
      </mesh>
      {/* tongue */}
      <mesh position={[0, -0.4, 1.0]} scale={[1.6, 0.5, 1.2]}>
        <sphereGeometry args={[1, 24, 24]} />
        <meshStandardMaterial color={remaining > 0.4 ? "#c9828f" : "#d96a7e"} roughness={0.55} />
      </mesh>
      {/* white coating */}
      {remaining > 0.05 && info.target === "fungal" && (
        <mesh position={[0, -0.02, 1.0]} scale={[1.35, 0.18, 1.0]}>
          <sphereGeometry args={[1, 20, 20]} />
          <meshStandardMaterial color="#fefce8" transparent opacity={0.55 * remaining + 0.1} roughness={0.9} />
        </mesh>
      )}

      {info.target === "fungal" ? <Hyphae remaining={remaining} /> : <ViralBlister remaining={remaining} />}

      {/* medicine drops */}
      <group ref={drops}>
        {[0, 1, 2, 3].map((i) => (
          <mesh key={i} position={[-0.6 + i * 0.4, 2, 1.2]}>
            <sphereGeometry args={[0.11, 10, 10]} />
            <meshStandardMaterial color={info.color} emissive={info.color} emissiveIntensity={0.8} />
          </mesh>
        ))}
      </group>
      <Label text={`${info.name} drops`} position={[0, 3.0, 1.2]} size={0.45} color={info.color} />

      <Label text={info.name} position={[0, 3.7, 0]} size={0.6} color={info.color} />
      <Label text={remaining <= 0.02 ? "Infection cleared ✓" : `${Math.round(remaining * 100)}% infection left — ${info.note}`} position={[0, -2.4, 0.8]} size={0.45} color={remaining <= 0.02 ? "#86efac" : "#e2e8f0"} />
    </group>
  );
}

export function Topic10421Sim(props: SimProps) {
  const agent = String(props.agent ?? "nystatin");
  const day = Number(props.day ?? 0);
  const info = INFO[agent] ?? INFO.nystatin;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Agent", info.name], ["Day", `${day}/14`], ["Status", day >= 12 ? "Cleared" : "Treating"]]} />
      <SimCanvas cameraPosition={[0, 1, 8.5]} target={[0, 0.3, 1]}>
        <Scene agent={agent} day={day} />
      </SimCanvas>
    </div>
  );
}
