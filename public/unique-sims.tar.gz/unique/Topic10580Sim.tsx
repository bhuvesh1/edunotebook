// Topic10580 — Veneers: composite and ceramic.
// A chipped, stained front tooth gets a paper-thin veneer shell that
// slides on and bonds. Compare glassy ceramic with opaque composite.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "material", label: "Veneer material", kind: "select", min: 0, max: 0, step: 1, default: "ceramic", options: ["ceramic", "composite"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Veneers: composite and ceramic",
  blurb: "A thin porcelain shell slides over a chipped tooth — compare glassy ceramic with chairside composite.",
};

function Animator({
  shell,
  sparkle,
  elapsed,
  speed,
}: {
  shell: RefObject<THREE.Group>;
  sparkle: RefObject<THREE.Group>;
  elapsed: RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current % 8; // loop: approach -> bond -> lift -> repeat
    if (shell.current) {
      let x: number;
      if (t < 3) x = 3.2 - (t / 3) * 2.35; // slides in
      else if (t < 5.5) x = 0.85; // bonded, seated
      else x = 0.85 + ((t - 5.5) / 2.5) * 2.35; // lifts off
      shell.current.position.x = x;
      shell.current.position.y = 2.15 + Math.sin(elapsed.current * 2) * 0.03;
    }
    if (sparkle.current) {
      const bonded = t >= 3 && t < 5.5;
      sparkle.current.visible = bonded;
      sparkle.current.rotation.y = elapsed.current * 3;
      sparkle.current.children.forEach((m, i) => {
        m.scale.setScalar(bonded ? 0.6 + 0.4 * Math.abs(Math.sin(elapsed.current * 5 + i)) : 0.001);
      });
    }
  });
  return null;
}

export function Topic10580Sim(props: SimProps) {
  const material = String(props.material ?? "ceramic");
  const speed = Number(props.speed ?? 1);
  const ceramic = material === "ceramic";
  const shell = useRef<THREE.Group>(null!);
  const sparkle = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const veneerMat = useMemo(
    () =>
      ceramic
        ? { color: "#ffffff", roughness: 0.08, opacity: 0.92, emissive: "#dbeafe", ei: 0.15 }
        : { color: "#fef3c7", roughness: 0.45, opacity: 1, emissive: "#000000", ei: 0 },
    [ceramic]
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Material", ceramic ? "Ceramic" : "Composite"],
          ["Thickness", ceramic ? "0.3 mm" : "0.5 mm"],
          ["Lifespan", ceramic ? "10–15 yrs" : "5–7 yrs"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 11]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* damaged tooth: stained crown with a chip notch */}
        <mesh position={[0, 2.15, 0]} castShadow>
          <cylinderGeometry args={[0.85, 0.68, 1.7, 20]} />
          <meshStandardMaterial color="#c9a227" roughness={0.55} />
        </mesh>
        <mesh position={[0.42, 2.9, 0.3]} castShadow>
          <boxGeometry args={[0.34, 0.3, 0.5]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <mesh position={[0, 0.75, 0]} castShadow>
          <coneGeometry args={[0.6, 1.3, 18]} />
          <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
        </mesh>
        <mesh position={[0, 0.55, 0]}>
          <cylinderGeometry args={[1.9, 2.3, 0.7, 24]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.7} />
        </mesh>

        {/* the veneer: thin curved shell that seats on the front face */}
        <group ref={shell} position={[3.2, 2.15, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[1.02, 0.86, 1.85, 20, 1, true, -0.85, 1.7]} />
            <meshStandardMaterial
              color={veneerMat.color}
              roughness={veneerMat.roughness}
              transparent
              opacity={veneerMat.opacity}
              emissive={veneerMat.emissive}
              emissiveIntensity={veneerMat.ei}
              side={THREE.DoubleSide}
            />
          </mesh>
          {/* bond sparkle while seated */}
          <group ref={sparkle} position={[0, 0.4, 0.9]}>
            {Array.from({ length: 6 }).map((_, i) => {
              const a = (i / 6) * Math.PI * 2;
              return (
                <mesh key={i} position={[Math.cos(a) * 0.7, Math.sin(a) * 0.7, 0]}>
                  <octahedronGeometry args={[0.09]} />
                  <meshStandardMaterial color="#fef9c3" emissive="#facc15" emissiveIntensity={1.5} />
                </mesh>
              );
            })}
          </group>
        </group>

        <Label text="CHIPPED, STAINED TOOTH" position={[-3.2, 2.2, 0]} size={0.38} color="#fcd34d" />
        <Label text={ceramic ? "CERAMIC VENEER — glassy, 0.3 mm" : "COMPOSITE VENEER — opaque, 0.5 mm"} position={[0, 4.4, 0]} size={0.4} color="#e0f2fe" />
        <Label text="RESIN CEMENT BONDS IT FOREVER" position={[0, -0.75, 0]} size={0.36} color="#94a3b8" />

        <Animator shell={shell} sparkle={sparkle} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
