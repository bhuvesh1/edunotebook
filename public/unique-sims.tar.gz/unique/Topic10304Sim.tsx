// Pediatric orthopedics: CTEV, DDH, Perthes disease, SCFE.
// Children's bones grow — and grow wrong. A clubfoot twists inward then
// straightens with casts; the hip slips out in DDH; the femoral head
// flattens in Perthes.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "ctev", options: ["ctev", "ddh", "perthes", "scfe"] },
  { key: "correction", label: "Correction", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.6, unit: "" },
];

export const UNIQUE_META = {
  title: "Children's Bones: Clubfoot & Hip",
  blurb: "Clubfoot twisting inward then straightening, a hip slipping from its socket, or a femoral head going flat.",
};

function Animator({
  group, foot, hipBall, head, elapsed, correction, condition,
}: {
  group: React.RefObject<THREE.Group>;
  foot: React.RefObject<THREE.Group>;
  hipBall: React.RefObject<THREE.Mesh>;
  head: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  correction: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // clubfoot: twist corrects with the slider; cast appears when corrected
    if (foot.current && condition === "ctev") {
      const twist = (1 - correction) * 1.1;
      foot.current.rotation.y = twist;
      foot.current.rotation.z = twist * 0.7;
      foot.current.position.x = -0.2 + correction * 0.2;
    }
    if (hipBall.current && condition === "ddh") {
      // hip pops in/out with correction
      const out = (1 - correction) * 0.9;
      hipBall.current.position.x = 0.3 + out * 0.8;
      hipBall.current.position.y = 3.0 - out * 0.4;
    }
    if (head.current && (condition === "perthes" || condition === "scfe")) {
      const flat = 1 - correction * 0.45;
      head.current.scale.set(1, condition === "perthes" ? flat : 1, 1);
      if (condition === "scfe") head.current.position.x = 0.3 - correction * 0.45; // slipped epiphysis slides back
      (head.current.material as THREE.MeshStandardMaterial).emissiveIntensity = (1 - correction) * 0.7;
    }
  });
  return null;
}

export function Topic10304Sim(props: SimProps) {
  const condition = String(props.condition ?? "ctev");
  const correction = Number(props.correction ?? 0.6);
  const group = useRef<THREE.Group>(null!);
  const foot = useRef<THREE.Group>(null!);
  const hipBall = useRef<THREE.Mesh>(null!);
  const head = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    ctev: "CTEV (clubfoot)", ddh: "DDH (hip dysplasia)", perthes: "Perthes disease", scfe: "SCFE (slipped epiphysis)",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Correction", `${Math.round(correction * 100)}%`]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {condition === "ctev" && (
            <>
              {/* lower leg */}
              <mesh position={[0, 2.6, 0]} castShadow>
                <cylinderGeometry args={[0.28, 0.24, 1.8, 14]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              {/* the clubfoot: twisted inward */}
              <group ref={foot} position={[0, 1.5, 0]}>
                <mesh position={[-0.2, -0.25, 0.15]} rotation={[0, 0, 0.2]} castShadow>
                  <boxGeometry args={[0.55, 0.4, 1.1]} />
                  <meshStandardMaterial color="#f5c396" roughness={0.6} />
                </mesh>
                {[-0.35, -0.15, 0.05, 0.25].map((x, i) => (
                  <mesh key={i} position={[x - 0.2, -0.35, 0.85]} castShadow>
                    <cylinderGeometry args={[0.06, 0.06, 0.3, 8]} />
                    <meshStandardMaterial color="#f5c396" roughness={0.6} />
                  </mesh>
                ))}
              </group>
              {/* corrective cast appears as correction rises */}
              {correction > 0.35 && (
                <mesh position={[0, 1.9, 0]} castShadow>
                  <capsuleGeometry args={[0.55, 1.6, 8, 14]} />
                  <meshStandardMaterial color="#fef3c7" roughness={0.8} transparent opacity={0.55} />
                </mesh>
              )}
              <Label text={correction > 0.7 ? "✨ Straightened!" : "⚠ Foot twists inward"} position={[0, 0.4, 0]} size={0.6} color={correction > 0.7 ? "#86efac" : "#fca5a5"} />
              <Label text="Weekly casts correct it" position={[-2.4, 2.6, 0]} size={0.5} color="#fef3c7" />
            </>
          )}
          {condition === "ddh" && (
            <>
              {/* shallow socket */}
              <mesh position={[-0.4, 3.1, -0.2]} scale={[1.2, 0.9, 1]} castShadow>
                <sphereGeometry args={[0.65, 18, 14]} />
                <meshStandardMaterial color="#cbd5e1" roughness={0.5} />
              </mesh>
              <mesh ref={hipBall} position={[0.3, 3.0, 0.2]} castShadow>
                <sphereGeometry args={[0.34, 18, 14]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
              <mesh position={[0.3, 2.2, 0.2]} castShadow>
                <cylinderGeometry args={[0.16, 0.18, 1.4, 12]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
              <Label text={correction > 0.6 ? "Hip back in socket ✓" : "⚠ Hip out of shallow socket"} position={[0, 1.0, 0.2]} size={0.6} color={correction > 0.6 ? "#86efac" : "#fca5a5"} />
            </>
          )}
          {(condition === "perthes" || condition === "scfe") && (
            <>
              <mesh position={[-0.5, 3.1, -0.2]} scale={[1.2, 1, 1]} castShadow>
                <sphereGeometry args={[0.65, 18, 14]} />
                <meshStandardMaterial color="#cbd5e1" roughness={0.5} />
              </mesh>
              <mesh ref={head} position={[0.3, 3.0, 0.2]} castShadow>
                <sphereGeometry args={[0.36, 18, 14]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.4} />
              </mesh>
              <mesh position={[0.3, 2.2, 0.2]} castShadow>
                <cylinderGeometry args={[0.16, 0.18, 1.4, 12]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.5} />
              </mesh>
              <Label text={condition === "perthes" ? "⚠ Femoral head flattening" : "⚠ Growth plate slipping"} position={[0, 1.0, 0.2]} size={0.6} color="#fca5a5" />
              <Label text="Correction contains the head" position={[-2.3, 2.4, 0]} size={0.5} color="#86efac" />
            </>
          )}
        </group>
        <Animator group={group} foot={foot} hipBall={hipBall} head={head} elapsed={elapsed} correction={correction} condition={condition} />
      </SimCanvas>
    </div>
  );
}
