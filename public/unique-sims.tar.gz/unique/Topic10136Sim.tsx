// Anaerobes: drumstick Clostridium rods with terminal spores thrive in the
// oxygen-free jar while spiral H. pylori burrows into the stomach lining.
"use client";

import { useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "o2", label: "Oxygen in jar", kind: "slider", min: 0, max: 100, step: 5, default: 5, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Anaerobes: clostridia & H. pylori",
  blurb: "Drumstick clostridia thrive without oxygen while spiral H. pylori burrows into the stomach.",
};

const N_CLOS = 7;

function Animator({ clos, hp, o2bub, elapsed, o2, setTick }: {
  clos: React.RefObject<(THREE.Group | null)[]>;
  hp: React.RefObject<THREE.Group>;
  o2bub: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  o2: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const happy = 1 - o2 / 100; // anaerobes hate oxygen
    clos.current.forEach((g, i) => {
      if (!g) return;
      g.visible = happy > 0.08 || ((i * 37) % 10) / 10 < happy + 0.1;
      g.position.y = 1.3 + Math.sin(t * (0.8 + happy * 1.6) + i * 2.3) * 0.16 * happy;
      g.rotation.z = Math.PI / 2 + Math.sin(t * 1.2 + i) * 0.3;
      const s = 0.6 + happy * 0.5;
      g.scale.setScalar(s);
    });
    if (hp.current) {
      // H. pylori corkscrews into the stomach wall
      hp.current.rotation.x = t * (2 + happy * 4);
      hp.current.position.z = -0.4 + Math.sin(t * 0.8) * 0.25;
    }
    o2bub.current.forEach((b, i) => {
      if (!b) return;
      const f = (t * 0.5 + i / 8) % 1;
      b.position.set(-3 + (i % 4) * 0.7, 0.5 + f * 2.6, (Math.floor(i / 4) - 0.5) * 1.6);
      b.visible = o2 > 10;
      ((b as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = Math.max(0, 0.6 - f * 0.6) * (o2 / 100);
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(happy * 100)); }
  });
  return null;
}

export function Topic10136Sim(props: SimProps) {
  const o2 = Number(props.o2 ?? 5);
  const showLabels = String(props.detail ?? "on") === "on";
  const clos = useRef<(THREE.Group | null)[]>([]);
  const hp = useRef<THREE.Group>(null!);
  const o2bub = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const hpGeo = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 40; i++) {
      const a = (i / 40) * Math.PI * 5;
      pts.push(new THREE.Vector3((i / 40 - 0.5) * 2.2, Math.cos(a) * 0.3, Math.sin(a) * 0.3));
    }
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 48, 0.13, 8);
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Jar oxygen", `${o2}%`],
          ["Anaerobe growth", `${tick}%`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 13]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* anaerobic jar */}
        <mesh position={[-2.6, 1.7, 0]}>
          <boxGeometry args={[4.6, 3.4, 3]} />
          <meshStandardMaterial color="#7dd3fc" transparent opacity={0.18} roughness={0.1} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[-2.6, 3.55, 0]}>
          <boxGeometry args={[4.8, 0.3, 3.2]} />
          <meshStandardMaterial color="#334155" metalness={0.5} roughness={0.4} />
        </mesh>
        {showLabels && <Label text="anaerobic jar — no oxygen" position={[-2.6, 4.3, 0]} color="#7dd3fc" />}

        {/* Clostridium drumsticks: rod + terminal spore */}
        {Array.from({ length: N_CLOS }).map((_, i) => (
          <group
            key={i}
            ref={(g) => { clos.current[i] = g; }}
            position={[-4 + (i % 4) * 1.1, 1.3, Math.floor(i / 4) * 1.1 - 0.5]}
          >
            <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
              <capsuleGeometry args={[0.16, 0.8, 6, 10]} />
              <meshStandardMaterial color="#65a30d" roughness={0.5} />
            </mesh>
            <mesh position={[0.62, 0, 0]}>
              <sphereGeometry args={[0.26, 14, 10]} />
              <meshStandardMaterial color="#fde047" emissive="#a16207" emissiveIntensity={0.7} />
            </mesh>
          </group>
        ))}
        {showLabels && <Label text="Clostridium — drumstick + spore" position={[-2.6, 0.15, 0]} size={0.45} color="#bef264" />}

        {/* oxygen bubbles (the enemy) */}
        {Array.from({ length: 8 }).map((_, i) => (
          <mesh key={`o${i}`} ref={(m) => { o2bub.current[i] = m; }}>
            <sphereGeometry args={[0.12, 8, 8]} />
            <meshStandardMaterial color="#e0f2fe" transparent opacity={0.5} />
          </mesh>
        ))}

        {/* stomach with H. pylori */}
        <group position={[3.6, 1.4, 0]}>
          <mesh scale={[1.3, 1, 0.9]} castShadow>
            <sphereGeometry args={[1.1, 20, 14]} />
            <meshStandardMaterial color="#f4a7b9" roughness={0.6} transparent opacity={0.8} />
          </mesh>
          <group ref={hp} position={[0, 0.1, 0.3]}>
            <mesh geometry={hpGeo} castShadow>
              <meshStandardMaterial color="#fb923c" emissive="#c2410c" emissiveIntensity={0.6} />
            </mesh>
          </group>
        </group>
        {showLabels && <Label text="stomach" position={[3.6, 3.1, 0]} size={0.45} color="#f9a8d4" />}
        {showLabels && <Label text="H. pylori — spiral, causes ulcers" position={[3.6, -0.15, 0]} size={0.4} color="#fdba74" />}

        <Animator clos={clos} hp={hp} o2bub={o2bub} elapsed={elapsed} o2={o2} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
