// Hair disorders: alopecia; nail disorders.
// The scalp with its forest of hairs — alopecia's smooth bald patch spreads —
// and a nail in cross-section showing fungus thickening and lifting it.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "alopecia", options: ["alopecia", "nail_fungus", "ingrown"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Hair & Nails: Alopecia to Fungus",
  blurb: "A bald patch spreading on the scalp, or a nail thickened and lifted by fungus — plus the painful ingrown toenail.",
};

function Animator({
  group, patch, hairs, nailLift, elapsed, speed, condition,
}: {
  group: React.RefObject<THREE.Group>;
  patch: React.RefObject<THREE.Mesh>;
  hairs: React.RefObject<THREE.Group>;
  nailLift: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.15;
    // alopecia patch slowly expands; remaining hairs tremble
    if (patch.current && condition === "alopecia") {
      const r = 0.7 + (0.5 + 0.5 * Math.sin(t * 0.5)) * 0.45;
      patch.current.scale.set(r, 1, r * 0.9);
    }
    if (hairs.current) {
      hairs.current.children.forEach((h, i) => {
        const inPatch = Math.hypot(h.position.x - 0.4, h.position.z - 0.2) < 0.85;
        h.visible = !(condition === "alopecia" && inPatch);
        h.rotation.x = Math.sin(t * 1.8 + i * 1.4) * 0.08;
      });
    }
    // fungal nail thickens and lifts
    if (nailLift.current && condition === "nail_fungus") {
      nailLift.current.rotation.x = -0.25 - 0.1 * Math.sin(t * 1.5);
      (nailLift.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.25 + 0.2 * Math.sin(t * 3);
    }
  });
  return null;
}

export function Topic10326Sim(props: SimProps) {
  const condition = String(props.condition ?? "alopecia");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const patch = useRef<THREE.Mesh>(null!);
  const hairs = useRef<THREE.Group>(null!);
  const nailLift = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    alopecia: "Alopecia areata", nail_fungus: "Nail fungus (onychomycosis)", ingrown: "Ingrown toenail",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {condition === "alopecia" && (
            <>
              {/* scalp dome */}
              <mesh position={[0, 1.6, 0]} scale={[1.7, 1.0, 1.5]} castShadow>
                <sphereGeometry args={[1.6, 32, 20, 0, Math.PI * 2, 0, Math.PI / 2]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              {/* hair forest */}
              <group ref={hairs}>
                {Array.from({ length: 60 }).map((_, i) => {
                  const a = (i / 60) * Math.PI * 2;
                  const r = 0.5 + ((i * 37) % 100) / 100 * 1.9;
                  return (
                    <mesh key={i} position={[Math.cos(a) * r, 3.15 + ((i * 53) % 30) / 100, Math.sin(a) * r * 0.9]}
                      rotation={[(Math.sin(i) * 0.3), 0, Math.cos(i * 1.3) * 0.3]} castShadow>
                      <cylinderGeometry args={[0.025, 0.02, 0.7, 6]} />
                      <meshStandardMaterial color="#451a03" roughness={0.7} />
                    </mesh>
                  );
                })}
              </group>
              {/* smooth bald patch */}
              <mesh ref={patch} position={[0.4, 3.05, 0.2]} scale={[0.85, 0.35, 0.75]} castShadow>
                <sphereGeometry args={[0.85, 20, 14]} />
                <meshStandardMaterial color="#f8c8a0" roughness={0.4} emissive="#b45309" emissiveIntensity={0.2} />
              </mesh>
              <Label text="⚠ Smooth bald patch" position={[0.4, 3.9, 0.2]} size={0.55} color="#fca5a5" />
              <Label text="Immune system attacks hair roots" position={[-2.8, 2.4, 0]} size={0.5} color="#fde68a" />
            </>
          )}

          {(condition === "nail_fungus" || condition === "ingrown") && (
            <group position={[0, 1.6, 0]}>
              {/* toe */}
              <mesh position={[0, 0, -0.3]} scale={[1, 0.85, 1.6]} castShadow>
                <sphereGeometry args={[0.85, 24, 18]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
              {/* nail plate */}
              <mesh ref={nailLift} position={[0, 0.62, 0.25]} rotation={[-0.25, 0, 0]} castShadow>
                <boxGeometry args={[1.0, 0.12, 1.3]} />
                <meshStandardMaterial
                  color={condition === "nail_fungus" ? "#d6a05c" : "#fde8d0"}
                  roughness={condition === "nail_fungus" ? 0.95 : 0.4}
                  emissive={condition === "nail_fungus" ? "#78350f" : "#000000"}
                  emissiveIntensity={0.3}
                />
              </mesh>
              {/* fungus debris under the nail */}
              {condition === "nail_fungus" && (
                <>
                  {[-0.25, 0.1, 0.35].map((x, i) => (
                    <mesh key={i} position={[x, 0.45, 0.3]} castShadow>
                      <sphereGeometry args={[0.12, 8, 6]} />
                      <meshStandardMaterial color="#a3e635" emissive="#3f6212" emissiveIntensity={0.8} />
                    </mesh>
                  ))}
                  <Label text="🍄 Fungus thickens & yellows nail" position={[0, 1.6, 0.3]} size={0.55} color="#bef264" />
                </>
              )}
              {/* ingrown: nail edge digging into red skin fold */}
              {condition === "ingrown" && (
                <>
                  <mesh position={[0.55, 0.55, 0.3]} scale={[0.6, 0.5, 0.9]} castShadow>
                    <sphereGeometry args={[0.4, 14, 10]} />
                    <meshStandardMaterial color="#dc2626" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.6} />
                  </mesh>
                  <Label text="⚠ Nail digging into skin — ouch!" position={[0, 1.6, 0.3]} size={0.6} color="#fca5a5" />
                </>
              )}
              <Label text="Toenail" position={[-1.7, 0.9, 0.3]} size={0.5} color="#fde8d0" />
            </group>
          )}
        </group>
        <Animator group={group} patch={patch} hairs={hairs} nailLift={nailLift} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
