"use client";
// Dentition: Deciduous to Permanent — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "age", label: "Age", kind: "slider", min: 5, max: 13, step: 0.5, default: 8, unit: " yrs" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Dentition: Deciduous to Permanent",
  blurb: "Slide from age 5 to 13 — small spaced baby teeth are replaced by bigger permanent teeth erupting in.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const grow = Math.min(1, Math.max(0, (p.age - 6) / 6));
    for (let i = 0; i < 5; i++) {
      const th: any = g("dth" + i);
      if (th) {
        const s = 0.85 + grow * 0.5;
        th.scale.setScalar(s);
        th.position.x = -2.4 + i * 1.2 + (i - 2) * grow * 0.25;
      }
    }
    const er: any = g("erupt");
    if (er) {
      const k = Math.min(1, Math.max(0, (p.age - 6) / 4));
      er.position.y = 3.4 - k * 1.9;
      er.visible = p.age > 6 && p.age < 12.5;
    }
    group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
  });
  return null;
}

export function Topic10460Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const age = Number(props.age ?? 8);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, age };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Age", `${age} years`],
          ["Dentition", age < 6 ? "Deciduous only" : age < 12 ? "Mixed dentition" : "Permanent"],
          ["Teeth", age < 6 ? "20 baby teeth" : age < 12 ? "Mixed set" : "28 + wisdom later"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <GumSlab position={[0, 0.3, 0]} scale={1.3} />
          {[0, 1, 2, 3, 4].map((i) => (
            <Tooth key={i} name={"dth" + i} position={[-2.4 + i * 1.2, 1.1, 0]} scale={0.85} />
          ))}
          <group name="erupt" position={[3.4, 3.4, 0]}>
            <Tooth scale={1.0} enamel="#fbf7ec" />
          </group>
          <Arrow from={[3.4, 4.6, 0]} to={[3.4, 3.6, 0]} color="#22c55e" />
          <Label text="Baby teeth (small, spaced)" position={[-1.2, 3.2, 0]} size={0.42} />
          <Label text="Permanent tooth erupting" position={[3.4, 5.1, 0]} size={0.42} color="#22c55e" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
