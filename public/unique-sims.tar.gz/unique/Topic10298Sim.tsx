// Spinal injuries: cervical, thoracolumbar, disc prolapse, sciatica.
// The vertebral column with its cushions. A disc bulges out and pinches the
// nerve — pain shoots down the leg as sciatica.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "level", label: "Injury level", kind: "select", min: 0, max: 0, step: 1, default: "disc", options: ["cervical", "thoracic", "lumbar", "disc"] },
  { key: "severity", label: "Severity", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.7, unit: "" },
];

export const UNIQUE_META = {
  title: "Spine: Disc Prolapse & Sciatica",
  blurb: "Vertebrae stacked with cushions — a slipped disc bulges out, pinches the nerve, and pain fires down the leg.",
};

function Animator({
  group, bulge, pain, nerve, elapsed, severity, level,
}: {
  group: React.RefObject<THREE.Group>;
  bulge: React.RefObject<THREE.Mesh>;
  pain: React.RefObject<THREE.Group>;
  nerve: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  severity: number;
  level: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // disc bulge grows with severity, throbs
    if (bulge.current) {
      bulge.current.visible = level === "disc";
      const s = severity * (1 + 0.12 * Math.sin(t * 3));
      bulge.current.scale.set(0.6 + s, 0.5 + s * 0.6, 0.6 + s);
    }
    // sciatica: pain bolts race down the leg
    if (pain.current) {
      pain.current.visible = level === "disc";
      pain.current.children.forEach((b, i) => {
        const ph = ((t * 1.2 + i / pain.current!.children.length) % 1);
        b.position.y = 1.6 - ph * 1.6;
        (b as THREE.Mesh).scale.setScalar(0.7 + ph * 0.6);
      });
    }
    // injured level vertebra flashes
    if (nerve.current) {
      const idx = { cervical: 8, thoracic: 5, lumbar: 2, disc: 2 }[level] ?? 2;
      nerve.current.position.y = 0.55 + idx * 0.52;
      (nerve.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.5 + 0.5 * Math.sin(t * 5);
    }
  });
  return null;
}

export function Topic10298Sim(props: SimProps) {
  const level = String(props.level ?? "disc");
  const severity = Number(props.severity ?? 0.7);
  const group = useRef<THREE.Group>(null!);
  const bulge = useRef<THREE.Mesh>(null!);
  const pain = useRef<THREE.Group>(null!);
  const nerve = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    cervical: "Cervical injury (neck)", thoracic: "Thoracic injury", lumbar: "Lumbar injury", disc: "Disc prolapse + sciatica",
  };
  const N = 10;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Level", names[level] ?? level], ["Severity", `${Math.round(severity * 100)}%`]]} />
      <SimCanvas cameraPosition={[2.5, 2.6, 9.5]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* vertebrae + discs stacked */}
          {Array.from({ length: N }).map((_, i) => (
            <group key={i} position={[0, 0.55 + i * 0.52, 0]}>
              <mesh castShadow>
                <cylinderGeometry args={[0.42, 0.42, 0.3, 18]} />
                <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
              </mesh>
              {/* spinous process pointing back */}
              <mesh position={[0, 0, -0.5]} rotation={[Math.PI / 2, 0, 0]} castShadow>
                <cylinderGeometry args={[0.09, 0.12, 0.6, 8]} />
                <meshStandardMaterial color="#cbd5e1" roughness={0.5} />
              </mesh>
              {i < N - 1 && (
                <mesh position={[0, 0.26, 0]} castShadow>
                  <cylinderGeometry args={[0.34, 0.34, 0.22, 18]} />
                  <meshStandardMaterial color="#7dd3fc" roughness={0.45} />
                </mesh>
              )}
            </group>
          ))}
          {/* spinal cord */}
          <mesh position={[0, 2.9, 0.28]} castShadow>
            <cylinderGeometry args={[0.11, 0.11, 5.4, 10]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.5} />
          </mesh>
          {/* prolapsed disc bulge pressing the nerve */}
          <mesh ref={bulge} position={[0.45, 1.85, 0.1]} visible={false} castShadow>
            <sphereGeometry args={[0.35, 16, 12]} />
            <meshStandardMaterial color="#ef4444" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.5} />
          </mesh>
          {/* pinched nerve root */}
          <mesh position={[0.55, 1.85, 0.28]} rotation={[0, 0, 1.1]} castShadow>
            <cylinderGeometry args={[0.07, 0.07, 0.9, 8]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.5} emissive="#b45309" emissiveIntensity={0.6} />
          </mesh>
          {/* sciatica pain shooting down the leg */}
          <group ref={pain} visible={false}>
            {Array.from({ length: 7 }).map((_, i) => (
              <mesh key={i} position={[0.85, 1.6, 0.3]} rotation={[0, 0, 0.4]}>
                <coneGeometry args={[0.12, 0.42, 4]} />
                <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1.4} />
              </mesh>
            ))}
          </group>
          {/* injury level highlighter */}
          <mesh ref={nerve} position={[0, 3.5, 0]}>
            <torusGeometry args={[0.55, 0.07, 8, 24]} />
            <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={1} />
          </mesh>
          {/* skull on top for orientation */}
          <mesh position={[0, 6.15, 0]} castShadow>
            <sphereGeometry args={[0.55, 20, 14]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <Label text="Skull" position={[1.4, 6.15, 0]} size={0.5} color="#f8fafc" />
          <Label text="Vertebra" position={[-1.5, 3.4, 0]} size={0.5} color="#e2e8f0" />
          <Label text="Disc (cushion)" position={[-1.5, 2.6, 0]} size={0.5} color="#7dd3fc" />
          <Label text="Spinal cord" position={[1.3, 4.6, 0.28]} size={0.5} color="#fde68a" />
          {level === "disc" && <Label text="⚠ Slipped disc pinches nerve" position={[1.9, 1.85, 0.1]} size={0.55} color="#fca5a5" />}
          {level === "disc" && <Label text="⚡ Sciatica down the leg" position={[1.9, 0.6, 0.3]} size={0.55} color="#fde68a" />}
          {level === "cervical" && <Label text="⚠ Neck injury — arms/legs at risk" position={[0, 0.2, 0]} size={0.55} color="#fca5a5" />}
        </group>
        <Animator group={group} bulge={bulge} pain={pain} nerve={nerve} elapsed={elapsed} severity={severity} level={level} />
      </SimCanvas>
    </div>
  );
}
