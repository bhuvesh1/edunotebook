"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "klass", label: "Kennedy class", kind: "select", min: 0, max: 0, step: 1, default: "I", options: ["I", "II", "III", "IV"] },
  { key: "mod", label: "Applegate modification", kind: "select", min: 0, max: 0, step: 1, default: "none", options: ["none", "mod1", "mod2"] },
];

export const UNIQUE_META = {
  title: "Removable partial dentures: classification — Kennedy, Applegate",
  blurb: "A dental arch with missing-tooth gaps glowing red — switch Kennedy classes to see each edentulous pattern and its denture design.",
};

const CLASSES: Record<string, { name: string; gaps: number[]; note: string; support: string }> = {
  I: { name: "Class I", gaps: [0, 1, 6, 7], note: "Bilateral free-end — no back teeth", support: "Tooth + tissue supported" },
  II: { name: "Class II", gaps: [0, 1], note: "One-sided free-end", support: "Tooth + tissue supported" },
  III: { name: "Class III", gaps: [3, 4], note: "Gap with teeth on both sides", support: "Fully tooth supported" },
  IV: { name: "Class IV", gaps: [3, 4], note: "Front gap crossing the midline", support: "Fully tooth supported" },
};

function Scene({ klass, mod }: { klass: string; mod: string }) {
  const group = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const c = CLASSES[klass] ?? CLASSES.I;
  const n = 8;
  const extraGaps = mod === "mod1" ? [2] : mod === "mod2" ? [2, 5] : [];
  const gaps = [...c.gaps, ...extraGaps];

  useFrame((_, delta) => {
    t.current += delta;
    if (group.current) group.current.rotation.y = Math.sin(t.current * 0.3) * 0.5;
  });

  const teeth: { x: number; z: number; a: number }[] = [];
  for (let i = 0; i < n; i++) {
    const a = Math.PI * (0.06 + (0.88 * i) / (n - 1));
    teeth.push({ x: Math.cos(a) * 2.6, z: Math.sin(a) * 2.6, a });
  }

  return (
    <group ref={group}>
      {/* jaw */}
      <mesh position={[0, -0.55, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[2.6, 0.7, 14, 40, Math.PI]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>
      {/* partial denture base hint over gaps */}
      {gaps.map((gi) => {
        const tt = teeth[gi];
        return (
          <mesh key={gi} position={[tt.x, 0.25, tt.z]} rotation={[0, -tt.a + Math.PI / 2, 0]}>
            <boxGeometry args={[0.7, 0.25, 0.9]} />
            <meshStandardMaterial color="#f472b6" transparent opacity={0.65} roughness={0.5} />
          </mesh>
        );
      })}

      {teeth.map((tt, i) => {
        const isGap = gaps.includes(i);
        return (
          <group key={i} position={[tt.x, 0.4, tt.z]} rotation={[0, -tt.a + Math.PI / 2, 0]}>
            {isGap ? (
              <mesh>
                <boxGeometry args={[0.55, 0.18, 0.7]} />
                <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.7} />
              </mesh>
            ) : (
              <mesh>
                <cylinderGeometry args={[0.26, 0.32, 0.65, 10]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.3} />
              </mesh>
            )}
          </group>
        );
      })}

      {/* midline */}
      <mesh position={[0, 0.1, 2.85]}>
        <boxGeometry args={[0.06, 0.5, 0.6]} />
        <meshStandardMaterial color="#38bdf8" emissive="#38bdf8" emissiveIntensity={0.5} />
      </mesh>
      <Label text="Midline" position={[0, 0.85, 2.85]} size={0.36} color="#7dd3fc" />

      <Label text={`Kennedy ${c.name}`} position={[0, 3.0, 0]} size={0.7} color="#fca5a5" />
      <Label text={c.note} position={[0, -2.0, 0]} size={0.45} color="#e2e8f0" />
      <Label text={`${c.support}${mod !== "none" ? ` · Applegate ${mod === "mod1" ? "mod 1" : "mod 2"}` : ""}`} position={[0, -2.7, 0]} size={0.42} color="#94a3b8" />
    </group>
  );
}

export function Topic10432Sim(props: SimProps) {
  const klass = String(props.klass ?? "I");
  const mod = String(props.mod ?? "none");
  const c = CLASSES[klass] ?? CLASSES.I;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Kennedy", c.name], ["Pattern", c.note], ["Design", c.support]]} />
      <SimCanvas cameraPosition={[0, 4, 9]} target={[0, 0, 0]}>
        <Scene klass={klass} mod={mod} />
      </SimCanvas>
    </div>
  );
}
