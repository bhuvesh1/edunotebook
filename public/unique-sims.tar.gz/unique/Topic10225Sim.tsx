// GERD, peptic ulcer & GI bleeding — a stomach sac with acid splashing up
// the esophagus (reflux slider); an ulcer crater glows in the stomach wall
// and drips blood when severe.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "acid", label: "Acid reflux", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "ulcer", label: "Ulcer", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "GERD & Peptic Ulcer",
  blurb: "Acid splashes up the food pipe (heartburn); an ulcer crater in the stomach wall bleeds when it gets bad.",
};

function Animator({ splash, bleed, elapsed, acid }: {
  splash: React.RefObject<THREE.Group>;
  bleed: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  acid: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (splash.current) {
      splash.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * 1.1 + i * 0.17) % 1);
        // droplets rise up the esophagus with each reflux wave
        m.position.y = 2.6 + ph * (2.2 + (acid / 100) * 1.6);
        m.visible = ph < 0.25 + (acid / 100) * 0.7;
      });
    }
    if (bleed.current) {
      bleed.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * 0.8 + i * 0.3) % 1);
        m.position.y = 1.75 - ph * 1.4;
        m.visible = acid > 65;
      });
    }
  });
  return null;
}

export function Topic10225Sim(props: SimProps) {
  const acid = Number(props.acid ?? 60);
  const ulcerOn = String(props.ulcer ?? "on") === "on";
  const splash = useRef<THREE.Group>(null!);
  const bleed = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const bleeding = ulcerOn && acid > 65;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Reflux", `${acid}%`], ["Symptom", acid > 60 ? "heartburn ⚠" : "mild"], ["Ulcer", ulcerOn ? (bleeding ? "BLEEDING ⚠" : "present") : "none"]]} />
      <SimCanvas cameraPosition={[0, 3.4, 12]} target={[0, 2.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* esophagus */}
        <mesh position={[0, 4.6, 0]} castShadow>
          <cylinderGeometry args={[0.5, 0.55, 3.4, 16, 1, true]} />
          <meshStandardMaterial color={acid > 60 ? "#f87171" : "#f9a8d4"} roughness={0.55} side={THREE.DoubleSide} />
        </mesh>
        <Label text="Esophagus — acid burns here = heartburn" position={[2.4, 4.6, 0]} size={0.46} color={acid > 60 ? "#fca5a5" : "#e2e8f0"} />
        {/* stomach: J-shaped sac */}
        <group position={[0, 1.9, 0]}>
          <mesh scale={[1.6, 1.25, 1.1]} castShadow>
            <sphereGeometry args={[1.25, 28, 22]} />
            <meshStandardMaterial color="#fb923c" roughness={0.55} />
          </mesh>
          {/* acid pool sloshing at the bottom */}
          <mesh position={[0, -0.7, 0]} scale={[1.3, 0.5, 0.9]}>
            <sphereGeometry args={[1.0, 20, 14]} />
            <meshStandardMaterial color="#facc15" roughness={0.25} emissive="#a16207" emissiveIntensity={0.5} />
          </mesh>
          {/* ulcer crater */}
          {ulcerOn && (
            <group>
              <mesh position={[0.9, 0.35, 0.85]} scale={[1, 0.7, 0.5]}>
                <sphereGeometry args={[0.45, 16, 12]} />
                <meshStandardMaterial color="#7f1d1d" roughness={0.7} emissive="#dc2626" emissiveIntensity={0.4} />
              </mesh>
              <mesh position={[0.95, 0.55, 0.95]} scale={[0.7, 0.4, 0.35]}>
                <sphereGeometry args={[0.45, 14, 10]} />
                <meshStandardMaterial color="#450a0a" roughness={0.9} />
              </mesh>
              <Label text={bleeding ? "Ulcer BLEEDING ⚠" : "Peptic ulcer"} position={[2.6, 0.9, 0.8]} size={0.5} color={bleeding ? "#fca5a5" : "#fdba74"} />
            </group>
          )}
        </group>
        {/* duodenum exit */}
        <mesh position={[1.9, 0.9, 0]} rotation={[0, 0, Math.PI / 2.3]}>
          <cylinderGeometry args={[0.42, 0.42, 2.2, 14, 1, true]} />
          <meshStandardMaterial color="#fda4af" roughness={0.55} side={THREE.DoubleSide} />
        </mesh>

        {/* reflux splash droplets */}
        <group ref={splash}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i} position={[(i % 3 - 1) * 0.2, 2.6, (i % 2) * 0.2]}>
              <sphereGeometry args={[0.13, 10, 10]} />
              <meshBasicMaterial color="#facc15" transparent opacity={0.85} />
            </mesh>
          ))}
        </group>
        {/* blood drips from ulcer */}
        <group ref={bleed}>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[0.9, 1.75, 0.85]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshBasicMaterial color="#dc2626" />
            </mesh>
          ))}
        </group>

        <Label text="H. pylori + NSAIDs cause most ulcers" position={[0, -1.2, 0]} size={0.44} color="#94a3b8" />
        <Animator splash={splash} bleed={bleed} elapsed={elapsed} acid={acid} />
      </SimCanvas>
    </div>
  );
}
