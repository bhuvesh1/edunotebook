"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "prep", label: "Preparation type", kind: "select", min: 0, max: 0, step: 1, default: "crown", options: ["crown", "veneer", "onlay"] },
  { key: "taper", label: "Taper", kind: "slider", min: 2, max: 12, step: 1, default: 6, unit: "°" },
];

export const UNIQUE_META = {
  title: "Fixed partial dentures: tooth preparation principles, impressions",
  blurb: "A spinning bur sculpts a tooth into a tapered stump — crown, veneer or onlay prep — with water spray cooling the cut.",
};

const PREPS: Record<string, { name: string; cut: number; note: string; color: string }> = {
  crown: { name: "Full crown prep", cut: 1.0, note: "1.5–2 mm all around, chamfer margin", color: "#fbbf24" },
  veneer: { name: "Veneer prep", cut: 0.35, note: "Only 0.5 mm off the front — enamel saved", color: "#7dd3fc" },
  onlay: { name: "Onlay prep", cut: 0.7, note: "Covers the chewing cusps, keeps walls", color: "#a78bfa" },
};

function Spray() {
  const pts = useRef<THREE.Points>(null!);
  const t = useRef(0);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(24 * 3), 3));
    return g;
  }, []);
  useFrame((_, delta) => {
    t.current += delta * 2;
    if (!pts.current) return;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < 24; i++) {
      const f = (t.current * 0.8 + i / 24) % 1;
      pos.setXYZ(i, 1.7 - f * 1.6, 2.6 - f * 2.2, 0.4 + Math.sin(i * 2.3) * f * 0.5);
    }
    pos.needsUpdate = true;
  });
  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial color="#bae6fd" size={0.09} transparent opacity={0.8} />
    </points>
  );
}

function Scene({ prep, taper }: { prep: string; taper: number }) {
  const bur = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const p = PREPS[prep] ?? PREPS.crown;
  const taperRad = (taper * Math.PI) / 180;

  useFrame((_, delta) => {
    t.current += delta;
    if (bur.current) {
      bur.current.position.x = 1.7 + Math.sin(t.current * 1.8) * 0.55;
      bur.current.position.y = 2.4 + Math.cos(t.current * 2.6) * 0.45;
      bur.current.rotation.y = t.current * 30;
    }
  });

  return (
    <group>
      {/* original tooth outline (ghost) */}
      <mesh position={[0, 0.5, 0]}>
        <cylinderGeometry args={[0.62, 0.72, 1.3, 14]} />
        <meshStandardMaterial color="#f8fafc" transparent opacity={0.18} roughness={0.3} />
      </mesh>
      {/* prepared stump — tapered */}
      <mesh position={[0, 0.5, 0]}>
        <cylinderGeometry args={[0.62 - p.cut * 0.35 - Math.tan(taperRad) * 0.6, 0.72 - p.cut * 0.2, 1.3 - p.cut * 0.35, 14]} />
        <meshStandardMaterial color="#efe3c8" roughness={0.55} />
      </mesh>
      {/* chamfer margin line */}
      <mesh position={[0, -0.12, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.62 - p.cut * 0.28, 0.045, 8, 20]} />
        <meshStandardMaterial color={p.color} emissive={p.color} emissiveIntensity={0.8} />
      </mesh>
      <Label text="Chamfer margin" position={[1.6, -0.12, 0]} size={0.4} color={p.color} />
      {/* root */}
      <mesh position={[0, -0.9, 0]}>
        <coneGeometry args={[0.5, 1.3, 14]} />
        <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
      </mesh>

      {/* dental bur */}
      <group ref={bur} position={[1.7, 2.4, 0.4]}>
        <mesh position={[0, 0.5, 0]}>
          <cylinderGeometry args={[0.09, 0.09, 1.1, 10]} />
          <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
        </mesh>
        <mesh position={[0, -0.25, 0]}>
          <cylinderGeometry args={[0.14, 0.1, 0.5, 10]} />
          <meshStandardMaterial color="#fde047" metalness={0.5} roughness={0.4} />
        </mesh>
        <mesh position={[0, -0.52, 0]}>
          <sphereGeometry args={[0.1, 8, 8]} />
          <meshStandardMaterial color="#fde047" emissive="#eab308" emissiveIntensity={0.9} />
        </mesh>
      </group>
      <Spray />
      <Label text="Diamond bur + water spray" position={[1.7, 3.3, 0.4]} size={0.4} color="#bae6fd" />

      <Label text={p.name} position={[0, 3.9, 0]} size={0.6} color={p.color} />
      <Label text={`${p.note} · taper ${taper}°`} position={[0, -2.3, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10436Sim(props: SimProps) {
  const prep = String(props.prep ?? "crown");
  const taper = Number(props.taper ?? 6);
  const p = PREPS[prep] ?? PREPS.crown;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Preparation", p.name], ["Taper", `${taper}°`], ["Margin", "Chamfer"]]} />
      <SimCanvas cameraPosition={[0, 2, 9]} target={[0, 0.4, 0]}>
        <Scene prep={prep} taper={taper} />
      </SimCanvas>
    </div>
  );
}
