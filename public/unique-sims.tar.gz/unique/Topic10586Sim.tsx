// Topic10586 — Dental records and legal aspects.
// The FDI chart comes alive: a probe hops tooth to tooth across all 32
// positions, calling out each number and its legal condition — sound,
// filling, caries, crown or missing.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Charting speed", kind: "slider", min: 1, max: 8, step: 1, default: 3, unit: "teeth/s" },
];

export const UNIQUE_META = {
  title: "Dental records and legal aspects",
  blurb: "Chart a full FDI dental record tooth by tooth — the legal document every dentist must keep.",
};

type Cond = "sound" | "filling" | "caries" | "crown" | "missing";
const COND_COLOR: Record<Cond, string> = {
  sound: "#16a34a",
  filling: "#f59e0b",
  caries: "#dc2626",
  crown: "#eab308",
  missing: "#1e293b",
};
const COND_LABEL: Record<Cond, string> = {
  sound: "sound",
  filling: "amalgam filling",
  caries: "CARIES — needs treatment",
  crown: "porcelain crown",
  missing: "MISSING — extracted 2021",
};

// 32 FDI numbers in chart order: upper right->left, then lower left->right
const FDI_ORDER: string[] = [
  "18","17","16","15","14","13","12","11","21","22","23","24","25","26","27","28",
  "38","37","36","35","34","33","32","31","41","42","43","44","45","46","47","48",
];
const CONDITIONS: Record<string, Cond> = {
  "16": "filling", "26": "caries", "36": "caries", "11": "crown",
  "46": "missing", "24": "filling", "37": "filling",
};
const condOf = (f: string): Cond => CONDITIONS[f] ?? "sound";

function Animator({
  teeth,
  probe,
  elapsed,
  speed,
}: {
  teeth: RefObject<THREE.Group>;
  probe: RefObject<THREE.Group>;
  elapsed: RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const idx = Math.floor(elapsed.current) % FDI_ORDER.length;
    const per = 16;
    const col = idx % per;
    const row = Math.floor(idx / per);
    const x = -4.65 + col * 0.62;
    const y = row === 0 ? 2.9 : 1.55;
    if (probe.current) {
      probe.current.position.x += (x - probe.current.position.x) * 0.35;
      probe.current.position.y = y + 0.75 + Math.sin(elapsed.current * 10) * 0.08;
    }
    if (teeth.current) {
      teeth.current.children.forEach((mesh, i) => {
        const s = i === idx ? 1.35 : 1;
        mesh.scale.setScalar(mesh.scale.x + (s - mesh.scale.x) * 0.3);
      });
    }
  });
  return null;
}

export function Topic10586Sim(props: SimProps) {
  const speed = Number(props.speed ?? 3);
  const teeth = useRef<THREE.Group>(null!);
  const probe = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const chart = useMemo(
    () =>
      FDI_ORDER.map((f) => ({
        fdi: f,
        cond: condOf(f),
        x: -4.65 + (FDI_ORDER.indexOf(f) % 16) * 0.62,
        y: Math.floor(FDI_ORDER.indexOf(f) / 16) === 0 ? 2.9 : 1.55,
      })),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["System", "FDI numbering"],
          ["Teeth", "32 charted"],
          ["Legal", "Signed + dated record"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 13.5]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* chart board */}
        <mesh position={[0, 2.2, -0.6]} receiveShadow>
          <boxGeometry args={[11.4, 3.6, 0.2]} />
          <meshStandardMaterial color="#0f1e38" roughness={0.7} />
        </mesh>
        <mesh position={[0, 2.2, 0.15]}>
          <boxGeometry args={[11.4, 0.12, 0.12]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.5} />
        </mesh>

        {/* 32 teeth on the chart */}
        <group ref={teeth}>
          {chart.map((t) => (
            <group key={t.fdi} position={[t.x, t.y, 0]}>
              {t.cond === "missing" ? (
                <mesh>
                  <torusGeometry args={[0.2, 0.05, 8, 16]} />
                  <meshStandardMaterial color="#475569" roughness={0.6} />
                </mesh>
              ) : (
                <mesh castShadow>
                  <boxGeometry args={[0.48, 0.62, 0.4]} />
                  <meshStandardMaterial color={COND_COLOR[t.cond]} roughness={0.45} />
                </mesh>
              )}
            </group>
          ))}
        </group>

        {/* explorer probe hopping between teeth */}
        <group ref={probe} position={[-4.65, 3.65, 0]}>
          <mesh position={[0, 0.35, 0]} rotation={[0, 0, 0.5]}>
            <cylinderGeometry args={[0.05, 0.05, 0.9, 8]} />
            <meshStandardMaterial color="#cbd5e1" roughness={0.3} metalness={0.8} />
          </mesh>
          <mesh>
            <sphereGeometry args={[0.12, 12, 12]} />
            <meshStandardMaterial color="#22d3ee" emissive="#0ea5e9" emissiveIntensity={1.6} />
          </mesh>
        </group>

        <Label text="FDI DENTAL CHART — legal record" position={[0, 4.6, 0]} size={0.44} color="#e0f2fe" />
        <Label text="GREEN sound · AMBER filling · RED caries · GOLD crown · RING missing" position={[0, 0.55, 0]} size={0.34} color="#94a3b8" />
        <Label text="Every entry signed, dated & kept 7+ years" position={[0, -0.25, 0]} size={0.34} color="#fcd34d" />

        <Animator teeth={teeth} probe={probe} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
