"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "normal", options: ["normal", "hepatitis", "CKD"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Liver & Kidney Function Tests",
  blurb: "Watch ALT, AST, bilirubin, creatinine and urea bars swing from green to red across disease states.",
};

const TESTS: [string, number, number, number][] = [["ALT",0.15,0.95,0.2],["AST",0.15,0.9,0.2],["Bilirubin",0.15,0.85,0.25],["Creatinine",0.15,0.25,0.95],["Urea",0.15,0.25,0.9]];
const TCOL = ["#4ade80","#4ade80","#4ade80","#4ade80","#4ade80"];

function Animator({ root, fills, elapsed, speed }: { root: RefObject<THREE.Group>; fills: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (fills.current) {
      fills.current.children.forEach((m, i) => {
        const target = parseFloat(m.userData.target as string);
        const cur = m.scale.y;
        const nx = cur + (target - cur) * Math.min(1, delta * 3);
        m.scale.y = Math.max(0.03, nx);
        m.position.y = 0.55 + m.scale.y * 1.35;
      });
    }
    if (root.current) root.current.rotation.y = Math.sin(t * 0.2) * 0.08;
  });
  return null;
}

export function Topic10077Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const cond = String(props.cond ?? "normal");
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const fills = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Panel", "LFT + RFT"],
          ["Condition", cond],
          ["Interpret", cond === "normal" ? "all within range" : cond === "hepatitis" ? "hepatocellular injury" : "renal failure"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 0.25, -1]} castShadow>
            <boxGeometry args={[11, 0.5, 2.4]} /><meshStandardMaterial color="#334155" roughness={0.7} />
          </mesh>
          {TESTS.map(([name, n, h, c], i) => {
            const x = -4 + i * 2;
            const target = cond === "normal" ? n : cond === "hepatitis" ? h : c;
            const bad = target > 0.5;
            return (
              <group key={name}>
                <mesh position={[x, 1.9, 0]}><boxGeometry args={[0.9, 2.9, 0.5]} /><meshStandardMaterial color="#0f172a" roughness={0.6} /></mesh>
                <mesh position={[x, 2.62, 0.28]}>
                  <boxGeometry args={[0.9, 0.08, 0.02]} /><meshStandardMaterial color="#f8fafc" />
                </mesh>
                <Label text={name} position={[x, 3.7, 0]} size={0.4} color={bad ? "#f87171" : "#4ade80"} />
                <Label text={bad ? "HIGH" : "normal"} position={[x, 0.75, 0.6]} size={0.36} color={bad ? "#f87171" : "#4ade80"} />
              </group>
            );
          })}
          <group ref={fills}>
            {TESTS.map(([name, n, h, c], i) => {
              const target = cond === "normal" ? n : cond === "hepatitis" ? h : c;
              const bad = target > 0.5;
              return (
                <mesh key={name} position={[-4 + i * 2, 1.9, 0]} scale={[1, 0.15, 1]} userData={{ target: String(target) }}>
                  <boxGeometry args={[0.7, 2.7, 0.4]} />
                  <meshStandardMaterial color={bad ? "#ef4444" : "#22c55e"} roughness={0.4} />
                </mesh>
              );
            })}
          </group>
          <Label text="LFT: ALT \u00b7 AST \u00b7 bilirubin" position={[-2.6, 4.5, 0]} size={0.42} color="#94a3b8" />
          <Label text="RFT: creatinine \u00b7 urea" position={[3.2, 4.5, 0]} size={0.42} color="#94a3b8" />
        </group>
        <Animator root={root} fills={fills} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
