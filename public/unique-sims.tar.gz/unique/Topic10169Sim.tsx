"use client";
// Biostatistics: data types, sampling, tests of significance.
// A glowing bell curve while sample dots rain into bins — bigger samples
// make the curve smoother and the p-value smaller.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "n", label: "Sample size", kind: "slider", min: 10, max: 200, step: 10, default: 60, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Biostatistics: Sampling & the Bell Curve",
  blurb: "Sample dots rain into the bell curve — grow the sample and watch the result get more certain (smaller p-value).",
};

const N_DOTS = 40;

function Animator({ dots, elapsed, speed, n }: { dots: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number; n: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (dots.current) {
      const active = Math.round((n / 200) * N_DOTS);
      dots.current.children.forEach((d, i) => {
        d.visible = i < active;
        if (!d.visible) return;
        const ph = (elapsed.current * 0.8 + i * 0.23) % 1;
        const x = Math.sin(i * 12.9) * 2.6 * (1 - ph * 0.85);
        d.position.set(x, 5.2 - ph * 4.6, Math.cos(i * 7.7) * 0.6);
      });
    }
  });
  return null;
}

export function Topic10169Sim(props: SimProps) {
  const n = Number(props.n ?? 60);
  const speed = Number(props.speed ?? 1);
  const dots = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = Math.max(0.001, 0.5 * Math.exp(-n / 45));
  const sig = p < 0.05 ? "Significant! (p < 0.05)" : "Not significant yet";

  const curve = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 60; i++) {
      const x = -4 + (i / 60) * 8;
      const y = 0.3 + 3 * Math.exp(-(x * x) / 3.2);
      pts.push(new THREE.Vector3(x, y, 0));
    }
    const geo = new THREE.BufferGeometry().setFromPoints(pts);
    return new THREE.Line(geo, new THREE.LineBasicMaterial({ color: "#38bdf8" }));
  }, []);

  const dotMeshes = useMemo(
    () =>
      Array.from({ length: N_DOTS }, (_, i) => (
        <mesh key={i} position={[0, 5, 0]}>
          <sphereGeometry args={[0.13, 8, 8]} />
          <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={0.8} />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["n", `${n}`], ["p-value", p < 0.01 ? "< 0.01" : p.toFixed(2)], ["Result", sig]]} />
      <SimCanvas cameraPosition={[0, 3.4, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <primitive object={curve} />
        <mesh position={[0, 0.08, 0]}>
          <boxGeometry args={[9, 0.12, 0.3]} />
          <meshStandardMaterial color="#64748b" roughness={0.7} />
        </mesh>
        <Label text="BELL CURVE (normal distribution)" position={[0, 4.4, 0]} size={0.55} color="#7dd3fc" />
        <group ref={dots}>{dotMeshes}</group>
        {/* p-value gauge */}
        <group position={[6.2, 2.4, 0]}>
          <mesh castShadow>
            <boxGeometry args={[1.6, 3, 0.4]} />
            <meshStandardMaterial color="#1e293b" roughness={0.8} />
          </mesh>
          <mesh position={[0, -1.5 + Math.min(1, (0.5 - p) / 0.5) * 3, 0.22]}>
            <boxGeometry args={[1.1, 0.25, 0.06]} />
            <meshStandardMaterial color={p < 0.05 ? "#22c55e" : "#ef4444"} emissive={p < 0.05 ? "#22c55e" : "#ef4444"} emissiveIntensity={0.8} />
          </mesh>
          <Label text="p-VALUE" position={[0, 2, 0]} size={0.55} color="#fbbf24" />
        </group>
        <Animator dots={dots} elapsed={elapsed} speed={speed} n={n} />
      </SimCanvas>
    </div>
  );
}
