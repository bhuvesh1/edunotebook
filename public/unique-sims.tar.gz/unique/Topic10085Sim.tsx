"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "itype", label: "Type", kind: "select", min: 0, max: 0, step: 1, default: "acute", options: ["acute", "chronic"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Inflammation: Acute vs Chronic",
  blurb: "Neutrophils roll, stick and squeeze through the vessel wall in acute inflammation; macrophages take over in chronic.",
};

function Animator({ root, wbc, glow, macro, gran, elapsed, speed, acute }: { root: RefObject<THREE.Group>; wbc: RefObject<THREE.Group>; glow: RefObject<THREE.Mesh>; macro: RefObject<THREE.Group>; gran: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; acute: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (wbc.current) {
      wbc.current.visible = acute;
      wbc.current.children.forEach((m, i) => {
        const p = (t * 0.3 + i / 6) % 1;
        const x = -5 + p * 10;
        const gap = Math.abs(((x + 5) % 3.4) - 1.7) < 0.45;
        const dive = p > 0.35 && p < 0.6 && gap ? (p - 0.35) / 0.25 : 0;
        m.position.set(x, 2.9 - Math.min(1, dive) * 1.9, 0.6);
        m.rotation.x += delta * 4;
      });
    }
    if (glow.current) {
      glow.current.visible = acute;
      (glow.current.material as THREE.MeshStandardMaterial).opacity = 0.22 + 0.14 * Math.sin(t * 4);
    }
    if (macro.current) {
      macro.current.visible = !acute;
      macro.current.children.forEach((m, i) => {
        m.position.x = 1.5 + Math.sin(t * 0.8 + i * 2.4) * 0.5;
        m.position.y = 1.6 + Math.cos(t * 0.7 + i) * 0.3;
      });
    }
    if (gran.current) {
      gran.current.visible = !acute;
      const s = Math.min(1, (t * 0.25) % 1.4);
      gran.current.scale.setScalar(Math.max(0.05, s));
      gran.current.rotation.z = t * 0.5;
    }
  });
  return null;
}

export function Topic10085Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const itype = String(props.itype ?? "acute");
  const acute = itype === "acute";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const wbc = useRef<THREE.Group>(null!);
  const glow = useRef<THREE.Mesh>(null!);
  const macro = useRef<THREE.Group>(null!);
  const gran = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Type", itype],
          ["Key cell", acute ? "neutrophil" : "macrophage"],
          ["Cardinal sign", acute ? "rubor \u00b7 calor \u00b7 tumor \u00b7 dolor" : "granuloma formation"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 1.9, -0.9]}>
            <boxGeometry args={[11, 1.4, 0.5]} /><meshStandardMaterial color="#f9a8d4" roughness={0.6} />
          </mesh>
          {[-3.4, 0, 3.4].map((x) => (
            <mesh key={x} position={[x, 1.9, -0.6]}>
              <boxGeometry args={[0.9, 1.5, 0.7]} /><meshStandardMaterial color="#0f172a" roughness={1} />
            </mesh>
          ))}
          <Label text="endothelium" position={[-5.2, 2.9, -0.9]} size={0.42} color="#f9a8d4" />
          <mesh ref={glow} position={[0, 1.9, -0.4]}>
            <boxGeometry args={[11, 1.6, 0.2]} />
            <meshStandardMaterial color="#ef4444" transparent opacity={0.25} emissive="#ef4444" emissiveIntensity={0.7} />
          </mesh>
          <group ref={wbc}>
            {Array.from({ length: 6 }).map((_, i) => (
              <mesh key={i} castShadow>
                <sphereGeometry args={[0.34, 16, 16]} /><meshStandardMaterial color="#f8fafc" roughness={0.4} />
              </mesh>
            ))}
          </group>
          <Label text="neutrophils \u2014 diapedesis" position={[3.4, 4.2, 0]} size={0.42} color="#f8fafc" />
          <group ref={macro} visible={false}>
            {[0, 1].map((i) => (
              <mesh key={i} position={[1.5, 1.6, 0.6]} castShadow>
                <sphereGeometry args={[0.55, 18, 18]} /><meshStandardMaterial color="#d6a05b" roughness={0.5} />
              </mesh>
            ))}
          </group>
          <mesh ref={gran} visible={false} position={[1.5, 1.6, 0.6]}>
            <torusGeometry args={[1.1, 0.16, 12, 28]} />
            <meshStandardMaterial color="#facc15" emissive="#eab308" emissiveIntensity={0.6} />
          </mesh>
          <Label text={acute ? "acute: redness \u00b7 heat \u00b7 swelling" : "chronic: macrophages \u00b7 granuloma"} position={[0, 5, 0]} size={0.48} color={acute ? "#f87171" : "#facc15"} />
        </group>
        <Animator root={root} wbc={wbc} glow={glow} macro={macro} gran={gran} elapsed={elapsed} speed={speed} acute={acute} />
      </SimCanvas>
    </div>
  );
}
