"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "view", label: "Focus", kind: "select", min: 0, max: 0, step: 1, default: "occlusion", options: ["occlusion", "tmj"] },
  { key: "disc", label: "Disc position", kind: "select", min: 0, max: 0, step: 1, default: "normal", options: ["normal", "displaced"] },
];

export const UNIQUE_META = {
  title: "Full-mouth rehabilitation basics, occlusion and TMD basics",
  blurb: "A fully crowned mouth opening and closing — then zoom to the jaw joint to see the disc slip and click in TMD.",
};

function Scene({ view, disc }: { view: string; disc: string }) {
  const jaw = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const displaced = disc === "displaced";

  useFrame((_, delta) => {
    t.current += delta;
    if (jaw.current) {
      const f = (Math.sin(t.current * 1.3) + 1) / 2;
      jaw.current.rotation.x = f * 0.45;
      jaw.current.position.y = -f * 0.5;
    }
  });

  const teeth: { x: number; z: number }[] = [];
  const n = 7;
  for (let i = 0; i < n; i++) {
    const a = Math.PI * (0.12 + (0.76 * i) / (n - 1));
    teeth.push({ x: Math.cos(a) * 1.9, z: Math.sin(a) * 1.9 });
  }

  return (
    <group>
      {view === "occlusion" && (
        <>
          {/* upper full arch of crowns */}
          <group position={[0, 0.9, 0]}>
            {teeth.map((tt, i) => (
              <mesh key={i} position={[tt.x, 0, tt.z]}>
                <cylinderGeometry args={[0.3, 0.34, 0.55, 4]} />
                <meshStandardMaterial color="#fdf6e3" metalness={0.15} roughness={0.3} flatShading />
              </mesh>
            ))}
            <mesh rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[1.9, 0.3, 10, 28, Math.PI]} />
              <meshStandardMaterial color="#e0788a" roughness={0.6} />
            </mesh>
          </group>
          {/* lower jaw moves */}
          <group ref={jaw} position={[0, -0.9, 0]}>
            {teeth.map((tt, i) => (
              <mesh key={i} position={[tt.x, 0.5, tt.z]}>
                <cylinderGeometry args={[0.3, 0.34, 0.55, 4]} />
                <meshStandardMaterial color="#fdf6e3" metalness={0.15} roughness={0.3} flatShading />
              </mesh>
            ))}
            <mesh position={[0, 0.1, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[1.9, 0.3, 10, 28, Math.PI]} />
              <meshStandardMaterial color="#e0788a" roughness={0.6} />
            </mesh>
          </group>
          <Label text="Every tooth crowned — new bite rebuilt" position={[0, 2.6, 0]} size={0.5} color="#fde68a" />
          <Label text="Canine-guided / group function occlusion" position={[0, -2.8, 0]} size={0.42} color="#e2e8f0" />
        </>
      )}

      {view === "tmj" && (
        <group>
          {/* skull base / fossa */}
          <mesh position={[0, 1.6, 0]}>
            <sphereGeometry args={[1.5, 20, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <meshStandardMaterial color="#e3cfae" roughness={0.85} side={THREE.DoubleSide} />
          </mesh>
          {/* articular disc */}
          <mesh position={[displaced ? 0.55 : 0, 0.35, 0]} rotation={[0, 0, displaced ? 0.35 : 0]}>
            <cylinderGeometry args={[0.55, 0.55, 0.16, 18]} />
            <meshStandardMaterial color={displaced ? "#ef4444" : "#7dd3fc"} roughness={0.4} />
          </mesh>
          <Label text={displaced ? "Disc displaced — CLICK!" : "Disc in place"} position={[0, 1.05, 0]} size={0.45} color={displaced ? "#fca5a5" : "#7dd3fc"} />
          {/* condyle moving */}
          <group ref={jaw} position={[0, -0.4, 0]}>
            <mesh>
              <sphereGeometry args={[0.42, 16, 16]} />
              <meshStandardMaterial color="#d9c49c" roughness={0.8} />
            </mesh>
            <mesh position={[0, -0.8, 0.3]} rotation={[0.4, 0, 0]}>
              <boxGeometry args={[0.5, 1.6, 0.4]} />
              <meshStandardMaterial color="#e3cfae" roughness={0.85} />
            </mesh>
            <Label text="Condyle" position={[1.1, -0.2, 0]} size={0.4} color="#fde68a" />
          </group>
          {displaced && (
            <mesh position={[0.3, 0.35, 0.75]}>
              <sphereGeometry args={[0.12, 10, 10]} />
              <meshStandardMaterial color="#fde047" emissive="#facc15" emissiveIntensity={1.5} />
            </mesh>
          )}
          <Label text="TMJ — jaw joint" position={[0, 3.0, 0]} size={0.6} color="#e2e8f0" />
          <Label text={displaced ? "TMD: pain, clicking, limited opening" : "Healthy joint: smooth silent glide"} position={[0, -2.6, 0]} size={0.42} color="#e2e8f0" />
        </group>
      )}
    </group>
  );
}

export function Topic10441Sim(props: SimProps) {
  const view = String(props.view ?? "occlusion");
  const disc = String(props.disc ?? "normal");
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Focus", view === "occlusion" ? "Full-mouth rehab" : "TMJ"], ["Disc", disc], ["Plan", view === "occlusion" ? "Raise VDO → provisionals → final" : disc === "displaced" ? "Splint + physio" : "—"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, 0.3, 0]}>
        <Scene view={view} disc={disc} />
      </SimCanvas>
    </div>
  );
}
