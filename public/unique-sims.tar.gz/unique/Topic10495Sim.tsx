"use client";
// Exodontia: Forceps & Elevators — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "force", label: "Rocking force", kind: "slider", min: 0.3, max: 1.5, step: 0.1, default: 0.8, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Exodontia: Forceps & Elevators",
  blurb: "Rock the tooth side to side to stretch the ligament, then lift it clean out of the socket.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const T = 9;
    const ph = (t % T) / T;
    const th: any = g("extooth");
    const fc: any = g("forceps");
    if (th && fc) {
      if (ph < 0.55) {
        const rock = 0.28 * p.force * Math.sin(t * 5);
        th.rotation.z = rock;
        fc.rotation.z = rock;
        th.position.y = 1.1;
        fc.position.y = 2.2;
      } else {
        const lift = (ph - 0.55) / 0.45;
        th.rotation.z *= 1 - lift * 0.2;
        th.position.y = 1.1 + lift * 2.4;
        fc.position.y = 2.2 + lift * 2.4;
      }
    }
    const el: any = g("elevator");
    if (el) el.visible = ph < 0.3;
  });
  return null;
}

export function Topic10495Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const force = Number(props.force ?? 0.8);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, force };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Step 1", "Elevator luxation"],
          ["Step 2", "Forceps rocking"],
          ["Step 3", "Delivery"],
          ["Force", `${force.toFixed(1)}×`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <GumSlab position={[0, 0.2, 0]} scale={1.15} />
          <mesh position={[0, 0.45, 0]}>
            <cylinderGeometry args={[0.55, 0.6, 0.5, 14]} />
            <meshStandardMaterial color="#1e293b" roughness={1} />
          </mesh>
          <group name="extooth" position={[0, 1.1, 0]}>
            <Tooth scale={1.4} />
          </group>
          <group name="forceps" position={[0, 2.2, 0]}>
            <mesh position={[-0.35, 0.9, 0]} rotation={[0, 0, 0.25]}>
              <boxGeometry args={[0.14, 1.6, 0.2]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
            </mesh>
            <mesh position={[0.35, 0.9, 0]} rotation={[0, 0, -0.25]}>
              <boxGeometry args={[0.14, 1.6, 0.2]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
            </mesh>
            <mesh position={[-0.28, 0.05, 0]} rotation={[0, 0, 0.35]}>
              <boxGeometry args={[0.16, 0.7, 0.22]} />
              <meshStandardMaterial color="#64748b" metalness={0.85} roughness={0.3} />
            </mesh>
            <mesh position={[0.28, 0.05, 0]} rotation={[0, 0, -0.35]}>
              <boxGeometry args={[0.16, 0.7, 0.22]} />
              <meshStandardMaterial color="#64748b" metalness={0.85} roughness={0.3} />
            </mesh>
          </group>
          <group name="elevator" position={[0.85, 0.8, 0.2]}>
            <mesh rotation={[0, 0, -0.7]}>
              <boxGeometry args={[0.12, 1.4, 0.08]} />
              <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.25} />
            </mesh>
          </group>
          <Label text="Forceps beaks grip crown" position={[2.7, 2.4, 0]} size={0.42} />
          <Label text="Elevator wedges first" position={[-2.9, 0.8, 0.2]} size={0.42} />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
