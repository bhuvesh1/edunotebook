// Diabetes mellitus — type 1 vs type 2. A blood vessel carries glucose
// (yellow cubes); beta cells in the pancreas release insulin keys that unlock
// cell doors. Type 1: no keys made. Type 2: keys made but locks are rusty.
// Blood-sugar slider floods the vessel with glucose.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "sugar", label: "Blood sugar", kind: "slider", min: 70, max: 400, step: 5, default: 220, unit: " mg/dL" },
  { key: "type", label: "Diabetes type", kind: "select", min: 0, max: 0, step: 1, default: "type 2", options: ["type 1", "type 2"] },
];

export const UNIQUE_META = {
  title: "Diabetes Mellitus",
  blurb: "Glucose piles up in the blood because insulin keys are missing (type 1) or the locks are rusty (type 2). Raise blood sugar and watch.",
};

function Animator({ glucose, keys, elapsed, sugar, type }: {
  glucose: React.RefObject<THREE.Group>;
  keys: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  sugar: number;
  type: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (glucose.current) {
      glucose.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        m.position.x += delta * 1.5;
        if (m.position.x > 6.5) m.position.x = -6.5;
        m.rotation.x = t * 2 + i;
      });
    }
    if (keys.current) {
      keys.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * 0.5 + i * 0.2) % 1);
        // keys fly from pancreas to cell doors
        m.position.x = -2.2 + ph * 4.4;
        m.position.y = 2.8 - ph * 2.2;
        m.visible = type === "type 2"; // type 1: no keys at all
      });
    }
  });
  return null;
}

export function Topic10229Sim(props: SimProps) {
  const sugar = Number(props.sugar ?? 220);
  const type = String(props.type ?? "type 2");
  const glucose = useRef<THREE.Group>(null!);
  const keys = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const nGlucose = Math.round(6 + ((sugar - 70) / 330) * 26);
  const high = sugar > 180;
  const keyList = [0, 1, 2, 3, 4];

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Blood sugar", `${sugar} mg/dL`], ["Status", sugar > 250 ? "very high ⚠" : sugar > 140 ? "high" : "normal"], ["Problem", type === "type 1" ? "no insulin made" : "insulin resistance"]]} />
      <SimCanvas cameraPosition={[0, 2.6, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* blood vessel */}
        <mesh position={[0, 0.6, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.85, 0.85, 13.5, 20, 1, true]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.5} side={THREE.DoubleSide} transparent opacity={0.85} />
        </mesh>
        {/* glucose cubes flowing */}
        <group ref={glucose}>
          {Array.from({ length: nGlucose }).map((_, i) => (
            <mesh key={i} position={[-6.5 + (i * 13.5) / nGlucose, 0.6 + ((i * 0.37) % 0.9) - 0.45, ((i * 0.53) % 0.8) - 0.4]}>
              <boxGeometry args={[0.26, 0.26, 0.26]} />
              <meshStandardMaterial color="#facc15" roughness={0.4} emissive="#a16207" emissiveIntensity={0.4} />
            </mesh>
          ))}
        </group>

        {/* pancreas with beta cells */}
        <mesh position={[-2.2, 3.4, 0]} rotation={[0, 0, 0.1]} scale={[1.8, 0.7, 0.65]} castShadow>
          <sphereGeometry args={[0.85, 22, 16]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.55} />
        </mesh>
        {keyList.map((i) => (
          <mesh key={i} position={[-2.9 + i * 0.35, 3.75, 0.25]}>
            <sphereGeometry args={[0.13, 10, 10]} />
            <meshStandardMaterial color={type === "type 1" ? "#64748b" : "#38bdf8"} roughness={0.4} emissive={type === "type 1" ? "#000" : "#0c4a6e"} emissiveIntensity={0.6} />
          </mesh>
        ))}
        <Label text={type === "type 1" ? "Beta cells destroyed — no insulin" : "Beta cells make insulin"} position={[-2.2, 4.7, 0]} size={0.48} color={type === "type 1" ? "#fca5a5" : "#7dd3fc"} />

        {/* insulin keys flying to cells */}
        <group ref={keys}>
          {keyList.map((i) => (
            <mesh key={i} position={[-2.2, 2.8, 0]}>
              <torusGeometry args={[0.14, 0.05, 8, 14]} />
              <meshStandardMaterial color="#38bdf8" roughness={0.3} emissive="#0c4a6e" emissiveIntensity={0.7} />
            </mesh>
          ))}
        </group>

        {/* body cell with a door lock */}
        <group position={[2.6, 0.4, 0]}>
          <mesh scale={[1.3, 1.1, 1.1]} castShadow>
            <sphereGeometry args={[0.9, 22, 16]} />
            <meshStandardMaterial color="#86efac" roughness={0.5} transparent opacity={0.55} />
          </mesh>
          <mesh position={[0, 0.6, 0.85]}>
            <boxGeometry args={[0.5, 0.7, 0.15]} />
            <meshStandardMaterial color={type === "type 2" ? "#a16207" : "#fbbf24"} roughness={0.4} emissive={type === "type 2" ? "#713f12" : "#000"} emissiveIntensity={0.5} />
          </mesh>
          <Label text={type === "type 2" ? "Rusty lock — keys don't work" : "Lock works, but no keys arrive"} position={[0, 1.7, 0]} size={0.46} color={type === "type 2" ? "#fca5a5" : "#fde047"} />
        </group>

        <Label text={high ? "Sugar stuck in blood → damages eyes, kidneys, nerves" : "Sugar enters cells for energy ✓"} position={[0, -1.5, 0]} size={0.46} color={high ? "#fca5a5" : "#86efac"} />
        <Animator glucose={glucose} keys={keys} elapsed={elapsed} sugar={sugar} type={type} />
      </SimCanvas>
    </div>
  );
}
