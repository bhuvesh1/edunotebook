// Cholinergic drugs: acetylcholine released from the nerve ending crosses the
// synapse and docks on muscarinic receptors — the muscle twitches.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stim", label: "Nerve stimulation", kind: "slider", min: 0.3, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "drug", label: "Drug type", kind: "select", min: 0, max: 0, step: 1, default: "agonist", options: ["agonist", "antagonist"] },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Cholinergic drugs",
  blurb: "Acetylcholine crosses the synapse and docks on receptors — agonists boost the twitch, antagonists block it.",
};

const N = 10;
const REC_X = (i: number) => -2.25 + i * 0.5;

function Animator({ dots, muscle, elapsed, speed, setTick }: {
  dots: React.RefObject<(THREE.Mesh | null)[]>;
  muscle: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    let docked = 0;
    dots.current.forEach((d, i) => {
      if (!d) return;
      // cycle: released at top, fall through cleft, dock, fade, repeat
      const f = (t * 0.7 + i / N) % 1;
      const y = 2.9 - f * 2.1;
      d.position.set(REC_X(i) + Math.sin(t * 3 + i) * 0.08 * (1 - f), y, 0);
      ((d as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = f > 0.92 ? Math.max(0, 1 - (f - 0.92) * 12) : 1;
      if (f > 0.82 && f < 0.92) docked++;
    });
    if (muscle.current) {
      const twitch = 1 + docked * 0.02 * Math.abs(Math.sin(t * 6));
      muscle.current.scale.set(twitch, 1, 1);
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(docked); }
  });
  return null;
}

export function Topic10108Sim(props: SimProps) {
  const speed = Number(props.stim ?? 1);
  const drug = String(props.drug ?? "agonist");
  const isAgonist = drug === "agonist";
  const showLabels = String(props.detail ?? "on") === "on";
  const dots = useRef<(THREE.Mesh | null)[]>([]);
  const muscle = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Drug", isAgonist ? "Cholinergic agonist" : "Anticholinergic"],
          ["Receptors firing", isAgonist ? `${tick}` : "0 (blocked)"],
          ["Muscle", isAgonist ? "contracting" : "relaxed"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 10]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* nerve terminal bulb */}
        <mesh position={[0, 3.3, 0]} scale={[1.6, 0.8, 1]} castShadow>
          <sphereGeometry args={[0.9, 24, 18]} />
          <meshStandardMaterial color="#f59e0b" roughness={0.5} />
        </mesh>
        <mesh position={[0, 4.15, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.28, 0.28, 1.6, 12]} />
          <meshStandardMaterial color="#b45309" roughness={0.6} />
        </mesh>
        {showLabels && <Label text="nerve ending" position={[2.6, 3.6, 0]} color="#fcd34d" />}

        {/* synaptic cleft guide */}
        <mesh position={[0, 1.75, 0]}>
          <boxGeometry args={[5.4, 1.9, 0.06]} />
          <meshStandardMaterial color="#1e293b" transparent opacity={0.35} />
        </mesh>
        {showLabels && <Label text="synaptic cleft" position={[3.4, 1.75, 0]} size={0.45} color="#94a3b8" />}

        {/* muscle fibre with muscarinic receptors */}
        <mesh ref={muscle} position={[0, 0.45, 0]} castShadow>
          <boxGeometry args={[5.6, 0.7, 1.4]} />
          <meshStandardMaterial color="#ef4444" roughness={0.55} />
        </mesh>
        {Array.from({ length: N }).map((_, i) => (
          <mesh key={i} position={[REC_X(i), 0.95, 0]}>
            <cylinderGeometry args={[0.12, 0.16, 0.22, 10]} />
            <meshStandardMaterial
              color={isAgonist ? "#22c55e" : "#ef4444"}
              emissive={isAgonist ? "#16a34a" : "#7f1d1d"}
              emissiveIntensity={0.7}
            />
          </mesh>
        ))}
        {showLabels && <Label text="muscle — muscarinic receptors" position={[0, -0.35, 0]} color="#fca5a5" />}

        {/* acetylcholine (or blocker) molecules */}
        {Array.from({ length: N }).map((_, i) => (
          <mesh key={i} ref={(m) => { dots.current[i] = m; }} position={[REC_X(i), 2.9, 0]}>
            <sphereGeometry args={[0.14, 12, 10]} />
            <meshStandardMaterial
              color={isAgonist ? "#38bdf8" : "#ef4444"}
              emissive={isAgonist ? "#0284c7" : "#991b1b"}
              emissiveIntensity={1}
              transparent
            />
          </mesh>
        ))}
        {showLabels && (
          <Label
            text={isAgonist ? "acetylcholine (ACh)" : "anticholinergic blocker"}
            position={[0, 4.9, 0]}
            color={isAgonist ? "#7dd3fc" : "#fca5a5"}
          />
        )}

        <Animator dots={dots} muscle={muscle} elapsed={elapsed} speed={isAgonist ? speed : 0.001} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
