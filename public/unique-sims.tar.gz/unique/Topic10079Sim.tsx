"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "marker", label: "Marker", kind: "select", min: 0, max: 0, step: 1, default: "troponin", options: ["troponin", "PSA", "CA-125", "CEA", "AFP"] },
  { key: "level", label: "Marker level", kind: "slider", min: 0, max: 100, step: 1, default: 30 },
];

export const UNIQUE_META = {
  title: "Tumor & Cardiac Markers",
  blurb: "Pick a marker badge and raise its level: watch the troponin curve climb while the heart beats faster.",
};

const BADGES: [string, string][] = [["PSA","#60a5fa"],["CA-125","#f472b6"],["CEA","#facc15"],["AFP","#4ade80"],["troponin","#ef4444"]];

function Animator({ root, heart, bars, elapsed, level }: { root: RefObject<THREE.Group>; heart: RefObject<THREE.Group>; bars: RefObject<THREE.Group>; elapsed: RefObject<number>; level: number }) {
  useFrame((_, delta) => {
    elapsed.current += 0.016;
    const t = elapsed.current;
    if (heart.current) {
      const beat = 1 + 0.14 * Math.abs(Math.sin(t * (2 + level / 22)));
      heart.current.scale.setScalar(beat * (level > 70 ? 1.15 : 1));
    }
    if (bars.current) {
      bars.current.children.forEach((m, i) => {
        const target = (level / 100) * (0.4 + i * 0.09);
        m.scale.y += (Math.max(0.05, target) - m.scale.y) * 0.08;
        m.position.y = 0.4 + m.scale.y * 1.1;
      });
    }
  });
  return null;
}

export function Topic10079Sim(props: SimProps) {
  const marker = String(props.marker ?? "troponin");
  const level = Number(props.level ?? 30);
  const CUTS: Record<string, string> = { "troponin": "99th %ile URL", "PSA": "4 ng/mL", "CA-125": "35 U/mL", "CEA": "5 ng/mL", "AFP": "10 ng/mL" };
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const heart = useRef<THREE.Group>(null!);
  const bars = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Marker", marker],
          ["Level", `${level}`],
          ["Cutoff", CUTS[marker] ?? ""],
          ["Flag", level > 50 ? "ABNORMAL" : "normal"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          {BADGES.map(([name, color], i) => {
            const sel = marker === name;
            return (
              <group key={name} position={[-4.4 + i * 2.2, 4.4, 0]}>
                <mesh castShadow scale={[1, 1, 1]}>
                  <boxGeometry args={[1.9, 1, 0.18]} />
                  <meshStandardMaterial color={color} emissive={color} emissiveIntensity={sel ? 1.1 : 0.15} roughness={0.4} />
                </mesh>
                <Label text={name} position={[0, 0, 0.25]} size={0.4} color="#0f172a" />
              </group>
            );
          })}
          <group ref={heart} position={[-2.6, 1.9, 0]}>
            <mesh castShadow><sphereGeometry args={[0.85, 22, 22]} /><meshStandardMaterial color="#ef4444" roughness={0.45} /></mesh>
            <mesh position={[0.55, 0.45, 0]}><sphereGeometry args={[0.55, 18, 18]} /><meshStandardMaterial color="#dc2626" roughness={0.45} /></mesh>
            <mesh position={[0, 1.05, 0]} rotation={[0.4, 0, 0]}><coneGeometry args={[0.5, 0.9, 14]} /><meshStandardMaterial color="#b91c1c" roughness={0.45} /></mesh>
          </group>
          <Label text="heart" position={[-2.6, 0.6, 0]} size={0.42} color="#f87171" />
          <group ref={bars}>
            {Array.from({ length: 8 }).map((_, i) => (
              <mesh key={i} position={[1.2 + i * 0.55, 1, 0]} scale={[1, 0.2, 1]}>
                <boxGeometry args={[0.4, 2.2, 0.4]} /><meshStandardMaterial color="#ef4444" emissive="#b91c1d" emissiveIntensity={0.5} />
              </mesh>
            ))}
          </group>
          <Label text={`${marker} trend`} position={[3.2, 3.6, 0]} size={0.45} color="#f87171" />
          <Label text={level > 50 ? "ABNORMAL \u2014 investigate" : "within range"} position={[0, 5.6, 0]} size={0.5} color={level > 50 ? "#ef4444" : "#4ade80"} />
        </group>
        <Animator root={root} heart={heart} bars={bars} elapsed={elapsed} level={level} />
      </SimCanvas>
    </div>
  );
}
