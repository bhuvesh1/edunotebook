// General virology & hepatitis: a spiky virus particle tumbles in the
// bloodstream while hepatitis viruses swarm and infect the liver.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "load", label: "Viral load", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "General virology & hepatitis",
  blurb: "A spiky virus tumbles in blood while hepatitis viruses swarm and infect the liver.",
};

const N_HEP = 10;

function BigVirus({ color, spike }: { color: string; spike: string }) {
  return (
    <group>
      <mesh castShadow>
        <icosahedronGeometry args={[0.85, 1]} />
        <meshStandardMaterial color={color} roughness={0.45} flatShading />
      </mesh>
      {Array.from({ length: 14 }).map((_, i) => {
        const th = (i / 14) * Math.PI * 2;
        const ph = ((i * 47) % 10) / 10 * Math.PI - Math.PI / 2;
        return (
          <mesh
            key={i}
            position={[
              Math.cos(th) * Math.cos(ph) * 1.0,
              Math.sin(ph) * 1.0,
              Math.sin(th) * Math.cos(ph) * 1.0,
            ]}
          >
            <coneGeometry args={[0.09, 0.42, 8]} />
            <meshStandardMaterial color={spike} emissive={spike} emissiveIntensity={0.5} />
          </mesh>
        );
      })}
    </group>
  );
}

function Animator({ big, hep, liver, elapsed, load, setTick }: {
  big: React.RefObject<THREE.Group>;
  hep: React.RefObject<(THREE.Mesh | null)[]>;
  liver: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  load: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = load / 100;
    if (big.current) {
      big.current.rotation.y = t * 0.9;
      big.current.rotation.x = t * 0.4;
      big.current.position.y = 2.6 + Math.sin(t * 1.4) * 0.2;
    }
    let infecting = 0;
    hep.current.forEach((h, i) => {
      if (!h) return;
      const active = ((i * 53) % 10) / 10 < 0.2 + k * 0.8;
      h.visible = active;
      if (!active) return;
      // swarm from blood toward the liver, then stick to it
      const f = (t * 0.4 + i / N_HEP) % 1;
      const stick = Math.min(1, f * 1.6);
      h.position.set(
        -4.5 + stick * 7.2 + Math.sin(t * 3 + i * 2) * 0.2 * (1 - stick),
        1.8 + Math.sin(i * 2.4) * 0.7 * (1 - stick) + stick * 0.2,
        Math.cos(i * 1.8) * 0.8 * (1 - stick)
      );
      if (stick > 0.9) infecting++;
      h.rotation.y = t * 3 + i;
    });
    if (liver.current) {
      const m = liver.current.material as THREE.MeshStandardMaterial;
      // liver yellows (jaundice) as infection rises
      m.color.setHSL(0.07 - k * 0.04, 0.55, 0.32 + k * 0.12);
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(infecting); }
  });
  return null;
}

export function Topic10137Sim(props: SimProps) {
  const load = Number(props.load ?? 55);
  const showLabels = String(props.detail ?? "on") === "on";
  const big = useRef<THREE.Group>(null!);
  const hep = useRef<(THREE.Mesh | null)[]>([]);
  const liver = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Viruses on liver", `${tick}`],
          ["Liver", load > 65 ? "jaundiced" : load > 30 ? "inflamed" : "healthy"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* hero virus particle */}
        <group ref={big} position={[-3.4, 2.6, 0]}>
          <BigVirus color="#a855f7" spike="#e9d5ff" />
        </group>
        {showLabels && <Label text="virus — protein spikes" position={[-3.4, 4.2, 0]} color="#d8b4fe" />}
        {showLabels && <Label text="genetic material inside" position={[-3.4, 1.3, 0]} size={0.4} color="#c4b5fd" />}

        {/* liver */}
        <mesh ref={liver} position={[2.8, 1.7, -0.4]} scale={[1.5, 0.9, 1]} castShadow>
          <sphereGeometry args={[1.1, 24, 18]} />
          <meshStandardMaterial color="#7c2d12" roughness={0.55} />
        </mesh>
        {showLabels && <Label text="liver — hepatitis target" position={[2.8, 3.4, -0.4]} color="#fdba74" />}

        {/* hepatitis viruses swarming */}
        {Array.from({ length: N_HEP }).map((_, i) => (
          <group key={i} ref={(m) => { hep.current[i] = m as unknown as THREE.Mesh; }}>
            <mesh castShadow>
              <sphereGeometry args={[0.2, 12, 10]} />
              <meshStandardMaterial color="#facc15" emissive="#a16207" emissiveIntensity={0.9} />
            </mesh>
            {[0, 1, 2, 3, 4, 5].map((s) => {
              const a = (s / 6) * Math.PI * 2;
              return (
                <mesh key={s} position={[Math.cos(a) * 0.26, Math.sin(a) * 0.26, 0]}>
                  <coneGeometry args={[0.05, 0.18, 6]} />
                  <meshStandardMaterial color="#fef08a" emissive="#eab308" emissiveIntensity={0.6} />
                </mesh>
              );
            })}
          </group>
        ))}
        {showLabels && <Label text="hepatitis viruses (A–E)" position={[-4.6, 1.4, 0]} size={0.45} color="#fde047" />}

        <Animator big={big} hep={hep} liver={liver} elapsed={elapsed} load={load} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
