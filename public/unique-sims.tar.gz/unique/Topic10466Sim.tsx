"use client";
// Biology of Tooth Movement — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "force", label: "Ortho force", kind: "slider", min: 50, max: 300, step: 10, default: 150, unit: " g" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Biology of Tooth Movement",
  blurb: "Push a tooth and watch the biology: bone melts away on the pressure side and rebuilds on the tension side.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const th: any = g("movetooth");
    const drift = 0.15 + (p.force / 300) * 0.75;
    if (th) th.position.x = drift * (0.5 + 0.5 * Math.sin(t * 0.7));
    const pr: any = g("presszone");
    if (pr) (pr.material as any).opacity = 0.25 + (p.force / 300) * 0.45 * (0.7 + 0.3 * Math.sin(t * 3));
    const tn: any = g("tenszone");
    if (tn) (tn.material as any).opacity = 0.25 + (p.force / 300) * 0.45 * (0.7 + 0.3 * Math.cos(t * 3));
    const ar: any = g("forcearrow");
    if (ar) ar.scale.setScalar(0.8 + (p.force / 300) * 0.6);
  });
  return null;
}

export function Topic10466Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const force = Number(props.force ?? 150);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, force };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Force", `${force} g`],
          ["Pressure side", "Bone resorbs (red)"],
          ["Tension side", "Bone forms (green)"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <BoneBlock position={[0, 0.6, -1.1]} scale={1.1} />
          <GumSlab position={[0, 1.9, 0]} scale={1.1} />
          <group name="movetooth" position={[0, 1.6, 0]}>
            <Tooth scale={1.3} />
          </group>
          {[-0.9, -0.45, 0, 0.45, 0.9].map((y, i) => (
            <mesh key={i} position={[-0.85, 1.3 + y * 0.8, 0]} rotation={[0, 0, 0.5]}>
              <cylinderGeometry args={[0.03, 0.03, 0.7, 6]} />
              <meshStandardMaterial color="#eab308" roughness={0.6} />
            </mesh>
          ))}
          {[-0.9, -0.45, 0, 0.45, 0.9].map((y, i) => (
            <mesh key={i} position={[0.85, 1.3 + y * 0.8, 0]} rotation={[0, 0, -0.5]}>
              <cylinderGeometry args={[0.03, 0.03, 0.7, 6]} />
              <meshStandardMaterial color="#eab308" roughness={0.6} />
            </mesh>
          ))}
          <mesh name="presszone" position={[1.05, 1.4, 0]}>
            <sphereGeometry args={[0.55, 12, 12]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.7} transparent opacity={0.4} />
          </mesh>
          <mesh name="tenszone" position={[-1.05, 1.4, 0]}>
            <sphereGeometry args={[0.55, 12, 12]} />
            <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.7} transparent opacity={0.4} />
          </mesh>
          <group name="forcearrow" position={[-2.6, 1.8, 0]}>
            <Arrow from={[0, 0, 0]} to={[1.1, 0, 0]} color="#fbbf24" />
          </group>
          <Label text="Pressure: bone resorbs" position={[2.6, 2.6, 0]} size={0.42} color="#ef4444" />
          <Label text="Tension: bone forms" position={[-2.7, 2.6, 0]} size={0.42} color="#22c55e" />
          <Label text="PDL fibers" position={[0, 0.15, 0]} size={0.42} color="#eab308" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
