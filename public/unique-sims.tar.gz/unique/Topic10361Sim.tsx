"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "bleed", label: "Bleeding rate", kind: "slider", min: 0, max: 1.5, step: 0.1, default: 1, unit: "×" },
  { key: "tourniquet", label: "Tourniquet", kind: "select", min: 0, max: 0, step: 1, default: "off", options: ["off", "on"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Trauma resuscitation, hemorrhage control",
  blurb: "Bleeding leg wound with flowing blood — apply direct pressure and a tourniquet to stop it, then watch the IV blood drip restore volume.",
};

const SKIN = "#f7c9a8";
const BLOOD = "#dc2626";

// Blood stream particles falling from the wound
function BloodFlow({ bleed, tourniquet, speed }: { bleed: number; tourniquet: boolean; speed: number }) {
  const pts = useRef<THREE.Points>(null!);
  const N = 120;
  const data = useRef<Float32Array>(null!);
  if (!data.current) {
    const arr = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 0.5;
      arr[i * 3 + 1] = Math.random() * 2.2;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 0.5;
    }
    data.current = arr;
  }
  useFrame((_, delta) => {
    if (!pts.current) return;
    const p = pts.current.geometry.attributes.position;
    const active = !tourniquet && bleed > 0.05;
    pts.current.visible = active;
    if (!active) return;
    for (let i = 0; i < N; i++) {
      let y = p.getY(i) - delta * speed * (2.2 + bleed * 2.5);
      if (y < 0) {
        y = 2.2;
        p.setX(i, (Math.random() - 0.5) * 0.5);
        p.setZ(i, (Math.random() - 0.5) * 0.5);
      }
      p.setY(i, y);
    }
    p.needsUpdate = true;
  });
  return (
    <points ref={pts} position={[0, 0.6, 0.55]}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[data.current, 3]} />
      </bufferGeometry>
      <pointsMaterial color={BLOOD} size={0.11} transparent opacity={0.95} />
    </points>
  );
}

// Blood bag dripping into IV line
function BloodBag({ drip }: { drip: boolean }) {
  const drop = useRef<THREE.Mesh>(null!);
  const bagLevel = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (drop.current) {
      const c = (elapsed.current * 1.5) % 1;
      drop.current.position.y = 2.6 - c * 1.4;
      drop.current.visible = drip;
      (drop.current.material as THREE.MeshBasicMaterial).opacity = 1 - c;
    }
    if (bagLevel.current) {
      const s = Math.max(0.25, 1 - (elapsed.current % 60) / 60);
      bagLevel.current.scale.y = s;
      bagLevel.current.position.y = 3.6 - (1 - s) * 0.5;
    }
  });
  return (
    <group position={[3.2, 0, -0.5]}>
      {/* stand pole */}
      <mesh position={[0, 1.6, 0]} castShadow>
        <cylinderGeometry args={[0.08, 0.08, 4.6, 10]} />
        <meshStandardMaterial color="#94a3b8" metalness={0.7} roughness={0.4} />
      </mesh>
      {/* bag */}
      <mesh position={[0, 3.7, 0]} castShadow>
        <boxGeometry args={[1, 1.4, 0.35]} />
        <meshPhysicalMaterial color="#fecdd3" transparent opacity={0.5} roughness={0.2} />
      </mesh>
      <mesh ref={bagLevel} position={[0, 3.6, 0]}>
        <boxGeometry args={[0.9, 1.2, 0.28]} />
        <meshStandardMaterial color={BLOOD} roughness={0.3} />
      </mesh>
      {/* drip chamber + line down to arm */}
      <mesh position={[0, 2.9, 0]}>
        <cylinderGeometry args={[0.12, 0.12, 0.5, 10]} />
        <meshPhysicalMaterial color="#e0f2fe" transparent opacity={0.6} roughness={0.1} />
      </mesh>
      <mesh ref={drop} position={[0, 2.6, 0]}>
        <sphereGeometry args={[0.07, 10, 10]} />
        <meshBasicMaterial color={BLOOD} transparent opacity={1} />
      </mesh>
      <mesh position={[-1.2, 1.6, 0.3]} rotation={[0, 0, 1.05]}>
        <cylinderGeometry args={[0.03, 0.03, 3.2, 8]} />
        <meshStandardMaterial color="#e0f2fe" transparent opacity={0.7} roughness={0.2} />
      </mesh>
    </group>
  );
}

function TraumaScene({ bleed, tourniquet, speed, showLabels }: { bleed: number; tourniquet: boolean; speed: number; showLabels: boolean }) {
  const pool = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (pool.current) {
      const grow = tourniquet ? 1 : 1 + Math.sin(elapsed.current * 0.3) * 0.05;
      pool.current.scale.set(grow * (0.6 + bleed * 0.8), 1, grow * (0.5 + bleed * 0.6));
    }
  });
  return (
    <group>
      {/* thigh */}
      <mesh position={[0, 2.2, 0]} castShadow>
        <cylinderGeometry args={[1.05, 0.85, 3.6, 20]} />
        <meshStandardMaterial color={SKIN} roughness={0.65} />
      </mesh>
      {/* knee + shin */}
      <mesh position={[0, 0.1, 0]} castShadow>
        <cylinderGeometry args={[0.7, 0.55, 1.6, 16]} />
        <meshStandardMaterial color={SKIN} roughness={0.65} />
      </mesh>
      {/* wound crater on thigh */}
      <mesh position={[0, 2.9, 0.72]} rotation={[Math.PI / 2.4, 0, 0]} castShadow>
        <cylinderGeometry args={[0.5, 0.62, 0.35, 20]} />
        <meshStandardMaterial color="#7f1d1d" roughness={0.85} />
      </mesh>
      <mesh position={[0, 2.98, 0.78]} rotation={[-Math.PI / 2.6, 0, 0]}>
        <circleGeometry args={[0.42, 20]} />
        <meshStandardMaterial color="#991b1b" roughness={0.4} emissive="#7f1d1d" emissiveIntensity={0.4} />
      </mesh>
      {/* torn edges */}
      {[-0.5, 0.5].map((x, i) => (
        <mesh key={i} position={[x, 3.05, 0.7]} rotation={[0, 0, x * 0.8]} castShadow>
          <boxGeometry args={[0.5, 0.18, 0.4]} />
          <meshStandardMaterial color={SKIN} roughness={0.65} />
        </mesh>
      ))}
      <BloodFlow bleed={bleed} tourniquet={tourniquet} speed={speed} />
      {/* tourniquet band above wound */}
      <group position={[0, 3.7, 0]}>
        <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
          <torusGeometry args={[1.12, tourniquet ? 0.16 : 0.1, 10, 28]} />
          <meshStandardMaterial color={tourniquet ? "#f97316" : "#78716c"} roughness={0.6} />
        </mesh>
        {/* windlass stick */}
        <mesh position={[0, 0.2, 1.05]} rotation={[Math.PI / 2, 0, 0.6]} castShadow>
          <cylinderGeometry args={[0.06, 0.06, 0.9, 8]} />
          <meshStandardMaterial color="#1c1917" roughness={0.5} />
        </mesh>
      </group>
      {/* pooling blood on ground */}
      <mesh ref={pool} position={[0, 0.02, 0.9]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[1.1, 28]} />
        <meshStandardMaterial color={BLOOD} transparent opacity={0.75} roughness={0.25} />
      </mesh>
      <BloodBag drip={tourniquet || bleed < 0.4} />
      {showLabels && (
        <>
          <Text position={[-3.2, 2.9, 0]} fontSize={0.42} color="#fca5a5">Arterial bleed</Text>
          <Text position={[2.6, 4.4, 0]} fontSize={0.42} color="#fdba74">{tourniquet ? "Tourniquet ON — bleed stopped" : "Tourniquet off"}</Text>
          <Text position={[3.2, 5.2, -0.5]} fontSize={0.4} color="#fecaca">Blood transfusion</Text>
          <Text position={[0, 5.4, 0]} fontSize={0.44} color="#fef3c7" maxWidth={8}>C-A-B-C: catastrophic hemorrhage first</Text>
        </>
      )}
    </group>
  );
}

export function Topic10361Sim(props: SimProps) {
  const bleed = Number(props.bleed ?? 1);
  const tourniquet = String(props.tourniquet ?? "off") === "on";
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Bleeding", tourniquet ? "controlled ✓" : bleed > 0.8 ? "severe" : bleed > 0.3 ? "moderate" : "oozing"],
          ["Tourniquet", tourniquet ? "ON 2–3″ above wound" : "off"],
          ["Resuscitation", "blood + TXA + warm"],
        ]}
      />
      <SimCanvas cameraPosition={[6.5, 4.5, 9]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.35, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <TraumaScene bleed={bleed} tourniquet={tourniquet} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
