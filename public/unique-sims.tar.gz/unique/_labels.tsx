// Shared text-label helper for unique topic sims.
// Camera-facing canvas-texture sprites — fully offline, no font downloads.
"use client";

import { useMemo } from "react";
import * as THREE from "three";

interface LabelProps {
  text: string;
  position: [number, number, number];
  size?: number;
  color?: string;
  bg?: string;
}

export function Label({ text, position, size = 0.55, color = "#f1f5f9", bg = "rgba(2,6,23,0.62)" }: LabelProps) {
  const { texture, aspect } = useMemo(() => {
    const c = document.createElement("canvas");
    let ctx = c.getContext("2d")!;
    const font = "600 44px system-ui, -apple-system, sans-serif";
    ctx.font = font;
    const tw = Math.ceil(ctx.measureText(text).width);
    c.width = tw + 40;
    c.height = 72;
    ctx = c.getContext("2d")!;
    ctx.font = font;
    ctx.fillStyle = bg;
    const r = 14;
    ctx.beginPath();
    ctx.roundRect(0, 0, c.width, c.height, r);
    ctx.fill();
    ctx.fillStyle = color;
    ctx.textBaseline = "middle";
    ctx.fillText(text, 20, c.height / 2 + 2);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return { texture: tex, aspect: c.width / c.height };
  }, [text, color, bg]);

  return (
    <sprite position={position} scale={[aspect * size, size, 1]}>
      <spriteMaterial map={texture} transparent depthWrite={false} />
    </sprite>
  );
}

/** 3D arrow from `from` to `to`. */
export function Arrow({
  from,
  to,
  color = "#fbbf24",
  thickness = 0.05,
}: {
  from: [number, number, number];
  to: [number, number, number];
  color?: string;
  thickness?: number;
}) {
  const { dir, len, quat } = useMemo(() => {
    const a = new THREE.Vector3(...from);
    const b = new THREE.Vector3(...to);
    const d = b.clone().sub(a);
    const len = Math.max(d.length(), 0.001);
    const dir = d.clone().normalize();
    const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
    return { dir, len, quat };
  }, [from, to]);
  const headLen = Math.min(0.34, len * 0.32);
  const shaftLen = Math.max(len - headLen, 0.01);
  const a = new THREE.Vector3(...from);
  const midShaft = a.clone().addScaledVector(dir, shaftLen / 2);
  const headPos = a.clone().addScaledVector(dir, shaftLen + headLen / 2);
  return (
    <group>
      <mesh position={midShaft} quaternion={quat}>
        <cylinderGeometry args={[thickness, thickness, shaftLen, 10]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.25} />
      </mesh>
      <mesh position={headPos} quaternion={quat}>
        <coneGeometry args={[thickness * 2.8, headLen, 12]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.25} />
      </mesh>
    </group>
  );
}
