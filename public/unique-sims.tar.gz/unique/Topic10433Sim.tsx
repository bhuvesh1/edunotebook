"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "part", label: "Highlight part", kind: "select", min: 0, max: 0, step: 1, default: "clasp", options: ["clasp", "rest", "connector", "base"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Removable partial dentures: components — clasps, rests, connectors",
  blurb: "A partial denture exploded over the teeth — metal clasps hug the teeth, rests sit on top, connector spans the palate.",
};

const PARTS: Record<string, { name: string; note: string; color: string }> = {
  clasp: { name: "Clasp (retainer)", note: "C-shaped arm grips the tooth below its bulge", color: "#fbbf24" },
  rest: { name: "Rest", note: "Small shelf on the tooth — carries the bite force", color: "#7dd3fc" },
  connector: { name: "Major connector", note: "Joins both sides across the palate", color: "#a78bfa" },
  base: { name: "Denture base + teeth", note: "Pink acrylic holds the false teeth", color: "#f472b6" },
};

function Scene({ part, speed }: { part: string; speed: number }) {
  const group = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const p = PARTS[part] ?? PARTS.clasp;
  const hi = (k: string) => (k === part ? 1.6 : 0.25);

  useFrame((_, delta) => {
    t.current += delta * speed;
    if (group.current) group.current.rotation.y = t.current * 0.35;
  });

  const teeth: { x: number; z: number; a: number }[] = [];
  const n = 6;
  for (let i = 0; i < n; i++) {
    const a = Math.PI * (0.1 + (0.8 * i) / (n - 1));
    teeth.push({ x: Math.cos(a) * 2.6, z: Math.sin(a) * 2.6, a });
  }
  const abutments = [1, 4];

  return (
    <group ref={group}>
      {/* natural teeth */}
      {teeth.map((tt, i) => (
        <group key={i} position={[tt.x, 0.5, tt.z]} rotation={[0, -tt.a + Math.PI / 2, 0]}>
          <mesh>
            <cylinderGeometry args={[0.28, 0.34, 0.7, 10]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.3} />
          </mesh>
          {/* rest seat on abutments */}
          {abutments.includes(i) && (
            <mesh position={[0, 0.42, 0]}>
              <boxGeometry args={[0.22, 0.08, 0.3]} />
              <meshStandardMaterial color="#7dd3fc" emissive="#0ea5e9" emissiveIntensity={hi("rest")} />
            </mesh>
          )}
          {/* clasp arm wrapping abutment */}
          {abutments.includes(i) && (
            <mesh position={[0, 0.05, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.38, 0.07, 8, 20, Math.PI * 1.5]} />
              <meshStandardMaterial color="#d4af37" metalness={0.7} roughness={0.35} emissive="#fbbf24" emissiveIntensity={hi("clasp")} />
            </mesh>
          )}
        </group>
      ))}

      {/* major connector across palate */}
      <mesh position={[0, 0.75, -0.5]} rotation={[0.25, 0, 0]}>
        <boxGeometry args={[3.4, 0.08, 1.1]} />
        <meshStandardMaterial color="#c0c7d1" metalness={0.7} roughness={0.35} emissive="#a78bfa" emissiveIntensity={hi("connector")} />
      </mesh>
      {/* minor connectors to clasps */}
      {abutments.map((i) => {
        const tt = teeth[i];
        return (
          <mesh key={i} position={[tt.x * 0.75, 0.7, tt.z * 0.75 - 0.3]}>
            <boxGeometry args={[0.18, 0.08, 1.2]} />
            <meshStandardMaterial color="#c0c7d1" metalness={0.7} roughness={0.35} emissive="#a78bfa" emissiveIntensity={hi("connector")} />
          </mesh>
        );
      })}

      {/* denture base + artificial teeth over the gap */}
      <group>
        <mesh position={[0, 0.35, 2.35]}>
          <boxGeometry args={[1.7, 0.3, 1.1]} />
          <meshStandardMaterial color="#f472b6" emissive="#f472b6" emissiveIntensity={hi("base")} roughness={0.5} />
        </mesh>
        {[-0.5, 0, 0.5].map((x, i) => (
          <mesh key={i} position={[x, 0.75, 2.35]}>
            <boxGeometry args={[0.4, 0.45, 0.5]} />
            <meshStandardMaterial color="#fdfbf3" roughness={0.3} emissive="#f472b6" emissiveIntensity={hi("base") * 0.4} />
          </mesh>
        ))}
      </group>

      <Label text={p.name} position={[0, 3.2, 0]} size={0.65} color={p.color} />
      <Label text={p.note} position={[0, -1.8, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10433Sim(props: SimProps) {
  const part = String(props.part ?? "clasp");
  const speed = Number(props.speed ?? 1);
  const p = PARTS[part] ?? PARTS.clasp;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Component", p.name], ["Material", part === "base" ? "Acrylic" : "Cobalt-chromium"], ["Function", part === "clasp" ? "Retention" : part === "rest" ? "Support" : part === "connector" ? "Join + rigidity" : "Replace teeth"]]} />
      <SimCanvas cameraPosition={[0, 3.5, 9]} target={[0, 0.4, 0]}>
        <Scene part={part} speed={speed} />
      </SimCanvas>
    </div>
  );
}
