"use client";
// Periodontal Examination: Probing & Indices — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "depth", label: "Pocket depth", kind: "slider", min: 1, max: 10, step: 0.5, default: 4, unit: " mm" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Periodontal Examination: Probing & Indices",
  blurb: "Slide the probe into the pocket — the depth gauge reads out the CPI score like a real checkup.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const pr: any = g("probe");
    if (pr) pr.position.y = 3.3 - p.depth * 0.22;
    const fill: any = g("pocketfill");
    if (fill) {
      fill.scale.y = Math.max(0.05, p.depth * 0.22);
      fill.position.y = 2.05 - (p.depth * 0.22) / 2;
      (fill.material as any).color.set(p.depth <= 3 ? "#4ade80" : p.depth <= 5 ? "#fbbf24" : "#ef4444");
    }
  });
  return null;
}

export function Topic10484Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const depth = Number(props.depth ?? 4);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, depth };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Pocket depth", `${depth} mm`],
          ["CPI", depth <= 3 ? "0–2: healthy/gingivitis" : depth <= 5 ? "3: shallow pocket" : "4: deep pocket"],
          ["Probe", "Williams, 1mm marks"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1.2, 0]} scale={1.5} />
          <mesh position={[-0.9, 1.5, 0]}>
            <boxGeometry args={[1.2, 1.4, 2]} />
            <meshStandardMaterial color="#e0808f" roughness={0.6} />
          </mesh>
          <mesh name="pocketfill" position={[-0.28, 1.6, 0]}>
            <boxGeometry args={[0.18, 1, 0.5]} />
            <meshStandardMaterial color="#4ade80" emissive="#4ade80" emissiveIntensity={0.4} transparent opacity={0.85} />
          </mesh>
          <group name="probe" position={[-0.28, 2.4, 0]}>
            <mesh>
              <cylinderGeometry args={[0.035, 0.035, 2.4, 8]} />
              <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.25} />
            </mesh>
            {[0, 1, 2, 3].map((i) => (
              <mesh key={i} position={[0, -0.7 + i * 0.22, 0]}>
                <cylinderGeometry args={[0.04, 0.04, 0.06, 8]} />
                <meshStandardMaterial color="#1e293b" roughness={0.5} />
              </mesh>
            ))}
          </group>
          <Label text="Williams probe" position={[-2.6, 3.4, 0]} size={0.42} />
          <Label text="Pocket depth gauge" position={[2.2, 1.8, 0]} size={0.42} />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
