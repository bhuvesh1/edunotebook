// Histology: circulatory system + lymphoid organs — an artery in cross-section
// with red blood cells streaming through its lumen, beside a lymph node whose
// follicles pulse with immune activity.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "flow", label: "Blood flow rate", kind: "slider", min: 0, max: 2.5, step: 0.1, default: 1, unit: "×" },
  { key: "vessel", label: "Vessel type", kind: "select", min: 0, max: 0, step: 1, default: "artery", options: ["artery", "vein"] },
];

export const UNIQUE_META = {
  title: "Histology: Artery & Lymph Node",
  blurb: "RBCs stream through an artery's thick muscular wall; next door a lymph node glows with active follicles.",
};

function Animator({
  rbcs, follicles, wall, elapsed, flow, speed,
}: {
  rbcs: React.RefObject<THREE.Group>;
  follicles: React.RefObject<THREE.Group>;
  wall: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  flow: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (rbcs.current) {
      rbcs.current.children.forEach((m, i) => {
        const ph = ((t * 0.28 * flow + i / 14) % 1 + 1) % 1;
        m.position.x = -4.6 + ph * 9.2;
        m.position.y = 1.9 + Math.sin(t * 3 + i * 2.2) * 0.18 * (1 - Math.abs(m.position.x) / 6);
        m.rotation.x += delta * 2;
      });
    }
    if (follicles.current) {
      follicles.current.children.forEach((m, i) => {
        const s = 1 + 0.16 * Math.sin(t * 2.4 + i * 1.3);
        m.scale.setScalar(s);
      });
    }
    if (wall.current) {
      const s = 1 + 0.03 * Math.sin(t * flow * Math.PI * 2 * 1.1);
      wall.current.scale.set(s, s, 1);
    }
  });
  return null;
}

export function Topic10018Sim(props: SimProps) {
  const flow = Number(props.flow ?? 1);
  const vessel = String(props.vessel ?? "artery");
  const speed = 1;
  const rbcs = useRef<THREE.Group>(null!);
  const follicles = useRef<THREE.Group>(null!);
  const wall = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const isArtery = vessel === "artery";
  const wallR = isArtery ? 1.5 : 1.25;
  const wallColor = isArtery ? "#ef4444" : "#3b82f6";

  const rbcSeeds = useMemo(
    () =>
      Array.from({ length: 14 }).map((_, i) => ({
        y: 1.9 + (i % 5) * 0.22 - 0.45,
        z: ((i * 2.3) % 3) * 0.4 - 0.5,
      })),
    []
  );
  const folliclePos = useMemo(
    () =>
      [
        [-0.8, 0.6, 0.3], [0.7, 0.7, -0.2], [0, 0.1, 0.5],
        [-0.5, -0.4, -0.4], [0.9, -0.3, 0.3], [0.1, 0.9, 0],
      ] as [number, number, number][],
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Vessel", isArtery ? "artery — thick wall" : "vein — thin wall"],
          ["Flow", `${flow.toFixed(1)}×`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5, 15]} target={[0.5, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* vessel wall: thick muscular tube */}
        <group ref={wall} position={[-2.5, 1.9, 0]}>
          <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
            <cylinderGeometry args={[wallR, wallR, 9.6, 28, 1, true]} />
            <meshStandardMaterial color={wallColor} roughness={0.5} side={THREE.DoubleSide} />
          </mesh>
          {/* smooth-muscle rings */}
          {Array.from({ length: 9 }).map((_, i) => (
            <mesh key={i} position={[-4.4 + i * 1.1, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
              <torusGeometry args={[wallR, 0.09, 8, 28]} />
              <meshStandardMaterial color={isArtery ? "#b91c1c" : "#1d4ed8"} roughness={0.5} />
            </mesh>
          ))}
          {/* lumen glow */}
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[wallR - 0.45, wallR - 0.45, 9.5, 20, 1, true]} />
            <meshStandardMaterial color="#7f1d1d" roughness={0.7} side={THREE.BackSide} />
          </mesh>
        </group>
        {/* RBCs streaming through the lumen */}
        <group ref={rbcs}>
          {rbcSeeds.map((s, i) => (
            <mesh key={i} position={[-4.6, s.y, s.z]} scale={[1, 0.42, 1]} castShadow>
              <sphereGeometry args={[0.24, 14, 14]} />
              <meshStandardMaterial color="#dc2626" roughness={0.4} />
            </mesh>
          ))}
        </group>
        <Label text={isArtery ? "artery" : "vein"} position={[-2.5, 4.3, 0]} size={0.44} color="#f8fafc" />
        <Label text="tunica media (smooth muscle)" position={[-2.5, 0.35, 2.2]} size={0.3} color="#fca5a5" />
        <Label text="red blood cells" position={[2.6, 3.4, 0]} size={0.32} color="#fca5a5" />

        {/* lymph node */}
        <group position={[6.8, 1.6, 0]}>
          <mesh castShadow scale={[1.15, 0.85, 0.85]}>
            <sphereGeometry args={[1.5, 24, 24]} />
            <meshStandardMaterial color="#d6a97c" transparent opacity={0.55} roughness={0.45} />
          </mesh>
          <group ref={follicles}>
            {folliclePos.map((p, i) => (
              <mesh key={i} position={p} castShadow>
                <sphereGeometry args={[0.34, 14, 14]} />
                <meshStandardMaterial color="#4ade80" emissive="#14532d" emissiveIntensity={0.5} roughness={0.4} />
              </mesh>
            ))}
          </group>
          {/* hilum vessels */}
          <mesh position={[1.9, -0.4, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.12, 0.12, 1.4, 10]} />
            <meshStandardMaterial color="#ef4444" />
          </mesh>
          <mesh position={[1.9, 0.35, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.14, 0.14, 1.4, 10]} />
            <meshStandardMaterial color="#3b82f6" />
          </mesh>
        </group>
        <Label text="lymph node" position={[6.8, 3.5, 0]} size={0.42} color="#f8fafc" />
        <Label text="lymphoid follicles" position={[6.8, 0.15, 1.3]} size={0.3} color="#86efac" />

        <Animator rbcs={rbcs} follicles={follicles} wall={wall} elapsed={elapsed} flow={flow} speed={speed} />
      </SimCanvas>
    </div>
  );
}
