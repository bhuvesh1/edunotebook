"use client";
// Impacted Canines & Supernumerary Teeth — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Impacted Canines & Supernumerary Teeth",
  blurb: "A canine stuck high in the gum is winched down along its traction path — spot the extra tooth too.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const T = 10;
    const ph = (t % T) / T;
    const ca: any = g("canine");
    if (ca) {
      const k = ph < 0.75 ? ph / 0.75 : 1;
      ca.position.set(1.5 - k * 0.4, 3.6 - k * 2.3, 0);
    }
    for (let i = 0; i < 6; i++) {
      const d: any = g("path" + i);
      if (d) (d.material as any).opacity = 0.35 + 0.35 * Math.sin(t * 4 - i);
    }
    const sup: any = g("super");
    if (sup) {
      sup.visible = ph < 0.85;
      (sup.material as any).opacity = ph < 0.7 ? 1 : 1 - (ph - 0.7) / 0.15;
    }
  });
  return null;
}

export function Topic10500Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Canine", "Palatally impacted"],
          ["Traction", "Gold chain + elastic"],
          ["Extra", "Supernumerary — remove"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          {[-2.4, -1.2, 0, 2.4].map((x, i) => (
            <mesh key={i} position={[x, 1.2, 0]}>
              <boxGeometry args={[1, 1.5, 1]} />
              <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
            </mesh>
          ))}
          <GumSlab position={[0, 0.15, -0.3]} scale={1.25} />
          <group name="canine" position={[1.5, 3.6, 0]}>
            <Tooth scale={1.05} enamel="#fbf7ec" />
          </group>
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <mesh key={i} name={"path" + i} position={[1.5 - (i / 5) * 0.4, 3.5 - (i / 5) * 2.2, 0]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.7} transparent opacity={0.6} />
            </mesh>
          ))}
          <mesh name="super" position={[-1.2, 1.2, 0.9]}>
            <boxGeometry args={[0.6, 0.8, 0.6]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.5} transparent opacity={1} roughness={0.4} />
          </mesh>
          <Label text="Impacted canine" position={[2.9, 3.9, 0]} size={0.42} />
          <Label text="Traction path" position={[-1.6, 2.6, 0]} size={0.4} color="#fbbf24" />
          <Label text="Supernumerary!" position={[-1.2, 2.3, 0.9]} size={0.4} color="#ef4444" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
