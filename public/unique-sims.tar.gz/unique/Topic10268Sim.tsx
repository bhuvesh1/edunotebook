// Respiratory (pediatrics): pneumonia, bronchiolitis, asthma in children.
// Child's lungs breathe in and out. Air particles stream through the bronchial
// tree; asthma squeezes the airways shut, pneumonia inflames one lobe.

"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "asthma", options: ["healthy", "pneumonia", "bronchiolitis", "asthma"] },
  { key: "rate", label: "Breath rate", kind: "slider", min: 0.3, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Child's Lungs: Asthma & Pneumonia",
  blurb: "Watch a child's lungs breathe — then see asthma squeeze the airways, pneumonia inflame a lobe, or bronchiolitis clog tiny airways.",
};

const N_AIR = 30;

function Animator({
  group, lungL, lungR, air, bronchi, elapsed, rate, condition,
}: {
  group: React.RefObject<THREE.Group>;
  lungL: React.RefObject<THREE.Group>;
  lungR: React.RefObject<THREE.Group>;
  air: React.RefObject<THREE.Group>;
  bronchi: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  rate: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * rate;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // breathing: lungs inflate/deflate; asthmatic breathing is labored
    const labored = condition === "asthma" ? 0.6 : 1;
    const b = 0.5 + 0.5 * Math.sin(t * 3 * labored);
    const inflate = 1 + b * 0.16 * (condition === "pneumonia" ? 0.6 : 1);
    if (lungL.current) lungL.current.scale.set(inflate * 0.95, inflate, inflate * 0.95);
    if (lungR.current) {
      const stiff = condition === "pneumonia" ? 0.35 : 1; // consolidated lobe barely moves
      lungR.current.scale.set(1 + b * 0.16 * stiff * 0.95, 1 + b * 0.16 * stiff, 1 + b * 0.16 * stiff * 0.95);
    }
    // air particles flow in on inhale, out on exhale
    if (air.current) {
      air.current.children.forEach((p, i) => {
        const ph = (b + i / N_AIR) % 1;
        const side = i % 2 === 0 ? -1 : 1;
        const depth = ph * 2.2;
        p.position.set(side * (0.15 + depth * 0.45), 3.6 - depth * 0.75, 0.1);
        (p as THREE.Mesh).scale.setScalar(0.6 + ph * 0.8);
      });
    }
    // asthma: bronchi narrow and spasm
    if (bronchi.current) {
      const narrow = condition === "asthma" ? 0.45 + 0.1 * Math.sin(t * 9) : condition === "bronchiolitis" ? 0.7 : 1;
      bronchi.current.children.forEach((br) => {
        (br as THREE.Mesh).scale.set(narrow, 1, narrow);
      });
    }
  });
  return null;
}

export function Topic10268Sim(props: SimProps) {
  const condition = String(props.condition ?? "asthma");
  const rate = Number(props.rate ?? 1);
  const group = useRef<THREE.Group>(null!);
  const lungL = useRef<THREE.Group>(null!);
  const lungR = useRef<THREE.Group>(null!);
  const air = useRef<THREE.Group>(null!);
  const bronchi = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const lobeGeo = useMemo(() => new THREE.SphereGeometry(1, 24, 18), []);
  const names: Record<string, string> = { healthy: "Healthy lungs", pneumonia: "Pneumonia (right lobe)", bronchiolitis: "Bronchiolitis", asthma: "Asthma attack" };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Breath rate", `${rate.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* windpipe */}
          <mesh position={[0, 4.3, 0]} castShadow>
            <cylinderGeometry args={[0.32, 0.32, 1.6, 16]} />
            <meshStandardMaterial color="#bae6fd" roughness={0.5} />
          </mesh>
          {/* bronchial tree */}
          <group ref={bronchi}>
            {[-1, 1].map((s) => (
              <mesh key={s} position={[s * 0.5, 3.45, 0]} rotation={[0, 0, s * 0.55]} castShadow>
                <cylinderGeometry args={[0.16, 0.2, 1.3, 12]} />
                <meshStandardMaterial color={condition === "bronchiolitis" ? "#fbbf24" : "#7dd3fc"} roughness={0.5} emissive={condition === "bronchiolitis" ? "#92400e" : "#000000"} emissiveIntensity={0.4} />
              </mesh>
            ))}
            {[-1, 1].map((s) => [-0.5, -0.9].map((dy, j) => (
              <mesh key={`${s}${j}`} position={[s * (0.85 + j * 0.25), 3.1 + dy * 0.5, 0]} rotation={[0, 0, s * 0.9]} castShadow>
                <cylinderGeometry args={[0.08, 0.1, 0.7, 10]} />
                <meshStandardMaterial color="#7dd3fc" roughness={0.5} />
              </mesh>
            )))}
          </group>
          {/* lungs */}
          <group ref={lungL} position={[-1.15, 2.3, 0]}>
            <mesh geometry={lobeGeo} scale={[0.95, 1.35, 0.75]} castShadow>
              <meshStandardMaterial color="#fda4af" roughness={0.5} transparent opacity={0.92} />
            </mesh>
          </group>
          <group ref={lungR} position={[1.15, 2.3, 0]}>
            <mesh geometry={lobeGeo} scale={[0.95, 1.35, 0.75]} castShadow>
              <meshStandardMaterial
                color={condition === "pneumonia" ? "#dc2626" : "#fda4af"}
                roughness={0.5}
                transparent
                opacity={0.92}
                emissive={condition === "pneumonia" ? "#7f1d1d" : "#000000"}
                emissiveIntensity={condition === "pneumonia" ? 0.5 : 0}
              />
            </mesh>
            {condition === "pneumonia" && (
              <mesh position={[0, 0.3, 0.45]} scale={[0.6, 0.9, 0.4]}>
                <sphereGeometry args={[0.5, 16, 12]} />
                <meshStandardMaterial color="#fbbf24" roughness={0.6} transparent opacity={0.75} />
              </mesh>
            )}
          </group>
          {/* air particles */}
          <group ref={air}>
            {Array.from({ length: N_AIR }).map((_, i) => (
              <mesh key={i}>
                <sphereGeometry args={[0.08, 8, 6]} />
                <meshBasicMaterial color="#e0f2fe" transparent opacity={0.8} />
              </mesh>
            ))}
          </group>
          <Label text="Windpipe" position={[0, 5.35, 0]} size={0.5} color="#bae6fd" />
          <Label text="Bronchi" position={[-2.2, 3.4, 0]} size={0.5} color="#7dd3fc" />
          {condition === "pneumonia" && <Label text="⚠ Infected lobe (consolidation)" position={[1.15, 0.75, 0]} size={0.55} color="#fca5a5" />}
          {condition === "asthma" && <Label text="⚠ Airways squeezed shut" position={[0, 0.85, 0]} size={0.55} color="#fca5a5" />}
          {condition === "bronchiolitis" && <Label text="⚠ Tiny airways swollen" position={[0, 0.85, 0]} size={0.55} color="#fde68a" />}
          {condition === "healthy" && <Label text="Easy breathing ✓" position={[0, 0.85, 0]} size={0.55} color="#86efac" />}
        </group>
        <Animator group={group} lungL={lungL} lungR={lungR} air={air} bronchi={bronchi} elapsed={elapsed} rate={rate} condition={condition} />
      </SimCanvas>
    </div>
  );
}
