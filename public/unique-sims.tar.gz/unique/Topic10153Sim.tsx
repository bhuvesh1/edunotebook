"use client";
// Autopsy: procedure, exhumation, artifacts.
// An examination table with a covered form, a magnifying glass that scans
// back and forth, and an instrument tray — the steps of an autopsy.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "step", label: "Autopsy step", kind: "select", min: 0, max: 0, step: 1, default: "external", options: ["external", "internal", "samples"] },
  { key: "speed", label: "Scan speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Autopsy: Procedure, Exhumation, Artifacts",
  blurb: "A magnifier scans the body step by step — external exam, internal exam, then samples for the lab.",
};

function Animator({ glass, elapsed, speed }: { glass: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (glass.current) {
      glass.current.position.x = Math.sin(elapsed.current * 1.1) * 1.7;
      glass.current.position.y = 2.6 + Math.cos(elapsed.current * 2.2) * 0.15;
    }
  });
  return null;
}

export function Topic10153Sim(props: SimProps) {
  const step = String(props.step ?? "external");
  const speed = Number(props.speed ?? 1);
  const glass = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const stepInfo: Record<string, [string, string]> = {
    external: ["1 · External examination", "Look: injuries, marks, clothes"],
    internal: ["2 · Internal examination", "Open: organs weighed & checked"],
    samples: ["3 · Samples to lab", "Blood, tissue → toxicology"],
  };
  const [stepTitle, stepDesc] = stepInfo[step] ?? stepInfo.external;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Step", stepTitle], ["Note", stepDesc]]} />
      <SimCanvas cameraPosition={[0, 4, 12]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* examination table */}
        <group position={[0, 0, 0]}>
          <mesh position={[0, 1.05, 0]} castShadow>
            <boxGeometry args={[5.4, 0.22, 2.2]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.5} roughness={0.4} />
          </mesh>
          {[[-2.4, -0.9], [2.4, -0.9], [-2.4, 0.9], [2.4, 0.9]].map(([x, z]) => (
            <mesh key={`${x}${z}`} position={[x, 0.5, z]} castShadow>
              <boxGeometry args={[0.18, 1, 0.18]} />
              <meshStandardMaterial color="#475569" roughness={0.7} />
            </mesh>
          ))}
          {/* covered form */}
          <mesh position={[-0.4, 1.65, 0]} castShadow>
            <capsuleGeometry args={[0.55, 2.6, 6, 14]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.9} />
          </mesh>
          <mesh position={[-0.4, 2.35, 0]} rotation={[0, 0, Math.PI / 2]}>
            <capsuleGeometry args={[0.55, 0.4, 6, 14]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.9} />
          </mesh>
          {step !== "external" && (
            <mesh position={[-0.4, 1.7, 0.62]}>
              <boxGeometry args={[1.6, 0.7, 0.06]} />
              <meshStandardMaterial color={step === "internal" ? "#f87171" : "#38bdf8"} emissive={step === "internal" ? "#ef4444" : "#0ea5e9"} emissiveIntensity={0.45} />
            </mesh>
          )}
          <Label text="EXAMINATION TABLE" position={[0, 3.3, 0]} size={0.6} color="#fbbf24" />
        </group>
        {/* scanning magnifier */}
        <group ref={glass} position={[0, 2.6, 1.6]}>
          <mesh rotation={[0.5, 0, 0]}>
            <torusGeometry args={[0.55, 0.09, 12, 28]} />
            <meshStandardMaterial color="#b45309" roughness={0.5} />
          </mesh>
          <mesh rotation={[0.5, 0, 0]} position={[0, -0.75, 0.42]}>
            <cylinderGeometry args={[0.06, 0.06, 1.1, 10]} />
            <meshStandardMaterial color="#92400e" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0, 0.02]} rotation={[0.5, 0, 0]}>
            <circleGeometry args={[0.5, 28]} />
            <meshStandardMaterial color="#bae6fd" transparent opacity={0.35} roughness={0.1} />
          </mesh>
        </group>
        {/* instrument tray */}
        <group position={[4.6, 0, 0.6]}>
          <mesh position={[0, 0.9, 0]} castShadow>
            <boxGeometry args={[2.4, 0.12, 1.6]} />
            <meshStandardMaterial color="#64748b" metalness={0.6} roughness={0.4} />
          </mesh>
          <mesh position={[0, 0.45, 0]}>
            <boxGeometry args={[0.3, 0.9, 0.3]} />
            <meshStandardMaterial color="#475569" roughness={0.7} />
          </mesh>
          {[[-0.7, 0], [0, 0.2], [0.7, -0.1]].map(([x, z], i) => (
            <mesh key={i} position={[x, 1.05, z]} rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.04, 0.04, 0.9, 8]} />
              <meshStandardMaterial color="#e2e8f0" metalness={0.8} roughness={0.3} />
            </mesh>
          ))}
          <Label text="INSTRUMENTS" position={[0, 1.9, 0]} size={0.55} />
        </group>
        <Label text={stepTitle} position={[0, 4.6, 0]} size={0.7} color="#93c5fd" />
        <Animator glass={glass} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
