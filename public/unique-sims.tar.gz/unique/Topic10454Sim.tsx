"use client";
// Post-Endodontic Restoration: Posts, Cores, Crowns — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "postdepth", label: "Post depth", kind: "slider", min: 0.5, max: 1.5, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Post-Endodontic Restoration: Posts, Cores, Crowns",
  blurb: "Rebuild a root-treated tooth step by step: metal post into the canal, core build-up, then the crown cap.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const T = 10;
    const ph = (t % T) / T;
    const post: any = g("post");
    const core: any = g("core");
    const crown: any = g("crown");
    const ease = (x: number) => x * x * (3 - 2 * x);
    if (post) {
      const k = ease(Math.min(1, Math.max(0, ph / 0.3)));
      post.position.y = 4.2 - (4.2 - (2.5 - (p.postdepth - 1) * 0.5)) * k;
      post.scale.y = p.postdepth;
    }
    if (core) {
      const k = ease(Math.min(1, Math.max(0, (ph - 0.3) / 0.25)));
      core.scale.setScalar(Math.max(0.001, k));
    }
    if (crown) {
      const k = ease(Math.min(1, Math.max(0, (ph - 0.55) / 0.3)));
      crown.position.y = 5.2 - (5.2 - 2.75) * k;
    }
    group.current.rotation.y = Math.sin(t * 0.2) * 0.3;
  });
  return null;
}

export function Topic10454Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const postdepth = Number(props.postdepth ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, postdepth };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Step 1", "Post cemented in canal"],
          ["Step 2", "Core build-up"],
          ["Step 3", "Crown seated"],
          ["Post depth", `${postdepth.toFixed(1)}×`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 0.7, 0]} scale={1.4} showCanal name="endo" />
          <GumSlab position={[0, -0.1, 0]} scale={1.2} />
          <mesh name="post" position={[0, 4.2, 0]}>
            <cylinderGeometry args={[0.09, 0.07, 1.7, 10]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.9} roughness={0.3} />
          </mesh>
          <mesh name="core" position={[0, 2.35, 0]}>
            <boxGeometry args={[0.85, 0.6, 0.85]} />
            <meshStandardMaterial color="#93c5fd" roughness={0.5} />
          </mesh>
          <group name="crown" position={[0, 5.2, 0]}>
            <mesh>
              <cylinderGeometry args={[0.72, 0.62, 0.85, 16]} />
              <meshStandardMaterial color="#faf7ef" roughness={0.25} />
            </mesh>
            {[[-0.32, -0.22], [0.32, -0.22], [-0.32, 0.22], [0.32, 0.22]].map((c, i) => (
              <mesh key={i} position={[c[0], 0.5, c[1]]}>
                <sphereGeometry args={[0.2, 10, 10]} />
                <meshStandardMaterial color="#faf7ef" roughness={0.25} />
              </mesh>
            ))}
          </group>
          <Label text="Metal post" position={[2.2, 3.4, 0]} size={0.42} />
          <Label text="Core build-up" position={[-2.4, 2.4, 0]} size={0.42} color="#93c5fd" />
          <Label text="Crown" position={[2.3, 4.9, 0]} size={0.42} />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
