// HIV & respiratory viruses: HIV docks on a CD4 T-cell and buds new virions
// while a crowned coronavirus drifts through the airway.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "load", label: "Viral load", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "HIV & respiratory viruses",
  blurb: "HIV docks on a CD4 cell and buds new virions while a crowned coronavirus drifts through the airway.",
};

const N_BUD = 8;

function SpikyBall({ r, color, spikes, spikeColor, n = 12 }: {
  r: number; color: string; spikes: number; spikeColor: string; n?: number;
}) {
  return (
    <group>
      <mesh castShadow>
        <sphereGeometry args={[r, 20, 14]} />
        <meshStandardMaterial color={color} roughness={0.45} />
      </mesh>
      {Array.from({ length: n }).map((_, i) => {
        const th = (i / n) * Math.PI * 2;
        const ph = ((i * 53) % 10) / 10 * Math.PI - Math.PI / 2;
        return (
          <group
            key={i}
            position={[
              Math.cos(th) * Math.cos(ph) * (r + spikes / 2),
              Math.sin(ph) * (r + spikes / 2),
              Math.sin(th) * Math.cos(ph) * (r + spikes / 2),
            ]}
          >
            <mesh>
              <cylinderGeometry args={[0.05, 0.05, spikes, 6]} />
              <meshStandardMaterial color={spikeColor} emissive={spikeColor} emissiveIntensity={0.5} />
            </mesh>
            <mesh position={[0, spikes / 2 + 0.06, 0]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshStandardMaterial color={spikeColor} emissive={spikeColor} emissiveIntensity={0.7} />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

function Animator({ hiv, buds, corona, tcell, elapsed, load, setTick }: {
  hiv: React.RefObject<THREE.Group>;
  buds: React.RefObject<(THREE.Mesh | null)[]>;
  corona: React.RefObject<THREE.Group>;
  tcell: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  load: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = load / 100;
    if (hiv.current) {
      // HIV approaches and docks on the T-cell
      const dock = Math.min(1, t * 0.2);
      hiv.current.position.set(-4.5 + dock * 2.6, 1.7, 0);
      hiv.current.rotation.y = t * 1.2;
    }
    buds.current.forEach((b, i) => {
      if (!b) return;
      const active = ((i * 41) % 10) / 10 < k;
      b.visible = active;
      if (!active) return;
      // new virions bud off the infected cell surface
      const f = (t * 0.5 + i / N_BUD) % 1;
      const a = (i / N_BUD) * Math.PI * 2;
      b.position.set(-1.9 + Math.cos(a) * (0.9 + f * 1.6), 1.7 + Math.sin(a) * (0.9 + f * 1.6), Math.sin(f * 5) * 0.5);
      b.scale.setScalar(0.3 + f * 0.7);
    });
    if (tcell.current) {
      // T-cell depletes as viral load rises
      const s = 1 - k * 0.35 + Math.sin(t * 2) * 0.03;
      tcell.current.scale.setScalar(Math.max(0.3, s));
    }
    if (corona.current) {
      corona.current.rotation.y = t * 0.8;
      corona.current.position.y = 3.6 + Math.sin(t * 1.6) * 0.25;
      corona.current.position.x = 3.2 + Math.sin(t * 0.5) * 0.6;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(k * 100)); }
  });
  return null;
}

export function Topic10138Sim(props: SimProps) {
  const load = Number(props.load ?? 55);
  const showLabels = String(props.detail ?? "on") === "on";
  const hiv = useRef<THREE.Group>(null!);
  const buds = useRef<(THREE.Mesh | null)[]>([]);
  const corona = useRef<THREE.Group>(null!);
  const tcell = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Viral load", `${tick}%`],
          ["CD4 T-cells", load > 65 ? "depleted" : load > 30 ? "falling" : "holding"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* CD4 T-cell */}
        <mesh ref={tcell} position={[-1.9, 1.7, 0]} castShadow>
          <sphereGeometry args={[0.95, 22, 16]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.5} />
        </mesh>
        {showLabels && <Label text="CD4 T-cell" position={[-1.9, 3.2, 0]} color="#7dd3fc" />}

        {/* HIV docking */}
        <group ref={hiv} position={[-4.5, 1.7, 0]}>
          <SpikyBall r={0.55} color="#ef4444" spikes={0.3} spikeColor="#fca5a5" n={14} />
        </group>
        {showLabels && <Label text="HIV — gp120 spikes" position={[-4.5, 0.6, 0]} size={0.45} color="#fca5a5" />}

        {/* budding virions */}
        {Array.from({ length: N_BUD }).map((_, i) => (
          <mesh key={i} ref={(m) => { buds.current[i] = m; }}>
            <sphereGeometry args={[0.16, 10, 8]} />
            <meshStandardMaterial color="#f87171" emissive="#b91c1c" emissiveIntensity={0.9} />
          </mesh>
        ))}
        {showLabels && <Label text="new virions budding" position={[-1.9, 0.35, 0]} size={0.4} color="#fca5a5" />}

        {/* coronavirus in the airway */}
        <group>
          <mesh position={[3.2, 4.6, -0.5]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.55, 0.55, 2.6, 14, 1, true]} />
            <meshStandardMaterial color="#f9a8d4" transparent opacity={0.4} side={THREE.DoubleSide} />
          </mesh>
          {showLabels && <Label text="airway" position={[3.2, 5.6, -0.5]} size={0.4} color="#f9a8d4" />}
        </group>
        <group ref={corona} position={[3.2, 3.6, 0]}>
          <SpikyBall r={0.6} color="#f59e0b" spikes={0.35} spikeColor="#fde047" n={14} />
        </group>
        {showLabels && <Label text="coronavirus — crown spikes" position={[3.2, 2.5, 0]} size={0.45} color="#fcd34d" />}

        {/* ART pill */}
        <group position={[0.4, 0, 2.2]}>
          <mesh position={[0, 0.4, 0]} castShadow>
            <capsuleGeometry args={[0.2, 0.34, 8, 14]} />
            <meshStandardMaterial color="#4ade80" roughness={0.3} />
          </mesh>
        </group>
        {showLabels && <Label text="antiretroviral therapy" position={[0.4, 1.3, 2.2]} size={0.4} color="#86efac" />}

        <Animator hiv={hiv} buds={buds} corona={corona} tcell={tcell} elapsed={elapsed} load={load} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
