"use client";
// Throat: stridor, tracheostomy, laryngeal tumors.
// A windpipe of C-shaped rings carries air; pick stridor to narrow it
// with a whistling squeeze, or tracheostomy to open a breathing tube.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "stridor", options: ["normal", "stridor", "tracheostomy", "tumor"] },
  { key: "speed", label: "Airflow speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Stridor, Tracheostomy & Laryngeal Tumors",
  blurb: "Air whooshes down the windpipe — squeeze it into noisy stridor, or fit a tracheostomy tube as a new airway.",
};

const N_AIR = 16;

function Animator({ air, squeeze, elapsed, speed, condition }: { air: React.RefObject<THREE.Group>; squeeze: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; speed: number; condition: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (air.current) {
      const blocked = condition === "stridor" ? 0.45 : condition === "tumor" ? 0.6 : 0;
      air.current.children.forEach((p, i) => {
        const viaTube = condition === "tracheostomy" && i % 2 === 0;
        const ph = (elapsed.current * 1.1 + (i / N_AIR)) % 1;
        p.position.y = 5 - ph * 4.6;
        p.position.x = viaTube ? 1.35 : Math.sin(ph * 9 + i) * 0.15 * (1 - blocked);
        p.visible = ph > blocked * 0.7 || viaTube;
      });
    }
    if (squeeze.current) {
      const target = condition === "stridor" ? 0.55 : condition === "tumor" ? 0.7 : 1;
      const s = squeeze.current.scale;
      s.x += (target - s.x) * 0.08;
      s.z += (target - s.z) * 0.08;
    }
  });
  return null;
}

export function Topic10194Sim(props: SimProps) {
  const condition = String(props.condition ?? "stridor");
  const speed = Number(props.speed ?? 1);
  const air = useRef<THREE.Group>(null!);
  const squeeze = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const note =
    condition === "stridor" ? "Noisy breathing — narrowed airway" :
    condition === "tracheostomy" ? "Tube = new airway below blockage" :
    condition === "tumor" ? "Tumor narrows the voice box" : "Wide open, silent airflow";

  const airDots = useMemo(
    () =>
      Array.from({ length: N_AIR }, (_, i) => (
        <mesh key={i} position={[0, 5 - (i / N_AIR) * 4.6, 0]}>
          <sphereGeometry args={[0.12, 8, 8]} />
          <meshStandardMaterial color="#7dd3fc" emissive="#38bdf8" emissiveIntensity={0.9} />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Airway", condition], ["Sound", note]]} />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* trachea: C-rings */}
        <group position={[0, 2.8, 0]}>
          <mesh ref={squeeze}>
            <group>
              {[0, 1, 2, 3, 4, 5, 6].map((i) => (
                <mesh key={i} position={[0, 1.9 - i * 0.62, 0]} rotation={[0, 0.5, 0]} castShadow>
                  <torusGeometry args={[0.72, 0.11, 8, 22, Math.PI * 1.7]} />
                  <meshStandardMaterial color="#bae6fd" roughness={0.5} />
                </mesh>
              ))}
            </group>
          </mesh>
          <mesh position={[0, 2.1, 0]}>
            <cylinderGeometry args={[0.6, 0.6, 4.6, 14, 1, true]} />
            <meshStandardMaterial color="#e0f2fe" transparent opacity={0.18} roughness={0.3} side={THREE.DoubleSide} />
          </mesh>
          {/* tumor lump */}
          {condition === "tumor" && (
            <group position={[0.55, 1.2, 0.3]}>
              <mesh castShadow>
                <icosahedronGeometry args={[0.5, 1]} />
                <meshStandardMaterial color="#7c3aed" emissive="#8b5cf6" emissiveIntensity={0.5} roughness={0.55} flatShading />
              </mesh>
              <Label text="TUMOR" position={[1.1, 0.6, 0]} size={0.5} color="#c4b5fd" />
            </group>
          )}
          {/* tracheostomy tube */}
          {condition === "tracheostomy" && (
            <group position={[1.35, 0.4, 0]}>
              <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
                <cylinderGeometry args={[0.28, 0.28, 1.6, 12]} />
                <meshStandardMaterial color="#38bdf8" roughness={0.4} />
              </mesh>
              <mesh position={[0.9, 0, 0]}>
                <boxGeometry args={[0.5, 0.9, 0.9]} />
                <meshStandardMaterial color="#0ea5e9" roughness={0.5} />
              </mesh>
              <Label text="TRACH TUBE" position={[1.4, 1, 0]} size={0.5} color="#7dd3fc" />
            </group>
          )}
          <group ref={air}>{airDots}</group>
          <Arrow from={[-2.4, 5.6, 0]} to={[-0.9, 5.6, 0]} color="#7dd3fc" />
          <Label text="AIR IN" position={[-3.1, 6.1, 0]} size={0.55} color="#7dd3fc" />
          <Label text="WINDPIPE (TRACHEA)" position={[0, -0.9, 0]} size={0.55} color="#bae6fd" />
          {condition === "stridor" && (
            <Label text="⚠ STRIDOR: noisy, narrowed" position={[0, 5.9, 0]} size={0.6} color="#fbbf24" />
          )}
        </group>
        <Animator air={air} squeeze={squeeze} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
