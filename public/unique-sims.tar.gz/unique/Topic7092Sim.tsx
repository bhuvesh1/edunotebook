// app/components/sims/unique/Topic7092Sim.tsx
// Uniform vs non-uniform motion: two cars race side by side. The top car
// moves uniformly (constant speed) so its time-dots land equally spaced;
// the bottom car accelerates, so its dots spread further apart.

"use client";

import { useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Cruise speed", kind: "slider", min: 1, max: 5, step: 0.5, default: 2.5, unit: "m/s" },
];

export const UNIQUE_META = {
  title: "Uniform and Non-Uniform Motion",
  blurb: "Race: constant speed vs speeding up. Equal-time dots reveal which is which.",
};

const DOTS = 14;
const DOT_DT = 0.4;

function Racer({
  car,
  dots,
  laneZ,
  color,
  speed,
  accelerating,
  offset,
}: {
  car: RefObject<THREE.Group>;
  dots: RefObject<THREE.Group>;
  laneZ: number;
  color: string;
  speed: number;
  accelerating: boolean;
  offset: number;
}) {
  const t = useRef(offset);
  const lastDrop = useRef(-10);
  const dropX = useRef<number[]>([]);
  const wheels = useRef<THREE.Group>(null!);
  useFrame((_, delta) => {
    t.current += delta;
    const T = t.current;
    const v = accelerating ? speed * 0.4 + T * 1.1 : speed;
    const x = accelerating ? speed * 0.4 * T + 0.55 * T * T - 8.5 : speed * T - 8.5;
    if (x > 9.5) {
      t.current = 0;
      dropX.current = [];
      lastDrop.current = -10;
      return;
    }
    if (car.current) car.current.position.x = x;
    if (wheels.current) wheels.current.children.forEach((w) => (w.rotation.z -= (v * delta) / 0.32));
    if (T - lastDrop.current >= DOT_DT) {
      lastDrop.current = T;
      dropX.current.push(x);
      if (dropX.current.length > DOTS) dropX.current.shift();
    }
    if (dots.current) {
      const kids = dots.current.children;
      for (let i = 0; i < DOTS; i++) {
        const k = kids[i];
        if (i < dropX.current.length) {
          k.visible = true;
          k.position.set(dropX.current[i], 0.14, laneZ);
        } else k.visible = false;
      }
    }
  });
  return (
    <>
      <group ref={dots}>
        {Array.from({ length: DOTS }, (_, i) => (
          <mesh key={i} visible={false}>
            <sphereGeometry args={[0.11, 12, 12]} />
            <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} />
          </mesh>
        ))}
      </group>
      <group ref={car} position={[0, 0, laneZ]}>
        <mesh position={[0, 0.72, 0]} castShadow>
          <boxGeometry args={[2.2, 0.66, 1.2]} />
          <meshStandardMaterial color={color} roughness={0.35} metalness={0.4} />
        </mesh>
        <mesh position={[-0.15, 1.3, 0]} castShadow>
          <boxGeometry args={[1.1, 0.55, 1.0]} />
          <meshStandardMaterial color="#e2e8f0" roughness={0.25} metalness={0.3} />
        </mesh>
        <group ref={wheels}>
          {[-0.75, 0.75].map((x) =>
            [-0.62, 0.62].map((z) => (
              <mesh key={`${x}${z}`} position={[x, 0.32, z]} rotation={[Math.PI / 2, 0, 0]}>
                <cylinderGeometry args={[0.32, 0.32, 0.18, 18]} />
                <meshStandardMaterial color="#111827" roughness={0.8} />
              </mesh>
            ))
          )}
        </group>
      </group>
    </>
  );
}

export function Topic7092Sim(props: SimProps) {
  const speed = Number(props.speed ?? 2.5);
  const carA = useRef<THREE.Group>(null!);
  const carB = useRef<THREE.Group>(null!);
  const dotsA = useRef<THREE.Group>(null!);
  const dotsB = useRef<THREE.Group>(null!);
  const [, bump] = useState(0);
  void bump;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["🔵 Top car", "uniform — dots equally spaced"],
          ["🟠 Bottom car", "non-uniform — dots spread out"],
          ["Dots", "dropped every 0.4 s"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 7, 15]} target={[0, 0.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {[-1.6, 1.6].map((z) => (
          <mesh key={z} position={[0, 0.05, z]} receiveShadow>
            <boxGeometry args={[21, 0.1, 2.2]} />
            <meshStandardMaterial color="#334155" roughness={0.9} />
          </mesh>
        ))}
        <Racer car={carA} dots={dotsA} laneZ={-1.6} color="#38bdf8" speed={speed} accelerating={false} offset={0} />
        <Racer car={carB} dots={dotsB} laneZ={1.6} color="#fb923c" speed={speed} accelerating offset={1.2} />
      </SimCanvas>
    </div>
  );
}
