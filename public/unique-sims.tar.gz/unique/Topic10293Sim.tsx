// Operative OBGYN: episiotomy, forceps, vacuum, hysterectomy basics.
// The delivery-room instruments: forceps blades cradling the baby's head,
// the vacuum cup with suction, episiotomy scissors — and the uterus lifted
// away in hysterectomy.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "tool", label: "Instrument", kind: "select", min: 0, max: 0, step: 1, default: "forceps", options: ["forceps", "vacuum", "episiotomy", "hysterectomy"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Delivery Instruments & Hysterectomy",
  blurb: "Forceps cradling the head, vacuum cup pulling with suction, the episiotomy cut — and uterus removal in hysterectomy.",
};

function Animator({
  group, toolGroup, babyHead, uterus, elapsed, speed, tool,
}: {
  group: React.RefObject<THREE.Group>;
  toolGroup: React.RefObject<THREE.Group>;
  babyHead: React.RefObject<THREE.Group>;
  uterus: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
  tool: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
    // gentle traction pulls in the delivery direction
    if (toolGroup.current && (tool === "forceps" || tool === "vacuum")) {
      const pull = 0.5 + 0.5 * Math.sin(t * 1.6);
      toolGroup.current.position.z = 0.6 + pull * 0.55;
      if (babyHead.current) babyHead.current.position.z = 0.1 + pull * 0.55;
    }
    if (tool === "episiotomy" && toolGroup.current) {
      // scissors snip open and closed
      const snip = 0.5 + 0.5 * Math.sin(t * 3);
      toolGroup.current.children.forEach((b, i) => {
        b.rotation.z = (i === 0 ? 1 : -1) * (0.15 + snip * 0.35);
      });
    }
    if (uterus.current && tool === "hysterectomy") {
      // uterus is lifted out and away
      const cyc = (t % 10) / 10;
      const lift = cyc < 0.4 ? cyc / 0.4 : cyc < 0.7 ? 1 : 1 - (cyc - 0.7) / 0.3;
      uterus.current.position.y = 2.2 + lift * 2.2;
      uterus.current.position.x = lift * 2.4;
      uterus.current.rotation.z = lift * 0.5;
    }
  });
  return null;
}

export function Topic10293Sim(props: SimProps) {
  const tool = String(props.tool ?? "forceps");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const toolGroup = useRef<THREE.Group>(null!);
  const babyHead = useRef<THREE.Group>(null!);
  const uterus = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    forceps: "Obstetric forceps", vacuum: "Vacuum extractor", episiotomy: "Episiotomy scissors", hysterectomy: "Hysterectomy",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Instrument", names[tool] ?? tool], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10.5]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* birth canal ring */}
          <mesh position={[0, 1.6, -0.6]} rotation={[Math.PI / 2.3, 0, 0]} castShadow>
            <torusGeometry args={[0.85, 0.24, 14, 24]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
          </mesh>
          {/* baby's head at the outlet */}
          <group ref={babyHead} position={[0, 1.6, 0.1]}>
            <mesh castShadow>
              <sphereGeometry args={[0.55, 24, 18]} />
              <meshStandardMaterial color="#fde68a" roughness={0.6} />
            </mesh>
          </group>

          {(tool === "forceps" || tool === "vacuum") && (
            <group ref={toolGroup} position={[0, 1.6, 0.6]}>
              {tool === "forceps" ? (
                <>
                  {/* two curved blades cradling the head */}
                  {[-1, 1].map((s) => (
                    <group key={s} position={[s * 0.62, 0, -0.5]}>
                      <mesh rotation={[0, s * 0.35, 0]} castShadow>
                        <torusGeometry args={[0.5, 0.07, 10, 20, Math.PI * 1.2]} />
                        <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.3} />
                      </mesh>
                      <mesh position={[s * 0.25, 0, 0.75]} rotation={[Math.PI / 2, 0, 0]} castShadow>
                        <cylinderGeometry args={[0.06, 0.06, 1.6, 10]} />
                        <meshStandardMaterial color="#64748b" metalness={0.8} roughness={0.3} />
                      </mesh>
                    </group>
                  ))}
                  <mesh position={[0, 0, 1.6]} castShadow>
                    <boxGeometry args={[0.5, 0.18, 0.3]} />
                    <meshStandardMaterial color="#1e293b" roughness={0.5} />
                  </mesh>
                </>
              ) : (
                <>
                  {/* vacuum cup on the head + suction tube */}
                  <mesh position={[0, 0.1, -0.55]} rotation={[Math.PI / 2, 0, 0]} castShadow>
                    <cylinderGeometry args={[0.3, 0.38, 0.35, 18]} />
                    <meshStandardMaterial color="#38bdf8" roughness={0.4} transparent opacity={0.85} />
                  </mesh>
                  <mesh position={[0, 0.1, 0.4]} rotation={[Math.PI / 2, 0, 0]} castShadow>
                    <cylinderGeometry args={[0.07, 0.07, 1.8, 10]} />
                    <meshStandardMaterial color="#94a3b8" roughness={0.4} />
                  </mesh>
                  <mesh position={[0, 0.1, 1.4]} castShadow>
                    <boxGeometry args={[0.5, 0.4, 0.5]} />
                    <meshStandardMaterial color="#1e293b" roughness={0.5} />
                  </mesh>
                </>
              )}
            </group>
          )}

          {tool === "episiotomy" && (
            <group ref={toolGroup} position={[0.9, 1.0, 0.6]}>
              {/* scissor blades */}
              {[0, 1].map((i) => (
                <mesh key={i} position={[i === 0 ? -0.15 : 0.15, 0.55, 0]} rotation={[0, 0, i === 0 ? 0.3 : -0.3]} castShadow>
                  <boxGeometry args={[0.12, 1.3, 0.05]} />
                  <meshStandardMaterial color="#cbd5e1" metalness={0.85} roughness={0.25} />
                </mesh>
              ))}
              <mesh position={[0, -0.35, 0]} castShadow>
                <torusGeometry args={[0.16, 0.05, 8, 16]} />
                <meshStandardMaterial color="#1e293b" roughness={0.5} />
              </mesh>
              {/* the cut line */}
              <mesh position={[-0.7, -0.4, -0.3]} rotation={[0, 0, 0.5]} castShadow>
                <boxGeometry args={[1.0, 0.09, 0.05]} />
                <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={0.9} />
              </mesh>
            </group>
          )}

          {tool === "hysterectomy" && (
            <mesh ref={uterus} position={[0, 2.2, 0]} scale={[1.0, 1.15, 0.85]} castShadow>
              <sphereGeometry args={[0.95, 28, 20]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
            </mesh>
          )}

          <Label text="Baby's head" position={[-1.9, 2.3, 0.1]} size={0.5} color="#fde68a" />
          {tool === "forceps" && <Label text="Forceps: cradle & pull gently" position={[0, 0.35, 1.2]} size={0.55} color="#cbd5e1" />}
          {tool === "vacuum" && <Label text="Vacuum: suction cup pulls" position={[0, 0.35, 1.2]} size={0.55} color="#7dd3fc" />}
          {tool === "episiotomy" && <Label text="✂ Small cut to widen outlet" position={[0.9, -0.15, 0.6]} size={0.55} color="#fca5a5" />}
          {tool === "hysterectomy" && <Label text="Uterus removed" position={[-2.2, 3.4, 0]} size={0.55} color="#f9a8d4" />}
        </group>
        <Animator group={group} toolGroup={toolGroup} babyHead={babyHead} uterus={uterus} elapsed={elapsed} speed={speed} tool={tool} />
      </SimCanvas>
    </div>
  );
}
