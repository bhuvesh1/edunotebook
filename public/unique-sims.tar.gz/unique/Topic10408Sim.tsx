"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "variant", label: "Variant", kind: "select", min: 0, max: 0, step: 1, default: "conventional", options: ["conventional", "unicystic", "peripheral"] },
  { key: "growth", label: "Tumour growth", kind: "slider", min: 0.4, max: 1.6, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Odontogenic tumors: ameloblastoma and variants",
  blurb: "Soap-bubble tumour expanding the jaw — multilocular chambers of a conventional ameloblastoma, unicystic or peripheral variant.",
};

const INFO: Record<string, { name: string; note: string; bubbles: number }> = {
  conventional: { name: "Conventional ameloblastoma", note: "Multilocular 'soap-bubble' — honeycomb chambers", bubbles: 9 },
  unicystic: { name: "Unicystic ameloblastoma", note: "Single cystic cavity around an unerupted tooth", bubbles: 1 },
  peripheral: { name: "Peripheral ameloblastoma", note: "Sits on the gum outside the bone — no expansion", bubbles: 4 },
};

function Scene({ variant, growth }: { variant: string; growth: number }) {
  const group = useRef<THREE.Group>(null!);
  const tumor = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const info = INFO[variant] ?? INFO.conventional;

  const bubbles = useMemo(() => {
    const arr: { p: [number, number, number]; r: number }[] = [];
    const n = info.bubbles;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      const rad = variant === "unicystic" ? 0 : 0.55 + (i % 3) * 0.18;
      arr.push({
        p: [Math.cos(a) * rad, Math.sin(a * 1.3) * 0.4, Math.sin(a) * rad * 0.7],
        r: variant === "unicystic" ? 1.1 : 0.38 + ((i * 37) % 10) / 28,
      });
    }
    return arr;
  }, [variant, info.bubbles]);

  useFrame((_, delta) => {
    t.current += delta;
    if (tumor.current) tumor.current.scale.setScalar(growth * (1 + Math.sin(t.current * 1.8) * 0.03));
    if (group.current) group.current.rotation.y = Math.sin(t.current * 0.3) * 0.45;
  });

  const onGum = variant === "peripheral";

  return (
    <group ref={group}>
      {/* mandible body — curved */}
      <mesh position={[0, -0.4, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[2.6, 0.85, 16, 40, Math.PI]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>
      {/* teeth stubs */}
      {[-1.6, -0.8, 0.8, 1.6].map((x, i) => (
        <mesh key={i} position={[x, 0.75, 1.55]} rotation={[0.15, 0, 0]}>
          <cylinderGeometry args={[0.22, 0.28, 0.6, 10]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.3} />
        </mesh>
      ))}
      <Label text="Mandible" position={[-3.4, -1.4, 0]} size={0.5} color="#fde68a" />

      {/* soap-bubble tumour */}
      <group ref={tumor} position={[0, onGum ? 1.15 : -0.15, 1.35]}>
        {bubbles.map((b, i) => (
          <mesh key={i} position={b.p}>
            <sphereGeometry args={[b.r, 18, 18]} />
            <meshStandardMaterial color="#c4b5fd" transparent opacity={0.55} roughness={0.25} />
          </mesh>
        ))}
        {bubbles.map((b, i) => (
          <mesh key={`w${i}`} position={b.p}>
            <sphereGeometry args={[b.r * 1.01, 12, 12]} />
            <meshStandardMaterial color="#8b5cf6" wireframe transparent opacity={0.4} />
          </mesh>
        ))}
      </group>
      <Label text={info.name} position={[0, 2.9, 1.2]} size={0.6} color="#c4b5fd" />
      <Label text={info.note} position={[0, -2.6, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10408Sim(props: SimProps) {
  const variant = String(props.variant ?? "conventional");
  const growth = Number(props.growth ?? 1);
  const info = INFO[variant] ?? INFO.conventional;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Variant", info.name], ["Behaviour", "Benign but locally aggressive"], ["Treatment", "Wide resection"]]} />
      <SimCanvas cameraPosition={[0, 2.5, 9.5]} target={[0, 0.2, 0.6]}>
        <Scene variant={variant} growth={growth} />
      </SimCanvas>
    </div>
  );
}
