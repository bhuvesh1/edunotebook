// app/components/sims/unique/Topic7106Sim.tsx
// Projectile motion: a cannon fires a ball in a perfect parabola. The
// dashed arc is the trajectory; the flag marks the range, the pole marks
// the maximum height. Range, height and time of flight update live.

"use client";

import { useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "velocity", label: "Launch velocity", kind: "slider", min: 5, max: 15, step: 0.5, default: 10, unit: "m/s" },
  { key: "angle", label: "Launch angle", kind: "slider", min: 10, max: 80, step: 1, default: 45, unit: "°" },
];

export const UNIQUE_META = {
  title: "Projectile Motion",
  blurb: "Cannon fire in a parabola — range flag, max-height pole, and the trajectory arc drawn live.",
};

const G = 9.8;
const X0 = -6;
const TN = 64;

function Animator({
  ball, trail, trailGeo, v0, theta, T, bump,
}: {
  ball: RefObject<THREE.Mesh>;
  trail: RefObject<THREE.Line>;
  trailGeo: THREE.BufferGeometry;
  v0: number; theta: number; T: number;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const cycle = T + 0.8;
    const ft = Math.min(t.current % cycle, T);
    const x = X0 + v0 * Math.cos(theta) * ft;
    const y = 0.35 + v0 * Math.sin(theta) * ft - 0.5 * G * ft * ft;
    if (ball.current) ball.current.position.set(x, Math.max(y, 0.35), 0);
    const pos = trailGeo.attributes.position as THREE.BufferAttribute;
    const k = Math.floor((ft / T) * TN);
    for (let i = 0; i < TN; i++) {
      const f = (i / (TN - 1)) * T;
      pos.setXYZ(i, X0 + v0 * Math.cos(theta) * f, 0.35 + v0 * Math.sin(theta) * f - 0.5 * G * f * f, 0);
    }
    pos.needsUpdate = true;
    if (trail.current) trail.current.geometry.setDrawRange(0, Math.max(k, 0));
    if (++n.current % 20 === 0) bump();
  });
  return null;
}

export function Topic7106Sim(props: SimProps) {
  const v0 = Number(props.velocity ?? 10);
  const angle = Number(props.angle ?? 45);
  const theta = (angle * Math.PI) / 180;
  const ball = useRef<THREE.Mesh>(null!);
  const trail = useRef<THREE.Line>(null!);
  const [, bump] = useState(0);

  const R = (v0 * v0 * Math.sin(2 * theta)) / G;
  const H = ((v0 * Math.sin(theta)) ** 2) / (2 * G);
  const T = (2 * v0 * Math.sin(theta)) / G;

  const trailGeo = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(TN * 3), 3));
    return geo;
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Range", `${R.toFixed(1)} m`],
          ["Max height", `${H.toFixed(1)} m`],
          ["Time of flight", `${T.toFixed(2)} s`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5, 15]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* cannon */}
        <group position={[X0, 0, 0]}>
          <mesh position={[0, 0.5, 0]} castShadow>
            <boxGeometry args={[1.6, 1, 1.4]} />
            <meshStandardMaterial color="#57534e" roughness={0.7} />
          </mesh>
          {[-0.6, 0.6].map((z) => (
            <mesh key={z} position={[0, 0.4, z]} rotation={[Math.PI / 2, 0, 0]} castShadow>
              <cylinderGeometry args={[0.4, 0.4, 0.25, 18]} />
              <meshStandardMaterial color="#292524" roughness={0.8} />
            </mesh>
          ))}
          <mesh position={[0.7, 1.25, 0]} rotation={[0, 0, theta - Math.PI / 2]} castShadow>
            <cylinderGeometry args={[0.28, 0.34, 2.2, 18]} />
            <meshStandardMaterial color="#44403c" roughness={0.5} metalness={0.5} />
          </mesh>
        </group>

        {/* trajectory arc */}
        <primitive object={new THREE.Line(trailGeo, new THREE.LineBasicMaterial({ color: "#fbbf24" }))} ref={trail} />

        {/* range flag */}
        <group position={[X0 + R, 0, 0]}>
          <mesh position={[0, 0.9, 0]}>
            <cylinderGeometry args={[0.05, 0.05, 1.8, 8]} />
            <meshStandardMaterial color="#94a3b8" roughness={0.6} />
          </mesh>
          <mesh position={[0.35, 1.5, 0]}>
            <boxGeometry args={[0.7, 0.45, 0.04]} />
            <meshStandardMaterial color="#22c55e" emissive="#15803d" emissiveIntensity={0.5} roughness={0.5} />
          </mesh>
        </group>
        {/* max-height pole */}
        <group position={[X0 + R / 2, 0, 0]}>
          <mesh position={[0, H / 2, 0]}>
            <cylinderGeometry args={[0.04, 0.04, H, 8]} />
            <meshStandardMaterial color="#f87171" transparent opacity={0.7} roughness={0.6} />
          </mesh>
          <mesh position={[0, H + 0.1, 0]}>
            <sphereGeometry args={[0.14, 12, 12]} />
            <meshStandardMaterial color="#f87171" emissive="#b91c1c" emissiveIntensity={0.7} />
          </mesh>
        </group>

        {/* the cannonball */}
        <mesh ref={ball} position={[X0, 0.35, 0]} castShadow>
          <sphereGeometry args={[0.32, 24, 24]} />
          <meshStandardMaterial color="#1f2937" roughness={0.35} metalness={0.5} />
        </mesh>

        <Animator ball={ball} trail={trail} trailGeo={trailGeo} v0={v0} theta={theta} T={T} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
