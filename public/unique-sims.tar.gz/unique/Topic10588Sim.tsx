// Topic10588 — Soft tissue lasers in periodontics and surgery.
// An inflamed gum pocket bleeds red around a tooth. The laser fibre
// sweeps the gumline, vaporising diseased tissue — the pocket shrinks
// and pink, healthy gum seals behind it.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "power", label: "Laser power", kind: "slider", min: 1, max: 10, step: 1, default: 5, unit: "W" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Soft tissue lasers in periodontics and surgery",
  blurb: "A laser fibre sterilises an infected gum pocket — diseased tissue vaporises, healthy gum seals.",
};

const POCKET_XS = [-2.4, -1.2, 0, 1.2, 2.4];

function Animator({
  fibre,
  pockets,
  vapor,
  elapsed,
  power,
  speed,
}: {
  fibre: RefObject<THREE.Group>;
  pockets: RefObject<THREE.Group>;
  vapor: RefObject<THREE.Group>;
  elapsed: RefObject<number>;
  power: number;
  speed: number;
}) {
  const healed = useMemo(() => new Float32Array(POCKET_XS.length).fill(0), []);
  const pink = useMemo(() => new THREE.Color("#f9a8d4"), []);
  const angry = useMemo(() => new THREE.Color("#b91c1c"), []);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const fx = Math.sin(t * 0.9) * 2.9;
    if (fibre.current) {
      fibre.current.position.x = fx;
      const tip = fibre.current.children[1] as THREE.Mesh;
      (tip.material as THREE.MeshStandardMaterial).emissiveIntensity = 1.2 + Math.sin(t * 14) * 0.6;
    }
    if (pockets.current) {
      pockets.current.children.forEach((mesh, i) => {
        const m = mesh as THREE.Mesh;
        const near = Math.abs(POCKET_XS[i] - fx) < 0.7;
        if (near) healed[i] = Math.min(1, healed[i] + delta * speed * power * 0.22);
        const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
        mat.color.copy(angry).lerp(pink, healed[i]);
        const s = 1 - healed[i] * 0.55;
        m.scale.set(s, s, s);
        mat.emissive.setHex(0x7f1d1d);
        mat.emissiveIntensity = (1 - healed[i]) * 0.5;
      });
    }
    if (vapor.current) {
      vapor.current.children.forEach((mm, i) => {
        const y = 2.6 + ((t * 2 + i * 0.45) % 1.6);
        mm.position.set(fx + Math.sin(t * 3 + i) * 0.25, y, Math.cos(t * 2 + i) * 0.2);
        mm.scale.setScalar(0.4 + (y - 2.6) * 0.5);
      });
    }
  });
  return null;
}

export function Topic10588Sim(props: SimProps) {
  const power = Number(props.power ?? 5);
  const speed = Number(props.speed ?? 1);
  const fibre = useRef<THREE.Group>(null!);
  const pockets = useRef<THREE.Group>(null!);
  const vapor = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Laser", `${power} W diode fibre`],
          ["Effect", "Sterilise + seal pocket"],
          ["Bleeding", "None — laser seals"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* three teeth in a row */}
        {[-1.8, 0, 1.8].map((x) => (
          <group key={x} position={[x, 2.5, 0]}>
            <mesh castShadow>
              <boxGeometry args={[1.15, 1.9, 0.7]} />
              <meshStandardMaterial color="#fefdf8" roughness={0.3} />
            </mesh>
            <mesh position={[0, -1.35, 0]}>
              <coneGeometry args={[0.36, 1.1, 12]} />
              <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
            </mesh>
          </group>
        ))}

        {/* gum with infected pockets between teeth */}
        <mesh position={[0, 1.9, 0]}>
          <boxGeometry args={[7.6, 1.1, 1.5]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.65} />
        </mesh>
        <group ref={pockets}>
          {POCKET_XS.map((x) => (
            <mesh key={x} position={[x, 2.45, 0.55]} castShadow>
              <sphereGeometry args={[0.42, 14, 14]} />
              <meshStandardMaterial color="#b91c1c" roughness={0.5} />
            </mesh>
          ))}
        </group>

        {/* laser fibre tip sweeping the gumline */}
        <group ref={fibre} position={[0, 3.1, 1.2]}>
          <mesh castShadow rotation={[Math.PI / 3.2, 0, 0]}>
            <cylinderGeometry args={[0.07, 0.07, 1.8, 10]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.3} metalness={0.6} />
          </mesh>
          <mesh position={[0, -0.75, 0.42]}>
            <sphereGeometry args={[0.14, 12, 12]} />
            <meshStandardMaterial color="#f87171" emissive="#ef4444" emissiveIntensity={1.5} />
          </mesh>
        </group>

        {/* vapor wisps at the treatment point */}
        <group ref={vapor}>
          {Array.from({ length: 7 }).map((_, i) => (
            <mesh key={i} position={[0, 2.6, 0.6]}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshStandardMaterial color="#fecaca" transparent opacity={0.55} roughness={1} />
            </mesh>
          ))}
        </group>

        <Label text="INFECTED POCKETS — red, swollen" position={[0, 4.6, 0]} size={0.4} color="#fca5a5" />
        <Label text="LASER FIBRE — vaporises disease, seals gum" position={[0, 0.5, 0]} size={0.38} color="#fde68a" />
        <Label text="Healthy pink gum seals behind the beam" position={[0, -0.3, 0]} size={0.34} color="#86efac" />

        <Animator fibre={fibre} pockets={pockets} vapor={vapor} elapsed={elapsed} power={power} speed={speed} />
      </SimCanvas>
    </div>
  );
}
