// Viral skin infections: warts, herpes, molluscum.
// Viruses reshape the skin: rough cauliflower warts, clusters of herpes
// blisters that tingle and burst, and pearly molluscum bumps with a dimple.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "infection", label: "Infection", kind: "select", min: 0, max: 0, step: 1, default: "warts", options: ["warts", "herpes", "molluscum"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Viral Skin: Warts, Herpes, Molluscum",
  blurb: "Cauliflower warts, bursting herpes blisters, and dimpled molluscum pearls — viruses written on the skin.",
};

function Animator({
  group, blisters, elapsed, speed, infection,
}: {
  group: React.RefObject<THREE.Group>;
  blisters: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  infection: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.15;
    // herpes: blisters swell, burst, and reform in waves
    if (blisters.current && infection === "herpes") {
      const cyc = (t % 8) / 8;
      blisters.current.children.forEach((b, i) => {
        const local = (cyc + i * 0.06) % 1;
        const s = local < 0.4 ? 0.5 + local * 1.4 : local < 0.55 ? 1.06 - (local - 0.4) * 4 : 0.45;
        (b as THREE.Mesh).scale.setScalar(Math.max(0.4, s));
      });
    }
  });
  return null;
}

export function Topic10321Sim(props: SimProps) {
  const infection = String(props.infection ?? "warts");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const blisters = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    warts: "Warts (HPV)", herpes: "Herpes blisters", molluscum: "Molluscum contagiosum",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Infection", names[infection] ?? infection], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10]} target={[0, 1.7, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* skin patch */}
          <mesh position={[0, 1.0, 0]} castShadow receiveShadow>
            <boxGeometry args={[7, 1.4, 4]} />
            <meshStandardMaterial color="#f5c396" roughness={0.7} />
          </mesh>

          {infection === "warts" && (
            <>
              {/* rough cauliflower warts */}
              {[[-1.8, 0.4], [-0.2, -0.5], [1.6, 0.5]].map(([x, z], i) => (
                <mesh key={i} position={[x, 1.95, z]} castShadow>
                  <icosahedronGeometry args={[0.5 - i * 0.08, 1]} />
                  <meshStandardMaterial color="#d4a574" roughness={1} flatShading emissive="#78350f" emissiveIntensity={0.25} />
                </mesh>
              ))}
              {/* black dots: thrombosed capillaries */}
              {[[-1.7, 0.5], [-0.1, -0.4]].map(([x, z], i) => (
                <mesh key={i} position={[x, 2.35, z]}>
                  <sphereGeometry args={[0.06, 8, 6]} />
                  <meshBasicMaterial color="#1c1917" />
                </mesh>
              ))}
              <Label text="Rough, cauliflower surface" position={[0, 0.1, 0]} size={0.55} color="#e7c08a" />
              <Label text="Black dots = tiny clotted vessels" position={[-1.8, 2.9, 0.4]} size={0.45} color="#a8a29e" />
            </>
          )}

          {infection === "herpes" && (
            <>
              {/* red base */}
              <mesh position={[0, 1.78, 0]} scale={[1.6, 0.3, 1.1]} castShadow>
                <sphereGeometry args={[0.9, 18, 12]} />
                <meshStandardMaterial color="#ef4444" roughness={0.5} transparent opacity={0.6} emissive="#7f1d1d" emissiveIntensity={0.4} />
              </mesh>
              {/* cluster of clear blisters */}
              <group ref={blisters} position={[0, 2.0, 0]}>
                {Array.from({ length: 9 }).map((_, i) => {
                  const a = (i / 9) * Math.PI * 2;
                  return (
                    <mesh key={i} position={[Math.cos(a) * 0.7, 0.15 + (i % 3) * 0.12, Math.sin(a) * 0.5]} castShadow>
                      <sphereGeometry args={[0.22, 14, 10]} />
                      <meshStandardMaterial color="#fef3c7" roughness={0.15} transparent opacity={0.85} emissive="#f59e0b" emissiveIntensity={0.3} />
                    </mesh>
                  );
                })}
              </group>
              <Label text="⚠ Painful blister cluster" position={[0, 0.1, 0]} size={0.6} color="#fca5a5" />
              <Label text="Tingles → blisters → crusts" position={[2.6, 2.6, 0]} size={0.5} color="#fde68a" />
            </>
          )}

          {infection === "molluscum" && (
            <>
              {/* pearly dome bumps with central dimple */}
              {[[-1.6, 0.3], [0, -0.4], [1.5, 0.4], [0.7, 0.9]].map(([x, z], i) => (
                <group key={i} position={[x, 1.85, z]}>
                  <mesh castShadow>
                    <sphereGeometry args={[0.35, 18, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
                    <meshStandardMaterial color="#fde68a" roughness={0.3} emissive="#b45309" emissiveIntensity={0.25} />
                  </mesh>
                  <mesh position={[0, 0.32, 0]}>
                    <sphereGeometry args={[0.09, 10, 8]} />
                    <meshBasicMaterial color="#92400e" />
                  </mesh>
                </group>
              ))}
              <Label text="Pearly bumps with a dimple" position={[0, 0.1, 0]} size={0.55} color="#fde68a" />
            </>
          )}
          <Label text="🦠 Virus in the skin" position={[-2.8, 2.8, 0]} size={0.5} color="#fde047" />
        </group>
        <Animator group={group} blisters={blisters} elapsed={elapsed} speed={speed} infection={infection} />
      </SimCanvas>
    </div>
  );
}
