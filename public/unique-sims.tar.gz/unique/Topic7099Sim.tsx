// app/components/sims/unique/Topic7099Sim.tsx
// Vector addition (triangle/parallelogram law): red vector A and blue
// vector B join tip-to-tail; the green resultant R closes the triangle.
// Drag the angle slider and watch R shrink and grow.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "angle", label: "Angle between A and B", kind: "slider", min: 0, max: 180, step: 5, default: 60, unit: "°" },
];

export const UNIQUE_META = {
  title: "Addition of Vectors",
  blurb: "A + B tip-to-tail: the green resultant is the vector sum. Change the angle, change the sum.",
};

const A_LEN = 3;
const B_LEN = 2.2;

/** Arrow built along +Y, rotated about Z so it points along angle phi (from +x). */
function VecArrow({
  g, len, color, phi, from,
}: {
  g?: RefObject<THREE.Group>;
  len: number;
  color: string;
  phi: number;
  from?: [number, number, number];
}) {
  return (
    <group ref={g} position={from ?? [0, 0, 0]} rotation={[0, 0, phi - Math.PI / 2]}>
      <mesh position={[0, len / 2, 0]}>
        <cylinderGeometry args={[0.09, 0.09, len, 12]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.45} roughness={0.4} />
      </mesh>
      <mesh position={[0, len + 0.2, 0]}>
        <coneGeometry args={[0.24, 0.45, 14]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.45} roughness={0.4} />
      </mesh>
    </group>
  );
}

function Pulser({ g }: { g: RefObject<THREE.Group> }) {
  const t = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    if (g.current) {
      const s = 1 + 0.03 * Math.sin(t.current * 3);
      g.current.scale.set(s, s, s);
    }
  });
  return null;
}

export function Topic7099Sim(props: SimProps) {
  const angle = Number(props.angle ?? 60);
  const theta = (angle * Math.PI) / 180;
  const res = useRef<THREE.Group>(null!);

  // Resultant geometry from the law of cosines.
  const R = Math.sqrt(A_LEN * A_LEN + B_LEN * B_LEN + 2 * A_LEN * B_LEN * Math.cos(theta));
  const tipX = A_LEN + B_LEN * Math.cos(theta);
  const tipY = B_LEN * Math.sin(theta);
  const phiR = Math.atan2(tipY, tipX);

  const ghost = useMemo(() => {
    // Parallelogram completion lines: B shifted to A's tip, A shifted to B's tip.
    const pts = [
      new THREE.Vector3(A_LEN, 0, 0), new THREE.Vector3(tipX, tipY, 0),
      new THREE.Vector3(B_LEN * Math.cos(theta), B_LEN * Math.sin(theta), 0), new THREE.Vector3(tipX, tipY, 0),
    ];
    return new THREE.LineSegments(
      new THREE.BufferGeometry().setFromPoints(pts),
      new THREE.LineBasicMaterial({ color: "#94a3b8", transparent: true, opacity: 0.6 })
    );
  }, [theta, tipX, tipY]);

  // Center the construction in view.
  const cx = -tipX / 2;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["|A|", `${A_LEN.toFixed(1)}`],
          ["|B|", `${B_LEN.toFixed(1)}`],
          ["|R| = |A + B|", `${R.toFixed(2)}`],
          ["🟢 R", "resultant vector"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* origin marker */}
        <mesh position={[cx, 1.5, 0]}>
          <sphereGeometry args={[0.12, 14, 14]} />
          <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
        </mesh>

        <group position={[cx, 1.5, 0]}>
          <VecArrow len={A_LEN} color="#ef4444" phi={0} />
          <VecArrow len={B_LEN} color="#3b82f6" phi={theta} />
          {/* B translated to tip of A (tip-to-tail) */}
          <VecArrow len={B_LEN} color="#3b82f6" phi={theta} from={[A_LEN, 0, 0]} />
          <primitive object={ghost} />
          {/* resultant */}
          <group ref={res}>
            <VecArrow len={R} color="#22c55e" phi={phiR} />
          </group>
        </group>
        <Pulser g={res} />
      </SimCanvas>
    </div>
  );
}
