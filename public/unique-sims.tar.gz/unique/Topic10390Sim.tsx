"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cement", label: "Cement", kind: "select", min: 0, max: 0, step: 1, default: "gic", options: ["zoe", "zinc-phosphate", "gic"] },
  { key: "mix", label: "Mix + set", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.55, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Dental cements: ZOE, zinc phosphate, glass ionomer",
  blurb: "Mix powder and liquid on a slab — watch the paste thicken, then get packed under a crown where it locks everything in place.",
};

const CEMENTS: Record<string, { name: string; powder: string; liquid: string; set: string; perk: string }> = {
  zoe: { name: "Zinc oxide eugenol", powder: "#fefce8", liquid: "#d6a35c", set: "chelate set · soothing", perk: "palliative, sedative to pulp" },
  "zinc-phosphate": { name: "Zinc phosphate", powder: "#e7e5e4", liquid: "#bae6fd", set: "acid–base · exothermic", perk: "classic crown cement" },
  gic: { name: "Glass ionomer", powder: "#fef9c3", liquid: "#fde68a", set: "releases fluoride ✓", perk: "bonds chemically + fights decay" },
};

function CementScene({ cement, mix, speed, showLabels }: { cement: string; mix: number; speed: number; showLabels: boolean }) {
  const paste = useRef<THREE.Mesh>(null!);
  const crown = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const cfg = CEMENTS[cement] ?? CEMENTS.gic;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (paste.current) {
      // paste thickens: from glossy puddle to matte mound
      const m = paste.current.material as THREE.MeshStandardMaterial;
      m.roughness = THREE.MathUtils.lerp(0.1, 0.8, mix);
      const s = 1 + Math.sin(elapsed.current * 1.5) * 0.02 * (1 - mix);
      paste.current.scale.set(s, 1 + mix * 0.5, s);
    }
    if (crown.current) {
      crown.current.position.y = THREE.MathUtils.lerp(4.6, 1.35, Math.min(1, mix * 1.15));
    }
  });

  return (
    <group>
      {/* glass mixing slab */}
      <mesh position={[-3.6, -1.4, 0]} receiveShadow>
        <boxGeometry args={[4.6, 0.35, 3.4]} />
        <meshPhysicalMaterial color="#e0f2fe" transparent opacity={0.55} roughness={0.1} />
      </mesh>
      {/* powder mound */}
      <mesh position={[-4.4, -1.05, -0.5]} castShadow>
        <coneGeometry args={[0.7, 0.6, 18]} />
        <meshStandardMaterial color={cfg.powder} roughness={0.9} />
      </mesh>
      {/* liquid drops */}
      {[-3.4, -3.0].map((x, i) => (
        <mesh key={i} position={[x, -1.0, 0.7]} castShadow>
          <sphereGeometry args={[0.2, 12, 10]} />
          <meshStandardMaterial color={cfg.liquid} roughness={0.15} />
        </mesh>
      ))}
      {/* spatula folding the mix */}
      <Spatula mix={mix} speed={speed} />
      {/* the mixed paste */}
      <mesh ref={paste} position={[-3.2, -1.05, -0.2]} castShadow>
        <sphereGeometry args={[0.85, 20, 14]} />
        <meshStandardMaterial color={cfg.powder} roughness={0.1} />
      </mesh>

      {/* tooth stump receiving the crown */}
      <group position={[3.4, 0, 0]}>
        <mesh position={[0, -0.4, 0]} castShadow>
          <cylinderGeometry args={[0.95, 1.05, 1.8, 18]} />
          <meshStandardMaterial color="#fde68a" roughness={0.4} />
        </mesh>
        {/* cement film under crown */}
        <mesh position={[0, 0.62, 0]}>
          <cylinderGeometry args={[1.02, 1.02, 0.22, 18]} />
          <meshStandardMaterial color={cfg.powder} roughness={0.7} transparent opacity={0.9} />
        </mesh>
        {/* crown descending */}
        <group ref={crown} position={[0, 4.6, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[1.12, 1.25, 1.5, 20, 1, true]} />
            <meshStandardMaterial color="#fef9c3" roughness={0.25} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[0, 0.75, 0]} castShadow>
            <sphereGeometry args={[1.12, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <meshStandardMaterial color="#fef9c3" roughness={0.25} />
          </mesh>
        </group>
      </group>

      {showLabels && (
        <>
          <Text position={[-3.6, 1.6, 0]} fontSize={0.42} color="#fef3c7">{cfg.name}</Text>
          <Text position={[-3.6, -3.2, 0]} fontSize={0.4} color="#e2e8f0" maxWidth={6}>
            {mix < 0.4 ? "Spatulate: fold powder into liquid" : mix < 0.8 ? "Working time — load the crown now" : "Set! " + cfg.set}
          </Text>
          <Text position={[3.4, 4.6, 0]} fontSize={0.4} color="#fde68a" maxWidth={5}>{cfg.perk}</Text>
        </>
      )}
    </group>
  );
}

function Spatula({ mix, speed }: { mix: number; speed: number }) {
  const s = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (s.current && mix < 0.85) {
      s.current.rotation.y = Math.sin(elapsed.current * 4) * 0.5;
      s.current.position.x = -3.2 + Math.sin(elapsed.current * 4) * 0.5;
    }
  });
  return (
    <group ref={s} position={[-3.2, -0.2, -0.2]} rotation={[0.4, 0, 0.3]}>
      <mesh castShadow>
        <cylinderGeometry args={[0.09, 0.09, 2.4, 8]} />
        <meshStandardMaterial color="#94a3b8" metalness={0.7} roughness={0.35} />
      </mesh>
      <mesh position={[0, -1.35, 0]}>
        <boxGeometry args={[0.55, 0.5, 0.1]} />
        <meshStandardMaterial color="#cbd5e1" metalness={0.7} roughness={0.3} />
      </mesh>
    </group>
  );
}

export function Topic10390Sim(props: SimProps) {
  const cement = String(props.cement ?? "gic");
  const mix = Number(props.mix ?? 0.55);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = CEMENTS[cement] ?? CEMENTS.gic;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Cement", cfg.name],
          ["Stage", mix < 0.4 ? "mixing" : mix < 0.8 ? "working time" : "set ✓"],
          ["Superpower", cfg.perk],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 13]} target={[0, 0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.6, 0]} receiveShadow>
          <planeGeometry args={[36, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <CementScene cement={cement} mix={mix} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
