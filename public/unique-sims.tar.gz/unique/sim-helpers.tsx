// Shared helpers for unique topic sims: 3D arrows, canvas text labels,
// coil springs, and a simple stylized person. No external assets.
"use client";

import { useMemo } from "react";
import * as THREE from "three";

/** 3D arrow from `from` to `to`. To animate length, wrap in a group with scale.y = k. */
export function Arrow({
  from,
  to,
  color = "#fbbf24",
  r = 0.05,
}: {
  from: [number, number, number];
  to: [number, number, number];
  color?: string;
  r?: number;
}) {
  const { quat, len } = useMemo(() => {
    const a = new THREE.Vector3(from[0], from[1], from[2]);
    const b = new THREE.Vector3(to[0], to[1], to[2]);
    const d = b.sub(a);
    const len = Math.max(d.length(), 0.001);
    const quat = new THREE.Quaternion().setFromUnitVectors(
      new THREE.Vector3(0, 1, 0),
      d.clone().normalize()
    );
    return { quat, len };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [from[0], from[1], from[2], to[0], to[1], to[2]]);
  const head = Math.min(0.3, len * 0.45);
  const shaft = Math.max(0.02, len - head);
  return (
    <group position={from} quaternion={quat}>
      <mesh position={[0, shaft / 2, 0]}>
        <cylinderGeometry args={[r, r, shaft, 10]} />
        <meshStandardMaterial color={color} roughness={0.45} />
      </mesh>
      <mesh position={[0, shaft + head / 2, 0]}>
        <coneGeometry args={[r * 2.8, head, 12]} />
        <meshStandardMaterial color={color} roughness={0.45} />
      </mesh>
    </group>
  );
}

/** Floating text label drawn on a canvas sprite (always faces camera). */
export function Label({
  text,
  position,
  size = 0.34,
  color = "#f8fafc",
}: {
  text: string;
  position: [number, number, number];
  size?: number;
  color?: string;
}) {
  const { tex, aspect } = useMemo(() => {
    const c = document.createElement("canvas");
    const meas = c.getContext("2d")!;
    const font = "700 54px system-ui, -apple-system, sans-serif";
    meas.font = font;
    const w = Math.ceil(meas.measureText(text).width) + 56;
    c.width = w;
    c.height = 96;
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "rgba(8,13,28,0.82)";
    ctx.beginPath();
    ctx.roundRect(2, 2, w - 4, 92, 22);
    ctx.fill();
    ctx.strokeStyle = "rgba(148,163,184,0.55)";
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.font = font;
    ctx.fillStyle = color;
    ctx.textBaseline = "middle";
    ctx.fillText(text, 28, 52);
    const tex = new THREE.CanvasTexture(c);
    tex.anisotropy = 4;
    return { tex, aspect: w / 96 };
  }, [text, color]);
  return (
    <sprite position={position} scale={[size * aspect, size, 1]} renderOrder={10}>
      <spriteMaterial map={tex} transparent depthTest={false} />
    </sprite>
  );
}

/** Coil spring stretched along +X from x=0 to x=length. */
export function Spring({
  length,
  coils = 9,
  radius = 0.3,
  tube = 0.05,
  color = "#94a3b8",
}: {
  length: number;
  coils?: number;
  radius?: number;
  tube?: number;
  color?: string;
}) {
  const geo = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    const n = Math.max(24, coils * 20);
    for (let i = 0; i <= n; i++) {
      const t = i / n;
      const a = t * coils * Math.PI * 2;
      pts.push(
        new THREE.Vector3(t * length, Math.cos(a) * radius, Math.sin(a) * radius)
      );
    }
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), n, tube, 8, false);
  }, [length, coils, radius, tube]);
  return (
    <mesh geometry={geo} castShadow>
      <meshStandardMaterial color={color} roughness={0.35} metalness={0.7} />
    </mesh>
  );
}

/** Simple stylized person: capsule body + sphere head. h = total height. */
export function Person({
  position,
  color = "#38bdf8",
  h = 1.1,
  rotation = [0, 0, 0],
}: {
  position: [number, number, number];
  color?: string;
  h?: number;
  rotation?: [number, number, number];
}) {
  return (
    <group position={position} rotation={rotation}>
      <mesh position={[0, h * 0.3, 0]} castShadow>
        <capsuleGeometry args={[h * 0.16, h * 0.34, 6, 12]} />
        <meshStandardMaterial color={color} roughness={0.6} />
      </mesh>
      <mesh position={[0, h * 0.74, 0]} castShadow>
        <sphereGeometry args={[h * 0.15, 20, 20]} />
        <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
      </mesh>
    </group>
  );
}

/** Flat circular orbit ring (line loop) of given radius in the XZ plane. */
export function OrbitRing({
  radius,
  color = "#64748b",
  opacity = 0.6,
  y = 0,
}: {
  radius: number;
  color?: string;
  opacity?: number;
  y?: number;
}) {
  const geo = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 128; i++) {
      const a = (i / 128) * Math.PI * 2;
      pts.push(new THREE.Vector3(Math.cos(a) * radius, y, Math.sin(a) * radius));
    }
    return new THREE.BufferGeometry().setFromPoints(pts);
  }, [radius, y]);
  return (
    <primitive
      object={
        new THREE.Line(
          geo,
          new THREE.LineBasicMaterial({ color, transparent: true, opacity })
        )
      }
    />
  );
}
