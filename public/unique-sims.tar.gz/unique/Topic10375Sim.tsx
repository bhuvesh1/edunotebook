"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dtype", label: "Dentin type", kind: "select", min: 0, max: 0, step: 1, default: "primary", options: ["primary", "secondary", "tertiary"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Dentin: structure, types, dentinogenesis",
  blurb: "Cut through dentin to see thousands of tiny tubules radiating from the pulp — then watch secondary and reparative dentin wall the pulp in.",
};

const INFO: Record<string, { name: string; color: string; note: string }> = {
  primary: { name: "Primary dentin", color: "#fde68a", note: "forms the bulk of the tooth before eruption" },
  secondary: { name: "Secondary dentin", color: "#fbbf24", note: "slow lifelong layer — pulp chamber shrinks with age" },
  tertiary: { name: "Tertiary (reparative) dentin", color: "#f97316", note: "emergency wall built under decay or wear" },
};

function DentinBlock({ dtype, speed, showLabels }: { dtype: string; speed: number; showLabels: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const fluid = useRef<THREE.Points>(null!);
  const elapsed = useRef(0);
  const cfg = INFO[dtype] ?? INFO.primary;

  const tubules = useMemo(() => {
    const arr: { pos: [number, number, number]; dir: [number, number, number]; len: number }[] = [];
    for (let i = 0; i < 90; i++) {
      const a = (i / 90) * Math.PI * 2;
      const r = 1.1 + Math.random() * 0.9;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      arr.push({ pos: [x, (Math.random() - 0.5) * 3.4, z], dir: [x, 0, z], len: 1.6 + Math.random() * 0.8 });
    }
    return arr;
  }, []);

  const fluidPts = useMemo(() => {
    const arr = new Float32Array(60 * 3);
    for (let i = 0; i < 60; i++) {
      const t = tubules[i % tubules.length];
      arr[i * 3] = t.pos[0]; arr[i * 3 + 1] = t.pos[1]; arr[i * 3 + 2] = t.pos[2];
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(arr, 3));
    return geo;
  }, [tubules]);

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) g.current.rotation.y = elapsed.current * 0.3;
    if (fluid.current) {
      const p = fluid.current.geometry.attributes.position;
      for (let i = 0; i < p.count; i++) {
        // fluid shuttles along the tubule (sensitivity!)
        const t = tubules[i % tubules.length];
        const w = Math.sin(elapsed.current * 3 + i) * 0.35;
        const n = new THREE.Vector3(...t.dir).normalize();
        p.setXYZ(i, t.pos[0] + n.x * w, t.pos[1], t.pos[2] + n.z * w);
      }
      p.needsUpdate = true;
    }
  });

  return (
    <group>
      <group ref={g}>
        {/* dentin block, quarter cut away to reveal tubules */}
        <mesh castShadow>
          <cylinderGeometry args={[2.2, 2.2, 3.6, 32, 1, false, 0, Math.PI * 1.5]} />
          <meshStandardMaterial color={cfg.color} roughness={0.5} side={THREE.DoubleSide} />
        </mesh>
        {/* pulp core */}
        <mesh position={[0, 0, 0]}>
          <cylinderGeometry args={[0.55, 0.55, 3.7, 18]} />
          <meshStandardMaterial color="#ef4444" roughness={0.4} emissive="#7f1d1d" emissiveIntensity={0.5} />
        </mesh>
        {/* tubules radiating outward */}
        {tubules.map((t, i) => {
          const dir = new THREE.Vector3(...t.dir).normalize();
          const mid: [number, number, number] = [t.pos[0] + dir.x * t.len / 2, t.pos[1], t.pos[2] + dir.z * t.len / 2];
          const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
          return (
            <mesh key={i} position={mid} quaternion={quat}>
              <cylinderGeometry args={[0.035, 0.035, t.len, 6]} />
              <meshBasicMaterial color="#92400e" transparent opacity={0.75} />
            </mesh>
          );
        })}
        {/* odontoblast layer at pulp border */}
        <mesh>
          <cylinderGeometry args={[0.62, 0.62, 3.7, 18, 1, true]} />
          <meshBasicMaterial color="#fbbf24" transparent opacity={0.35} side={THREE.DoubleSide} />
        </mesh>
        <points ref={fluid} geometry={fluidPts}>
          <pointsMaterial color="#7dd3fc" size={0.1} transparent opacity={0.9} />
        </points>
      </group>
      {showLabels && (
        <>
          <Text position={[0, 3.4, 0]} fontSize={0.44} color="#fde68a">{cfg.name}</Text>
          <Text position={[0, -3.3, 0]} fontSize={0.4} color="#e2e8f0" maxWidth={10}>{cfg.note}</Text>
          <Text position={[3.9, 0.6, 0]} fontSize={0.38} color="#fca5a5">Pulp</Text>
          <Text position={[3.9, -0.6, 0]} fontSize={0.38} color="#7dd3fc">Tubule fluid moves → sensitivity</Text>
        </>
      )}
    </group>
  );
}

export function Topic10375Sim(props: SimProps) {
  const dtype = String(props.dtype ?? "primary");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = INFO[dtype] ?? INFO.primary;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Dentin", cfg.name],
          ["Tubules", "~30,000 / mm²"],
          ["Made by", "odontoblasts"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 11]} target={[0, 0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.6, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <DentinBlock dtype={dtype} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
