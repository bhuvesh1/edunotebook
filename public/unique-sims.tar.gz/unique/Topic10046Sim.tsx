// GI: digestion, absorption & motility — a peristaltic wave squeezes a food
// bolus along the small intestine while villi absorb glowing nutrient dots,
// and the liver processes them.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "peri", label: "Peristalsis speed", kind: "slider", min: 0.2, max: 2.5, step: 0.1, default: 1, unit: "×" },
  { key: "meal", label: "Meal size", kind: "slider", min: 0.3, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "GI: Peristalsis & Absorption",
  blurb: "A peristaltic wave pushes the bolus along the intestine while villi absorb nutrients into the blood.",
};

function Animator({
  squeeze, bolus, nutrients, elapsed, peri, speed,
}: {
  squeeze: React.RefObject<THREE.Group>;
  bolus: React.RefObject<THREE.Group>;
  nutrients: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  peri: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // bolus travels the S-shaped intestine
    if (bolus.current) {
      bolus.current.children.forEach((m, i) => {
        const ph = ((t * 0.09 * peri + i / 30) % 1 + 1) % 1;
        const path = m.userData.path as THREE.Vector3[];
        const idx = Math.min(path.length - 2, Math.floor(ph * (path.length - 1)));
        const f = ph * (path.length - 1) - idx;
        m.position.lerpVectors(path[idx], path[idx + 1], f);
      });
    }
    // peristaltic squeeze rings chase the bolus
    if (squeeze.current) {
      squeeze.current.children.forEach((m, i) => {
        const path = m.userData.path as THREE.Vector3[];
        const lead = 0.04;
        const ph = ((t * 0.09 * peri + lead + i * 0.012) % 1 + 1) % 1;
        const idx = Math.min(path.length - 2, Math.floor(ph * (path.length - 1)));
        const f = ph * (path.length - 1) - idx;
        m.position.lerpVectors(path[idx], path[idx + 1], f);
        const s = 1 + 0.35 * Math.sin(ph * Math.PI * 8);
        m.scale.set(s, s, 1);
      });
    }
    // nutrients absorbed: rise from villi into capillary
    if (nutrients.current) {
      nutrients.current.children.forEach((m, i) => {
        const ph = ((t * 0.4 * peri + i / 14) % 1 + 1) % 1;
        m.position.y = 1.2 + ph * 1.3;
        const mat = (m as THREE.Mesh).material as THREE.MeshBasicMaterial;
        mat.opacity = 1 - ph * 0.7;
      });
    }
  });
  return null;
}

export function Topic10046Sim(props: SimProps) {
  const peri = Number(props.peri ?? 1);
  const meal = Number(props.meal ?? 1);
  const speed = 1;
  const squeeze = useRef<THREE.Group>(null!);
  const bolus = useRef<THREE.Group>(null!);
  const nutrients = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const gutPath = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 60; i++) {
      const f = i / 60;
      pts.push(new THREE.Vector3(-7 + f * 14, 2.6 + Math.sin(f * Math.PI * 5) * 1.1, 0));
    }
    return pts;
  }, []);
  const gutTube = useMemo(
    () =>
      new THREE.Mesh(
        new THREE.TubeGeometry(new THREE.CatmullRomCurve3(gutPath), 120, 0.5, 12, false),
        new THREE.MeshStandardMaterial({ color: "#fda4af", roughness: 0.5 })
      ),
    [gutPath]
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Motility", "peristaltic wave → aboral"],
          ["Absorption", "villi → portal blood → liver"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* small intestine */}
        <primitive object={gutTube} />
        {/* peristaltic squeeze rings */}
        <group ref={squeeze}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={gutPath[0]} rotation={[0, Math.PI / 2, 0]}
              ref={(m) => { if (m) m.userData.path = gutPath; }}>
              <torusGeometry args={[0.52, 0.12, 8, 18]} />
              <meshStandardMaterial color="#f43f5e" emissive="#7f1d1d" emissiveIntensity={0.5} roughness={0.4} />
            </mesh>
          ))}
        </group>
        {/* food bolus chunks */}
        <group ref={bolus}>
          {Array.from({ length: 9 }).map((_, i) => (
            <mesh key={i} position={gutPath[0]} scale={meal}
              ref={(m) => { if (m) m.userData.path = gutPath; }} castShadow>
              <dodecahedronGeometry args={[0.22]} />
              <meshStandardMaterial color="#d97706" roughness={0.6} />
            </mesh>
          ))}
        </group>
        <Label text="small intestine" position={[-7.8, 4.4, 0]} size={0.4} color="#f8fafc" />
        <Label text="peristaltic wave squeezes →" position={[0, 4.6, 0]} size={0.32} color="#fca5a5" />

        {/* villi close-up with absorption */}
        <group position={[-1.5, 0, 0]}>
          <mesh position={[0, 0.5, 0]} castShadow>
            <boxGeometry args={[5.4, 0.9, 1.8]} />
            <meshStandardMaterial color="#fb7185" roughness={0.55} />
          </mesh>
          {[-2, -1, 0, 1, 2].map((x, i) => (
            <group key={i} position={[x, 1.4, 0]}>
              <mesh castShadow>
                <coneGeometry args={[0.28, 1.3, 10]} />
                <meshStandardMaterial color="#fda4af" roughness={0.5} />
              </mesh>
              <mesh position={[0, -0.25, 0]}>
                <torusGeometry args={[0.12, 0.045, 8, 12]} />
                <meshStandardMaterial color="#dc2626" />
              </mesh>
            </group>
          ))}
        </group>
        <group ref={nutrients}>
          {Array.from({ length: 14 }).map((_, i) => (
            <mesh key={i} position={[-1.5 + ((i * 1.7) % 5 - 2), 1.2, ((i * 0.9) % 2 - 1) * 0.5]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshBasicMaterial color="#4ade80" transparent opacity={0.8} />
            </mesh>
          ))}
        </group>
        <Label text="villi absorb nutrients → blood" position={[-1.5, 3.1, 0]} size={0.34} color="#86efac" />

        {/* liver processing */}
        <group position={[6.4, 3.4, 0]}>
          <mesh castShadow scale={[1.35, 0.85, 0.9]}>
            <sphereGeometry args={[1.1, 18, 18]} />
            <meshStandardMaterial color="#7c2d12" roughness={0.55} />
          </mesh>
          {/* portal vein in */}
          <mesh position={[-1.9, -0.3, 0]} rotation={[0, 0, 1.1]} castShadow>
            <cylinderGeometry args={[0.16, 0.16, 1.8, 10]} />
            <meshStandardMaterial color="#3b82f6" roughness={0.4} />
          </mesh>
        </group>
        <Label text="liver — first-pass metabolism" position={[6.4, 5.0, 0]} size={0.34} color="#f8fafc" />
        <Label text="portal vein (nutrient-rich)" position={[4.0, 2.4, 0]} size={0.28} color="#93c5fd" />

        <Animator squeeze={squeeze} bolus={bolus} nutrients={nutrients}
          elapsed={elapsed} peri={peri} speed={speed} />
      </SimCanvas>
    </div>
  );
}
