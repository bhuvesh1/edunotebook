"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "wax", label: "Wax type", kind: "select", min: 0, max: 0, step: 1, default: "inlay", options: ["inlay", "baseplate", "boxing"] },
  { key: "heat", label: "Heat", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.4, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Waxes: inlay, baseplate, boxing waxes",
  blurb: "Dental waxes soften with heat — warm the inlay wax stick and watch it droop, then carve a crown pattern from it.",
};

const WAXES: Record<string, { name: string; color: string; use: string; melt: string }> = {
  inlay: { name: "Inlay wax", color: "#22c55e", use: "carve crown patterns for casting", melt: "~60 °C" },
  baseplate: { name: "Baseplate wax", color: "#f472b6", use: "denture trial bases, bite rims", melt: "~45 °C" },
  boxing: { name: "Boxing wax", color: "#facc15", use: "box impressions before pouring", melt: "~55 °C" },
};

function WaxScene({ wax, heat, speed, showLabels }: { wax: string; heat: number; speed: number; showLabels: boolean }) {
  const stick = useRef<THREE.Group>(null!);
  const drip = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const cfg = WAXES[wax] ?? WAXES.inlay;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (stick.current) {
      // droop under heat
      stick.current.rotation.z = heat * 0.55 + Math.sin(elapsed.current * 1.5) * 0.02 * heat;
      const m = stick.current.children[0] as THREE.Mesh;
      if (m) {
        const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
        mat.roughness = THREE.MathUtils.lerp(0.5, 0.12, heat);
      }
    }
    if (drip.current) {
      const falling = heat > 0.75;
      drip.current.visible = falling;
      if (falling) {
        const c = (elapsed.current * 1.2) % 1;
        drip.current.position.y = 0.4 - c * 2.4;
        (drip.current.material as THREE.MeshBasicMaterial).opacity = 1 - c * 0.5;
      }
    }
  });

  return (
    <group>
      {/* workbench */}
      <mesh position={[0, -2.4, 0]} receiveShadow>
        <boxGeometry args={[12, 0.6, 6]} />
        <meshStandardMaterial color="#78350f" roughness={0.8} />
      </mesh>
      {/* wax stick held at one end, drooping */}
      <group position={[-3.4, 0.4, 0]}>
        <group ref={stick}>
          <mesh castShadow>
            <cylinderGeometry args={[0.32, 0.32, 5.4, 14]} />
            <meshStandardMaterial color={cfg.color} roughness={0.5} />
          </mesh>
          {/* softened tip glows */}
          <mesh position={[0, -2.7, 0]}>
            <sphereGeometry args={[0.34, 14, 10]} />
            <meshStandardMaterial color={cfg.color} roughness={0.1} emissive={cfg.color} emissiveIntensity={heat * 0.7} />
          </mesh>
        </group>
        {/* clamp */}
        <mesh position={[0, 2.9, 0]} castShadow>
          <boxGeometry args={[1, 0.7, 1]} />
          <meshStandardMaterial color="#475569" metalness={0.6} roughness={0.4} />
        </mesh>
      </group>
      {/* heat lamp */}
      <group position={[2.2, 2.6, 0]}>
        <mesh castShadow>
          <coneGeometry args={[1.1, 1.4, 18, 1, true]} />
          <meshStandardMaterial color="#1e293b" metalness={0.6} roughness={0.4} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[0, -0.5, 0]}>
          <sphereGeometry args={[0.3, 12, 10]} />
          <meshBasicMaterial color={heat > 0.1 ? "#fbbf24" : "#57534e"} />
        </mesh>
        {/* heat beam */}
        <mesh position={[-1.2, -2.2, 0]} rotation={[0, 0, 0.5]}>
          <coneGeometry args={[1.6, 3.6, 16, 1, true]} />
          <meshBasicMaterial color="#f59e0b" transparent opacity={0.1 + heat * 0.14} side={THREE.DoubleSide} />
        </mesh>
      </group>
      {/* drip */}
      <mesh ref={drip} position={[-1.2, 0.4, 0]} visible={false}>
        <sphereGeometry args={[0.16, 10, 8]} />
        <meshBasicMaterial color={cfg.color} transparent opacity={1} />
      </mesh>
      {/* wax sheet + boxing strip samples */}
      <mesh position={[4.6, -1.9, -1]} rotation={[-Math.PI / 2.15, 0, 0.2]} castShadow>
        <boxGeometry args={[2.4, 1.8, 0.12]} />
        <meshStandardMaterial color="#f472b6" roughness={0.45} />
      </mesh>
      <mesh position={[4.6, -1.9, 1.2]} castShadow>
        <boxGeometry args={[2.4, 0.5, 0.3]} />
        <meshStandardMaterial color="#facc15" roughness={0.45} />
      </mesh>

      {showLabels && (
        <>
          <Text position={[-3.4, 4.4, 0]} fontSize={0.42} color="#fef3c7">{cfg.name} stick</Text>
          <Text position={[4.6, -0.9, 0]} fontSize={0.38} color="#f9a8d4">Baseplate sheet · boxing strip</Text>
          <Text position={[0, -4.2, 0]} fontSize={0.44} color={heat > 0.7 ? "#fdba74" : "#e2e8f0"} maxWidth={10}>
            {heat < 0.25 ? "Cool: hard and brittle — carves cleanly" : heat < 0.7 ? "Warming: plastic, bends without breaking" : "Hot: flows and drips — too soft to carve!"}
          </Text>
          <Text position={[-6.4, 2.6, 0]} fontSize={0.36} color="#94a3b8" maxWidth={4}>Use: {cfg.use}</Text>
        </>
      )}
    </group>
  );
}

export function Topic10389Sim(props: SimProps) {
  const wax = String(props.wax ?? "inlay");
  const heat = Number(props.heat ?? 0.4);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = WAXES[wax] ?? WAXES.inlay;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Wax", cfg.name],
          ["Softens ~", cfg.melt],
          ["State", heat < 0.25 ? "hard" : heat < 0.7 ? "plastic" : "flowing"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 13]} target={[0, 0.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.75, 0]} receiveShadow>
          <planeGeometry args={[36, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <WaxScene wax={wax} heat={heat} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
