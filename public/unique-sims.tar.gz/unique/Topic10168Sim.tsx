"use client";
// Epidemiology: outbreak investigation, epidemic curves.
// An epidemic curve builds itself bar by bar: a single sharp peak for
// point-source, rolling waves for a propagated outbreak.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "otype", label: "Outbreak type", kind: "select", min: 0, max: 0, step: 1, default: "point", options: ["point", "propagated"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Outbreak Investigation: The Epidemic Curve",
  blurb: "Watch the epidemic curve grow day by day — one sharp peak means one source, rolling waves mean person-to-person spread.",
};

const N_DAYS = 16;

function curveHeight(day: number, otype: string) {
  if (otype === "point") {
    const d = day - 5;
    return Math.max(0.05, 3.4 * Math.exp(-(d * d) / 6));
  }
  return Math.max(0.05, 1.1 + 1.9 * Math.abs(Math.sin(day * 0.75)) * Math.exp(-day / 22) + (day > 2 && day < 6 ? 0.8 : 0));
}

function Animator({ bars, elapsed, speed, otype }: { bars: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number; otype: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const dayFloat = (elapsed.current * 1.6) % (N_DAYS + 3);
    if (bars.current) {
      bars.current.children.forEach((b, i) => {
        const target = i <= dayFloat ? curveHeight(i, otype) : 0.05;
        const m = b as THREE.Mesh;
        m.scale.y += (target - m.scale.y) * 0.12;
        m.position.y = (m.scale.y * 1) / 2;
      });
    }
  });
  return null;
}

export function Topic10168Sim(props: SimProps) {
  const otype = String(props.otype ?? "point");
  const speed = Number(props.speed ?? 1);
  const bars = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const shape = otype === "point" ? "Single sharp peak = one source (e.g. feast)" : "Rolling waves = person-to-person spread";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Outbreak", otype === "point" ? "point-source" : "propagated"], ["Curve says", shape]]} />
      <SimCanvas cameraPosition={[0, 3.8, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* axes */}
        <mesh position={[0, 0.08, 0]}>
          <boxGeometry args={[12.4, 0.12, 0.3]} />
          <meshStandardMaterial color="#64748b" roughness={0.7} />
        </mesh>
        <mesh position={[-6.2, 2.2, 0]}>
          <boxGeometry args={[0.12, 4.4, 0.3]} />
          <meshStandardMaterial color="#64748b" roughness={0.7} />
        </mesh>
        <Label text="CASES" position={[-6.9, 4.4, 0]} size={0.5} color="#94a3b8" />
        <Label text="DAYS →" position={[5.6, 0.55, 0]} size={0.5} color="#94a3b8" />
        {/* bars */}
        <group ref={bars}>
          {Array.from({ length: N_DAYS }, (_, i) => (
            <mesh key={i} position={[-5.6 + i * 0.74, 0.05, 0]} castShadow>
              <boxGeometry args={[0.6, 1, 0.6]} />
              <meshStandardMaterial color={otype === "point" ? "#38bdf8" : "#f59e0b"} emissive={otype === "point" ? "#0ea5e9" : "#d97706"} emissiveIntensity={0.35} />
            </mesh>
          ))}
        </group>
        {/* investigator magnifier */}
        <group position={[4.9, 3.4, 1.5]}>
          <mesh rotation={[0.4, 0, -0.4]}>
            <torusGeometry args={[0.5, 0.08, 10, 24]} />
            <meshStandardMaterial color="#b45309" roughness={0.5} />
          </mesh>
          <Label text="INVESTIGATE" position={[0, 1.1, 0]} size={0.5} color="#fbbf24" />
        </group>
        <Label text="EPIDEMIC CURVE" position={[0, 5.6, 0]} size={0.7} color="#93c5fd" />
        <Animator bars={bars} elapsed={elapsed} speed={speed} otype={otype} />
      </SimCanvas>
    </div>
  );
}
