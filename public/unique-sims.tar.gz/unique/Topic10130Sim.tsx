// Sterilization & disinfection: the autoclave chamber fills with pressurized
// steam — bacteria die off as temperature and time climb; the indicator strip
// turns black when sterile.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "temp", label: "Autoclave temperature", kind: "slider", min: 60, max: 134, step: 1, default: 121, unit: "°C" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Sterilization & disinfection",
  blurb: "The autoclave fills with steam — bacteria die as temperature climbs and the strip turns sterile-black.",
};

const N_BUG = 12;
const N_STEAM = 10;

function Animator({ bugs, steam, strip, elapsed, temp, setTick }: {
  bugs: React.RefObject<(THREE.Mesh | null)[]>;
  steam: React.RefObject<(THREE.Mesh | null)[]>;
  strip: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  temp: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const kill = THREE.MathUtils.clamp((temp - 80) / 54, 0, 1); // 0 below 80°C
    const cycle = (t * 0.25) % 1; // 0..1 loop of one sterilization cycle
    const dead = Math.min(1, cycle * (0.3 + kill * 2.2));
    let aliveCount = 0;
    bugs.current.forEach((b, i) => {
      if (!b) return;
      const dies = ((i * 31) % 10) / 10 < dead;
      b.visible = !dies;
      if (!dies) {
        aliveCount++;
        b.position.y = 1.2 + Math.sin(t * 3 + i * 2) * 0.12;
        b.rotation.y = t * 2 + i;
      }
    });
    steam.current.forEach((s, i) => {
      if (!s) return;
      const f = (t * (0.4 + kill * 0.8) + i / N_STEAM) % 1;
      s.position.set(-2.4 + (i % 5) * 1.2, 0.6 + f * 2.4, (Math.floor(i / 5) - 0.5) * 1.4);
      s.scale.setScalar(0.3 + f * 0.9);
      ((s as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = Math.max(0, 0.5 - f * 0.55) * (0.3 + kill * 0.7);
    });
    if (strip.current) {
      const m = strip.current.material as THREE.MeshStandardMaterial;
      const black = dead >= 0.99;
      m.color.set(black ? "#111827" : "#fbbf24");
      m.emissive.set(m.color.getHex());
      m.emissiveIntensity = black ? 0.1 : 0.5;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(aliveCount); }
  });
  return null;
}

export function Topic10130Sim(props: SimProps) {
  const temp = Number(props.temp ?? 121);
  const showLabels = String(props.detail ?? "on") === "on";
  const bugs = useRef<(THREE.Mesh | null)[]>([]);
  const steam = useRef<(THREE.Mesh | null)[]>([]);
  const strip = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const status = temp >= 121 ? (tick === 0 ? "STERILE ✓" : "sterilizing…") : temp >= 100 ? "disinfecting" : "too cool — bugs survive";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Chamber", `${temp}°C`],
          ["Bacteria alive", `${tick}/${N_BUG}`],
          ["Status", status],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* autoclave chamber */}
        <group>
          <mesh position={[0, 1.9, -0.9]} castShadow>
            <boxGeometry args={[6.4, 3.6, 2.6]} />
            <meshStandardMaterial color="#64748b" metalness={0.6} roughness={0.35} />
          </mesh>
          <mesh position={[0, 1.9, 0.5]}>
            <boxGeometry args={[5.8, 3.0, 0.18]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.5} roughness={0.4} transparent opacity={0.85} />
          </mesh>
          {/* pressure gauge */}
          <mesh position={[-2.2, 3.9, -0.5]}>
            <cylinderGeometry args={[0.4, 0.4, 0.15, 20]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.3} />
          </mesh>
          <mesh position={[-2.2, 3.9, -0.38]} rotation={[Math.PI / 2, 0, -0.6 - (temp / 134) * 1.6]}>
            <boxGeometry args={[0.05, 0.32, 0.02]} />
            <meshStandardMaterial color="#ef4444" />
          </mesh>
        </group>
        {showLabels && <Label text="autoclave" position={[0, 4.6, -0.9]} color="#cbd5e1" />}

        {/* bacteria inside */}
        {Array.from({ length: N_BUG }).map((_, i) => (
          <mesh
            key={i}
            ref={(m) => { bugs.current[i] = m; }}
            position={[-2.4 + (i % 4) * 1.6, 1.2 + Math.floor(i / 8) * 0.9, -0.4 + (i % 2) * 0.8]}
            rotation={[0, 0, Math.PI / 2]}
          >
            <capsuleGeometry args={[0.14, 0.4, 6, 10]} />
            <meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={0.5} />
          </mesh>
        ))}

        {/* steam puffs */}
        {Array.from({ length: N_STEAM }).map((_, i) => (
          <mesh key={`s${i}`} ref={(m) => { steam.current[i] = m; }}>
            <sphereGeometry args={[0.35, 10, 8]} />
            <meshStandardMaterial color="#e2e8f0" transparent opacity={0.4} depthWrite={false} />
          </mesh>
        ))}

        {/* chemical indicator strip */}
        <mesh ref={strip} position={[2.2, 1.9, 0.62]}>
          <boxGeometry args={[0.5, 1.4, 0.05]} />
          <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.5} />
        </mesh>
        {showLabels && <Label text="indicator strip" position={[2.2, 3.1, 0.62]} size={0.45} color="#fde68a" />}

        <Animator bugs={bugs} steam={steam} strip={strip} elapsed={elapsed} temp={temp} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
