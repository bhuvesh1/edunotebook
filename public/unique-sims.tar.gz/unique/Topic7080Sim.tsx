// app/components/sims/unique/Topic7080Sim.tsx
// Vernier caliper: main scale beam + fixed jaw + sliding jaw with vernier
// plate. The jaw opens/closes and the gold ball between the jaws changes
// size so its diameter always equals the jaw opening.

"use client";

import { useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Jaw motion speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Vernier Calipers & Screw Gauge",
  blurb: "The sliding jaw opens and closes to measure the ball's diameter, just like a real vernier caliper.",
};

const MAIN_TICKS: number[] = [];
for (let i = 0; i <= 16; i++) MAIN_TICKS.push(-4 + i * 0.5);
const VERNIER_TICKS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// Fixed inner face of the stationary jaw (world x).
const FIXED_FACE = -3.95;

function Animator({
  jaw,
  ball,
  speed,
  opening,
  bump,
}: {
  jaw: RefObject<THREE.Group>;
  ball: RefObject<THREE.Mesh>;
  speed: number;
  opening: RefObject<number>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta * speed;
    // Jaw opening oscillates between 0.5 and 1.5 scene units.
    // Jaw opening oscillates between 0.5 and 1.5 scene units.
    const open = 1.0 - 0.5 * Math.cos(t.current * 0.8);
    opening.current = open;
    if (jaw.current) jaw.current.position.x = FIXED_FACE + open + 0.15;
    if (ball.current) {
      const r = open / 2;
      ball.current.scale.setScalar(Math.max(r, 0.001));
      ball.current.position.x = FIXED_FACE + open / 2;
    }
    if (++n.current % 20 === 0) bump();
  });
  return null;
}

export function Topic7080Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const jaw = useRef<THREE.Group>(null!);
  const ball = useRef<THREE.Mesh>(null!);
  const opening = useRef(1);
  const [, bump] = useState(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Reading", `${(opening.current * 20).toFixed(1)} mm`],
          ["● Fixed jaw", "gray"],
          ["● Sliding jaw", "blue"],
          ["● Object", "gold ball"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 12]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* main scale beam */}
        <mesh position={[0, 1.6, 0]} castShadow>
          <boxGeometry args={[9, 0.5, 0.6]} />
          <meshStandardMaterial color="#94a3b8" roughness={0.35} metalness={0.7} />
        </mesh>
        {/* main scale ticks */}
        {MAIN_TICKS.map((x, i) => (
          <mesh key={i} position={[x, 1.87, 0.31]}>
            <boxGeometry args={[i % 2 === 0 ? 0.05 : 0.03, i % 2 === 0 ? 0.22 : 0.14, 0.01]} />
            <meshStandardMaterial color="#1e293b" roughness={0.6} />
          </mesh>
        ))}

        {/* fixed jaw */}
        <mesh position={[-4.1, 0.85, 0]} castShadow>
          <boxGeometry args={[0.3, 1.5, 0.5]} />
          <meshStandardMaterial color="#64748b" roughness={0.4} metalness={0.6} />
        </mesh>

        {/* measured ball (unit sphere, scaled by animator) */}
        <mesh ref={ball} position={[FIXED_FACE + 0.5, 0.85, 0]} castShadow>
          <sphereGeometry args={[1, 32, 32]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.25} metalness={0.5} />
        </mesh>

        {/* sliding jaw assembly */}
        <group ref={jaw} position={[FIXED_FACE + 1.15, 0, 0]}>
          <mesh position={[0, 0.85, 0]} castShadow>
            <boxGeometry args={[0.3, 1.5, 0.5]} />
            <meshStandardMaterial color="#3b82f6" roughness={0.4} metalness={0.5} />
          </mesh>
          {/* vernier plate riding over the main beam */}
          <mesh position={[0.1, 1.6, 0]} castShadow>
            <boxGeometry args={[1.5, 0.7, 0.68]} />
            <meshStandardMaterial color="#1d4ed8" roughness={0.45} metalness={0.4} />
          </mesh>
          {VERNIER_TICKS.map((i) => (
            <mesh key={i} position={[-0.45 + i * 0.1, 1.62, 0.35]}>
              <boxGeometry args={[0.025, 0.3, 0.01]} />
              <meshStandardMaterial color="#e0f2fe" roughness={0.6} />
            </mesh>
          ))}
          {/* index pointer */}
          <mesh position={[-0.55, 1.95, 0.31]}>
            <boxGeometry args={[0.04, 0.3, 0.01]} />
            <meshStandardMaterial color="#ef4444" roughness={0.5} />
          </mesh>
        </group>

        <Animator jaw={jaw} ball={ball} speed={speed} opening={opening} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
