// app/components/sims/unique/Topic10548Sim.tsx
// Epidemiology of oral diseases: a 3D bar chart comparing caries,
// periodontal disease, and oral cancer prevalence across age groups.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "pop", label: "Population", kind: "select", min: 0, max: 0, step: 1, default: "adults", options: ["children", "adults", "elderly"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Epidemiology of Oral Diseases",
  blurb: "How common are cavities, gum disease, and oral cancer? Bars rise and fall as you switch age groups.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ bars, elapsed, speed, targets }: {
  bars: RefObject<THREE.Mesh>[]; elapsed: RefObject<number>; speed: number; targets: number[];
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    bars.forEach((b, i) => {
      if (!b.current) return;
      const cur = b.current.scale.y;
      const next = cur + (targets[i] - cur) * Math.min(delta * 3, 1);
      b.current.scale.y = Math.max(next, 0.02);
      b.current.position.y = next * 2.5;
    });
  });
  return null;
}

// illustrative prevalence (%) per age group: [caries, periodontal, oral cancer]
const DATA: Record<string, { vals: number[]; note: string }> = {
  children: { vals: [52, 12, 0.5], note: "caries dominates in children" },
  adults: { vals: [68, 45, 2], note: "gum disease climbs with age" },
  elderly: { vals: [75, 70, 4], note: "periodontal disease peaks; tooth loss rises" },
};

const BARS = [
  { label: "dental caries", color: "#fbbf24", icon: "tooth" },
  { label: "periodontal disease", color: "#f87171", icon: "gum" },
  { label: "oral cancer", color: "#c084fc", icon: "cell" },
];

export function Topic10548Sim(props: SimProps) {
  const pop = String(props.pop ?? "adults");
  const speed = Number(props.speed ?? 1);
  const b0 = useRef<THREE.Mesh>(null!);
  const b1 = useRef<THREE.Mesh>(null!);
  const b2 = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const data = DATA[pop] ?? DATA.adults;
  const targets = data.vals.map((v) => v / 80); // normalize to chart height

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Population", pop],
          ["Caries", `${data.vals[0]}%`],
          ["Periodontal", `${data.vals[1]}%`],
          ["Oral cancer", `${data.vals[2]}%`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 14]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* chart base + axes */}
        <mesh position={[0, 0.15, 0]} receiveShadow>
          <boxGeometry args={[10, 0.3, 4]} />
          <meshStandardMaterial color="#1e293b" roughness={0.7} />
        </mesh>
        <mesh position={[-5, 2.8, 0]}>
          <boxGeometry args={[0.12, 5.6, 0.12]} />
          <meshStandardMaterial color="#475569" roughness={0.6} />
        </mesh>
        <Label p={[-5.6, 5.6, 0]} size={0.3} color="#94a3b8">% affected</Label>

        {[b0, b1, b2].map((ref, i) => (
          <group key={i}>
            <mesh ref={ref} position={[-3.2 + i * 3.2, 2.5, 0]} castShadow>
              <boxGeometry args={[1.8, 5, 1.8]} />
              <meshStandardMaterial color={BARS[i].color} emissive={BARS[i].color} emissiveIntensity={0.35} roughness={0.4} />
            </mesh>
            <Text position={[-3.2 + i * 3.2, 0.7, 1.1]} fontSize={0.34} color="#e2e8f0" anchorX="center" anchorY="middle">
              {BARS[i].label}
            </Text>
            <Text position={[-3.2 + i * 3.2, 5.9, 0]} fontSize={0.4} color={BARS[i].color} anchorX="center" anchorY="middle">
              {`${data.vals[i]}%`}
            </Text>
          </group>
        ))}

        {/* tooth icon over caries bar */}
        <mesh position={[-3.2, 6.6, 0]} castShadow>
          <boxGeometry args={[0.7, 0.8, 0.6]} />
          <meshStandardMaterial color="#ffffff" roughness={0.3} />
        </mesh>
        {/* gum icon over periodontal bar */}
        <mesh position={[0, 6.6, 0]} scale={[1.2, 0.5, 0.8]} castShadow>
          <sphereGeometry args={[0.5, 14, 14]} />
          <meshStandardMaterial color="#f87171" roughness={0.5} />
        </mesh>
        {/* cell icon over cancer bar */}
        <mesh position={[3.2, 6.6, 0]} castShadow>
          <sphereGeometry args={[0.45, 16, 16]} />
          <meshStandardMaterial color="#c084fc" emissive="#a855f7" emissiveIntensity={0.6} roughness={0.4} />
        </mesh>

        <Label p={[0, 7.6, 0]} size={0.34} color="#e2e8f0">{data.note}</Label>

        <Animator bars={[b0, b1, b2]} elapsed={elapsed} speed={speed} targets={targets} />
      </SimCanvas>
    </div>
  );
}
