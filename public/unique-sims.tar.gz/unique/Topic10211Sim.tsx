// Neuro-ophthalmology — optic neuritis (the optic nerve inflames and its
// signal pulses weaken), papilledema (the optic disc swells), and visual
// field defects (hemianopia patterns on a test screen). Select the defect.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "defect", label: "Visual field defect", kind: "select", min: 0, max: 0, step: 1, default: "normal", options: ["normal", "bitemporal hemianopia", "homonymous hemianopia", "central scotoma"] },
  { key: "nerve", label: "Optic nerve state", kind: "select", min: 0, max: 0, step: 1, default: "healthy", options: ["healthy", "optic neuritis", "papilledema"] },
];

export const UNIQUE_META = {
  title: "Neuro-Ophthalmology",
  blurb: "Inflame the optic nerve or swell the disc — then pick a visual-field defect and see exactly what the patient sees.",
};

function Animator({ pulses, elapsed, nerve }: {
  pulses: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  nerve: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const strength = nerve === "healthy" ? 1 : 0.35;
    if (pulses.current) {
      pulses.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * (0.6 * strength) + i * 0.25) % 1);
        m.position.x = -1.6 - ph * 4.6;
        ((m as THREE.Mesh).material as THREE.MeshBasicMaterial).opacity = strength * (0.4 + 0.6 * (1 - ph));
      });
    }
  });
  return null;
}

export function Topic10211Sim(props: SimProps) {
  const defect = String(props.defect ?? "normal");
  const nerve = String(props.nerve ?? "healthy");
  const pulses = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const inflamed = nerve === "optic neuritis";
  const swollen = nerve === "papilledema";

  // visual-field screen: two circles (L/R eye); dark = blind
  const blind = (side: "L" | "R", half: "left" | "right" | "center"): boolean => {
    if (defect === "normal") return false;
    if (defect === "bitemporal hemianopia") return (side === "L" && half === "left") || (side === "R" && half === "right");
    if (defect === "homonymous hemianopia") return half === "right";
    if (defect === "central scotoma") return half === "center";
    return false;
  };

  const FieldCircle = ({ x }: { x: number }) => (
    <group position={[x, 0.8, 0]}>
      <mesh>
        <circleGeometry args={[1.5, 32, Math.PI / 2, Math.PI]} />
        <meshBasicMaterial color={blind(x < 0 ? "L" : "R", "left") ? "#1e293b" : "#4ade80"} transparent opacity={0.85} side={THREE.DoubleSide} />
      </mesh>
      <mesh>
        <circleGeometry args={[1.5, 32, -Math.PI / 2, Math.PI]} />
        <meshBasicMaterial color={blind(x < 0 ? "L" : "R", "right") ? "#1e293b" : "#4ade80"} transparent opacity={0.85} side={THREE.DoubleSide} />
      </mesh>
      {defect === "central scotoma" && (
        <mesh position={[0, 0, 0.02]}>
          <circleGeometry args={[0.55, 24]} />
          <meshBasicMaterial color="#1e293b" />
        </mesh>
      )}
      <mesh position={[0, 0, 0.01]}>
        <circleGeometry args={[0.09, 12]} />
        <meshBasicMaterial color="#f8fafc" />
      </mesh>
      <Label text={x < 0 ? "Left eye field" : "Right eye field"} position={[0, -2.1, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Optic nerve", nerve], ["Signal", inflamed ? "weak & painful ⚠" : "strong"], ["Patient sees", defect]]} />
      <SimCanvas cameraPosition={[0, 2.4, 12]} target={[0, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* eyeball */}
        <mesh position={[0.8, 2.6, 0]} castShadow>
          <sphereGeometry args={[1.25, 32, 24]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.35} />
        </mesh>
        <mesh position={[1.9, 2.6, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.42, 0.2, 12, 26]} />
          <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
        </mesh>
        {/* optic disc at the back: swells in papilledema */}
        <mesh position={[-0.35, 2.6, 0]} scale={[0.6, swollen ? 1.5 : 1, swollen ? 1.5 : 1]}>
          <sphereGeometry args={[0.4, 18, 14]} />
          <meshStandardMaterial color={swollen ? "#f87171" : "#fb923c"} roughness={0.5} emissive={swollen ? "#7f1d1d" : "#7c2d12"} emissiveIntensity={0.5} />
        </mesh>
        {/* optic nerve cable */}
        <mesh position={[-3.2, 2.6, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[inflamed ? 0.5 : 0.36, inflamed ? 0.5 : 0.36, 4.4, 18]} />
          <meshStandardMaterial color={inflamed ? "#ef4444" : "#fbbf24"} roughness={0.55} emissive={inflamed ? "#7f1d1d" : "#000000"} emissiveIntensity={inflamed ? 0.6 : 0} />
        </mesh>
        {/* brain */}
        <mesh position={[-6.4, 2.6, 0]} scale={[1, 1.15, 0.9]}>
          <sphereGeometry args={[0.95, 24, 18]} />
          <meshStandardMaterial color="#f472b6" roughness={0.55} />
        </mesh>
        {/* signal pulses */}
        <group ref={pulses}>
          {Array.from({ length: 4 }).map((_, i) => (
            <mesh key={i} position={[-1.6, 2.6, 0]}>
              <sphereGeometry args={[0.18, 12, 12]} />
              <meshBasicMaterial color="#fde047" transparent opacity={0.9} />
            </mesh>
          ))}
        </group>
        {inflamed && <Label text="Optic neuritis — painful eye movements" position={[-3.2, 4.1, 0]} size={0.48} color="#fca5a5" />}
        {swollen && <Label text="Papilledema — disc swollen from brain pressure" position={[-0.35, 4.1, 0]} size={0.48} color="#fca5a5" />}

        {/* visual field test screen */}
        <mesh position={[2.2, 0.8, -0.15]}>
          <boxGeometry args={[7.6, 4.4, 0.2]} />
          <meshStandardMaterial color="#0b1020" roughness={0.7} />
        </mesh>
        <FieldCircle x={0.4} />
        <FieldCircle x={4.0} />
        <Label text={`Visual field: ${defect}`} position={[2.2, 3.6, 0]} size={0.52} color="#fde047" />

        <Animator pulses={pulses} elapsed={elapsed} nerve={nerve} />
      </SimCanvas>
    </div>
  );
}
