// Enterobacteriaceae: E. coli, Salmonella, Shigella swim with whipping flagella
// while comma-shaped Vibrio curves through the broth.
"use client";

import { useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Swim speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Enterobacteriaceae",
  blurb: "E. coli, Salmonella and Shigella swim with flagella while comma-shaped Vibrio curves through the broth.",
};

const BUGS = [
  { name: "E. coli", x: -3.6, color: "#4ade80", flagella: true, curve: 0 },
  { name: "Salmonella", x: -1.2, color: "#22c55e", flagella: true, curve: 0 },
  { name: "Shigella", x: 1.2, color: "#86efac", flagella: false, curve: 0 },
  { name: "Vibrio", x: 3.6, color: "#2dd4bf", flagella: true, curve: 0.5 },
];

function Animator({ bugs, elapsed, speed, setTick }: {
  bugs: React.RefObject<(THREE.Group | null)[]>;
  elapsed: React.RefObject<number>;
  speed: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    bugs.current.forEach((g, i) => {
      if (!g) return;
      // each swims in a lazy circle at its own lane
      const r = 0.8;
      g.position.x = BUGS[i].x + Math.cos(t * 0.9 + i * 1.8) * r;
      g.position.z = Math.sin(t * 0.9 + i * 1.8) * r;
      g.position.y = 1.6 + Math.sin(t * 1.7 + i * 2.4) * 0.18;
      g.rotation.y = -t * 0.9 - i * 1.8 + Math.PI / 2;
      // flagella whip
      g.children.forEach((c) => {
        if ((c as THREE.Mesh).geometry?.type === "TubeGeometry") {
          c.rotation.x = Math.sin(t * 14 + i) * 0.5;
        }
      });
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(t * 10)); }
  });
  return null;
}

export function Topic10133Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const bugs = useRef<(THREE.Group | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const flagGeo = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 20; i++) {
      pts.push(new THREE.Vector3(-0.9 - i * 0.09, Math.sin(i * 0.9) * 0.16, 0));
    }
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 24, 0.035, 6);
  }, []);
  const vibrioGeo = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 20; i++) {
      const a = (i / 20) * Math.PI * 0.9;
      pts.push(new THREE.Vector3(Math.sin(a) * 1.1, 0, (1 - Math.cos(a)) * 0.7 - 0.35));
    }
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 24, 0.26, 10);
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Family", "Enterobacteriaceae"],
          ["Motile", "E. coli, Salmonella, Vibrio"],
          ["Non-motile", "Shigella"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 13]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* culture broth */}
        <mesh position={[0, 0.55, 0]} receiveShadow>
          <boxGeometry args={[11, 1.1, 5]} />
          <meshStandardMaterial color="#14532d" transparent opacity={0.5} roughness={0.2} />
        </mesh>
        {showLabels && <Label text="nutrient broth" position={[0, -0.35, 0]} size={0.45} color="#86efac" />}

        {BUGS.map((b, i) => (
          <group key={b.name} ref={(g) => { bugs.current[i] = g; }} position={[b.x, 1.6, 0]}>
            {b.curve > 0 ? (
              <mesh geometry={vibrioGeo} castShadow>
                <meshStandardMaterial color={b.color} roughness={0.45} />
              </mesh>
            ) : (
              <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
                <capsuleGeometry args={[0.28, 1.0, 6, 12]} />
                <meshStandardMaterial color={b.color} roughness={0.45} />
              </mesh>
            )}
            {b.flagella &&
              [-0.35, 0, 0.35].map((z, fi) => (
                <mesh key={fi} geometry={flagGeo} position={[0, 0, z]}>
                  <meshStandardMaterial color="#d1fae5" roughness={0.5} />
                </mesh>
              ))}
            {showLabels && (
              <Label text={b.name} position={[0, 1.15, 0]} size={0.5} color="#d1fae5" />
            )}
          </group>
        ))}
        {showLabels && <Label text="whipping flagella" position={[-5.6, 2.6, 0]} size={0.4} color="#a7f3d0" />}

        <Animator bugs={bugs} elapsed={elapsed} speed={speed} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
