"use client";

// Medically compromised patients: renal, hepatic, pregnancy.
// One patient, three risk profiles — the highlighted organ shows
// the dental precaution that changes the treatment plan.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Patient profile", kind: "select", min: 0, max: 0, step: 1, default: "renal", options: ["renal", "hepatic", "pregnancy"] },
];

export const UNIQUE_META = {
  title: "Medically Compromised Patients",
  blurb: "Renal, hepatic or pregnant — the highlighted organ shows the dental precaution that changes the treatment plan.",
};

type Ref = { current: THREE.Group | null };
const IDX: Record<string, number> = { renal: 0, hepatic: 1, pregnancy: 2 };

function Animator({ organs, elapsed, condition }: { organs: Ref; elapsed: { current: number }; condition: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const e = elapsed.current;
    const sel = IDX[condition] ?? 0;
    organs.current?.children.forEach((g, i) => {
      const s = i === sel ? 1 + 0.09 * Math.sin(e * 3.2) : 1;
      g.scale.set(s, s, s);
      g.children.forEach((m) => {
        const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = i === sel ? 0.55 + 0.3 * Math.sin(e * 3.2) : 0;
        mat.transparent = true;
        mat.opacity = i === sel ? 1 : 0.45;
      });
    });
  });
  return null;
}

export function Topic10566Sim(props: SimProps) {
  const condition = String(props.condition ?? "renal");

  const organs = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const data: Record<string, { organ: string; precaution: string }> = {
    renal: { organ: "Kidneys", precaution: "Avoid NSAIDs — dose-adjust drugs, watch bleeding" },
    hepatic: { organ: "Liver", precaution: "Check clotting — avoid hepatotoxic drugs" },
    pregnancy: { organ: "Pregnancy", precaution: "2nd trimester safest — avoid X-rays & tetracyclines" },
  };
  const d = data[condition];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Profile", d.organ],
          ["Dental precaution", d.precaution],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 10.5]} target={[0, 2.3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* torso + head */}
        <mesh position={[0, 2.1, 0]} castShadow>
          <capsuleGeometry args={[0.85, 1.7, 8, 20]} />
          <meshStandardMaterial color="#eab88f" roughness={0.7} />
        </mesh>
        <mesh position={[0, 4.05, 0]} castShadow>
          <sphereGeometry args={[0.5, 20, 20]} />
          <meshStandardMaterial color="#eab88f" roughness={0.7} />
        </mesh>

        {/* organs: kidney, liver, pregnant belly */}
        <group ref={organs}>
          <group position={[-0.5, 2.45, 0.62]}>
            <mesh scale={[0.75, 1.05, 0.6]} castShadow>
              <sphereGeometry args={[0.34, 18, 18]} />
              <meshStandardMaterial color="#92400e" emissive="#92400e" roughness={0.5} />
            </mesh>
          </group>
          <group position={[0.45, 3.05, 0.62]}>
            <mesh castShadow>
              <boxGeometry args={[0.85, 0.45, 0.35]} />
              <meshStandardMaterial color="#7f1d1d" emissive="#7f1d1d" roughness={0.5} />
            </mesh>
          </group>
          <group position={[0, 1.4, 0.66]}>
            <mesh scale={[1, 0.9, 0.72]} castShadow>
              <sphereGeometry args={[0.52, 20, 20]} />
              <meshStandardMaterial color="#f3a6b8" emissive="#f3a6b8" roughness={0.55} />
            </mesh>
          </group>
        </group>

        <Label text="Kidney" position={[-1.7, 2.45, 0.6]} size={0.45} color={condition === "renal" ? "#fdba74" : "#64748b"} />
        <Label text="Liver" position={[1.75, 3.05, 0.6]} size={0.45} color={condition === "hepatic" ? "#fca5a5" : "#64748b"} />
        <Label text="Pregnancy" position={[0, 0.55, 0.7]} size={0.45} color={condition === "pregnancy" ? "#f9a8d4" : "#64748b"} />
        <Label text={d.precaution} position={[0, 4.95, 0]} size={0.46} color="#fbbf24" />
        <Animator organs={organs} elapsed={elapsed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
