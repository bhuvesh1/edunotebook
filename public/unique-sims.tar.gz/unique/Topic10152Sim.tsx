"use client";
// Thanatology: death — types, signs, postmortem changes.
// A "hours after death" timeline: four body icons change colour and pose
// (pallor → livor mortis → rigor mortis → decomposition) as the clock turns.


import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "hours", label: "Hours after death", kind: "slider", min: 0, max: 48, step: 1, default: 6, unit: "h" },
  { key: "speed", label: "Clock speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 0, unit: "×" },
];

export const UNIQUE_META = {
  title: "Thanatology: Signs of Death & Postmortem Changes",
  blurb: "Turn the hours dial and watch the body change: cooling, livor mortis, rigor mortis, then decomposition.",
};

const STAGES = [
  { name: "Pallor + cooling", color: "#e8dcc8", until: 2 },
  { name: "Livor mortis (bluish patches)", color: "#7c8db0", until: 8 },
  { name: "Rigor mortis (stiff)", color: "#b0a58e", until: 24 },
  { name: "Decomposition (greenish)", color: "#6b8f5e", until: 48 },
];

function Animator({ hand, elapsed, speed, setT }: { hand: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number; setT: (v: number) => void }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (hand.current) hand.current.rotation.z = -elapsed.current * 0.6;
    if (speed > 0) setT((elapsed.current % 48));
  });
  return null;
}

function BodyIcon({ color, stiff, x }: { color: string; stiff: boolean; x: number }) {
  return (
    <group position={[x, 0, 0]}>
      <mesh position={[0, 1.9, 0]} castShadow>
        <sphereGeometry args={[0.4, 18, 18]} />
        <meshStandardMaterial color={color} roughness={0.8} />
      </mesh>
      <mesh position={[0, 1.0, 0]} rotation={[0, 0, stiff ? 0 : 0.12]} castShadow>
        <capsuleGeometry args={[0.42, 0.9, 6, 14]} />
        <meshStandardMaterial color={color} roughness={0.8} />
      </mesh>
      {stiff && (
        <mesh position={[0, 1.0, 0]}>
          <boxGeometry args={[2.2, 0.12, 0.12]} />
          <meshStandardMaterial color="#475569" roughness={0.6} />
        </mesh>
      )}
    </group>
  );
}

export function Topic10152Sim(props: SimProps) {
  const speed = Number(props.speed ?? 0);
  const manual = Number(props.hours ?? 6);
  const [autoT, setAutoT] = useState(manual);
  const lastInt = useRef(-1);
  const setT = (v: number) => { const i = Math.floor(v); if (i !== lastInt.current) { lastInt.current = i; setAutoT(i); } };
  const hand = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const t = speed > 0 ? autoT : manual;
  const stage = STAGES.find((s) => t <= s.until) ?? STAGES[3];

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Hours", `${Math.floor(t)}h`], ["Stage", stage.name]]} />
      <SimCanvas cameraPosition={[0, 4, 13]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* clock */}
        <group position={[-6.4, 3.4, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[1.3, 1.3, 0.25, 28]} />
            <meshStandardMaterial color="#f1f5f9" roughness={0.5} />
          </mesh>
          <group ref={hand} position={[0, 0, 0.16]}>
            <mesh position={[0, 0.5, 0]}>
              <boxGeometry args={[0.09, 1.05, 0.05]} />
              <meshStandardMaterial color="#dc2626" roughness={0.5} />
            </mesh>
          </group>
          <Label text="TIME" position={[0, -1.9, 0]} size={0.55} color="#fbbf24" />
        </group>
        {/* timeline rail */}
        <mesh position={[0.6, 0.08, 0]}>
          <boxGeometry args={[13, 0.16, 0.5]} />
          <meshStandardMaterial color="#334155" roughness={0.8} />
        </mesh>
        {STAGES.map((s, i) => (
          <group key={s.name}>
            <BodyIcon color={s.color} stiff={i === 2} x={-4.4 + i * 3.4} />
            <Label text={s.name} position={[-4.4 + i * 3.4, 3.1, 0]} size={0.5} color={stage.name === s.name ? "#fbbf24" : "#94a3b8"} />
            {stage.name === s.name && (
              <mesh position={[-4.4 + i * 3.4, 0.35, 0]}>
                <boxGeometry args={[2.6, 0.18, 1.2]} />
                <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.7} />
              </mesh>
            )}
          </group>
        ))}
        <Animator hand={hand} elapsed={elapsed} speed={speed} setT={setT} />
      </SimCanvas>
    </div>
  );
}
