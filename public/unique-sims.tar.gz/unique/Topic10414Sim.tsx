"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "hygiene", label: "Brushing quality", kind: "slider", min: 0, max: 100, step: 5, default: 30, unit: "%" },
  { key: "time", label: "Plaque age", kind: "select", min: 0, max: 0, step: 1, default: "24h", options: ["4h", "24h", "72h"] },
];

export const UNIQUE_META = {
  title: "Oral microbiology: dental plaque biofilm, cariogenic bacteria",
  blurb: "Tooth surface magnified — sticky biofilm slime with rod and coccus bacteria, dropping acid that pits the enamel.",
};

function Scene({ hygiene, time }: { hygiene: number; time: string }) {
  const t = useRef(0);
  const slime = useRef<THREE.Mesh>(null!);
  const ageFactor = time === "4h" ? 0.5 : time === "24h" ? 1 : 1.6;
  const density = Math.max(0.1, (1 - hygiene / 130) * ageFactor);

  const bacteria = useMemo(() => {
    const arr: { p: [number, number, number]; rod: boolean; s: number; ph: number }[] = [];
    for (let i = 0; i < 46; i++) {
      arr.push({
        p: [(Math.random() - 0.5) * 5.4, 0.35 + Math.random() * 0.9 * ageFactor, (Math.random() - 0.5) * 3.4],
        rod: Math.random() > 0.45,
        s: 0.7 + Math.random() * 0.6,
        ph: Math.random() * Math.PI * 2,
      });
    }
    return arr;
  }, [ageFactor]);

  const acids = useMemo(() => {
    const arr: { x: number; z: number; ph: number }[] = [];
    for (let i = 0; i < 14; i++) arr.push({ x: (Math.random() - 0.5) * 5, z: (Math.random() - 0.5) * 3, ph: Math.random() * 6 });
    return arr;
  }, []);

  const acidRefs = useRef<(THREE.Mesh | null)[]>([]);

  useFrame((_, delta) => {
    t.current += delta;
    if (slime.current) {
      const m = slime.current.material as THREE.MeshStandardMaterial;
      m.opacity = 0.28 + Math.sin(t.current * 1.5) * 0.06;
    }
    acidRefs.current.forEach((m, i) => {
      if (!m) return;
      const a = acids[i];
      m.position.y = 1.6 - ((t.current * 0.7 + a.ph) % 1.6);
      ((m as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = density > 0.3 ? 0.9 : 0.25;
    });
  });

  const visible = Math.floor(bacteria.length * Math.min(1, density));

  return (
    <group>
      {/* enamel surface */}
      <mesh position={[0, 0, 0]} receiveShadow>
        <boxGeometry args={[6.4, 0.5, 4]} />
        <meshStandardMaterial color="#f1ead8" roughness={0.35} />
      </mesh>
      <Label text="Enamel surface" position={[-3.7, 0.1, 0]} size={0.45} color="#fde68a" />
      {/* demineralization pits */}
      {density > 0.4 && acids.slice(0, 8).map((a, i) => (
        <mesh key={i} position={[a.x, 0.26, a.z]}>
          <circleGeometry args={[0.16, 12]} />
          <meshStandardMaterial color="#92400e" roughness={1} />
        </mesh>
      ))}
      {/* EPS slime */}
      <mesh ref={slime} position={[0, 0.75, 0]}>
        <boxGeometry args={[6.2, 0.9, 3.8]} />
        <meshStandardMaterial color="#4d7c0f" transparent opacity={0.3} roughness={0.2} />
      </mesh>
      <Label text="Biofilm slime (EPS)" position={[3.7, 0.9, 0]} size={0.45} color="#a3e635" />

      {/* bacteria */}
      {bacteria.slice(0, visible).map((b, i) =>
        b.rod ? (
          <mesh key={i} position={b.p} rotation={[Math.PI / 2, 0, b.ph]} scale={b.s}>
            <capsuleGeometry args={[0.11, 0.34, 6, 12]} />
            <meshStandardMaterial color="#facc15" roughness={0.5} />
          </mesh>
        ) : (
          <mesh key={i} position={b.p} scale={b.s}>
            <sphereGeometry args={[0.16, 12, 12]} />
            <meshStandardMaterial color="#fb923c" roughness={0.5} />
          </mesh>
        )
      )}
      <Label text="Strep. mutans (rods + cocci)" position={[0, 2.4, 0]} size={0.55} color="#fde68a" />

      {/* acid droplets */}
      {acids.map((a, i) => (
        <mesh key={i} ref={(m) => { acidRefs.current[i] = m; }} position={[a.x, 1.5, a.z]}>
          <sphereGeometry args={[0.1, 10, 10]} />
          <meshStandardMaterial color="#f97316" transparent opacity={0.9} roughness={0.2} />
        </mesh>
      ))}
      <Label text="Acid attack → cavity" position={[0, -0.9, 0]} size={0.5} color="#fb923c" />
    </group>
  );
}

export function Topic10414Sim(props: SimProps) {
  const hygiene = Number(props.hygiene ?? 30);
  const time = String(props.time ?? "24h");
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Brushing", `${hygiene}%`], ["Plaque age", time], ["Caries risk", hygiene < 40 ? "High" : hygiene < 75 ? "Moderate" : "Low"]]} />
      <SimCanvas cameraPosition={[0, 4.5, 8.5]} target={[0, 0.6, 0]}>
        <Scene hygiene={hygiene} time={time} />
      </SimCanvas>
    </div>
  );
}
