"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "span", label: "Bridge span", kind: "select", min: 0, max: 0, step: 1, default: "3unit", options: ["3unit", "4unit"] },
  { key: "pontic", label: "Pontic design", kind: "select", min: 0, max: 0, step: 1, default: "ridgelap", options: ["ridgelap", "ovate", "sanitary"] },
];

export const UNIQUE_META = {
  title: "Fixed partial dentures: abutments, pontics, connectors",
  blurb: "A dental bridge in 3D — crowned abutment teeth on both ends, a pontic floating over the gum, joined by connectors.",
};

const SPANS: Record<string, { name: string; units: number; note: string }> = {
  "3unit": { name: "3-unit bridge", units: 3, note: "One missing tooth — ideal span" },
  "4unit": { name: "4-unit bridge", units: 4, note: "Two missing teeth — longer span, more flex" },
};

const PONTICS: Record<string, { name: string; note: string }> = {
  ridgelap: { name: "Ridge lap", note: "Sits on the ridge — easy to clean under" },
  ovate: { name: "Ovate", note: "Egg-in-socket — best looks for front teeth" },
  sanitary: { name: "Sanitary (hygienic)", note: "High above gum — easiest cleaning" },
};

function CrownedTooth({ x, label }: { x: number; label: string }) {
  return (
    <group position={[x, 0, 0]}>
      {/* prepared stump */}
      <mesh position={[0, 0.35, 0]}>
        <cylinderGeometry args={[0.32, 0.42, 0.8, 12]} />
        <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
      </mesh>
      {/* gold crown */}
      <mesh position={[0, 0.75, 0]}>
        <cylinderGeometry args={[0.42, 0.44, 0.55, 12]} />
        <meshStandardMaterial color="#d4af37" metalness={0.75} roughness={0.3} />
      </mesh>
      {/* porcelain top */}
      <mesh position={[0, 1.05, 0]}>
        <cylinderGeometry args={[0.4, 0.42, 0.18, 12]} />
        <meshStandardMaterial color="#fdfbf3" roughness={0.25} />
      </mesh>
      <Label text={label} position={[0, 1.65, 0]} size={0.4} color="#fde68a" />
    </group>
  );
}

function Scene({ span, pontic }: { span: string; pontic: string }) {
  const group = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const s = SPANS[span] ?? SPANS["3unit"];
  const p = PONTICS[pontic] ?? PONTICS.ridgelap;
  const ponticCount = s.units - 2;
  const gapX = s.units === 3 ? [0] : [-0.75, 0.75];

  useFrame((_, delta) => {
    t.current += delta;
    if (group.current) group.current.rotation.y = Math.sin(t.current * 0.3) * 0.5;
  });

  const ponticY = pontic === "sanitary" ? 0.9 : pontic === "ovate" ? 0.35 : 0.5;

  return (
    <group ref={group}>
      {/* gum ridge */}
      <mesh position={[0, -0.5, 0]}>
        <boxGeometry args={[7.5, 1.0, 2.2]} />
        <meshStandardMaterial color="#e0788a" roughness={0.6} />
      </mesh>
      {/* bone */}
      <mesh position={[0, -1.4, 0]}>
        <boxGeometry args={[7.5, 0.9, 2.0]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>

      <CrownedTooth x={-2.4} label="Abutment" />
      <CrownedTooth x={2.4} label="Abutment" />

      {/* pontics */}
      {Array.from({ length: ponticCount }).map((_, i) => (
        <group key={i} position={[gapX[i] ?? 0, ponticY, 0]}>
          <mesh scale={[1, pontic === "ovate" ? 1.25 : 0.9, 0.95]}>
            <sphereGeometry args={[0.55, 16, 16]} />
            <meshStandardMaterial color="#fdfbf3" roughness={0.25} />
          </mesh>
          <Label text="Pontic (false tooth)" position={[0, 1.15, 0]} size={0.4} color="#e2e8f0" />
        </group>
      ))}

      {/* connectors */}
      {[-1.2, 1.2].map((x, i) => (
        <mesh key={i} position={[x, 0.75, 0]}>
          <boxGeometry args={[1.1, 0.35, 0.5]} />
          <meshStandardMaterial color="#d4af37" metalness={0.7} roughness={0.35} />
        </mesh>
      ))}
      <Label text="Connectors" position={[0, 1.45, 0]} size={0.4} color="#fde68a" />

      <Label text={s.name} position={[0, 2.9, 0]} size={0.65} color="#fde68a" />
      <Label text={`${p.name} pontic: ${p.note}`} position={[0, -2.6, 0]} size={0.42} color="#e2e8f0" />
      <Label text={s.note} position={[0, -3.25, 0]} size={0.4} color="#94a3b8" />
    </group>
  );
}

export function Topic10435Sim(props: SimProps) {
  const span = String(props.span ?? "3unit");
  const pontic = String(props.pontic ?? "ridgelap");
  const s = SPANS[span] ?? SPANS["3unit"];
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Bridge", s.name], ["Pontic", (PONTICS[pontic] ?? PONTICS.ridgelap).name], ["Retainers", "Full crowns"]]} />
      <SimCanvas cameraPosition={[0, 2, 10]} target={[0, 0.3, 0]}>
        <Scene span={span} pontic={pontic} />
      </SimCanvas>
    </div>
  );
}
