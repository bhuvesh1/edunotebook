// app/components/sims/unique/Topic10516Sim.tsx
// Potentially malignant disorders: leukoplakia (white patch), OSMF (fibrous
// bands + restricted opening), and lichen planus (lacy white lines).

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "pmd", label: "Disorder", kind: "select", min: 0, max: 0, step: 1, default: "leukoplakia", options: ["leukoplakia", "osmf", "lichen-planus"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Potentially Malignant Disorders",
  blurb: "Leukoplakia's white patch, OSMF's fibrous bands that lock the jaw, or lichen planus' lacy lines.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ marks, elapsed, speed, pmd }: {
  marks: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; pmd: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (!marks.current) return;
    const s = pmd === "osmf" ? 1 : 1 + 0.06 * Math.sin(elapsed.current * 2.2);
    marks.current.scale.setScalar(s);
  });
  return null;
}

const INFO: Record<string, { title: string; sign: string; risk: string }> = {
  leukoplakia: { title: "Leukoplakia", sign: "non-scrapable white patch", risk: "malignant transformation ~1–2%/yr" },
  osmf: { title: "Oral submucous fibrosis", sign: "fibrous bands, burning, trismus", risk: "areca-nut habit; transformation ~7–13%" },
  "lichen-planus": { title: "Oral lichen planus", sign: "lacy white Wickham striae", risk: "erosive type needs monitoring" },
};

export function Topic10516Sim(props: SimProps) {
  const pmd = String(props.pmd ?? "leukoplakia");
  const speed = Number(props.speed ?? 1);
  const marks = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = INFO[pmd] ?? INFO.leukoplakia;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Disorder", info.title],
          ["Clinical sign", info.sign],
          ["Risk", info.risk],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.6, 10]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* face */}
        <mesh position={[0, 2.6, -0.8]} castShadow>
          <sphereGeometry args={[2.6, 32, 32]} />
          <meshStandardMaterial color="#f0b98d" roughness={0.7} />
        </mesh>
        {/* open mouth cavity — narrower for OSMF (trismus) */}
        <mesh position={[0, 2.4, 1.2]} scale={[pmd === "osmf" ? 0.75 : 1, pmd === "osmf" ? 0.7 : 1, 1]}>
          <sphereGeometry args={[1.35, 24, 24]} />
          <meshStandardMaterial color="#5b1a1a" roughness={0.9} />
        </mesh>
        {/* lips */}
        <mesh position={[0, 2.4, 1.55]} scale={[pmd === "osmf" ? 1 : 1.35, pmd === "osmf" ? 0.55 : 0.85, 0.6]} castShadow>
          <torusGeometry args={[1.05, 0.28, 14, 32]} />
          <meshStandardMaterial color="#e0788a" roughness={0.55} />
        </mesh>
        {/* tongue */}
        <mesh position={[0, 1.85, 1.5]} scale={[1, 0.45, 1.15]} castShadow>
          <sphereGeometry args={[0.85, 24, 24]} />
          <meshStandardMaterial color="#e0607a" roughness={0.55} />
        </mesh>
        {/* upper teeth */}
        {[-0.75, -0.38, 0, 0.38, 0.75].map((x, i) => (
          <mesh key={i} position={[x, 3.15, 1.5]} castShadow>
            <boxGeometry args={[0.3, 0.4, 0.25]} />
            <meshStandardMaterial color="#ffffff" roughness={0.3} />
          </mesh>
        ))}

        {/* disorder-specific markings */}
        <group ref={marks}>
          {pmd === "leukoplakia" && (
            <mesh position={[-0.7, 2.6, 1.82]} rotation={[0, 0.35, 0.25]}>
              <circleGeometry args={[0.5, 22]} />
              <meshStandardMaterial color="#f8fafc" emissive="#ffffff" emissiveIntensity={0.3} roughness={0.8} side={THREE.DoubleSide} />
            </mesh>
          )}
          {pmd === "osmf" && (
            <>
              {/* vertical fibrous bands on both cheeks */}
              {[-0.95, -0.6, 0.6, 0.95].map((x, i) => (
                <mesh key={i} position={[x, 2.55, 1.72]} rotation={[0, x < 0 ? 0.5 : -0.5, 0]}>
                  <boxGeometry args={[0.12, 1.1, 0.06]} />
                  <meshStandardMaterial color="#fde68a" emissive="#f59e0b" emissiveIntensity={0.5} roughness={0.6} />
                </mesh>
              ))}
              {/* blanched mucosa tint */}
              <mesh position={[0, 2.4, 1.35]} scale={[1.1, 0.85, 0.9]}>
                <sphereGeometry args={[1.0, 20, 20]} />
                <meshStandardMaterial color="#fcd9b8" transparent opacity={0.55} roughness={0.8} />
              </mesh>
            </>
          )}
          {pmd === "lichen-planus" && (
            <>
              {/* lacy white Wickham striae: criss-cross lines on cheek */}
              {[-0.3, 0, 0.3].map((dy, i) => (
                <mesh key={`a${i}`} position={[-0.75, 2.4 + dy, 1.8]} rotation={[0, 0.35, 0.6]}>
                  <boxGeometry args={[0.9, 0.05, 0.03]} />
                  <meshStandardMaterial color="#f8fafc" emissive="#ffffff" emissiveIntensity={0.4} />
                </mesh>
              ))}
              {[-0.25, 0.05, 0.35].map((dy, i) => (
                <mesh key={`b${i}`} position={[-0.75, 2.35 + dy, 1.8]} rotation={[0, 0.35, -0.6]}>
                  <boxGeometry args={[0.9, 0.05, 0.03]} />
                  <meshStandardMaterial color="#f8fafc" emissive="#ffffff" emissiveIntensity={0.4} />
                </mesh>
              ))}
            </>
          )}
        </group>

        <Label p={[2.6, 2.6, 1.4]} size={0.3} color="#fde68a">{info.sign}</Label>
        <Label p={[0, 4.9, 0.5]} size={0.32} color="#e2e8f0">{info.title}</Label>

        <Animator marks={marks} elapsed={elapsed} speed={speed} pmd={pmd} />
      </SimCanvas>
    </div>
  );
}
