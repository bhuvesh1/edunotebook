"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "parasite", label: "Parasite", kind: "select", min: 0, max: 0, step: 1, default: "scabies", options: ["scabies", "pediculosis"] },
  { key: "infest", label: "Infestation", kind: "slider", min: 0.2, max: 1.5, step: 0.1, default: 0.8, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "HIV dermatology, scabies, pediculosis",
  blurb: "Scabies mite crawling inside its skin burrow; head-louse nits cemented to a hair shaft.",
};

const SKIN = "#e8a87c";
const DERMIS = "#d9826b";

// S-curved burrow path the mite crawls along.
const BURROW = useMemoSafe();

function useMemoSafe() {
  const pts: THREE.Vector3[] = [];
  for (let i = 0; i <= 40; i++) {
    const t = i / 40;
    pts.push(new THREE.Vector3((t - 0.5) * 6, 0.42 + Math.sin(t * Math.PI) * 0.05, Math.sin(t * Math.PI * 3) * 0.5));
  }
  return new THREE.CatmullRomCurve3(pts);
}

function ScabiesMite({ infest, speed, showLabels }: { infest: number; speed: number; showLabels: boolean }) {
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const burrowTube = useMemo(() => {
    const g = new THREE.TubeGeometry(BURROW, 48, 0.16, 10, false);
    return new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: "#7c2d12", roughness: 0.6 }));
  }, []);
  useFrame((_, delta) => {
    elapsed.current += delta * speed * 0.12 * infest;
    const t = (elapsed.current % 1 + 1) % 1;
    const p = BURROW.getPointAt(t);
    const tan = BURROW.getTangentAt(t);
    if (group.current) {
      group.current.position.copy(p).y += 0.12;
      group.current.lookAt(p.clone().add(tan));
      group.current.position.y += Math.abs(Math.sin(elapsed.current * 40)) * 0.03;
    }
  });
  return (
    <group>
      {/* skin slab */}
      <mesh position={[0, -0.9, 0]} castShadow receiveShadow>
        <boxGeometry args={[8, 1.8, 4]} />
        <meshStandardMaterial color={DERMIS} roughness={0.85} />
      </mesh>
      <mesh position={[0, 0.15, 0]} castShadow>
        <boxGeometry args={[8, 0.5, 4]} />
        <meshStandardMaterial color={SKIN} roughness={0.7} />
      </mesh>
      {/* burrow tunnel */}
      <primitive object={burrowTube} />
      {/* excoriated papules along burrow */}
      {BURROW.getPoints(8).slice(1, 7).map((p, i) => (
        <mesh key={i} position={[p.x, 0.55, p.z]}>
          <sphereGeometry args={[0.14 * infest + 0.08, 12, 12]} />
          <meshStandardMaterial color="#ef4444" roughness={0.6} />
        </mesh>
      ))}
      {/* the mite: oval body + 8 legs */}
      <group ref={group}>
        <mesh castShadow>
          <sphereGeometry args={[0.22, 16, 12]} />
          <meshStandardMaterial color="#fef3c7" roughness={0.4} />
        </mesh>
        <mesh position={[0.2, 0.03, 0]} rotation={[0, 0, -Math.PI / 2]}>
          <coneGeometry args={[0.09, 0.18, 10]} />
          <meshStandardMaterial color="#fde68a" roughness={0.4} />
        </mesh>
        {Array.from({ length: 8 }).map((_, i) => {
          const side = i % 2 === 0 ? 1 : -1;
          const row = Math.floor(i / 2);
          return (
            <mesh key={i} position={[-0.05 + row * 0.09, -0.05, side * 0.2]} rotation={[side * 0.9, 0, 0.4]}>
              <cylinderGeometry args={[0.02, 0.015, 0.24, 6]} />
              <meshStandardMaterial color="#fcd34d" roughness={0.5} />
            </mesh>
          );
        })}
      </group>
      {showLabels && (
        <>
          <Text position={[0, 1.7, 0]} fontSize={0.44} color="#fef3c7">Scabies burrow (S-shaped tunnel)</Text>
          <Text position={[-4.9, 0.15, 0]} fontSize={0.4} color="#fef3c7">Epidermis</Text>
        </>
      )}
    </group>
  );
}

function Lice({ infest, speed, showLabels }: { infest: number; speed: number; showLabels: boolean }) {
  const nit = useRef<THREE.Group>(null!);
  const louse = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (nit.current) nit.current.position.y = 2.6 + Math.sin(elapsed.current * 0.8) * 0.04;
    if (louse.current) {
      louse.current.position.x = Math.sin(elapsed.current * 0.7) * 1.4;
      louse.current.rotation.y = Math.cos(elapsed.current * 0.7) * 0.5;
    }
  });
  return (
    <group>
      {/* scalp surface */}
      <mesh position={[0, -0.5, 0]} castShadow receiveShadow>
        <boxGeometry args={[8, 1, 4]} />
        <meshStandardMaterial color={DERMIS} roughness={0.85} />
      </mesh>
      {/* hair shaft */}
      <mesh position={[0, 1.6, 0]} castShadow>
        <cylinderGeometry args={[0.09, 0.09, 4.4, 12]} />
        <meshStandardMaterial color="#292524" roughness={0.4} />
      </mesh>
      {/* nits cemented to hair */}
      <group ref={nit}>
        {[0, 0.5, 1.0].map((dy, i) => (
          <group key={i} position={[0.16, dy - 0.4, 0]}>
            <mesh rotation={[0, 0, -0.5]} castShadow>
              <capsuleGeometry args={[0.11, 0.22, 6, 12]} />
              <meshStandardMaterial color={i === 1 ? "#fde68a" : "#e7e5e4"} roughness={0.35} />
            </mesh>
          </group>
        ))}
      </group>
      {/* adult louse crawling on scalp */}
      <group ref={louse} position={[0, 0.35, 0.9]}>
        <mesh castShadow scale={[1.5, 0.8, 1]}>
          <sphereGeometry args={[0.24, 16, 12]} />
          <meshStandardMaterial color="#a16207" roughness={0.5} />
        </mesh>
        {Array.from({ length: 6 }).map((_, i) => {
          const side = i % 2 === 0 ? 1 : -1;
          return (
            <mesh key={i} position={[-0.2 + Math.floor(i / 2) * 0.2, -0.1, side * 0.28]} rotation={[side * 1, 0, 0]}>
              <cylinderGeometry args={[0.025, 0.02, 0.3, 6]} />
              <meshStandardMaterial color="#713f12" roughness={0.5} />
            </mesh>
          );
        })}
        {showLabels && (
          <Text position={[0, 0.9, 0]} fontSize={0.4} color="#fef3c7">Adult louse</Text>
        )}
      </group>
      {showLabels && (
        <>
          <Text position={[2.4, 2.4, 0]} fontSize={0.42} color="#fef3c7">Nits cemented to hair shaft</Text>
          <Text position={[-4.9, -0.5, 0]} fontSize={0.4} color="#fef3c7">Scalp</Text>
        </>
      )}
    </group>
  );
}

export function Topic10331Sim(props: SimProps) {
  const parasite = String(props.parasite ?? "scabies");
  const infest = Number(props.infest ?? 0.8);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const scabies = parasite === "scabies";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Parasite", scabies ? "Sarcoptes scabiei" : "Pediculus humanus"],
          ["Sign", scabies ? "S-burrow + papules" : "Nits on hair"],
          ["Rx", scabies ? "Permethrin 5%" : "Permethrin 1%"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.6, 10]} target={[0, 0.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.6, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {scabies
          ? <ScabiesMite infest={infest} speed={speed} showLabels={showLabels} />
          : <Lice infest={infest} speed={speed} showLabels={showLabels} />}
      </SimCanvas>
    </div>
  );
}
