"use client";

// Dental insurance and financing basics.
// A clinic bill of ₹2000: the insurance card covers part, the
// patient's wallet covers the rest. Move the coverage slider to
// see who pays what.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "coverage", label: "Plan coverage", kind: "slider", min: 0, max: 100, step: 5, default: 70, unit: "%" },
];

export const UNIQUE_META = {
  title: "Dental Insurance & Financing",
  blurb: "Who pays the clinic bill? Slide the coverage and watch coins flow from the insurance card and your wallet.",
};

type P = [number, number, number];
type Ref = { current: THREE.Group | null };

const BILL: P = [2.7, 1.6, 0];
const CARD_TOP: P = [-2.7, 1.75, 0];
const WALLET_TOP: P = [-2.7, 1.5, 1.9];

function coinPath(from: P, t: number): P {
  // quadratic bezier: from -> control -> bill
  const c: P = [(from[0] + BILL[0]) / 2, Math.max(from[1], BILL[1]) + 1.6, (from[2] + BILL[2]) / 2];
  const a = (1 - t) * (1 - t);
  const b = 2 * (1 - t) * t;
  const d = t * t;
  return [a * from[0] + b * c[0] + d * BILL[0], a * from[1] + b * c[1] + d * BILL[1], a * from[2] + b * c[2] + d * BILL[2]];
}

function Animator({ ins, pat, elapsed }: { ins: Ref; pat: Ref; elapsed: { current: number } }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const e = elapsed.current;
    ins.current?.children.forEach((m, i) => {
      const n = ins.current!.children.length || 1;
      m.position.set(...coinPath(CARD_TOP, (e * 0.4 + i / n) % 1));
    });
    pat.current?.children.forEach((m, i) => {
      const n = pat.current!.children.length || 1;
      m.position.set(...coinPath(WALLET_TOP, (e * 0.4 + i / n) % 1));
    });
  });
  return null;
}

function Coin() {
  return (
    <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
      <cylinderGeometry args={[0.2, 0.2, 0.08, 16]} />
      <meshStandardMaterial color="#fbbf24" roughness={0.3} metalness={0.7} />
    </mesh>
  );
}

export function Topic10558Sim(props: SimProps) {
  const coverage = Number(props.coverage ?? 70);
  const bill = 2000;
  const insPay = Math.round((bill * coverage) / 100);
  const youPay = bill - insPay;
  const nIns = Math.round((coverage / 100) * 8);
  const nPat = 8 - nIns;

  const ins = useRef<THREE.Group>(null!);
  const pat = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Clinic bill", `₹${bill}`],
          ["Insurance pays", `₹${insPay}`],
          ["You pay", `₹${youPay}`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 12]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* insurance card */}
        <group position={[-2.7, 1.2, 0]} rotation={[0, 0.25, 0]}>
          <mesh castShadow>
            <boxGeometry args={[2.3, 0.12, 1.5]} />
            <meshStandardMaterial color="#2563eb" roughness={0.4} />
          </mesh>
          <mesh position={[0, 0.07, -0.4]}>
            <boxGeometry args={[1.8, 0.02, 0.25]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.4} />
          </mesh>
        </group>

        {/* wallet */}
        <mesh position={[-2.7, 0.85, 1.9]} castShadow>
          <boxGeometry args={[1.2, 0.7, 0.9]} />
          <meshStandardMaterial color="#92400e" roughness={0.8} />
        </mesh>

        {/* clinic bill */}
        <group position={[2.7, 0, 0]} rotation={[0, -0.2, 0]}>
          <mesh position={[0, 1.5, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[1.7, 2.3]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.9} side={THREE.DoubleSide} />
          </mesh>
          {[-0.5, -0.2, 0.1, 0.4].map((y, i) => (
            <mesh key={i} position={[0, 1.52, 0.85 - y]} rotation={[-Math.PI / 2, 0, 0]}>
              <planeGeometry args={[1.2, 0.06]} />
              <meshStandardMaterial color="#94a3b8" />
            </mesh>
          ))}
          <mesh position={[0, 0.45, -0.15]} rotation={[0.35, 0, 0]}>
            <boxGeometry args={[0.15, 1.6, 0.15]} />
            <meshStandardMaterial color="#475569" roughness={0.6} />
          </mesh>
        </group>

        {/* flowing coins */}
        <group ref={ins}>
          {Array.from({ length: nIns }).map((_, i) => (
            <Coin key={`i${i}`} />
          ))}
        </group>
        <group ref={pat}>
          {Array.from({ length: nPat }).map((_, i) => (
            <Coin key={`p${i}`} />
          ))}
        </group>

        <Label text="Dental insurance card" position={[-2.7, 2.5, 0]} size={0.45} color="#93c5fd" />
        <Label text="Your wallet" position={[-2.7, 0.1, 1.9]} size={0.42} color="#d6a05f" />
        <Label text="Clinic bill ₹2000" position={[2.7, 3.1, 0]} size={0.48} color="#e2e8f0" />
        <Label text={`Insurance pays ₹${insPay}`} position={[-1.2, 3.6, 0]} size={0.45} color="#60a5fa" />
        <Label text={`You pay ₹${youPay}`} position={[1.4, 3.0, 0]} size={0.45} color="#fbbf24" />
        <Animator ins={ins} pat={pat} elapsed={elapsed} />
      </SimCanvas>
    </div>
  );
}
