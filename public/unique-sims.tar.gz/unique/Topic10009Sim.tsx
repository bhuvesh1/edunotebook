"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Swallow speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Head and neck: pharynx, larynx, thyroid, parathyroid, salivary glands",
  blurb: "The front of the neck: the butterfly-shaped thyroid hugs the windpipe while each swallow sends food down the esophagus.",
};

function Neck({ speed }: { speed: number }) {
  const bolus = useRef<THREE.Mesh>(null!);
  const thyroid = useRef<THREE.Group>(null!);
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d * speed;
    if (bolus.current) {
      const k = (t.current * 0.45) % 1;
      bolus.current.position.y = 4.6 - k * 3.6;
      bolus.current.visible = true;
    }
    if (thyroid.current) thyroid.current.scale.setScalar(1 + Math.sin(t.current * 1.5) * 0.03);
  });
  return (
    <group position={[0, 0.4, 0]}>
      {/* neck column */}
      <mesh position={[0, 2.6, -0.4]} castShadow>
        <cylinderGeometry args={[0.85, 1.0, 5.4, 18]} />
        <meshStandardMaterial color="#f1c27d" roughness={0.7} />
      </mesh>
      {/* trachea: stacked C-rings */}
      {Array.from({ length: 9 }).map((_, i) => (
        <mesh key={i} position={[0, 1.4 + i * 0.42, 0.55]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <torusGeometry args={[0.42, 0.09, 10, 20]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.5} />
        </mesh>
      ))}
      {/* larynx (voice box) */}
      <mesh position={[0, 5.35, 0.55]} castShadow>
        <boxGeometry args={[0.7, 0.7, 0.6]} />
        <meshStandardMaterial color="#d6d3d1" roughness={0.55} />
      </mesh>
      {/* thyroid: butterfly lobes + isthmus */}
      <group ref={thyroid}>
        {[-0.52, 0.52].map((x) => (
          <mesh key={x} position={[x, 3.3, 0.75]} rotation={[0, 0, x > 0 ? -0.3 : 0.3]} castShadow>
            <sphereGeometry args={[0.42, 16, 16]} />
            <meshStandardMaterial color="#b91c1c" roughness={0.45} emissive="#7f1d1d" emissiveIntensity={0.35} />
          </mesh>
        ))}
        <mesh position={[0, 3.3, 0.78]} castShadow>
          <boxGeometry args={[0.5, 0.3, 0.3]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.45} emissive="#7f1d1d" emissiveIntensity={0.35} />
        </mesh>
        {/* parathyroids: tiny dots behind */}
        {[-0.5, 0.5].map((x) => (
          <mesh key={x} position={[x, 3.75, 0.45]}>
            <sphereGeometry args={[0.1, 10, 10]} />
            <meshStandardMaterial color="#fde68a" emissive="#f59e0b" emissiveIntensity={0.8} />
          </mesh>
        ))}
      </group>
      {/* esophagus behind trachea */}
      <mesh position={[0, 2.8, -0.15]}>
        <cylinderGeometry args={[0.3, 0.3, 4.4, 14]} />
        <meshStandardMaterial color="#fca5a5" roughness={0.6} transparent opacity={0.6} />
      </mesh>
      {/* food bolus travelling down */}
      <mesh ref={bolus} position={[0, 4.6, -0.15]}>
        <sphereGeometry args={[0.2, 12, 12]} />
        <meshStandardMaterial color="#a16207" roughness={0.7} />
      </mesh>
      {/* salivary gland hint */}
      <mesh position={[-0.9, 5.6, 0.4]} castShadow>
        <sphereGeometry args={[0.3, 14, 14]} />
        <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.9} />
      </mesh>
    </group>
  );
}

export function Topic10009Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Gland", "thyroid"], ["Airway", "trachea"], ["Swallow", "bolus ↓"]]} />
      <SimCanvas cameraPosition={[4.5, 4, 10]} target={[0, 3, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Neck speed={speed} />
        {showLabels && (
          <>
            <Label text="Thyroid (butterfly)" position={[-3.0, 4.2, 0.8]} color="#fca5a5" size={0.5} />
            <Label text="Trachea rings" position={[2.6, 2.6, 0.8]} color="#e7e5e4" size={0.5} />
            <Label text="Larynx" position={[2.4, 6.0, 0]} color="#d6d3d1" size={0.45} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
