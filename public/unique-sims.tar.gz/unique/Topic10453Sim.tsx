"use client";
// Obturation: Gutta-Percha Techniques, Sealers — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "taper", label: "Cone taper", kind: "slider", min: 0.04, max: 0.12, step: 0.01, default: 0.06 },
];

export const UNIQUE_META = {
  title: "Obturation: Gutta-Percha Techniques, Sealers",
  blurb: "A pink gutta-percha cone slides into the cleaned canal while sealer coats the walls — the 3D seal of a root filling.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const cone: any = g("cone");
    const seal: any = g("seal");
    const T = 7;
    const ph = (t % T) / T;
    if (cone) {
      const r = 0.09 + p.taper * 1.4;
      cone.scale.set(r / 0.16, 1, r / 0.16);
      if (ph < 0.55) cone.position.y = 4.6 - (4.6 - 2.15) * (ph / 0.55);
      else cone.position.y = 2.15;
    }
    if (seal) {
      const seated = ph > 0.55 ? 1 : 0;
      (seal.material as any).opacity = 0.25 + seated * (0.45 + 0.2 * Math.sin(t * 4));
    }
    group.current.rotation.y = Math.sin(t * 0.25) * 0.25;
  });
  return null;
}

export function Topic10453Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const taper = Number(props.taper ?? 0.06);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, taper };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Master cone", `0.${Math.round(taper * 100)} taper`],
          ["Sealer", "Zinc-oxide eugenol"],
          ["Speed", `${speed.toFixed(1)}×`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1, 0]} scale={1.5} showCanal name="endo" />
          <GumSlab position={[0, 0.1, 0]} scale={1.2} />
          <mesh name="cone" position={[0, 4.6, 0]}>
            <coneGeometry args={[0.16, 2.1, 12]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
          </mesh>
          <mesh name="seal" position={[0, 2.55, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.28, 0.09, 10, 20]} />
            <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.6} transparent opacity={0.3} />
          </mesh>
          <Label text="Gutta-percha cone" position={[2.2, 4.2, 0]} size={0.42} color="#f9a8d4" />
          <Label text="Sealer coating" position={[-2.3, 2.5, 0]} size={0.42} color="#fbbf24" />
          <Label text="Sealed apex" position={[2.1, 0.6, 0]} size={0.42} />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
