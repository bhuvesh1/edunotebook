"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "view", label: "Survey line", kind: "select", min: 0, max: 0, step: 1, default: "contour", options: ["contour", "undercut", "path"] },
  { key: "tilt", label: "Cast tilt", kind: "slider", min: -15, max: 15, step: 1, default: 0, unit: "°" },
];

export const UNIQUE_META = {
  title: "Removable partial dentures: surveying, design, mouth preparation",
  blurb: "A dental cast on the surveyor — the analyzing rod finds the height of contour, glowing undercuts, and the path of insertion.",
};

function Scene({ view, tilt }: { view: string; tilt: number }) {
  const rod = useRef<THREE.Group>(null!);
  const cast = useRef<THREE.Group>(null!);
  const t = useRef(0);

  useFrame((_, delta) => {
    t.current += delta;
    if (rod.current) rod.current.position.x = Math.sin(t.current * 0.9) * 1.8;
    if (cast.current) cast.current.rotation.z = (tilt * Math.PI) / 180;
  });

  const teeth: { x: number; z: number; a: number }[] = [];
  const n = 6;
  for (let i = 0; i < n; i++) {
    const a = Math.PI * (0.1 + (0.8 * i) / (n - 1));
    teeth.push({ x: Math.cos(a) * 2.2, z: Math.sin(a) * 2.2, a });
  }

  return (
    <group>
      {/* surveyor base + arm */}
      <mesh position={[0, -1.7, -1.8]}>
        <boxGeometry args={[6, 0.4, 3]} />
        <meshStandardMaterial color="#334155" metalness={0.4} roughness={0.5} />
      </mesh>
      <mesh position={[-2.8, 0.2, -1.8]}>
        <boxGeometry args={[0.35, 4, 0.35]} />
        <meshStandardMaterial color="#64748b" metalness={0.6} roughness={0.4} />
      </mesh>
      <mesh position={[-1.3, 2.1, -1.8]} rotation={[0, 0, 0.25]}>
        <boxGeometry args={[3.2, 0.3, 0.3]} />
        <meshStandardMaterial color="#64748b" metalness={0.6} roughness={0.4} />
      </mesh>
      {/* analyzing rod (moves across teeth) */}
      <group ref={rod} position={[0, 0, 0.4]}>
        <mesh position={[0, 1.1, 0]}>
          <cylinderGeometry args={[0.05, 0.05, 2.4, 8]} />
          <meshStandardMaterial color="#fbbf24" metalness={0.6} roughness={0.35} />
        </mesh>
        <mesh position={[0, -0.15, 0]}>
          <sphereGeometry args={[0.09, 10, 10]} />
          <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1} />
        </mesh>
      </group>
      <Label text="Analyzing rod" position={[2.2, 2.4, -1.4]} size={0.4} color="#fbbf24" />

      {/* cast on tilting table */}
      <group ref={cast} position={[0, -1.2, 0.4]}>
        <mesh position={[0, -0.35, 0]}>
          <cylinderGeometry args={[3.0, 3.1, 0.5, 24]} />
          <meshStandardMaterial color="#e8e4da" roughness={0.8} />
        </mesh>
        {teeth.map((tt, i) => (
          <group key={i} position={[tt.x, 0.35, tt.z]} rotation={[0, -tt.a + Math.PI / 2, 0]}>
            <mesh>
              <cylinderGeometry args={[0.3, 0.36, 0.75, 10]} />
              <meshStandardMaterial color="#f5f2e9" roughness={0.7} />
            </mesh>
            {/* height of contour line */}
            {view === "contour" && (
              <mesh position={[0, 0.1, 0]} rotation={[Math.PI / 2, 0, 0]}>
                <torusGeometry args={[0.335, 0.03, 6, 16]} />
                <meshStandardMaterial color="#38bdf8" emissive="#0ea5e9" emissiveIntensity={0.9} />
              </mesh>
            )}
            {/* undercut glow */}
            {view === "undercut" && i % 2 === 0 && (
              <mesh position={[0, -0.22, 0.2]}>
                <sphereGeometry args={[0.16, 10, 10]} />
                <meshStandardMaterial color="#f97316" emissive="#ea580c" emissiveIntensity={1} />
              </mesh>
            )}
          </group>
        ))}
        {/* path of insertion arrow */}
        {view === "path" && (
          <group position={[0, 2.2, 0]}>
            <mesh position={[0, 0.5, 0]}>
              <coneGeometry args={[0.16, 0.35, 10]} />
              <meshStandardMaterial color="#86efac" emissive="#22c55e" emissiveIntensity={0.8} />
            </mesh>
            <mesh position={[0, -0.3, 0]}>
              <cylinderGeometry args={[0.06, 0.06, 1.2, 8]} />
              <meshStandardMaterial color="#86efac" emissive="#22c55e" emissiveIntensity={0.8} />
            </mesh>
          </group>
        )}
      </group>

      <Label text={view === "contour" ? "Height of contour (survey line)" : view === "undercut" ? "Undercuts glow orange" : "Path of insertion"} position={[0, 3.4, 0]} size={0.55} color="#7dd3fc" />
      <Label text={`Cast tilted ${tilt}° — tilt changes undercuts`} position={[0, -2.9, 0]} size={0.42} color="#e2e8f0" />
    </group>
  );
}

export function Topic10434Sim(props: SimProps) {
  const view = String(props.view ?? "contour");
  const tilt = Number(props.tilt ?? 0);
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["View", view], ["Tilt", `${tilt}°`], ["Tool", "Ney surveyor"]]} />
      <SimCanvas cameraPosition={[0, 2.5, 10]} target={[0, 0.2, 0]}>
        <Scene view={view} tilt={tilt} />
      </SimCanvas>
    </div>
  );
}
