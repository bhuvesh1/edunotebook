"use client";
// Ear: otitis externa, otitis media — acute, chronic, complications.
// An ear canal cross-section: pick outer-ear infection (red, swollen
// canal) or middle-ear infection (fluid + bulging red eardrum).


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "media", options: ["externa", "media"] },
  { key: "severity", label: "Severity", kind: "slider", min: 0, max: 100, step: 5, default: 50, unit: "%" },
];

export const UNIQUE_META = {
  title: "Otitis: Outer vs Middle Ear Infection",
  blurb: "Swimmer's ear reddens the canal; middle-ear infection fills the space behind the eardrum with fluid — compare both.",
};

function Animator({ throb, elapsed, severity }: { throb: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; severity: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (throb.current) {
      throb.current.children.forEach((c, i) => {
        const s = 1 + Math.sin(elapsed.current * (2 + severity / 40) + i * 1.7) * 0.07 * (0.4 + severity / 100);
        c.scale.set(s, s, s);
      });
    }
  });
  return null;
}

export function Topic10185Sim(props: SimProps) {
  const condition = String(props.condition ?? "media");
  const severity = Number(props.severity ?? 50);
  const throb = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const isMedia = condition === "media";
  const fluidLevel = isMedia ? severity / 100 : 0;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", isMedia ? "otitis media" : "otitis externa"], ["Pain", severity > 66 ? "severe" : severity > 33 ? "moderate" : "mild"]]} />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[-1, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* outer ear */}
        <group position={[-5.6, 3, 0]}>
          <mesh castShadow>
            <torusGeometry args={[1, 0.4, 12, 24]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.65} />
          </mesh>
          <Label text="OUTER EAR" position={[0, 1.9, 0]} size={0.5} color="#fcd9b8" />
        </group>
        {/* ear canal — inflamed in externa */}
        <group ref={throb}>
          <mesh position={[-3.4, 3, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.55 + (!isMedia ? severity / 400 : 0), 0.55 + (!isMedia ? severity / 400 : 0), 2.6, 14, 1, true]} />
            <meshStandardMaterial
              color={!isMedia ? "#f87171" : "#e8b58e"}
              transparent
              opacity={0.6}
              roughness={0.6}
              side={THREE.DoubleSide}
              emissive={!isMedia ? "#ef4444" : "#000000"}
              emissiveIntensity={!isMedia ? severity / 150 : 0}
            />
          </mesh>
          {/* eardrum — bulging red in media */}
          <mesh position={[-1.9, 3, 0]} rotation={[0, Math.PI / 2, 0]}>
            <sphereGeometry args={[0.55, 18, 14, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <meshStandardMaterial
              color={isMedia ? "#f87171" : "#d1d5db"}
              roughness={0.4}
              emissive={isMedia ? "#ef4444" : "#000000"}
              emissiveIntensity={isMedia ? severity / 150 : 0}
              side={THREE.DoubleSide}
            />
          </mesh>
        </group>
        <Label text="EAR CANAL" position={[-3.4, 4.2, 0]} size={0.5} color={!isMedia ? "#f87171" : "#e8b58e"} />
        <Label text="EARDRUM" position={[-1.9, 4.2, 0]} size={0.5} color={isMedia ? "#f87171" : "#d1d5db"} />
        {/* middle ear cavity with fluid */}
        <group position={[0, 3, 0]}>
          <mesh>
            <boxGeometry args={[2.6, 2.2, 1.6]} />
            <meshStandardMaterial color="#1e293b" transparent opacity={0.45} roughness={0.7} />
          </mesh>
          {fluidLevel > 0.02 && (
            <mesh position={[0, -1.1 + fluidLevel * 1.05, 0]}>
              <boxGeometry args={[2.4, fluidLevel * 2.1, 1.4]} />
              <meshStandardMaterial color="#fbbf24" transparent opacity={0.75} roughness={0.35} emissive="#f59e0b" emissiveIntensity={0.3} />
            </mesh>
          )}
          {/* ossicles */}
          {[[-0.6], [0], [0.6]].map(([x], i) => (
            <mesh key={x} position={[x, 0.5, 0]} rotation={[0, 0, 0.3 - i * 0.3]} castShadow>
              <capsuleGeometry args={[0.12, 0.35, 4, 8]} />
              <meshStandardMaterial color="#fef3c7" roughness={0.5} />
            </mesh>
          ))}
          <Label text="MIDDLE EAR" position={[0, 1.7, 0]} size={0.5} color="#fcd34d" />
          {isMedia && fluidLevel > 0.02 && (
            <Label text="FLUID / PUS" position={[0, -1.6, 0]} size={0.5} color="#fbbf24" />
          )}
        </group>
        {/* germs */}
        {Array.from({ length: 6 }, (_, i) => (
          <mesh key={i} position={[-3.4 + Math.sin(i * 2.4) * 0.8, 3 + Math.cos(i * 3.1) * 0.6, 0.4]}>
            <icosahedronGeometry args={[0.16, 0]} />
            <meshStandardMaterial color="#4ade80" emissive="#22c55e" emissiveIntensity={0.7} flatShading />
          </mesh>
        ))}
        <Label text={isMedia ? "OTITIS MEDIA: infection behind the drum" : "OTITIS EXTERNA: swimmer's ear"} position={[-1.5, 5.6, 0]} size={0.6} color="#f87171" />
        <Animator throb={throb} elapsed={elapsed} severity={severity} />
      </SimCanvas>
    </div>
  );
}
