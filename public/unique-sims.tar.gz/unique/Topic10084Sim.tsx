"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "adapt", label: "Adaptation", kind: "select", min: 0, max: 0, step: 1, default: "hypertrophy", options: ["hypertrophy", "hyperplasia", "atrophy", "metaplasia"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Cellular Adaptations",
  blurb: "Four cells adapt four ways: growing bigger, multiplying, shrinking, or changing shape entirely.",
};

function Animator({ root, a1, a2, a3, a4, elapsed, speed }: { root: RefObject<THREE.Group>; a1: RefObject<THREE.Mesh>; a2: RefObject<THREE.Group>; a3: RefObject<THREE.Mesh>; a4: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const q = (t * 0.4) % 1;
    const e = q < 0.5 ? q * 2 : (1 - q) * 2;
    if (a1.current) a1.current.scale.setScalar(0.8 + e * 0.8);
    if (a2.current) {
      a2.current.children.forEach((m, i) => {
        m.position.x = -1.5 + (i === 0 ? -1 : 1) * Math.min(0.75, e * 0.9);
        m.scale.setScalar(1 - Math.min(0.3, e * 0.35));
      });
    }
    if (a3.current) a3.current.scale.setScalar(1.1 - e * 0.55);
    if (a4.current) {
      a4.current.scale.set(1.15 - e * 0.55, 0.8 + e * 0.9, 1.15 - e * 0.55);
      (a4.current.material as THREE.MeshStandardMaterial).color.set(e > 0.5 ? "#f472b6" : "#60a5fa");
    }
  });
  return null;
}

export function Topic10084Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const adapt = String(props.adapt ?? "hypertrophy");
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const a1 = useRef<THREE.Mesh>(null!);
  const a2 = useRef<THREE.Group>(null!);
  const a3 = useRef<THREE.Mesh>(null!);
  const a4 = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Adaptation", adapt],
          ["Trigger", adapt === "hypertrophy" ? "increased workload" : adapt === "hyperplasia" ? "growth factors" : adapt === "atrophy" ? "disuse / denervation" : "chronic irritation"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh ref={a1} position={[-4.8, 1.8, 0]} castShadow>
            <sphereGeometry args={[0.8, 22, 22]} /><meshStandardMaterial color="#f87171" roughness={0.45} />
          </mesh>
          <Label text="hypertrophy \u2014 bigger" position={[-4.8, 3.3, 0]} size={0.42} color="#f87171" />
          <group ref={a2}>
            <mesh position={[-1.5, 1.8, 0]} castShadow><sphereGeometry args={[0.8, 22, 22]} /><meshStandardMaterial color="#4ade80" roughness={0.45} /></mesh>
            <mesh position={[-1.5, 1.8, 0]} castShadow><sphereGeometry args={[0.8, 22, 22]} /><meshStandardMaterial color="#4ade80" roughness={0.45} /></mesh>
          </group>
          <Label text="hyperplasia \u2014 more cells" position={[-1.5, 3.3, 0]} size={0.42} color="#4ade80" />
          <mesh ref={a3} position={[1.8, 1.8, 0]} castShadow>
            <sphereGeometry args={[0.8, 22, 22]} /><meshStandardMaterial color="#facc15" roughness={0.45} />
          </mesh>
          <Label text="atrophy \u2014 shrinks" position={[1.8, 3.3, 0]} size={0.42} color="#facc15" />
          <mesh ref={a4} position={[4.8, 1.8, 0]} castShadow>
            <boxGeometry args={[1.4, 1.4, 1.4]} /><meshStandardMaterial color="#60a5fa" roughness={0.45} />
          </mesh>
          <Label text="metaplasia \u2014 changes type" position={[4.8, 3.3, 0]} size={0.42} color="#93c5fd" />
          <Label text={`spotlight: ${adapt}`} position={[0, 4.4, 0]} size={0.45} color="#f8fafc" />
        </group>
        <Animator root={root} a1={a1} a2={a2} a3={a3} a4={a4} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
