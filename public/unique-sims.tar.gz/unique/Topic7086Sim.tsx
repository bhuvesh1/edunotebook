// app/components/sims/unique/Topic7086Sim.tsx
// The four fundamental forces, each demoed live on its own pedestal:
// gravity (orbiting moon), electromagnetism (attracting charges),
// strong force (jiggling quarks locked in a nucleus), weak force
// (a neutron periodically decaying into proton + electron).

"use client";

import { useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Fundamental Forces in Nature",
  blurb: "Gravity, electromagnetism, the strong and weak nuclear forces — each one acting out on its own pedestal.",
};

const STATIONS = [
  { x: -5.4, color: "#38bdf8" }, // gravity
  { x: -1.8, color: "#facc15" }, // electromagnetism
  { x: 1.8, color: "#a78bfa" }, // strong
  { x: 5.4, color: "#f87171" }, // weak
];

function Animator({
  orbit,
  chargeA,
  chargeB,
  link,
  quarks,
  neutron,
  proton,
  electron,
  flash,
  speed,
  bump,
}: {
  orbit: RefObject<THREE.Group>;
  chargeA: RefObject<THREE.Mesh>;
  chargeB: RefObject<THREE.Mesh>;
  link: RefObject<THREE.Mesh>;
  quarks: RefObject<THREE.Group>;
  neutron: RefObject<THREE.Mesh>;
  proton: RefObject<THREE.Mesh>;
  electron: RefObject<THREE.Mesh>;
  flash: RefObject<THREE.Mesh>;
  speed: number;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta * speed;
    const T = t.current;
    if (orbit.current) orbit.current.rotation.y = T * 0.7;
    // EM: opposite charges breathe toward/away from each other.
    const sep = 0.85 + 0.4 * Math.sin(T * 1.5);
    if (chargeA.current) chargeA.current.position.x = -1.8 - sep;
    if (chargeB.current) chargeB.current.position.x = -1.8 + sep;
    if (link.current) {
      link.current.scale.x = Math.max(sep * 2, 0.01);
      link.current.position.x = -1.8;
    }
    // Strong: quarks jiggle but never escape the nucleus.
    if (quarks.current) {
      quarks.current.children.forEach((q, i) => {
        q.position.set(
          Math.cos(T * 5 + i * 2.1) * 0.2,
          0.75 + Math.sin(T * 6.2 + i * 1.4) * 0.12,
          Math.sin(T * 5 + i * 2.1) * 0.2
        );
      });
    }
    // Weak: 7 s cycle, neutron decays in the last 2.5 s.
    const p = T % 7;
    const split = p > 4.5;
    if (neutron.current) neutron.current.visible = !split;
    if (proton.current) proton.current.visible = split;
    if (electron.current) {
      electron.current.visible = split;
      if (split) electron.current.position.set(5.4 + (p - 4.5) * 1.6, 0.75 + (p - 4.5) * 0.7, 0);
    }
    if (flash.current) {
      const f = split ? Math.max(0, 1 - (p - 4.5) / 1.2) : 0;
      flash.current.visible = f > 0;
      flash.current.scale.setScalar(0.3 + (1 - f) * 1.4);
      (flash.current.material as THREE.MeshStandardMaterial).opacity = f * 0.7;
    }
    if (++n.current % 30 === 0) bump();
  });
  return null;
}

export function Topic7086Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const orbit = useRef<THREE.Group>(null!);
  const chargeA = useRef<THREE.Mesh>(null!);
  const chargeB = useRef<THREE.Mesh>(null!);
  const link = useRef<THREE.Mesh>(null!);
  const quarks = useRef<THREE.Group>(null!);
  const neutron = useRef<THREE.Mesh>(null!);
  const proton = useRef<THREE.Mesh>(null!);
  const electron = useRef<THREE.Mesh>(null!);
  const flash = useRef<THREE.Mesh>(null!);
  const [, bump] = useState(0);

  const orbitRing = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 64; i++) {
      const a = (i / 64) * Math.PI * 2;
      pts.push(new THREE.Vector3(Math.cos(a) * 1.1, 0.75, Math.sin(a) * 1.1));
    }
    return new THREE.Line(
      new THREE.BufferGeometry().setFromPoints(pts),
      new THREE.LineBasicMaterial({ color: "#38bdf8", transparent: true, opacity: 0.35 })
    );
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["🌍 Gravity", "moon orbits Earth"],
          ["⚡ Electromagnetism", "+ and − attract"],
          ["🔴🟢🔵 Strong", "locks quarks together"],
          ["☢️ Weak", "neutron decays"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 6.5, 14]} target={[0, 1, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {STATIONS.map((s, i) => (
          <mesh key={i} position={[s.x, 0.14, 0]} receiveShadow>
            <cylinderGeometry args={[1.35, 1.55, 0.28, 24]} />
            <meshStandardMaterial color="#1e293b" roughness={0.8} />
          </mesh>
        ))}

        {/* GRAVITY: Earth + orbiting moon */}
        <mesh position={[-5.4, 0.75, 0]} castShadow>
          <sphereGeometry args={[0.55, 32, 32]} />
          <meshStandardMaterial color="#3b82f6" roughness={0.5} />
        </mesh>
        <group position={[-5.4, 0, 0]}>
          <primitive object={orbitRing} />
          <group ref={orbit}>
            <mesh position={[1.1, 0.75, 0]} castShadow>
              <sphereGeometry args={[0.22, 24, 24]} />
              <meshStandardMaterial color="#cbd5e1" roughness={0.6} />
            </mesh>
          </group>
        </group>

        {/* ELECTROMAGNETISM: + and − charges attracting */}
        <mesh ref={chargeA} position={[-2.65, 0.75, 0]} castShadow>
          <sphereGeometry args={[0.4, 32, 32]} />
          <meshStandardMaterial color="#ef4444" roughness={0.4} emissive="#7f1d1d" emissiveIntensity={0.6} />
        </mesh>
        <mesh ref={chargeB} position={[-0.95, 0.75, 0]} castShadow>
          <sphereGeometry args={[0.4, 32, 32]} />
          <meshStandardMaterial color="#3b82f6" roughness={0.4} emissive="#1e3a8a" emissiveIntensity={0.6} />
        </mesh>
        <mesh ref={link} position={[-1.8, 0.75, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.05, 0.05, 1, 8]} />
          <meshStandardMaterial color="#fde047" emissive="#fde047" emissiveIntensity={0.9} transparent opacity={0.85} />
        </mesh>

        {/* STRONG: three quarks jiggling inside a nucleus */}
        <group ref={quarks} position={[1.8, 0, 0]}>
          {["#ef4444", "#22c55e", "#3b82f6"].map((c, i) => (
            <mesh key={i} position={[0, 0.75, 0]} castShadow>
              <sphereGeometry args={[0.24, 24, 24]} />
              <meshStandardMaterial color={c} roughness={0.4} />
            </mesh>
          ))}
        </group>
        <mesh position={[1.8, 0.75, 0]}>
          <sphereGeometry args={[0.62, 32, 32]} />
          <meshStandardMaterial color="#a78bfa" transparent opacity={0.16} roughness={0.2} />
        </mesh>

        {/* WEAK: neutron that periodically decays */}
        <mesh ref={neutron} position={[5.4, 0.75, 0]} castShadow>
          <sphereGeometry args={[0.42, 32, 32]} />
          <meshStandardMaterial color="#94a3b8" roughness={0.45} />
        </mesh>
        <mesh ref={proton} position={[5.4, 0.75, 0]} visible={false} castShadow>
          <sphereGeometry args={[0.4, 32, 32]} />
          <meshStandardMaterial color="#ef4444" roughness={0.4} />
        </mesh>
        <mesh ref={electron} position={[5.4, 0.75, 0]} visible={false}>
          <sphereGeometry args={[0.16, 20, 20]} />
          <meshStandardMaterial color="#60a5fa" emissive="#2563eb" emissiveIntensity={1} />
        </mesh>
        <mesh ref={flash} position={[5.4, 0.75, 0]} visible={false}>
          <sphereGeometry args={[0.5, 24, 24]} />
          <meshStandardMaterial color="#fef08a" transparent opacity={0.7} emissive="#fde047" emissiveIntensity={1} />
        </mesh>

        <Animator
          orbit={orbit} chargeA={chargeA} chargeB={chargeB} link={link}
          quarks={quarks} neutron={neutron} proton={proton}
          electron={electron} flash={flash} speed={speed}
          bump={() => bump((v) => v + 1)}
        />
      </SimCanvas>
    </div>
  );
}
