// Respiratory: hypoxia, high altitude & deep-sea — a mountain whose summit air
// thins with altitude; the oxygen–hemoglobin curve shifts and the climber's
// saturation dial drops; a diver descends on the other side.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "altitude", label: "Altitude", kind: "slider", min: 0, max: 8000, step: 250, default: 0, unit: "m" },
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "altitude", options: ["altitude", "exercise", "fetal"] },
];

export const UNIQUE_META = {
  title: "Respiratory: Hypoxia & Altitude",
  blurb: "Climb higher and the air thins — the Hb–O₂ curve shifts and saturation falls. Exercise and fetal Hb shift it too.",
};

const CONDITIONS: Record<string, { shift: number; note: string }> = {
  altitude: { shift: 0, note: "low PO₂ → desaturation" },
  exercise: { shift: 1, note: "↑CO₂, ↓pH, ↑temp → right shift: O₂ unloads" },
  fetal: { shift: -1, note: "fetal HbF → left shift: grabs O₂ tighter" },
};

function Animator({
  o2dots, flag, diver, elapsed, speed,
}: {
  o2dots: React.RefObject<THREE.Group>;
  flag: React.RefObject<THREE.Mesh>;
  diver: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (o2dots.current) {
      o2dots.current.children.forEach((m, i) => {
        m.position.y += Math.sin(t * 2 + i * 1.7) * delta * 0.6;
        m.rotation.y += delta;
      });
    }
    if (flag.current) flag.current.rotation.y = Math.sin(t * 5) * 0.25;
    if (diver.current) diver.current.position.y = -1.6 + Math.sin(t * 0.9) * 0.35;
  });
  return null;
}

export function Topic10042Sim(props: SimProps) {
  const altitude = Number(props.altitude ?? 0);
  const condition = String(props.condition ?? "altitude");
  const speed = 1;
  const o2dots = useRef<THREE.Group>(null!);
  const flag = useRef<THREE.Mesh>(null!);
  const diver = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const cond = CONDITIONS[condition] ?? CONDITIONS.altitude;

  // barometric pressure falls with altitude; alveolar PO2 approx
  const po2 = Math.max(20, 100 * Math.exp(-altitude / 7000));
  const p50 = 26 * (cond.shift > 0 ? 1.35 : cond.shift < 0 ? 0.72 : 1);
  const sat = Math.round((100 * Math.pow(po2, 2.8)) / (Math.pow(p50, 2.8) + Math.pow(po2, 2.8)));
  const o2count = Math.max(2, Math.round(12 * (po2 / 100)));

  const curvePts = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 60; i++) {
      const p = (i / 60) * 120;
      const s = (100 * Math.pow(p, 2.8)) / (Math.pow(p50, 2.8) + Math.pow(p, 2.8));
      pts.push(new THREE.Vector3(-4 + (p / 120) * 8, 0.4 + (s / 100) * 3.2, 0));
    }
    return pts;
  }, [p50]);
  const curveObj = useMemo(
    () =>
      new THREE.Mesh(
        new THREE.TubeGeometry(new THREE.CatmullRomCurve3(curvePts), 60, 0.05, 8, false),
        new THREE.MeshBasicMaterial({ color: "#38bdf8" })
      ),
    [curvePts]
  );
  const curveShift = cond.shift > 0 ? "right shift" : cond.shift < 0 ? "left shift" : "normal position";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Alveolar PO₂", `~${Math.round(po2)} mmHg`],
          ["SaO₂", `${sat}% — ${cond.note}`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 16]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[42, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* mountain */}
        <group position={[-6.5, 0, -2]}>
          <mesh castShadow>
            <coneGeometry args={[4.2, 7.5, 4]} />
            <meshStandardMaterial color="#475569" roughness={0.8} flatShading />
          </mesh>
          <mesh position={[0, 6.2, 0]}>
            <coneGeometry args={[1.35, 2.6, 4]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.6} flatShading />
          </mesh>
          {/* flag at summit */}
          <mesh position={[0, 7.6, 0]}>
            <cylinderGeometry args={[0.05, 0.05, 1.6, 8]} />
            <meshStandardMaterial color="#92400e" />
          </mesh>
          <mesh ref={flag} position={[0.45, 8.1, 0]}>
            <boxGeometry args={[0.9, 0.5, 0.05]} />
            <meshStandardMaterial color="#ef4444" side={THREE.DoubleSide} />
          </mesh>
          {/* climber partway up by altitude */}
          <mesh position={[1.8 - (altitude / 8000) * 2.6, 1.2 + (altitude / 8000) * 5.2, 1.2]} castShadow>
            <capsuleGeometry args={[0.22, 0.7, 6, 10]} />
            <meshStandardMaterial color="#f97316" roughness={0.5} />
          </mesh>
        </group>
        {/* thinning O2 dots near summit */}
        <group ref={o2dots}>
          {Array.from({ length: 12 }).map((_, i) => (
            <mesh key={i} position={[-6.5 + ((i * 1.7) % 5 - 2.5), 3 + ((i * 2.3) % 5), -1 + (i % 3)]}
              visible={i < o2count}>
              <sphereGeometry args={[0.13, 8, 8]} />
              <meshBasicMaterial color="#38bdf8" />
            </mesh>
          ))}
        </group>
        <Label text={`Everest region — ${altitude} m`} position={[-6.5, 8.6, -2]} size={0.36} color="#f8fafc" />
        <Label text="air thins: fewer O₂ molecules" position={[-6.5, 1.0, 1.5]} size={0.3} color="#7dd3fc" />

        {/* Hb-O2 dissociation curve */}
        <group position={[3.5, 0, 0]}>
          {/* axes */}
          <mesh position={[0, 0.4, 0]}>
            <boxGeometry args={[8.4, 0.06, 0.06]} />
            <meshStandardMaterial color="#64748b" />
          </mesh>
          <mesh position={[-4, 2.0, 0]}>
            <boxGeometry args={[0.06, 3.6, 0.06]} />
            <meshStandardMaterial color="#64748b" />
          </mesh>
          <primitive object={curveObj} />
          {/* current operating point */}
          <mesh position={[-4 + (Math.min(po2, 120) / 120) * 8, 0.4 + (sat / 100) * 3.2, 0]}>
            <sphereGeometry args={[0.14, 10, 10]} />
            <meshBasicMaterial color="#fef08a" />
          </mesh>
          <Label text="PO₂ (mmHg)" position={[4.3, 0.15, 0]} size={0.3} color="#94a3b8" />
          <Label text="SaO₂ %" position={[-4.6, 3.9, 0]} size={0.3} color="#94a3b8" />
        </group>
        <Label text={`Hb–O₂ curve: ${curveShift}`} position={[3.5, 4.6, 0]} size={0.38} color="#f8fafc" />
        <Label text={`P50 = ${p50.toFixed(0)} mmHg`} position={[3.5, -0.6, 0]} size={0.3} color="#7dd3fc" />

        {/* diver for deep-sea */}
        <group ref={diver} position={[8.6, 0, 1.5]}>
          <mesh position={[0, -1.6, 0]} castShadow>
            <capsuleGeometry args={[0.25, 0.9, 6, 10]} />
            <meshStandardMaterial color="#0ea5e9" roughness={0.5} />
          </mesh>
          <mesh position={[0.35, -1.2, 0]}>
            <boxGeometry args={[0.5, 0.35, 0.3]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.4} />
          </mesh>
          {/* bubbles rising */}
          {[0, 1, 2].map((i) => (
            <mesh key={i} position={[-0.3 + i * 0.25, -0.6 + i * 0.45, 0]}>
              <sphereGeometry args={[0.09 + i * 0.03, 8, 8]} />
              <meshStandardMaterial color="#bae6fd" transparent opacity={0.7} />
            </mesh>
          ))}
        </group>
        {/* water */}
        <mesh position={[8.6, -1.2, 1.5]}>
          <boxGeometry args={[3.6, 2.4, 2.4]} />
          <meshStandardMaterial color="#0369a1" transparent opacity={0.25} roughness={0.2} />
        </mesh>
        <Label text="deep-sea: ↑pressure, N₂ narcosis risk" position={[8.6, 0.6, 1.5]} size={0.3} color="#7dd3fc" />

        <Animator o2dots={o2dots} flag={flag} diver={diver} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
