"use client";
// Cleft Lip and Palate — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Treatment stage", kind: "slider", min: 0, max: 3, step: 1, default: 1 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Cleft Lip and Palate",
  blurb: "The palate has a gap down the middle — slide the stage to watch an orthopedic plate guide it closed.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const gap = (3 - p.stage) * 0.55;
    const l: any = g("palL");
    const r: any = g("palR");
    if (l) l.position.x += (-1.9 - gap / 2 - l.position.x) * 0.08;
    if (r) r.position.x += (1.9 + gap / 2 - r.position.x) * 0.08;
    const nam: any = g("nam");
    if (nam) nam.visible = p.stage >= 1 && p.stage < 3;
    const lip: any = g("liprepair");
    if (lip) (lip.material as any).opacity = p.stage === 3 ? 0.9 : 0.25;
    group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
  });
  return null;
}

export function Topic10473Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const stage = Number(props.stage ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, stage };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", ["Cleft open", "NAM plate", "Closing", "Closed"][stage]],
          ["Cleft gap", `${((3 - stage) * 4).toFixed(0)} mm`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <group name="palL" position={[-2.2, 2.2, 0]}>
            <mesh rotation={[0, 0, Math.PI / 2]}>
              <torusGeometry args={[1.6, 0.55, 12, 20, Math.PI]} />
              <meshStandardMaterial color="#e0808f" roughness={0.6} />
            </mesh>
          </group>
          <group name="palR" position={[2.2, 2.2, 0]}>
            <mesh rotation={[0, 0, -Math.PI / 2]}>
              <torusGeometry args={[1.6, 0.55, 12, 20, Math.PI]} />
              <meshStandardMaterial color="#e0808f" roughness={0.6} />
            </mesh>
          </group>
          <mesh name="nam" position={[0, 2.2, 0]}>
            <cylinderGeometry args={[1.5, 1.5, 0.25, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.4} transparent opacity={0.85} />
          </mesh>
          <mesh name="liprepair" position={[0, 0.9, 1.2]}>
            <boxGeometry args={[2.2, 0.5, 0.2]} />
            <meshStandardMaterial color="#f4a7b9" roughness={0.5} transparent opacity={0.25} />
          </mesh>
          <Label text="Cleft in palate" position={[0, 4.4, 0]} size={0.44} color="#ef4444" />
          <Label text="NAM molding plate" position={[0, 1.3, 0]} size={0.4} color="#f9a8d4" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
