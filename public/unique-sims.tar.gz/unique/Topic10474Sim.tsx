"use client";
// Orthognathic Surgery: Orthodontic Preparation — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "move", label: "Jaw movement", kind: "slider", min: -5, max: 8, step: 0.5, default: 4, unit: " mm" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Orthognathic Surgery: Orthodontic Preparation",
  blurb: "Jaw surgery planned on screen — slide the jaw forward or back along the surgical cut line.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const jaw: any = g("surgjaw");
    if (jaw) jaw.position.z = (p.move / 8) * 1.2;
    const cut: any = g("cutline");
    if (cut) (cut.material as any).opacity = 0.5 + 0.3 * Math.sin(t * 3);
    group.current.rotation.y = -0.5 + Math.sin(t * 0.25) * 0.15;
  });
  return null;
}

export function Topic10474Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const move = Number(props.move ?? 4);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, move };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Planned move", `${move > 0 ? "+" : ""}${move} mm`],
          ["Cut", "Bilateral sagittal split"],
          ["Direction", move >= 0 ? "Advancement" : "Setback"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <mesh position={[0.4, 3.8, 0]}>
            <sphereGeometry args={[1.5, 24, 24]} />
            <meshStandardMaterial color="#e8e0cf" roughness={0.6} />
          </mesh>
          <mesh position={[-0.5, 2.7, 0]}>
            <boxGeometry args={[1.7, 0.8, 1.2]} />
            <meshStandardMaterial color="#ded3ba" roughness={0.6} />
          </mesh>
          <Label text="Upper jaw (fixed)" position={[1.9, 3, 0]} size={0.42} />
          <group name="surgjaw" position={[0, 1.7, 0]}>
            <mesh position={[-0.6, 0, 0]}>
              <boxGeometry args={[2, 0.5, 1.1]} />
              <meshStandardMaterial color="#d3c7ab" roughness={0.6} />
            </mesh>
            <mesh position={[-1.5, 0.5, 0]}>
              <boxGeometry args={[0.4, 0.9, 1]} />
              <meshStandardMaterial color="#d3c7ab" roughness={0.6} />
            </mesh>
          </group>
          <mesh name="cutline" position={[-1.5, 2.2, 0]} rotation={[0, 0, 0.35]}>
            <boxGeometry args={[0.08, 1.1, 1.15]} />
            <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.8} transparent opacity={0.6} />
          </mesh>
          <Arrow from={[-0.6, 1.7, 1.3]} to={[-0.6, 1.7, 0.4]} color="#38bdf8" />
          <Label text="Surgical cut line" position={[-2.9, 2.2, 0]} size={0.42} color="#ef4444" />
          <Label text="Lower jaw slides to new position" position={[0, 0.7, 0]} size={0.42} color="#38bdf8" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
