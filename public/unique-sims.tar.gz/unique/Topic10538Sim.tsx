// app/components/sims/unique/Topic10538Sim.tsx
// Pulp therapy in primary teeth: cross-section of a baby tooth showing
// enamel, dentin, and pulp. Pulpotomy removes the coronal pulp; pulpectomy
// cleans the full root canals with files.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "proc", label: "Procedure", kind: "select", min: 0, max: 0, step: 1, default: "pulpotomy", options: ["pulpotomy", "pulpectomy"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Pulp Therapy in Primary Teeth",
  blurb: "Peek inside a baby tooth: pulpotomy treats the crown pulp, pulpectomy cleans the whole root canal.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ files, elapsed, speed, proc }: {
  files: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; proc: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (files.current) {
      files.current.visible = proc === "pulpectomy";
      files.current.children.forEach((c, i) => {
        c.position.y = 1.6 + 0.5 * Math.abs(Math.sin(t * 3 + i * 1.5));
        c.rotation.y = t * 8;
      });
    }
  });
  return null;
}

const INFO: Record<string, { what: string; when: string }> = {
  pulpotomy: { what: "coronal pulp removed, radicular pulp kept vital", when: "deep caries, no root infection" },
  pulpectomy: { what: "all pulp removed, canals cleaned + filled", when: "infected / non-vital pulp" },
};

export function Topic10538Sim(props: SimProps) {
  const proc = String(props.proc ?? "pulpotomy");
  const speed = Number(props.speed ?? 1);
  const files = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = INFO[proc];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Procedure", proc],
          ["Does", info.what],
          ["Indicated", info.when],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* tooth cross-section: half-cut so layers are visible */}
        <group position={[0, 0, 0]}>
          {/* dentin core */}
          <mesh position={[0, 2.6, 0]} castShadow>
            <boxGeometry args={[2.2, 1.8, 1.6]} />
            <meshStandardMaterial color="#fde68a" roughness={0.5} />
          </mesh>
          {/* enamel cap */}
          <mesh position={[0, 3.35, 0]} castShadow>
            <boxGeometry args={[2.4, 0.5, 1.8]} />
            <meshStandardMaterial color="#ffffff" roughness={0.25} />
          </mesh>
          {/* roots */}
          {[-0.55, 0.55].map((x, i) => (
            <mesh key={i} position={[x, 1.0, 0]} rotation={[Math.PI, 0, 0]} castShadow>
              <coneGeometry args={[0.42, 1.8, 12]} />
              <meshStandardMaterial color="#fde68a" roughness={0.5} />
            </mesh>
          ))}

          {/* pulp chamber + canals (red); treatment changes them */}
          {proc === "pulpotomy" ? (
            <>
              {/* coronal pulp removed -> gray medicament */}
              <mesh position={[0, 2.9, 0.85]}>
                <boxGeometry args={[1.1, 0.7, 0.25]} />
                <meshStandardMaterial color="#94a3b8" roughness={0.6} />
              </mesh>
              {/* radicular pulp stays vital (red) */}
              {[-0.55, 0.55].map((x, i) => (
                <mesh key={i} position={[x, 1.1, 0.85]}>
                  <cylinderGeometry args={[0.12, 0.12, 1.3, 10]} />
                  <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.5} roughness={0.4} />
                </mesh>
              ))}
              <Label p={[2.6, 2.9, 0.9]} size={0.3} color="#94a3b8">medicament (MTA)</Label>
              <Label p={[2.6, 1.1, 0.9]} size={0.3} color="#fca5a5">vital root pulp kept</Label>
            </>
          ) : (
            <>
              {/* all pulp removed -> canals filled (orange paste) */}
              {[-0.55, 0.55].map((x, i) => (
                <mesh key={i} position={[x, 1.1, 0.85]}>
                  <cylinderGeometry args={[0.12, 0.12, 1.3, 10]} />
                  <meshStandardMaterial color="#fb923c" emissive="#ea580c" emissiveIntensity={0.4} roughness={0.5} />
                </mesh>
              ))}
              <mesh position={[0, 2.9, 0.85]}>
                <boxGeometry args={[1.1, 0.7, 0.25]} />
                <meshStandardMaterial color="#fb923c" emissive="#ea580c" emissiveIntensity={0.4} roughness={0.5} />
              </mesh>
              <Label p={[2.8, 2.0, 0.9]} size={0.3} color="#fdba74">canals cleaned + filled</Label>
            </>
          )}

          {/* endodontic files working the canals (pulpectomy) */}
          <group ref={files} visible={false}>
            {[-0.55, 0.55].map((x, i) => (
              <group key={i} position={[x, 1.6, 0.85]}>
                <mesh>
                  <cylinderGeometry args={[0.05, 0.02, 1.8, 8]} />
                  <meshStandardMaterial color="#e2e8f0" metalness={0.8} roughness={0.3} />
                </mesh>
                <mesh position={[0, 1.05, 0]}>
                  <cylinderGeometry args={[0.09, 0.09, 0.35, 8]} />
                  <meshStandardMaterial color={i === 0 ? "#ef4444" : "#3b82f6"} roughness={0.5} />
                </mesh>
              </group>
            ))}
          </group>
        </group>

        <Label p={[-3.0, 3.35, 0]} size={0.3} color="#ffffff">enamel</Label>
        <Label p={[-3.0, 2.6, 0]} size={0.3} color="#fde68a">dentin</Label>
        <Label p={[-3.0, 1.7, 0]} size={0.3} color="#fca5a5">pulp</Label>
        <Label p={[0, 0.1, 0]} size={0.32} color="#e2e8f0">baby tooth cross-section — {proc}</Label>

        <Animator files={files} elapsed={elapsed} speed={speed} proc={proc} />
      </SimCanvas>
    </div>
  );
}
