// Obstetrics: abortions, ectopic pregnancy, gestational trophoblastic disease.
// The embryo must implant inside the uterus. Watch it land in the wrong place
// — stuck in the fallopian tube (ectopic) — or grow into a cluster of
// grape-like molar vesicles.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "ectopic", options: ["normal", "ectopic", "molar", "miscarriage"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Wrong Implantation: Ectopic & Molar",
  blurb: "The embryo must reach the uterus — see it stuck in the tube (ectopic), turned into molar grapes, or lost in miscarriage.",
};

function Animator({
  group, embryo, marker, elapsed, speed, condition,
}: {
  group: React.RefObject<THREE.Group>;
  embryo: React.RefObject<THREE.Group>;
  marker: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    if (embryo.current) {
      // embryo drifts; in miscarriage it falls out
      if (condition === "miscarriage") {
        const cyc = (t % 8) / 8;
        embryo.current.position.y = 2.0 - cyc * cyc * 2.4;
        embryo.current.position.z = 0.2 + cyc * 0.5;
      } else {
        embryo.current.position.y = 2.0 + Math.sin(t * 1.4) * 0.05;
      }
    }
    if (marker.current) {
      marker.current.children.forEach((m, i) => {
        (m as THREE.Mesh).scale.setScalar(1 + 0.3 * Math.sin(t * 5 + i * 2));
      });
    }
  });
  return null;
}

export function Topic10283Sim(props: SimProps) {
  const condition = String(props.condition ?? "ectopic");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const embryo = useRef<THREE.Group>(null!);
  const marker = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    normal: "Normal implantation", ectopic: "Ectopic (in the tube)", molar: "Molar pregnancy (GTD)", miscarriage: "Miscarriage",
  };

  // embryo sits: uterus center (normal/miscarriage), tube (ectopic), molar cluster replaces it
  const embryoPos: [number, number, number] =
    condition === "ectopic" ? [2.15, 2.9, 0.2] : [0, 2.0, 0.2];

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.6, 10.5]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* uterus */}
          <mesh position={[0, 2.0, 0]} scale={[1.0, 1.15, 0.85]} castShadow>
            <sphereGeometry args={[0.95, 28, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.55} />
          </mesh>
          {/* fallopian tubes */}
          {[-1, 1].map((s) => (
            <group key={s}>
              <mesh position={[s * 1.75, 2.85, 0]} rotation={[0, 0, s * -0.25]} castShadow>
                <cylinderGeometry args={[0.16, 0.2, 1.9, 12]} />
                <meshStandardMaterial color={condition === "ectopic" && s === 1 ? "#ef4444" : "#f0abfc"} roughness={0.5}
                  emissive={condition === "ectopic" && s === 1 ? "#7f1d1d" : "#000000"} emissiveIntensity={0.6} />
              </mesh>
              <mesh position={[s * 0.85, 2.75, 0]} castShadow>
                <sphereGeometry args={[0.28, 14, 10]} />
                <meshStandardMaterial color="#f0abfc" roughness={0.5} />
              </mesh>
            </group>
          ))}
          {/* ovaries */}
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 2.85, 2.7, 0]} scale={[1, 1.3, 0.8]} castShadow>
              <sphereGeometry args={[0.26, 16, 12]} />
              <meshStandardMaterial color="#fde68a" roughness={0.5} />
            </mesh>
          ))}
          {/* embryo (not shown for molar — replaced by vesicles) */}
          {condition !== "molar" && (
            <group ref={embryo} position={embryoPos}>
              <mesh castShadow>
                <sphereGeometry args={[condition === "ectopic" ? 0.22 : 0.3, 18, 14]} />
                <meshStandardMaterial
                  color={condition === "miscarriage" ? "#94a3b8" : "#fde68a"}
                  roughness={0.6}
                  emissive={condition === "ectopic" ? "#b45309" : "#000000"}
                  emissiveIntensity={0.5}
                />
              </mesh>
            </group>
          )}
          {/* molar: cluster of grape-like vesicles filling the uterus */}
          {condition === "molar" && (
            <group position={[0, 2.0, 0.2]}>
              {Array.from({ length: 16 }).map((_, i) => {
                const a = (i / 16) * Math.PI * 2;
                const r = 0.35 + (i % 3) * 0.18;
                return (
                  <mesh key={i} position={[Math.cos(a) * r, Math.sin(a * 1.3) * r * 0.9, Math.sin(a) * r * 0.5]} castShadow>
                    <sphereGeometry args={[0.17, 12, 10]} />
                    <meshStandardMaterial color="#a78bfa" roughness={0.4} emissive="#5b21b6" emissiveIntensity={0.4} />
                  </mesh>
                );
              })}
            </group>
          )}
          {/* danger marker */}
          <group ref={marker}>
            {condition === "ectopic" && (
              <mesh position={[2.15, 3.45, 0.4]}>
                <sphereGeometry args={[0.2, 12, 10]} />
                <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={1.4} />
              </mesh>
            )}
            {condition === "molar" && (
              <mesh position={[0, 3.3, 0.4]}>
                <sphereGeometry args={[0.2, 12, 10]} />
                <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={1.4} />
              </mesh>
            )}
          </group>
          <Label text="Uterus" position={[-1.9, 1.4, 0]} size={0.55} color="#f9a8d4" />
          <Label text="Fallopian tube" position={[2.6, 3.6, 0]} size={0.5} color="#f0abfc" />
          <Label text="Ovary" position={[-3.6, 2.7, 0]} size={0.5} color="#fde68a" />
          {condition === "ectopic" && <Label text="⚠ Embryo stuck in tube — can rupture!" position={[0, 0.55, 0.3]} size={0.55} color="#fca5a5" />}
          {condition === "molar" && <Label text="⚠ Grape-like molar tissue" position={[0, 0.55, 0.3]} size={0.55} color="#c4b5fd" />}
          {condition === "miscarriage" && <Label text="Pregnancy lost" position={[0, 0.55, 0.5]} size={0.55} color="#94a3b8" />}
          {condition === "normal" && <Label text="Implanted safely in uterus ✓" position={[0, 0.55, 0.3]} size={0.55} color="#86efac" />}
        </group>
        <Animator group={group} embryo={embryo} marker={marker} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
