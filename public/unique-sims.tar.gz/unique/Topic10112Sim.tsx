// Anticoagulants: platelets clump into a clot on a vessel plaque — blood
// thinners dissolve the clot and keep the blood flowing.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Anticoagulant dose", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Anticoagulants & thrombolytics",
  blurb: "Platelets clump into a clot on a vessel plaque — blood thinners dissolve it and restore flow.",
};

const N_PLATE = 12;
const N_FLOW = 10;

function Animator({ clot, platelets, flow, elapsed, dose, setTick }: {
  clot: React.RefObject<THREE.Group>;
  platelets: React.RefObject<(THREE.Mesh | null)[]>;
  flow: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  dose: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    // clot grows when untreated, dissolves with drug
    const clotSize = THREE.MathUtils.clamp(1.25 - k * 1.1 - Math.sin(t * 0.4) * 0.05, 0.12, 1.3);
    if (clot.current) {
      clot.current.scale.setScalar(clotSize);
      clot.current.rotation.y = t * 0.4;
    }
    // platelets: drift in, get captured near the clot when it is big
    platelets.current.forEach((p, i) => {
      if (!p) return;
      const f = (t * 0.25 + i / N_PLATE) % 1;
      const captured = f > 0.55 && clotSize > 0.5;
      const x = -5 + f * 10;
      const targetX = captured ? 0.6 + Math.sin(i * 3) * 0.5 : x;
      const targetY = captured ? 0.4 + Math.cos(i * 2.4) * 0.45 : 1.4 + Math.sin(t * 2 + i) * 0.25;
      p.position.x += (targetX - p.position.x) * 0.08;
      p.position.y += (targetY - p.position.y) * 0.08;
      p.rotation.x = t * 2 + i;
    });
    // red blood cells flow faster when the vessel is open
    flow.current.forEach((f2, i) => {
      if (!f2) return;
      const f = (t * (0.2 + k * 0.6) + i / N_FLOW) % 1;
      f2.position.set(-5.5 + f * 11, 1.4 + Math.sin(i * 2.1) * 0.3, 0.9 - (i % 3) * 0.9);
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(clotSize * 100)); }
  });
  return null;
}

export function Topic10112Sim(props: SimProps) {
  const dose = Number(props.dose ?? 60);
  const showLabels = String(props.detail ?? "on") === "on";
  const clot = useRef<THREE.Group>(null!);
  const platelets = useRef<(THREE.Mesh | null)[]>([]);
  const flow = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const blockage = Math.round(THREE.MathUtils.clamp(95 - (dose / 100) * 90, 5, 95));

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Vessel blockage", `${blockage}%`],
          ["Blood flow", blockage > 60 ? "blocked" : blockage > 25 ? "slow" : "free"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* blood vessel */}
        <mesh position={[0, 1.4, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[1.0, 1.0, 11, 24, 1, true]} />
          <meshStandardMaterial color="#991b1b" roughness={0.5} side={THREE.DoubleSide} transparent opacity={0.55} />
        </mesh>
        {/* atherosclerotic plaque */}
        <mesh position={[0.6, 0.55, 0]} scale={[1.4, 0.5, 1]} castShadow>
          <sphereGeometry args={[0.8, 18, 14]} />
          <meshStandardMaterial color="#eab308" roughness={0.7} />
        </mesh>
        {showLabels && <Label text="plaque" position={[0.6, -0.5, 0]} size={0.45} color="#fde047" />}

        {/* the clot */}
        <group ref={clot} position={[0.6, 1.1, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.75, 18, 14]} />
            <meshStandardMaterial color="#7f1d1d" roughness={0.8} />
          </mesh>
          <mesh position={[0.3, 0.35, 0.2]}>
            <sphereGeometry args={[0.4, 14, 10]} />
            <meshStandardMaterial color="#991b1b" roughness={0.8} />
          </mesh>
          <mesh position={[-0.35, -0.2, -0.15]}>
            <sphereGeometry args={[0.35, 14, 10]} />
            <meshStandardMaterial color="#991b1b" roughness={0.8} />
          </mesh>
        </group>
        {showLabels && <Label text="blood clot" position={[0.6, 2.9, 0]} color="#fca5a5" />}

        {/* platelets */}
        {Array.from({ length: N_PLATE }).map((_, i) => (
          <mesh key={i} ref={(m) => { platelets.current[i] = m; }}>
            <cylinderGeometry args={[0.16, 0.16, 0.07, 12]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
        ))}
        {showLabels && <Label text="platelets" position={[-4.4, 2.5, 0]} size={0.45} color="#fde68a" />}

        {/* flowing red blood cells */}
        {Array.from({ length: N_FLOW }).map((_, i) => (
          <mesh key={i} ref={(m) => { flow.current[i] = m; }} scale={[1, 1, 0.45]}>
            <sphereGeometry args={[0.22, 12, 10]} />
            <meshStandardMaterial color="#ef4444" roughness={0.4} />
          </mesh>
        ))}

        {/* heparin / warfarin pill bottle */}
        <group position={[5.4, 0, 1.2]}>
          <mesh position={[0, 0.5, 0]} castShadow>
            <cylinderGeometry args={[0.45, 0.45, 1, 14]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.4} />
          </mesh>
          <mesh position={[0, 1.15, 0]}>
            <cylinderGeometry args={[0.2, 0.2, 0.3, 12]} />
            <meshStandardMaterial color="#3b82f6" roughness={0.4} />
          </mesh>
        </group>
        {showLabels && <Label text="anticoagulant" position={[5.4, 2, 1.2]} size={0.45} color="#93c5fd" />}

        <Animator clot={clot} platelets={platelets} flow={flow} elapsed={elapsed} dose={dose} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
