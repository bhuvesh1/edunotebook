// Embryology: urinary and genital systems — the metanephric kidney with its
// ureteric bud branching inside, urine droplets draining down the ureter, and
// the indifferent gonad choosing its path.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "urineflow", label: "Urine flow", kind: "slider", min: 0, max: 2.5, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Embryology: Kidney & Ureter",
  blurb: "The ureteric bud branches inside the metanephros while forming urine drains down the ureter.",
};

function Animator({
  urine, budTips, kidney, elapsed, urineflow, speed,
}: {
  urine: React.RefObject<THREE.Group>;
  budTips: React.RefObject<THREE.Group>;
  kidney: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  urineflow: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (urine.current) {
      urine.current.children.forEach((m, i) => {
        const ph = ((t * 0.5 * urineflow + i / 7) % 1 + 1) % 1;
        m.position.y = 2.6 - ph * 2.4;
        m.visible = urineflow > 0.02;
      });
    }
    if (budTips.current) {
      budTips.current.children.forEach((m, i) => {
        const s = 1 + 0.12 * Math.sin(t * 3 + i * 1.4);
        m.scale.setScalar(s);
      });
    }
    if (kidney.current) {
      kidney.current.position.y = 2.6 + Math.sin(t * 1.4) * 0.06;
    }
  });
  return null;
}

export function Topic10027Sim(props: SimProps) {
  const urineflow = Number(props.urineflow ?? 1);
  const speed = Number(props.speed ?? 1);
  const urine = useRef<THREE.Group>(null!);
  const budTips = useRef<THREE.Group>(null!);
  const kidney = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const branches = useMemo(
    () =>
      Array.from({ length: 8 }).map((_, i) => {
        const a = (i / 8) * Math.PI * 2;
        return { a, len: 0.9 + (i % 3) * 0.25 };
      }),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Metanephros", "definitive kidney"],
          ["Ureteric bud", "branches → collecting system"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 14]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* metanephric kidney: bean shape */}
        <mesh ref={kidney} position={[-2.5, 2.6, 0]} castShadow scale={[1, 1.35, 0.9]}>
          <sphereGeometry args={[1.1, 24, 24]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.45} />
        </mesh>
        {/* ureteric bud branching inside (stylised as glowing tree on the kidney) */}
        <group ref={budTips} position={[-2.5, 2.6, 0.9]}>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.09, 0.13, 1.1, 8]} />
            <meshStandardMaterial color="#fde68a" roughness={0.4} />
          </mesh>
          {branches.map((b, i) => (
            <group key={i} position={[0.55, 0, 0]} rotation={[b.a, 0, 0]}>
              <mesh position={[0, b.len / 2, 0]}>
                <cylinderGeometry args={[0.05, 0.08, b.len, 8]} />
                <meshStandardMaterial color="#fde68a" roughness={0.4} />
              </mesh>
              <mesh position={[0, b.len, 0]}>
                <sphereGeometry args={[0.14, 10, 10]} />
                <meshStandardMaterial color="#fef9c3" emissive="#a16207" emissiveIntensity={0.6} />
              </mesh>
            </group>
          ))}
        </group>
        <Label text="metanephric kidney" position={[-2.5, 4.7, 0]} size={0.4} color="#f8fafc" />
        <Label text="ureteric bud branching" position={[-0.4, 3.4, 0.9]} size={0.32} color="#fde68a" />

        {/* ureter with peristaltic urine droplets */}
        <mesh position={[-2.5, 0.9, 0]} castShadow>
          <cylinderGeometry args={[0.22, 0.22, 3.2, 12]} />
          <meshStandardMaterial color="#fda4af" roughness={0.5} />
        </mesh>
        <group ref={urine}>
          {Array.from({ length: 7 }).map((_, i) => (
            <mesh key={i} position={[-2.5, 2.6, 0]}>
              <sphereGeometry args={[0.11, 10, 10]} />
              <meshStandardMaterial color="#fde047" emissive="#a16207" emissiveIntensity={0.5} />
            </mesh>
          ))}
        </group>
        <Label text="ureter" position={[-1.5, 0.9, 0]} size={0.34} color="#f8fafc" />

        {/* bladder */}
        <mesh position={[-2.5, -0.4, 0]} castShadow scale={[1, 0.8, 1]}>
          <sphereGeometry args={[0.75, 18, 18]} />
          <meshStandardMaterial color="#facc15" transparent opacity={0.75} roughness={0.35} />
        </mesh>
        <Label text="bladder" position={[-2.5, -1.35, 0]} size={0.32} color="#fde68a" />

        {/* mesonephric (Wolffian) and paramesonephric (Müllerian) ducts */}
        <group position={[3.5, 0, 0]}>
          <mesh position={[0, 2.4, -0.5]} castShadow>
            <cylinderGeometry args={[0.16, 0.16, 4.4, 12]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.45} />
          </mesh>
          <mesh position={[0, 2.4, 0.5]} castShadow>
            <cylinderGeometry args={[0.16, 0.16, 4.4, 12]} />
            <meshStandardMaterial color="#f472b6" roughness={0.45} />
          </mesh>
          {/* indifferent gonad ridge */}
          <mesh position={[0, 3.2, 0]} castShadow scale={[1.6, 0.8, 1.4]}>
            <sphereGeometry args={[0.7, 16, 16]} />
            <meshStandardMaterial color="#c084fc" roughness={0.5} />
          </mesh>
        </group>
        <Label text="indifferent gonad" position={[3.5, 4.35, 0]} size={0.36} color="#f8fafc" />
        <Label text="mesonephric (Wolffian) duct" position={[3.5, 1.15, -1.5]} size={0.3} color="#7dd3fc" />
        <Label text="paramesonephric (Müllerian) duct" position={[3.5, 0.55, 1.7]} size={0.3} color="#f9a8d4" />

        <Animator urine={urine} budTips={budTips} kidney={kidney} elapsed={elapsed} urineflow={urineflow} speed={speed} />
      </SimCanvas>
    </div>
  );
}
