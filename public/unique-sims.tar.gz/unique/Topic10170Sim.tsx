"use client";
// Screening: validity of screening tests, natural history.
// A glowing 2×2 table (true/false × positive/negative) fills with people
// icons — raise sensitivity and watch the missed cases shrink.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "sens", label: "Sensitivity", kind: "slider", min: 50, max: 100, step: 1, default: 80, unit: "%" },
  { key: "prev", label: "Disease prevalence", kind: "slider", min: 5, max: 50, step: 5, default: 20, unit: "%" },
];

export const UNIQUE_META = {
  title: "Screening Tests: The 2×2 Table",
  blurb: "Four boxes, four fates: true positives, false alarms, missed cases and true negatives — tune sensitivity and watch them shift.",
};

function Animator({ cells, elapsed }: { cells: React.RefObject<THREE.Group>; elapsed: React.RefObject<number> }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (cells.current) {
      cells.current.children.forEach((cell, ci) => {
        cell.children.forEach((p, pi) => {
          (p as THREE.Mesh).position.y = 0.25 + Math.abs(Math.sin(elapsed.current * 2 + pi * 0.9 + ci)) * 0.12;
        });
      });
    }
  });
  return null;
}

export function Topic10170Sim(props: SimProps) {
  const sens = Number(props.sens ?? 80);
  const prev = Number(props.prev ?? 20);
  const cells = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const N = 100;
  const diseased = Math.round((N * prev) / 100);
  const tp = Math.round((diseased * sens) / 100);
  const fn = diseased - tp;
  const healthy = N - diseased;
  const tn = Math.round(healthy * 0.9);
  const fp = healthy - tn;
  const spec = Math.round((tn / Math.max(1, healthy)) * 100);

  const cellsData = useMemo(
    () => [
      { key: "TP", label: "Caught! ✓", color: "#22c55e", count: tp, x: -1.7, y: 1.55 },
      { key: "FP", label: "False alarm", color: "#f59e0b", count: fp, x: 1.7, y: 1.55 },
      { key: "FN", label: "MISSED ✗", color: "#ef4444", count: fn, x: -1.7, y: -1.55 },
      { key: "TN", label: "Healthy ✓", color: "#38bdf8", count: tn, x: 1.7, y: -1.55 },
    ],
    [tp, fp, fn, tn]
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Sensitivity", `${sens}%`], ["Specificity", `${spec}%`], ["Missed (FN)", `${fn}`]]} />
      <SimCanvas cameraPosition={[0, 3.4, 13]} target={[0, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Label text="TEST +" position={[-1.7, 3.9, 0]} size={0.55} color="#e2e8f0" />
        <Label text="TEST −" position={[1.7, 3.9, 0]} size={0.55} color="#e2e8f0" />
        <Label text="SICK" position={[-4.4, 1.55, 0]} size={0.55} color="#e2e8f0" />
        <Label text="WELL" position={[-4.4, -1.55, 0]} size={0.55} color="#e2e8f0" />
        <group ref={cells}>
          {cellsData.map((c) => (
            <group key={c.key} position={[c.x, c.y, 0]}>
              <mesh castShadow>
                <boxGeometry args={[2.9, 2.6, 0.35]} />
                <meshStandardMaterial color={c.color} transparent opacity={0.28} roughness={0.6} />
              </mesh>
              <mesh position={[0, 0, 0.2]}>
                <boxGeometry args={[2.9, 2.6, 0.06]} />
                <meshStandardMaterial color={c.color} transparent opacity={0.12} roughness={0.6} />
              </mesh>
              {Array.from({ length: Math.min(8, c.count) }, (_, i) => (
                <mesh key={i} position={[-1 + (i % 4) * 0.65, -0.5 + Math.floor(i / 4) * 0.7, 0.35]}>
                  <capsuleGeometry args={[0.14, 0.25, 4, 8]} />
                  <meshStandardMaterial color={c.color} emissive={c.color} emissiveIntensity={0.5} roughness={0.5} />
                </mesh>
              ))}
              <Label text={`${c.key}: ${c.count}`} position={[0, 1.05, 0.4]} size={0.5} color={c.color} />
              <Label text={c.label} position={[0, -1.05, 0.4]} size={0.42} color="#e2e8f0" />
            </group>
          ))}
        </group>
        <Label text="A good screening test MISSES almost nobody" position={[0, 5, 0]} size={0.55} color="#93c5fd" />
        <Animator cells={cells} elapsed={elapsed} />
      </SimCanvas>
    </div>
  );
}
