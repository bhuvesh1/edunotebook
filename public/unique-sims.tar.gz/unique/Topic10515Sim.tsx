// app/components/sims/unique/Topic10515Sim.tsx
// Oral mucosal lesions: an open mouth showing white lesions, red lesions,
// and vesiculobullous (blister) lesions on the cheek and tongue.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "lesion", label: "Lesion type", kind: "select", min: 0, max: 0, step: 1, default: "white", options: ["white", "red", "vesiculobullous"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Oral Mucosal Lesions: White, Red & Vesiculobullous",
  blurb: "Look inside the mouth: white patches, red patches, or fluid-filled blisters appear on the cheek and tongue.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ lesions, elapsed, speed }: {
  lesions: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (lesions.current) {
      const s = 1 + 0.07 * Math.sin(elapsed.current * 2.4);
      lesions.current.scale.setScalar(s);
    }
  });
  return null;
}

const INFO: Record<string, { color: string; label: string; eg: string }> = {
  white: { color: "#f8fafc", label: "white lesion (keratotic)", eg: "e.g. frictional keratosis" },
  red: { color: "#ef4444", label: "red lesion (erythematous)", eg: "e.g. erythroplakia — biopsy!" },
  vesiculobullous: { color: "#fde68a", label: "vesicles / bullae (fluid-filled)", eg: "e.g. herpes, pemphigus" },
};

export function Topic10515Sim(props: SimProps) {
  const lesion = String(props.lesion ?? "white");
  const speed = Number(props.speed ?? 1);
  const lesions = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = INFO[lesion] ?? INFO.white;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Lesion", info.label],
          ["Example", info.eg],
          ["Site", "buccal mucosa + tongue"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.6, 10]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* face hint */}
        <mesh position={[0, 2.6, -0.8]} castShadow>
          <sphereGeometry args={[2.6, 32, 32]} />
          <meshStandardMaterial color="#f0b98d" roughness={0.7} />
        </mesh>
        {/* open mouth cavity */}
        <mesh position={[0, 2.4, 1.2]}>
          <sphereGeometry args={[1.35, 24, 24]} />
          <meshStandardMaterial color="#5b1a1a" roughness={0.9} />
        </mesh>
        {/* lips */}
        <mesh position={[0, 2.4, 1.55]} scale={[1.35, 0.85, 0.6]} castShadow>
          <torusGeometry args={[1.05, 0.28, 14, 32]} />
          <meshStandardMaterial color="#e0788a" roughness={0.55} />
        </mesh>
        {/* tongue */}
        <mesh position={[0, 1.85, 1.5]} scale={[1, 0.45, 1.15]} castShadow>
          <sphereGeometry args={[0.85, 24, 24]} />
          <meshStandardMaterial color="#e0607a" roughness={0.55} />
        </mesh>
        {/* upper teeth */}
        {[-0.75, -0.38, 0, 0.38, 0.75].map((x, i) => (
          <mesh key={i} position={[x, 3.15, 1.5]} castShadow>
            <boxGeometry args={[0.3, 0.4, 0.25]} />
            <meshStandardMaterial color="#ffffff" roughness={0.3} />
          </mesh>
        ))}
        {/* lower teeth */}
        {[-0.6, -0.2, 0.2, 0.6].map((x, i) => (
          <mesh key={i} position={[x, 1.55, 1.35]} castShadow>
            <boxGeometry args={[0.28, 0.32, 0.22]} />
            <meshStandardMaterial color="#ffffff" roughness={0.3} />
          </mesh>
        ))}

        {/* lesions on cheek + tongue */}
        <group ref={lesions}>
          {lesion === "vesiculobullous" ? (
            <>
              {[[-0.85, 2.5, 1.75], [-0.55, 2.75, 1.7], [0.7, 2.0, 1.95], [0.35, 1.9, 2.0]].map((p, i) => (
                <mesh key={i} position={p as [number, number, number]} castShadow>
                  <sphereGeometry args={[0.16 + (i % 2) * 0.07, 14, 14]} />
                  <meshStandardMaterial color={info.color} emissive="#f59e0b" emissiveIntensity={0.5} transparent opacity={0.85} roughness={0.2} />
                </mesh>
              ))}
            </>
          ) : (
            <>
              {/* cheek patch */}
              <mesh position={[-0.8, 2.55, 1.78]} rotation={[0, 0.4, 0.2]}>
                <circleGeometry args={[0.42, 20]} />
                <meshStandardMaterial color={info.color} emissive={lesion === "red" ? "#ef4444" : "#ffffff"} emissiveIntensity={0.35} roughness={0.7} side={THREE.DoubleSide} />
              </mesh>
              {/* tongue patch */}
              <mesh position={[0.45, 2.12, 1.95]} rotation={[-0.5, 0, 0.3]}>
                <circleGeometry args={[0.3, 20]} />
                <meshStandardMaterial color={info.color} emissive={lesion === "red" ? "#ef4444" : "#ffffff"} emissiveIntensity={0.35} roughness={0.7} side={THREE.DoubleSide} />
              </mesh>
            </>
          )}
        </group>

        <Label p={[2.4, 2.55, 1.6]} size={0.3} color={info.color}>{info.label}</Label>
        <Label p={[0, 4.9, 0.5]} size={0.32} color="#e2e8f0">open mouth — buccal mucosa & tongue</Label>

        <Animator lesions={lesions} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
