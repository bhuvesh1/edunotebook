// Obstetrics: multiple pregnancy, preterm labor, PROM, IUGR.
// One uterus, two babies — twins sharing the womb. See a growth-restricted
// baby (IUGR), waters breaking early (PROM), or a preterm baby in the warmer.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "twins", options: ["twins", "iugr", "prom", "preterm"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "High-Risk Pregnancy: Twins & More",
  blurb: "Two babies in one womb — plus IUGR (too-small baby), PROM (waters break early), and preterm birth.",
};

function Animator({
  group, babyA, babyB, waters, elapsed, speed, condition,
}: {
  group: React.RefObject<THREE.Group>;
  babyA: React.RefObject<THREE.Group>;
  babyB: React.RefObject<THREE.Group>;
  waters: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
    const kick = (ref: React.RefObject<THREE.Group>, ph: number) => {
      if (ref.current) {
        ref.current.position.y = 1.9 + Math.max(0, Math.sin(t * 2.6 + ph)) * 0.12;
        ref.current.rotation.z = Math.sin(t * 1.3 + ph) * 0.12;
      }
    };
    kick(babyA, 0);
    if (babyB.current) {
      babyB.current.visible = condition === "twins" || condition === "iugr";
      kick(babyB, 2.2);
      if (condition === "iugr") babyB.current.scale.setScalar(0.55); // growth-restricted
    }
    if (waters.current) {
      // PROM: water droplets gush downward
      waters.current.visible = condition === "prom";
      waters.current.children.forEach((d, i) => {
        const ph = ((t * 0.8 + i / waters.current!.children.length) % 1);
        d.position.set(Math.sin(i * 3.3) * 0.4, 1.3 - ph * 1.3, 0.6);
      });
    }
  });
  return null;
}

function Fetus({ tint = "#fde68a" }: { tint?: string }) {
  return (
    <group>
      <mesh position={[-0.18, 0.28, 0]} castShadow>
        <sphereGeometry args={[0.26, 18, 14]} />
        <meshStandardMaterial color={tint} roughness={0.6} />
      </mesh>
      <mesh position={[0.14, -0.08, 0]} rotation={[0, 0, 1.1]} castShadow>
        <capsuleGeometry args={[0.15, 0.32, 6, 12]} />
        <meshStandardMaterial color={tint} roughness={0.6} />
      </mesh>
    </group>
  );
}

export function Topic10281Sim(props: SimProps) {
  const condition = String(props.condition ?? "twins");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const babyA = useRef<THREE.Group>(null!);
  const babyB = useRef<THREE.Group>(null!);
  const waters = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    twins: "Twin pregnancy", iugr: "IUGR — one baby too small", prom: "PROM — waters break early", preterm: "Preterm labor",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.6, 10.5]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* uterus: bigger for twins */}
          <mesh position={[0, 1.9, 0]} scale={[condition === "twins" ? 1.35 : 1.1, 1.45, 1.05]} castShadow>
            <sphereGeometry args={[1.0, 28, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.5} />
          </mesh>
          {/* baby A */}
          <group ref={babyA} position={[-0.55, 1.9, 0.25]}>
            <Fetus />
          </group>
          {/* baby B: twin or the IUGR small one */}
          <group ref={babyB} position={[0.6, 1.9, 0.25]} visible={false}>
            <Fetus tint={condition === "iugr" ? "#fca5a5" : "#fde68a"} />
          </group>
          {/* dividing membrane for twins */}
          {condition === "twins" && (
            <mesh position={[0.02, 1.9, 0.25]} castShadow>
              <boxGeometry args={[0.05, 2.2, 1.4]} />
              <meshStandardMaterial color="#7dd3fc" roughness={0.3} transparent opacity={0.6} />
            </mesh>
          )}
          {/* PROM: gushing waters */}
          <group ref={waters} visible={false}>
            {Array.from({ length: 16 }).map((_, i) => (
              <mesh key={i}>
                <sphereGeometry args={[0.1, 8, 6]} />
                <meshBasicMaterial color="#7dd3fc" transparent opacity={0.85} />
              </mesh>
            ))}
          </group>
          {/* preterm: tiny baby in warmer beside */}
          {condition === "preterm" && (
            <group position={[2.8, 1.1, 0.3]}>
              <mesh castShadow>
                <boxGeometry args={[1.8, 0.3, 1.4]} />
                <meshStandardMaterial color="#334155" roughness={0.5} />
              </mesh>
              <mesh position={[0, 0.75, 0]}>
                <boxGeometry args={[1.8, 1.1, 1.4]} />
                <meshStandardMaterial color="#7dd3fc" transparent opacity={0.18} roughness={0.1} />
              </mesh>
              <group scale={0.4} position={[0, 0.55, 0]}>
                <Fetus tint="#fecdd3" />
              </group>
            </group>
          )}
          <Label text="Uterus" position={[-2.1, 3.2, 0]} size={0.55} color="#f9a8d4" />
          {condition === "twins" && <Label text="Twin A + Twin B 👶👶" position={[0, 0.4, 0.3]} size={0.55} color="#fde68a" />}
          {condition === "iugr" && <Label text="⚠ Baby B not growing" position={[0.6, 0.75, 0.3]} size={0.55} color="#fca5a5" />}
          {condition === "prom" && <Label text="💧 Waters broke early!" position={[0, 0.2, 0.6]} size={0.55} color="#7dd3fc" />}
          {condition === "preterm" && <Label text="⚠ Born too soon — warmer" position={[2.8, 2.4, 0.3]} size={0.55} color="#fca5a5" />}
        </group>
        <Animator group={group} babyA={babyA} babyB={babyB} waters={waters} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
