// app/components/sims/unique/Topic10525Sim.tsx
// Imaging physics: X-ray production and the IOPA technique. Electrons slam
// into the anode target, X-ray photons stream out, pass through the tooth,
// and expose the film/sensor behind it.

"use client";

import { useMemo, useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ma", label: "Tube current (mA)", kind: "slider", min: 2, max: 15, step: 1, default: 8, unit: " mA" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "X-ray Production & IOPA Technique",
  blurb: "Electrons hit the tungsten target, X-rays fly through the tooth, and the film captures its shadow.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

const PHOTONS = 40;

function Animator({ photons, elapsed, speed, ma }: {
  photons: RefObject<THREE.InstancedMesh>; elapsed: RefObject<number>; speed: number; ma: number;
}) {
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (photons.current) {
      const active = Math.round((ma / 15) * PHOTONS);
      for (let i = 0; i < PHOTONS; i++) {
        if (i < active) {
          const prog = (t * 1.6 + i * 0.37) % 1; // 0..1 along the beam
          const x = -3.2 + prog * 6.4;
          const spread = prog * 0.9;
          const yy = 2.4 + Math.sin(i * 12.9) * spread * 0.5;
          const zz = Math.cos(i * 7.7) * spread * 0.5;
          dummy.position.set(x, yy, zz);
          dummy.scale.setScalar(1);
        } else {
          dummy.position.set(0, -10, 0);
          dummy.scale.setScalar(0.001);
        }
        dummy.updateMatrix();
        photons.current.setMatrixAt(i, dummy.matrix);
      }
      photons.current.instanceMatrix.needsUpdate = true;
    }
  });
  return null;
}

export function Topic10525Sim(props: SimProps) {
  const ma = Number(props.ma ?? 8);
  const speed = Number(props.speed ?? 1);
  const photons = useRef<THREE.InstancedMesh>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Tube current", `${ma} mA`],
          ["Photon flux", ma >= 10 ? "high — darker film" : ma >= 5 ? "medium" : "low — pale film"],
          ["IOPA", "film inside mouth, behind tooth"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 13]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* X-ray tube head */}
        <group position={[-4.4, 2.4, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.9, 0.9, 1.6, 20]} />
            <meshStandardMaterial color="#475569" metalness={0.6} roughness={0.4} />
          </mesh>
          {/* anode target glowing where electrons hit */}
          <mesh position={[0.85, 0, 0]}>
            <boxGeometry args={[0.15, 0.7, 0.7]} />
            <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1.6} />
          </mesh>
          <Label p={[0, 1.5, 0]} size={0.3} color="#fde68a">X-ray tube</Label>
          <Label p={[0, -1.5, 0]} size={0.26} color="#94a3b8">electrons → tungsten target</Label>
        </group>

        {/* collimator cone */}
        <mesh position={[-2.9, 2.4, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.35, 0.85, 1.2, 16, 1, true]} />
          <meshStandardMaterial color="#64748b" metalness={0.6} roughness={0.4} side={THREE.DoubleSide} />
        </mesh>

        {/* tooth in the beam path */}
        <group position={[0.4, 2.4, 0]}>
          <mesh castShadow>
            <boxGeometry args={[0.8, 0.9, 0.7]} />
            <meshStandardMaterial color="#ffffff" roughness={0.25} />
          </mesh>
          <mesh position={[-0.2, -0.85, 0]} rotation={[Math.PI, 0, 0]}>
            <coneGeometry args={[0.16, 0.8, 10]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.3} />
          </mesh>
          <mesh position={[0.2, -0.85, 0]} rotation={[Math.PI, 0, 0]}>
            <coneGeometry args={[0.16, 0.8, 10]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.3} />
          </mesh>
          {/* caries shows dark on film */}
          <mesh position={[0.15, 0.15, 0.36]}>
            <sphereGeometry args={[0.14, 12, 12]} />
            <meshStandardMaterial color="#7c2d12" roughness={0.6} />
          </mesh>
        </group>
        <Label p={[0.4, 1.1, 0]} size={0.3} color="#ffffff">tooth</Label>

        {/* IOPA film/sensor behind the tooth */}
        <group position={[2.6, 2.4, 0]}>
          <mesh castShadow>
            <boxGeometry args={[0.12, 2.2, 1.8]} />
            <meshStandardMaterial color="#1e3a8a" roughness={0.4} />
          </mesh>
          {/* exposed image brightens with mA */}
          <mesh position={[-0.08, 0, 0]}>
            <boxGeometry args={[0.02, 1.9, 1.5]} />
            <meshStandardMaterial
              color="#dbeafe"
              emissive="#93c5fd"
              emissiveIntensity={0.2 + (ma / 15) * 1.4}
              roughness={0.4}
            />
          </mesh>
          {/* tooth shadow on film */}
          <mesh position={[-0.1, 0.1, 0]} scale={[1, 1, 1]}>
            <boxGeometry args={[0.02, 0.9, 0.7]} />
            <meshStandardMaterial color="#0f172a" roughness={0.6} />
          </mesh>
        </group>
        <Label p={[2.6, 0.8, 0]} size={0.3} color="#93c5fd">IOPA film</Label>

        {/* X-ray photons */}
        <instancedMesh ref={photons} args={[undefined, undefined, PHOTONS]}>
          <sphereGeometry args={[0.07, 8, 8]} />
          <meshStandardMaterial color="#fde68a" emissive="#facc15" emissiveIntensity={2} />
        </instancedMesh>

        <Label p={[0, 4.6, 0]} size={0.32} color="#fde68a">X-ray beam: tube → tooth → film</Label>

        <Animator photons={photons} elapsed={elapsed} speed={speed} ma={ma} />
      </SimCanvas>
    </div>
  );
}
