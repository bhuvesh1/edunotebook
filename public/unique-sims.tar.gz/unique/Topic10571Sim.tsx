"use client";

// Trauma basics: first aid and hemorrhage control.
// An injured arm bleeds — tighten the tourniquet and the bleeding
// slows; add direct pressure and elevation to stop it.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "pressure", label: "Tourniquet pressure", kind: "slider", min: 0, max: 100, step: 5, default: 35, unit: "%" },
];

export const UNIQUE_META = {
  title: "Trauma First Aid: Hemorrhage Control",
  blurb: "An arm is bleeding — tighten the tourniquet, press directly on the wound and elevate to stop the bleed.",
};

const NB = 26;
type Ref = { current: THREE.Group | null };

function Animator({ blood, band, elapsed, flow }: { blood: Ref; band: Ref; elapsed: { current: number }; flow: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const e = elapsed.current;
    blood.current?.children.forEach((m, i) => {
      const t = (e * (0.5 + flow * 1.6) + i / NB) % 1;
      const drift = Math.sin(i * 3.7) * 0.25;
      m.position.set(0.3 + drift * 0.4 + t * 0.35, 2.08 - t * 1.95, drift * 0.5);
      const s = Math.max(0.001, (1 - t) * flow);
      m.scale.set(s, s, s);
    });
    if (band.current) {
      const target = flow < 0.4 ? 1 : 0.001;
      const cur = band.current.scale.x + (target - band.current.scale.x) * Math.min(1, delta * 4);
      band.current.scale.set(cur, cur, cur);
    }
  });
  return null;
}

export function Topic10571Sim(props: SimProps) {
  const pressure = Number(props.pressure ?? 35);
  const flow = 1 - pressure / 100;
  const bleedRate = Math.round(flow * 120);
  const status = flow <= 0.05 ? "Bleeding controlled" : flow < 0.5 ? "Bleeding slowing" : "UNCONTROLLED bleeding";

  const blood = useRef<THREE.Group>(null!);
  const band = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const drops = useMemo(() => Array.from({ length: NB }, (_, i) => i), []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Bleeding rate", `≈ ${bleedRate} mL/min`],
          ["Status", status],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.6, 10.5]} target={[0.3, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* arm */}
        <mesh position={[0, 1.7, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.42, 0.38, 3.6, 18]} />
          <meshStandardMaterial color="#eab88f" roughness={0.7} />
        </mesh>
        <mesh position={[2.0, 1.7, 0]} castShadow>
          <sphereGeometry args={[0.42, 16, 16]} />
          <meshStandardMaterial color="#eab88f" roughness={0.7} />
        </mesh>

        {/* wound */}
        <mesh position={[0.3, 2.08, 0]} castShadow>
          <boxGeometry args={[0.55, 0.14, 0.36]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.55} />
        </mesh>

        {/* tourniquet: 5-7 cm above the wound */}
        <mesh position={[-0.9, 1.7, 0]} rotation={[0, Math.PI / 2, 0]} scale={1 - (pressure / 100) * 0.22} castShadow>
          <torusGeometry args={[0.5, 0.14, 12, 24]} />
          <meshStandardMaterial color="#f97316" roughness={0.5} />
        </mesh>

        {/* pressure bandage (appears when bleeding is controlled) */}
        <group ref={band} position={[0.3, 2.12, 0]} scale={0.001}>
          <mesh castShadow>
            <boxGeometry args={[0.95, 0.3, 0.95]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.8} />
          </mesh>
        </group>

        {/* blood droplets */}
        <group ref={blood}>
          {drops.map((i) => (
            <mesh key={i}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshStandardMaterial color="#ef4444" emissive="#b91c1c" emissiveIntensity={0.6} />
            </mesh>
          ))}
        </group>

        {/* elevation hint */}
        <Arrow from={[2.7, 1.5, 0]} to={[2.7, 3.0, 0]} color="#22c55e" radius={0.07} />
        <Label text="Elevate the limb" position={[2.7, 3.35, 0]} size={0.42} color="#86efac" />

        <Label text="Wound — bleeding" position={[0.3, 2.75, 0]} size={0.45} color="#fca5a5" />
        <Label text="Tourniquet: 5–7 cm above wound" position={[-0.9, 0.75, 0]} size={0.42} color="#fdba74" />
        <Label text="Direct pressure" position={[0.3, 2.75, 1.2]} size={0.4} color="#e2e8f0" />
        <Animator blood={blood} band={band} elapsed={elapsed} flow={flow} />
      </SimCanvas>
    </div>
  );
}
