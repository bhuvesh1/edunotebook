// app/components/sims/unique/Topic7103Sim.tsx
// Dot and cross products: red vector A and blue vector B with an
// adjustable angle between them. In dot mode the glowing segment is B's
// projection on A (a number: A·B). In cross mode the gold arrow pops out
// of the plane with length |A×B|.

"use client";

import { useMemo, useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "angle", label: "Angle between A and B", kind: "slider", min: 0, max: 180, step: 5, default: 50, unit: "°" },
  { key: "mode", label: "Product", kind: "select", min: 0, max: 0, step: 1, default: "dot", options: ["dot", "cross"] },
];

export const UNIQUE_META = {
  title: "Dot and Cross Product",
  blurb: "Dot product: how much of B lies along A. Cross product: the arrow popping out of the plane.",
};

const A_LEN = 3.2;
const B_LEN = 2.4;

function YArrow({ len, color }: { len: number; color: string }) {
  return (
    <group>
      <mesh position={[0, len / 2, 0]}>
        <cylinderGeometry args={[0.09, 0.09, Math.max(len, 0.001), 12]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.45} roughness={0.4} />
      </mesh>
      <mesh position={[0, len + 0.18, 0]}>
        <coneGeometry args={[0.22, 0.4, 14]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.45} roughness={0.4} />
      </mesh>
    </group>
  );
}

function Spin({ g }: { g: RefObject<THREE.Group> }) {
  const t = useRef(0);
  useFrame((_, d) => {
    t.current += d;
    if (g.current) g.current.rotation.z = 0.12 * Math.sin(t.current * 1.6);
  });
  return null;
}

export function Topic7103Sim(props: SimProps) {
  const angle = Number(props.angle ?? 50);
  const mode = String(props.mode ?? "dot");
  const theta = (angle * Math.PI) / 180;
  const spin = useRef<THREE.Group>(null!);

  const dot = A_LEN * B_LEN * Math.cos(theta);
  const cross = A_LEN * B_LEN * Math.sin(theta);
  const projLen = B_LEN * Math.cos(theta);

  const drop = useMemo(
    () =>
      new THREE.Line(
        new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(B_LEN * Math.cos(theta), B_LEN * Math.sin(theta), 0),
          new THREE.Vector3(projLen, 0, 0),
        ]),
        new THREE.LineBasicMaterial({ color: "#cbd5e1", transparent: true, opacity: 0.6 })
      ),
    [theta, projLen]
  );

  const crossLen = Math.max((cross / (A_LEN * B_LEN)) * 3.2, 0.001);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={
          mode === "dot"
            ? [
                ["A·B = |A||B|cosθ", `${dot.toFixed(2)}`],
                ["Type", "scalar (a number)"],
                ["🟨 Glow", "B's projection on A"],
              ]
            : [
                ["|A×B| = |A||B|sinθ", `${cross.toFixed(2)}`],
                ["Direction", "out of the screen (+z)"],
                ["🟡 Gold arrow", "A×B vector"],
              ]
        }
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0.4, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={spin} position={[-1.4, 1.4, 0]}>
          {/* A along +x */}
          <group rotation={[0, 0, -Math.PI / 2]}>
            <YArrow len={A_LEN} color="#ef4444" />
          </group>
          {/* B at angle θ */}
          <group rotation={[0, 0, theta - Math.PI / 2]}>
            <YArrow len={B_LEN} color="#3b82f6" />
          </group>

          {mode === "dot" ? (
            <>
              <primitive object={drop} />
              {/* projection segment on A */}
              <mesh position={[projLen / 2, 0, 0]} rotation={[0, 0, -Math.PI / 2]}>
                <cylinderGeometry args={[0.13, 0.13, Math.max(Math.abs(projLen), 0.001), 10]} />
                <meshStandardMaterial
                  color="#fde047" emissive="#fde047" emissiveIntensity={0.9}
                  transparent opacity={0.85} roughness={0.4}
                />
              </mesh>
            </>
          ) : (
            <group position={[1.1, 1.1, 0]}>
              <YArrow len={crossLen} color="#fbbf24" />
            </group>
          )}
        </group>
        <Spin g={spin} />
      </SimCanvas>
    </div>
  );
}
