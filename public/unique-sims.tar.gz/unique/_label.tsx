// Shared helpers for unique sims: canvas text sprites + animated wave lines.
// No external textures — sprites are generated locally via canvas.

"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";

/** Simple billboard text sprite (locally generated canvas texture). */
export function makeTextSprite(
  text: string,
  color = "#ffffff",
  fontSize = 56
): THREE.Sprite {
  const pad = 18;
  const meas = document.createElement("canvas").getContext("2d")!;
  meas.font = `bold ${fontSize}px sans-serif`;
  const w = Math.ceil(meas.measureText(text).width) + pad * 2;
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = fontSize + pad * 2;
  const ctx = canvas.getContext("2d")!;
  ctx.font = `bold ${fontSize}px sans-serif`;
  ctx.fillStyle = color;
  ctx.textBaseline = "middle";
  ctx.fillText(text, pad, canvas.height / 2);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false })
  );
  const s = 0.011;
  sprite.scale.set(canvas.width * s, canvas.height * s, 1);
  return sprite;
}

/** Convenience: <primitive object={label("Hi")} position={...} /> */
export function label(text: string, color = "#ffffff", fontSize = 56): THREE.Sprite {
  return makeTextSprite(text, color, fontSize);
}

/** Animated 1D wave line: y = fn(x, t). Renders as THREE.Line. */
export function Wave({
  fn,
  color,
  width = 12,
  segments = 220,
  opacity = 1,
  speed = 1,
  position = [0, 0, 0] as [number, number, number],
  linewidth,
}: {
  fn: (x: number, t: number) => number;
  color: string;
  width?: number;
  segments?: number;
  opacity?: number;
  speed?: number;
  position?: [number, number, number];
  linewidth?: number;
}) {
  const { line } = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute(
      "position",
      new THREE.BufferAttribute(new Float32Array((segments + 1) * 3), 3)
    );
    const mat = new THREE.LineBasicMaterial({
      color,
      transparent: true,
      opacity,
    });
    if (linewidth) mat.linewidth = linewidth;
    return { line: new THREE.Line(geo, mat) };
  }, [color, segments, opacity]);

  useFrame((state) => {
    const t = state.clock.elapsedTime * speed;
    const attr = line.geometry.getAttribute("position") as THREE.BufferAttribute;
    for (let i = 0; i <= segments; i++) {
      const x = -width / 2 + (width * i) / segments;
      attr.setXYZ(i, x, fn(x, t), 0);
    }
    attr.needsUpdate = true;
  });

  return <primitive object={line} position={position} />;
}

/** Straight wire between two points (thin cylinder). */
export function Wire({
  from,
  to,
  color = "#94a3b8",
  radius = 0.03,
}: {
  from: [number, number, number];
  to: [number, number, number];
  color?: string;
  radius?: number;
}) {
  const { mesh, mid, quat } = useMemo(() => {
    const a = new THREE.Vector3(...from);
    const b = new THREE.Vector3(...to);
    const dir = b.clone().sub(a);
    const len = dir.length();
    const mesh = new THREE.Mesh(
      new THREE.CylinderGeometry(radius, radius, len, 8),
      new THREE.MeshStandardMaterial({ color, roughness: 0.5, metalness: 0.6 })
    );
    const quat = new THREE.Quaternion().setFromUnitVectors(
      new THREE.Vector3(0, 1, 0),
      dir.clone().normalize()
    );
    const mid = a.clone().add(b).multiplyScalar(0.5);
    return { mesh, len, mid, quat };
  }, [from, to, color, radius]);
  return <primitive object={mesh} position={mid} quaternion={quat} />;
}
