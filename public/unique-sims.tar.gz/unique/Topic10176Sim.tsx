"use client";
// Demography: indicators, population dynamics.
// A population pyramid that morphs as the years pass — wide base of
// children shrinking as the country ages.


import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "year", label: "Year", kind: "slider", min: 1960, max: 2026, step: 2, default: 1990, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 0, unit: "×" },
];

export const UNIQUE_META = {
  title: "Demography: The Population Pyramid",
  blurb: "Drag through the decades and watch India's population pyramid change shape as birth rates fall.",
};

const AGE_GROUPS = ["0–14", "15–29", "30–44", "45–59", "60+"];

function popShare(gi: number, year: number) {
  // stylised India: young-heavy in 1960, ageing by 2026
  const t = (year - 1960) / 66;
  const young = [42, 26, 18, 9, 5];
  const old = [26, 27, 22, 14, 11];
  return young[gi] + (old[gi] - young[gi]) * t;
}

function Animator({ bars, elapsed, speed, setYear }: { bars: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number; setYear: (y: number) => void }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (speed > 0) setYear(1960 + ((elapsed.current * 8) % 66));
    if (bars.current) {
      bars.current.children.forEach((pair) => {
        pair.children.forEach((b) => {
          const m = b as THREE.Mesh;
          const target = (m.userData.share as number) / 42;
          m.scale.x += (Math.max(0.08, target) - m.scale.x) * 0.1;
        });
      });
    }
  });
  return null;
}

export function Topic10176Sim(props: SimProps) {
  const speed = Number(props.speed ?? 0);
  const manualYear = Number(props.year ?? 1990);
  const [autoY, setAutoY] = useState(manualYear);
  const lastY = useRef(-1);
  const setYear = (y: number) => { const i = Math.round(y); if (i !== lastY.current) { lastY.current = i; setAutoY(i); } };
  const year = speed > 0 ? autoY : manualYear;
  const bars = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const young = Math.round(popShare(0, year));

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Year", `${year}`], ["Children 0–14", `${young}%`], ["Trend", year < 1990 ? "high birth rate" : "ageing population"]]} />
      <SimCanvas cameraPosition={[0, 3.8, 14]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* centre axis */}
        <mesh position={[0, 2.6, 0]}>
          <boxGeometry args={[0.12, 5.6, 0.3]} />
          <meshStandardMaterial color="#94a3b8" roughness={0.7} />
        </mesh>
        <Label text="♂ MALE" position={[-4.6, 5.8, 0]} size={0.55} color="#7dd3fc" />
        <Label text="FEMALE ♀" position={[4.6, 5.8, 0]} size={0.55} color="#f9a8d4" />
        <group ref={bars}>
          {AGE_GROUPS.map((g, gi) => (
            <group key={g} position={[0, 0.8 + gi * 1.05, 0]}>
              {[-1, 1].map((side) => (
                <mesh
                  key={side}
                  position={[(side * 2.6) / 2, 0, 0]}
                  castShadow
                  userData={{ share: popShare(gi, year) }}
                >
                  <boxGeometry args={[2.6, 0.85, 0.9]} />
                  <meshStandardMaterial color={side < 0 ? "#38bdf8" : "#f472b6"} roughness={0.6} />
                </mesh>
              ))}
              <Label text={g} position={[0, 0, 1]} size={0.42} color="#e2e8f0" />
            </group>
          ))}
        </group>
        <Label text="POPULATION PYRAMID" position={[0, 6.8, 0]} size={0.7} color="#93c5fd" />
        <Animator bars={bars} elapsed={elapsed} speed={speed} setYear={setYear} />
      </SimCanvas>
    </div>
  );
}
