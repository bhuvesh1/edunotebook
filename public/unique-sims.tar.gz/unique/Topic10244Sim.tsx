// Hernias — inguinal, femoral, incisional, umbilical. An abdominal wall with
// a defect; a loop of bowel bulges through it. The strain slider (coughing /
// lifting) makes the bulge pop out further; site select moves the defect.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "strain", label: "Strain (cough/lift)", kind: "slider", min: 0, max: 100, step: 5, default: 50, unit: "%" },
  { key: "site", label: "Hernia site", kind: "select", min: 0, max: 0, step: 1, default: "inguinal", options: ["inguinal", "femoral", "umbilical", "incisional"] },
];

export const UNIQUE_META = {
  title: "Hernias",
  blurb: "A weak spot in the belly wall lets bowel bulge through — strain (cough) and watch it pop out; move the defect between four classic sites.",
};

function Animator({ bulge, elapsed, strain }: {
  bulge: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  strain: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (bulge.current) {
      // cough spikes
      const cough = Math.max(0, Math.sin(t * 2.2)) ** 6;
      const pop = 0.55 + (strain / 100) * 0.45 + cough * 0.25;
      bulge.current.scale.setScalar(pop);
      bulge.current.children.forEach((c, i) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        if (strain > 75) m.emissiveIntensity = 0.3 + 0.3 * Math.sin(t * 6 + i);
      });
    }
  });
  return null;
}

export function Topic10244Sim(props: SimProps) {
  const strain = Number(props.strain ?? 50);
  const site = String(props.site ?? "inguinal");
  const bulge = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  // defect position per site
  const defect: [number, number, number] =
    site === "inguinal" ? [-1.3, 1.2, 1.35]
    : site === "femoral" ? [-1.5, 0.3, 1.3]
    : site === "umbilical" ? [0, 2.6, 1.45]
    : [1.6, 2.2, 1.35];
  const strang = strain > 80;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Site", site], ["Bulge", strain > 70 ? "large, tense ⚠" : "reducible"], ["Risk", strang ? "strangulation risk — emergency" : "watchful"]]} />
      <SimCanvas cameraPosition={[0, 2.8, 12]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* torso */}
        <mesh position={[0, 2.6, 0]} castShadow>
          <cylinderGeometry args={[2.1, 2.3, 5.4, 26]} />
          <meshStandardMaterial color="#f5d0b8" roughness={0.65} />
        </mesh>
        {/* abdominal wall muscle layer (front) */}
        <mesh position={[0, 2.6, 1.15]}>
          <cylinderGeometry args={[2.12, 2.32, 5.0, 26, 1, true, -Math.PI * 0.42, Math.PI * 0.84]} />
          <meshStandardMaterial color="#dc2626" roughness={0.6} side={THREE.DoubleSide} />
        </mesh>
        {/* the defect: dark hole in the wall */}
        <mesh position={defect}>
          <circleGeometry args={[0.55, 20]} />
          <meshStandardMaterial color="#450a0a" roughness={0.9} />
        </mesh>
        {/* bowel inside */}
        <mesh position={[0, 2.6, 0.3]} rotation={[0, 0, Math.PI / 2]}>
          <torusGeometry args={[1.1, 0.42, 12, 26]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.55} />
        </mesh>

        {/* the herniating bulge */}
        <group ref={bulge} position={[defect[0], defect[1], defect[2] + 0.5]}>
          <mesh scale={[1, 1.25, 0.9]}>
            <sphereGeometry args={[0.75, 20, 16]} />
            <meshStandardMaterial color={strang ? "#991b1b" : "#f9a8d4"} roughness={0.55} emissive={strang ? "#7f1d1d" : "#000"} emissiveIntensity={0.4} />
          </mesh>
          <mesh position={[0, 0.1, 0.1]} rotation={[0.4, 0, 0.3]}>
            <torusGeometry args={[0.4, 0.18, 10, 18]} />
            <meshStandardMaterial color="#fda4af" roughness={0.5} />
          </mesh>
        </group>

        <Label text={`${site} hernia`} position={[defect[0], defect[1] + 1.9, defect[2]]} size={0.55} color={strang ? "#fca5a5" : "#fde047"} />
        {strang && <Label text="Can't push back + severe pain = EMERGENCY" position={[0, 6.2, 0]} size={0.5} color="#fca5a5" />}
        <Label text="Cough / lift / strain pops it out further" position={[0, -1.1, 0]} size={0.44} color="#94a3b8" />
        <Animator bulge={bulge} elapsed={elapsed} strain={strain} />
      </SimCanvas>
    </div>
  );
}
