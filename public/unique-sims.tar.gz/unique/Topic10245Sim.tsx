// Acute abdomen — appendicitis, peritonitis & intestinal obstruction. An
// inflamed appendix (worm-like tube) reddens and swells on the cecum; flip
// to obstruction and a bowel loop balloons with trapped gas; peritonitis
// reddens the whole lining.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "severity", label: "Severity", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "emergency", label: "Emergency", kind: "select", min: 0, max: 0, step: 1, default: "appendicitis", options: ["appendicitis", "intestinal obstruction", "peritonitis"] },
];

export const UNIQUE_META = {
  title: "Acute Abdomen",
  blurb: "An appendix swells red, a bowel loop balloons with trapped gas, or the whole lining ignites — the surgical emergencies of belly pain.",
};

function Animator({ target, elapsed, emergency, severity }: {
  target: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  emergency: string;
  severity: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (target.current) {
      target.current.children.forEach((c, i) => {
        const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
        // inflamed tissue throbs
        m.emissiveIntensity = (severity / 100) * (0.35 + 0.3 * Math.sin(t * 3.5 + i * 1.6));
        if (emergency === "intestinal obstruction") {
          c.scale.set(1 + (severity / 100) * 0.25 * Math.sin(t * 2 + i), 1, 1 + (severity / 100) * 0.25 * Math.sin(t * 2 + i));
        }
      });
    }
  });
  return null;
}

export function Topic10245Sim(props: SimProps) {
  const severity = Number(props.severity ?? 60);
  const emergency = String(props.emergency ?? "appendicitis");
  const target = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const f = severity / 100;
  const ruptured = emergency === "appendicitis" && severity > 80;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Emergency", emergency], ["Severity", `${severity}%`], ["Sign", emergency === "appendicitis" ? "McBurney's point tenderness" : emergency === "intestinal obstruction" ? "no gas/stool, distension" : "rigid board-like belly ⚠"]]} />
      <SimCanvas cameraPosition={[0, 3, 12.5]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* abdominal cavity */}
        <mesh position={[0, 2.6, -0.6]} castShadow>
          <boxGeometry args={[7.4, 5.2, 3.4]} />
          <meshStandardMaterial color="#f5d0b8" roughness={0.65} />
        </mesh>
        {/* peritoneum lining (ignites in peritonitis) */}
        <mesh position={[0, 2.6, 1.15]}>
          <boxGeometry args={[7.0, 4.8, 0.15]} />
          <meshStandardMaterial color={emergency === "peritonitis" ? "#ef4444" : "#fda4af"} roughness={0.55} transparent opacity={emergency === "peritonitis" ? 0.85 : 0.45} emissive={emergency === "peritonitis" ? "#7f1d1d" : "#000"} emissiveIntensity={0.4} />
        </mesh>

        <group ref={target}>
          {emergency === "appendicitis" && (
            <group position={[-1.6, 1.6, 0.6]}>
              {/* cecum */}
              <mesh scale={[1, 1.3, 0.9]}>
                <sphereGeometry args={[0.75, 18, 14]} />
                <meshStandardMaterial color="#f9a8d4" roughness={0.55} />
              </mesh>
              {/* appendix: worm tube, swollen & red */}
              <mesh position={[0.5, -0.7, 0.2]} rotation={[0, 0, -0.5]} scale={[1 + f * 0.9, 1 + f * 0.4, 1 + f * 0.9]}>
                <capsuleGeometry args={[0.22, 1.1, 6, 12]} />
                <meshStandardMaterial color="#dc2626" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.4} />
              </mesh>
              {ruptured && (
                <mesh position={[0.5, -0.7, 0.6]}>
                  <sphereGeometry args={[0.55, 12, 10]} />
                  <meshStandardMaterial color="#facc15" roughness={0.4} emissive="#a16207" emissiveIntensity={0.5} transparent opacity={0.8} />
                </mesh>
              )}
              <Label text={ruptured ? "RUPTURED — pus leaking ⚠" : "Inflamed appendix"} position={[0.5, -2.3, 0.6]} size={0.52} color="#fca5a5" />
            </group>
          )}
          {emergency === "intestinal obstruction" && (
            <group position={[0, 2.6, 0.6]}>
              {[0, 1, 2].map((i) => (
                <mesh key={i} position={[-2 + i * 2, 0.4 - i * 0.3, 0]} rotation={[0, 0, Math.PI / 2]} scale={[1 + f * 0.55, 1 + f * 0.55, 1]}>
                  <capsuleGeometry args={[0.5, 1.4, 8, 14]} />
                  <meshStandardMaterial color="#fda4af" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.25} />
                </mesh>
              ))}
              {/* blockage point */}
              <mesh position={[2.9, -0.2, 0]}>
                <dodecahedronGeometry args={[0.4, 0]} />
                <meshStandardMaterial color="#78350f" roughness={0.9} flatShading />
              </mesh>
              <Label text="Blocked here — gas & fluid pile up behind" position={[2.9, 1.3, 0]} size={0.5} color="#fde047" />
            </group>
          )}
          {emergency === "peritonitis" && (
            <group position={[0, 2.6, 0.6]}>
              {Array.from({ length: 10 }).map((_, i) => (
                <mesh key={i} position={[((i * 0.97) % 5.6) - 2.8, ((i * 0.61) % 3.6) - 1.8, 0.2]}>
                  <sphereGeometry args={[0.22, 10, 8]} />
                  <meshStandardMaterial color="#facc15" roughness={0.4} emissive="#a16207" emissiveIntensity={0.5} />
                </mesh>
              ))}
              <Label text="Pus everywhere — rigid belly, emergency surgery" position={[0, 2.8, 0.4]} size={0.52} color="#fca5a5" />
            </group>
          )}
        </group>

        <Label text="Sudden severe belly pain + vomiting = think surgical emergency" position={[0, -1.3, 0]} size={0.44} color="#94a3b8" />
        <Animator target={target} elapsed={elapsed} emergency={emergency} severity={severity} />
      </SimCanvas>
    </div>
  );
}
