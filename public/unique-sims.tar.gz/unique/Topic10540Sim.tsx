// app/components/sims/unique/Topic10540Sim.tsx
// Space maintainers: a dental arch with a missing baby tooth leaves a gap.
// A band-and-loop appliance holds the space while the neighboring teeth
// try (and fail) to drift into it.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "app", label: "Appliance", kind: "select", min: 0, max: 0, step: 1, default: "band-loop", options: ["band-loop", "lingual-arch", "none"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Space Maintainers & Regainers",
  blurb: "A baby tooth is lost early — the band-and-loop holds its space so the permanent tooth has room to erupt.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ drifters, loop, elapsed, speed, app }: {
  drifters: RefObject<THREE.Group>[]; loop: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number; app: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // without an appliance the neighbors drift into the gap; with one they bounce off the loop
    const hasApp = app !== "none";
    drifters.forEach((d, i) => {
      if (!d.current) return;
      const dir = i === 0 ? 1 : -1; // toward the gap
      const pull = hasApp ? 0.12 + 0.06 * Math.sin(t * 3 + i) : 0.55 * (0.5 - 0.5 * Math.cos(t * 0.8));
      d.current.position.x = d.current.userData.bx + dir * pull;
    });
    if (loop.current) {
      loop.current.visible = app !== "none";
      loop.current.position.y = 0.05 * Math.sin(t * 3);
    }
  });
  return null;
}

const INFO: Record<string, { name: string; note: string }> = {
  "band-loop": { name: "Band & loop", note: "single missing tooth — band on molar, wire loop holds space" },
  "lingual-arch": { name: "Lingual arch", note: "multiple missing teeth — wire hugs the tongue side" },
  none: { name: "No appliance", note: "neighbors drift in — space is lost!" },
};

export function Topic10540Sim(props: SimProps) {
  const app = String(props.app ?? "band-loop");
  const speed = Number(props.speed ?? 1);
  const d0 = useRef<THREE.Group>(null!);
  const d1 = useRef<THREE.Group>(null!);
  const loop = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = INFO[app];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Appliance", info.name],
          ["Space", app === "none" ? "closing — LOST ⚠" : "held open ✓"],
          ["Why", info.note],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.2, 11]} target={[0, 1, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* gum base */}
        <mesh position={[0, 0.6, 0]} castShadow>
          <boxGeometry args={[8.4, 0.7, 1.8]} />
          <meshStandardMaterial color="#e0607a" roughness={0.6} />
        </mesh>

        {/* stable teeth */}
        {[-3.6, -2.7, 2.7, 3.6].map((x, i) => (
          <mesh key={i} position={[x, 1.5, 0]} castShadow>
            <boxGeometry args={[0.7, 0.9, 0.7]} />
            <meshStandardMaterial color="#fefce8" roughness={0.3} />
          </mesh>
        ))}

        {/* drifting neighbors beside the gap */}
        <group ref={d0} position={[0, 0, 0]} userData={{ bx: -1.35 }}>
          <mesh position={[-1.35, 1.5, 0]} castShadow>
            <boxGeometry args={[0.7, 0.9, 0.7]} />
            <meshStandardMaterial color="#fde68a" roughness={0.3} />
          </mesh>
        </group>
        <group ref={d1} position={[0, 0, 0]} userData={{ bx: 1.35 }}>
          <mesh position={[1.35, 1.5, 0]} castShadow>
            <boxGeometry args={[0.7, 0.9, 0.7]} />
            <meshStandardMaterial color="#fde68a" roughness={0.3} />
          </mesh>
        </group>

        {/* the gap: missing baby tooth */}
        <mesh position={[0, 1.0, 0]}>
          <boxGeometry args={[1.5, 0.25, 1.2]} />
          <meshStandardMaterial color="#7f1d1d" transparent opacity={0.5} roughness={0.8} />
        </mesh>
        <Label p={[0, 2.6, 0]} size={0.3} color="#fca5a5">empty space — permanent tooth coming</Label>

        {/* band-and-loop / lingual arch appliance */}
        <group ref={loop} visible={app !== "none"}>
          {/* band on the molar */}
          <mesh position={[-2.7, 1.5, 0]} castShadow>
            <cylinderGeometry args={[0.52, 0.52, 0.6, 14, 1, true]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} side={THREE.DoubleSide} />
          </mesh>
          {app === "band-loop" ? (
            /* wire loop spanning the gap */
            <mesh position={[-1.35, 1.35, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
              <torusGeometry args={[0.85, 0.07, 10, 24]} />
              <meshStandardMaterial color="#cbd5e1" metalness={0.85} roughness={0.3} />
            </mesh>
          ) : (
            /* lingual arch wire along the tongue side */
            <mesh position={[0, 1.35, -0.75]} castShadow>
              <boxGeometry args={[6.4, 0.12, 0.12]} />
              <meshStandardMaterial color="#cbd5e1" metalness={0.85} roughness={0.3} />
            </mesh>
          )}
          {/* bands on both molars for lingual arch */}
          {app === "lingual-arch" && (
            <mesh position={[2.7, 1.5, 0]} castShadow>
              <cylinderGeometry args={[0.52, 0.52, 0.6, 14, 1, true]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} side={THREE.DoubleSide} />
            </mesh>
          )}
        </group>

        <Label p={[-2.7, 2.6, 0]} size={0.28} color="#cbd5e1">band on molar</Label>
        <Label p={[0, -0.6, 0]} size={0.32} color="#e2e8f0">{info.name} — {info.note}</Label>

        <Animator drifters={[d0, d1]} loop={loop} elapsed={elapsed} speed={speed} app={app} />
      </SimCanvas>
    </div>
  );
}
