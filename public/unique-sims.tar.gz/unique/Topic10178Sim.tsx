"use client";
// National programs: NVBDCP (vector-borne), NLEP (leprosy), NPCB (blindness).
// A flapping mosquito, a healing hand and a bright eye — pick the
// program and its symbol takes centre stage.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "program", label: "Program", kind: "select", min: 0, max: 0, step: 1, default: "nvbdcp", options: ["nvbdcp", "nlep", "npcb"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Vector-Borne, Leprosy & Blindness Programs",
  blurb: "Mosquito versus net, healing hands, and a bright eye — three national programs, three symbols in motion.",
};

const PROG_TXT: Record<string, string> = {
  nvbdcp: "NVBDCP: mosquito nets beat malaria & dengue",
  nlep: "NLEP: leprosy is curable — MDT works",
  npcb: "NPCB: cataract surgery restores sight",
};

function Animator({ wings, net, elapsed, speed, program }: { wings: React.RefObject<THREE.Group>; net: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; speed: number; program: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (wings.current) {
      const flap = Math.sin(elapsed.current * (program === "nvbdcp" ? 22 : 4)) * 0.7;
      wings.current.children.forEach((w, i) => {
        w.rotation.z = (i === 0 ? 1 : -1) * (0.5 + flap * (i === 0 ? 1 : -1) * 0.5);
      });
      wings.current.position.y = 3 + Math.sin(elapsed.current * 2) * 0.25;
      wings.current.position.x = -4.4 + Math.sin(elapsed.current * 0.9) * 0.8;
    }
    if (net.current) {
      (net.current.material as THREE.MeshStandardMaterial).opacity = 0.25 + Math.sin(elapsed.current * 1.5) * 0.08;
    }
  });
  return null;
}

export function Topic10178Sim(props: SimProps) {
  const program = String(props.program ?? "nvbdcp");
  const speed = Number(props.speed ?? 1);
  const wings = useRef<THREE.Group>(null!);
  const net = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const dim = (k: string) => (program === k ? 1 : 0.3);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Program", program.toUpperCase()], ["Goal", PROG_TXT[program] ?? ""]]} />
      <SimCanvas cameraPosition={[0, 3.4, 13]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* NVBDCP: mosquito + net */}
        <group scale={[dim("nvbdcp"), dim("nvbdcp"), dim("nvbdcp")]}>
          <group ref={wings} position={[-4.4, 3, 0]}>
            <mesh castShadow>
              <capsuleGeometry args={[0.18, 0.7, 6, 10]} />
              <meshStandardMaterial color="#1e293b" roughness={0.6} />
            </mesh>
            <group>
              {[-1, 1].map((s) => (
                <mesh key={s} position={[s * 0.45, 0.25, 0]} rotation={[0, 0, s * 0.5]}>
                  <boxGeometry args={[0.7, 0.06, 0.4]} />
                  <meshStandardMaterial color="#bae6fd" transparent opacity={0.7} roughness={0.3} />
                </mesh>
              ))}
            </group>
          </group>
          <mesh ref={net} position={[-1.6, 1.8, 0]}>
            <boxGeometry args={[2.6, 2.6, 2.6]} />
            <meshStandardMaterial color="#e0f2fe" transparent opacity={0.28} roughness={0.4} depthWrite={false} />
          </mesh>
          <Label text="NVBDCP: MOSQUITO vs NET" position={[-3, 4.8, 0]} size={0.55} color={program === "nvbdcp" ? "#7dd3fc" : "#64748b"} />
        </group>
        {/* NLEP: healing hands */}
        <group position={[0.4, 0, 0]} scale={[dim("nlep"), dim("nlep"), dim("nlep")]}>
          {[-0.8, 0.8].map((x, i) => (
            <group key={x} position={[x, 1.8, 0]} rotation={[0, 0, i === 0 ? 0.5 : -0.5]}>
              <mesh castShadow>
                <boxGeometry args={[0.55, 1.6, 0.35]} />
                <meshStandardMaterial color="#fcd9b8" roughness={0.7} />
              </mesh>
              {[0, 1, 2, 3].map((f) => (
                <mesh key={f} position={[(f - 1.5) * 0.14, 1.05, 0]}>
                  <boxGeometry args={[0.11, 0.5, 0.3]} />
                  <meshStandardMaterial color="#fcd9b8" roughness={0.7} />
                </mesh>
              ))}
            </group>
          ))}
          <mesh position={[0, 3.1, 0]}>
            <boxGeometry args={[0.7, 0.24, 0.1]} />
            <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.6} />
          </mesh>
          <mesh position={[0, 3.1, 0]}>
            <boxGeometry args={[0.24, 0.7, 0.1]} />
            <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.6} />
          </mesh>
          <Label text="NLEP: LEPROSY CURABLE" position={[0.4, 4.4, 0]} size={0.55} color={program === "nlep" ? "#86efac" : "#64748b"} />
        </group>
        {/* NPCB: bright eye */}
        <group position={[4.6, 2.2, 0]} scale={[dim("npcb"), dim("npcb"), dim("npcb")]}>
          <mesh castShadow>
            <sphereGeometry args={[1.1, 22, 18]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.35} />
          </mesh>
          <mesh position={[0, 0, 0.85]}>
            <sphereGeometry args={[0.45, 18, 18]} />
            <meshStandardMaterial color="#1d4ed8" roughness={0.25} />
          </mesh>
          <mesh position={[0, 0, 1.15]}>
            <sphereGeometry args={[0.2, 14, 14]} />
            <meshStandardMaterial color="#0f172a" roughness={0.2} />
          </mesh>
          <mesh position={[-0.35, 0.45, 1.05]}>
            <sphereGeometry args={[0.12, 10, 10]} />
            <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.9} />
          </mesh>
          <Label text="NPCB: CLEAR VISION" position={[0, 1.9, 0]} size={0.55} color={program === "npcb" ? "#93c5fd" : "#64748b"} />
        </group>
        <Animator wings={wings} net={net} elapsed={elapsed} speed={speed} program={program} />
      </SimCanvas>
    </div>
  );
}
