// Obstetrics: abnormal labor — malpresentations, obstructed labor, C-section.
// The baby lies wrong: breech (bottom first), transverse (sideways), or stuck
// at the pelvis — then the C-section scar shows the surgical rescue.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "problem", label: "Problem", kind: "select", min: 0, max: 0, step: 1, default: "breech", options: ["breech", "transverse", "obstructed", "csection"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Abnormal Labor: Breech to C-Section",
  blurb: "When the baby lies wrong — breech, sideways, or stuck — see why a C-section becomes the safe rescue.",
};

function Animator({
  group, baby, warn, elapsed, speed, problem,
}: {
  group: React.RefObject<THREE.Group>;
  baby: React.RefObject<THREE.Group>;
  warn: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  problem: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
    if (baby.current) {
      if (problem === "obstructed") {
        // pushes but cannot pass: small futile bobs
        baby.current.position.y = 1.9 + Math.max(0, Math.sin(t * 2.2)) * 0.12;
      } else if (problem === "csection") {
        // baby lifted out through the incision
        const cyc = (t % 10) / 10;
        const lift = cyc < 0.5 ? (cyc / 0.5) : 1 - (cyc - 0.5) / 0.5;
        baby.current.position.y = 1.9 + lift * 1.6;
        baby.current.position.z = 0.6 + lift * 0.9;
      } else {
        baby.current.position.y = 2.2 + Math.sin(t * 1.1) * 0.08;
      }
    }
    if (warn.current) {
      warn.current.children.forEach((w, i) => {
        (w as THREE.Mesh).scale.setScalar(1 + 0.3 * Math.sin(t * 5 + i * 2));
      });
    }
  });
  return null;
}

function BabyFigure({ color = "#fde68a" }: { color?: string }) {
  return (
    <group>
      <mesh position={[0, 0.55, 0]} castShadow>
        <sphereGeometry args={[0.4, 22, 16]} />
        <meshStandardMaterial color={color} roughness={0.6} />
      </mesh>
      <mesh position={[0, -0.25, 0]} scale={[0.9, 1.1, 0.8]} castShadow>
        <sphereGeometry args={[0.38, 22, 16]} />
        <meshStandardMaterial color={color} roughness={0.6} />
      </mesh>
      {[-0.32, 0.32].map((x, i) => (
        <mesh key={i} position={[x, -0.75, 0.1]} rotation={[0, 0, i === 0 ? 0.4 : -0.4]} castShadow>
          <capsuleGeometry args={[0.1, 0.35, 6, 10]} />
          <meshStandardMaterial color={color} roughness={0.6} />
        </mesh>
      ))}
    </group>
  );
}

export function Topic10278Sim(props: SimProps) {
  const problem = String(props.problem ?? "breech");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const baby = useRef<THREE.Group>(null!);
  const warn = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    breech: "Breech (bottom first)", transverse: "Transverse lie (sideways)",
    obstructed: "Obstructed labor (stuck)", csection: "C-section rescue",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Problem", names[problem] ?? problem], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.6, 10.5]} target={[0, 2.0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* pelvis ring */}
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 1.35, 1.6, 0]} rotation={[0, 0, s * 0.35]} castShadow>
              <torusGeometry args={[1.05, 0.28, 14, 24, Math.PI * 1.1]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.5} />
            </mesh>
          ))}
          {/* uterus */}
          <mesh position={[0, 3.5, -0.3]} scale={[1.15, 1.3, 1]} castShadow>
            <sphereGeometry args={[1.05, 28, 20]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} transparent opacity={0.55} />
          </mesh>
          {/* baby in the problem position */}
          <group ref={baby} position={[0, 2.2, 0.1]} rotation={[0, 0, problem === "transverse" ? Math.PI / 2 : problem === "breech" ? Math.PI : 0]}>
            <BabyFigure />
          </group>
          {/* warning markers at the pinch point */}
          <group ref={warn} position={[0, 1.0, 0.7]}>
            {[-0.5, 0.5].map((x, i) => (
              <mesh key={i} position={[x, 0, 0]}>
                <sphereGeometry args={[0.2, 12, 10]} />
                <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={1.4} transparent opacity={0.9} />
              </mesh>
            ))}
          </group>
          {/* C-section incision line on the belly */}
          {problem === "csection" && (
            <>
              <mesh position={[0, 2.2, 1.15]} rotation={[0, 0, 0]} castShadow>
                <boxGeometry args={[2.2, 0.14, 0.06]} />
                <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={0.9} />
              </mesh>
              {Array.from({ length: 6 }).map((_, i) => (
                <mesh key={i} position={[-0.85 + i * 0.34, 2.2, 1.2]} rotation={[Math.PI / 2, 0, 0.4]}>
                  <torusGeometry args={[0.09, 0.03, 8, 12]} />
                  <meshStandardMaterial color="#e2e8f0" roughness={0.4} />
                </mesh>
              ))}
            </>
          )}
          <Label text="Pelvis" position={[2.7, 2.1, 0]} size={0.55} color="#e2e8f0" />
          {problem === "breech" && <Label text="⚠ Bottom first — risky" position={[0, 0.3, 0.4]} size={0.55} color="#fca5a5" />}
          {problem === "transverse" && <Label text="⚠ Sideways — can't deliver" position={[0, 0.3, 0.4]} size={0.55} color="#fca5a5" />}
          {problem === "obstructed" && <Label text="⚠ Head stuck at pelvis" position={[0, 0.3, 0.4]} size={0.55} color="#fca5a5" />}
          {problem === "csection" && <Label text="✂ C-section: safe delivery" position={[0, 0.3, 0.4]} size={0.55} color="#86efac" />}
        </group>
        <Animator group={group} baby={baby} warn={warn} elapsed={elapsed} speed={speed} problem={problem} />
      </SimCanvas>
    </div>
  );
}
