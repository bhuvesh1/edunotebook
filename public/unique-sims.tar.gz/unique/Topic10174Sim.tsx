"use client";
// Environment: water, air, sanitation, waste management.
// A water drop falls through filter layers into a clean glass, a cloud
// puffs clean air, and a bin swallows waste — pick the element to clean.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "factor", label: "Element", kind: "select", min: 0, max: 0, step: 1, default: "water", options: ["water", "air", "waste"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Environment: Water, Air, Sanitation & Waste",
  blurb: "Dirty water drips through a filter into a clean glass, smoke turns to fresh air, and waste lands in the right bin.",
};

const FACTOR_TXT: Record<string, string> = {
  water: "Safe water: filter or boil it",
  air: "Clean air: less smoke, more trees",
  waste: "Segregate waste: wet, dry, hazardous",
};
const N_DROPS = 10;

function Animator({ drops, puffs, elapsed, speed, factor }: { drops: React.RefObject<THREE.Group>; puffs: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number; factor: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (drops.current) {
      drops.current.visible = factor === "water";
      drops.current.children.forEach((d, i) => {
        const ph = (elapsed.current * 0.9 + i / N_DROPS) % 1;
        d.position.y = 4.6 - ph * 4.2;
      });
    }
    if (puffs.current) {
      puffs.current.visible = factor === "air";
      puffs.current.children.forEach((p, i) => {
        const ph = (elapsed.current * 0.4 + i / 6) % 1;
        p.position.y = 1.6 + ph * 2.6;
        p.position.x = 3.6 + Math.sin(ph * 5 + i) * 0.5;
        const s = 0.6 + ph * 1.1;
        p.scale.set(s, s, s);
        (p as THREE.Mesh).material = (p as THREE.Mesh).material;
      });
    }
  });
  return null;
}

export function Topic10174Sim(props: SimProps) {
  const factor = String(props.factor ?? "water");
  const speed = Number(props.speed ?? 1);
  const drops = useRef<THREE.Group>(null!);
  const puffs = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const dropMeshes = useMemo(
    () =>
      Array.from({ length: N_DROPS }, (_, i) => (
        <mesh key={i} position={[-4.4, 4.6 - (i / N_DROPS) * 4.2, 0]}>
          <sphereGeometry args={[0.14, 10, 10]} />
          <meshStandardMaterial color="#7dd3fc" emissive="#38bdf8" emissiveIntensity={0.8} />
        </mesh>
      )),
    []
  );
  const puffMeshes = useMemo(
    () =>
      Array.from({ length: 6 }, (_, i) => (
        <mesh key={i} position={[3.6, 1.6, 0]}>
          <sphereGeometry args={[0.5, 12, 12]} />
          <meshStandardMaterial color="#e0f2fe" transparent opacity={0.55} roughness={0.9} />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Element", factor], ["Rule", FACTOR_TXT[factor] ?? ""]]} />
      <SimCanvas cameraPosition={[0, 3.6, 13]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* water filter station */}
        <group position={[-4.4, 0, 0]}>
          <mesh position={[0, 5.2, 0]} castShadow>
            <sphereGeometry args={[0.5, 14, 14]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.3} />
          </mesh>
          <mesh position={[0, 5.75, 0]}>
            <coneGeometry args={[0.28, 0.55, 12]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.3} />
          </mesh>
          {["sand", "charcoal", "gravel"].map((l, i) => (
            <mesh key={l} position={[0, 3.9 - i * 0.75, 0]} castShadow>
              <boxGeometry args={[2, 0.6, 2]} />
              <meshStandardMaterial color={["#d6b48a", "#3f3f46", "#a8a29e"][i]} roughness={0.95} />
            </mesh>
          ))}
          <mesh position={[0, 1.15, 0]}>
            <cylinderGeometry args={[0.7, 0.55, 1.3, 14, 1, true]} />
            <meshStandardMaterial color="#e2e8f0" transparent opacity={0.4} roughness={0.15} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[0, 0.85, 0]}>
            <cylinderGeometry args={[0.55, 0.45, 0.6, 14]} />
            <meshStandardMaterial color="#7dd3fc" transparent opacity={0.8} roughness={0.2} />
          </mesh>
          <group ref={drops}>{dropMeshes}</group>
          <Label text="💧 WATER FILTER" position={[0, 6.6, 0]} size={0.6} color={factor === "water" ? "#7dd3fc" : "#64748b"} />
        </group>
        {/* air station */}
        <group position={[3.6, 0, 0]}>
          <mesh position={[0, 0.9, 0]} castShadow>
            <boxGeometry args={[1.4, 1.8, 1.4]} />
            <meshStandardMaterial color="#475569" roughness={0.8} />
          </mesh>
          <mesh position={[0, 2.1, 0]}>
            <cylinderGeometry args={[0.3, 0.5, 0.7, 10]} />
            <meshStandardMaterial color="#64748b" roughness={0.8} />
          </mesh>
          <group ref={puffs}>{puffMeshes}</group>
          {/* tree */}
          <mesh position={[2.2, 0.8, 0]} castShadow>
            <cylinderGeometry args={[0.14, 0.18, 1.2, 8]} />
            <meshStandardMaterial color="#78350f" roughness={0.9} />
          </mesh>
          <mesh position={[2.2, 1.9, 0]} castShadow>
            <sphereGeometry args={[0.8, 12, 12]} />
            <meshStandardMaterial color="#4d7c0f" roughness={0.8} />
          </mesh>
          <Label text="🌬 CLEAN AIR" position={[0, 4.9, 0]} size={0.6} color={factor === "air" ? "#7dd3fc" : "#64748b"} />
        </group>
        {/* waste bins */}
        <group position={[0, 0, 3.4]}>
          {[
            { c: "#22c55e", t: "WET", x: -1.4 },
            { c: "#38bdf8", t: "DRY", x: 0 },
            { c: "#ef4444", t: "HAZARD", x: 1.4 },
          ].map((b) => (
            <group key={b.t} position={[b.x, 0, 0]}>
              <mesh position={[0, 0.8, 0]} castShadow>
                <cylinderGeometry args={[0.5, 0.42, 1.4, 12]} />
                <meshStandardMaterial color={b.c} roughness={0.7} />
              </mesh>
              <mesh position={[0, 1.6, 0]}>
                <cylinderGeometry args={[0.55, 0.55, 0.14, 12]} />
                <meshStandardMaterial color="#1e293b" roughness={0.7} />
              </mesh>
              <Label text={b.t} position={[0, 0.15, 0]} size={0.42} color="#f8fafc" />
            </group>
          ))}
          <Label text="🗑 SEGREGATE WASTE" position={[0, 2.6, 0]} size={0.6} color={factor === "waste" ? "#4ade80" : "#64748b"} />
        </group>
        <Animator drops={drops} puffs={puffs} elapsed={elapsed} speed={speed} factor={factor} />
      </SimCanvas>
    </div>
  );
}
