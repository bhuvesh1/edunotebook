// Neurophysiology: motor system, basal ganglia, cerebellum — the motor cortex
// flashes, the command races down the corticospinal tract, and the hand
// muscle twitches; basal ganglia gate and cerebellum fine-tune the movement.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "move", label: "Movement", kind: "select", min: 0, max: 0, step: 1, default: "voluntary", options: ["voluntary", "reflex"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Neurophysiology: Motor System",
  blurb: "Motor cortex fires → corticospinal tract → muscle twitch. Compare the slow voluntary path with a fast reflex arc.",
};

function Animator({
  command, motorCtx, muscleArm, elapsed, voluntary, speed,
}: {
  command: React.RefObject<THREE.Group>;
  motorCtx: React.RefObject<THREE.Mesh>;
  muscleArm: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  voluntary: boolean;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const cyc = (t * (voluntary ? 0.5 : 1.4)) % 1;
    // command travels brain -> cord -> muscle
    if (command.current) {
      command.current.children.forEach((m, i) => {
        const ph = ((cyc + i / 8) % 1 + 1) % 1;
        if (voluntary) {
          m.position.set(-3.5 + ph * 9.5, 5.2 - ph * 3.4, 0);
        } else {
          // reflex: skin -> cord -> muscle (short arc)
          if (ph < 0.4) {
            const f = ph / 0.4;
            m.position.set(7 - f * 4.5, 1.2 + f * 1.4, 0);
          } else {
            const f = (ph - 0.4) / 0.6;
            m.position.set(2.5 + f * 4.5, 2.6 - f * 1.4, 0);
          }
        }
        m.visible = cyc < 0.75;
      });
    }
    if (motorCtx.current) {
      const mat = motorCtx.current.material as THREE.MeshBasicMaterial;
      mat.opacity = voluntary ? 0.4 + 0.5 * Math.max(0, Math.sin(cyc * Math.PI * 2)) : 0.15;
    }
    if (muscleArm.current) {
      const twitch = Math.max(0, Math.sin((cyc - (voluntary ? 0.55 : 0.35)) * Math.PI * 4));
      muscleArm.current.rotation.z = (voluntary ? -0.5 : -0.35) * Math.max(0, twitch);
    }
  });
  return null;
}

export function Topic10053Sim(props: SimProps) {
  const voluntary = String(props.move ?? "voluntary") === "voluntary";
  const speed = 1;
  const command = useRef<THREE.Group>(null!);
  const motorCtx = useRef<THREE.Mesh>(null!);
  const muscleArm = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Pathway", voluntary ? "corticospinal (voluntary)" : "reflex arc (spinal)"],
          ["Latency", voluntary ? "~200 ms" : "~30 ms"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5, 15]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* brain with motor cortex */}
        <group position={[-3.5, 0, 0]}>
          <mesh position={[0, 5.6, 0]} castShadow scale={[1.2, 0.9, 1]}>
            <sphereGeometry args={[1.5, 22, 22]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.5} />
          </mesh>
          <mesh ref={motorCtx} position={[-0.5, 6.0, 0.9]}>
            <sphereGeometry args={[0.42, 12, 12]} />
            <meshBasicMaterial color="#fbbf24" transparent opacity={0.5} />
          </mesh>
          {/* basal ganglia (deep) */}
          <mesh position={[0.4, 5.0, 0]} castShadow>
            <sphereGeometry args={[0.4, 12, 12]} />
            <meshStandardMaterial color="#a78bfa" roughness={0.45} />
          </mesh>
          {/* cerebellum */}
          <mesh position={[1.6, 4.6, -0.6]} castShadow scale={[1, 0.7, 1]}>
            <sphereGeometry args={[0.7, 14, 14]} />
            <meshStandardMaterial color="#c084fc" roughness={0.5} />
          </mesh>
        </group>
        <Label text="motor cortex" position={[-4.6, 7.0, 0.9]} size={0.32} color="#fde68a" />
        <Label text="basal ganglia (gate)" position={[-2.4, 4.7, 0]} size={0.3} color="#c4b5fd" />
        <Label text="cerebellum (fine-tune)" position={[-1.2, 4.0, -0.6]} size={0.3} color="#d8b4fe" />
        <Label text="brain" position={[-3.5, 7.5, 0]} size={0.36} color="#f8fafc" />

        {/* corticospinal tract down */}
        <mesh position={[-3.0, 3.4, 0]} rotation={[0, 0, 0.12]} castShadow>
          <cylinderGeometry args={[0.2, 0.2, 3.4, 10]} />
          <meshStandardMaterial color={voluntary ? "#fbbf24" : "#475569"} roughness={0.45} />
        </mesh>
        <Label text={voluntary ? "corticospinal tract" : "corticospinal (idle)"} position={[-4.4, 3.4, 0]} size={0.3} color="#fde68a" />

        {/* spinal cord segment */}
        <mesh position={[-2.6, 1.4, 0]} castShadow>
          <cylinderGeometry args={[0.45, 0.45, 1.6, 14]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.5} />
        </mesh>
        {/* motor nerve to arm */}
        <mesh position={[1.4, 1.6, 0]} rotation={[0, 0, -0.15]} castShadow>
          <cylinderGeometry args={[0.12, 0.12, 7.6, 8]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.45} />
        </mesh>
        <Label text="lower motor neuron" position={[1.4, 0.9, 0]} size={0.3} color="#fde68a" />

        {/* arm with biceps that twitches */}
        <group position={[6.8, 0, 0]}>
          <mesh position={[0, 1.2, 0]} castShadow>
            <cylinderGeometry args={[0.28, 0.28, 2.4, 12]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.55} />
          </mesh>
          <group ref={muscleArm} position={[0, 2.4, 0]}>
            <mesh position={[0.5, 0.6, 0]} rotation={[0, 0, -0.9]} castShadow>
              <capsuleGeometry args={[0.3, 1.4, 6, 10]} />
              <meshStandardMaterial color="#fcd9b8" roughness={0.55} />
            </mesh>
            <mesh position={[0.75, 0.75, 0]} castShadow>
              <sphereGeometry args={[0.32, 12, 12]} />
              <meshStandardMaterial color="#ef4444" roughness={0.45} />
            </mesh>
          </group>
        </group>
        <Label text="biceps twitches" position={[6.8, 4.4, 0]} size={0.32} color="#fca5a5" />

        {/* reflex arc extras when reflex mode */}
        {!voluntary && (
          <group>
            <mesh position={[7, 1.2, 0]} castShadow>
              <boxGeometry args={[1.4, 0.3, 1.2]} />
              <meshStandardMaterial color="#fcd9b8" roughness={0.55} />
            </mesh>
            <mesh position={[6.4, 1.75, 0]} rotation={[0, 0, -0.7]} castShadow>
              <coneGeometry args={[0.1, 1.0, 8]} />
              <meshStandardMaterial color="#e2e8f0" metalness={0.7} roughness={0.3} />
            </mesh>
            <Label text="tendon tap → reflex arc" position={[7, 0.5, 0]} size={0.3} color="#f8fafc" />
            <Label text="no brain needed!" position={[2.5, 3.4, 0]} size={0.3} color="#86efac" />
          </group>
        )}

        {/* command volley */}
        <group ref={command}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[-3.5, 5.2, 0]}>
              <sphereGeometry args={[0.13, 8, 8]} />
              <meshBasicMaterial color="#fbbf24" />
            </mesh>
          ))}
        </group>

        <Animator command={command} motorCtx={motorCtx} muscleArm={muscleArm}
          elapsed={elapsed} voluntary={voluntary} speed={speed} />
      </SimCanvas>
    </div>
  );
}
