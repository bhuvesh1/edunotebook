// app/components/sims/unique/Topic10536Sim.tsx
// Pit and fissure sealants: a giant molar with deep dark fissures. Sealant
// liquid flows from the applicator tip and fills the grooves.

"use client";

import { useMemo, useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "fill", label: "Sealant coverage", kind: "slider", min: 0, max: 100, step: 1, default: 70, unit: "%" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Pit & Fissure Sealants",
  blurb: "Sealant flows into the molar's deep grooves, sealing out the bacteria that cause cavities.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

const DROPS = 18;

function Animator({ drops, sealant, elapsed, speed, fill }: {
  drops: RefObject<THREE.InstancedMesh>; sealant: RefObject<THREE.Group>;
  elapsed: RefObject<number>; speed: number; fill: number;
}) {
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (drops.current) {
      const active = fill > 2 ? DROPS : 0;
      for (let i = 0; i < DROPS; i++) {
        if (i < active) {
          const cyc = (t * 0.9 + i / DROPS) % 1;
          const lane = (i % 3) - 1;
          dummy.position.set(lane * 0.55 + Math.sin(i * 3) * 0.1, 5.2 - cyc * 2.6, Math.cos(i * 2) * 0.4);
          dummy.scale.setScalar(0.09);
        } else {
          dummy.position.set(0, -10, 0);
          dummy.scale.setScalar(0.001);
        }
        dummy.updateMatrix();
        drops.current.setMatrixAt(i, dummy.matrix);
      }
      drops.current.instanceMatrix.needsUpdate = true;
    }
    if (sealant.current) {
      // sealant level in the fissures rises with the fill slider
      const f = fill / 100;
      sealant.current.children.forEach((c) => {
        const m = c as THREE.Mesh;
        m.scale.y = Math.max(f * (1 + 0.05 * Math.sin(t * 2)), 0.001);
      });
    }
  });
  return null;
}

export function Topic10536Sim(props: SimProps) {
  const fill = Number(props.fill ?? 70);
  const speed = Number(props.speed ?? 1);
  const drops = useRef<THREE.InstancedMesh>(null!);
  const sealant = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Coverage", `${fill}%`],
          ["Protection", fill >= 80 ? "grooves fully sealed ✓" : fill >= 40 ? "partially sealed" : "grooves exposed — caries risk"],
          ["Material", "resin sealant"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* giant molar crown */}
        <mesh position={[0, 2.4, 0]} castShadow>
          <boxGeometry args={[3.4, 1.6, 3]} />
          <meshStandardMaterial color="#ffffff" roughness={0.25} />
        </mesh>
        {/* cusps */}
        {[[-1.1, -1], [1.1, -1], [-1.1, 1], [1.1, 1]].map(([x, z], i) => (
          <mesh key={i} position={[x, 3.45, z]} castShadow>
            <coneGeometry args={[0.55, 0.7, 4]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.3} />
          </mesh>
        ))}
        {/* deep fissures: dark grooves between cusps */}
        {[-0.55, 0, 0.55].map((x, i) => (
          <mesh key={`f${i}`} position={[x, 3.22, 0]}>
            <boxGeometry args={[0.22, 0.35, 2.9]} />
            <meshStandardMaterial color="#451a03" roughness={0.9} />
          </mesh>
        ))}
        <mesh position={[0, 3.22, 0]}>
          <boxGeometry args={[3.2, 0.35, 0.22]} />
          <meshStandardMaterial color="#451a03" roughness={0.9} />
        </mesh>
        {/* roots */}
        {[[-1, -0.8], [1, -0.8], [-1, 0.8], [1, 0.8]].map(([x, z], i) => (
          <mesh key={`r${i}`} position={[x, 0.9, z]} rotation={[Math.PI, 0, 0]} castShadow>
            <coneGeometry args={[0.32, 1.6, 10]} />
            <meshStandardMaterial color="#fef9c3" roughness={0.4} />
          </mesh>
        ))}

        {/* sealant pooled in the fissures (rises with fill) */}
        <group ref={sealant}>
          {[-0.55, 0, 0.55].map((x, i) => (
            <mesh key={i} position={[x, 3.32, 0]}>
              <boxGeometry args={[0.2, 0.3, 2.85]} />
              <meshStandardMaterial color="#7dd3fc" emissive="#0ea5e9" emissiveIntensity={0.5} transparent opacity={0.9} roughness={0.3} />
            </mesh>
          ))}
          <mesh position={[0, 3.32, 0]}>
            <boxGeometry args={[3.15, 0.3, 0.2]} />
            <meshStandardMaterial color="#7dd3fc" emissive="#0ea5e9" emissiveIntensity={0.5} transparent opacity={0.9} roughness={0.3} />
          </mesh>
        </group>

        {/* applicator tip dripping sealant */}
        <group position={[0, 5.6, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.28, 0.12, 1.1, 12]} />
            <meshStandardMaterial color="#f472b6" roughness={0.4} />
          </mesh>
          <mesh position={[0, 0.85, 0]}>
            <cylinderGeometry args={[0.34, 0.34, 0.7, 12]} />
            <meshStandardMaterial color="#be185d" roughness={0.4} />
          </mesh>
        </group>
        <instancedMesh ref={drops} args={[undefined, undefined, DROPS]}>
          <sphereGeometry args={[1, 10, 10]} />
          <meshStandardMaterial color="#7dd3fc" emissive="#0ea5e9" emissiveIntensity={0.8} transparent opacity={0.9} />
        </instancedMesh>

        <Label p={[-3.2, 3.3, 0]} size={0.3} color="#451a03">deep pits & fissures</Label>
        <Label p={[3.2, 3.3, 0]} size={0.3} color="#7dd3fc">sealant barrier</Label>
        <Label p={[0, 0.1, 0]} size={0.3} color="#e2e8f0">molar (chewing surface)</Label>

        <Animator drops={drops} sealant={sealant} elapsed={elapsed} speed={speed} fill={fill} />
      </SimCanvas>
    </div>
  );
}
