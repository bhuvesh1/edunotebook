// app/components/sims/unique/Topic7095Sim.tsx
// Relative velocity in one dimension: two cars share a road. Blue and
// orange arrows are their ground-frame velocities; the red arrow rides
// on a ghost of car A and shows car B's velocity as seen from car A
// (v_B − v_A) — it flips direction when A outruns B.

"use client";

import { useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "vA", label: "Car A velocity", kind: "slider", min: -4, max: 6, step: 0.5, default: 2, unit: "m/s" },
  { key: "vB", label: "Car B velocity", kind: "slider", min: -4, max: 6, step: 0.5, default: 4, unit: "m/s" },
];

export const UNIQUE_META = {
  title: "Relative Velocity in One Dimension",
  blurb: "Two cars on one road — the red arrow is car B's velocity as seen by the driver of car A.",
};

const TRACK = 20;
const wrap = (t: number, v: number, off: number) =>
  -TRACK / 2 + ((((t * v + off) % TRACK) + TRACK) % TRACK);

/** Velocity arrow: shaft is a unit cylinder stretched along signed Y. */
function VelArrow({
  g, shaft, cone, color,
}: {
  g: RefObject<THREE.Group>;
  shaft: RefObject<THREE.Mesh>;
  cone: RefObject<THREE.Mesh>;
  color: string;
}) {
  return (
    <group ref={g} position={[0, 2.2, 0]}>
      <mesh ref={shaft}>
        <cylinderGeometry args={[0.08, 0.08, 1, 10]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.45} roughness={0.4} />
      </mesh>
      <mesh ref={cone}>
        <coneGeometry args={[0.2, 0.4, 12]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.45} roughness={0.4} />
      </mesh>
    </group>
  );
}

function aimArrow(
  g: RefObject<THREE.Group>,
  shaft: RefObject<THREE.Mesh>,
  cone: RefObject<THREE.Mesh>,
  x: number, z: number, v: number
) {
  const L = 0.3 + Math.abs(v) * 0.5;
  const dir = v >= 0 ? 1 : -1;
  if (g.current) g.current.position.set(x, 2.2, z);
  if (shaft.current) {
    shaft.current.scale.set(1, L, 1);
    shaft.current.position.set(0, (dir * L) / 2, 0);
  }
  if (cone.current) {
    cone.current.position.set(0, dir * (L + 0.2), 0);
    cone.current.rotation.z = dir >= 0 ? 0 : Math.PI;
  }
}

function Car({ color, g }: { color: string; g: RefObject<THREE.Group> }) {
  return (
    <group ref={g}>
      <mesh position={[0, 0.72, 0]} castShadow>
        <boxGeometry args={[2.2, 0.66, 1.2]} />
        <meshStandardMaterial color={color} roughness={0.35} metalness={0.4} />
      </mesh>
      <mesh position={[-0.15, 1.3, 0]} castShadow>
        <boxGeometry args={[1.1, 0.55, 1.0]} />
        <meshStandardMaterial color="#bae6fd" roughness={0.2} metalness={0.3} />
      </mesh>
      {[-0.75, 0.75].map((x) =>
        [-0.62, 0.62].map((z) => (
          <mesh key={`${x}${z}`} position={[x, 0.32, z]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.32, 0.32, 0.18, 18]} />
            <meshStandardMaterial color="#111827" roughness={0.8} />
          </mesh>
        ))
      )}
    </group>
  );
}

function Animator({
  carA, carB, ghost, aA, aB, aR, vA, vB, vrel, bump,
}: {
  carA: RefObject<THREE.Group>;
  carB: RefObject<THREE.Group>;
  ghost: RefObject<THREE.Group>;
  aA: { g: RefObject<THREE.Group>; shaft: RefObject<THREE.Mesh>; cone: RefObject<THREE.Mesh> };
  aB: { g: RefObject<THREE.Group>; shaft: RefObject<THREE.Mesh>; cone: RefObject<THREE.Mesh> };
  aR: { g: RefObject<THREE.Group>; shaft: RefObject<THREE.Mesh>; cone: RefObject<THREE.Mesh> };
  vA: number; vB: number;
  vrel: RefObject<number>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const T = t.current;
    const xA = wrap(T, vA, 0);
    const xB = wrap(T, vB, 10);
    if (carA.current) carA.current.position.set(xA, 0, -1.6);
    if (carB.current) carB.current.position.set(xB, 0, 1.6);
    if (ghost.current) ghost.current.position.set(xA, 0, 3.6);
    aimArrow(aA.g, aA.shaft, aA.cone, xA, -1.6, vA);
    aimArrow(aB.g, aB.shaft, aB.cone, xB, 1.6, vB);
    const rel = vB - vA;
    vrel.current = rel;
    aimArrow(aR.g, aR.shaft, aR.cone, xA, 3.6, rel);
    if (++n.current % 20 === 0) bump();
  });
  return null;
}

export function Topic7095Sim(props: SimProps) {
  const vA = Number(props.vA ?? 2);
  const vB = Number(props.vB ?? 4);
  const carA = useRef<THREE.Group>(null!);
  const carB = useRef<THREE.Group>(null!);
  const ghost = useRef<THREE.Group>(null!);
  const gA = useRef<THREE.Group>(null!); const sA = useRef<THREE.Mesh>(null!); const cA = useRef<THREE.Mesh>(null!);
  const gB = useRef<THREE.Group>(null!); const sB = useRef<THREE.Mesh>(null!); const cB = useRef<THREE.Mesh>(null!);
  const gR = useRef<THREE.Group>(null!); const sR = useRef<THREE.Mesh>(null!); const cR = useRef<THREE.Mesh>(null!);
  const vrel = useRef(vB - vA);
  const [, bump] = useState(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["v_A (ground)", `${vA.toFixed(1)} m/s`],
          ["v_B (ground)", `${vB.toFixed(1)} m/s`],
          ["v_B seen by A", `${vrel.current.toFixed(1)} m/s`],
          ["🔴 Red arrow", "relative velocity"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 8, 17]} target={[0, 1, 0.6]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 26]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {[-1.6, 1.6].map((z) => (
          <mesh key={z} position={[0, 0.05, z]} receiveShadow>
            <boxGeometry args={[22, 0.1, 2.2]} />
            <meshStandardMaterial color="#334155" roughness={0.9} />
          </mesh>
        ))}
        {/* "A's point of view" lane */}
        <mesh position={[0, 0.05, 3.6]} receiveShadow>
          <boxGeometry args={[22, 0.1, 2.2]} />
          <meshStandardMaterial color="#3b1f33" roughness={0.9} />
        </mesh>
        <group ref={ghost}>
          <mesh position={[0, 0.72, 0]}>
            <boxGeometry args={[2.2, 0.66, 1.2]} />
            <meshStandardMaterial color="#38bdf8" transparent opacity={0.3} roughness={0.4} />
          </mesh>
        </group>

        <Car color="#38bdf8" g={carA} />
        <Car color="#fb923c" g={carB} />
        <VelArrow g={gA} shaft={sA} cone={cA} color="#38bdf8" />
        <VelArrow g={gB} shaft={sB} cone={cB} color="#fb923c" />
        <VelArrow g={gR} shaft={sR} cone={cR} color="#ef4444" />

        <Animator
          carA={carA} carB={carB} ghost={ghost}
          aA={{ g: gA, shaft: sA, cone: cA }}
          aB={{ g: gB, shaft: sB, cone: cB }}
          aR={{ g: gR, shaft: sR, cone: cR }}
          vA={vA} vB={vB} vrel={vrel}
          bump={() => bump((v) => v + 1)}
        />
      </SimCanvas>
    </div>
  );
}
