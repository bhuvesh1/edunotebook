"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "drug", label: "Drug class", kind: "select", min: 0, max: 0, step: 1, default: "nsaid", options: ["nsaid", "opioid"] },
  { key: "pain", label: "Pain level", kind: "slider", min: 1, max: 10, step: 1, default: 7, unit: "/10" },
];

export const UNIQUE_META = {
  title: "Analgesics: NSAIDs, opioids in dental pain",
  blurb: "Pain signals race from an aching tooth to the brain — NSAIDs block them at the tooth, opioids block them in the brain.",
};

const INFO: Record<string, { name: string; site: string; color: string; note: string }> = {
  nsaid: { name: "NSAID (ibuprofen)", site: "tooth", color: "#34d399", note: "Blocks COX at the injury — also fights swelling" },
  opioid: { name: "Opioid (tramadol)", site: "brain", color: "#a78bfa", note: "Blocks pain in brain/spinal cord — sedation risk" },
};

function PainSignals({ rate, blocked }: { rate: number; blocked: "tooth" | "brain" }) {
  const pts = useRef<THREE.Points>(null!);
  const t = useRef(Math.random() * 5);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(26 * 3), 3));
    return g;
  }, []);
  useFrame((_, delta) => {
    t.current += delta * rate;
    if (!pts.current) return;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < 26; i++) {
      const f = (t.current * 0.5 + i / 26) % 1;
      const maxF = blocked === "tooth" ? 0.25 : blocked === "brain" ? 0.92 : 1;
      const ff = Math.min(f, maxF);
      // nerve path: tooth (-2.5,0) up to brain (2,2.5)
      pos.setXYZ(i, -2.5 + ff * 4.5, 0.2 + ff * ff * 2.3, 0);
    }
    pos.needsUpdate = true;
  });
  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial color="#ef4444" size={0.16} transparent opacity={0.95} />
    </points>
  );
}

function Scene({ drug, pain }: { drug: string; pain: number }) {
  const info = INFO[drug] ?? INFO.nsaid;
  const t = useRef(0);
  const toothPulse = useRef<THREE.Mesh>(null!);

  useFrame((_, delta) => {
    t.current += delta;
    if (toothPulse.current) toothPulse.current.scale.setScalar(1 + Math.sin(t.current * (2 + pain * 0.5)) * 0.06);
  });

  return (
    <group>
      {/* aching tooth */}
      <group position={[-2.5, 0.2, 0]}>
        <mesh ref={toothPulse} position={[0, 0.3, 0]}>
          <cylinderGeometry args={[0.45, 0.58, 0.95, 14]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.25} />
        </mesh>
        {/* inflamed pulp glowing */}
        <mesh position={[0, 0.35, 0]}>
          <sphereGeometry args={[0.22, 12, 12]} />
          <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={1.5} />
        </mesh>
        <Label text="Aching tooth" position={[0, 1.4, 0]} size={0.45} color="#fca5a5" />
      </group>
      {/* nerve path */}
      <mesh position={[-0.25, 0.9, 0]} rotation={[0, 0, -1.05]}>
        <cylinderGeometry args={[0.07, 0.07, 5.2, 10]} />
        <meshStandardMaterial color="#facc15" roughness={0.4} />
      </mesh>
      {/* brain */}
      <group position={[2.2, 2.6, 0]}>
        <mesh scale={[1.15, 0.95, 1]}>
          <sphereGeometry args={[0.75, 20, 20]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
        </mesh>
        <mesh scale={[1.16, 0.96, 1.01]}>
          <sphereGeometry args={[0.75, 12, 12]} />
          <meshStandardMaterial color="#be185d" wireframe transparent opacity={0.35} />
        </mesh>
        <Label text="Brain" position={[0, 1.2, 0]} size={0.45} color="#f9a8d4" />
      </group>
      <PainSignals rate={0.4 + pain * 0.12} blocked={info.site as "tooth" | "brain"} />

      {/* drug blockade */}
      {info.site === "tooth" && (
        <group position={[-2.5, 0.9, 0]}>
          <mesh>
            <torusGeometry args={[0.75, 0.09, 10, 24]} />
            <meshStandardMaterial color={info.color} emissive={info.color} emissiveIntensity={0.8} />
          </mesh>
          <Label text="NSAID shield at tooth" position={[0, 1.1, 0]} size={0.42} color={info.color} />
        </group>
      )}
      {info.site === "brain" && (
        <group position={[2.2, 2.6, 0]}>
          <mesh scale={[1.35, 1.2, 1.25]}>
            <sphereGeometry args={[0.75, 18, 18]} />
            <meshStandardMaterial color={info.color} transparent opacity={0.3} roughness={0.2} side={THREE.BackSide} />
          </mesh>
          <Label text="Opioid block in brain" position={[0, 1.6, 0]} size={0.42} color={info.color} />
        </group>
      )}

      <Label text={info.name} position={[0, 4.3, 0]} size={0.6} color={info.color} />
      <Label text={info.note} position={[0, -1.6, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10419Sim(props: SimProps) {
  const drug = String(props.drug ?? "nsaid");
  const pain = Number(props.pain ?? 7);
  const info = INFO[drug] ?? INFO.nsaid;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Drug", info.name], ["Acts at", info.site === "tooth" ? "Periphery (COX)" : "Central (opioid receptors)"], ["Pain", `${pain}/10`]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, 1, 0]}>
        <Scene drug={drug} pain={pain} />
      </SimCanvas>
    </div>
  );
}
