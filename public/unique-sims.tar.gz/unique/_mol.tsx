// app/components/sims/unique/_mol.tsx
// Shared molecular/chromosome primitives for unique sims. No external assets.

"use client";

import { useMemo } from "react";
import * as THREE from "three";

/** Single atom/ball. */
export function Atom({
  position,
  color,
  r = 0.3,
  opacity = 1,
  emissive,
}: {
  position: [number, number, number];
  color: string;
  r?: number;
  opacity?: number;
  emissive?: string;
}) {
  return (
    <mesh position={position}>
      <sphereGeometry args={[r, 20, 20]} />
      <meshStandardMaterial
        color={color}
        roughness={0.35}
        transparent={opacity < 1}
        opacity={opacity}
        emissive={emissive ?? "#000000"}
        emissiveIntensity={emissive ? 0.7 : 0}
      />
    </mesh>
  );
}

/** Cylinder bond between two points. */
export function Bond({
  from,
  to,
  color = "#94a3b8",
  radius = 0.09,
}: {
  from: [number, number, number];
  to: [number, number, number];
  color?: string;
  radius?: number;
}) {
  const { len, mid, quat } = useMemo(() => {
    const a = new THREE.Vector3(...from);
    const b = new THREE.Vector3(...to);
    const d = b.clone().sub(a);
    const len = Math.max(0.001, d.length());
    const mid = a.clone().add(b).multiplyScalar(0.5);
    const quat = new THREE.Quaternion().setFromUnitVectors(
      new THREE.Vector3(0, 1, 0),
      d.normalize()
    );
    return { len, mid, quat };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [from[0], from[1], from[2], to[0], to[1], to[2]]);
  return (
    <mesh position={mid.toArray()} quaternion={quat}>
      <cylinderGeometry args={[radius, radius, len, 10]} />
      <meshStandardMaterial color={color} roughness={0.5} />
    </mesh>
  );
}

/** Smooth tube through a list of points (for DNA strands, chromatin, intestines...). */
export function Chain({
  points,
  color,
  radius = 0.08,
}: {
  points: [number, number, number][];
  color: string;
  radius?: number;
}) {
  const geo = useMemo(() => {
    const v = points.map((p) => new THREE.Vector3(...p));
    const curve = new THREE.CatmullRomCurve3(v);
    return new THREE.TubeGeometry(curve, Math.max(8, v.length * 4), radius, 8, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [points.length, color, radius, JSON.stringify(points)]);
  return (
    <mesh geometry={geo}>
      <meshStandardMaterial color={color} roughness={0.45} />
    </mesh>
  );
}

/** X-shaped replicated chromosome made of 4 short cylinders. */
export function XChrom({
  position,
  colorA = "#ef4444",
  colorB,
  scale = 1,
}: {
  position: [number, number, number];
  colorA?: string;
  colorB?: string;
  scale?: number;
}) {
  const b = colorB ?? colorA;
  const arms: { from: [number, number, number]; to: [number, number, number]; c: string }[] = [
    { from: [0, 0, 0], to: [-0.28, 0.42, 0], c: colorA },
    { from: [0, 0, 0], to: [0.28, 0.42, 0], c: b },
    { from: [0, 0, 0], to: [-0.28, -0.42, 0], c: colorA },
    { from: [0, 0, 0], to: [0.28, -0.42, 0], c: b },
  ];
  return (
    <group position={position} scale={scale}>
      {arms.map((a, i) => (
        <Bond key={i} from={a.from} to={a.to} color={a.c} radius={0.11} />
      ))}
      <Atom position={[0, 0, 0]} color="#f8fafc" r={0.1} />
    </group>
  );
}
