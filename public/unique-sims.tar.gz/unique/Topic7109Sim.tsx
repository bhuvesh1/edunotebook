// app/components/sims/unique/Topic7109Sim.tsx
// Centripetal acceleration: the same lapping race car, but now the red
// arrow shows what pulls it around — acceleration pointing at the center,
// a = v²/r. Faster laps stretch the arrow longer.

"use client";

import { useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Car speed", kind: "slider", min: 1, max: 6, step: 0.5, default: 3, unit: "m/s" },
];

export const UNIQUE_META = {
  title: "Centripetal Acceleration",
  blurb: "What keeps the car turning? The red arrow: acceleration v²/r, always pointing at the center.",
};

const R = 4.2;

function Animator({
  car, arrow, speed, bump,
}: {
  car: RefObject<THREE.Group>;
  arrow: RefObject<THREE.Group>;
  speed: number;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const omega = speed / R;
    const a = t.current * omega;
    const x = Math.cos(a) * R;
    const z = Math.sin(a) * R;
    if (car.current) {
      car.current.position.set(x, 0, z);
      car.current.rotation.y = -a;
    }
    if (arrow.current) {
      // Arrow from the car toward the center: rotate +Z-built arrow to face inward.
      arrow.current.position.set(x, 1.15, z);
      arrow.current.rotation.y = -a + Math.PI;
      const ac = (speed * speed) / R;
      const L = 0.5 + ac * 0.35;
      const shaft = arrow.current.children[0] as THREE.Mesh;
      const cone = arrow.current.children[1] as THREE.Mesh;
      shaft.scale.set(1, L, 1);
      shaft.rotation.set(Math.PI / 2, 0, 0);
      shaft.position.set(0, 0, L / 2);
      cone.rotation.set(Math.PI / 2, 0, 0);
      cone.position.set(0, 0, L + 0.2);
    }
    if (++n.current % 25 === 0) bump();
  });
  return null;
}

export function Topic7109Sim(props: SimProps) {
  const speed = Number(props.speed ?? 3);
  const car = useRef<THREE.Group>(null!);
  const arrow = useRef<THREE.Group>(null!);
  const [, bump] = useState(0);
  const ac = (speed * speed) / R;

  const track = useMemo(
    () => new THREE.Mesh(
      new THREE.TorusGeometry(R, 0.55, 12, 64),
      new THREE.MeshStandardMaterial({ color: "#334155", roughness: 0.9 })
    ),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["a = v²/r", `${ac.toFixed(2)} m/s²`],
          ["Direction", "toward center"],
          ["🔴 Arrow", "centripetal acceleration"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 10, 11]} target={[0, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <primitive object={track} position={[0, 0.08, 0]} rotation={[Math.PI / 2, 0, 0]} />
        <mesh position={[0, 0.15, 0]}>
          <cylinderGeometry args={[0.18, 0.18, 0.3, 16]} />
          <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.6} />
        </mesh>

        <group ref={car}>
          <mesh position={[0, 0.62, 0]} castShadow>
            <boxGeometry args={[1.1, 0.5, 2.1]} />
            <meshStandardMaterial color="#8b5cf6" roughness={0.35} metalness={0.4} />
          </mesh>
          <mesh position={[0, 1.05, -0.2]} castShadow>
            <boxGeometry args={[0.9, 0.4, 1.0]} />
            <meshStandardMaterial color="#bae6fd" roughness={0.2} metalness={0.3} />
          </mesh>
          {[-0.55, 0.55].map((x) =>
            [-0.7, 0.7].map((z) => (
              <mesh key={`${x}${z}`} position={[x, 0.3, z]} rotation={[0, 0, Math.PI / 2]}>
                <cylinderGeometry args={[0.3, 0.3, 0.18, 16]} />
                <meshStandardMaterial color="#111827" roughness={0.8} />
              </mesh>
            ))
          )}
        </group>

        {/* centripetal arrow (built along +Z, aimed at center) */}
        <group ref={arrow}>
          <mesh>
            <cylinderGeometry args={[0.1, 0.1, 1, 10]} />
            <meshStandardMaterial color="#ef4444" emissive="#b91c1c" emissiveIntensity={0.6} roughness={0.4} />
          </mesh>
          <mesh>
            <coneGeometry args={[0.26, 0.5, 12]} />
            <meshStandardMaterial color="#ef4444" emissive="#b91c1c" emissiveIntensity={0.6} roughness={0.4} />
          </mesh>
        </group>

        <Animator car={car} arrow={arrow} speed={speed} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
