// Vaccines & transplant immunology: the syringe delivers antigen into the arm,
// memory cells multiply into an immune army — and a transplanted organ earns
// its green check when matched.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "doses", label: "Vaccine doses", kind: "slider", min: 0, max: 3, step: 1, default: 2, unit: "" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Vaccines & transplant immunology",
  blurb: "Vaccination builds a memory-cell army; a matched transplant earns its green check.",
};

const N_MEM = 12;

function Animator({ mem, syringe, organ, check, elapsed, doses, setTick }: {
  mem: React.RefObject<(THREE.Mesh | null)[]>;
  syringe: React.RefObject<THREE.Group>;
  organ: React.RefObject<THREE.Mesh>;
  check: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  doses: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    // memory cells multiply with each dose
    const target = Math.min(N_MEM, doses * 5);
    mem.current.forEach((m, i) => {
      if (!m) return;
      const alive = i < target;
      m.visible = alive;
      if (!alive) return;
      const a = (i / N_MEM) * Math.PI * 2;
      m.position.set(
        -2.8 + Math.cos(a + t * 0.5) * (0.9 + (i % 3) * 0.45),
        2.2 + Math.sin(a * 2 + t * 0.8) * 0.5,
        Math.sin(a + t * 0.5) * 1.2
      );
      ((m as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = 0.6 + Math.sin(t * 3 + i) * 0.3;
    });
    if (syringe.current) {
      // injection plunge, then rest
      const f = Math.min(1, (t % 6) / 1.2);
      syringe.current.position.set(-4.6, 2.6 - f * 0.9, 0.9);
      syringe.current.rotation.z = -0.9;
    }
    if (organ.current) {
      organ.current.rotation.y = t * 0.4;
      const ok = doses >= 1;
      const m = organ.current.material as THREE.MeshStandardMaterial;
      m.emissive.set(ok ? "#16a34a" : "#7f1d1d");
      m.emissiveIntensity = 0.25 + Math.sin(t * 2) * 0.15;
    }
    if (check.current) {
      check.current.visible = doses >= 1;
      check.current.position.y = 3.4 + Math.sin(t * 2) * 0.12;
      check.current.rotation.y = t * 0.8;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.min(N_MEM, doses * 5)); }
  });
  return null;
}

export function Topic10147Sim(props: SimProps) {
  const doses = Number(props.doses ?? 2);
  const showLabels = String(props.detail ?? "on") === "on";
  const mem = useRef<(THREE.Mesh | null)[]>([]);
  const syringe = useRef<THREE.Group>(null!);
  const organ = useRef<THREE.Mesh>(null!);
  const check = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const protection = doses === 0 ? "none" : doses === 1 ? "partial" : doses === 2 ? "strong" : "boosted";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Doses", `${doses}`],
          ["Memory cells", `${tick}`],
          ["Protection", protection],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* arm receiving vaccine */}
        <mesh position={[-4.6, 1.4, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <capsuleGeometry args={[0.42, 2.2, 8, 14]} />
          <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
        </mesh>
        {showLabels && <Label text="arm — vaccination" position={[-4.6, 2.5, 0]} size={0.45} color="#fde68a" />}

        {/* syringe */}
        <group ref={syringe}>
          <mesh rotation={[0, 0, -0.9]} castShadow>
            <cylinderGeometry args={[0.15, 0.15, 1.3, 12]} />
            <meshStandardMaterial color="#e0f2fe" transparent opacity={0.85} />
          </mesh>
          <mesh position={[0.5, -0.35, 0]} rotation={[0, 0, -0.9]}>
            <cylinderGeometry args={[0.03, 0.03, 0.6, 8]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.6} roughness={0.3} />
          </mesh>
        </group>

        {/* memory B/T cells multiplying */}
        {Array.from({ length: N_MEM }).map((_, i) => (
          <mesh key={i} ref={(m) => { mem.current[i] = m; }} castShadow>
            <sphereGeometry args={[0.24, 14, 10]} />
            <meshStandardMaterial color="#38bdf8" emissive="#0369a1" emissiveIntensity={0.8} />
          </mesh>
        ))}
        {showLabels && <Label text="memory cells — immune army" position={[-2.8, 3.6, 0]} color="#7dd3fc" />}

        {/* transplanted organ */}
        <mesh ref={organ} position={[3.4, 1.5, 0]} scale={[0.85, 1.15, 0.85]} castShadow>
          <sphereGeometry args={[0.85, 20, 14]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.5} emissive="#000000" />
        </mesh>
        {showLabels && <Label text="transplanted organ" position={[3.4, 0.1, 0]} size={0.45} color="#fca5a5" />}

        {/* green check = matched graft */}
        <group ref={check} position={[3.4, 3.4, 0]}>
          <mesh rotation={[0, 0, -0.7]}>
            <boxGeometry args={[0.14, 0.5, 0.14]} />
            <meshStandardMaterial color="#22c55e" emissive="#16a34a" emissiveIntensity={1} />
          </mesh>
          <mesh position={[0.28, 0.12, 0]} rotation={[0, 0, 0.7]}>
            <boxGeometry args={[0.14, 0.9, 0.14]} />
            <meshStandardMaterial color="#22c55e" emissive="#16a34a" emissiveIntensity={1} />
          </mesh>
        </group>
        {showLabels && doses >= 1 && <Label text="HLA matched ✓" position={[3.4, 4.3, 0]} size={0.45} color="#86efac" />}

        <Animator mem={mem} syringe={syringe} organ={organ} check={check} elapsed={elapsed} doses={doses} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
