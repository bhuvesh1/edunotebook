// Histology: endocrine glands, skin, eye, ear — a thyroid follicle trio with
// colloid, layered skin with a sweating gland, and an eye focusing light rays.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "sweat", label: "Sweat rate", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Histology: Thyroid, Skin & Eye",
  blurb: "Thyroid follicles store colloid, skin layers protect and sweat, and the eye focuses light onto the retina.",
};

function Animator({
  rays, sweatDrops, colloid, elapsed, sweat, speed,
}: {
  rays: React.RefObject<THREE.Group>;
  sweatDrops: React.RefObject<THREE.Group>;
  colloid: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  sweat: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (rays.current) {
      rays.current.children.forEach((m, i) => {
        const mat = (m as THREE.Mesh).material as THREE.MeshBasicMaterial;
        mat.opacity = 0.45 + 0.35 * Math.sin(t * 4 - i * 0.9);
      });
    }
    if (sweatDrops.current) {
      sweatDrops.current.children.forEach((m, i) => {
        const ph = ((t * 0.4 * sweat + i / 5) % 1 + 1) % 1;
        m.position.y = 2.15 + ph * 1.1;
        m.visible = sweat > 0.02;
      });
    }
    if (colloid.current) {
      colloid.current.children.forEach((m, i) => {
        const s = 1 + 0.06 * Math.sin(t * 2 + i * 2.1);
        m.scale.setScalar(s);
      });
    }
  });
  return null;
}

export function Topic10021Sim(props: SimProps) {
  const sweat = Number(props.sweat ?? 1);
  const speed = Number(props.speed ?? 1);
  const rays = useRef<THREE.Group>(null!);
  const sweatDrops = useRef<THREE.Group>(null!);
  const colloid = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const follicles = useMemo(
    () => [
      { x: -7.6, y: 1.9 }, { x: -6.0, y: 2.5 }, { x: -4.6, y: 1.8 },
    ],
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Thyroid", "colloid-filled follicles"],
          ["Skin", "epidermis / dermis / hypodermis"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 6, 16.5]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* THYROID follicles: ring of cells around pink colloid */}
        <group ref={colloid}>
          {follicles.map((f, i) => (
            <group key={i} position={[f.x, f.y, 0]}>
              <mesh castShadow>
                <sphereGeometry args={[0.55, 18, 18]} />
                <meshStandardMaterial color="#f9a8d4" roughness={0.35} />
              </mesh>
              {Array.from({ length: 10 }).map((_, j) => {
                const a = (j / 10) * Math.PI * 2;
                return (
                  <mesh key={j} position={[Math.cos(a) * 0.62, Math.sin(a) * 0.62, 0]}>
                    <boxGeometry args={[0.16, 0.3, 0.2]} />
                    <meshStandardMaterial color="#be185d" roughness={0.5} />
                  </mesh>
                );
              })}
            </group>
          ))}
        </group>
        <Label text="thyroid follicles" position={[-6.1, 3.9, 0]} size={0.4} color="#f8fafc" />
        <Label text="colloid (thyroglobulin)" position={[-6.1, 0.9, 0]} size={0.3} color="#f9a8d4" />

        {/* SKIN layers */}
        <group position={[0.5, 0, 0]}>
          <mesh position={[0, 2.9, 0]} castShadow>
            <boxGeometry args={[6.4, 0.5, 2.4]} />
            <meshStandardMaterial color="#fcd34d" roughness={0.6} />
          </mesh>
          <mesh position={[0, 1.85, 0]} castShadow>
            <boxGeometry args={[6.4, 1.6, 2.4]} />
            <meshStandardMaterial color="#f59e0b" roughness={0.65} />
          </mesh>
          <mesh position={[0, 0.6, 0]} castShadow>
            <boxGeometry args={[6.4, 0.9, 2.4]} />
            <meshStandardMaterial color="#b45309" roughness={0.7} />
          </mesh>
          {/* hair follicle + shaft */}
          <mesh position={[-1.4, 2.2, 0]} rotation={[0, 0, 0.25]} castShadow>
            <cylinderGeometry args={[0.12, 0.12, 3.2, 10]} />
            <meshStandardMaterial color="#451a03" roughness={0.6} />
          </mesh>
          <mesh position={[-1.75, 1.5, 0]}>
            <sphereGeometry args={[0.3, 12, 12]} />
            <meshStandardMaterial color="#78350f" roughness={0.5} />
          </mesh>
          {/* sweat gland coil + duct */}
          <mesh position={[1.6, 0.9, 0]} castShadow>
            <torusGeometry args={[0.35, 0.14, 10, 18]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.45} />
          </mesh>
          <mesh position={[1.6, 1.9, 0]} castShadow>
            <cylinderGeometry args={[0.12, 0.12, 1.6, 10]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.45} />
          </mesh>
        </group>
        <group ref={sweatDrops}>
          {Array.from({ length: 5 }).map((_, i) => (
            <mesh key={i} position={[2.1, 2.15, 0]}>
              <sphereGeometry args={[0.1, 10, 10]} />
              <meshStandardMaterial color="#7dd3fc" emissive="#0369a1" emissiveIntensity={0.5} />
            </mesh>
          ))}
        </group>
        <Label text="epidermis" position={[-2.4, 3.75, 0]} size={0.32} color="#fde68a" />
        <Label text="dermis" position={[-2.4, 1.85, 1.5]} size={0.32} color="#fdba74" />
        <Label text="hair shaft" position={[-2.9, 3.4, 0]} size={0.3} color="#d6a97c" />
        <Label text="sweat gland" position={[3.1, 0.9, 0]} size={0.3} color="#7dd3fc" />
        <Label text="skin" position={[0.5, 4.35, 0]} size={0.4} color="#f8fafc" />

        {/* EYE: eyeball with lens focusing parallel rays onto retina */}
        <group position={[7.8, 2.2, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[1.35, 24, 24]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.25} />
          </mesh>
          <mesh position={[0.55, 0, 0]} scale={[0.55, 1, 1]}>
            <sphereGeometry args={[0.5, 18, 18]} />
            <meshStandardMaterial color="#38bdf8" transparent opacity={0.85} roughness={0.15} />
          </mesh>
          <mesh position={[0.45, 0, 0]}>
            <sphereGeometry args={[0.22, 12, 12]} />
            <meshStandardMaterial color="#0f172a" />
          </mesh>
          {/* retina: glowing back wall */}
          <mesh position={[-1.05, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
            <circleGeometry args={[0.75, 20]} />
            <meshBasicMaterial color="#f97316" />
          </mesh>
        </group>
        <group ref={rays}>
          {[-0.55, -0.2, 0.2, 0.55].map((dy, i) => (
            <mesh key={i} position={[4.6, 2.2 + dy, 0]} rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.045, 0.045, 3.4 - Math.abs(dy) * 2.2, 8]} />
              <meshBasicMaterial color="#fef08a" transparent opacity={0.6} />
            </mesh>
          ))}
        </group>
        <Label text="eye — light focuses on retina" position={[7.8, 4.2, 0]} size={0.38} color="#f8fafc" />
        <Label text="lens" position={[8.6, 1.35, 0]} size={0.3} color="#7dd3fc" />
        <Label text="retina" position={[6.6, 1.3, 0]} size={0.3} color="#fb923c" />

        <Animator rays={rays} sweatDrops={sweatDrops} colloid={colloid} elapsed={elapsed} sweat={sweat} speed={speed} />
      </SimCanvas>
    </div>
  );
}
