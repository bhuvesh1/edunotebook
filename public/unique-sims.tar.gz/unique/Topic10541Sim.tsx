// app/components/sims/unique/Topic10541Sim.tsx
// Preventive and interceptive orthodontics in children: a crooked front
// tooth wearing a bracket and wire gradually uprights as treatment
// progresses.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "prog", label: "Treatment progress", kind: "slider", min: 0, max: 100, step: 1, default: 55, unit: "%" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Preventive & Interceptive Orthodontics",
  blurb: "A crooked tooth in braces slowly straightens as the wire guides it — early treatment, big smile.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ tooth, wire, elapsed, speed, prog }: {
  tooth: RefObject<THREE.Group>; wire: RefObject<THREE.Mesh>;
  elapsed: RefObject<number>; speed: number; prog: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (tooth.current) {
      // tooth uprights from tilted (0.5 rad) to straight as progress rises
      const target = 0.5 * (1 - prog / 100);
      tooth.current.rotation.z = target + 0.02 * Math.sin(t * 2.5);
      tooth.current.position.y = 2.0 - 0.15 * (prog / 100);
    }
    if (wire.current) {
      // wire flexes less as the tooth straightens
      const mat = wire.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = 0.3 + 0.4 * (1 - prog / 100) + 0.1 * Math.sin(t * 2.5);
    }
  });
  return null;
}

export function Topic10541Sim(props: SimProps) {
  const prog = Number(props.prog ?? 55);
  const speed = Number(props.speed ?? 1);
  const tooth = useRef<THREE.Group>(null!);
  const wire = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Progress", `${prog}%`],
          ["Tooth angle", `${(0.5 * (1 - prog / 100) * 57.3).toFixed(1)}° off`],
          ["Result", prog >= 90 ? "aligned ✓" : prog >= 40 ? "improving" : "just started"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 10]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* gum */}
        <mesh position={[0, 1.1, 0]} castShadow>
          <boxGeometry args={[6.4, 0.8, 1.4]} />
          <meshStandardMaterial color="#e0607a" roughness={0.6} />
        </mesh>

        {/* straight neighbor teeth with brackets */}
        {[-2.4, -1.6, -0.8, 0.8, 1.6, 2.4].map((x, i) => (
          <group key={i} position={[x, 2.1, 0]}>
            <mesh castShadow>
              <boxGeometry args={[0.66, 0.95, 0.6]} />
              <meshStandardMaterial color="#fefce8" roughness={0.3} />
            </mesh>
            <mesh position={[0, 0.1, 0.36]}>
              <boxGeometry args={[0.3, 0.3, 0.12]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.35} />
            </mesh>
          </group>
        ))}

        {/* the crooked tooth: tilts upright with progress */}
        <group ref={tooth} position={[0, 2.0, 0]}>
          <mesh castShadow>
            <boxGeometry args={[0.66, 1.05, 0.6]} />
            <meshStandardMaterial color="#fde68a" roughness={0.3} />
          </mesh>
          <mesh position={[0, 0.1, 0.36]}>
            <boxGeometry args={[0.3, 0.3, 0.12]} />
            <meshStandardMaterial color="#f59e0b" metalness={0.7} roughness={0.35} />
          </mesh>
        </group>

        {/* archwire through all brackets */}
        <mesh ref={wire} position={[0, 2.2, 0.42]} castShadow>
          <boxGeometry args={[6.2, 0.07, 0.07]} />
          <meshStandardMaterial color="#e2e8f0" metalness={0.85} roughness={0.25} emissive="#94a3b8" emissiveIntensity={0.4} />
        </mesh>

        <Label p={[0, 3.4, 0]} size={0.3} color="#fde68a">crooked tooth uprighting</Label>
        <Label p={[-3.6, 2.2, 0]} size={0.28} color="#e2e8f0">brackets + wire</Label>
        <Label p={[0, 0.2, 0]} size={0.3} color="#e2e8f0">interceptive orthodontics — guide growth early</Label>

        <Animator tooth={tooth} wire={wire} elapsed={elapsed} speed={speed} prog={prog} />
      </SimCanvas>
    </div>
  );
}
