"use client";
// Occupational health: hazards, ESI Act, ergonomics.
// A factory with puffing chimneys, a worker in a hard hat, and three
// hazard icons — dust, noise, chemical — pick one to highlight.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "hazard", label: "Hazard", kind: "select", min: 0, max: 0, step: 1, default: "dust", options: ["dust", "noise", "chemical"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Occupational Health: Hazards at Work",
  blurb: "The factory puffs away while a hard-hat worker faces dust, noise or chemicals — spot the hazard, wear the protection.",
};

const HAZARD_TXT: Record<string, string> = {
  dust: "Dust: mask on — protects the lungs",
  noise: "Noise: earplugs — protects hearing",
  chemical: "Chemical: gloves — protects the skin",
};

function Animator({ smoke, elapsed, speed }: { smoke: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (smoke.current) {
      smoke.current.children.forEach((s, i) => {
        const ph = (elapsed.current * 0.5 + i * 0.2) % 1;
        s.position.y = 4.6 + ph * 2.4;
        const sc = 0.5 + ph * 1.2;
        s.scale.set(sc, sc, sc);
        (s as THREE.Mesh).material = (s as THREE.Mesh).material;
      });
    }
  });
  return null;
}

export function Topic10180Sim(props: SimProps) {
  const hazard = String(props.hazard ?? "dust");
  const speed = Number(props.speed ?? 1);
  const smoke = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Hazard", hazard], ["Protection", HAZARD_TXT[hazard] ?? ""]]} />
      <SimCanvas cameraPosition={[0, 3.8, 14]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#141a26" roughness={1} />
        </mesh>
        {/* factory */}
        <group position={[-3.4, 0, -1.5]}>
          <mesh position={[0, 1.5, 0]} castShadow>
            <boxGeometry args={[5.4, 3, 3.4]} />
            <meshStandardMaterial color="#7c2d12" roughness={0.85} />
          </mesh>
          <mesh position={[0, 3.6, 0]} castShadow>
            <coneGeometry args={[3.6, 1.4, 4]} />
            <meshStandardMaterial color="#57534e" roughness={0.9} />
          </mesh>
          {[-1.4, 1.4].map((x) => (
            <mesh key={x} position={[x, 4.6, 0]} castShadow>
              <cylinderGeometry args={[0.4, 0.5, 1.8, 10]} />
              <meshStandardMaterial color="#a8a29e" roughness={0.8} />
            </mesh>
          ))}
          <group ref={smoke}>
            {Array.from({ length: 8 }, (_, i) => (
              <mesh key={i} position={[(i % 2 === 0 ? -1.4 : 1.4), 4.6 + (i / 8) * 2.4, 0]}>
                <sphereGeometry args={[0.45, 10, 10]} />
                <meshStandardMaterial color="#9ca3af" transparent opacity={0.5} roughness={0.95} />
              </mesh>
            ))}
          </group>
          {/* glowing windows */}
          {[-1.6, 0, 1.6].map((x) => (
            <mesh key={x} position={[x, 1.6, 1.72]}>
              <boxGeometry args={[0.9, 0.9, 0.06]} />
              <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={0.8} />
            </mesh>
          ))}
          <Label text="FACTORY" position={[0, 6.2, 0]} size={0.6} color="#fbbf24" />
        </group>
        {/* worker with hard hat */}
        <group position={[3.6, 0, 0.5]}>
          <mesh position={[0, 1, 0]} castShadow>
            <capsuleGeometry args={[0.45, 1, 6, 12]} />
            <meshStandardMaterial color="#f59e0b" roughness={0.7} />
          </mesh>
          <mesh position={[0, 2.15, 0]} castShadow>
            <sphereGeometry args={[0.38, 16, 16]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
          <mesh position={[0, 2.42, 0]} castShadow>
            <sphereGeometry args={[0.46, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.4} />
          </mesh>
          <mesh position={[0, 2.45, 0]}>
            <cylinderGeometry args={[0.62, 0.62, 0.08, 16]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.4} />
          </mesh>
          <Label text="WORKER" position={[0, 3.3, 0]} size={0.55} color="#fde68a" />
        </group>
        {/* hazard icons */}
        <group position={[3.6, 0, 3]}>
          {[
            { k: "dust", c: "#a8a29e", y: 1 },
            { k: "noise", c: "#f472b6", y: 2.1 },
            { k: "chemical", c: "#4ade80", y: 3.2 },
          ].map((h) => (
            <group key={h.k} position={[0, h.y, 0]}>
              <mesh castShadow>
                <sphereGeometry args={[0.42, 14, 14]} />
                <meshStandardMaterial color={h.c} emissive={h.c} emissiveIntensity={hazard === h.k ? 0.9 : 0.1} roughness={0.5} />
              </mesh>
              <Label text={h.k.toUpperCase()} position={[1.4, 0, 0]} size={0.45} color={hazard === h.k ? h.c : "#64748b"} />
            </group>
          ))}
          <Label text="HAZARDS" position={[0, 4.1, 0]} size={0.55} color="#f87171" />
        </group>
        {/* ESI card */}
        <group position={[-0.2, 0, 3.6]}>
          <mesh position={[0, 0.9, 0]} rotation={[-0.2, 0, 0]} castShadow>
            <boxGeometry args={[2.2, 1.4, 0.08]} />
            <meshStandardMaterial color="#1d4ed8" roughness={0.6} />
          </mesh>
          <Label text="ESI CARD" position={[0, 1.75, 0.3]} size={0.5} color="#ffffff" />
          <Label text="worker insurance" position={[0, 0.35, 0]} size={0.45} color="#93c5fd" />
        </group>
        <Animator smoke={smoke} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
