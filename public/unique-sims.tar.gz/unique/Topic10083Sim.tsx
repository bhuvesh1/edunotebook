"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "injury", label: "Injury type", kind: "select", min: 0, max: 0, step: 1, default: "necrosis", options: ["reversible", "necrosis", "apoptosis"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Cell Injury: Necrosis vs Apoptosis",
  blurb: "One cell, three fates: reversible swelling, explosive necrosis, or quiet apoptotic dismantling.",
};

function Animator({ root, cell, frag, bleb, elapsed, speed, injury }: { root: RefObject<THREE.Group>; cell: RefObject<THREE.Mesh>; frag: RefObject<THREE.Group>; bleb: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; injury: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const q = (t * 0.35) % 1;
    if (cell.current) {
      const m = cell.current.material as THREE.MeshStandardMaterial;
      if (injury === "reversible") {
        cell.current.scale.setScalar(1 + 0.35 * Math.sin(q * Math.PI));
        cell.current.visible = true; m.opacity = 0.55;
      } else if (injury === "necrosis") {
        const burst = q > 0.55;
        cell.current.visible = !burst;
        cell.current.scale.setScalar(1 + q * 0.7);
        m.opacity = 0.55;
      } else {
        cell.current.visible = true;
        cell.current.scale.setScalar(Math.max(0.2, 1 - q * 0.8));
        m.opacity = 0.55;
      }
    }
    if (frag.current) {
      frag.current.visible = injury === "necrosis";
      frag.current.children.forEach((f, i) => {
        const r = Math.max(0, q - 0.55) * 3.2;
        const a = (i / 8) * Math.PI * 2;
        f.position.set(Math.cos(a) * (1 + r), 1.8 + Math.sin(a * 2) * r * 0.5, Math.sin(a) * (1 + r));
      });
    }
    if (bleb.current) {
      bleb.current.visible = injury === "apoptosis";
      bleb.current.children.forEach((f, i) => {
        const a = (i / 6) * Math.PI * 2;
        const rr = 1.1 * Math.max(0.2, 1 - q * 0.8);
        f.position.set(Math.cos(a) * rr, 1.8 + Math.sin(a) * rr * 0.8, Math.sin(a) * rr);
      });
    }
  });
  return null;
}

export function Topic10083Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const injury = String(props.injury ?? "necrosis");
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const cell = useRef<THREE.Mesh>(null!);
  const frag = useRef<THREE.Group>(null!);
  const bleb = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Injury", injury],
          ["Outcome", injury === "reversible" ? "recovers" : injury === "necrosis" ? "rupture + inflammation" : "phagocytosed quietly"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 11]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh ref={cell} position={[0, 1.8, 0]} castShadow>
            <sphereGeometry args={[1.4, 28, 28]} />
            <meshStandardMaterial color="#f9a8d4" transparent opacity={0.55} roughness={0.4} />
          </mesh>
          <mesh position={[0, 1.8, 0]}>
            <sphereGeometry args={[0.55, 18, 18]} /><meshStandardMaterial color="#7c2d12" roughness={0.5} />
          </mesh>
          <Label text="nucleus" position={[0, 0.75, 0]} size={0.42} color="#fdba74" />
          <group ref={frag} visible={false}>
            {Array.from({ length: 8 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.28, 12, 12]} /><meshStandardMaterial color="#ef4444" roughness={0.5} /></mesh>
            ))}
          </group>
          <group ref={bleb} visible={false}>
            {Array.from({ length: 6 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.26, 12, 12]} /><meshStandardMaterial color="#fde047" roughness={0.5} /></mesh>
            ))}
          </group>
          <Label text={injury === "reversible" ? "cellular swelling \u2014 reversible" : injury === "necrosis" ? "membrane rupture \u2014 necrosis" : "blebbing \u2014 apoptosis"} position={[0, 4.1, 0]} size={0.5} color={injury === "necrosis" ? "#f87171" : injury === "apoptosis" ? "#fde047" : "#4ade80"} />
          <Label text="injured cell" position={[-2.6, 2.4, 0]} size={0.42} color="#f9a8d4" />
        </group>
        <Animator root={root} cell={cell} frag={frag} bleb={bleb} elapsed={elapsed} speed={speed} injury={injury} />
      </SimCanvas>
    </div>
  );
}
