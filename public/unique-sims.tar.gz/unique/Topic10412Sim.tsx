"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "manifest", label: "Manifestation", kind: "select", min: 0, max: 0, step: 1, default: "candidiasis", options: ["candidiasis", "hairyleukoplakia", "kaposi"] },
  { key: "cd4", label: "CD4 count", kind: "slider", min: 50, max: 800, step: 50, default: 200, unit: "/µL" },
];

export const UNIQUE_META = {
  title: "Oral manifestations of systemic diseases and HIV",
  blurb: "An open mouth showing HIV-linked oral lesions — candidiasis plaques, hairy leukoplakia, or Kaposi sarcoma — worsening as CD4 falls.",
};

const INFO: Record<string, { name: string; note: string; color: string }> = {
  candidiasis: { name: "Oral candidiasis (thrush)", note: "White curd-like plaques — wipeable", color: "#fef3c7" },
  hairyleukoplakia: { name: "Hairy leukoplakia", note: "White ridged patch on tongue side — EBV", color: "#e2e8f0" },
  kaposi: { name: "Kaposi sarcoma", note: "Purple-red nodules — HHV-8 vascular tumour", color: "#c084fc" },
};

function Scene({ manifest, cd4 }: { manifest: string; cd4: number }) {
  const lesions = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const info = INFO[manifest] ?? INFO.candidiasis;
  const load = cd4 < 200 ? 1.4 : cd4 < 350 ? 1.0 : 0.6;

  useFrame((_, delta) => {
    t.current += delta;
    if (lesions.current) lesions.current.scale.setScalar(load * (1 + Math.sin(t.current * 2.5) * 0.04));
  });

  return (
    <group>
      {/* lips */}
      <mesh position={[0, 0.4, 1.9]} rotation={[0, 0, 0]}>
        <torusGeometry args={[1.9, 0.42, 14, 32]} />
        <meshStandardMaterial color="#c2556a" roughness={0.5} />
      </mesh>
      {/* oral cavity dark */}
      <mesh position={[0, 0.3, 1.2]}>
        <sphereGeometry args={[1.75, 24, 24]} />
        <meshStandardMaterial color="#3f1d24" roughness={1} side={THREE.BackSide} />
      </mesh>
      {/* tongue */}
      <mesh position={[0, -0.35, 1.1]} scale={[1.5, 0.45, 1.1]}>
        <sphereGeometry args={[1, 24, 24]} />
        <meshStandardMaterial color="#d96a7e" roughness={0.55} />
      </mesh>
      {/* palate hint */}
      <mesh position={[0, 1.35, 0.9]} rotation={[0.5, 0, 0]}>
        <sphereGeometry args={[1.4, 20, 12, 0, Math.PI * 2, 0, Math.PI / 3]} />
        <meshStandardMaterial color="#c9808b" roughness={0.6} side={THREE.DoubleSide} />
      </mesh>

      {/* lesions */}
      <group ref={lesions}>
        {manifest === "candidiasis" && (
          <>
            {[[-0.7, 0.15, 1.35], [0.6, 0.1, 1.3], [0, 0.5, 1.05], [-0.2, -0.35, 1.75], [0.8, -0.3, 1.6]].map(([x, y, z], i) => (
              <mesh key={i} position={[x, y, z]} scale={[1, 0.5, 1]}>
                <sphereGeometry args={[0.3, 12, 12]} />
                <meshStandardMaterial color="#fef9c3" roughness={0.9} />
              </mesh>
            ))}
          </>
        )}
        {manifest === "hairyleukoplakia" && (
          <group position={[1.15, -0.15, 1.05]} rotation={[0, 0.5, 0]}>
            {[0, 1, 2, 3].map((i) => (
              <mesh key={i} position={[0, i * 0.16 - 0.24, 0]} rotation={[0, 0, Math.PI / 2]}>
                <cylinderGeometry args={[0.05, 0.05, 0.9, 8]} />
                <meshStandardMaterial color="#f1f5f9" roughness={0.8} />
              </mesh>
            ))}
            <mesh position={[0, 0, -0.06]}>
              <boxGeometry args={[0.95, 0.8, 0.08]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.85} />
            </mesh>
          </group>
        )}
        {manifest === "kaposi" && (
          <>
            {[[-0.8, 0.9, 1.15], [0.7, 0.75, 1.2], [0, 1.15, 0.95]].map(([x, y, z], i) => (
              <mesh key={i} position={[x, y, z]} scale={[1, 0.7, 0.6]}>
                <sphereGeometry args={[0.32, 14, 14]} />
                <meshStandardMaterial color="#9333ea" roughness={0.35} />
              </mesh>
            ))}
          </>
        )}
      </group>

      <Label text={info.name} position={[0, 2.9, 0.8]} size={0.6} color={info.color} />
      <Label text={info.note} position={[0, -2.2, 0.8]} size={0.45} color="#e2e8f0" />
      <Label text={cd4 < 200 ? "CD4 < 200 — AIDS range" : cd4 < 350 ? "CD4 low — lesions appear" : "CD4 OK — lesions fade"} position={[0, -2.9, 0.8]} size={0.45} color={cd4 < 200 ? "#f87171" : "#86efac"} />
    </group>
  );
}

export function Topic10412Sim(props: SimProps) {
  const manifest = String(props.manifest ?? "candidiasis");
  const cd4 = Number(props.cd4 ?? 200);
  const info = INFO[manifest] ?? INFO.candidiasis;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Lesion", info.name], ["CD4", `${cd4}/µL`], ["Risk", cd4 < 200 ? "High" : cd4 < 350 ? "Moderate" : "Low"]]} />
      <SimCanvas cameraPosition={[0, 1, 8.5]} target={[0, 0.3, 1]}>
        <Scene manifest={manifest} cd4={cd4} />
      </SimCanvas>
    </div>
  );
}
