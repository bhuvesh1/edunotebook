"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "gout", label: "Uric acid level", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.5 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Purine Breakdown & Gout",
  blurb: "IMP branches to AMP and GMP; excess purines become uric acid that crystallizes painfully in joints.",
};

function Animator({ root, ua, crys, elapsed, speed, gout }: { root: RefObject<THREE.Group>; ua: RefObject<THREE.Group>; crys: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; gout: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (ua.current) {
      ua.current.children.forEach((m, i) => {
        const q = (t * (0.3 + gout * 0.7) + i / 5) % 1;
        m.position.set(Math.sin(i * 3) * 0.3, 2.3 - q * 1.5, 0);
      });
    }
    if (crys.current) {
      crys.current.scale.setScalar(0.25 + gout * 1.1);
      crys.current.rotation.y = t * 0.4;
    }
  });
  return null;
}

export function Topic10070Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const gout = Number(props.gout ?? 0.5);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const ua = useRef<THREE.Group>(null!);
  const crys = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["End product", "uric acid"],
          ["Enzyme", "xanthine oxidase"],
          ["Gout risk", gout > 0.6 ? "HIGH \u2014 crystals forming" : "low"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 3.1, 0]} castShadow>
            <sphereGeometry args={[0.5, 20, 20]} /><meshStandardMaterial color="#f8fafc" roughness={0.4} />
          </mesh>
          <Label text="IMP" position={[0, 3.9, 0]} color="#f8fafc" />
          <mesh position={[-2.6, 3.1, 0]} castShadow>
            <sphereGeometry args={[0.4, 18, 18]} /><meshStandardMaterial color="#4ade80" roughness={0.4} />
          </mesh>
          <Label text="AMP" position={[-2.6, 3.9, 0]} size={0.45} color="#4ade80" />
          <mesh position={[2.6, 3.1, 0]} castShadow>
            <sphereGeometry args={[0.4, 18, 18]} /><meshStandardMaterial color="#60a5fa" roughness={0.4} />
          </mesh>
          <Label text="GMP" position={[2.6, 3.9, 0]} size={0.45} color="#60a5fa" />
          {[-1.55, 1.55].map((x, i) => (
            <mesh key={i} position={[x, 3.1, 0]} rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.08, 0.08, 1.7, 8]} /><meshStandardMaterial color="#64748b" />
            </mesh>
          ))}
          <group ref={ua}>
            {Array.from({ length: 5 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.16, 10, 10]} /><meshStandardMaterial color="#d6d3d1" roughness={0.6} /></mesh>
            ))}
          </group>
          <Label text="uric acid" position={[1.4, 1.6, 0]} size={0.42} color="#d6d3d1" />
          <mesh position={[0, 0.75, 0]}>
            <sphereGeometry args={[1.15, 24, 24]} />
            <meshStandardMaterial color="#93c5fd" transparent opacity={0.22} roughness={0.3} />
          </mesh>
          <group ref={crys} position={[0, 0.75, 0]}>
            {Array.from({ length: 12 }).map((_, i) => {
              const a = (i / 12) * Math.PI * 2;
              return (
                <mesh key={i} position={[Math.cos(a) * 0.5, (i % 3) * 0.3 - 0.3, Math.sin(a) * 0.5]} rotation={[i * 0.7, i * 1.3, i * 0.4]}>
                  <boxGeometry args={[0.09, 0.65, 0.09]} />
                  <meshStandardMaterial color="#fefce8" emissive="#fde68a" emissiveIntensity={0.5} roughness={0.3} />
                </mesh>
              );
            })}
          </group>
          <Label text="joint \u2014 urate crystals" position={[0, -0.75, 0]} size={0.45} color="#fde68a" />
        </group>
        <Animator root={root} ua={ua} crys={crys} elapsed={elapsed} speed={speed} gout={gout} />
      </SimCanvas>
    </div>
  );
}
