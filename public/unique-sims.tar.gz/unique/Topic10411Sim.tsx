"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "disease", label: "Disease", kind: "select", min: 0, max: 0, step: 1, default: "fibrous", options: ["fibrous", "paget", "osteomyelitis"] },
  { key: "severity", label: "Severity", kind: "slider", min: 0.5, max: 1.8, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Bone diseases of jaws: fibrous dysplasia, Paget's, osteomyelitis",
  blurb: "A mandible showing three bone diseases — ground-glass fibrous dysplasia, cotton-wool Paget's, or draining osteomyelitis.",
};

const INFO: Record<string, { name: string; note: string; color: string }> = {
  fibrous: { name: "Fibrous dysplasia", note: "Ground-glass bone — orange-peel texture, painless swelling", color: "#fb923c" },
  paget: { name: "Paget's disease", note: "Cotton-wool fluffy new bone — enlarged dense jaw", color: "#f8fafc" },
  osteomyelitis: { name: "Osteomyelitis", note: "Infected bone — pus draining through the gum", color: "#ef4444" },
};

function Scene({ disease, severity }: { disease: string; severity: number }) {
  const group = useRef<THREE.Group>(null!);
  const lesion = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const info = INFO[disease] ?? INFO.fibrous;

  useFrame((_, delta) => {
    t.current += delta;
    if (lesion.current) lesion.current.scale.setScalar(severity * (1 + Math.sin(t.current * 2) * 0.03));
    if (group.current) group.current.rotation.y = Math.sin(t.current * 0.25) * 0.45;
  });

  return (
    <group ref={group}>
      {/* mandible */}
      <mesh position={[0, 0, 0]} rotation={[Math.PI / 2, 0, 0]} receiveShadow>
        <torusGeometry args={[2.5, 0.8, 16, 40, Math.PI]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>
      <mesh position={[0, -2.5, 0]}>
        <boxGeometry args={[1.6, 1.4, 1.4]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>
      {/* teeth */}
      {[-1.8, -0.9, 0, 0.9, 1.8].map((x, i) => (
        <mesh key={i} position={[x, 1.05, 1.6]} rotation={[0.2, 0, 0]}>
          <cylinderGeometry args={[0.22, 0.28, 0.6, 10]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.3} />
        </mesh>
      ))}

      {/* disease lesion on right body of mandible */}
      <group ref={lesion} position={[1.7, -0.35, 1.35]}>
        {disease === "fibrous" && (
          <mesh>
            <sphereGeometry args={[0.75, 18, 18]} />
            <meshStandardMaterial color="#fb923c" roughness={0.95} flatShading />
          </mesh>
        )}
        {disease === "paget" && (
          <group>
            {[0, 1, 2, 3, 4].map((i) => (
              <mesh key={i} position={[(i % 2) * 0.5 - 0.25, Math.floor(i / 2) * 0.4 - 0.3, (i % 3) * 0.2 - 0.2]}>
                <icosahedronGeometry args={[0.34, 1]} />
                <meshStandardMaterial color="#f1f5f9" roughness={1} flatShading />
              </mesh>
            ))}
          </group>
        )}
        {disease === "osteomyelitis" && (
          <group>
            <mesh>
              <sphereGeometry args={[0.7, 18, 18]} />
              <meshStandardMaterial color="#b91c1c" roughness={0.7} />
            </mesh>
            {[0, 1, 2].map((i) => (
              <mesh key={i} position={[0.2 * i - 0.2, 0.55 + 0.12 * i, 0.3]}>
                <sphereGeometry args={[0.13, 10, 10]} />
                <meshStandardMaterial color="#fde047" roughness={0.4} />
              </mesh>
            ))}
            {/* draining sinus */}
            <mesh position={[0, 0.75, 0.45]} rotation={[0.4, 0, 0]}>
              <cylinderGeometry args={[0.08, 0.14, 0.5, 10]} />
              <meshStandardMaterial color="#fde047" roughness={0.4} />
            </mesh>
          </group>
        )}
      </group>

      <Label text={info.name} position={[1.7, 1.6, 1.35]} size={0.6} color={info.color} />
      <Label text={info.note} position={[0, -3.6, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10411Sim(props: SimProps) {
  const disease = String(props.disease ?? "fibrous");
  const severity = Number(props.severity ?? 1);
  const info = INFO[disease] ?? INFO.fibrous;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Disease", info.name], ["X-ray sign", disease === "fibrous" ? "Ground glass" : disease === "paget" ? "Cotton wool" : "Moth-eaten + sequestrum"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, -0.5, 0]}>
        <Scene disease={disease} severity={severity} />
      </SimCanvas>
    </div>
  );
}
