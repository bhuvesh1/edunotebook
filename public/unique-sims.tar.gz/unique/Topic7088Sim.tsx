// app/components/sims/unique/Topic7088Sim.tsx
// Frame of reference: a ball bounces inside a moving train. The red trail
// shows the ball's path as seen from the ground (a moving zigzag); the
// blue trail shows the same motion as seen from the train (straight
// up-and-down). Same motion, different description per frame.

"use client";

import { useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Train speed", kind: "slider", min: 0.5, max: 3, step: 0.1, default: 1.5, unit: "m/s" },
  { key: "frame", label: "Observer frame", kind: "select", min: 0, max: 0, step: 1, default: "ground", options: ["ground", "train"] },
];

export const UNIQUE_META = {
  title: "Rest and Motion, Frame of Reference",
  blurb: "A ball bounces inside a moving train — its path looks different from the ground than from inside the train.",
};

const TRAIL_N = 61;
const BALL_Y = (t: number) => 1.7 + Math.abs(Math.sin(t * 2.2)) * 1.1;
const TRAIN_X = (t: number, v: number) => -10 + ((((t * v) % 20) + 20) % 20);

function Animator({
  train,
  ball,
  trail,
  trailGeo,
  trainSpeed,
  frame,
  bump,
}: {
  train: RefObject<THREE.Group>;
  ball: RefObject<THREE.Mesh>;
  trail: RefObject<THREE.Line>;
  trailGeo: THREE.BufferGeometry;
  trainSpeed: number;
  frame: string;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const T = t.current;
    const tx = TRAIN_X(T, trainSpeed);
    if (train.current) train.current.position.x = tx;
    const by = BALL_Y(T);
    if (ball.current) ball.current.position.y = by;
    // Rebuild the ground-frame trail: ball world positions over the last ~3.6 s.
    const pos = trailGeo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < TRAIL_N; i++) {
      const ti = T - (TRAIL_N - 1 - i) * 0.06;
      pos.setXYZ(i, TRAIN_X(ti, trainSpeed), BALL_Y(ti), 0);
    }
    pos.needsUpdate = true;
    if (trail.current) trail.current.visible = frame === "ground";
    if (++n.current % 20 === 0) bump();
  });
  return null;
}

export function Topic7088Sim(props: SimProps) {
  const trainSpeed = Number(props.speed ?? 1.5);
  const frame = String(props.frame ?? "ground");
  const train = useRef<THREE.Group>(null!);
  const ball = useRef<THREE.Mesh>(null!);
  const trail = useRef<THREE.Line>(null!);
  const [, bump] = useState(0);

  const trailGeo = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(TRAIL_N * 3), 3));
    return geo;
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Observer", frame === "ground" ? "on the ground" : "inside the train"],
          ["Ball path (ground)", "red zigzag"],
          ["Ball path (train)", "blue, straight up-down"],
          ["Train speed", `${trainSpeed.toFixed(1)} m/s`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5, 16]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* rails */}
        {[-0.7, 0.7].map((z) => (
          <mesh key={z} position={[0, 0.06, z]} receiveShadow>
            <boxGeometry args={[24, 0.12, 0.18]} />
            <meshStandardMaterial color="#475569" roughness={0.5} metalness={0.6} />
          </mesh>
        ))}

        {/* ground-frame trail of the ball */}
        <primitive object={new THREE.Line(trailGeo, new THREE.LineBasicMaterial({ color: "#ef4444" }))} ref={trail} />

        {/* moving train */}
        <group ref={train}>
          <mesh position={[0, 1.5, 0]} castShadow>
            <boxGeometry args={[3.6, 1.5, 1.7]} />
            <meshStandardMaterial color="#2563eb" roughness={0.5} />
          </mesh>
          <mesh position={[0, 2.35, 0]} castShadow>
            <boxGeometry args={[3.8, 0.25, 1.9]} />
            <meshStandardMaterial color="#1e3a8a" roughness={0.5} />
          </mesh>
          {[-1.1, 0, 1.1].map((x) => (
            <mesh key={x} position={[x, 1.7, 0.86]}>
              <boxGeometry args={[0.7, 0.6, 0.05]} />
              <meshStandardMaterial color="#bae6fd" roughness={0.2} metalness={0.3} />
            </mesh>
          ))}
          {[-1.2, 1.2].map((x) =>
            [-0.85, 0.85].map((z) => (
              <mesh key={`${x}${z}`} position={[x, 0.42, z]} rotation={[Math.PI / 2, 0, 0]} castShadow>
                <cylinderGeometry args={[0.42, 0.42, 0.2, 20]} />
                <meshStandardMaterial color="#1f2937" roughness={0.7} />
              </mesh>
            ))
          )}
          {/* train-frame trail: straight vertical bounce */}
          <primitive
            object={
              new THREE.Line(
                new THREE.BufferGeometry().setFromPoints([
                  new THREE.Vector3(0, 1.55, 0),
                  new THREE.Vector3(0, 2.95, 0),
                ]),
                new THREE.LineBasicMaterial({ color: "#38bdf8" })
              )
            }
            visible={frame === "train"}
          />
          {/* bouncing ball (child of train: no horizontal motion in train frame) */}
          <mesh ref={ball} position={[0, 1.7, 0]} castShadow>
            <sphereGeometry args={[0.3, 24, 24]} />
            <meshStandardMaterial color="#fb923c" roughness={0.4} />
          </mesh>
        </group>

        <Animator
          train={train} ball={ball} trail={trail} trailGeo={trailGeo}
          trainSpeed={trainSpeed} frame={frame}
          bump={() => bump((v) => v + 1)}
        />
      </SimCanvas>
    </div>
  );
}
