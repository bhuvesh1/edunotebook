// Urology: kidneys, ureters, bladder — stones, UTI, BPH, prostate cancer.
// Urine particles stream from the kidneys to the bladder. A stone tumbles down
// the ureter, the bladder burns red in UTI, or the prostate squeezes the urethra in BPH.

"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "stone", options: ["healthy", "stone", "uti", "bph", "prostate_cancer"] },
  { key: "flow", label: "Urine flow", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Urinary Tract: Stones, UTI, BPH",
  blurb: "Follow urine from kidneys to bladder — then watch a stone block the ureter, infection burn the bladder, or BPH squeeze the urethra.",
};

// path of the left ureter from kidney to bladder
const URETER: [number, number, number][] = [
  [-1.9, 3.0, 0], [-1.85, 2.4, 0], [-1.7, 1.8, 0], [-1.5, 1.2, 0], [-1.2, 0.7, 0], [-0.8, 0.55, 0],
];

function Animator({
  group, drops, stone, bladder, elapsed, flow, condition,
}: {
  group: React.RefObject<THREE.Group>;
  drops: React.RefObject<THREE.Group>;
  stone: React.RefObject<THREE.Mesh>;
  bladder: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  flow: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * flow;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // urine drops travel the ureter path, looping
    if (drops.current) {
      drops.current.children.forEach((d, i) => {
        const ph = ((t * 0.45 + i / drops.current!.children.length) % 1);
        const seg = ph * (URETER.length - 1);
        const a = Math.floor(seg), b = Math.min(a + 1, URETER.length - 1);
        const f = seg - a;
        const A = URETER[a], B = URETER[b];
        d.position.set(A[0] + (B[0] - A[0]) * f, A[1] + (B[1] - A[1]) * f, A[2] + (B[2] - A[2]) * f);
        d.visible = condition !== "stone" || ph < 0.45;
      });
    }
    if (stone.current) {
      stone.current.visible = condition === "stone";
      const ph = (t * 0.16) % 1;
      const seg = ph * (URETER.length - 1);
      const a = Math.floor(seg), b = Math.min(a + 1, URETER.length - 1);
      const f = seg - a;
      const A = URETER[a], B = URETER[b];
      stone.current.position.set(A[0] + (B[0] - A[0]) * f, A[1] + (B[1] - A[1]) * f, A[2] + (B[2] - A[2]) * f);
      stone.current.rotation.x = t * 4; stone.current.rotation.y = t * 3;
    }
    if (bladder.current) {
      const m = bladder.current.material as THREE.MeshStandardMaterial;
      const inflamed = condition === "uti";
      m.emissive.set(inflamed ? "#dc2626" : "#000000");
      m.emissiveIntensity = inflamed ? 0.35 + 0.35 * Math.sin(t * 5) : 0;
    }
  });
  return null;
}

export function Topic10252Sim(props: SimProps) {
  const condition = String(props.condition ?? "stone");
  const flow = Number(props.flow ?? 1);
  const group = useRef<THREE.Group>(null!);
  const drops = useRef<THREE.Group>(null!);
  const stone = useRef<THREE.Mesh>(null!);
  const bladder = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const ureterCurve = useMemo(() => new THREE.CatmullRomCurve3(URETER.map((p) => new THREE.Vector3(...p))), []);
  const ureterGeo = useMemo(() => new THREE.TubeGeometry(ureterCurve, 32, 0.11, 10), [ureterCurve]);
  // mirrored for the right ureter
  const ureterGeoR = useMemo(() => {
    const pts = URETER.map((p) => new THREE.Vector3(-p[0], p[1], p[2]));
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 32, 0.11, 10);
  }, []);

  const names: Record<string, string> = {
    healthy: "Healthy urinary tract", stone: "Ureteric stone", uti: "Urinary tract infection (UTI)",
    bph: "BPH — enlarged prostate", prostate_cancer: "Prostate cancer",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Flow", `${flow.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* kidneys: bean shapes */}
          {[-1, 1].map((s) => (
            <group key={s} position={[s * 2.1, 3.4, 0]}>
              <mesh scale={[0.85, 1.15, 0.6]} castShadow>
                <sphereGeometry args={[0.62, 24, 18]} />
                <meshStandardMaterial color="#b91c1c" roughness={0.5} />
              </mesh>
              <mesh position={[-s * 0.35, 0, 0]} scale={[0.6, 0.8, 0.5]} rotation={[0, 0, s * 0.5]}>
                <sphereGeometry args={[0.4, 18, 14]} />
                <meshStandardMaterial color="#7f1d1d" roughness={0.6} />
              </mesh>
            </group>
          ))}
          {/* ureters */}
          <mesh geometry={ureterGeo} castShadow>
            <meshStandardMaterial color="#f0abfc" roughness={0.5} />
          </mesh>
          <mesh geometry={ureterGeoR} castShadow>
            <meshStandardMaterial color="#f0abfc" roughness={0.5} />
          </mesh>
          {/* urine drops */}
          <group ref={drops}>
            {Array.from({ length: 10 }).map((_, i) => (
              <mesh key={i} castShadow>
                <sphereGeometry args={[0.09, 10, 8]} />
                <meshStandardMaterial color="#facc15" roughness={0.3} emissive="#a16207" emissiveIntensity={0.7} />
              </mesh>
            ))}
          </group>
          {/* the stone */}
          <mesh ref={stone} visible={false} castShadow>
            <octahedronGeometry args={[0.22, 0]} />
            <meshStandardMaterial color="#57534e" roughness={0.7} flatShading />
          </mesh>
          {/* bladder */}
          <mesh ref={bladder} position={[0, 0.1, 0]} scale={[1.15, 0.95, 0.9]} castShadow>
            <sphereGeometry args={[0.75, 28, 20]} />
            <meshStandardMaterial color="#fb923c" roughness={0.45} />
          </mesh>
          {/* prostate: donut hugging the urethra below the bladder */}
          <mesh position={[0, -0.85, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow
            scale={condition === "bph" || condition === "prostate_cancer" ? [1.6, 1.6, 1.1] : [1, 1, 1]}>
            <torusGeometry args={[0.32, 0.24, 14, 24]} />
            <meshStandardMaterial
              color={condition === "prostate_cancer" ? "#7f1d1d" : "#f472b6"}
              roughness={0.5}
              emissive={condition === "prostate_cancer" ? "#450a0a" : "#000000"}
              emissiveIntensity={0.5}
            />
          </mesh>
          {/* urethra */}
          <mesh position={[0, -1.55, 0]} castShadow>
            <cylinderGeometry args={[condition === "bph" ? 0.05 : 0.11, 0.11, 1.1, 12]} />
            <meshStandardMaterial color="#f0abfc" roughness={0.5} />
          </mesh>
          <Label text="Kidney" position={[-2.1, 4.5, 0]} size={0.5} color="#fca5a5" />
          <Label text="Ureter" position={[-2.5, 1.9, 0]} size={0.5} color="#f0abfc" />
          <Label text="Bladder" position={[1.35, 0.1, 0]} size={0.5} color="#fdba74" />
          <Label text="Prostate" position={[1.15, -0.85, 0]} size={0.5} color="#f9a8d4" />
          {condition === "stone" && <Label text="⚠ Stone blocking!" position={[-2.6, 0.9, 0]} size={0.55} color="#fca5a5" />}
          {condition === "uti" && <Label text="🔥 Infection" position={[0, -0.35, 0.8]} size={0.5} color="#fdba74" />}
          {condition === "bph" && <Label text="⚠ Enlarged — weak stream" position={[-1.9, -1.5, 0]} size={0.5} color="#fca5a5" />}
          {condition === "prostate_cancer" && <Label text="⚠ Cancerous prostate" position={[-1.9, -0.85, 0]} size={0.5} color="#fca5a5" />}
          <Arrow from={[-1.9, 3.0, 0]} to={[-1.85, 2.4, 0]} color="#facc15" radius={0.05} />
        </group>
        <Animator group={group} drops={drops} stone={stone} bladder={bladder} elapsed={elapsed} flow={flow} condition={condition} />
      </SimCanvas>
    </div>
  );
}
