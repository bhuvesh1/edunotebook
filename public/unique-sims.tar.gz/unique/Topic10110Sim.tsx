// Antihypertensives: a pulsing artery, a live BP dial, and a pill that brings
// the pressure needle down from hypertensive red into the healthy green zone.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Antihypertensive dose", kind: "slider", min: 0, max: 100, step: 5, default: 50, unit: "mg" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Antihypertensives",
  blurb: "Watch the BP dial fall from the hypertensive red zone into healthy green as the drug dose rises.",
};

const N_PULSE = 5;

function Animator({ needle, pulses, pill, elapsed, dose, setTick }: {
  needle: React.RefObject<THREE.Mesh>;
  pulses: React.RefObject<(THREE.Mesh | null)[]>;
  pill: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  dose: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    const sys = 185 - k * 65; // 185 -> 120 mmHg
    // dial: -120deg (low) .. +120deg (high); map 90..190 mmHg
    const ang = THREE.MathUtils.degToRad(THREE.MathUtils.mapLinear(sys, 90, 190, -120, 120));
    if (needle.current) needle.current.rotation.z = -ang;
    pulses.current.forEach((p, i) => {
      if (!p) return;
      const f = (t * (0.5 + (1 - k) * 0.5) + i / N_PULSE) % 1;
      p.position.set(-4 + f * 8, 1.4, 0);
      const s = 0.8 + k * 0.5;
      p.scale.set(s, s, 1);
      ((p as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = 0.9 - k * 0.3;
    });
    if (pill.current) {
      pill.current.position.y = 0.9 + Math.sin(t * 2) * 0.12;
      pill.current.rotation.y = t * 1.2;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(sys)); }
  });
  return null;
}

export function Topic10110Sim(props: SimProps) {
  const dose = Number(props.dose ?? 50);
  const showLabels = String(props.detail ?? "on") === "on";
  const needle = useRef<THREE.Mesh>(null!);
  const pulses = useRef<(THREE.Mesh | null)[]>([]);
  const pill = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const k = dose / 100;
  const sys = Math.round(185 - k * 65);
  const zone = sys >= 140 ? "hypertensive" : sys >= 120 ? "elevated" : "normal";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Blood pressure", `${sys} mmHg`],
          ["Zone", zone],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* artery */}
        <mesh position={[0, 1.4, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.65, 0.65, 8.5, 20]} />
          <meshStandardMaterial color="#b91c1c" roughness={0.45} />
        </mesh>
        <mesh position={[0, 1.4, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.45, 0.45, 8.5, 20]} />
          <meshStandardMaterial color="#7f1d1d" roughness={0.5} />
        </mesh>
        {showLabels && <Label text="artery" position={[-3.4, 2.6, 0]} color="#fca5a5" />}

        {/* pressure pulse rings travelling through the artery */}
        {Array.from({ length: N_PULSE }).map((_, i) => (
          <mesh key={i} ref={(m) => { pulses.current[i] = m; }} rotation={[0, Math.PI / 2, 0]}>
            <torusGeometry args={[0.52, 0.09, 8, 20]} />
            <meshStandardMaterial color="#f87171" emissive="#dc2626" emissiveIntensity={1} transparent />
          </mesh>
        ))}

        {/* BP dial */}
        <group position={[0, 4.4, -1.5]}>
          <mesh>
            <cylinderGeometry args={[1.3, 1.3, 0.25, 32]} />
            <meshStandardMaterial color="#0f172a" roughness={0.4} />
          </mesh>
          {/* green / amber / red zones */}
          <mesh position={[0, 0, 0.14]} rotation={[0, 0, THREE.MathUtils.degToRad(120)]}>
            <torusGeometry args={[1.0, 0.12, 8, 12, THREE.MathUtils.degToRad(80)]} />
            <meshStandardMaterial color="#22c55e" emissive="#16a34a" emissiveIntensity={0.8} />
          </mesh>
          <mesh position={[0, 0, 0.14]} rotation={[0, 0, THREE.MathUtils.degToRad(40)]}>
            <torusGeometry args={[1.0, 0.12, 8, 12, THREE.MathUtils.degToRad(80)]} />
            <meshStandardMaterial color="#f59e0b" emissive="#b45309" emissiveIntensity={0.8} />
          </mesh>
          <mesh position={[0, 0, 0.14]} rotation={[0, 0, THREE.MathUtils.degToRad(-40)]}>
            <torusGeometry args={[1.0, 0.12, 8, 12, THREE.MathUtils.degToRad(80)]} />
            <meshStandardMaterial color="#ef4444" emissive="#b91c1c" emissiveIntensity={0.8} />
          </mesh>
          <mesh ref={needle} position={[0, 0, 0.2]}>
            <boxGeometry args={[0.09, 1.05, 0.05]} />
            <meshStandardMaterial color="#f8fafc" emissive="#ffffff" emissiveIntensity={0.4} />
          </mesh>
          <mesh position={[0, 0, 0.24]}>
            <sphereGeometry args={[0.12, 12, 10]} />
            <meshStandardMaterial color="#fbbf24" />
          </mesh>
        </group>
        {showLabels && <Label text={`BP dial — ${sys} mmHg`} position={[0, 6.1, -1.5]} color="#fde68a" />}

        {/* the antihypertensive pill */}
        <group ref={pill} position={[5.2, 0.9, 1]}>
          <mesh castShadow>
            <capsuleGeometry args={[0.24, 0.4, 8, 16]} />
            <meshStandardMaterial color="#3b82f6" roughness={0.3} />
          </mesh>
        </group>
        {showLabels && <Label text="antihypertensive pill" position={[5.2, 2.1, 1]} size={0.45} color="#93c5fd" />}

        <Animator needle={needle} pulses={pulses} pill={pill} elapsed={elapsed} dose={dose} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
