"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cyst", label: "Cyst type", kind: "select", min: 0, max: 0, step: 1, default: "dentigerous", options: ["dentigerous", "radicular", "keratocyst"] },
  { key: "size", label: "Cyst size", kind: "slider", min: 0.5, max: 1.8, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Odontogenic cysts: dentigerous, radicular, odontogenic keratocyst",
  blurb: "Jawbone cross-section with a translucent fluid-filled cyst sac — around a tooth crown, at a root tip, or in the jaw body.",
};

const INFO: Record<string, { name: string; sac: [number, number, number]; note: string; color: string }> = {
  dentigerous: { name: "Dentigerous cyst", sac: [0, 1.6, 0], note: "Encloses the crown of an unerupted tooth", color: "#7dd3fc" },
  radicular: { name: "Radicular (periapical) cyst", sac: [0, -0.55, 0], note: "At the root tip of a dead tooth", color: "#fda4af" },
  keratocyst: { name: "Odontogenic keratocyst", sac: [2.2, 0.1, 0], note: "Aggressive cyst in the jaw body — high recurrence", color: "#fcd34d" },
};

function Tooth() {
  return (
    <group>
      <mesh position={[0, 1.15, 0]}>
        <cylinderGeometry args={[0.45, 0.6, 1.0, 14]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.25} />
      </mesh>
      <mesh position={[0, 0.15, 0]}>
        <coneGeometry args={[0.42, 1.2, 14]} />
        <meshStandardMaterial color="#e8dcc8" roughness={0.45} />
      </mesh>
      {/* pulp */}
      <mesh position={[0, 0.75, 0]}>
        <cylinderGeometry args={[0.12, 0.16, 1.4, 10]} />
        <meshStandardMaterial color="#ef4444" roughness={0.5} />
      </mesh>
    </group>
  );
}

function Scene({ cyst, size }: { cyst: string; size: number }) {
  const sac = useRef<THREE.Mesh>(null!);
  const group = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const info = INFO[cyst] ?? INFO.dentigerous;

  useFrame((_, delta) => {
    t.current += delta;
    if (sac.current) {
      const s = size * (1 + Math.sin(t.current * 2) * 0.04);
      sac.current.scale.setScalar(s);
      (sac.current.material as THREE.MeshStandardMaterial).opacity = 0.45 + Math.sin(t.current * 2) * 0.08;
    }
    if (group.current) group.current.rotation.y = Math.sin(t.current * 0.25) * 0.4;
  });

  return (
    <group ref={group}>
      {/* jaw bone block */}
      <mesh position={[0, 0, -0.6]} receiveShadow>
        <boxGeometry args={[6.5, 3.4, 2.4]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>
      {/* gum line */}
      <mesh position={[0, 1.75, -0.6]}>
        <boxGeometry args={[6.5, 0.4, 2.6]} />
        <meshStandardMaterial color="#e0788a" roughness={0.6} />
      </mesh>
      <Label text="Jaw bone" position={[-3.6, -0.4, 0.8]} size={0.45} color="#fde68a" />

      <group position={[-0.4, 0.2, 0.4]}>
        <Tooth />
      </group>

      {/* cyst sac */}
      <mesh ref={sac} position={info.sac}>
        <sphereGeometry args={[0.85, 24, 24]} />
        <meshStandardMaterial color={info.color} transparent opacity={0.5} roughness={0.2} />
      </mesh>
      <mesh position={info.sac} scale={size}>
        <sphereGeometry args={[0.85, 24, 24]} />
        <meshStandardMaterial color={info.color} wireframe transparent opacity={0.35} />
      </mesh>
      {/* fluid shimmer inside */}
      <mesh position={[info.sac[0], info.sac[1] - 0.2 * size, info.sac[2]]} scale={size * 0.55}>
        <sphereGeometry args={[0.6, 16, 16]} />
        <meshStandardMaterial color="#ffffff" transparent opacity={0.25} roughness={0.1} />
      </mesh>

      <Label text={info.name} position={[info.sac[0], info.sac[1] + 1.5 * size, info.sac[2]]} size={0.6} color={info.color} />
      <Label text={info.note} position={[0, -2.4, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10407Sim(props: SimProps) {
  const cyst = String(props.cyst ?? "dentigerous");
  const size = Number(props.size ?? 1);
  const info = INFO[cyst] ?? INFO.dentigerous;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Cyst", info.name], ["Lining", "Epithelium + fluid"], ["Treatment", "Enucleation"]]} />
      <SimCanvas cameraPosition={[0, 2.5, 9]} target={[0, 0.3, 0]}>
        <Scene cyst={cyst} size={size} />
      </SimCanvas>
    </div>
  );
}
