// Mycology: branching hyphae spread across the skin patch with spore sacs at
// the tips — and a red ringworm lesion marks the infection.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Growth speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Mycology: fungi",
  blurb: "Branching hyphae spread with spore sacs at the tips — and a red ringworm lesion marks the skin.",
};

const SEGS: { p: [number, number, number]; r: [number, number, number]; l: number }[] = [
  { p: [0, 0, 0], r: [0, 0, Math.PI / 2.2], l: 2.6 },
  { p: [1.1, 0.35, 0.3], r: [0.3, 0, Math.PI / 3.2], l: 1.6 },
  { p: [-1.0, 0.3, -0.4], r: [-0.25, 0, -Math.PI / 3], l: 1.5 },
  { p: [0.3, 0.75, 0.6], r: [0.8, 0, 0.5], l: 1.2 },
  { p: [-0.3, -0.35, 0.5], r: [-0.7, 0, -0.6], l: 1.1 },
  { p: [1.6, -0.2, -0.5], r: [0.2, 0, Math.PI / 4], l: 1.2 },
  { p: [-1.6, -0.3, 0.4], r: [-0.2, 0, -Math.PI / 4], l: 1.1 },
];

function Animator({ colony, spores, elapsed, speed, setTick }: {
  colony: React.RefObject<THREE.Group>;
  spores: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  speed: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (colony.current) {
      // colony grows then fruits — loop
      const grow = Math.min(1, (t * 0.2) % 1.4);
      const s = 0.4 + Math.min(1, grow) * 0.6;
      colony.current.scale.set(s, 0.5 + Math.min(1, grow) * 0.5, s);
    }
    spores.current.forEach((sp, i) => {
      if (!sp) return;
      // spores puff off the tips and drift
      const f = (t * 0.35 + i / 8) % 1;
      const seg = SEGS[i % SEGS.length];
      sp.position.set(
        seg.p[0] + Math.sin(i * 2.1) * f * 2,
        1.5 + f * 2.2,
        seg.p[2] + Math.cos(i * 1.7) * f * 1.5
      );
      (sp.material as THREE.MeshStandardMaterial).opacity = Math.max(0, 0.9 - f);
      sp.visible = f < 0.95;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(t * 10)); }
  });
  return null;
}

export function Topic10141Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const colony = useRef<THREE.Group>(null!);
  const spores = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Structure", "hyphae + spores"],
          ["Types", "superficial → systemic"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 12]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* skin patch */}
        <mesh position={[0, 0.3, 0]} receiveShadow>
          <boxGeometry args={[7.5, 0.6, 5.5]} />
          <meshStandardMaterial color="#e8b48c" roughness={0.85} />
        </mesh>
        {/* ringworm lesion */}
        <mesh position={[2.6, 0.62, 1.2]} rotation={[-Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.7, 0.12, 10, 28]} />
          <meshStandardMaterial color="#ef4444" emissive="#b91c1c" emissiveIntensity={0.7} />
        </mesh>
        {showLabels && <Label text="ringworm lesion" position={[2.6, 1.4, 1.2]} size={0.4} color="#fca5a5" />}

        {/* hyphal colony */}
        <group ref={colony} position={[-1.2, 0.6, -0.5]}>
          {SEGS.map((s, i) => (
            <group key={i}>
              <mesh position={s.p} rotation={s.r} castShadow>
                <cylinderGeometry args={[0.08, 0.12, s.l, 8]} />
                <meshStandardMaterial color="#d6c79a" roughness={0.7} />
              </mesh>
              {/* spore sac at tip */}
              <mesh position={[s.p[0] + 0.25, s.p[1] + 0.5, s.p[2]]}>
                <sphereGeometry args={[0.16, 12, 10]} />
                <meshStandardMaterial color="#fef3c7" emissive="#d97706" emissiveIntensity={0.5} />
              </mesh>
            </group>
          ))}
        </group>
        {showLabels && <Label text="hyphae — branching threads" position={[-1.2, 2.4, -0.5]} color="#f5eeda" />}
        {showLabels && <Label text="spore sacs" position={[-3.2, 1.6, -0.5]} size={0.4} color="#fef3c7" />}

        {/* drifting spores */}
        {Array.from({ length: 8 }).map((_, i) => (
          <mesh key={`sp${i}`} ref={(m) => { spores.current[i] = m; }}>
            <sphereGeometry args={[0.09, 8, 8]} />
            <meshStandardMaterial color="#fef9c3" emissive="#ca8a04" emissiveIntensity={0.6} transparent />
          </mesh>
        ))}

        {/* yeast budding inset */}
        <group position={[4.6, 1.1, -1.4]}>
          <mesh castShadow>
            <sphereGeometry args={[0.4, 16, 12]} />
            <meshStandardMaterial color="#fde68a" roughness={0.5} />
          </mesh>
          <mesh position={[0.35, 0.25, 0]}>
            <sphereGeometry args={[0.18, 12, 10]} />
            <meshStandardMaterial color="#fde68a" roughness={0.5} />
          </mesh>
        </group>
        {showLabels && <Label text="yeast — budding" position={[4.6, 2.2, -1.4]} size={0.4} color="#fde047" />}

        <Animator colony={colony} spores={spores} elapsed={elapsed} speed={speed} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
