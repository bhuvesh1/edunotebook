"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "contract", label: "Contraction", kind: "slider", min: 0, max: 100, step: 5, default: 40, unit: " %" },
  { key: "speed", label: "Pulse speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Muscles: types, structure, actions",
  blurb: "Skeletal muscle fibers in action: they shorten and thicken as they contract — the sliding-filament theory you can see.",
};

function Fibers({ contract, speed }: { contract: number; speed: number }) {
  const fibers = useRef<(THREE.Mesh | null)[]>([]);
  const bands = useRef<(THREE.Mesh | null)[]>([]);
  const t = useRef(0);
  const c = contract / 100;
  useFrame((_, d) => {
    t.current += d * speed;
    fibers.current.forEach((m, i) => {
      if (!m) return;
      const wave = 1 + Math.sin(t.current * 2.5 - i * 0.9) * 0.06 * speed;
      m.scale.set(1 + c * 0.45 * wave, 1 - c * 0.38, 1 + c * 0.45 * wave);
    });
    bands.current.forEach((m, i) => {
      if (!m) return;
      m.position.x = ((t.current * (0.6 + c * 1.4) + i * 0.55) % 3.4) - 1.7;
    });
  });
  return (
    <group position={[0, 2.2, 0]}>
      {/* tendon caps */}
      {[-2.6, 2.6].map((x) => (
        <mesh key={x} position={[x, 0, 0]} castShadow>
          <boxGeometry args={[0.8, 1.6, 1.6]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.7} />
        </mesh>
      ))}
      {/* 5 muscle fibers */}
      {Array.from({ length: 5 }).map((_, i) => (
        <mesh
          key={i}
          ref={(m) => { fibers.current[i] = m; }}
          position={[0, 0, -1.1 + i * 0.55]}
          rotation={[0, 0, Math.PI / 2]}
          castShadow
        >
          <cylinderGeometry args={[0.2, 0.2, 4.4, 14]} />
          <meshStandardMaterial color="#dc2626" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.25 + c * 0.5} />
        </mesh>
      ))}
      {/* sliding actin/myosin bands travelling along fibers */}
      {Array.from({ length: 6 }).map((_, i) => (
        <mesh key={i} ref={(m) => { bands.current[i] = m; }} position={[0, 0, -1.1 + (i % 5) * 0.55]}>
          <boxGeometry args={[0.12, 0.5, 0.5]} />
          <meshStandardMaterial color="#fca5a5" emissive="#ef4444" emissiveIntensity={1.2} />
        </mesh>
      ))}
    </group>
  );
}

export function Topic10002Sim(props: SimProps) {
  const contract = Number(props.contract ?? 40);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Contraction", contract + " %"], ["Fiber type", "skeletal"], ["Action", contract > 66 ? "strong pull" : contract > 33 ? "moderate" : "relaxed"]]} />
      <SimCanvas cameraPosition={[0, 3.5, 11]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Fibers contract={contract} speed={speed} />
        {showLabels && (
          <>
            <Label text="Muscle fibers" position={[0, 4.2, 0]} color="#fca5a5" size={0.5} />
            <Label text="Tendon" position={[-3.4, 1.2, 0]} color="#e7e5e4" size={0.5} />
          </>
        )}
      </SimCanvas>
    </div>
  );
}
