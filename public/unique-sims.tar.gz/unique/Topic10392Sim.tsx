"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Stage", kind: "select", min: 0, max: 0, step: 1, default: "triturate", options: ["triturate", "pack", "carve"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Amalgam: composition, mercury hygiene, handling",
  blurb: "Shake the capsule to triturate alloy + mercury, pack the silver mass into the cavity, carve the anatomy — with mercury-hygiene rules.",
};

function Capsule({ active, speed }: { active: boolean; speed: number }) {
  const c = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (c.current) {
      c.current.position.x = active ? Math.sin(elapsed.current * 28) * 0.35 : 0;
      c.current.position.y = 2.6 + (active ? Math.abs(Math.sin(elapsed.current * 28)) * 0.15 : 0);
    }
  });
  return (
    <group position={[-4.4, 0, 0]}>
      <group ref={c}>
        {/* capsule halves */}
        <mesh castShadow>
          <capsuleGeometry args={[0.55, 1.1, 8, 18]} />
          <meshStandardMaterial color="#f97316" roughness={0.4} />
        </mesh>
        {/* alloy powder + mercury pellet inside (visible via cutaway tint) */}
        <mesh position={[-0.2, -0.2, 0]}>
          <sphereGeometry args={[0.3, 12, 10]} />
          <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.3} />
        </mesh>
        <mesh position={[0.25, 0.15, 0]}>
          <sphereGeometry args={[0.18, 12, 10]} />
          <meshStandardMaterial color="#e2e8f0" metalness={0.95} roughness={0.15} />
        </mesh>
      </group>
      {/* amalgamator arms */}
      {[-1.1, 1.1].map((x, i) => (
        <mesh key={i} position={[x, 2.6, 0]} castShadow>
          <boxGeometry args={[0.5, 2.2, 0.8]} />
          <meshStandardMaterial color="#475569" metalness={0.6} roughness={0.4} />
        </mesh>
      ))}
    </group>
  );
}

function AmalgamScene({ stage, speed, showLabels }: { stage: string; speed: number; showLabels: boolean }) {
  const packer = useRef<THREE.Group>(null!);
  const fill = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (packer.current && stage === "pack") {
      packer.current.position.y = 4.2 + Math.abs(Math.sin(elapsed.current * 5)) * -1.6;
    }
    if (fill.current) {
      const target = stage === "triturate" ? 0.001 : 1;
      const s = THREE.MathUtils.lerp(fill.current.scale.x, target, 0.05);
      fill.current.scale.setScalar(Math.max(s, 0.001));
    }
  });

  return (
    <group>
      <Capsule active={stage === "triturate"} speed={speed} />

      {/* tooth with cavity */}
      <group position={[2.6, 0, 0]}>
        <mesh position={[0, 0.6, 0]} castShadow>
          <boxGeometry args={[2.8, 2.6, 2.6]} />
          <meshStandardMaterial color="#fef9c3" roughness={0.25} />
        </mesh>
        <mesh position={[0, -1.6, 0]} castShadow>
          <cylinderGeometry args={[1.25, 0.45, 3.2, 16]} />
          <meshStandardMaterial color="#fde68a" roughness={0.4} />
        </mesh>
        {/* cavity prep */}
        <mesh position={[0, 1.5, 0]}>
          <boxGeometry args={[1.5, 1.2, 1.5]} />
          <meshStandardMaterial color="#a8a29e" roughness={0.9} />
        </mesh>
        {/* packed amalgam */}
        <mesh ref={fill} position={[0, 1.5, 0]} scale={[0.001, 0.001, 0.001]} castShadow>
          <boxGeometry args={[1.5, stage === "carve" ? 0.95 : 1.35, 1.5]} />
          <meshStandardMaterial color="#cbd5e1" metalness={0.85} roughness={0.3} />
        </mesh>
        {/* carved anatomy grooves */}
        {stage === "carve" && (
          <mesh position={[0, 2.05, 0]} rotation={[-Math.PI / 2, 0, 0.6]}>
            <planeGeometry args={[1.3, 0.12]} />
            <meshBasicMaterial color="#64748b" />
          </mesh>
        )}
      </group>

      {/* condenser packing */}
      {stage === "pack" && (
        <group ref={packer} position={[2.6, 4.2, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.12, 0.12, 2.2, 10]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.7} roughness={0.35} />
          </mesh>
          <mesh position={[0, -1.25, 0]} castShadow>
            <cylinderGeometry args={[0.3, 0.35, 0.4, 12]} />
            <meshStandardMaterial color="#64748b" metalness={0.7} roughness={0.35} />
          </mesh>
        </group>
      )}

      {/* mercury hygiene: sealed container + no-touch */}
      <group position={[-4.4, -2.2, 2.2]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.7, 0.7, 1, 18]} />
          <meshStandardMaterial color="#facc15" roughness={0.5} />
        </mesh>
        <mesh position={[0, 0.65, 0]}>
          <cylinderGeometry args={[0.72, 0.72, 0.25, 18]} />
          <meshStandardMaterial color="#1e293b" roughness={0.4} />
        </mesh>
      </group>

      {showLabels && (
        <>
          <Text position={[-4.4, 4.6, 0]} fontSize={0.42} color="#fdba74">Amalgamator — triturate 8–10 s</Text>
          <Text position={[2.6, 3.9, 0]} fontSize={0.42} color="#cbd5e1">
            {stage === "triturate" ? "Alloy + mercury → plastic mass" : stage === "pack" ? "Condense in increments!" : "Carve anatomy before it sets"}
          </Text>
          <Text position={[-4.4, -3.6, 2.2]} fontSize={0.38} color="#facc15" maxWidth={5}>Mercury hygiene: sealed scrap container, no bare hands</Text>
          <Text position={[0, -4.4, 0]} fontSize={0.4} color="#e2e8f0" maxWidth={11}>Composition: Ag–Sn–Cu alloy + Hg (~50%)</Text>
        </>
      )}
    </group>
  );
}

export function Topic10392Sim(props: SimProps) {
  const stage = String(props.stage ?? "triturate");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stage", stage],
          ["Alloy", "Ag–Sn–Cu + Hg"],
          ["Hygiene", "sealed container · ventilate · no touch"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 13]} target={[-0.5, 0.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.4, 0]} receiveShadow>
          <planeGeometry args={[36, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <AmalgamScene stage={stage} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
