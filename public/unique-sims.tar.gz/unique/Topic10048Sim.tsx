// Endocrine: adrenal cortex/medulla & pancreatic hormones — the adrenal cap on
// the kidney flashes adrenaline in "fight" bursts; the pancreatic islet
// releases insulin (blue) when glucose is high, glucagon (orange) when low.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "glucose", label: "Blood glucose", kind: "slider", min: 40, max: 300, step: 5, default: 100, unit: "mg/dL" },
  { key: "stress", label: "Stress (adrenaline)", kind: "slider", min: 0, max: 2, step: 0.1, default: 0.6, unit: "×" },
];

export const UNIQUE_META = {
  title: "Endocrine: Adrenal & Pancreatic Hormones",
  blurb: "Raise glucose and insulin pours out; drop it and glucagon answers. Crank stress for an adrenaline burst.",
};

function Animator({
  insulin, glucagon, adrenalFlash, medulla, elapsed, glucose, stress, speed,
}: {
  insulin: React.RefObject<THREE.Group>;
  glucagon: React.RefObject<THREE.Group>;
  adrenalFlash: React.RefObject<THREE.Mesh>;
  medulla: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  glucose: number;
  stress: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const insRate = Math.max(0, (glucose - 100) / 120);
    const gluRate = Math.max(0, (90 - glucose) / 60);
    const rise = (grp: React.RefObject<THREE.Group>, rate: number, spread: number) => {
      if (!grp.current) return;
      grp.current.children.forEach((m, i) => {
        const ph = ((t * 0.5 * rate + i / 7) % 1 + 1) % 1;
        m.position.y = 1.8 + ph * spread;
        m.position.x = 4.6 + Math.sin(i * 2.4) * 0.5;
        m.visible = rate > 0.02;
      });
    };
    rise(insulin, insRate, 1.6);
    rise(glucagon, gluRate, 1.6);
    if (adrenalFlash.current) {
      const burst = Math.max(0, Math.sin(t * 2.5)) * stress;
      const mat = adrenalFlash.current.material as THREE.MeshBasicMaterial;
      mat.opacity = Math.min(0.85, burst);
      adrenalFlash.current.scale.setScalar(1 + burst * 0.4);
    }
    if (medulla.current) {
      const mat = medulla.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = 0.3 + stress * 0.6 + 0.2 * Math.sin(t * 6);
    }
  });
  return null;
}

export function Topic10048Sim(props: SimProps) {
  const glucose = Number(props.glucose ?? 100);
  const stress = Number(props.stress ?? 0.6);
  const speed = 1;
  const insulin = useRef<THREE.Group>(null!);
  const glucagon = useRef<THREE.Group>(null!);
  const adrenalFlash = useRef<THREE.Mesh>(null!);
  const medulla = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const glyStatus = glucose > 140 ? "hyperglycemia → insulin ↑" : glucose < 80 ? "hypoglycemia → glucagon ↑" : "euglycemia ✓";
  const glyColor = glucose > 140 || glucose < 80 ? "#fca5a5" : "#86efac";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Glucose", `${glucose} mg/dL — ${glyStatus}`],
          ["Adrenal", stress > 1.2 ? "adrenaline surge!" : "basal cortisol"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* kidney with adrenal cap */}
        <group position={[-4, 0, 0]}>
          <mesh position={[0, 1.8, 0]} castShadow scale={[1, 1.35, 0.9]}>
            <sphereGeometry args={[1.0, 20, 20]} />
            <meshStandardMaterial color="#b91c1c" roughness={0.45} />
          </mesh>
          {/* adrenal cortex (outer) */}
          <mesh position={[0, 3.35, 0]} castShadow scale={[1.05, 0.55, 0.9]}>
            <sphereGeometry args={[0.72, 18, 18]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.45} />
          </mesh>
          {/* adrenal medulla (inner, flashes) */}
          <mesh ref={medulla} position={[0, 3.35, 0]} scale={[0.7, 0.35, 0.6]}>
            <sphereGeometry args={[0.6, 14, 14]} />
            <meshStandardMaterial color="#ef4444" emissive="#7f1d1d" emissiveIntensity={0.5} roughness={0.4} />
          </mesh>
          {/* adrenaline burst flash */}
          <mesh ref={adrenalFlash} position={[0, 3.35, 0]}>
            <sphereGeometry args={[1.0, 14, 14]} />
            <meshBasicMaterial color="#fef08a" transparent opacity={0.4} />
          </mesh>
        </group>
        <Label text="adrenal gland (cap on kidney)" position={[-4, 4.9, 0]} size={0.38} color="#f8fafc" />
        <Label text="cortex: cortisol, aldosterone" position={[-6.4, 3.5, 0]} size={0.3} color="#fde68a" />
        <Label text="medulla: adrenaline!" position={[-1.7, 3.35, 0]} size={0.3} color="#fca5a5" />

        {/* pancreas with islet of Langerhans */}
        <group position={[4.6, 0, 0]}>
          <mesh position={[0, 1.8, 0]} rotation={[0, 0, -0.35]} castShadow>
            <capsuleGeometry args={[0.5, 2.6, 6, 12]} />
            <meshStandardMaterial color="#fbbf24" roughness={0.5} />
          </mesh>
          {/* islet */}
          <mesh position={[0.3, 1.8, 0.55]} castShadow>
            <sphereGeometry args={[0.42, 14, 14]} />
            <meshStandardMaterial color="#fef3c7" emissive="#a16207" emissiveIntensity={0.4} roughness={0.4} />
          </mesh>
          {/* beta cells (blue) vs alpha cells (orange) */}
          {[0, 1, 2].map((i) => (
            <mesh key={`b${i}`} position={[0.15 + i * 0.16, 1.95, 0.75]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshStandardMaterial color="#38bdf8" />
            </mesh>
          ))}
          {[0, 1].map((i) => (
            <mesh key={`a${i}`} position={[0.2 + i * 0.18, 1.62, 0.75]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshStandardMaterial color="#fb923c" />
            </mesh>
          ))}
        </group>
        {/* insulin (blue) and glucagon (orange) release */}
        <group ref={insulin}>
          {Array.from({ length: 7 }).map((_, i) => (
            <mesh key={i} position={[4.6, 1.8, 0]}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshBasicMaterial color="#38bdf8" />
            </mesh>
          ))}
        </group>
        <group ref={glucagon}>
          {Array.from({ length: 7 }).map((_, i) => (
            <mesh key={i} position={[4.6, 1.8, 0]}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshBasicMaterial color="#fb923c" />
            </mesh>
          ))}
        </group>
        <Label text="pancreas — islet of Langerhans" position={[4.6, 0.6, 0]} size={0.38} color="#f8fafc" />
        <Label text="β cells → insulin (blue)" position={[6.9, 2.2, 0]} size={0.3} color="#7dd3fc" />
        <Label text="α cells → glucagon (orange)" position={[6.9, 1.55, 0]} size={0.3} color="#fdba74" />
        <Label text={glyStatus} position={[4.6, 4.1, 0]} size={0.34} color={glyColor} />

        <Animator insulin={insulin} glucagon={glucagon} adrenalFlash={adrenalFlash}
          medulla={medulla} elapsed={elapsed} glucose={glucose} stress={stress} speed={speed} />
      </SimCanvas>
    </div>
  );
}
