"use client";
// Toxicology: cardiac poisons & asphyxiants — CO, cyanide.
// A beating heart pumps while a gas cloud drifts in; pick carbon monoxide
// (blood turns cherry red) or cyanide and raise exposure to slow the beat.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "gas", label: "Poison gas", kind: "select", min: 0, max: 0, step: 1, default: "co", options: ["co", "cyanide"] },
  { key: "exposure", label: "Exposure", kind: "slider", min: 0, max: 100, step: 5, default: 25, unit: "%" },
];

export const UNIQUE_META = {
  title: "Cardiac Poisons & Asphyxiants: CO and Cyanide",
  blurb: "A heart beats as poison gas drifts in — carbon monoxide turns the blood cherry red while cyanide starves the cells.",
};

function Animator({ heart, cloud, elapsed, exposure }: { heart: React.RefObject<THREE.Group>; cloud: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; exposure: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const bpm = 72 - exposure * 0.45; // beat slows with exposure
    const beat = Math.pow(Math.max(0, Math.sin(elapsed.current * (bpm / 60) * Math.PI * 2)), 3);
    if (heart.current) {
      const s = 1 + beat * 0.16;
      heart.current.scale.set(s, s, s);
    }
    if (cloud.current) {
      cloud.current.children.forEach((c, i) => {
        c.position.x = -4 + ((elapsed.current * 0.7 + i * 1.37) % 9);
        c.position.y = 2.6 + Math.sin(elapsed.current * 1.2 + i * 2.4) * 0.5;
      });
      cloud.current.visible = exposure > 3;
    }
  });
  return null;
}

export function Topic10162Sim(props: SimProps) {
  const gas = String(props.gas ?? "co");
  const exposure = Number(props.exposure ?? 25);
  const heart = useRef<THREE.Group>(null!);
  const cloud = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const bpm = Math.round(72 - exposure * 0.45);
  const isCO = gas === "co";
  const heartColor = isCO && exposure > 40 ? "#fb7185" : exposure > 60 ? "#7f1d1d" : "#ef4444";
  const note = isCO ? "CO: cherry-red blood, no breathlessness" : "Cyanide: bitter-almond smell, cell suffocation";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Gas", isCO ? "Carbon monoxide" : "Cyanide"], ["Heart rate", `${bpm} bpm`], ["Clue", note]]} />
      <SimCanvas cameraPosition={[0, 3.2, 12]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* heart: two lobes + vessels */}
        <group ref={heart} position={[1.6, 2.4, 0]}>
          <mesh position={[-0.42, 0.25, 0]} castShadow>
            <sphereGeometry args={[0.72, 20, 20]} />
            <meshStandardMaterial color={heartColor} roughness={0.45} />
          </mesh>
          <mesh position={[0.42, 0.25, 0]} castShadow>
            <sphereGeometry args={[0.72, 20, 20]} />
            <meshStandardMaterial color={heartColor} roughness={0.45} />
          </mesh>
          <mesh position={[0, -0.55, 0]} rotation={[0, 0, Math.PI]}>
            <coneGeometry args={[0.95, 1.1, 20]} />
            <meshStandardMaterial color={heartColor} roughness={0.45} />
          </mesh>
          <mesh position={[-0.3, 1.15, 0]} castShadow>
            <cylinderGeometry args={[0.18, 0.24, 0.9, 12]} />
            <meshStandardMaterial color={isCO && exposure > 40 ? "#fda4af" : "#f87171"} roughness={0.5} />
          </mesh>
          <Label text="HEART" position={[0, -1.9, 0]} size={0.6} color="#f87171" />
        </group>
        {/* gas cloud drifting in from the left */}
        <group ref={cloud}>
          {Array.from({ length: 8 }, (_, i) => (
            <mesh key={i} position={[-4 + i, 2.6, -0.5]}>
              <sphereGeometry args={[0.55, 12, 12]} />
              <meshStandardMaterial color={isCO ? "#9ca3af" : "#a3e635"} transparent opacity={0.45} roughness={0.9} />
            </mesh>
          ))}
        </group>
        {/* gas mask / source */}
        <group position={[-5.4, 0, 0]}>
          <mesh position={[0, 1.6, 0]} castShadow>
            <boxGeometry args={[1.4, 1.8, 1]} />
            <meshStandardMaterial color="#365314" roughness={0.8} />
          </mesh>
          <mesh position={[0, 2.7, 0]}>
            <cylinderGeometry args={[0.25, 0.25, 0.5, 12]} />
            <meshStandardMaterial color="#4d7c0f" roughness={0.7} />
          </mesh>
          <Label text={isCO ? "CO GAS" : "CYANIDE"} position={[0, 0.4, 0]} size={0.55} color={isCO ? "#9ca3af" : "#a3e635"} />
        </group>
        {/* blood drop showing cherry-red change */}
        <group position={[4.6, 2.4, 0]}>
          <mesh castShadow>
            <sphereGeometry args={[0.55, 16, 16]} />
            <meshStandardMaterial color={isCO && exposure > 40 ? "#fb7185" : "#991b1b"} roughness={0.3} />
          </mesh>
          <mesh position={[0, 0.75, 0]}>
            <coneGeometry args={[0.3, 0.6, 12]} />
            <meshStandardMaterial color={isCO && exposure > 40 ? "#fb7185" : "#991b1b"} roughness={0.3} />
          </mesh>
          <Label text={isCO && exposure > 40 ? "CHERRY-RED BLOOD" : "BLOOD"} position={[0, -1, 0]} size={0.55} color="#f87171" />
        </group>
        <Animator heart={heart} cloud={cloud} elapsed={elapsed} exposure={exposure} />
      </SimCanvas>
    </div>
  );
}
