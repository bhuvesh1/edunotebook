// app/components/sims/unique/Topic7101Sim.tsx
// Unit vectors and position vectors: the red, green and blue arrows are
// the unit vectors i, j, k (each exactly length 1). The gold arrow is the
// position vector r of a satellite — its tip coordinates (x, y, z) are
// shown live.

"use client";

import { useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Orbit speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Unit Vectors and Position Vectors",
  blurb: "i, j, k are unit arrows along the axes; the gold position vector r always points at the satellite.",
};

function UnitArrow({ dir, color }: { dir: [number, number, number]; color: string }) {
  // Arrow of length 1.5 along dir (a unit axis).
  const quat = useMemo(() => {
    const q = new THREE.Quaternion();
    q.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(...dir).normalize());
    return q;
  }, [dir]);
  return (
    <group quaternion={quat}>
      <mesh position={[0, 0.75, 0]}>
        <cylinderGeometry args={[0.07, 0.07, 1.5, 10]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} roughness={0.4} />
      </mesh>
      <mesh position={[0, 1.65, 0]}>
        <coneGeometry args={[0.18, 0.35, 12]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} roughness={0.4} />
      </mesh>
    </group>
  );
}

function Animator({
  rArrow, sat, speed, pos, bump,
}: {
  rArrow: RefObject<THREE.Group>;
  sat: RefObject<THREE.Mesh>;
  speed: number;
  pos: RefObject<{ x: number; y: number; z: number }>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta * speed;
    const T = t.current;
    const p = new THREE.Vector3(
      2.6 * Math.cos(T * 0.8),
      2.6 + 1.4 * Math.sin(T * 1.1),
      2.6 * Math.sin(T * 0.8)
    );
    pos.current = { x: p.x, y: p.y, z: p.z };
    if (sat.current) sat.current.position.copy(p);
    if (rArrow.current) {
      // Stretch a +Y arrow from origin to p.
      const len = p.length();
      rArrow.current.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), p.clone().normalize());
      const shaft = rArrow.current.children[0] as THREE.Mesh;
      const cone = rArrow.current.children[1] as THREE.Mesh;
      shaft.scale.set(1, len, 1);
      shaft.position.set(0, len / 2, 0);
      cone.position.set(0, len + 0.2, 0);
    }
    if (++n.current % 20 === 0) bump();
  });
  return null;
}

export function Topic7101Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const rArrow = useRef<THREE.Group>(null!);
  const sat = useRef<THREE.Mesh>(null!);
  const pos = useRef({ x: 2.6, y: 2.6, z: 0 });
  const [, bump] = useState(0);

  const grid = useMemo(() => new THREE.GridHelper(12, 12, "#334155", "#1e293b"), []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["r = (x, y, z)", `(${pos.current.x.toFixed(1)}, ${pos.current.y.toFixed(1)}, ${pos.current.z.toFixed(1)})`],
          ["🔴 i", "(1, 0, 0)"],
          ["🟢 j", "(0, 1, 0)"],
          ["🔵 k", "(0, 0, 1)"],
        ]}
      />
      <SimCanvas cameraPosition={[7, 6, 9]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 24]} />
          <meshStandardMaterial color="#0b1020" roughness={1} />
        </mesh>
        <primitive object={grid} position={[0, 0.02, 0]} />

        <group position={[0, 0.1, 0]}>
          <UnitArrow dir={[1, 0, 0]} color="#ef4444" />
          <UnitArrow dir={[0, 1, 0]} color="#22c55e" />
          <UnitArrow dir={[0, 0, 1]} color="#3b82f6" />
          {/* position vector r */}
          <group ref={rArrow}>
            <mesh>
              <cylinderGeometry args={[0.08, 0.08, 1, 10]} />
              <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.6} roughness={0.4} />
            </mesh>
            <mesh>
              <coneGeometry args={[0.2, 0.4, 12]} />
              <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.6} roughness={0.4} />
            </mesh>
          </group>
        </group>

        {/* the satellite */}
        <mesh ref={sat} castShadow>
          <sphereGeometry args={[0.3, 24, 24]} />
          <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.7} roughness={0.35} />
        </mesh>

        <Animator rArrow={rArrow} sat={sat} speed={speed} pos={pos} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
