// Antifungals & antivirals: branching fungal hyphae creep across skin while a
// spiky virus replicates nearby — the chosen drug attacks its target.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "target", label: "Drug target", kind: "select", min: 0, max: 0, step: 1, default: "fungus", options: ["fungus", "virus"] },
  { key: "dose", label: "Drug dose", kind: "slider", min: 0, max: 100, step: 5, default: 60, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Antifungals & antivirals",
  blurb: "Fungal hyphae creep across skin while a spiky virus replicates — the drug attacks its chosen target.",
};

const N_DX = 8;

function Animator({ hyphae, virus, dx, elapsed, dose, target, setTick }: {
  hyphae: React.RefObject<THREE.Group>;
  virus: React.RefObject<THREE.Group>;
  dx: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  dose: number;
  target: string;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    const atkFungus = target === "fungus" ? k : 0;
    const atkVirus = target === "virus" ? k : 0;
    if (hyphae.current) {
      // hyphae wither under antifungal
      const s = Math.max(0.15, 1 - atkFungus * 0.85);
      hyphae.current.scale.set(s, Math.max(0.1, 1 - atkFungus * 0.9), s);
      hyphae.current.rotation.y = t * 0.1;
    }
    if (virus.current) {
      virus.current.rotation.y = t * (0.8 + (1 - atkVirus) * 1.2);
      const vs = Math.max(0.15, 1 - atkVirus * 0.85);
      virus.current.scale.setScalar(vs);
      virus.current.position.y = 1.9 + Math.sin(t * 2) * 0.12 * (1 - atkVirus);
    }
    dx.current.forEach((d, i) => {
      if (!d) return;
      const tx = target === "fungus" ? -3 : 3;
      const f = (t * 0.5 + i / N_DX) % 1;
      d.position.set(tx + Math.sin(f * Math.PI * 2 + i) * 1.4 * (1 - f), 3.4 - f * 2.2, Math.cos(f * 6 + i) * 0.8);
      d.rotation.y = t * 4 + i;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(k * 100)); }
  });
  return null;
}

function Hyphae() {
  const segs: { p: [number, number, number]; r: [number, number, number]; l: number }[] = [
    { p: [0, 0, 0], r: [0, 0, Math.PI / 2.3], l: 2.2 },
    { p: [0.9, 0.5, 0.2], r: [0.4, 0, Math.PI / 3], l: 1.4 },
    { p: [-0.8, 0.4, -0.3], r: [-0.3, 0, -Math.PI / 3], l: 1.3 },
    { p: [0.2, 0.9, 0.5], r: [0.9, 0, 0.4], l: 1.1 },
    { p: [-0.2, -0.4, 0.4], r: [-0.8, 0, -0.5], l: 1.0 },
  ];
  return (
    <group>
      {segs.map((s, i) => (
        <group key={i}>
          <mesh position={s.p} rotation={s.r} castShadow>
            <cylinderGeometry args={[0.09, 0.13, s.l, 8]} />
            <meshStandardMaterial color="#d6c79a" roughness={0.7} />
          </mesh>
          <mesh position={[s.p[0] + 0.3, s.p[1] + 0.55, s.p[2]]}>
            <sphereGeometry args={[0.14, 10, 8]} />
            <meshStandardMaterial color="#f5eeda" emissive="#a8a29e" emissiveIntensity={0.3} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function Virus() {
  return (
    <group>
      <mesh castShadow>
        <sphereGeometry args={[0.8, 20, 14]} />
        <meshStandardMaterial color="#a855f7" roughness={0.5} />
      </mesh>
      {Array.from({ length: 12 }).map((_, i) => {
        const th = (i / 12) * Math.PI * 2;
        const ph = (i % 3) * 0.9 - 0.9;
        return (
          <mesh
            key={i}
            position={[Math.cos(th) * Math.cos(ph) * 0.95, Math.sin(ph) * 0.95, Math.sin(th) * Math.cos(ph) * 0.95]}
            rotation={[ph, th, 0]}
          >
            <coneGeometry args={[0.1, 0.4, 8]} />
            <meshStandardMaterial color="#e9d5ff" emissive="#7e22ce" emissiveIntensity={0.6} />
          </mesh>
        );
      })}
    </group>
  );
}

export function Topic10119Sim(props: SimProps) {
  const target = String(props.target ?? "fungus");
  const dose = Number(props.dose ?? 60);
  const showLabels = String(props.detail ?? "on") === "on";
  const hyphae = useRef<THREE.Group>(null!);
  const virus = useRef<THREE.Group>(null!);
  const dx = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const k = dose / 100;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Target", target === "fungus" ? "Fungus" : "Virus"],
          ["Pathogen load", `${Math.max(5, Math.round(100 - k * 92))}%`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* skin patch with fungus */}
        <mesh position={[-3, 0.35, 0]} receiveShadow>
          <boxGeometry args={[4.4, 0.7, 3.4]} />
          <meshStandardMaterial color="#e8b48c" roughness={0.8} />
        </mesh>
        <group ref={hyphae} position={[-3, 0.75, 0]}>
          <Hyphae />
        </group>
        {showLabels && <Label text="fungal hyphae on skin" position={[-3, 2.7, 0]} color="#f5eeda" />}

        {/* virus */}
        <group ref={virus} position={[3, 1.9, 0]}>
          <Virus />
        </group>
        {showLabels && <Label text="virus" position={[3, 3.4, 0]} color="#d8b4fe" />}

        {/* drug molecules homing to target */}
        {Array.from({ length: N_DX }).map((_, i) => (
          <mesh key={i} ref={(m) => { dx.current[i] = m; }} castShadow>
            <icosahedronGeometry args={[0.16]} />
            <meshStandardMaterial
              color={target === "fungus" ? "#f59e0b" : "#22d3ee"}
              emissive={target === "fungus" ? "#b45309" : "#0e7490"}
              emissiveIntensity={1}
            />
          </mesh>
        ))}
        {showLabels && (
          <Label
            text={target === "fungus" ? "antifungal drug" : "antiviral drug"}
            position={[target === "fungus" ? -3 : 3, 4.3, 0]}
            color={target === "fungus" ? "#fcd34d" : "#67e8f9"}
          />
        )}

        <Animator hyphae={hyphae} virus={virus} dx={dx} elapsed={elapsed} dose={dose} target={target} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
