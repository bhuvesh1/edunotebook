// Ocular anatomy & physiology of vision — eyeball cutaway: light enters through
// cornea → pupil → lens and focuses on the retina; a pulse then travels down
// the optic nerve to the brain.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "light", label: "Light brightness", kind: "slider", min: 0.2, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "labels", label: "Labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Ocular Anatomy & Vision",
  blurb: "Light rays travel through cornea, pupil and lens to focus on the retina, which fires the optic nerve.",
};

function Animator({ pulse, rays, elapsed, speed, light }: {
  pulse: React.RefObject<THREE.Mesh>;
  rays: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  light: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (pulse.current) {
      // signal packet travels from retina along the optic nerve to the brain
      const ph = (t % 3) / 3;
      pulse.current.position.x = -1.2 - ph * 4.2;
      const s = 0.22 + 0.1 * Math.sin(t * 10);
      pulse.current.scale.setScalar(s / 0.22);
    }
    if (rays.current) {
      const mat = (rays.current.children[0] as THREE.Mesh).material as THREE.MeshBasicMaterial;
      mat.opacity = 0.35 + 0.3 * light;
      rays.current.children.forEach((c, i) => {
        c.position.y += 0; // static paths, shimmering handled by opacity
      });
    }
  });
  return null;
}

function LightRay({ y, light }: { y: number; light: number }) {
  // parallel ray entering the eye, bending at the lens to meet on the retina
  return (
    <group>
      <Arrow from={[-6.2, y, 0]} to={[-1.15, y, 0]} color="#fef08a" radius={0.045} />
      <Arrow from={[-1.15, y, 0]} to={[1.05, y * 0.14, 0]} color="#fde047" radius={0.045} />
    </group>
  );
}

export function Topic10198Sim(props: SimProps) {
  const light = Number(props.light ?? 1);
  const showLabels = String(props.labels ?? "on") === "on";
  const speed = 1;
  const pulse = useRef<THREE.Mesh>(null!);
  const rays = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Vision path", "cornea → lens → retina → brain"], ["Focus", "sharp on retina"]]} />
      <SimCanvas cameraPosition={[0, 1.6, 11]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* sclera: white ball, front quarter cut away to see inside */}
        <mesh position={[0, 1.2, 0]} castShadow>
          <sphereGeometry args={[2.2, 40, 28, Math.PI * 0.42, Math.PI * 1.55, 0, Math.PI]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.35} side={THREE.DoubleSide} />
        </mesh>
        {/* retina: inner back lining */}
        <mesh position={[0, 1.2, 0]}>
          <sphereGeometry args={[1.92, 32, 24, Math.PI * 0.55, Math.PI * 1.1, Math.PI * 0.25, Math.PI * 0.5]} />
          <meshStandardMaterial color="#f97316" roughness={0.6} side={THREE.DoubleSide} emissive="#7c2d12" emissiveIntensity={0.35} />
        </mesh>
        {/* cornea: clear front dome */}
        <mesh position={[0, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <sphereGeometry args={[2.05, 32, 16, -Math.PI * 0.22, Math.PI * 0.44, Math.PI * 0.3, Math.PI * 0.4]} />
          <meshStandardMaterial color="#bae6fd" transparent opacity={0.45} roughness={0.1} />
        </mesh>
        {/* iris ring + pupil */}
        <mesh position={[2.02, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.72, 0.34, 14, 32]} />
          <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
        </mesh>
        <mesh position={[2.0, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <circleGeometry args={[0.42, 24]} />
          <meshStandardMaterial color="#020617" roughness={0.9} />
        </mesh>
        {/* lens */}
        <mesh position={[1.15, 1.2, 0]} scale={[0.55, 1, 1]} castShadow>
          <sphereGeometry args={[0.62, 24, 18]} />
          <meshStandardMaterial color="#7dd3fc" transparent opacity={0.75} roughness={0.15} />
        </mesh>
        {/* vitreous hint */}
        <mesh position={[0, 1.2, 0]}>
          <sphereGeometry args={[1.5, 20, 14]} />
          <meshStandardMaterial color="#e0f2fe" transparent opacity={0.12} roughness={0.2} />
        </mesh>
        {/* optic nerve: cable from back of eye toward the brain */}
        <mesh position={[-3.1, 1.2, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.42, 0.5, 3.6, 18]} />
          <meshStandardMaterial color="#fbbf24" roughness={0.55} />
        </mesh>
        {/* brain blob */}
        <mesh position={[-5.6, 1.2, 0]} scale={[1, 1.15, 0.9]}>
          <sphereGeometry args={[0.95, 24, 18]} />
          <meshStandardMaterial color="#f472b6" roughness={0.55} />
        </mesh>
        {/* travelling signal pulse */}
        <mesh ref={pulse} position={[-1.2, 1.2, 0]}>
          <sphereGeometry args={[0.22, 16, 16]} />
          <meshBasicMaterial color="#fde047" />
        </mesh>

        {/* light rays */}
        <group ref={rays}>
          <LightRay y={2.15} light={light} />
          <LightRay y={1.2} light={light} />
          <LightRay y={0.25} light={light} />
        </group>

        {showLabels && (
          <>
            <Label text="Cornea" position={[2.4, 3.9, 0]} size={0.5} color="#bae6fd" />
            <Label text="Iris + Pupil" position={[3.4, 2.4, 0]} size={0.5} color="#7dd3fc" />
            <Label text="Lens" position={[1.15, 0.05, 0]} size={0.5} color="#7dd3fc" />
            <Label text="Retina" position={[-1.1, 3.9, 0]} size={0.5} color="#fdba74" />
            <Label text="Optic nerve" position={[-3.1, 2.75, 0]} size={0.5} color="#fde047" />
            <Label text="Brain sees the image" position={[-5.6, 3.1, 0]} size={0.5} color="#f9a8d4" />
          </>
        )}
        <Animator pulse={pulse} rays={rays} elapsed={elapsed} speed={speed} light={light} />
      </SimCanvas>
    </div>
  );
}
