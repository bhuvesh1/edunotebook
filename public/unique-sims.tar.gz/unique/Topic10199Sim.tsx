// Refractive errors — myopia (long eyeball: rays meet BEFORE the retina),
// hypermetropia (short eyeball: rays would meet BEHIND it), astigmatism
// (two focal points). Lens-power slider moves the focal point toward the retina.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "error", label: "Refractive error", kind: "select", min: 0, max: 0, step: 1, default: "myopia", options: ["myopia", "hypermetropia", "astigmatism"] },
  { key: "power", label: "Lens power", kind: "slider", min: -6, max: 6, step: 0.5, default: 0, unit: " D" },
];

export const UNIQUE_META = {
  title: "Refractive Errors",
  blurb: "See where light focuses in myopia, hypermetropia and astigmatism — and how lens power shifts it back onto the retina.",
};

function Animator({ rays, elapsed }: { rays: React.RefObject<THREE.Group>; elapsed: React.RefObject<number> }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (rays.current) {
      const t = elapsed.current;
      rays.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        ((m as THREE.Mesh).material as THREE.MeshBasicMaterial).opacity = 0.55 + 0.25 * Math.sin(t * 6 + i * 1.3);
      });
    }
  });
  return null;
}

function Ray({ from, to, color = "#fde047" }: { from: [number, number, number]; to: [number, number, number]; color?: string }) {
  const dir = new THREE.Vector3(to[0] - from[0], to[1] - from[1], to[2] - from[2]);
  const len = dir.length();
  const mid = new THREE.Vector3((from[0] + to[0]) / 2, (from[1] + to[1]) / 2, (from[2] + to[2]) / 2);
  const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  return (
    <mesh position={mid.toArray()} quaternion={quat}>
      <cylinderGeometry args={[0.05, 0.05, len, 8]} />
      <meshBasicMaterial color={color} transparent opacity={0.7} />
    </mesh>
  );
}

export function Topic10199Sim(props: SimProps) {
  const error = String(props.error ?? "myopia");
  const power = Number(props.power ?? 0);
  const rays = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  // eyeball proportions per error; retina sits at back of eye (x = 0.55 depth)
  const retinaX = error === "myopia" ? -0.9 : error === "hypermetropia" ? 0.9 : 0;
  const eyeStretch = error === "myopia" ? 1.25 : error === "hypermetropia" ? 0.85 : 1.0;
  // natural focal point without correction
  const naturalF = error === "myopia" ? 1.9 : error === "hypermetropia" ? -1.6 : 0.4;
  // lens power nudges the focal point toward the retina
  const focusX = naturalF + power * 0.28;
  const onRetina = Math.abs(focusX - retinaX) < 0.25;

  const rayYs = [2.3, 1.2, 0.1];
  const lensX = -1.15;

  const focusDesc =
    error === "astigmatism"
      ? "two focal points — blurred"
      : focusX > retinaX + 0.25
        ? "focus BEFORE retina"
        : focusX < retinaX - 0.25
          ? "focus BEHIND retina"
          : "focus ON retina — clear!";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Error", error], ["Focus", onRetina ? "ON retina ✓" : "off retina"], ["Lens power", `${power.toFixed(1)} D`]]} />
      <SimCanvas cameraPosition={[0, 1.6, 11.5]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* eyeball scaled per error */}
        <mesh position={[retinaX, 1.2, 0]} scale={[eyeStretch, 1, 1]} castShadow>
          <sphereGeometry args={[2.2, 36, 26]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.35} />
        </mesh>
        {/* retina line at back */}
        <mesh position={[retinaX - 2.05 * eyeStretch, 1.2, 0]}>
          <boxGeometry args={[0.12, 3.4, 2.6]} />
          <meshStandardMaterial color="#f97316" roughness={0.6} emissive="#7c2d12" emissiveIntensity={0.4} />
        </mesh>
        <Label text="Retina" position={[retinaX - 2.05 * eyeStretch, 3.6, 0]} size={0.5} color="#fdba74" />
        {/* corrective lens */}
        <mesh position={[-3.4, 1.2, 0]} rotation={[0, Math.PI / 2, 0]} scale={[1, 1.4, 1]}>
          <cylinderGeometry args={[0.9, 0.9, 0.12, 28]} />
          <meshStandardMaterial color={power === 0 ? "#1e293b" : "#7dd3fc"} transparent opacity={power === 0 ? 0.35 : 0.85} roughness={0.15} />
        </mesh>
        <Label text={power === 0 ? "no glasses" : "glasses lens"} position={[-3.4, 3.2, 0]} size={0.45} color="#7dd3fc" />

        {/* rays: parallel in → bent at lens → meet at focusX */}
        <group ref={rays}>
          {rayYs.map((y, i) => (
            <group key={i}>
              <Ray from={[-6.2, y, 0]} to={[lensX, y, 0]} />
              {error === "astigmatism" ? (
                <>
                  <Ray from={[lensX, y, 0]} to={[focusX, y * 0.12, 0]} />
                  <Ray from={[lensX, y, 0]} to={[focusX - 0.9, y * 0.1, 0]} color="#f59e0b" />
                </>
              ) : (
                <Ray from={[lensX, y, 0]} to={[focusX, y * 0.12, 0]} />
              )}
            </group>
          ))}
        </group>

        {/* focal point marker */}
        <mesh position={[focusX, 1.2, 0]}>
          <sphereGeometry args={[0.2, 16, 16]} />
          <meshBasicMaterial color={onRetina ? "#22c55e" : "#ef4444"} />
        </mesh>
        <Label text={onRetina ? "sharp image ✓" : "blurry image"} position={[focusX, 0.1, 0]} size={0.5} color={onRetina ? "#86efac" : "#fca5a5"} />

        {/* retina screen behind focus point line */}
        <mesh position={[retinaX - 2.05 * eyeStretch + 0.2, 1.2, 0]} visible={Math.abs(focusX - retinaX) > 0.25}>
          <ringGeometry args={[0.5, 0.62, 24]} />
          <meshBasicMaterial color="#ef4444" transparent opacity={0.5} side={THREE.DoubleSide} />
        </mesh>

        <Label text={focusDesc} position={[1.5, 4.6, 0]} size={0.55} color="#fde047" />
        <Label text="Myopia = too long · Hypermetropia = too short · Astigmatism = uneven curve" position={[0, -1.6, 0]} size={0.42} color="#94a3b8" />
        <Animator rays={rays} elapsed={elapsed} />
      </SimCanvas>
    </div>
  );
}
