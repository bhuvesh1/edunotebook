// Gynecology: PCOS, endometriosis, adenomyosis.
// A magnified ovary shows PCOS's "string of pearls" cysts; endometriosis
// plants bleeding lesions outside the uterus; adenomyosis thickens the
// uterine wall itself.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "pcos", options: ["normal", "pcos", "endometriosis", "adenomyosis"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Ovary & Uterus: PCOS, Endometriosis",
  blurb: "PCOS pearls on the ovary, endometriosis lesions bleeding outside the womb, or adenomyosis swelling the uterine wall.",
};

function Animator({
  group, cysts, lesions, elapsed, speed, condition,
}: {
  group: React.RefObject<THREE.Group>;
  cysts: React.RefObject<THREE.Group>;
  lesions: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  condition: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    if (cysts.current) {
      cysts.current.visible = condition === "pcos";
      cysts.current.children.forEach((c, i) => {
        (c as THREE.Mesh).scale.setScalar(1 + 0.15 * Math.sin(t * 2.5 + i * 1.3));
      });
    }
    if (lesions.current) {
      lesions.current.visible = condition === "endometriosis";
      lesions.current.children.forEach((l, i) => {
        const m = (l as THREE.Mesh).material as THREE.MeshStandardMaterial;
        m.emissiveIntensity = 0.4 + 0.5 * (0.5 + 0.5 * Math.sin(t * 3 + i * 2.1));
      });
    }
  });
  return null;
}

export function Topic10286Sim(props: SimProps) {
  const condition = String(props.condition ?? "pcos");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const cysts = useRef<THREE.Group>(null!);
  const lesions = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    normal: "Normal ovary + uterus", pcos: "PCOS — many small cysts",
    endometriosis: "Endometriosis — lesions outside", adenomyosis: "Adenomyosis — thick wall",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Condition", names[condition] ?? condition], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10.5]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* uterus center */}
          <mesh position={[0, 2.0, -0.4]} scale={[1.0, 1.15, 0.85]} castShadow>
            <sphereGeometry args={[0.95, 28, 20]} />
            <meshStandardMaterial
              color={condition === "adenomyosis" ? "#e11d48" : "#f9a8d4"}
              roughness={0.5}
              transparent
              opacity={condition === "adenomyosis" ? 0.9 : 0.6}
              emissive={condition === "adenomyosis" ? "#881337" : "#000000"}
              emissiveIntensity={0.35}
            />
          </mesh>
          {condition === "adenomyosis" && (
            <mesh position={[0, 2.0, -0.4]} scale={[1.25, 1.4, 1.05]}>
              <sphereGeometry args={[0.95, 24, 18]} />
              <meshStandardMaterial color="#fb7185" roughness={0.6} transparent opacity={0.45} />
            </mesh>
          )}
          {/* ovary: magnified on the right */}
          <group position={[2.4, 2.2, 0.3]}>
            <mesh scale={[1, 1.3, 0.85]} castShadow>
              <sphereGeometry args={[0.85, 26, 20]} />
              <meshStandardMaterial color="#fde68a" roughness={0.5} />
            </mesh>
            {/* PCOS: ring of small cysts — string of pearls */}
            <group ref={cysts} visible={false}>
              {Array.from({ length: 10 }).map((_, i) => {
                const a = (i / 10) * Math.PI * 2;
                return (
                  <mesh key={i} position={[Math.cos(a) * 0.68, Math.sin(a) * 0.88, 0.3]} castShadow>
                    <sphereGeometry args={[0.2, 14, 10]} />
                    <meshStandardMaterial color="#7dd3fc" roughness={0.25} transparent opacity={0.9} emissive="#0369a1" emissiveIntensity={0.4} />
                  </mesh>
                );
              })}
            </group>
            {/* normal: one dominant follicle */}
            {condition !== "pcos" && (
              <mesh position={[0.3, 0.4, 0.35]} castShadow>
                <sphereGeometry args={[0.24, 14, 10]} />
                <meshStandardMaterial color="#38bdf8" roughness={0.25} transparent opacity={0.9} />
              </mesh>
            )}
          </group>
          {/* endometriosis lesions scattered outside the uterus */}
          <group ref={lesions} visible={false}>
            {[[-1.7, 1.2, 0.5], [1.5, 1.0, 0.6], [-0.9, 3.3, 0.3], [0.8, 3.4, -0.1], [-2.2, 2.4, 0.2]].map(([x, y, z], i) => (
              <mesh key={i} position={[x, y, z]} castShadow>
                <icosahedronGeometry args={[0.22, 0]} />
                <meshStandardMaterial color="#991b1b" roughness={0.6} emissive="#7f1d1d" emissiveIntensity={0.8} flatShading />
              </mesh>
            ))}
          </group>
          <Label text="Uterus" position={[-1.8, 2.8, -0.4]} size={0.55} color="#f9a8d4" />
          <Label text="Ovary (magnified)" position={[2.4, 3.65, 0.3]} size={0.55} color="#fde68a" />
          {condition === "pcos" && <Label text="⚠ String-of-pearls cysts" position={[2.4, 0.95, 0.3]} size={0.55} color="#7dd3fc" />}
          {condition === "endometriosis" && <Label text="⚠ Tissue growing OUTSIDE — bleeds & hurts" position={[0, 0.35, 0.5]} size={0.55} color="#fca5a5" />}
          {condition === "adenomyosis" && <Label text="⚠ Wall thickened & bulky" position={[0, 0.45, -0.2]} size={0.55} color="#fda4af" />}
          {condition === "normal" && <Label text="One egg ripens ✓" position={[2.4, 0.95, 0.3]} size={0.5} color="#86efac" />}
        </group>
        <Animator group={group} cysts={cysts} lesions={lesions} elapsed={elapsed} speed={speed} condition={condition} />
      </SimCanvas>
    </div>
  );
}
