// Dislocations: shoulder, elbow, hip.
// The ball pops OUT of its socket — then the doctor's maneuver snaps it back
// in. Watch the shoulder dislocate and reduce on loop.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "joint", label: "Joint", kind: "select", min: 0, max: 0, step: 1, default: "shoulder", options: ["shoulder", "elbow", "hip"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Dislocated Joint: Pop Out & Back",
  blurb: "The ball jumps out of its socket — then the reduction maneuver clicks it back into place.",
};

function Animator({
  group, ball, warn, elapsed, speed, joint,
}: {
  group: React.RefObject<THREE.Group>;
  ball: React.RefObject<THREE.Group>;
  warn: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
  joint: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
    // dislocation cycle: in place -> pops out -> held out -> snaps back
    const cyc = (t % 8) / 8;
    let out: number;
    if (cyc < 0.25) out = 0;
    else if (cyc < 0.35) out = (cyc - 0.25) / 0.1; // POP!
    else if (cyc < 0.65) out = 1;
    else if (cyc < 0.75) out = 1 - (cyc - 0.65) / 0.1; // reduction
    else out = 0;
    if (ball.current) {
      if (joint === "shoulder") {
        ball.current.position.set(-1 + out * -0.9, 3.4 - out * 0.7, 0.2 + out * 0.3);
        ball.current.rotation.z = out * 0.8;
      } else if (joint === "elbow") {
        ball.current.position.set(0.5 + out * 0.8, 2.2 - out * 0.4, 0);
      } else {
        ball.current.position.set(0.6 + out * 0.7, 3.2 - out * 0.5, 0.3);
      }
    }
    if (warn.current) {
      warn.current.visible = out > 0.5;
      warn.current.scale.setScalar(1 + 0.25 * Math.sin(t * 6));
    }
  });
  return null;
}

export function Topic10299Sim(props: SimProps) {
  const joint = String(props.joint ?? "shoulder");
  const speed = Number(props.speed ?? 1);
  const group = useRef<THREE.Group>(null!);
  const ball = useRef<THREE.Group>(null!);
  const warn = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = { shoulder: "Shoulder", elbow: "Elbow", hip: "Hip" };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Joint", names[joint] ?? joint], ["Cycle", "Dislocate → reduce (loop)"], ["Speed", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {joint === "shoulder" && (
            <>
              {/* scapula with glenoid socket */}
              <mesh position={[0.6, 3.5, -0.3]} scale={[1, 1.4, 0.4]} castShadow>
                <sphereGeometry args={[0.8, 20, 14]} />
                <meshStandardMaterial color="#cbd5e1" roughness={0.5} />
              </mesh>
              <mesh position={[-0.35, 3.55, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
                <torusGeometry args={[0.42, 0.16, 12, 20, Math.PI]} />
                <meshStandardMaterial color="#94a3b8" roughness={0.5} />
              </mesh>
              {/* humerus head (the ball) + shaft */}
              <group ref={ball} position={[-1, 3.4, 0.2]}>
                <mesh castShadow>
                  <sphereGeometry args={[0.38, 20, 14]} />
                  <meshStandardMaterial color="#f8fafc" roughness={0.5} />
                </mesh>
                <mesh position={[-0.7, -0.9, 0]} rotation={[0, 0, 0.35]} castShadow>
                  <cylinderGeometry args={[0.15, 0.17, 1.9, 12]} />
                  <meshStandardMaterial color="#f8fafc" roughness={0.5} />
                </mesh>
              </group>
            </>
          )}
          {joint === "elbow" && (
            <>
              <mesh position={[-0.6, 2.6, 0]} castShadow>
                <cylinderGeometry args={[0.2, 0.22, 1.6, 14]} />
                <meshStandardMaterial color="#cbd5e1" roughness={0.5} />
              </mesh>
              <group ref={ball} position={[0.5, 2.2, 0]}>
                <mesh castShadow>
                  <sphereGeometry args={[0.3, 18, 14]} />
                  <meshStandardMaterial color="#f8fafc" roughness={0.5} />
                </mesh>
                <mesh position={[0.35, -0.8, 0]} rotation={[0, 0, -0.25]} castShadow>
                  <cylinderGeometry args={[0.13, 0.14, 1.6, 12]} />
                  <meshStandardMaterial color="#f8fafc" roughness={0.5} />
                </mesh>
              </group>
            </>
          )}
          {joint === "hip" && (
            <>
              <mesh position={[-0.5, 3.4, -0.2]} scale={[1.3, 1, 1]} castShadow>
                <sphereGeometry args={[0.7, 20, 14]} />
                <meshStandardMaterial color="#cbd5e1" roughness={0.5} />
              </mesh>
              <mesh position={[0.35, 3.3, 0.1]} castShadow>
                <sphereGeometry args={[0.42, 18, 14, 0, Math.PI * 2, 0, Math.PI / 2]} />
                <meshStandardMaterial color="#94a3b8" roughness={0.5} side={THREE.DoubleSide} />
              </mesh>
              <group ref={ball} position={[0.6, 3.2, 0.3]}>
                <mesh castShadow>
                  <sphereGeometry args={[0.32, 18, 14]} />
                  <meshStandardMaterial color="#f8fafc" roughness={0.5} />
                </mesh>
                <mesh position={[0.35, -1.0, 0]} rotation={[0, 0, -0.2]} castShadow>
                  <cylinderGeometry args={[0.18, 0.2, 2.0, 12]} />
                  <meshStandardMaterial color="#f8fafc" roughness={0.5} />
                </mesh>
              </group>
            </>
          )}
          <mesh ref={warn} position={[0, 4.6, 0]} visible={false}>
            <sphereGeometry args={[0.22, 12, 10]} />
            <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={1.4} />
          </mesh>
          <Label text="Socket" position={[1.9, 3.9, -0.3]} size={0.5} color="#cbd5e1" />
          <Label text="Ball (dislocates!)" position={[-2.6, 2.6, 0.2]} size={0.55} color="#f8fafc" />
          <Label text="⚠ POP — out of socket" position={[0, 0.7, 0]} size={0.6} color="#fca5a5" />
        </group>
        <Animator group={group} ball={ball} warn={warn} elapsed={elapsed} speed={speed} joint={joint} />
      </SimCanvas>
    </div>
  );
}
