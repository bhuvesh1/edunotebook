// app/components/sims/unique/Topic10507Sim.tsx
// Salivary gland surgery basics: side-profile head showing the three major
// salivary glands — parotid, submandibular, sublingual — with their ducts.
// Selecting a gland highlights it and its duct.

"use client";

import { useRef, type ReactNode, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "gland", label: "Gland", kind: "select", min: 0, max: 0, step: 1, default: "parotid", options: ["parotid", "submandibular", "sublingual"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Salivary Gland Surgery Basics",
  blurb: "The three major salivary glands and their ducts light up — pick one to see its surgical anatomy.",
};

function Label({ p, children, size = 0.3, color = "#e2e8f0" }: { p: [number, number, number]; children: ReactNode; size?: number; color?: string }) {
  return (
    <Text position={p} fontSize={size} color={color} anchorX="center" anchorY="middle">
      {children}
    </Text>
  );
}

function Animator({ glands, elapsed, speed, active }: {
  glands: RefObject<THREE.Group>[];
  elapsed: RefObject<number>; speed: number; active: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    glands.forEach((g, i) => {
      if (!g.current) return;
      const on = i === active;
      const s = on ? 1.15 + 0.1 * Math.sin(elapsed.current * 3) : 0.9;
      g.current.scale.setScalar(s);
      g.current.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.isMesh) {
          const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
          mat.emissiveIntensity = on ? 0.9 + 0.3 * Math.sin(elapsed.current * 3) : 0.15;
        }
      });
    });
  });
  return null;
}

const SKIN = "#f0b98d";
const GLAND = "#fbbf24";

const INFO: Record<string, { duct: string; nerve: string }> = {
  parotid: { duct: "Stensen's duct → cheek", nerve: "facial nerve (CN VII) runs through it" },
  submandibular: { duct: "Wharton's duct → floor of mouth", nerve: "marginal mandibular branch nearby" },
  sublingual: { duct: "many tiny ducts → floor of mouth", nerve: "lingual nerve close by" },
};

export function Topic10507Sim(props: SimProps) {
  const gland = String(props.gland ?? "parotid");
  const speed = Number(props.speed ?? 1);
  const order = ["parotid", "submandibular", "sublingual"];
  const active = Math.max(order.indexOf(gland), 0);
  const g0 = useRef<THREE.Group>(null!);
  const g1 = useRef<THREE.Group>(null!);
  const g2 = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const info = INFO[gland];

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Gland", gland],
          ["Duct", info.duct],
          ["Watch out", info.nerve],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 12]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* side-profile head facing +x */}
        <mesh position={[-0.2, 3.4, 0]} castShadow>
          <sphereGeometry args={[1.5, 32, 32]} />
          <meshStandardMaterial color={SKIN} roughness={0.7} />
        </mesh>
        {/* face / snout toward +x */}
        <mesh position={[0.9, 2.9, 0]} castShadow>
          <boxGeometry args={[1.1, 1.3, 1.5]} />
          <meshStandardMaterial color={SKIN} roughness={0.7} />
        </mesh>
        {/* nose */}
        <mesh position={[1.55, 3.15, 0]} castShadow>
          <coneGeometry args={[0.22, 0.5, 12]} />
          <meshStandardMaterial color={SKIN} roughness={0.7} />
        </mesh>
        {/* neck */}
        <mesh position={[-0.4, 1.2, 0]} castShadow>
          <cylinderGeometry args={[0.8, 0.95, 1.8, 20]} />
          <meshStandardMaterial color={SKIN} roughness={0.7} />
        </mesh>
        {/* ear */}
        <mesh position={[-1.15, 3.5, 0]} castShadow>
          <torusGeometry args={[0.28, 0.12, 10, 20]} />
          <meshStandardMaterial color={SKIN} roughness={0.7} />
        </mesh>

        {/* PAROTID: in front of / below the ear */}
        <group ref={g0}>
          <mesh position={[-0.85, 2.9, 0.55]} castShadow>
            <sphereGeometry args={[0.55, 24, 24]} />
            <meshStandardMaterial color={GLAND} emissive={GLAND} emissiveIntensity={0.5} roughness={0.4} />
          </mesh>
          {/* Stensen's duct to cheek */}
          <mesh position={[0.15, 3.05, 0.55]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.07, 0.07, 1.4, 10]} />
            <meshStandardMaterial color={GLAND} emissive={GLAND} emissiveIntensity={0.5} roughness={0.4} />
          </mesh>
        </group>
        {/* SUBMANDIBULAR: below the jaw */}
        <group ref={g1}>
          <mesh position={[-0.1, 1.95, 0.5]} castShadow>
            <sphereGeometry args={[0.45, 24, 24]} />
            <meshStandardMaterial color={GLAND} emissive={GLAND} emissiveIntensity={0.5} roughness={0.4} />
          </mesh>
          {/* Wharton's duct curving up to floor of mouth */}
          <mesh position={[0.45, 2.25, 0.5]} rotation={[0, 0, -0.9]}>
            <cylinderGeometry args={[0.06, 0.06, 1.1, 10]} />
            <meshStandardMaterial color={GLAND} emissive={GLAND} emissiveIntensity={0.5} roughness={0.4} />
          </mesh>
        </group>
        {/* SUBLINGUAL: under the tongue */}
        <group ref={g2}>
          <mesh position={[0.75, 2.35, 0.35]} castShadow>
            <sphereGeometry args={[0.32, 20, 20]} />
            <meshStandardMaterial color={GLAND} emissive={GLAND} emissiveIntensity={0.5} roughness={0.4} />
          </mesh>
        </group>

        <Label p={[-0.85, 2.05, 0.9]} size={0.28} color="#fde68a">parotid</Label>
        <Label p={[-0.1, 1.25, 0.9]} size={0.28} color="#fde68a">submandibular</Label>
        <Label p={[0.75, 1.85, 0.7]} size={0.26} color="#fde68a">sublingual</Label>
        <Label p={[2.6, 4.6, 0]} size={0.3} color="#e2e8f0">major salivary glands</Label>

        <Animator glands={[g0, g1, g2]} elapsed={elapsed} speed={speed} active={active} />
      </SimCanvas>
    </div>
  );
}
