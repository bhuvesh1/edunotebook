"use client";
// Health planning and management, health economics basics.
// Three meshing gears turn the planning cycle: plan → implement →
// evaluate, while coins drop into a health budget jar.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Planning stage", kind: "select", min: 0, max: 0, step: 1, default: "plan", options: ["plan", "implement", "evaluate"] },
  { key: "speed", label: "Gear speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Health Planning & Management Cycle",
  blurb: "Three gears turn the planning cycle — plan, implement, evaluate — while the budget jar fills coin by coin.",
};

const STAGES = [
  { key: "plan", name: "PLAN", color: "#38bdf8", x: -4.2, desc: "Set goals, count resources" },
  { key: "implement", name: "IMPLEMENT", color: "#4ade80", x: 0, desc: "Run programs on the ground" },
  { key: "evaluate", name: "EVALUATE", color: "#fbbf24", x: 4.2, desc: "Measure: did it work?" },
];

function Gear({ x, color, gearRef, active }: { x: number; color: string; gearRef?: React.RefObject<THREE.Group>; active: boolean }) {
  return (
    <group position={[x, 2.2, 0]}>
      <group ref={gearRef}>
        <mesh castShadow>
          <cylinderGeometry args={[1, 1, 0.35, 12]} />
          <meshStandardMaterial color={color} roughness={0.5} metalness={0.3} emissive={color} emissiveIntensity={active ? 0.4 : 0} />
        </mesh>
        {Array.from({ length: 8 }, (_, i) => {
          const a = (i / 8) * Math.PI * 2;
          return (
            <mesh key={i} position={[Math.cos(a) * 1.1, Math.sin(a) * 1.1, 0]} rotation={[0, 0, a]}>
              <boxGeometry args={[0.35, 0.35, 0.35]} />
              <meshStandardMaterial color={color} roughness={0.5} metalness={0.3} />
            </mesh>
          );
        })}
        <mesh>
          <cylinderGeometry args={[0.3, 0.3, 0.45, 12]} />
          <meshStandardMaterial color="#0f172a" roughness={0.6} />
        </mesh>
      </group>
    </group>
  );
}

function Animator({ g1, g2, g3, coins, elapsed, speed }: { g1: React.RefObject<THREE.Group>; g2: React.RefObject<THREE.Group>; g3: React.RefObject<THREE.Group>; coins: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g1.current) g1.current.rotation.z = elapsed.current * 0.9;
    if (g2.current) g2.current.rotation.z = -elapsed.current * 0.9;
    if (g3.current) g3.current.rotation.z = elapsed.current * 0.9;
    if (coins.current) {
      coins.current.children.forEach((c, i) => {
        const ph = (elapsed.current * 0.5 + i * 0.2) % 1;
        c.position.y = 5.4 - ph * 3.6;
        c.visible = ph < 0.85;
      });
    }
  });
  return null;
}

export function Topic10181Sim(props: SimProps) {
  const stage = String(props.stage ?? "plan");
  const speed = Number(props.speed ?? 1);
  const g1 = useRef<THREE.Group>(null!);
  const g2 = useRef<THREE.Group>(null!);
  const g3 = useRef<THREE.Group>(null!);
  const coins = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const activeStage = STAGES.find((s) => s.key === stage) ?? STAGES[0];

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Stage", activeStage.name], ["Means", activeStage.desc]]} />
      <SimCanvas cameraPosition={[0, 3.8, 14]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Gear x={-4.2} color="#38bdf8" gearRef={g1} active={stage === "plan"} />
        <Gear x={0} color="#4ade80" gearRef={g2} active={stage === "implement"} />
        <Gear x={4.2} color="#fbbf24" gearRef={g3} active={stage === "evaluate"} />
        {STAGES.map((s) => (
          <Label key={s.key} text={s.name} position={[s.x, 0.55, 0]} size={0.55} color={stage === s.key ? s.color : "#64748b"} />
        ))}
        <Arrow from={[-2.6, 2.2, 0]} to={[-1.6, 2.2, 0]} color="#e2e8f0" />
        <Arrow from={[1.6, 2.2, 0]} to={[2.6, 2.2, 0]} color="#e2e8f0" />
        {/* budget jar with falling coins */}
        <group position={[0, 0, -4.2]}>
          <mesh position={[0, 1, 0]}>
            <cylinderGeometry args={[1, 0.85, 1.8, 16, 1, true]} />
            <meshStandardMaterial color="#e2e8f0" transparent opacity={0.35} roughness={0.15} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[0, 0.5, 0]}>
            <cylinderGeometry args={[0.8, 0.75, 0.7, 16]} />
            <meshStandardMaterial color="#fbbf24" transparent opacity={0.85} roughness={0.35} />
          </mesh>
          <group ref={coins}>
            {[0, 1, 2, 3, 4].map((i) => (
              <mesh key={i} position={[0, 5.4 - i * 0.7, 0]} rotation={[Math.PI / 2, 0, 0]}>
                <cylinderGeometry args={[0.28, 0.28, 0.08, 14]} />
                <meshStandardMaterial color="#fde68a" metalness={0.7} roughness={0.3} />
              </mesh>
            ))}
          </group>
          <Label text="HEALTH BUDGET" position={[0, 6, 0]} size={0.55} color="#fde68a" />
        </group>
        <Animator g1={g1} g2={g2} g3={g3} coins={coins} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
