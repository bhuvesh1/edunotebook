// Blood: RBC, hemoglobin, anemia — biconcave red blood cells stream through a
// vessel; hemoglobin tetramers carry O2; toggle anemia to see pale, sparse cells.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "hct", label: "Hematocrit (RBC count)", kind: "slider", min: 0.2, max: 1.5, step: 0.05, default: 1, unit: "×" },
  { key: "anemia", label: "Anemia", kind: "select", min: 0, max: 0, step: 1, default: "off", options: ["off", "on"] },
];

export const UNIQUE_META = {
  title: "Blood: RBCs & Hemoglobin",
  blurb: "Biconcave red cells flow through the vessel carrying hemoglobin — flip on anemia to see pale, sparse cells.",
};

function Animator({
  rbcs, hb, o2, elapsed, speed,
}: {
  rbcs: React.RefObject<THREE.Group>;
  hb: React.RefObject<THREE.Group>;
  o2: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (rbcs.current) {
      rbcs.current.children.forEach((m, i) => {
        const ph = ((t * 0.22 + i / 16) % 1 + 1) % 1;
        m.position.x = -5.5 + ph * 11;
        m.position.y = 2 + Math.sin(t * 2.5 + i * 1.8) * 0.35 * (1 - Math.abs(m.position.x) / 7);
        m.rotation.y += delta * 1.5;
      });
    }
    if (hb.current) hb.current.rotation.y = t * 0.8;
    if (o2.current) {
      o2.current.children.forEach((m, i) => {
        m.position.y = 1 + Math.sin(t * 4 + i * 1.6) * 0.35;
        m.position.x = Math.cos(t * 4 + i * 1.6) * 0.35;
      });
    }
  });
  return null;
}

export function Topic10033Sim(props: SimProps) {
  const hct = Number(props.hct ?? 1);
  const anemic = String(props.anemia ?? "off") === "on";
  const speed = 1;
  const rbcs = useRef<THREE.Group>(null!);
  const hb = useRef<THREE.Group>(null!);
  const o2 = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const visibleCount = Math.max(2, Math.round(16 * hct * (anemic ? 0.45 : 1)));
  const rbcColor = anemic ? "#fca5a5" : "#dc2626";

  const hbChains = useMemo(
    () =>
      [
        { p: [0.35, 0, 0] as [number, number, number], c: "#f87171" },
        { p: [-0.35, 0, 0] as [number, number, number], c: "#f87171" },
        { p: [0, 0.35, 0.15] as [number, number, number], c: "#60a5fa" },
        { p: [0, -0.35, -0.15] as [number, number, number], c: "#60a5fa" },
      ],
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["RBCs", anemic ? "low, pale (hypochromic)" : "normal biconcave discs"],
          ["Hemoglobin", anemic ? "↓ Hb" : "140 g/L ✓"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[38, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* blood vessel */}
        <mesh position={[0, 2, -0.4]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[1.6, 1.6, 11.6, 24, 1, true]} />
          <meshStandardMaterial color="#991b1b" roughness={0.5} side={THREE.DoubleSide} transparent opacity={0.55} />
        </mesh>
        {/* RBCs: biconcave discs (squashed spheres) */}
        <group ref={rbcs}>
          {Array.from({ length: 16 }).map((_, i) => (
            <mesh key={i} position={[-5.5, 2, 0]} scale={[1, 0.4, 1]}
              visible={i < visibleCount} castShadow>
              <sphereGeometry args={[0.32, 16, 16]} />
              <meshStandardMaterial color={rbcColor} roughness={0.4} />
            </mesh>
          ))}
        </group>
        <Label text="red blood cells (biconcave)" position={[0, 4.4, 0]} size={0.4} color="#f8fafc" />
        <Label text={anemic ? "anemia: pale & few" : "healthy RBC stream"} position={[0, -0.1, 0]} size={0.34} color={anemic ? "#fca5a5" : "#fca5a5"} />

        {/* hemoglobin tetramer: 2 alpha + 2 beta chains with heme dots */}
        <group position={[6.6, 2.0, 0]}>
          <group ref={hb}>
            {hbChains.map((ch, i) => (
              <group key={i} position={ch.p}>
                <mesh castShadow>
                  <sphereGeometry args={[0.42, 14, 14]} />
                  <meshStandardMaterial color={ch.c} roughness={0.45} />
                </mesh>
                <mesh>
                  <sphereGeometry args={[0.14, 8, 8]} />
                  <meshStandardMaterial color="#7c2d12" />
                </mesh>
              </group>
            ))}
          </group>
          {/* bound O2 molecules */}
          <group ref={o2}>
            {hbChains.map((ch, i) => (
              <mesh key={i} position={[ch.p[0], 1 + ch.p[1], ch.p[2]]}>
                <sphereGeometry args={[0.13, 8, 8]} />
                <meshBasicMaterial color="#bae6fd" />
              </mesh>
            ))}
          </group>
        </group>
        <Label text="hemoglobin (α₂β₂)" position={[6.6, 3.9, 0]} size={0.4} color="#f8fafc" />
        <Label text="α chains (red)" position={[8.2, 2.6, 0]} size={0.3} color="#fca5a5" />
        <Label text="β chains (blue)" position={[8.2, 1.5, 0]} size={0.3} color="#93c5fd" />
        <Label text="O₂ bound to heme" position={[6.6, 0.4, 0]} size={0.3} color="#bae6fd" />

        <Animator rbcs={rbcs} hb={hb} o2={o2} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
