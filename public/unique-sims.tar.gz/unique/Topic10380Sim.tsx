"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "mtype", label: "Mucosa type", kind: "select", min: 0, max: 0, step: 1, default: "masticatory", options: ["masticatory", "lining", "specialized"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Oral mucosa: masticatory, lining, specialized",
  blurb: "Three linings of the mouth in one scene — tough keratinized gum, soft stretchy cheek, and the bumpy taste-bud tongue.",
};

const INFO: Record<string, { name: string; note: string; demo: string }> = {
  masticatory: { name: "Masticatory mucosa", note: "keratinized, tough — gum + hard palate", demo: "gum" },
  lining: { name: "Lining mucosa", note: "non-keratinized, stretchy — cheek, lips, floor", demo: "cheek" },
  specialized: { name: "Specialized mucosa", note: "taste buds live here — dorsum of tongue", demo: "tongue" },
};

function MucosaScene({ mtype, speed, showLabels }: { mtype: string; speed: number; showLabels: boolean }) {
  const g = useRef<THREE.Group>(null!);
  const cheek = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const info = INFO[mtype] ?? INFO.masticatory;

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (g.current) g.current.rotation.y = Math.sin(elapsed.current * 0.25) * 0.12;
    if (cheek.current) {
      // lining mucosa stretches
      const s = 1 + Math.sin(elapsed.current * 1.8) * 0.06;
      cheek.current.scale.set(s, 2 - s > 0 ? 1 / s : 1, 1);
    }
  });

  const hi = (name: string) => (mtype === name ? 1.3 : 1);

  return (
    <group ref={g}>
      {/* GUM — masticatory */}
      <group position={[-4.5, 0, 0]} scale={hi("masticatory")}>
        {[0, 1, 2].map((i) => (
          <mesh key={i} position={[-1.1 + i * 1.1, 0.4, 0]} castShadow>
            <boxGeometry args={[1, 1.1, 0.9]} />
            <meshStandardMaterial color="#fef9c3" roughness={0.25} />
          </mesh>
        ))}
        <mesh position={[0, -0.7, 0]} castShadow>
          <boxGeometry args={[3.6, 1.1, 1.4]} />
          <meshStandardMaterial color={mtype === "masticatory" ? "#f472b6" : "#e88ca0"} roughness={0.45} emissive={mtype === "masticatory" ? "#831843" : "#000000"} emissiveIntensity={0.4} />
        </mesh>
        {/* keratin layer sheen */}
        <mesh position={[0, -0.1, 0]}>
          <boxGeometry args={[3.6, 0.08, 1.4]} />
          <meshStandardMaterial color="#fdf2f8" transparent opacity={0.7} roughness={0.15} />
        </mesh>
        {showLabels && <Text position={[0, 2.2, 0]} fontSize={0.44} color="#f9a8d4">Gum — keratinized</Text>}
      </group>

      {/* CHEEK — lining */}
      <group position={[0, 0, 0]} scale={hi("lining")}>
        <mesh ref={cheek} castShadow>
          <sphereGeometry args={[1.9, 28, 20]} />
          <meshStandardMaterial color={mtype === "lining" ? "#fb7185" : "#fda4af"} roughness={0.35} emissive={mtype === "lining" ? "#881337" : "#000000"} emissiveIntensity={0.35} />
        </mesh>
        {/* submucosa ripple */}
        <mesh position={[0, 0, 0]}>
          <sphereGeometry args={[1.7, 20, 14]} />
          <meshBasicMaterial color="#fecdd3" transparent opacity={0.25} wireframe />
        </mesh>
        {showLabels && <Text position={[0, 2.9, 0]} fontSize={0.44} color="#fda4af">Cheek — soft & stretchy</Text>}
      </group>

      {/* TONGUE — specialized */}
      <group position={[4.5, -0.4, 0]} scale={hi("specialized")}>
        <mesh position={[0, 0, 0]} scale={[1.6, 0.55, 1]} castShadow>
          <sphereGeometry args={[1.3, 24, 16]} />
          <meshStandardMaterial color={mtype === "specialized" ? "#ef4444" : "#f87171"} roughness={0.5} emissive={mtype === "specialized" ? "#7f1d1d" : "#000000"} emissiveIntensity={0.3} />
        </mesh>
        {/* papillae bumps */}
        {Array.from({ length: 18 }).map((_, i) => {
          const a = (i / 18) * Math.PI * 2;
          const r = 0.5 + (i % 4) * 0.32;
          return (
            <mesh key={i} position={[Math.cos(a) * r * 1.5, 0.62, Math.sin(a) * r * 0.9]} castShadow>
              <sphereGeometry args={[0.14, 10, 8]} />
              <meshStandardMaterial color="#fecaca" roughness={0.5} />
            </mesh>
          );
        })}
        {/* taste bud dots */}
        {Array.from({ length: 8 }).map((_, i) => (
          <mesh key={"t" + i} position={[(i % 4 - 1.5) * 0.7, 0.78, (Math.floor(i / 4) - 0.5) * 0.8]}>
            <sphereGeometry args={[0.07, 8, 8]} />
            <meshBasicMaterial color="#fde68a" />
          </mesh>
        ))}
        {showLabels && <Text position={[0, 2.2, 0]} fontSize={0.44} color="#fca5a5">Tongue — papillae + taste buds</Text>}
      </group>

      {showLabels && (
        <Text position={[0, -3.6, 0]} fontSize={0.44} color="#fef3c7" maxWidth={11}>{info.name}: {info.note}</Text>
      )}
    </group>
  );
}

export function Topic10380Sim(props: SimProps) {
  const mtype = String(props.mtype ?? "masticatory");
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const info = INFO[mtype] ?? INFO.masticatory;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Mucosa", info.name],
          ["Keratin", mtype === "lining" ? "none" : "yes"],
          ["Where", info.note.split("—")[1]?.trim() ?? ""],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 13]} target={[0, 0, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.4, 0]} receiveShadow>
          <planeGeometry args={[36, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <MucosaScene mtype={mtype} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
