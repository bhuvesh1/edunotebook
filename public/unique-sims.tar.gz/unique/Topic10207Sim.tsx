// Eyelid disorders — a stye (small red painful bump on the lid edge), a
// chalazion (bigger painless lump deeper in the lid), blepharitis (crusty red
// lid margin), and ptosis (the lid droops — slider lowers it).
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ptosis", label: "Ptosis (lid droop)", kind: "slider", min: 0, max: 100, step: 5, default: 45, unit: "%" },
  { key: "lump", label: "Lump type", kind: "select", min: 0, max: 0, step: 1, default: "stye", options: ["stye", "chalazion", "blepharitis"] },
];

export const UNIQUE_META = {
  title: "Eyelid Disorders",
  blurb: "Stye vs chalazion vs blepharitis on the lid margin — plus a ptosis slider that droops the lid over the eye.",
};

function Animator({ lumps, lid, elapsed, ptosis }: {
  lumps: React.RefObject<THREE.Group>;
  lid: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  ptosis: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (lumps.current) {
      // stye throbs (it's painful); chalazion sits still
      lumps.current.children.forEach((c, i) => {
        c.scale.setScalar(1 + 0.1 * Math.sin(t * 5 + i * 2));
      });
    }
    if (lid.current) {
      const target = -(ptosis / 100) * 1.05;
      lid.current.position.y += (target - lid.current.position.y) * Math.min(1, delta * 5);
    }
  });
  return null;
}

export function Topic10207Sim(props: SimProps) {
  const ptosis = Number(props.ptosis ?? 45);
  const lump = String(props.lump ?? "stye");
  const lumps = useRef<THREE.Group>(null!);
  const lid = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const droopY = -(ptosis / 100) * 1.05;
  const visionBlocked = ptosis > 65;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Lump", lump], ["Ptosis", `${ptosis}%`], ["Vision", visionBlocked ? "lid blocks pupil ⚠" : "clear"]]} />
      <SimCanvas cameraPosition={[0, 2.4, 9.5]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* eyeball */}
        <mesh position={[0, 1.2, 0]} castShadow>
          <sphereGeometry args={[1.9, 36, 26]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.35} />
        </mesh>
        <mesh position={[1.88, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.6, 0.28, 14, 32]} />
          <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
        </mesh>
        <mesh position={[1.86, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <circleGeometry args={[0.34, 24]} />
          <meshStandardMaterial color="#020617" roughness={0.9} />
        </mesh>

        {/* upper eyelid (droops with ptosis) */}
        <group ref={lid} position={[0, 0, 0]}>
          <mesh position={[0.4, 3.35, 0]} rotation={[0, 0, -0.28]} castShadow>
            <boxGeometry args={[3.4, 0.65, 2.9]} />
            <meshStandardMaterial color="#f5d0b8" roughness={0.6} />
          </mesh>
          {/* lid margin: lashes */}
          {Array.from({ length: 9 }).map((_, i) => (
            <mesh key={i} position={[-0.15 + i * 0.14, 2.98 - i * 0.045, 1.28 - Math.abs(i - 4) * 0.06]} rotation={[0.5, 0, -0.3]}>
              <cylinderGeometry args={[0.025, 0.01, 0.5, 6]} />
              <meshStandardMaterial color="#1c1917" roughness={0.8} />
            </mesh>
          ))}
        </group>

        {/* the lump, riding on the lid */}
        <group ref={lumps} position={[0, droopY, 0]}>
          {lump === "stye" && (
            <mesh position={[0.55, 3.05, 1.15]}>
              <sphereGeometry args={[0.3, 16, 14]} />
              <meshStandardMaterial color="#dc2626" roughness={0.5} emissive="#991b1b" emissiveIntensity={0.55} />
            </mesh>
          )}
          {lump === "chalazion" && (
            <mesh position={[0.35, 3.2, 1.1]} scale={[1.3, 0.8, 1]}>
              <sphereGeometry args={[0.42, 16, 14]} />
              <meshStandardMaterial color="#fca5a5" roughness={0.6} />
            </mesh>
          )}
          {lump === "blepharitis" && (
            <group>
              {Array.from({ length: 8 }).map((_, i) => (
                <mesh key={i} position={[-0.1 + i * 0.13, 2.95 - i * 0.04, 1.3]}>
                  <boxGeometry args={[0.1, 0.06, 0.12]} />
                  <meshStandardMaterial color="#fde68a" roughness={0.9} emissive="#a16207" emissiveIntensity={0.3} />
                </mesh>
              ))}
              <mesh position={[0.4, 3.1, 1.15]} rotation={[0, 0, -0.28]}>
                <boxGeometry args={[2.6, 0.16, 0.2]} />
                <meshStandardMaterial color="#ef4444" roughness={0.6} emissive="#7f1d1d" emissiveIntensity={0.5} />
              </mesh>
            </group>
          )}
        </group>

        <Label text={lump === "stye" ? "Stye — red, painful bump" : lump === "chalazion" ? "Chalazion — firm painless lump" : "Blepharitis — crusty red lid margin"} position={[-3.4, 4.2, 0]} size={0.5} color="#fca5a5" />
        <Label text={`Ptosis ${ptosis}% — ${visionBlocked ? "lid covers the pupil ⚠" : "lid above the pupil"}`} position={[3.2, 4.2, 0]} size={0.5} color={visionBlocked ? "#fca5a5" : "#86efac"} />
        <Animator lumps={lumps} lid={lid} elapsed={elapsed} ptosis={ptosis} />
      </SimCanvas>
    </div>
  );
}
