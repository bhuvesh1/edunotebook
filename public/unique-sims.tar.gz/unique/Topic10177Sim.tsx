"use client";
// National health programs: NHM, UIP/immunization, NTEP (TB).
// Pick a program: a syringe plunges for immunization, lungs breathe for
// the TB program, and a health-mission badge spins for NHM.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "program", label: "Program", kind: "select", min: 0, max: 0, step: 1, default: "uip", options: ["nhm", "uip", "ntep"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "National Health Programs: NHM, Immunization, TB",
  blurb: "Three national missions on one stage — pick one and watch its symbol come alive: the syringe, the lungs, or the mission badge.",
};

const PROG_TXT: Record<string, string> = {
  nhm: "NHM: health care for every village",
  uip: "UIP: free vaccines for every child",
  ntep: "NTEP: TB treatment, free & complete",
};

function Animator({ plunger, lungs, badge, elapsed, speed, program }: { plunger: React.RefObject<THREE.Group>; lungs: React.RefObject<THREE.Group>; badge: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number; program: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (plunger.current) {
      plunger.current.position.y = program === "uip" ? -0.35 - Math.abs(Math.sin(t * 1.6)) * 0.5 : -0.35;
    }
    if (lungs.current) {
      const b = program === "ntep" ? 1 + Math.sin(t * 3.2) * 0.12 : 1;
      lungs.current.scale.set(b, b, b);
    }
    if (badge.current) badge.current.rotation.y = t * (program === "nhm" ? 1.2 : 0.25);
  });
  return null;
}

export function Topic10177Sim(props: SimProps) {
  const program = String(props.program ?? "uip");
  const speed = Number(props.speed ?? 1);
  const plunger = useRef<THREE.Group>(null!);
  const lungs = useRef<THREE.Group>(null!);
  const badge = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const active = (k: string) => (program === k ? 1 : 0.25);

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Program", program.toUpperCase()], ["Mission", PROG_TXT[program] ?? ""]]} />
      <SimCanvas cameraPosition={[0, 3.4, 14]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* UIP: syringe + vial */}
        <group position={[-4.6, 0, 0]} scale={[active("uip"), active("uip"), active("uip")]}>
          <mesh position={[0, 2.2, 0]} rotation={[0, 0, 0.35]} castShadow>
            <cylinderGeometry args={[0.35, 0.35, 2.4, 14, 1, true]} />
            <meshStandardMaterial color="#e2e8f0" transparent opacity={0.45} roughness={0.15} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[0.42, 2.05, 0]} rotation={[0, 0, 0.35]}>
            <cylinderGeometry args={[0.28, 0.28, 1.2, 14]} />
            <meshStandardMaterial color="#38bdf8" transparent opacity={0.9} roughness={0.3} />
          </mesh>
          <group ref={plunger} position={[0, 0, 0]}>
            <mesh position={[-0.42, 3.05, 0]} rotation={[0, 0, 0.35]}>
              <cylinderGeometry args={[0.08, 0.08, 0.9, 8]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.6} roughness={0.4} />
            </mesh>
          </group>
          <mesh position={[0.85, 1.05, 0]} rotation={[0, 0, 0.35]}>
            <cylinderGeometry args={[0.03, 0.008, 0.9, 6]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.3} />
          </mesh>
          <mesh position={[-1.8, 1.2, 0]} castShadow>
            <cylinderGeometry args={[0.45, 0.45, 1.1, 12]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.5} />
          </mesh>
          <mesh position={[-1.8, 1.85, 0]}>
            <cylinderGeometry args={[0.48, 0.48, 0.18, 12]} />
            <meshStandardMaterial color="#ef4444" roughness={0.6} />
          </mesh>
          <Label text="UIP: VACCINES" position={[0, 4.4, 0]} size={0.6} color={program === "uip" ? "#7dd3fc" : "#64748b"} />
        </group>
        {/* NTEP: lungs */}
        <group position={[0, 0, 0]} scale={[active("ntep"), active("ntep"), active("ntep")]}>
          <group ref={lungs}>
            {[-0.9, 0.9].map((x) => (
              <mesh key={x} position={[x, 2.4, 0]} castShadow>
                <sphereGeometry args={[0.85, 18, 18]} />
                <meshStandardMaterial color="#f9a8d4" roughness={0.55} />
              </mesh>
            ))}
            <mesh position={[0, 3.4, 0]}>
              <cylinderGeometry args={[0.28, 0.34, 1.4, 12]} />
              <meshStandardMaterial color="#fbcfe8" roughness={0.6} />
            </mesh>
          </group>
          <Label text="NTEP: TB-FREE LUNGS" position={[0, 4.6, 0]} size={0.6} color={program === "ntep" ? "#f9a8d4" : "#64748b"} />
        </group>
        {/* NHM: mission badge */}
        <group position={[4.6, 2.4, 0]} scale={[active("nhm"), active("nhm"), active("nhm")]}>
          <group ref={badge}>
            <mesh castShadow>
              <cylinderGeometry args={[1.3, 1.3, 0.25, 6]} />
              <meshStandardMaterial color="#f59e0b" metalness={0.5} roughness={0.35} />
            </mesh>
            <mesh position={[0, 0, 0.14]}>
              <boxGeometry args={[0.7, 0.24, 0.04]} />
              <meshStandardMaterial color="#ffffff" roughness={0.5} />
            </mesh>
            <mesh position={[0, 0, 0.14]}>
              <boxGeometry args={[0.24, 0.7, 0.04]} />
              <meshStandardMaterial color="#ffffff" roughness={0.5} />
            </mesh>
          </group>
          <Label text="NHM: HEALTH MISSION" position={[0, 2.2, 0]} size={0.6} color={program === "nhm" ? "#fbbf24" : "#64748b"} />
        </group>
        <Animator plunger={plunger} lungs={lungs} badge={badge} elapsed={elapsed} speed={speed} program={program} />
      </SimCanvas>
    </div>
  );
}
