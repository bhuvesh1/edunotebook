// Embryology: gastrulation, neurulation, fetal membranes — a trilaminar disc
// (ectoderm/mesoderm/endoderm) whose neural folds rise and zip shut into the
// neural tube, wrapped by the amnion.
"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "closure", label: "Neural fold closure", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.7, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Embryology: Gastrulation & Neurulation",
  blurb: "Three germ layers form the trilaminar disc, then neural folds rise and fuse into the neural tube.",
};

function Animator({
  folds, groove, amnion, elapsed, speed,
}: {
  folds: React.RefObject<THREE.Group>;
  groove: React.RefObject<THREE.Mesh>;
  amnion: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // gentle pulsing of the whole embryo + shimmering amnion
    if (folds.current) folds.current.position.y = Math.sin(t * 1.6) * 0.08;
    if (groove.current) {
      const mat = groove.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = 0.25 + 0.2 * Math.sin(t * 3);
    }
    if (amnion.current) {
      const mat = amnion.current.material as THREE.MeshStandardMaterial;
      mat.opacity = 0.16 + 0.06 * Math.sin(t * 2.2);
    }
  });
  return null;
}

export function Topic10023Sim(props: SimProps) {
  const closure = Number(props.closure ?? 0.7);
  const speed = Number(props.speed ?? 1);
  const folds = useRef<THREE.Group>(null!);
  const groove = useRef<THREE.Mesh>(null!);
  const amnion = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  // neural folds: two ridges whose angle depends on `closure` (0=open, 1=closed tube)
  const foldAngle = useMemo(() => (1 - closure) * 0.9 + 0.06, [closure]);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Germ layers", "ecto / meso / endoderm"],
          ["Neural tube", closure > 0.85 ? "closed ✓" : closure > 0.3 ? "closing…" : "open groove"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 7, 13]} target={[0, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        <group ref={folds} position={[0, 0, 0]}>
          {/* trilaminar disc: three stacked germ layers */}
          <mesh position={[0, 0.75, 0]} castShadow>
            <cylinderGeometry args={[3.4, 3.4, 0.28, 28]} />
            <meshStandardMaterial color="#38bdf8" roughness={0.5} />
          </mesh>
          <mesh position={[0, 0.47, 0]} castShadow>
            <cylinderGeometry args={[3.4, 3.4, 0.28, 28]} />
            <meshStandardMaterial color="#ef4444" roughness={0.5} />
          </mesh>
          <mesh position={[0, 0.19, 0]} castShadow>
            <cylinderGeometry args={[3.4, 3.4, 0.28, 28]} />
            <meshStandardMaterial color="#facc15" roughness={0.5} />
          </mesh>
          {/* primitive streak */}
          <mesh position={[0, 0.95, -1.2]} rotation={[0, 0, 0]}>
            <boxGeometry args={[0.35, 0.1, 2.4]} />
            <meshStandardMaterial color="#7c3aed" roughness={0.5} />
          </mesh>
          {/* neural groove: glowing channel down the middle */}
          <mesh ref={groove} position={[0, 1.02, 0.6]}>
            <boxGeometry args={[1.5 - closure * 1.2, 0.12, 4.6]} />
            <meshStandardMaterial color="#0ea5e9" emissive="#0369a1" emissiveIntensity={0.3} />
          </mesh>
          {/* neural folds: two ridges rising and closing */}
          {[-1, 1].map((s) => (
            <group key={s} position={[s * (1.05 - closure * 0.62), 0.9, 0.6]} rotation={[0, 0, -s * foldAngle]}>
              <mesh position={[s * 0.55, 0.55, 0]} castShadow>
                <boxGeometry args={[0.9, 1.3, 4.8]} />
                <meshStandardMaterial color="#38bdf8" roughness={0.5} />
              </mesh>
              <mesh position={[s * 0.55, 1.32, 0]}>
                <sphereGeometry args={[0.28, 10, 10]} />
                <meshStandardMaterial color="#7dd3fc" roughness={0.4} />
              </mesh>
            </group>
          ))}
          {/* notochord beneath */}
          <mesh position={[0, 0.62, 0.6]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.14, 0.14, 4.4, 10]} />
            <meshStandardMaterial color="#a21caf" roughness={0.45} />
          </mesh>
        </group>

        {/* amnion: translucent dome over the embryo */}
        <mesh ref={amnion} position={[0, 1.0, 0]}>
          <sphereGeometry args={[5.2, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.52]} />
          <meshStandardMaterial color="#bae6fd" transparent opacity={0.18} roughness={0.2} side={THREE.DoubleSide} />
        </mesh>

        <Label text="ectoderm (blue)" position={[-4.6, 1.6, 0]} size={0.34} color="#7dd3fc" />
        <Label text="mesoderm (red)" position={[-4.6, 1.05, 0]} size={0.34} color="#fca5a5" />
        <Label text="endoderm (yellow)" position={[-4.7, 0.5, 0]} size={0.34} color="#fde68a" />
        <Label text="neural folds" position={[3.4, 3.3, 0.6]} size={0.36} color="#f8fafc" />
        <Label text="neural groove" position={[0, 2.6, 2.9]} size={0.32} color="#7dd3fc" />
        <Label text="notochord" position={[2.2, 0.62, 2.4]} size={0.3} color="#e879f9" />
        <Label text="primitive streak" position={[1.8, 1.15, -2.2]} size={0.3} color="#c4b5fd" />
        <Label text="amnion" position={[-5.9, 4.6, 0]} size={0.34} color="#bae6fd" />

        <Animator folds={folds} groove={groove} amnion={amnion} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
