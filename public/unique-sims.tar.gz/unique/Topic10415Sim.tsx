"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Disease stage", kind: "select", min: 0, max: 0, step: 1, default: "gingivitis", options: ["healthy", "gingivitis", "periodontitis", "advanced"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Oral microbiology: periodontal pathogens, odontogenic infections",
  blurb: "Tooth in its gum socket with a probe measuring the pocket — gums redden, recede and bone melts away as disease advances.",
};

const STAGES: Record<string, { name: string; gum: string; pocket: number; boneLoss: number; bleed: boolean; note: string }> = {
  healthy: { name: "Healthy", gum: "#e0788a", pocket: 2, boneLoss: 0, bleed: false, note: "Pink, firm, 1–3 mm sulcus" },
  gingivitis: { name: "Gingivitis", gum: "#d14a5e", pocket: 3.5, boneLoss: 0, bleed: true, note: "Red, puffy, bleeds — reversible" },
  periodontitis: { name: "Periodontitis", gum: "#b91c1c", pocket: 5.5, boneLoss: 0.8, bleed: true, note: "Pocket deepens, bone starts melting" },
  advanced: { name: "Advanced periodontitis", gum: "#7f1d1d", pocket: 8, boneLoss: 1.7, bleed: true, note: "Deep pockets, loose tooth, pus" },
};

function Scene({ stage, speed }: { stage: string; speed: number }) {
  const t = useRef(0);
  const bleed = useRef<THREE.Group>(null!);
  const st = STAGES[stage] ?? STAGES.gingivitis;

  useFrame((_, delta) => {
    t.current += delta * speed;
    if (bleed.current) {
      bleed.current.children.forEach((c, i) => {
        c.position.y = 1.1 - ((t.current * 0.5 + i * 0.33) % 1.1);
      });
    }
  });

  return (
    <group>
      {/* bone */}
      <mesh position={[0, -1.6 - st.boneLoss * 0.4, 0]} receiveShadow>
        <boxGeometry args={[5, 1.6, 3]} />
        <meshStandardMaterial color="#e3cfae" roughness={0.9} />
      </mesh>
      {/* bone loss craters */}
      {st.boneLoss > 0 && (
        <mesh position={[0.9, -0.9 - st.boneLoss * 0.4, 0.6]}>
          <sphereGeometry args={[0.7 * st.boneLoss, 14, 14]} />
          <meshStandardMaterial color="#8a6d4b" roughness={1} />
        </mesh>
      )}
      {/* gum */}
      <mesh position={[0, -0.15 - st.boneLoss * 0.5, 0]}>
        <boxGeometry args={[5, 1.1, 3]} />
        <meshStandardMaterial color={st.gum} roughness={0.55} />
      </mesh>
      {/* tooth */}
      <group>
        <mesh position={[0, 0.9, 0]}>
          <cylinderGeometry args={[0.5, 0.65, 1.1, 14]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.25} />
        </mesh>
        <mesh position={[0, -0.35, 0]}>
          <coneGeometry args={[0.45, 1.6, 14]} />
          <meshStandardMaterial color="#e8dcc8" roughness={0.45} />
        </mesh>
      </group>
      {/* subgingival plaque */}
      {st.pocket > 3 && (
        <mesh position={[0.55, -0.4, 0]}>
          <boxGeometry args={[0.25, st.pocket * 0.28, 0.6]} />
          <meshStandardMaterial color="#4d7c0f" transparent opacity={0.75} roughness={0.4} />
        </mesh>
      )}
      <Label text="Plaque under gumline" position={[2.2, -0.5, 0]} size={0.42} color="#a3e635" />

      {/* periodontal probe */}
      <group position={[1.35, 0.4, 0.4]} rotation={[0, 0, 0.35]}>
        <mesh position={[0, 0.9, 0]}>
          <cylinderGeometry args={[0.05, 0.02, 2.2, 8]} />
          <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.3} />
        </mesh>
        {[0.3, 0.6, 0.9].map((y, i) => (
          <mesh key={i} position={[0, y, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.055, 0.018, 6, 12]} />
            <meshStandardMaterial color="#111827" roughness={0.6} />
          </mesh>
        ))}
        <Label text={`Pocket: ${st.pocket} mm`} position={[0, 2.3, 0]} size={0.45} color="#7dd3fc" />
      </group>

      {/* bleeding on probing */}
      {st.bleed && (
        <group ref={bleed}>
          {[0, 1, 2].map((i) => (
            <mesh key={i} position={[1.1, 0.6, 0.5]}>
              <sphereGeometry args={[0.09, 10, 10]} />
              <meshStandardMaterial color="#ef4444" roughness={0.3} />
            </mesh>
          ))}
        </group>
      )}
      <Label text={st.name} position={[0, 3.1, 0]} size={0.65} color={st.gum} />
      <Label text={st.note} position={[0, -3.1, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10415Sim(props: SimProps) {
  const stage = String(props.stage ?? "gingivitis");
  const speed = Number(props.speed ?? 1);
  const st = STAGES[stage] ?? STAGES.gingivitis;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Stage", st.name], ["Pocket depth", `${st.pocket} mm`], ["Bone loss", st.boneLoss > 0 ? "Yes" : "No"]]} />
      <SimCanvas cameraPosition={[0, 2.5, 9]} target={[0, -0.3, 0]}>
        <Scene stage={stage} speed={speed} />
      </SimCanvas>
    </div>
  );
}
