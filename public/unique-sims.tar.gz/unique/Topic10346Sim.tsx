"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "modality", label: "Modality", kind: "select", min: 0, max: 0, step: 1, default: "ct", options: ["xray", "ct", "mri", "ultrasound", "nuclear"] },
  { key: "gantry", label: "Gantry speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Imaging physics: X-ray, CT, MRI, ultrasound, nuclear medicine",
  blurb: "One patient, five machines — X-ray tube, spinning CT gantry, MRI magnet, ultrasound probe waves, and gamma-camera tracer dots.",
};

// Patient slab with a simple spine + ribs inside
function Patient() {
  return (
    <group position={[0, 1.1, 0]}>
      <mesh castShadow>
        <boxGeometry args={[1.9, 1.1, 5.2]} />
        <meshPhysicalMaterial color="#f7c9a8" transparent opacity={0.45} roughness={0.4} />
      </mesh>
      {/* spine */}
      {Array.from({ length: 7 }).map((_, i) => (
        <mesh key={i} position={[0, 0.1, -2.1 + i * 0.7]} castShadow>
          <boxGeometry args={[0.45, 0.45, 0.45]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.5} />
        </mesh>
      ))}
      {/* ribs */}
      {[-0.9, 0, 0.9].map((z, i) => (
        <mesh key={i} position={[0, 0.35, z]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.7, 0.08, 8, 20, Math.PI]} />
          <meshStandardMaterial color="#e7e5e4" roughness={0.5} />
        </mesh>
      ))}
    </group>
  );
}

function Machine({ modality, gantry, speed, showLabels }: { modality: string; gantry: number; speed: number; showLabels: boolean }) {
  const spin = useRef<THREE.Group>(null!);
  const wave = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (spin.current) spin.current.rotation.z = elapsed.current * 1.6 * gantry;
    if (wave.current) {
      const s = 1 + ((elapsed.current * 1.2) % 1) * 1.6;
      wave.current.scale.set(s, s, 1);
      (wave.current.material as THREE.MeshBasicMaterial).opacity = 0.55 * (1 - ((elapsed.current * 1.2) % 1));
    }
  });

  const label: Record<string, string> = {
    xray: "X-ray: tube fires, rays hit film",
    ct: "CT: X-ray tube spins, slices stack up",
    mri: "MRI: magnet + radio waves, no radiation",
    ultrasound: "Ultrasound: sound echoes make the picture",
    nuclear: "Nuclear: tracer glows, gamma camera catches it",
  };

  return (
    <group>
      <Patient />
      {modality === "xray" && (
        <group>
          {/* X-ray tube housing above */}
          <mesh position={[0, 5.4, 0]} castShadow>
            <boxGeometry args={[1.6, 1.2, 1.6]} />
            <meshStandardMaterial color="#475569" metalness={0.6} roughness={0.4} />
          </mesh>
          {/* beam cone */}
          <mesh position={[0, 3.2, 0]}>
            <coneGeometry args={[2.2, 3.4, 4, 1, true]} />
            <meshBasicMaterial color="#facc15" transparent opacity={0.18} side={THREE.DoubleSide} />
          </mesh>
          {/* film cassette below */}
          <mesh position={[0, 0.15, 0]}>
            <boxGeometry args={[2.6, 0.12, 5.6]} />
            <meshStandardMaterial color="#1e293b" roughness={0.4} />
          </mesh>
          {showLabels && <Text position={[3.4, 5.4, 0]} fontSize={0.42} color="#facc15">X-ray tube</Text>}
        </group>
      )}
      {modality === "ct" && (
        <group>
          {/* gantry ring */}
          <mesh position={[0, 1.1, 0]} castShadow>
            <torusGeometry args={[2.6, 0.55, 14, 40]} />
            <meshStandardMaterial color="#e2e8f0" metalness={0.5} roughness={0.35} />
          </mesh>
          <group ref={spin} position={[0, 1.1, 0]}>
            {/* tube + detector opposite */}
            <mesh position={[0, 2.6, 0]} castShadow>
              <boxGeometry args={[0.9, 0.7, 0.9]} />
              <meshStandardMaterial color="#f59e0b" roughness={0.4} />
            </mesh>
            <mesh position={[0, -2.6, 0]}>
              <boxGeometry args={[1.4, 0.4, 1.4]} />
              <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
            </mesh>
          </group>
          {/* slice plane highlight */}
          <mesh position={[0, 1.1, 0]} rotation={[0, 0, 0]}>
            <boxGeometry args={[2.4, 1.4, 0.06]} />
            <meshBasicMaterial color="#38bdf8" transparent opacity={0.25} />
          </mesh>
          {showLabels && <Text position={[0, 4.6, 0]} fontSize={0.42} color="#7dd3fc">Spinning tube → slices</Text>}
        </group>
      )}
      {modality === "mri" && (
        <group>
          {/* magnet bore rings */}
          {[0, 1.2, -1.2].map((z, i) => (
            <mesh key={i} position={[0, 1.1, z]} castShadow>
              <torusGeometry args={[2.2, 0.5, 14, 36]} />
              <meshStandardMaterial color={i === 1 ? "#38bdf8" : "#94a3b8"} metalness={0.7} roughness={0.3} emissive={i === 1 ? "#0369a1" : "#000000"} emissiveIntensity={0.6} />
            </mesh>
          ))}
          {/* pulsing B-field rings */}
          <mesh ref={wave} position={[0, 1.1, 0]}>
            <torusGeometry args={[1.4, 0.05, 8, 40]} />
            <meshBasicMaterial color="#38bdf8" transparent opacity={0.5} />
          </mesh>
          {showLabels && <Text position={[0, 4.4, 0]} fontSize={0.42} color="#7dd3fc">Superconducting magnet</Text>}
        </group>
      )}
      {modality === "ultrasound" && (
        <group>
          {/* probe on patient */}
          <group position={[0.2, 2.4, 1.2]} rotation={[0.2, 0, 0.15]}>
            <mesh castShadow>
              <boxGeometry args={[0.7, 1.1, 0.7]} />
              <meshStandardMaterial color="#0ea5e9" roughness={0.35} />
            </mesh>
            <mesh position={[0, -0.7, 0]}>
              <boxGeometry args={[0.55, 0.25, 0.55]} />
              <meshStandardMaterial color="#e0f2fe" roughness={0.2} />
            </mesh>
          </group>
          {/* expanding sound fan */}
          <mesh ref={wave} position={[0.2, 1.6, 1.2]} rotation={[0.2, 0, 0.15]}>
            <coneGeometry args={[1.1, 1.8, 20, 1, true]} />
            <meshBasicMaterial color="#22d3ee" transparent opacity={0.3} side={THREE.DoubleSide} />
          </mesh>
          {showLabels && <Text position={[3, 3.4, 1.2]} fontSize={0.42} color="#67e8f9">Probe sends sound, listens for echoes</Text>}
        </group>
      )}
      {modality === "nuclear" && (
        <group>
          {/* tracer dots glowing inside patient */}
          {Array.from({ length: 14 }).map((_, i) => (
            <mesh key={i} position={[(Math.random() - 0.5) * 1.4, 1.1 + (Math.random() - 0.5) * 0.7, (Math.random() - 0.5) * 4.4]}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshBasicMaterial color="#4ade80" />
            </mesh>
          ))}
          {/* gamma camera head above */}
          <mesh position={[0, 4.6, 0]} castShadow>
            <boxGeometry args={[2.4, 1, 2.4]} />
            <meshStandardMaterial color="#16a34a" metalness={0.5} roughness={0.4} />
          </mesh>
          <mesh position={[0, 3.4, 0]}>
            <coneGeometry args={[1.8, 1.6, 4, 1, true]} />
            <meshBasicMaterial color="#4ade80" transparent opacity={0.15} side={THREE.DoubleSide} />
          </mesh>
          {showLabels && <Text position={[3.4, 4.6, 0]} fontSize={0.42} color="#86efac">Gamma camera catches tracer glow</Text>}
        </group>
      )}
      {showLabels && (
        <Text position={[0, 6.4, 0]} fontSize={0.44} color="#fef3c7" maxWidth={10}>{label[modality]}</Text>
      )}
    </group>
  );
}

export function Topic10346Sim(props: SimProps) {
  const modality = String(props.modality ?? "ct");
  const gantry = Number(props.gantry ?? 1);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const names: Record<string, string> = { xray: "X-ray", ct: "CT", mri: "MRI", ultrasound: "Ultrasound", nuclear: "Nuclear medicine" };
  const energy: Record<string, string> = { xray: "X-rays", ct: "X-rays (rotating)", mri: "Magnetic field + RF", ultrasound: "Sound waves", nuclear: "Gamma rays (tracer)" };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Modality", names[modality] ?? modality],
          ["Uses", energy[modality] ?? ""],
          ["Radiation", modality === "mri" || modality === "ultrasound" ? "none ✓" : "yes"],
        ]}
      />
      <SimCanvas cameraPosition={[7, 4.5, 10]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.5, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Machine modality={modality} gantry={gantry} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
