// app/components/sims/unique/Topic7091Sim.tsx
// Acceleration: a car starts from rest and keeps speeding up. Its green
// velocity arrow grows longer every second, and the dots it drops every
// half second spread further apart — the signature of acceleration.

"use client";

import { useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "accel", label: "Acceleration", kind: "slider", min: 0.5, max: 4, step: 0.1, default: 1.5, unit: "m/s²" },
];

export const UNIQUE_META = {
  title: "Acceleration",
  blurb: "A car speeds up from rest — watch the velocity arrow stretch and the trail dots spread apart.",
};

const DOTS = 12;
const DOT_DT = 0.5;

function Animator({
  car,
  shaft,
  cone,
  dots,
  wheels,
  accel,
  vel,
  bump,
}: {
  car: RefObject<THREE.Group>;
  shaft: RefObject<THREE.Mesh>;
  cone: RefObject<THREE.Mesh>;
  dots: RefObject<THREE.Group>;
  wheels: RefObject<THREE.Group>;
  accel: number;
  vel: RefObject<number>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  const lastDrop = useRef(-10);
  const dropX = useRef<number[]>([]);
  useFrame((_, delta) => {
    t.current += delta;
    const T = t.current;
    // v = a·t, x = ½a·t². Reset when the car leaves the view.
    let x = 0.5 * accel * T * T - 8;
    if (x > 9.5) {
      t.current = 0;
      dropX.current = [];
      lastDrop.current = -10;
      return;
    }
    const v = accel * T;
    vel.current = v;
    if (car.current) car.current.position.x = x;
    const L = 0.5 + v * 0.6;
    if (shaft.current) {
      shaft.current.scale.y = L;
      shaft.current.position.y = L / 2;
    }
    if (cone.current) cone.current.position.y = L + 0.22;
    if (wheels.current) wheels.current.children.forEach((w) => (w.rotation.z -= (v * delta) / 0.32));
    // Drop a dot every DOT_DT seconds (equal time intervals).
    if (T - lastDrop.current >= DOT_DT) {
      lastDrop.current = T;
      dropX.current.push(x);
      if (dropX.current.length > DOTS) dropX.current.shift();
    }
    if (dots.current) {
      const kids = dots.current.children;
      for (let i = 0; i < DOTS; i++) {
        const k = kids[i];
        if (i < dropX.current.length) {
          k.visible = true;
          k.position.set(dropX.current[i], 0.12, 0);
        } else k.visible = false;
      }
    }
    if (++n.current % 15 === 0) bump();
  });
  return null;
}

export function Topic7091Sim(props: SimProps) {
  const accel = Number(props.accel ?? 1.5);
  const car = useRef<THREE.Group>(null!);
  const shaft = useRef<THREE.Mesh>(null!);
  const cone = useRef<THREE.Mesh>(null!);
  const dots = useRef<THREE.Group>(null!);
  const wheels = useRef<THREE.Group>(null!);
  const vel = useRef(0);
  const [, bump] = useState(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Acceleration", `${accel.toFixed(1)} m/s²`],
          ["Velocity now", `${vel.current.toFixed(1)} m/s`],
          ["🟢 Arrow", "velocity (grows with time)"],
          ["Dots", "dropped every 0.5 s"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 6, 14]} target={[0, 1, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <mesh position={[0, 0.05, 0]} receiveShadow>
          <boxGeometry args={[21, 0.1, 2.4]} />
          <meshStandardMaterial color="#334155" roughness={0.9} />
        </mesh>

        <group ref={dots}>
          {Array.from({ length: DOTS }, (_, i) => (
            <mesh key={i} visible={false}>
              <sphereGeometry args={[0.12, 12, 12]} />
              <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.6} />
            </mesh>
          ))}
        </group>

        <group ref={car}>
          <mesh position={[0, 0.72, 0]} castShadow>
            <boxGeometry args={[2.2, 0.66, 1.2]} />
            <meshStandardMaterial color="#ef4444" roughness={0.35} metalness={0.4} />
          </mesh>
          <mesh position={[-0.15, 1.3, 0]} castShadow>
            <boxGeometry args={[1.1, 0.55, 1.0]} />
            <meshStandardMaterial color="#bae6fd" roughness={0.2} metalness={0.3} />
          </mesh>
          <group ref={wheels}>
            {[-0.75, 0.75].map((x) =>
              [-0.62, 0.62].map((z) => (
                <mesh key={`${x}${z}`} position={[x, 0.32, z]} rotation={[Math.PI / 2, 0, 0]}>
                  <cylinderGeometry args={[0.32, 0.32, 0.18, 18]} />
                  <meshStandardMaterial color="#111827" roughness={0.8} />
                </mesh>
              ))
            )}
          </group>
          <group position={[0, 1.9, 0]} rotation={[0, 0, -Math.PI / 2]}>
            <mesh ref={shaft}>
              <cylinderGeometry args={[0.09, 0.09, 1, 10]} />
              <meshStandardMaterial color="#22c55e" emissive="#15803d" emissiveIntensity={0.5} roughness={0.4} />
            </mesh>
            <mesh ref={cone}>
              <coneGeometry args={[0.24, 0.45, 12]} />
              <meshStandardMaterial color="#22c55e" emissive="#15803d" emissiveIntensity={0.5} roughness={0.4} />
            </mesh>
          </group>
        </group>

        <Animator
          car={car} shaft={shaft} cone={cone} dots={dots} wheels={wheels}
          accel={accel} vel={vel} bump={() => bump((v) => v + 1)}
        />
      </SimCanvas>
    </div>
  );
}
