// Glaucoma — open-angle vs angle-closure. Aqueous fluid drains through the
// trabecular meshwork; the blockage slider clogs the drain, intra-ocular
// pressure rises (gauge needle), and the optic disc cups.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "blockage", label: "Drainage blockage", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "type", label: "Type", kind: "select", min: 0, max: 0, step: 1, default: "open-angle", options: ["open-angle", "angle-closure"] },
];

export const UNIQUE_META = {
  title: "Glaucoma",
  blurb: "Fluid can't drain → eye pressure climbs → optic nerve damage. Block the drain and watch the gauge and optic disc.",
};

function Animator({ drops, needle, elapsed, blockage }: {
  drops: React.RefObject<THREE.Group>;
  needle: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  blockage: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const flow = 1 - blockage / 100;
    if (drops.current) {
      drops.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const ph = ((t * (0.5 + flow * 1.6) + i * 0.22) % 1);
        // droplets slide from the angle toward the drain canal
        m.position.y = 1.7 - ph * 1.1;
        m.visible = flow > 0.05 && ph < flow + 0.25;
      });
    }
    if (needle.current) {
      const target = -Math.PI * 0.42 + (blockage / 100) * Math.PI * 0.84;
      needle.current.rotation.z += (target - needle.current.rotation.z) * Math.min(1, delta * 4);
    }
  });
  return null;
}

export function Topic10201Sim(props: SimProps) {
  const blockage = Number(props.blockage ?? 55);
  const type = String(props.type ?? "open-angle");
  const drops = useRef<THREE.Group>(null!);
  const needle = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const iop = Math.round(12 + (blockage / 100) * 34 + (type === "angle-closure" ? 12 : 0));
  const danger = iop > 30;
  // angle-closure: iris bows forward, closing the angle
  const irisBump = type === "angle-closure" ? 0.35 : 0;
  const cupDepth = 0.15 + (blockage / 100) * 0.55;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Eye pressure (IOP)", `${iop} mmHg`], ["Status", danger ? "DANGER — nerve damage" : "safe range"], ["Type", type]]} />
      <SimCanvas cameraPosition={[0, 2.2, 11]} target={[0, 1.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* front-of-eye: cornea dome */}
        <mesh position={[-2.2, 1.6, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <sphereGeometry args={[1.6, 32, 18, 0, Math.PI * 2, 0, Math.PI * 0.42]} />
          <meshStandardMaterial color="#bae6fd" transparent opacity={0.5} roughness={0.15} side={THREE.DoubleSide} />
        </mesh>
        {/* iris, bowing forward in angle-closure */}
        <mesh position={[-2.2 + irisBump, 1.6, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.62, 0.3, 14, 32]} />
          <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
        </mesh>
        {/* anterior chamber fluid */}
        <mesh position={[-2.6, 1.6, 0]} rotation={[0, 0, Math.PI / 2]}>
          <sphereGeometry args={[1.15, 24, 14, 0, Math.PI * 2, 0, Math.PI * 0.45]} />
          <meshStandardMaterial color="#7dd3fc" transparent opacity={0.28} roughness={0.2} side={THREE.DoubleSide} />
        </mesh>
        {/* trabecular drain canal at the angle */}
        <mesh position={[-1.45, 2.35, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[1.05, 0.14 + (blockage / 100) * 0.12, 10, 36]} />
          <meshStandardMaterial color={blockage > 60 ? "#ef4444" : "#22c55e"} roughness={0.5} emissive={blockage > 60 ? "#7f1d1d" : "#14532d"} emissiveIntensity={0.5} />
        </mesh>
        {/* clog gunk */}
        {blockage > 30 && (
          <mesh position={[-1.45, 2.35, 0.75]} scale={[1, 1, 0.6]}>
            <sphereGeometry args={[0.35 + (blockage / 100) * 0.3, 12, 10]} />
            <meshStandardMaterial color="#78350f" roughness={1} />
          </mesh>
        )}
        {/* draining droplets */}
        <group ref={drops}>
          {Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[-1.45, 1.7, 0]}>
              <sphereGeometry args={[0.09, 10, 10]} />
              <meshBasicMaterial color="#7dd3fc" />
            </mesh>
          ))}
        </group>
        <Arrow from={[-2.9, 0.4, 0]} to={[-1.6, 0.4, 0]} color="#7dd3fc" radius={0.06} />

        {/* optic disc: cup deepens with pressure */}
        <mesh position={[2.6, 1.6, 0]} castShadow>
          <sphereGeometry args={[1.15, 28, 20]} />
          <meshStandardMaterial color="#fb923c" roughness={0.6} />
        </mesh>
        <mesh position={[3.35, 1.6, 0]} scale={[0.5, 1, 1]}>
          <sphereGeometry args={[0.35 + cupDepth * 0.7, 20, 14]} />
          <meshStandardMaterial color="#fef3c7" roughness={0.5} emissive="#b45309" emissiveIntensity={0.25} />
        </mesh>
        <Label text={`Optic disc cup ${cupDepth > 0.5 ? "DEEP ⚠" : "normal"}`} position={[2.6, 3.3, 0]} size={0.5} color={cupDepth > 0.5 ? "#fca5a5" : "#86efac"} />

        {/* pressure gauge */}
        <group position={[5.6, 0.2, 0]}>
          <mesh>
            <cylinderGeometry args={[1.1, 1.1, 0.18, 32]} />
            <meshStandardMaterial color="#1e293b" roughness={0.5} />
          </mesh>
          <mesh position={[0, 0, 0.11]}>
            <ringGeometry args={[0.7, 0.95, 32, 1, Math.PI * 0.08, Math.PI * 0.84]} />
            <meshBasicMaterial color={danger ? "#ef4444" : "#22c55e"} side={THREE.DoubleSide} />
          </mesh>
          <group ref={needle}>
            <mesh position={[0, 0.32, 0.14]}>
              <boxGeometry args={[0.08, 0.72, 0.05]} />
              <meshBasicMaterial color="#f8fafc" />
            </mesh>
          </group>
          <Label text={`${iop} mmHg`} position={[0, -1.5, 0]} size={0.55} color={danger ? "#fca5a5" : "#86efac"} />
        </group>

        <Label text="Trabecular drain" position={[-1.45, 3.6, 0]} size={0.5} color="#7dd3fc" />
        <Label text={type === "angle-closure" ? "Angle-CLOSURE: iris blocks the drain suddenly" : "Open-angle: drain clogs slowly, painlessly"} position={[0, -2.4, 0]} size={0.44} color="#94a3b8" />
        <Animator drops={drops} needle={needle} elapsed={elapsed} blockage={blockage} />
      </SimCanvas>
    </div>
  );
}
