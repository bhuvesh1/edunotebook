"use client";
// Removable Appliances: Hawley & Expansion Plates — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "appliance", label: "Appliance", kind: "select", min: 0, max: 0, step: 1, default: "Hawley retainer", options: ["Hawley retainer", "Expansion plate"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Removable Appliances: Hawley & Expansion Plates",
  blurb: "A Hawley retainer with its wire bow slides on and off the teeth — switch to see an expansion plate with its screw.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const app: any = g("appliance");
    if (app) {
      const ph = (t % 8) / 8;
      app.position.z = ph < 0.5 ? 2.6 * (1 - ph * 2) : 2.6 * ((ph - 0.5) * 2);
      app.visible = true;
    }
    group.current.rotation.y = Math.sin(t * 0.2) * 0.2;
  });
  return null;
}

export function Topic10467Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const appliance = String(props.appliance ?? "Hawley retainer");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, appliance };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Appliance", appliance],
          ["Parts", appliance === "Hawley retainer" ? "Acrylic + labial bow + clasps" : "Acrylic + midline screw"],
          ["Wear", "Removable by patient"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          {[-1.8, -0.6, 0.6, 1.8].map((x, i) => (
            <mesh key={i} position={[x, 1.4, 0]}>
              <boxGeometry args={[1, 1.5, 1]} />
              <meshStandardMaterial color="#f1e9d2" roughness={0.4} />
            </mesh>
          ))}
          <GumSlab position={[0, 0.3, -0.4]} scale={1.1} />
          <group name="appliance" position={[0, 1.4, 2.6]}>
            {appliance === "Hawley retainer" ? (
              <group>
                <mesh position={[0, -0.5, -0.5]}>
                  <cylinderGeometry args={[2.4, 2.4, 0.35, 24, 1, false, 0, Math.PI]} />
                  <meshStandardMaterial color="#f472b6" roughness={0.5} transparent opacity={0.9} />
                </mesh>
                <Wire points={[[-2.3, 0.35, 0.55], [-1, 0.5, 0.62], [1, 0.5, 0.62], [2.3, 0.35, 0.55]]} color="#e2e8f0" radius={0.05} />
              </group>
            ) : (
              <group>
                <mesh position={[0, -0.5, -0.5]}>
                  <cylinderGeometry args={[2.4, 2.4, 0.35, 24, 1, false, 0, Math.PI]} />
                  <meshStandardMaterial color="#c4b5fd" roughness={0.5} transparent opacity={0.9} />
                </mesh>
                <mesh position={[0, -0.5, -0.5]} rotation={[0, 0, Math.PI / 2]}>
                  <cylinderGeometry args={[0.22, 0.22, 1.1, 12]} />
                  <meshStandardMaterial color="#94a3b8" metalness={0.85} roughness={0.3} />
                </mesh>
                <mesh position={[0, -0.28, -0.5]}>
                  <boxGeometry args={[0.3, 0.06, 0.12]} />
                  <meshStandardMaterial color="#475569" roughness={0.4} />
                </mesh>
              </group>
            )}
            <Label text={appliance} position={[0, 2.6, 0]} size={0.42} color="#f472b6" />
          </group>
          <Label text="Labial bow wire" position={[2.9, 2.1, 0.6]} size={0.4} />
          <Label text="Pink acrylic plate" position={[-2.9, 0.6, -0.4]} size={0.4} color="#f472b6" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
