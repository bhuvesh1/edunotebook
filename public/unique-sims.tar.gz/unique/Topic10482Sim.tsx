"use client";
// Gingival Enlargement & Recession — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "Enlargement", options: ["Enlargement", "Recession"] },
  { key: "sev", label: "Severity", kind: "slider", min: 0.2, max: 1.5, step: 0.1, default: 0.8, unit: "×" },
];

export const UNIQUE_META = {
  title: "Gingival Enlargement & Recession",
  blurb: "The gumline on the move: drug-induced overgrowth creeps up the crown, or recession pulls down exposing root.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const m: any = g("margin");
    if (m) {
      if (p.cond === "Enlargement") {
        m.position.y = 1.5 + p.sev * 0.9;
        m.scale.set(1 + p.sev * 0.15, 1 + p.sev * 0.5, 1);
      } else {
        m.position.y = 1.5 - p.sev * 1.1;
        m.scale.set(1, Math.max(0.4, 1 - p.sev * 0.35), 1);
      }
    }
    const sens: any = g("sens");
    if (sens) (sens.material as any).opacity = p.cond === "Recession" ? 0.5 + 0.4 * Math.sin(t * 5) : 0;
    group.current.rotation.y = Math.sin(t * 0.25) * 0.3;
  });
  return null;
}

export function Topic10482Sim(props: SimProps) {
  const speed = 1;
  const cond = String(props.cond ?? "Enlargement");
  const sev = Number(props.sev ?? 0.8);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, sev, cond };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", cond],
          ["Severity", `${sev.toFixed(1)}×`],
          ["Effect", cond === "Enlargement" ? "Gum covers crown" : "Root exposed"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1.1, 0]} scale={1.5} />
          <mesh name="margin" position={[0, 1.5, 0]}>
            <boxGeometry args={[2.6, 1, 2]} />
            <meshStandardMaterial color="#e0808f" roughness={0.6} />
          </mesh>
          <mesh name="sens" position={[0.9, 0.2, 0.6]}>
            <sphereGeometry args={[0.22, 10, 10]} />
            <meshStandardMaterial color="#fde047" emissive="#fde047" emissiveIntensity={0.9} transparent opacity={0.5} />
          </mesh>
          <Label text="Gum margin" position={[-2.4, 2.4, 0]} size={0.42} color="#e0808f" />
          <Label text="Sensitivity!" position={[2.2, 0.2, 0.6]} size={0.4} color="#fde047" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
