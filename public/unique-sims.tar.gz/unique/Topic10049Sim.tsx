// Endocrine: calcium homeostasis — blood Ca²⁺ slider drives the loop: low Ca²⁺
// wakes the parathyroids (PTH ↑), PTH pulls calcium from bone and the kidney,
// while sunshine makes vitamin D to boost gut absorption.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ca", label: "Blood Ca²⁺", kind: "slider", min: 6, max: 13, step: 0.1, default: 9.5, unit: "mg/dL" },
  { key: "sun", label: "Sunshine (vitamin D)", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Endocrine: Calcium Homeostasis",
  blurb: "Low blood calcium wakes the parathyroids — PTH pulls Ca²⁺ from bone while vitamin D boosts gut absorption.",
};

function Animator({
  caFlow, pthPulses, sunRays, elapsed, ca, sun, speed,
}: {
  caFlow: React.RefObject<THREE.Group>;
  pthPulses: React.RefObject<THREE.Group>;
  sunRays: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  ca: number;
  sun: number;
  speed: number;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const pth = Math.max(0, (9.5 - ca) / 3.5); // PTH rises as Ca falls
    if (caFlow.current) {
      caFlow.current.children.forEach((m, i) => {
        const ph = ((t * (0.3 + pth * 0.7) + i / 10) % 1 + 1) % 1;
        // bone -> blood path
        m.position.x = -5.5 + ph * 5.5;
        m.position.y = 1.6 + Math.sin(ph * Math.PI) * 0.8;
        m.visible = pth > 0.02 || sun > 0.02;
      });
    }
    if (pthPulses.current) {
      pthPulses.current.children.forEach((m, i) => {
        const ph = ((t * 0.5 * Math.max(pth, 0.08) + i / 6) % 1 + 1) % 1;
        m.position.y = 3.2 - ph * 2.2;
        const mat = (m as THREE.Mesh).material as THREE.MeshBasicMaterial;
        mat.opacity = 0.25 + 0.75 * Math.min(1, pth + 0.15);
      });
    }
    if (sunRays.current) {
      sunRays.current.children.forEach((m, i) => {
        const mat = (m as THREE.Mesh).material as THREE.MeshBasicMaterial;
        mat.opacity = 0.15 + 0.5 * Math.min(1, sun) * (0.6 + 0.4 * Math.sin(t * 3 + i));
      });
    }
  });
  return null;
}

export function Topic10049Sim(props: SimProps) {
  const ca = Number(props.ca ?? 9.5);
  const sun = Number(props.sun ?? 1);
  const speed = 1;
  const caFlow = useRef<THREE.Group>(null!);
  const pthPulses = useRef<THREE.Group>(null!);
  const sunRays = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const pth = Math.max(0, (9.5 - ca) / 3.5);
  const caState = ca < 8.5 ? "hypocalcemia — PTH surging" : ca > 10.5 ? "hypercalcemia — PTH suppressed" : "normal 8.5–10.5 ✓";
  const caColor = ca < 8.5 || ca > 10.5 ? "#fca5a5" : "#86efac";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Blood Ca²⁺", `${ca.toFixed(1)} mg/dL — ${caState}`],
          ["PTH", pth > 0.05 ? `↑ ${(pth * 65).toFixed(0)} pg/mL` : "suppressed"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 5.5, 15]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[40, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* bone: femur-ish shaft releasing Ca2+ */}
        <group position={[-5.5, 0, 0]}>
          <mesh position={[0, 1.6, 0]} rotation={[0, 0, 0.25]} castShadow>
            <cylinderGeometry args={[0.55, 0.55, 3.4, 14]} />
            <meshStandardMaterial color="#e7e5e4" roughness={0.55} />
          </mesh>
          <mesh position={[-0.42, 3.35, 0]} castShadow>
            <sphereGeometry args={[0.75, 14, 14]} />
            <meshStandardMaterial color="#e7e5e4" roughness={0.55} />
          </mesh>
          <mesh position={[0.42, -0.15, 0]} castShadow>
            <sphereGeometry args={[0.75, 14, 14]} />
            <meshStandardMaterial color="#e7e5e4" roughness={0.55} />
          </mesh>
          {/* resorption pits glowing when PTH high */}
          {[-0.2, 0.5, 1.1].map((y, i) => (
            <mesh key={i} position={[0.4, 1.6 + y * 0.5, 0.35]}>
              <sphereGeometry args={[0.14, 8, 8]} />
              <meshBasicMaterial color="#f87171" transparent opacity={Math.min(1, 0.2 + pth)} />
            </mesh>
          ))}
        </group>
        {/* Ca2+ flowing bone -> blood */}
        <group ref={caFlow}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i} position={[-5.5, 1.6, 0]}>
              <sphereGeometry args={[0.11, 8, 8]} />
              <meshBasicMaterial color="#fef08a" />
            </mesh>
          ))}
        </group>
        <Label text="bone — Ca²⁺ reservoir" position={[-5.5, 4.6, 0]} size={0.38} color="#f8fafc" />
        <Label text="osteoclast resorption ↑ with PTH" position={[-5.5, -0.9, 0]} size={0.3} color="#fca5a5" />

        {/* blood pool */}
        <mesh position={[0.5, 1.6, 0]} castShadow>
          <sphereGeometry args={[1.3, 20, 20]} />
          <meshStandardMaterial color="#991b1b" transparent opacity={0.6} roughness={0.4} />
        </mesh>
        <Label text="blood Ca²⁺" position={[0.5, 3.4, 0]} size={0.38} color="#f8fafc" />
        <Label text={caState} position={[0.5, 0.1, 0]} size={0.32} color={caColor} />
        <Arrow from={[-3.4, 2.4, 0]} to={[-1.1, 1.9, 0]} color="#fef08a" radius={0.06} />

        {/* thyroid + 4 parathyroids behind */}
        <group position={[5.2, 0, 0]}>
          <mesh position={[0, 2.4, -0.4]} castShadow scale={[1, 1.2, 0.7]}>
            <sphereGeometry args={[0.8, 16, 16]} />
            <meshStandardMaterial color="#f472b6" roughness={0.45} />
          </mesh>
          {[[-0.4, 2.9], [0.4, 2.9], [-0.4, 1.9], [0.4, 1.9]].map(([x, y], i) => (
            <mesh key={i} position={[x, y, 0.45]} castShadow>
              <sphereGeometry args={[0.2, 10, 10]} />
              <meshStandardMaterial color="#fbbf24" emissive="#92400e"
                emissiveIntensity={0.3 + pth * 1.2} roughness={0.4} />
            </mesh>
          ))}
        </group>
        {/* PTH pulses */}
        <group ref={pthPulses}>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[5.2, 3.2, 0]}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshBasicMaterial color="#fbbf24" transparent opacity={0.8} />
            </mesh>
          ))}
        </group>
        <Label text="4 parathyroid glands" position={[5.2, 4.1, 0]} size={0.36} color="#f8fafc" />
        <Label text={`PTH ${pth > 0.05 ? "↑↑↑" : "—"}`} position={[6.9, 2.9, 0.45]} size={0.32} color="#fde68a" />
        <Arrow from={[4.4, 2.4, 0]} to={[2.0, 1.9, 0]} color="#fbbf24" radius={0.05} />

        {/* sun -> vitamin D -> gut absorption */}
        <group position={[-1.5, 6.4, -2]}>
          <mesh castShadow>
            <sphereGeometry args={[0.7, 16, 16]} />
            <meshBasicMaterial color="#fde047" />
          </mesh>
        </group>
        <group ref={sunRays}>
          {Array.from({ length: 6 }).map((_, i) => {
            const a = (i / 6) * Math.PI * 2;
            return (
              <mesh key={i} position={[-1.5 + Math.cos(a) * 1.1, 6.4 + Math.sin(a) * 1.1, -2]}
                rotation={[0, 0, a]}>
                <boxGeometry args={[0.5, 0.08, 0.08]} />
                <meshBasicMaterial color="#fde047" transparent opacity={0.4} />
              </mesh>
            );
          })}
        </group>
        <Label text="sun → vitamin D → gut absorbs Ca²⁺" position={[-1.5, 7.6, -2]} size={0.32} color="#fde68a" />
        {/* gut */}
        <mesh position={[-1.5, 0.5, 0]} rotation={[0, 0, 0.3]} castShadow>
          <torusGeometry args={[0.9, 0.3, 10, 20, Math.PI * 1.4]} />
          <meshStandardMaterial color="#fda4af" roughness={0.5} />
        </mesh>
        <Label text="gut" position={[-1.5, -0.6, 0]} size={0.3} color="#fda4af" />

        <Animator caFlow={caFlow} pthPulses={pthPulses} sunRays={sunRays}
          elapsed={elapsed} ca={ca} sun={sun} speed={speed} />
      </SimCanvas>
    </div>
  );
}
