// Eczema and dermatitis: atopic, contact, seborrheic.
// Itchy, inflamed skin that begs to be scratched — and scratching makes it
// worse. See the itch-scratch cycle, the contact trigger, and dandruff-like
// seborrheic scales.

"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "type", label: "Type", kind: "select", min: 0, max: 0, step: 1, default: "atopic", options: ["atopic", "contact", "seborrheic"] },
  { key: "itch", label: "Itch intensity", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.7, unit: "" },
];

export const UNIQUE_META = {
  title: "Eczema: The Itch-Scratch Cycle",
  blurb: "Red, itchy, scaly skin — scratching feels good for a second, then makes everything worse.",
};

function Animator({
  group, patches, scratcher, flakes, elapsed, itch, type,
}: {
  group: React.RefObject<THREE.Group>;
  patches: React.RefObject<THREE.Group>;
  scratcher: React.RefObject<THREE.Group>;
  flakes: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  itch: number;
  type: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (group.current) group.current.rotation.y = Math.sin(t * 0.2) * 0.15;
    // inflamed patches throb with the itch
    if (patches.current) {
      patches.current.children.forEach((p, i) => {
        const s = 1 + itch * 0.15 * Math.sin(t * 4 + i * 2.3);
        (p as THREE.Mesh).scale.set(s, 1, s);
        ((p as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = 0.25 + itch * 0.5 * (0.5 + 0.5 * Math.sin(t * 4 + i));
      });
    }
    // scratching hand rakes back and forth; worse itch = faster scratch
    if (scratcher.current) {
      scratcher.current.visible = itch > 0.15;
      scratcher.current.position.x = Math.sin(t * (2 + itch * 6)) * 1.1;
      scratcher.current.position.y = 2.6 + Math.abs(Math.cos(t * (2 + itch * 6))) * 0.15;
    }
    // seborrheic flakes drift off
    if (flakes.current) {
      flakes.current.visible = type === "seborrheic";
      flakes.current.children.forEach((f, i) => {
        const ph = ((t * 0.4 + i / flakes.current!.children.length) % 1);
        f.position.y = 2.5 - ph * 1.2;
        f.rotation.x = t * 2 + i;
      });
    }
  });
  return null;
}

export function Topic10323Sim(props: SimProps) {
  const type = String(props.type ?? "atopic");
  const itch = Number(props.itch ?? 0.7);
  const group = useRef<THREE.Group>(null!);
  const patches = useRef<THREE.Group>(null!);
  const scratcher = useRef<THREE.Group>(null!);
  const flakes = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const names: Record<string, string> = {
    atopic: "Atopic eczema", contact: "Contact dermatitis", seborrheic: "Seborrheic dermatitis",
  };

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Type", names[type] ?? type], ["Itch", `${Math.round(itch * 100)}%`]]} />
      <SimCanvas cameraPosition={[0, 2.4, 10]} target={[0, 1.7, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={group}>
          {/* skin patch */}
          <mesh position={[0, 1.0, 0]} castShadow receiveShadow>
            <boxGeometry args={[7, 1.4, 4]} />
            <meshStandardMaterial color="#f5c396" roughness={0.7} />
          </mesh>
          {/* inflamed eczema patches */}
          <group ref={patches}>
            {[[-1.8, 0.3, 1.1], [0.1, -0.4, 1.35], [1.9, 0.4, 0.95]].map(([x, z, r], i) => (
              <mesh key={i} position={[x, 1.78, z]} scale={[r, 0.3, r * 0.8]} castShadow>
                <sphereGeometry args={[0.7, 16, 12]} />
                <meshStandardMaterial color="#ef4444" roughness={0.85} emissive="#7f1d1d" emissiveIntensity={0.5} flatShading />
              </mesh>
            ))}
          </group>
          {/* contact trigger: the offending watch/bracelet */}
          {type === "contact" && (
            <group position={[2.6, 2.0, 0]}>
              <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
                <torusGeometry args={[0.55, 0.14, 12, 24]} />
                <meshStandardMaterial color="#fbbf24" metalness={0.8} roughness={0.3} />
              </mesh>
              <Label text="⚠ Nickel trigger!" position={[2.6, 2.9, 0]} size={0.5} color="#fde68a" />
            </group>
          )}
          {/* scratching fingers */}
          <group ref={scratcher} position={[0, 2.6, 0.8]}>
            {[-0.15, 0, 0.15].map((x, i) => (
              <mesh key={i} position={[x, 0, 0]} rotation={[0.4, 0, 0]} castShadow>
                <capsuleGeometry args={[0.07, 0.4, 6, 8]} />
                <meshStandardMaterial color="#f5c396" roughness={0.6} />
              </mesh>
            ))}
          </group>
          {/* seborrheic flakes */}
          <group ref={flakes} visible={false}>
            {Array.from({ length: 14 }).map((_, i) => (
              <mesh key={i} position={[-2 + (i % 7) * 0.65, 2.5, -0.8 + Math.floor(i / 7) * 1.2]}>
                <boxGeometry args={[0.14, 0.03, 0.1]} />
                <meshStandardMaterial color="#fef3c7" roughness={0.9} />
              </mesh>
            ))}
          </group>
          <Label text="🔴 Inflamed, itchy patches" position={[0, 0.1, 0]} size={0.55} color="#fca5a5" />
          <Label text="Scratching → more damage!" position={[-2.7, 3.1, 0.8]} size={0.5} color="#fde68a" />
          {type === "atopic" && <Label text="Inner elbows/knees — classic spots" position={[2.7, 1.0, 0]} size={0.45} color="#fecdd3" />}
        </group>
        <Animator group={group} patches={patches} scratcher={scratcher} flakes={flakes} elapsed={elapsed} itch={itch} type={type} />
      </SimCanvas>
    </div>
  );
}
