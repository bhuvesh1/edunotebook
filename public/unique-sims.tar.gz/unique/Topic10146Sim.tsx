// Complement & hypersensitivity: complement proteins punch MAC pores into the
// bacterium until it lyses — flip to allergy mode and the mast cell bursts
// histamine granules instead.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "mode", label: "Immune mode", kind: "select", min: 0, max: 0, step: 1, default: "complement", options: ["complement", "allergy"] },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Complement & hypersensitivity",
  blurb: "Complement punches pores into bacteria until they lyse — or flip to allergy and watch histamine burst.",
};

const N_C3 = 9;
const N_HIST = 12;

function Animator({ c3, bug, mast, hist, elapsed, mode, setTick }: {
  c3: React.RefObject<(THREE.Mesh | null)[]>;
  bug: React.RefObject<THREE.Group>;
  mast: React.RefObject<THREE.Mesh>;
  hist: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  mode: string;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (mode === "complement") {
      let pores = 0;
      c3.current.forEach((c, i) => {
        if (!c) return;
        // C3 proteins fly in and embed as MAC pores
        const cyc = Math.min(1, (t * 0.3 + i / N_C3) % 1.2);
        const a = (i / N_C3) * Math.PI * 2;
        if (cyc >= 1) pores++;
        const r = 3.2 * (1 - cyc) + 1.05 * cyc;
        c.position.set(-2.6 + Math.cos(a) * r, 1.6 + Math.sin(a * 1.4) * r * 0.7, Math.sin(a) * r * 0.6);
        c.rotation.y = t * 2 + i;
        ((c as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = cyc >= 1 ? 1.4 : 0.6;
      });
      if (bug.current) {
        // lysis when enough pores: deflate + wobble
        const lysed = Math.min(1, Math.max(0, (pores - 5) / 4));
        bug.current.scale.set(1 - lysed * 0.55, Math.max(0.2, 1 - lysed * 0.8), 1 - lysed * 0.55);
        bug.current.rotation.z = Math.sin(t * (1 + lysed * 8)) * 0.12 * (1 + lysed * 3);
        if (last.current && Math.abs(t - last.current) > 0.3) setTick(pores);
      }
      if (mast.current) mast.current.visible = false;
      hist.current.forEach((h) => { if (h) h.visible = false; });
    } else {
      // allergy mode: mast cell degranulates histamine
      if (mast.current) {
        mast.current.visible = true;
        const p = 1 + Math.sin(t * 5) * 0.06;
        mast.current.scale.set(p, p, p);
      }
      let out = 0;
      hist.current.forEach((h, i) => {
        if (!h) return;
        h.visible = true;
        const f = (t * 0.7 + i / N_HIST) % 1;
        const a = (i / N_HIST) * Math.PI * 2;
        h.position.set(2.6 + Math.cos(a) * f * 2.4, 1.6 + Math.sin(a) * f * 1.6, Math.sin(a * 2) * f);
        ((h as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = Math.max(0, 1 - f * 0.8);
        if (f > 0.5) out++;
      });
      c3.current.forEach((c) => { if (c) c.visible = false; });
      if (bug.current) {
        bug.current.visible = true;
        bug.current.scale.set(1, 1, 1);
        bug.current.rotation.z = Math.sin(t * 1.2) * 0.05;
      }
      if (Math.abs(t - last.current) > 0.3) setTick(out);
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; }
  });
  return null;
}

export function Topic10146Sim(props: SimProps) {
  const mode = String(props.mode ?? "complement");
  const showLabels = String(props.detail ?? "on") === "on";
  const c3 = useRef<(THREE.Mesh | null)[]>([]);
  const bug = useRef<THREE.Group>(null!);
  const mast = useRef<THREE.Mesh>(null!);
  const hist = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={
          mode === "complement"
            ? [["MAC pores punched", `${tick}`], ["Bacterium", tick >= 9 ? "LYSED!" : "under attack"]]
            : [["Histamine released", `${tick} granules`], ["Reaction", "allergy — swelling, redness"]]
        }
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* target bacterium */}
        <group ref={bug} position={[-2.6, 1.6, 0]}>
          <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
            <capsuleGeometry args={[0.85, 1.2, 8, 18]} />
            <meshStandardMaterial color="#4ade80" roughness={0.5} />
          </mesh>
        </group>
        {showLabels && mode === "complement" && <Label text="bacterium" position={[-2.6, 3.2, 0]} color="#86efac" />}

        {/* complement C3 proteins */}
        {Array.from({ length: N_C3 }).map((_, i) => (
          <mesh key={i} ref={(m) => { c3.current[i] = m; }} visible={mode === "complement"}>
            <torusGeometry args={[0.16, 0.07, 8, 14]} />
            <meshStandardMaterial color="#fb923c" emissive="#c2410c" emissiveIntensity={0.7} />
          </mesh>
        ))}
        {showLabels && mode === "complement" && <Label text="complement C3 → MAC pores" position={[-2.6, 4.2, 0]} size={0.45} color="#fdba74" />}

        {/* mast cell */}
        <mesh ref={mast} position={[2.6, 1.6, 0]} visible={mode === "allergy"} castShadow>
          <sphereGeometry args={[1.0, 20, 14]} />
          <meshStandardMaterial color="#c08497" roughness={0.5} />
        </mesh>
        {showLabels && mode === "allergy" && <Label text="mast cell — degranulating!" position={[2.6, 3.2, 0]} color="#f9a8d4" />}

        {/* histamine granules */}
        {Array.from({ length: N_HIST }).map((_, i) => (
          <mesh key={`h${i}`} ref={(m) => { hist.current[i] = m; }} visible={mode === "allergy"}>
            <sphereGeometry args={[0.11, 8, 8]} />
            <meshStandardMaterial color="#fde047" emissive="#eab308" emissiveIntensity={1} transparent />
          </mesh>
        ))}
        {showLabels && mode === "allergy" && <Label text="histamine" position={[2.6, 4.2, 0]} size={0.45} color="#fde047" />}

        <Animator c3={c3} bug={bug} mast={mast} hist={hist} elapsed={elapsed} mode={mode} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
