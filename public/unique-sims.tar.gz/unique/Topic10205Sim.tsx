// Corneal diseases — keratitis / corneal ulcer: a white infiltrate grows on
// the clear corneal dome; then a corneal-transplant disc swaps in and the
// eye clears. Ulcer-size slider + auto transplant cycle.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ulcer", label: "Ulcer size", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "stage", label: "Stage", kind: "select", min: 0, max: 0, step: 1, default: "keratitis", options: ["keratitis", "ulcer", "post-transplant"] },
];

export const UNIQUE_META = {
  title: "Corneal Diseases",
  blurb: "A cloudy ulcer spreads across the cornea — then a transplant disc drops in and the eye turns clear again.",
};

function Animator({ graft, elapsed, stage }: {
  graft: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  stage: string;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    if (graft.current) {
      if (stage === "post-transplant") {
        // donor disc descends and settles into the cornea
        const ph = Math.min(1, (t % 6) / 2.5);
        const ease = 1 - Math.pow(1 - ph, 3);
        graft.current.position.y = 6.5 - ease * 4.9;
        graft.current.rotation.y = t * (1 - ease) * 2;
        graft.current.visible = true;
      } else {
        graft.current.visible = false;
      }
    }
  });
  return null;
}

export function Topic10205Sim(props: SimProps) {
  const ulcer = Number(props.ulcer ?? 55);
  const stage = String(props.stage ?? "keratitis");
  const graft = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const ulcerScale = 0.25 + (ulcer / 100) * 1.0;
  const infected = stage !== "post-transplant";
  const cornealCloud = stage === "keratitis" ? ulcer / 100 : stage === "ulcer" ? Math.min(1, ulcer / 70) : 0;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Stage", stage], ["Corneal clarity", `${Math.round((1 - cornealCloud) * 100)}%`], ["Fix", stage === "post-transplant" ? "donor graft in place" : "antibiotics / transplant"]]} />
      <SimCanvas cameraPosition={[0, 2.2, 10.5]} target={[0, 1.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* eyeball */}
        <mesh position={[0, 1.2, 0]} castShadow>
          <sphereGeometry args={[2.1, 36, 26]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.35} />
        </mesh>
        {/* cornea: clouds over with disease, clears after transplant */}
        <mesh position={[0, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <sphereGeometry args={[1.98, 36, 20, -Math.PI * 0.24, Math.PI * 0.48, Math.PI * 0.3, Math.PI * 0.4]} />
          <meshStandardMaterial color={cornealCloud > 0.5 ? "#d6d3c8" : "#bae6fd"} transparent opacity={0.35 + cornealCloud * 0.55} roughness={0.2 + cornealCloud * 0.6} />
        </mesh>
        {/* iris + pupil */}
        <mesh position={[1.95, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.68, 0.32, 14, 32]} />
          <meshStandardMaterial color="#0ea5e9" roughness={0.4} />
        </mesh>
        <mesh position={[1.93, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
          <circleGeometry args={[0.4, 24]} />
          <meshStandardMaterial color="#020617" roughness={0.9} />
        </mesh>

        {/* ulcer infiltrate: white patch on the cornea */}
        {infected && (
          <mesh position={[2.02, 1.55, 0.15]} rotation={[0, Math.PI / 2, 0]} scale={[1, ulcerScale, ulcerScale]}>
            <circleGeometry args={[0.55, 20]} />
            <meshStandardMaterial color="#fefce8" roughness={0.95} emissive="#a8a29e" emissiveIntensity={0.25} />
          </mesh>
        )}
        {/* redness ring around the eye */}
        {infected && (
          <mesh position={[0.4, 1.2, 0]} rotation={[0, Math.PI / 2, 0]}>
            <torusGeometry args={[1.55, 0.1 + (ulcer / 100) * 0.14, 10, 40]} />
            <meshStandardMaterial color="#ef4444" roughness={0.5} emissive="#7f1d1d" emissiveIntensity={0.6} />
          </mesh>
        )}
        {/* donor graft disc descends during transplant */}
        <group ref={graft} visible={false}>
          <mesh rotation={[Math.PI / 2.4, 0, 0]}>
            <cylinderGeometry args={[0.85, 0.85, 0.1, 28]} />
            <meshStandardMaterial color="#bae6fd" transparent opacity={0.9} roughness={0.1} emissive="#0ea5e9" emissiveIntensity={0.25} />
          </mesh>
          <Label text="Donor cornea" position={[0, 0.9, 0]} size={0.5} color="#7dd3fc" />
        </group>

        <Label text={stage === "post-transplant" ? "Clear graft ✓" : stage === "ulcer" ? "Corneal ulcer — white infiltrate" : "Keratitis — cornea inflamed"} position={[2.6, 3.8, 0]} size={0.52} color={infected ? "#fca5a5" : "#86efac"} />
        <Label text="Transplant = replace the cloudy window with a donor one" position={[0, -1.7, 0]} size={0.44} color="#94a3b8" />
        <Animator graft={graft} elapsed={elapsed} stage={stage} />
      </SimCanvas>
    </div>
  );
}
