"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "clot", label: "Thrombus size", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.5 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Thrombosis & Embolism",
  blurb: "A clot grows on an injured vessel wall until a piece breaks off and travels downstream as an embolus.",
};

function Animator({ root, flow, thr, emb, elapsed, speed, clot }: { root: RefObject<THREE.Group>; flow: RefObject<THREE.Group>; thr: RefObject<THREE.Group>; emb: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; clot: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (flow.current) {
      flow.current.children.forEach((m, i) => {
        const p = (t * (0.5 - clot * 0.3) + i / 12) % 1;
        const near = Math.abs(-5.5 + p * 11) < 1.6;
        m.position.set(-5.5 + p * 11, 2 + Math.sin(i * 2.2) * (near ? 0.25 : 0.8), Math.cos(i) * 0.5);
      });
    }
    if (thr.current) thr.current.scale.setScalar(0.2 + clot * 1.1);
    if (emb.current) {
      const q = (t * 0.3) % 1;
      const go = q > 0.4 && clot > 0.35;
      emb.current.visible = go;
      if (go) {
        const r = (q - 0.4) / 0.6;
        emb.current.position.set(-1 + r * 7, 2 + Math.sin(r * 9) * 0.3, 0);
      }
    }
  });
  return null;
}

export function Topic10087Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const clot = Number(props.clot ?? 0.5);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const flow = useRef<THREE.Group>(null!);
  const thr = useRef<THREE.Group>(null!);
  const emb = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Occlusion", `${Math.round(clot * 90)}%`],
          ["Triad", "Virchow: stasis \u00b7 injury \u00b7 hypercoagulability"],
          ["Danger", "embolus \u2192 infarct downstream"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 11]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 2, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[1.5, 1.5, 12, 24, 1, true]} />
            <meshStandardMaterial color="#f9a8d4" transparent opacity={0.3} roughness={0.6} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[-1, 0.75, 0]} rotation={[0, 0, Math.PI / 2]}>
            <boxGeometry args={[1.4, 0.25, 1.2]} /><meshStandardMaterial color="#ef4444" emissive="#b91c1d" emissiveIntensity={0.5} />
          </mesh>
          <Label text="endothelial injury" position={[-1, 0.1, 0]} size={0.4} color="#f87171" />
          <group ref={thr} position={[-1, 1.35, 0]}>
            {Array.from({ length: 9 }).map((_, i) => (
              <mesh key={i} position={[Math.sin(i * 2.4) * 0.55, Math.cos(i * 1.8) * 0.4, Math.sin(i * 3.1) * 0.5]}>
                <sphereGeometry args={[0.3, 12, 12]} /><meshStandardMaterial color="#991b1b" roughness={0.7} />
              </mesh>
            ))}
          </group>
          <Label text="thrombus" position={[-1, 3.4, 0]} color="#f87171" />
          <mesh ref={emb} visible={false}>
            <sphereGeometry args={[0.34, 14, 14]} /><meshStandardMaterial color="#7f1d1d" emissive="#ef4444" emissiveIntensity={0.7} />
          </mesh>
          <Label text="embolus breaks off!" position={[3.4, 3.2, 0]} size={0.42} color="#fde047" />
          <group ref={flow}>
            {Array.from({ length: 12 }).map((_, i) => (
              <mesh key={i} scale={[1, 0.45, 1]}>
                <sphereGeometry args={[0.26, 14, 14]} /><meshStandardMaterial color="#dc2626" roughness={0.5} />
              </mesh>
            ))}
          </group>
        </group>
        <Animator root={root} flow={flow} thr={thr} emb={emb} elapsed={elapsed} speed={speed} clot={clot} />
      </SimCanvas>
    </div>
  );
}
