"use client";
// Asphyxia: hanging, strangulation, drowning.
// An airway tube carries glowing air particles to the lungs.
// Tighten the ligature — or flood the airway — and watch the airflow die.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cause", label: "Cause", kind: "select", min: 0, max: 0, step: 1, default: "hanging", options: ["hanging", "strangulation", "drowning"] },
  { key: "block", label: "Airway blockage", kind: "slider", min: 0, max: 100, step: 5, default: 40, unit: "%" },
];

export const UNIQUE_META = {
  title: "Asphyxia: Hanging, Strangulation, Drowning",
  blurb: "Air flows down the windpipe to the lungs — tighten the noose or flood it with water and watch the flow stop.",
};

const N_P = 26;

function Animator({ parts, blockRef, elapsed, block }: { parts: React.RefObject<THREE.Group>; blockRef: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; block: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const flow = 1 - block / 100;
    if (parts.current) {
      parts.current.children.forEach((p, i) => {
        const ph = ((elapsed.current * (0.6 + flow * 2.2) + i / N_P) % 1);
        p.position.y = 4.6 - ph * 4.4;
        (p as THREE.Mesh).material = (p as THREE.Mesh).material;
        p.visible = ph < 0.25 + flow * 0.75;
      });
    }
    if (blockRef.current) {
      const s = 0.55 + (block / 100) * 0.75;
      blockRef.current.scale.set(s, 1, s);
    }
  });
  return null;
}

export function Topic10155Sim(props: SimProps) {
  const cause = String(props.cause ?? "hanging");
  const block = Number(props.block ?? 40);
  const parts = useRef<THREE.Group>(null!);
  const blockRef = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const flowPct = Math.round((1 - block / 100) * 100);

  const dots = useMemo(
    () =>
      Array.from({ length: N_P }, (_, i) => (
        <mesh key={i} position={[0, 4.6 - (i / N_P) * 4.4, 0]}>
          <sphereGeometry args={[0.13, 10, 10]} />
          <meshStandardMaterial color="#7dd3fc" emissive="#38bdf8" emissiveIntensity={0.9} />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Cause", cause], ["Airflow", `${flowPct}%`], ["Status", flowPct > 60 ? "breathing" : flowPct > 20 ? "struggling" : "asphyxia"]]} />
      <SimCanvas cameraPosition={[0, 3.4, 12]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* head + neck */}
        <group position={[0, 0, 0]}>
          <mesh position={[0, 5.6, 0]} castShadow>
            <sphereGeometry args={[0.75, 22, 22]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.7} />
          </mesh>
          <mesh position={[0, 4.7, 0]} castShadow>
            <cylinderGeometry args={[0.42, 0.5, 0.9, 16]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.7} />
          </mesh>
          {/* windpipe */}
          <mesh position={[0, 2.6, 0]}>
            <cylinderGeometry args={[0.5, 0.5, 4.4, 18, 1, true]} />
            <meshStandardMaterial color="#bae6fd" transparent opacity={0.35} roughness={0.2} side={THREE.DoubleSide} />
          </mesh>
          {/* cartilage rings */}
          {[1.1, 1.7, 2.3, 2.9, 3.5, 4.1].map((y) => (
            <mesh key={y} position={[0, y, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.52, 0.06, 8, 20]} />
              <meshStandardMaterial color="#e0f2fe" roughness={0.5} />
            </mesh>
          ))}
          {/* ligature / water blockage */}
          <mesh ref={blockRef} position={[0, 4.35, 0]}>
            <torusGeometry args={[0.62, 0.14, 10, 24]} />
            <meshStandardMaterial color={cause === "drowning" ? "#38bdf8" : "#dc2626"} emissive={cause === "drowning" ? "#0ea5e9" : "#ef4444"} emissiveIntensity={0.7} />
          </mesh>
          {cause === "hanging" && (
            <mesh position={[0, 6.6, 0]}>
              <cylinderGeometry args={[0.07, 0.07, 1.6, 8]} />
              <meshStandardMaterial color="#a16207" roughness={0.8} />
            </mesh>
          )}
          {cause === "drowning" && (
            <mesh position={[0, 3.6, 0]}>
              <boxGeometry args={[1.15, 1.6, 1.15]} />
              <meshStandardMaterial color="#38bdf8" transparent opacity={0.55} roughness={0.15} />
            </mesh>
          )}
          {/* lungs */}
          {[-0.75, 0.75].map((x) => (
            <mesh key={x} position={[x, 0.75, 0]} castShadow>
              <sphereGeometry args={[0.62, 18, 18]} />
              <meshStandardMaterial color={flowPct > 20 ? "#f87171" : "#7f1d1d"} roughness={0.6} />
            </mesh>
          ))}
          <group ref={parts}>{dots}</group>
          <Arrow from={[-2.2, 5.6, 0]} to={[-1, 5.6, 0]} color="#7dd3fc" />
          <Label text="AIR IN" position={[-2.9, 6.1, 0]} size={0.55} color="#7dd3fc" />
          <Label text={cause === "drowning" ? "WATER IN AIRWAY" : "LIGATURE MARK"} position={[0, 5.15, 1]} size={0.6} color={cause === "drowning" ? "#38bdf8" : "#f87171"} />
          <Label text="LUNGS" position={[0, -0.25, 0]} size={0.6} color="#f87171" />
        </group>
        <Animator parts={parts} blockRef={blockRef} elapsed={elapsed} block={block} />
      </SimCanvas>
    </div>
  );
}
