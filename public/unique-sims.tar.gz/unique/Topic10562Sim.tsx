"use client";

// Cardiovascular: hypertension & ischemic heart disease.
// A beating heart with its great vessels. Raise the heart rate and
// watch the beat quicken — dental care must respect cardiac risk.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "bpm", label: "Heart rate", kind: "slider", min: 50, max: 140, step: 2, default: 72, unit: "bpm" },
];

export const UNIQUE_META = {
  title: "Heart: Hypertension & Ischemic Disease",
  blurb: "A beating heart with aorta and coronary arteries — feel how heart rate drives cardiac workload before dental treatment.",
};

type Ref = { current: THREE.Group | null };

function Animator({ heart, cells, elapsed, bpm }: { heart: Ref; cells: Ref; elapsed: { current: number }; bpm: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const e = elapsed.current;
    const rate = bpm / 60;
    // lub-dub pulse
    const ph = (e * rate) % 1;
    const beat = Math.pow(Math.max(0, Math.sin(ph * Math.PI * 2)), 6) + 0.5 * Math.pow(Math.max(0, Math.sin((ph - 0.18) * Math.PI * 2)), 8);
    const s = 1 + 0.1 * beat;
    if (heart.current) heart.current.scale.set(s, s, s);
    // blood cells riding the aortic arch
    cells.current?.children.forEach((m, i) => {
      const t = (e * rate * 0.55 + i / 10) % 1;
      const ang = Math.PI * 0.05 + t * Math.PI * 1.05;
      m.position.set(Math.cos(ang) * 0.62, 1.15 + Math.sin(ang) * 0.62, 0);
    });
  });
  return null;
}

export function Topic10562Sim(props: SimProps) {
  const bpm = Number(props.bpm ?? 72);
  const sys = Math.round(108 + (bpm - 60) * 0.55);
  const dia = Math.round(70 + (bpm - 60) * 0.2);
  const status = bpm < 100 ? "Normal rhythm" : bpm < 120 ? "Elevated — caution" : "Tachycardia — defer elective care";

  const heart = useRef<THREE.Group>(null!);
  const cells = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Heart rate", `${bpm} bpm`],
          ["Blood pressure", `≈ ${sys}/${dia} mmHg`],
          ["Status", status],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 10.5]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* heart muscle */}
        <group ref={heart} position={[0, 1.9, 0]}>
          <mesh position={[-0.28, 0.25, 0]} castShadow>
            <sphereGeometry args={[0.72, 24, 24]} />
            <meshStandardMaterial color="#dc2626" roughness={0.45} />
          </mesh>
          <mesh position={[0.38, 0.18, 0]} castShadow>
            <sphereGeometry args={[0.62, 24, 24]} />
            <meshStandardMaterial color="#dc2626" roughness={0.45} />
          </mesh>
          <mesh position={[0.02, -0.62, 0]} rotation={[0, 0, 0.15]} castShadow>
            <coneGeometry args={[0.6, 1.15, 20]} />
            <meshStandardMaterial color="#b91c1c" roughness={0.45} />
          </mesh>
          {/* coronary artery on the surface */}
          <mesh position={[0.05, 0.1, 0.68]} rotation={[0, 0, 0.5]}>
            <cylinderGeometry args={[0.06, 0.06, 1.3, 8]} />
            <meshStandardMaterial color="#f87171" roughness={0.4} />
          </mesh>
        </group>

        {/* aortic arch */}
        <mesh position={[0, 3.05, 0]} rotation={[0, 0, -0.15]} castShadow>
          <torusGeometry args={[0.62, 0.19, 14, 28, Math.PI * 1.15]} />
          <meshStandardMaterial color="#ef4444" roughness={0.4} />
        </mesh>
        {/* descending aorta */}
        <mesh position={[-0.62, 2.0, 0]} castShadow>
          <cylinderGeometry args={[0.19, 0.19, 1.6, 14]} />
          <meshStandardMaterial color="#ef4444" roughness={0.4} />
        </mesh>
        {/* pulmonary trunk + vena cava */}
        <mesh position={[0.55, 3.35, -0.15]} rotation={[0, 0, 0.5]} castShadow>
          <cylinderGeometry args={[0.15, 0.15, 0.9, 12]} />
          <meshStandardMaterial color="#3b82f6" roughness={0.4} />
        </mesh>
        <mesh position={[-0.1, 3.5, -0.3]} castShadow>
          <cylinderGeometry args={[0.16, 0.16, 1.0, 12]} />
          <meshStandardMaterial color="#3b82f6" roughness={0.4} />
        </mesh>

        {/* blood cells in the arch */}
        <group ref={cells}>
          {Array.from({ length: 10 }).map((_, i) => (
            <mesh key={i}>
              <sphereGeometry args={[0.09, 8, 8]} />
              <meshStandardMaterial color="#fecaca" emissive="#ef4444" emissiveIntensity={0.6} />
            </mesh>
          ))}
        </group>

        <Label text="Heart" position={[0, 0.75, 0]} size={0.55} color="#fca5a5" />
        <Label text="Aorta" position={[1.35, 3.6, 0]} size={0.45} color="#f87171" />
        <Label text="Coronary artery" position={[1.15, 2.0, 0.7]} size={0.4} color="#fca5a5" />
        <Label text="Ischemia = blocked coronaries" position={[0, 4.6, 0]} size={0.42} color="#94a3b8" />
        <Animator heart={heart} cells={cells} elapsed={elapsed} bpm={bpm} />
      </SimCanvas>
    </div>
  );
}
