"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "ptype", label: "Prosthesis", kind: "select", min: 0, max: 0, step: 1, default: "obturator", options: ["obturator", "ear", "nose"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Maxillofacial prosthetics: obturators, facial prostheses basics",
  blurb: "Prosthetics beyond teeth — an obturator bulb seals a palate defect, or a lifelike silicone ear / nose restores the face.",
};

const INFO: Record<string, { name: string; note: string; color: string }> = {
  obturator: { name: "Obturator", note: "Bulb plugs the palate hole — speech + swallowing back", color: "#f9a8d4" },
  ear: { name: "Auricular (ear) prosthesis", note: "Silicone ear on implants or adhesive", color: "#f2c9a0" },
  nose: { name: "Nasal prosthesis", note: "Silicone nose — colour-matched to skin", color: "#f2c9a0" },
};

function Scene({ ptype, speed }: { ptype: string; speed: number }) {
  const t = useRef(0);
  const prosthesis = useRef<THREE.Group>(null!);
  const info = INFO[ptype] ?? INFO.obturator;

  useFrame((_, delta) => {
    t.current += delta * speed;
    if (prosthesis.current) {
      const f = (Math.sin(t.current * 1.2) + 1) / 2;
      prosthesis.current.position.y = (ptype === "obturator" ? -0.8 : 0.6) + f * (ptype === "obturator" ? 1.3 : 0.8);
    }
  });

  return (
    <group>
      {ptype === "obturator" && (
        <>
          {/* palate with defect hole */}
          <mesh position={[0, 1.6, 0]} rotation={[Math.PI / 2.5, 0, 0]}>
            <circleGeometry args={[2.2, 24]} />
            <meshStandardMaterial color="#d98a94" roughness={0.6} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[0.5, 1.55, 0.35]}>
            <circleGeometry args={[0.7, 20]} />
            <meshStandardMaterial color="#1e293b" roughness={1} />
          </mesh>
          <Label text="Palate defect (hole)" position={[-2.6, 1.6, 0]} size={0.42} color="#fca5a5" />
          {/* obturator: denture base + bulb */}
          <group ref={prosthesis} position={[0.5, -0.8, 0.35]}>
            <mesh rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[1.9, 0.42, 12, 28, Math.PI]} />
              <meshStandardMaterial color="#f472b6" roughness={0.5} />
            </mesh>
            <mesh position={[0, 0.75, 0]}>
              <sphereGeometry args={[0.72, 18, 18]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.45} />
            </mesh>
            <Label text="Bulb seals the hole" position={[0, 1.9, 0]} size={0.42} color={info.color} />
          </group>
        </>
      )}

      {ptype !== "obturator" && (
        <>
          {/* face hint */}
          <mesh position={[0, 0, -0.8]}>
            <sphereGeometry args={[2.2, 24, 24]} />
            <meshStandardMaterial color="#e8b88a" roughness={0.65} />
          </mesh>
          <group ref={prosthesis} position={[ptype === "ear" ? -2.1 : 0, ptype === "ear" ? 0.3 : 0.1, 0.6]}>
            {ptype === "ear" ? (
              <group rotation={[0, Math.PI / 2.3, 0]}>
                <mesh scale={[1, 1.4, 0.55]}>
                  <sphereGeometry args={[0.65, 18, 18]} />
                  <meshStandardMaterial color="#f2c9a0" roughness={0.55} />
                </mesh>
                <mesh scale={[0.55, 0.9, 0.4]} position={[0, 0, 0.15]}>
                  <sphereGeometry args={[0.5, 14, 14]} />
                  <meshStandardMaterial color="#e0a878" roughness={0.6} />
                </mesh>
              </group>
            ) : (
              <group>
                <mesh position={[0, 0.2, 0.5]} rotation={[0.3, 0, 0]}>
                  <coneGeometry args={[0.42, 1.1, 14]} />
                  <meshStandardMaterial color="#f2c9a0" roughness={0.55} />
                </mesh>
                <mesh position={[0, -0.25, 0.75]}>
                  <sphereGeometry args={[0.3, 12, 12]} />
                  <meshStandardMaterial color="#e8b88a" roughness={0.6} />
                </mesh>
              </group>
            )}
            <Label text={info.name} position={[0, 1.6, 0]} size={0.45} color={info.color} />
          </group>
          {/* implant abutments */}
          {[0, 1].map((i) => (
            <mesh key={i} position={[ptype === "ear" ? -2.1 : -0.4 + i * 0.8, ptype === "ear" ? (i ? 1 : -0.4) : 0.9, 0.1]}>
              <cylinderGeometry args={[0.08, 0.08, 0.4, 8]} />
              <meshStandardMaterial color="#d4af37" metalness={0.8} roughness={0.3} />
            </mesh>
          ))}
          <Label text="Implant / adhesive retention" position={[0, -2.6, 0]} size={0.4} color="#94a3b8" />
        </>
      )}

      <Label text={info.name} position={[0, 3.6, 0]} size={0.6} color={info.color} />
      <Label text={info.note} position={[0, -3.3, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10440Sim(props: SimProps) {
  const ptype = String(props.ptype ?? "obturator");
  const speed = Number(props.speed ?? 1);
  const info = INFO[ptype] ?? INFO.obturator;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Prosthesis", info.name], ["Material", ptype === "obturator" ? "Acrylic" : "Medical silicone"], ["Made by", "Maxillofacial prosthodontist"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 10]} target={[0, 0.4, 0]}>
        <Scene ptype={ptype} speed={speed} />
      </SimCanvas>
    </div>
  );
}
