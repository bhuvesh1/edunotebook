"use client";
// Non-communicable diseases: prevention and control programs.
// A big shield guards the heart and lungs while risk-factor darts
// (tobacco, junk food, inactivity) bounce off — pick the threat.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "risk", label: "Risk factor", kind: "select", min: 0, max: 0, step: 1, default: "tobacco", options: ["tobacco", "junkfood", "inactivity"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "NCD Prevention: The Shield Against Lifestyle Disease",
  blurb: "Tobacco, junk food and laziness hurl darts at your heart — a healthy-lifestyle shield bounces every one off.",
};

const RISK_INFO: Record<string, { color: string; emoji: string; tip: string }> = {
  tobacco: { color: "#78716c", emoji: "🚬", tip: "Quit tobacco: lungs heal in months" },
  junkfood: { color: "#f59e0b", emoji: "🍔", tip: "Less sugar & oil: heart thanks you" },
  inactivity: { color: "#8b5cf6", emoji: "🛋", tip: "30 min walk daily beats inactivity" },
};

function Animator({ darts, shield, elapsed, speed }: { darts: React.RefObject<THREE.Group>; shield: React.RefObject<THREE.Mesh>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (darts.current) {
      darts.current.children.forEach((d, i) => {
        const ph = (elapsed.current * 0.55 + i * 0.33) % 1;
        // flies in, then bounces off the shield
        const x = -6 + ph * 9;
        const bounce = ph > 0.62 ? Math.sin((ph - 0.62) * 12) * 0.7 : 0;
        d.position.x = ph > 0.62 ? -6 + 0.62 * 9 - (ph - 0.62) * 6 : x;
        d.position.y = 2.6 + Math.sin(i * 2.2) * 1.1 + bounce;
        d.rotation.z = ph > 0.62 ? 2.2 : -Math.PI / 2;
      });
    }
    if (shield.current) {
      const s = 1 + Math.sin(elapsed.current * 2) * 0.03;
      shield.current.scale.set(s, s, 1);
    }
  });
  return null;
}

export function Topic10172Sim(props: SimProps) {
  const risk = String(props.risk ?? "tobacco");
  const speed = Number(props.speed ?? 1);
  const darts = useRef<THREE.Group>(null!);
  const shield = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const info = RISK_INFO[risk] ?? RISK_INFO.tobacco;

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Threat", risk], ["Defence", info.tip]]} />
      <SimCanvas cameraPosition={[0, 3.4, 13]} target={[0, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* organs behind the shield */}
        <group position={[2.4, 2.4, -0.8]}>
          <mesh position={[-0.5, 0.4, 0]} castShadow>
            <sphereGeometry args={[0.62, 18, 18]} />
            <meshStandardMaterial color="#ef4444" roughness={0.5} />
          </mesh>
          <mesh position={[0.5, 0.4, 0]} castShadow>
            <sphereGeometry args={[0.62, 18, 18]} />
            <meshStandardMaterial color="#ef4444" roughness={0.5} />
          </mesh>
          <mesh position={[0, -0.35, 0]} rotation={[0, 0, Math.PI]}>
            <coneGeometry args={[0.85, 1, 18]} />
            <meshStandardMaterial color="#ef4444" roughness={0.5} />
          </mesh>
          <Label text="HEART" position={[0, -1.6, 0]} size={0.55} color="#f87171" />
          {[-1.3, 1.3].map((x) => (
            <mesh key={x} position={[x, 1.9, 0]} castShadow>
              <sphereGeometry args={[0.5, 14, 14]} />
              <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
            </mesh>
          ))}
          <Label text="LUNGS" position={[0, 2.9, 0]} size={0.55} color="#f9a8d4" />
        </group>
        {/* shield */}
        <mesh ref={shield} position={[2.4, 2.4, 0.4]} castShadow>
          <sphereGeometry args={[2.4, 4, 3, 0, Math.PI * 2, 0, Math.PI * 0.62]} />
          <meshStandardMaterial color="#38bdf8" transparent opacity={0.32} roughness={0.2} emissive="#0ea5e9" emissiveIntensity={0.5} side={THREE.DoubleSide} />
        </mesh>
        <Label text="HEALTHY LIFESTYLE" position={[2.4, 5.4, 0]} size={0.6} color="#7dd3fc" />
        {/* incoming risk darts */}
        <group ref={darts}>
          {[0, 1, 2].map((i) => (
            <group key={i} position={[-6, 2.6, 0]}>
              <mesh rotation={[0, 0, -Math.PI / 2]}>
                <cylinderGeometry args={[0.09, 0.09, 1.2, 8]} />
                <meshStandardMaterial color={info.color} roughness={0.6} />
              </mesh>
              <mesh position={[0.75, 0, 0]} rotation={[0, 0, -Math.PI / 2]}>
                <coneGeometry args={[0.2, 0.4, 8]} />
                <meshStandardMaterial color={info.color} emissive={info.color} emissiveIntensity={0.5} />
              </mesh>
            </group>
          ))}
        </group>
        <Label text={`${info.emoji} ${risk.toUpperCase()} ATTACKS`} position={[-4.6, 4.6, 0]} size={0.6} color={info.color} />
        <Animator darts={darts} shield={shield} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
