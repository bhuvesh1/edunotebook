// app/components/sims/unique/Topic7093Sim.tsx
// Kinematic equations: a ball dropped from a tower under constant g.
// Glowing rings freeze its position every 0.5 s — the gaps grow because
// s = ½gt². Live readouts show t, v = gt and s = ut + ½at².

"use client";

import { useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "gravity", label: "Gravity", kind: "slider", min: 1, max: 20, step: 0.5, default: 9.8, unit: "m/s²" },
];

export const UNIQUE_META = {
  title: "Kinematic Equations",
  blurb: "A dropped ball under constant gravity — rings mark every 0.5 s and the gaps grow as s = ½gt².",
};

const H = 6.4; // drop height (scene units)
const MARKS = 8;
const MARK_DT = 0.5;

function Animator({
  ball,
  rings,
  g,
  state,
  bump,
}: {
  ball: RefObject<THREE.Mesh>;
  rings: RefObject<THREE.Group>;
  g: number;
  state: RefObject<{ t: number; v: number; s: number }>;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const fallTime = Math.sqrt((2 * H) / g);
    const cycle = fallTime + 1.2;
    const T = t.current % cycle;
    const s = T <= fallTime ? 0.5 * g * T * T : H;
    const v = T <= fallTime ? g * T : 0;
    state.current = { t: T, v, s };
    if (ball.current) ball.current.position.y = 0.4 + H - s;
    if (rings.current) {
      const kids = rings.current.children;
      for (let k = 1; k <= MARKS; k++) {
        const rk = kids[k - 1];
        const tk = k * MARK_DT;
        if (T >= tk && tk <= fallTime) {
          rk.visible = true;
          rk.position.y = 0.4 + H - 0.5 * g * tk * tk;
        } else rk.visible = false;
      }
    }
    if (++n.current % 12 === 0) bump();
  });
  return null;
}

export function Topic7093Sim(props: SimProps) {
  const g = Number(props.gravity ?? 9.8);
  const ball = useRef<THREE.Mesh>(null!);
  const rings = useRef<THREE.Group>(null!);
  const state = useRef({ t: 0, v: 0, s: 0 });
  const [, bump] = useState(0);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["t", `${state.current.t.toFixed(2)} s`],
          ["v = gt", `${state.current.v.toFixed(1)} m/s`],
          ["s = ½gt²", `${state.current.s.toFixed(2)} m`],
          ["🟡 Rings", "position every 0.5 s"],
        ]}
      />
      <SimCanvas cameraPosition={[4, 4.5, 12]} target={[0, 3.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* tower */}
        <mesh position={[-2.2, 3.4, 0]} castShadow>
          <boxGeometry args={[1.6, 6.8, 1.6]} />
          <meshStandardMaterial color="#64748b" roughness={0.7} />
        </mesh>
        <mesh position={[-2.2, 7.0, 0]} castShadow>
          <boxGeometry args={[2.2, 0.4, 2.2]} />
          <meshStandardMaterial color="#475569" roughness={0.7} />
        </mesh>
        {/* drop guide line */}
        <primitive
          object={
            new THREE.Line(
              new THREE.BufferGeometry().setFromPoints([
                new THREE.Vector3(0.6, 0.4, 0),
                new THREE.Vector3(0.6, 0.4 + H, 0),
              ]),
              new THREE.LineBasicMaterial({ color: "#475569", transparent: true, opacity: 0.5 })
            )
          }
        />
        {/* time-marker rings */}
        <group ref={rings}>
          {Array.from({ length: MARKS }, (_, i) => (
            <mesh key={i} visible={false} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.42, 0.06, 10, 24]} />
              <meshStandardMaterial color="#fbbf24" emissive="#b45309" emissiveIntensity={0.8} />
            </mesh>
          ))}
        </group>
        {/* the falling ball */}
        <mesh ref={ball} position={[0.6, 0.4 + H, 0]} castShadow>
          <sphereGeometry args={[0.38, 28, 28]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.35} />
        </mesh>

        <Animator ball={ball} rings={rings} g={g} state={state} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
