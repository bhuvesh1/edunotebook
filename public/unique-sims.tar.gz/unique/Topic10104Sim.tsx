"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "cond", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "sunburn", options: ["normal", "sunburn", "melanoma"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Skin Layers & Sun Damage",
  blurb: "Three skin layers under UV attack: sunburn reddens them while a melanoma mole grows on top.",
};

function Animator({ root, uv, red, mole, elapsed, speed, burn, mel }: { root: RefObject<THREE.Group>; uv: RefObject<THREE.Group>; red: RefObject<THREE.Mesh>; mole: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; burn: boolean; mel: boolean }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (uv.current) {
      uv.current.children.forEach((m, i) => {
        ((m as THREE.Mesh).material as THREE.MeshStandardMaterial).emissiveIntensity = 0.8 + 0.7 * Math.sin(t * 3 + i * 1.4);
        m.position.y = 4.6 + Math.sin(t * 2 + i) * 0.15;
      });
    }
    if (red.current) {
      red.current.visible = burn;
      (red.current.material as THREE.MeshStandardMaterial).opacity = 0.3 + 0.14 * Math.sin(t * 2.5);
    }
    if (mole.current) {
      mole.current.visible = mel;
      const s = 0.7 + 0.3 * Math.sin(t * 1.2);
      mole.current.scale.set(s * 1.2, s * 0.55, s);
    }
  });
  return null;
}

export function Topic10104Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const cond = String(props.cond ?? "sunburn");
  const burn = cond === "sunburn";
  const mel = cond === "melanoma";
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const uv = useRef<THREE.Group>(null!);
  const red = useRef<THREE.Mesh>(null!);
  const mole = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Condition", cond],
          ["UV", "ultraviolet B \u2014 DNA damage"],
          ["ABCDE", mel ? "asymmetry \u00b7 border \u00b7 color \u00b7 diameter" : "\u2014"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.4, 11]} target={[0, 1.9, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 1.05, 0]} castShadow>
            <boxGeometry args={[7, 0.9, 3.4]} /><meshStandardMaterial color="#fde68a" roughness={0.7} />
          </mesh>
          <Label text="subcutaneous fat" position={[3.9, 1.05, 0]} size={0.38} color="#fde68a" />
          <mesh position={[0, 1.95, 0]} castShadow>
            <boxGeometry args={[7, 0.9, 3.4]} /><meshStandardMaterial color="#f9a8d4" roughness={0.65} />
          </mesh>
          {[-2, 0, 2].map((x) => (
            <mesh key={x} position={[x, 1.95, 0.8]} castShadow>
              <cylinderGeometry args={[0.12, 0.16, 0.8, 8]} /><meshStandardMaterial color="#7c2d12" roughness={0.6} />
            </mesh>
          ))}
          <Label text="dermis + hair follicles" position={[-3.9, 1.95, 0]} size={0.38} color="#f9a8d4" />
          <mesh position={[0, 2.55, 0]} castShadow>
            <boxGeometry args={[7, 0.3, 3.4]} /><meshStandardMaterial color="#fdba74" roughness={0.6} />
          </mesh>
          <Label text="epidermis" position={[3.9, 2.55, 0]} size={0.38} color="#fdba74" />
          <group ref={uv}>
            {[-2.4, -1.2, 0, 1.2, 2.4].map((x, i) => (
              <mesh key={i} position={[x, 4.6, 0]} rotation={[0, 0, 0.25]}>
                <cylinderGeometry args={[0.09, 0.09, 1.6, 8]} />
                <meshStandardMaterial color="#fde047" emissive="#facc15" emissiveIntensity={0.8} transparent opacity={0.85} />
              </mesh>
            ))}
          </group>
          <Label text="UV rays" position={[-3.4, 5.2, 0]} size={0.4} color="#fde047" />
          <mesh ref={red} visible={false} position={[0, 2.62, 0]}>
            <boxGeometry args={[7, 0.36, 3.4]} />
            <meshStandardMaterial color="#ef4444" transparent opacity={0.3} emissive="#b91c1d" emissiveIntensity={0.6} />
          </mesh>
          <mesh ref={mole} visible={false} position={[1.4, 2.78, 0.6]} castShadow>
            <sphereGeometry args={[0.5, 18, 18]} /><meshStandardMaterial color="#1c0a0a" roughness={0.4} />
          </mesh>
          <Label text={burn ? "sunburn \u2014 UV inflammation" : mel ? "melanoma \u2014 ABCDE warning signs" : "healthy skin"} position={[0, 6, 0]} size={0.46} color={cond === "normal" ? "#4ade80" : "#f87171"} />
        </group>
        <Animator root={root} uv={uv} red={red} mole={mole} elapsed={elapsed} speed={speed} burn={burn} mel={mel} />
      </SimCanvas>
    </div>
  );
}
