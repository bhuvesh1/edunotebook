"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "alloy", label: "Alloy", kind: "select", min: 0, max: 0, step: 1, default: "noble", options: ["noble", "base"] },
  { key: "heat", label: "Furnace heat", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.7, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Metals and alloys: noble and base metal alloys, casting",
  blurb: "Melt gold or chrome-cobalt in the crucible, then sling the molten metal into the mold with the centrifugal casting arm.",
};

const ALLOYS: Record<string, { name: string; color: string; melt: string; note: string }> = {
  noble: { name: "Noble alloy (Au–Pt)", color: "#fbbf24", melt: "~1100 °C", note: "gold-based — kind to tissue, pricey" },
  base: { name: "Base metal (Co–Cr)", color: "#cbd5e1", melt: "~1400 °C", note: "stiff, light — partial denture frames" },
};

function Crucible({ alloy, heat, speed }: { alloy: string; heat: number; speed: number }) {
  const melt = useRef<THREE.Mesh>(null!);
  const glow = useRef<THREE.PointLight>(null!);
  const elapsed = useRef(0);
  const cfg = ALLOYS[alloy] ?? ALLOYS.noble;
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (melt.current) {
      const m = melt.current.material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = heat * (2.2 + Math.sin(elapsed.current * 6) * 0.5);
      melt.current.position.y = 0.1 + Math.sin(elapsed.current * 3) * 0.02 * heat;
    }
    if (glow.current) glow.current.intensity = heat * 30;
  });
  return (
    <group position={[-3.6, 0.6, 0]}>
      {/* crucible cup */}
      <mesh castShadow>
        <cylinderGeometry args={[1.3, 0.9, 1.4, 20, 1, true]} />
        <meshStandardMaterial color="#57534e" roughness={0.8} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[0, -0.7, 0]}>
        <circleGeometry args={[0.9, 20]} />
        <meshStandardMaterial color="#44403c" roughness={0.8} />
      </mesh>
      {/* molten metal surface */}
      <mesh ref={melt} position={[0, 0.1, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[1.15, 24]} />
        <meshStandardMaterial color={cfg.color} emissive={heat > 0.5 ? "#f97316" : "#000000"} emissiveIntensity={2} roughness={0.15} metalness={0.9} />
      </mesh>
      {/* furnace glow */}
      <pointLight ref={glow} position={[0, 1.5, 0]} color="#fb923c" intensity={heat * 30} distance={10} />
      {/* heat shimmer particles */}
      {heat > 0.4 &&
        Array.from({ length: 10 }).map((_, i) => (
          <mesh key={i} position={[(Math.random() - 0.5) * 1.6, 0.8 + (i % 5) * 0.35, (Math.random() - 0.5) * 1.6]}>
            <sphereGeometry args={[0.07, 8, 8]} />
            <meshBasicMaterial color="#fdba74" transparent opacity={0.7} />
          </mesh>
        ))}
    </group>
  );
}

function CastingArm({ heat, speed }: { heat: number; speed: number }) {
  const arm = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (arm.current && heat > 0.55) arm.current.rotation.y = elapsed.current * (1 + heat * 2);
  });
  return (
    <group position={[2.6, 0.6, 0]}>
      {/* central spindle */}
      <mesh position={[0, 0, 0]} castShadow>
        <cylinderGeometry args={[0.4, 0.5, 2.6, 14]} />
        <meshStandardMaterial color="#475569" metalness={0.6} roughness={0.4} />
      </mesh>
      <group ref={arm}>
        {/* arm */}
        <mesh position={[1.8, 0.9, 0]} castShadow>
          <boxGeometry args={[3.6, 0.3, 0.5]} />
          <meshStandardMaterial color="#64748b" metalness={0.6} roughness={0.4} />
        </mesh>
        {/* mold ring at arm end */}
        <mesh position={[3.4, 0.9, 0]} castShadow>
          <cylinderGeometry args={[0.8, 0.8, 1.2, 18]} />
          <meshStandardMaterial color="#a8a29e" roughness={0.6} />
        </mesh>
        {/* counterweight */}
        <mesh position={[-1.4, 0.9, 0]} castShadow>
          <boxGeometry args={[1, 0.8, 0.8]} />
          <meshStandardMaterial color="#334155" metalness={0.6} roughness={0.4} />
        </mesh>
      </group>
    </group>
  );
}

export function Topic10395Sim(props: SimProps) {
  const alloy = String(props.alloy ?? "noble");
  const heat = Number(props.heat ?? 0.7);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = ALLOYS[alloy] ?? ALLOYS.noble;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Alloy", cfg.name],
          ["Melting ~", cfg.melt],
          ["Cast", heat > 0.55 ? "spinning — metal forced in ✓" : "heat the metal first"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 13]} target={[0, 0.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.2, 0]} receiveShadow>
          <planeGeometry args={[36, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <Crucible alloy={alloy} heat={heat} speed={speed} />
        <CastingArm heat={heat} speed={speed} />
        {showLabels && (
          <>
            <Text position={[-3.6, 3.4, 0]} fontSize={0.44} color="#fdba74">Crucible — molten {alloy === "noble" ? "gold" : "Co–Cr"}</Text>
            <Text position={[2.6, 3.4, 0]} fontSize={0.44} color="#94a3b8">Centrifugal casting arm</Text>
            <Text position={[0, -2.6, 0]} fontSize={0.42} color="#e2e8f0" maxWidth={11}>{cfg.note}</Text>
          </>
        )}
      </SimCanvas>
    </div>
  );
}
