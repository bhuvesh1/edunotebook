"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "bone", label: "Bone type", kind: "select", min: 0, max: 0, step: 1, default: "long", options: ["long", "short", "flat", "irregular"] },
  { key: "speed", label: "Rotation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 0.6, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Bones: classification, structure, ossification",
  blurb: "Four bone shapes on the turntable: long, short, flat and irregular — long bones show epiphysis, diaphysis and marrow.",
};

function LongBone() {
  return (
    <group>
      {/* diaphysis shaft */}
      <mesh position={[0, 2.4, 0]} castShadow>
        <cylinderGeometry args={[0.42, 0.42, 3.2, 18]} />
        <meshStandardMaterial color="#f5f0e6" roughness={0.55} />
      </mesh>
      {/* epiphyses */}
      <mesh position={[0, 4.35, 0]} castShadow>
        <sphereGeometry args={[0.75, 20, 20]} />
        <meshStandardMaterial color="#efe8d8" roughness={0.55} />
      </mesh>
      <mesh position={[0, 0.45, 0]} castShadow>
        <sphereGeometry args={[0.7, 20, 20]} />
        <meshStandardMaterial color="#efe8d8" roughness={0.55} />
      </mesh>
      {/* marrow cavity hint */}
      <mesh position={[0, 2.4, 0]}>
        <cylinderGeometry args={[0.2, 0.2, 2.8, 12]} />
        <meshStandardMaterial color="#dc2626" emissive="#991b1b" emissiveIntensity={0.4} roughness={0.5} />
      </mesh>
      {/* growth plate */}
      <mesh position={[0, 3.85, 0]}>
        <cylinderGeometry args={[0.5, 0.5, 0.12, 18]} />
        <meshStandardMaterial color="#93c5fd" roughness={0.5} />
      </mesh>
    </group>
  );
}

function BoneModel({ bone }: { bone: string }) {
  const g = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const speed = 0.6;
  useFrame((_, d) => {
    t.current += d * speed;
    if (g.current) g.current.rotation.y = t.current * 0.8;
  });
  void speed;
  return (
    <group ref={g} position={[0, 0.4, 0]}>
      {bone === "long" && <LongBone />}
      {bone === "short" && (
        <mesh position={[0, 2.4, 0]} castShadow>
          <boxGeometry args={[1.8, 1.8, 1.8]} />
          <meshStandardMaterial color="#f5f0e6" roughness={0.55} />
        </mesh>
      )}
      {bone === "flat" && (
        <mesh position={[0, 2.4, 0]} rotation={[0.2, 0, 0]} castShadow>
          <boxGeometry args={[3.2, 2.4, 0.35]} />
          <meshStandardMaterial color="#f5f0e6" roughness={0.55} />
        </mesh>
      )}
      {bone === "irregular" && (
        <group position={[0, 2.4, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.55, 0.55, 1.4, 14]} />
            <meshStandardMaterial color="#f5f0e6" roughness={0.55} />
          </mesh>
          <mesh position={[0, 0.2, -0.7]} rotation={[0.5, 0, 0]} castShadow>
            <boxGeometry args={[0.35, 1.4, 0.3]} />
            <meshStandardMaterial color="#efe8d8" roughness={0.55} />
          </mesh>
          {[-0.6, 0.6].map((x) => (
            <mesh key={x} position={[x, 0.5, 0.4]} rotation={[0, 0, x > 0 ? -0.6 : 0.6]} castShadow>
              <boxGeometry args={[0.3, 1.2, 0.3]} />
              <meshStandardMaterial color="#efe8d8" roughness={0.55} />
            </mesh>
          ))}
        </group>
      )}
    </group>
  );
}

export function Topic10000Sim(props: SimProps) {
  const bone = String(props.bone ?? "long");
  const showLabels = String(props.detail ?? "on") === "on";
  const names: Record<string, string> = { long: "femur-like", short: "carpal-like", flat: "skull-like", irregular: "vertebra-like" };
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Type", bone + " bone"], ["Example", names[bone] ?? ""], ["Tissue", "compact + spongy"]]} />
      <SimCanvas cameraPosition={[5, 4, 10]} target={[0, 2.4, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <BoneModel bone={bone} />
        {showLabels && bone === "long" && (
          <>
            <Label text="Epiphysis" position={[-2.4, 4.9, 0]} color="#fef3c7" size={0.5} />
            <Label text="Diaphysis" position={[2.2, 2.8, 0]} color="#fef3c7" size={0.5} />
            <Label text="Marrow" position={[-2.2, 1.8, 0]} color="#fca5a5" size={0.5} />
          </>
        )}
        {showLabels && bone !== "long" && <Label text={bone + " bone"} position={[0, 5.2, 0]} color="#fef3c7" size={0.55} />}
      </SimCanvas>
    </div>
  );
}
