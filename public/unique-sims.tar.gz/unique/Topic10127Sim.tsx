// Drugs in pregnancy & age groups: a mother and child stand by the placental
// barrier — drug molecules try to cross while the dose dial adjusts for the
// patient group.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "group", label: "Patient group", kind: "select", min: 0, max: 0, step: 1, default: "adult", options: ["adult", "pregnant", "child", "elderly"] },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Drugs in pregnancy & age groups",
  blurb: "Drug molecules meet the placental barrier — doses must change for pregnancy, children and the elderly.",
};

const N_DX = 10;
const INFO: Record<string, { cross: number; dose: string; note: string }> = {
  adult: { cross: 0.5, dose: "100%", note: "standard dose" },
  pregnant: { cross: 0.35, dose: "avoid / lowest", note: "placenta blocks some drug" },
  child: { cross: 0.5, dose: "~50% (weight-based)", note: "dose by body weight" },
  elderly: { cross: 0.5, dose: "~50-75%", note: "slower kidney clearance" },
};

function Animator({ dx, barrier, mom, elapsed, group, setTick }: {
  dx: React.RefObject<(THREE.Mesh | null)[]>;
  barrier: React.RefObject<THREE.Mesh>;
  mom: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  group: string;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const cross = INFO[group]?.cross ?? 0.5;
    let crossed = 0;
    dx.current.forEach((d, i) => {
      if (!d) return;
      const f = (t * 0.35 + i / N_DX) % 1;
      // travel left->right toward the placenta at x=1.2
      const x = -4.5 + f * 8;
      d.position.set(x, 2.1 + Math.sin(t * 2 + i * 2.2) * 0.35, 0);
      const passes = ((i * 43) % 10) / 10 < cross;
      if (x > 1.2) {
        if (passes) {
          crossed++;
          ((d as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = 1 - (x - 1.2) * 0.25;
        } else {
          // blocked: bounce back and fade
          d.position.x = 1.2 - (x - 1.2) * 0.6;
          ((d as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = Math.max(0, 0.9 - (x - 1.2) * 0.5);
        }
      } else {
        ((d as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = 0.95;
      }
      d.rotation.y = t * 3 + i;
    });
    if (barrier.current) {
      (barrier.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.4 + Math.sin(t * 2.5) * 0.25;
    }
    if (mom.current) mom.current.position.y = Math.sin(t * 1.4) * 0.05;
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(crossed); }
  });
  return null;
}

function Figure({ scale = 1, color, x }: { scale?: number; color: string; x: number }) {
  return (
    <group position={[x, 0, 0]} scale={scale}>
      <mesh position={[0, 1.05, 0]} castShadow>
        <capsuleGeometry args={[0.4, 0.9, 8, 14]} />
        <meshStandardMaterial color={color} roughness={0.6} />
      </mesh>
      <mesh position={[0, 2.05, 0]} castShadow>
        <sphereGeometry args={[0.3, 16, 12]} />
        <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
      </mesh>
    </group>
  );
}

export function Topic10127Sim(props: SimProps) {
  const group = String(props.group ?? "adult");
  const showLabels = String(props.detail ?? "on") === "on";
  const dx = useRef<(THREE.Mesh | null)[]>([]);
  const barrier = useRef<THREE.Mesh>(null!);
  const mom = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const info = INFO[group] ?? INFO.adult;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Group", group],
          ["Dose rule", info.dose],
          ["Molecules crossing", `${tick}/${N_DX}`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.5, 12]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 22]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* mother */}
        <group ref={mom}>
          <Figure x={-2.6} color="#f472b6" />
          {/* baby bump */}
          <mesh position={[-2.25, 1.05, 0.35]} castShadow>
            <sphereGeometry args={[0.32, 16, 12]} />
            <meshStandardMaterial color="#f472b6" roughness={0.6} />
          </mesh>
        </group>
        {showLabels && <Label text="mother" position={[-2.6, 2.9, 0]} color="#f9a8d4" />}

        {/* placenta barrier */}
        <mesh ref={barrier} position={[1.2, 1.9, 0]}>
          <boxGeometry args={[0.28, 3.4, 2.6]} />
          <meshStandardMaterial color="#a855f7" emissive="#7e22ce" emissiveIntensity={0.5} transparent opacity={0.55} />
        </mesh>
        {showLabels && <Label text="placenta barrier" position={[1.2, 4, 0]} color="#d8b4fe" />}

        {/* fetus */}
        <group position={[3.4, 1.1, 0]} scale={0.55}>
          <mesh position={[0, 0.6, 0]} castShadow>
            <sphereGeometry args={[0.5, 16, 12]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
          <mesh position={[0, 1.25, 0]}>
            <sphereGeometry args={[0.32, 16, 12]} />
            <meshStandardMaterial color="#fcd9b8" roughness={0.6} />
          </mesh>
        </group>
        {showLabels && <Label text="fetus" position={[3.4, 2.4, 0]} size={0.45} color="#fde68a" />}

        {/* child & elderly figures */}
        <Figure x={-4.6} scale={0.55} color="#38bdf8" />
        {showLabels && <Label text="child" position={[-4.6, 1.8, 0]} size={0.4} color="#7dd3fc" />}
        <Figure x={5.2} scale={0.95} color="#94a3b8" />
        {showLabels && <Label text="elderly" position={[5.2, 2.75, 0]} size={0.4} color="#cbd5e1" />}

        {/* drug molecules */}
        {Array.from({ length: N_DX }).map((_, i) => (
          <mesh key={i} ref={(m) => { dx.current[i] = m; }}>
            <icosahedronGeometry args={[0.15]} />
            <meshStandardMaterial color="#f97316" emissive="#c2410c" emissiveIntensity={0.9} transparent />
          </mesh>
        ))}
        {showLabels && <Label text="drug molecules" position={[-4.5, 3.1, 0]} size={0.45} color="#fdba74" />}
        {showLabels && <Label text={info.note} position={[0, 4.9, 0]} color="#fef08a" />}

        <Animator dx={dx} barrier={barrier} mom={mom} elapsed={elapsed} group={group} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
