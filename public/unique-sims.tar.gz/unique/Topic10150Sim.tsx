"use client";
// Legal procedures: inquest, courts, medical evidence.
// A courthouse with columns, an animated gavel striking its block,
// and the scales of justice — the three stops of a medico-legal case.


import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Case stage", kind: "select", min: 0, max: 0, step: 1, default: "court", options: ["inquest", "court", "evidence"] },
  { key: "speed", label: "Gavel speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Legal Procedures: Inquest, Courts, Medical Evidence",
  blurb: "A courthouse, a striking gavel and the scales of justice trace a medico-legal case from inquest to evidence.",
};

function Animator({ gavel, elapsed, speed }: { gavel: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; speed: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    // gavel strikes twice per cycle
    const strike = Math.abs(Math.sin(t * 2.2));
    if (gavel.current) {
      gavel.current.rotation.z = -0.15 - strike * 0.9;
      gavel.current.position.y = 2.1 - strike * 0.55;
    }
  });
  return null;
}

export function Topic10150Sim(props: SimProps) {
  const stage = String(props.stage ?? "court");
  const speed = Number(props.speed ?? 1);
  const gavel = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const stageLabel = stage === "inquest" ? "Inquest: cause of death" : stage === "evidence" ? "Evidence: medical reports" : "Court: trial";

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Stage", stage], ["Gavel", `${speed.toFixed(1)}×`]]} />
      <SimCanvas cameraPosition={[0, 4.5, 13]} target={[0, 2.5, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* courthouse: steps, columns, pediment */}
        <group position={[-3.4, 0, -2]}>
          {[-1.2, 0, 1.2].map((x, i) => (
            <mesh key={x} position={[x * 1.4, 0.35 + i * 0.25, 0]} castShadow>
              <boxGeometry args={[5.2 - i * 0.7, 0.25, 3.4]} />
              <meshStandardMaterial color="#64748b" roughness={0.8} />
            </mesh>
          ))}
          {[-1.9, -0.65, 0.65, 1.9].map((x) => (
            <mesh key={x} position={[x, 2.6, 0]} castShadow>
              <cylinderGeometry args={[0.28, 0.34, 3.6, 14]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.6} />
            </mesh>
          ))}
          <mesh position={[0, 4.75, 0]} castShadow>
            <boxGeometry args={[5.4, 0.5, 3.6]} />
            <meshStandardMaterial color="#94a3b8" roughness={0.7} />
          </mesh>
          <mesh position={[0, 5.6, 0]} castShadow>
            <coneGeometry args={[3.6, 1.4, 4]} />
            <meshStandardMaterial color="#b45309" roughness={0.7} />
          </mesh>
          <Label text="COURT" position={[0, 3.4, 1.9]} size={0.7} color="#fbbf24" />
        </group>
        {/* judge's bench + striking gavel */}
        <group position={[3.6, 0, 0]}>
          <mesh position={[0, 0.6, 0]} castShadow>
            <boxGeometry args={[3, 1.2, 1.6]} />
            <meshStandardMaterial color="#7c2d12" roughness={0.7} />
          </mesh>
          <mesh position={[0, 1.32, 0]}>
            <cylinderGeometry args={[0.45, 0.45, 0.12, 20]} />
            <meshStandardMaterial color="#a16207" roughness={0.5} />
          </mesh>
          <group ref={gavel} position={[0, 2.1, 0]}>
            <mesh position={[0.7, 0, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
              <cylinderGeometry args={[0.09, 0.09, 1.6, 10]} />
              <meshStandardMaterial color="#92400e" roughness={0.6} />
            </mesh>
            <mesh position={[-0.25, 0, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
              <cylinderGeometry args={[0.28, 0.28, 0.7, 14]} />
              <meshStandardMaterial color="#b45309" roughness={0.5} />
            </mesh>
          </group>
          <Label text="GAVEL" position={[0, 3.3, 0]} size={0.55} color="#fbbf24" />
        </group>
        {/* scales of justice */}
        <group position={[0.4, 0, 2.6]}>
          <mesh position={[0, 1.1, 0]} castShadow>
            <cylinderGeometry args={[0.08, 0.12, 2.2, 10]} />
            <meshStandardMaterial color="#fbbf24" metalness={0.7} roughness={0.3} />
          </mesh>
          <mesh position={[0, 2.25, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
            <cylinderGeometry args={[0.06, 0.06, 2.4, 10]} />
            <meshStandardMaterial color="#fbbf24" metalness={0.7} roughness={0.3} />
          </mesh>
          {[-1.2, 1.2].map((x) => (
            <mesh key={x} position={[x, 1.75, 0]}>
              <cylinderGeometry args={[0.42, 0.3, 0.18, 16]} />
              <meshStandardMaterial color="#fde68a" metalness={0.6} roughness={0.35} />
            </mesh>
          ))}
          <Label text="JUSTICE" position={[0, 3.1, 0]} size={0.55} color="#fde68a" />
        </group>
        <Label text={stageLabel} position={[0, 6.6, 0]} size={0.75} color="#93c5fd" />
        <Animator gavel={gavel} elapsed={elapsed} speed={speed} />
      </SimCanvas>
    </div>
  );
}
