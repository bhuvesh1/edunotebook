"use client";
// Retention and Relapse — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "retainer", label: "Retainer", kind: "select", min: 0, max: 0, step: 1, default: "Wearing retainer", options: ["Wearing retainer", "No retainer"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Retention and Relapse",
  blurb: "Braces off! With a retainer the smile stays put — without one, watch the teeth drift back toward crooked.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const held = p.retainer === "Wearing retainer";
    const drift = held ? 0 : (0.5 + 0.5 * Math.sin(t * 0.6)) * 0.4;
    for (let i = 0; i < 6; i++) {
      const th: any = g("rth" + i);
      if (th) th.rotation.z = drift * (i % 2 === 0 ? 1 : -1) * (0.5 + i * 0.15);
    }
    const rw: any = g("retwire");
    if (rw) rw.visible = held;
    const warn: any = g("relapsewarn");
    if (warn) warn.visible = !held;
  });
  return null;
}

export function Topic10471Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const retainer = String(props.retainer ?? "Wearing retainer");
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, retainer };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Retainer", retainer],
          ["Relapse", retainer === "Wearing retainer" ? "0 mm — held!" : "Teeth drifting…"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          {[-2.5, -1.5, -0.5, 0.5, 1.5, 2.5].map((x, i) => (
            <group key={i} name={"rth" + i} position={[x, 1.2, 0]}>
              <mesh>
                <boxGeometry args={[0.9, 1.5, 0.9]} />
                <meshStandardMaterial color={i === 2 ? "#fbbf24" : "#f1e9d2"} roughness={0.4} />
              </mesh>
            </group>
          ))}
          <group name="retwire" position={[0, 1.1, -0.55]}>
            <Wire points={[[-2.9, 0, 0], [-1, 0.06, 0], [1, 0.06, 0], [2.9, 0, 0]]} color="#94a3b8" radius={0.045} />
          </group>
          <GumSlab position={[0, 0.15, -0.3]} scale={1.25} />
          <group name="relapsewarn" visible={false}>
            <Label text="Relapsing without retainer!" position={[0, 3.1, 0]} size={0.46} color="#ef4444" />
          </group>
          <Label text="Lingual retainer wire" position={[0, 0.35, -1.6]} size={0.4} color="#94a3b8" />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
