"use client";

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import { Arrow } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "stage", label: "Cancer stage", kind: "select", min: 0, max: 0, step: 1, default: "II", options: ["I", "II", "III", "IV"] },
  { key: "speed", label: "Spread animation", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Oral squamous cell carcinoma: pathology, staging, spread",
  blurb: "Ulcerated tumour mass growing through mouth tissue, with cancer cells spreading to a neck lymph node as stage rises.",
};

const STAGE_INFO: Record<string, { size: number; depth: number; node: number; note: string }> = {
  I: { size: 0.7, depth: 0.3, node: 0.35, note: "Small tumour, no spread" },
  II: { size: 1.0, depth: 0.55, node: 0.45, note: "Larger tumour, still local" },
  III: { size: 1.25, depth: 0.8, node: 0.7, note: "Invading deeper, node involved" },
  IV: { size: 1.55, depth: 1.05, node: 0.95, note: "Invading bone, nodes + spread" },
};

function SpreadDots({ speed, active }: { speed: number; active: boolean }) {
  const pts = useRef<THREE.Points>(null!);
  const t = useRef(0);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(new Float32Array(24 * 3), 3));
    return g;
  }, []);
  useFrame((_, delta) => {
    t.current += delta * speed;
    if (!pts.current) return;
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < 24; i++) {
      const f = ((t.current * 0.4 + i / 24) % 1);
      pos.setXYZ(i, -1.5 + f * 3.4, 0.6 + Math.sin(f * 6) * 0.15, -0.5 + f * -2.2);
    }
    pos.needsUpdate = true;
    pts.current.visible = active;
  });
  return (
    <points ref={pts} geometry={geo}>
      <pointsMaterial color="#f87171" size={0.12} transparent opacity={0.9} />
    </points>
  );
}

function Scene({ stage, speed }: { stage: string; speed: number }) {
  const tumor = useRef<THREE.Group>(null!);
  const spin = useRef<THREE.Group>(null!);
  const t = useRef(0);
  const st = STAGE_INFO[stage] ?? STAGE_INFO.II;

  useFrame((_, delta) => {
    t.current += delta;
    if (tumor.current) {
      const s = st.size * (1 + Math.sin(t.current * 2.5) * 0.05);
      tumor.current.scale.setScalar(s);
    }
    if (spin.current) spin.current.rotation.y = Math.sin(t.current * 0.3) * 0.35;
  });

  const lumps: [number, number, number, number][] = [
    [0, 0.3, 0, 0.55], [0.45, 0.15, 0.2, 0.42], [-0.45, 0.18, -0.1, 0.44],
    [0.15, 0.55, -0.25, 0.38], [-0.2, 0.5, 0.3, 0.36], [0.3, -0.1, -0.4, 0.34],
  ];

  return (
    <group ref={spin}>
      {/* healthy tissue slab */}
      <mesh position={[0, 0, 0]} receiveShadow>
        <boxGeometry args={[6, 1.4, 4]} />
        <meshStandardMaterial color="#d98a94" roughness={0.8} />
      </mesh>
      {/* bone invaded at high stage */}
      <mesh position={[0, -1.05, 0]}>
        <boxGeometry args={[6, 0.7, 4]} />
        <meshStandardMaterial color="#e7d3b3" roughness={0.9} />
      </mesh>
      <Label text="Jaw bone" position={[-3.5, -1.05, 0]} size={0.45} color="#fde68a" />

      {/* tumour mass */}
      <group ref={tumor} position={[-1.2, 0.75, 0]}>
        {lumps.map(([x, y, z, r], i) => (
          <mesh key={i} position={[x, y, z]}>
            <sphereGeometry args={[r, 16, 16]} />
            <meshStandardMaterial color={i % 2 ? "#b91c1c" : "#e11d48"} roughness={0.55} />
          </mesh>
        ))}
        {/* ulcer crater */}
        <mesh position={[0.1, 0.62, 0.15]} rotation={[-Math.PI / 2.3, 0, 0]}>
          <circleGeometry args={[0.42, 20]} />
          <meshStandardMaterial color="#450a0a" roughness={1} />
        </mesh>
      </group>
      <Label text="Ulcerated tumour" position={[-1.2, 2.6, 0]} size={0.55} color="#fca5a5" />

      {/* invasion depth marker */}
      <mesh position={[0.6, 0.7 - st.depth, 0.9]}>
        <boxGeometry args={[0.08, st.depth * 2, 0.08]} />
        <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.6} />
      </mesh>
      <Label text="Invasion depth" position={[0.6, 1.9, 0.9]} size={0.4} color="#fbbf24" />

      {/* neck lymph node */}
      <group position={[1.9, 0.5, -2.7]}>
        <mesh>
          <sphereGeometry args={[st.node, 18, 18]} />
          <meshStandardMaterial color={st.node > 0.6 ? "#f97316" : "#a3a380"} roughness={0.6} />
        </mesh>
        <Label text="Neck lymph node" position={[0, st.node + 0.7, 0]} size={0.5} color="#fdba74" />
      </group>
      <Arrow from={[-0.4, 0.9, -0.6]} to={[1.5, 0.7, -2.3]} color="#f87171" />
      <SpreadDots speed={speed} active={stage === "III" || stage === "IV"} />
      <Label text={`Stage ${stage}`} position={[0, 3.4, 0]} size={0.7} color="#fecaca" />
      <Label text={st.note} position={[0, -2.1, 0]} size={0.45} color="#e2e8f0" />
    </group>
  );
}

export function Topic10406Sim(props: SimProps) {
  const stage = String(props.stage ?? "II");
  const speed = Number(props.speed ?? 1);
  const st = STAGE_INFO[stage] ?? STAGE_INFO.II;
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Stage", stage], ["Tumour size", `${(st.size * 2).toFixed(1)} cm`], ["Nodes", stage === "I" || stage === "II" ? "Clear" : "Involved"]]} />
      <SimCanvas cameraPosition={[0, 4, 10]} target={[0, 0.6, 0]}>
        <Scene stage={stage} speed={speed} />
      </SimCanvas>
    </div>
  );
}
