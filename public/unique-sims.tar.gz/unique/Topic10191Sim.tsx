"use client";
// Nose: deviated nasal septum, nasal trauma, nasal tumors.
// The septum wall bends left or right with the slider — watch one
// nostril's airflow shrink while the other stays open.


import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "deviation", label: "Septum deviation", kind: "slider", min: -100, max: 100, step: 5, default: 45, unit: "%" },
  { key: "condition", label: "Condition", kind: "select", min: 0, max: 0, step: 1, default: "deviated", options: ["deviated", "trauma", "tumor"] },
];

export const UNIQUE_META = {
  title: "Deviated Septum, Nasal Trauma & Tumors",
  blurb: "Bend the nasal septum and watch one side's airflow fade — the classic cause of a permanently blocked nose.",
};

const N_FLOW = 8;

function Animator({ flow, elapsed, deviation }: { flow: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; deviation: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    if (flow.current) {
      const leftOpen = Math.max(0.05, 1 - Math.max(0, deviation) / 100);
      const rightOpen = Math.max(0.05, 1 - Math.max(0, -deviation) / 100);
      flow.current.children.forEach((p, i) => {
        const side = i < N_FLOW ? -1 : 1;
        const open = side < 0 ? leftOpen : rightOpen;
        const j = i % N_FLOW;
        const ph = (elapsed.current * 1.2 + j / N_FLOW) % 1;
        p.position.set(side * 0.55, 1.4 + ph * 2.2, 0.3);
        p.visible = ph < open;
        (p as THREE.Mesh).material = (p as THREE.Mesh).material;
      });
    }
  });
  return null;
}

export function Topic10191Sim(props: SimProps) {
  const deviation = Number(props.deviation ?? 45);
  const condition = String(props.condition ?? "deviated");
  const flow = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const bend = (deviation / 100) * 0.9;
  const blockedSide = deviation > 15 ? "left blocked" : deviation < -15 ? "right blocked" : "both open";

  const flowDots = useMemo(
    () =>
      Array.from({ length: N_FLOW * 2 }, (_, i) => (
        <mesh key={i} position={[(i < N_FLOW ? -1 : 1) * 0.55, 1.4, 0.3]}>
          <sphereGeometry args={[0.11, 8, 8]} />
          <meshStandardMaterial color="#7dd3fc" emissive="#38bdf8" emissiveIntensity={0.9} />
        </mesh>
      )),
    []
  );

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Septum", `${deviation > 0 ? "→" : deviation < 0 ? "←" : "="} ${Math.abs(deviation)}%`], ["Airflow", blockedSide]]} />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 2.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* nasal cavity frame */}
        <group position={[0, 0, 0]}>
          <mesh position={[0, 2.8, -0.4]} castShadow>
            <boxGeometry args={[2.6, 3.6, 1.2]} />
            <meshStandardMaterial color="#f5c9a0" transparent opacity={0.3} roughness={0.7} />
          </mesh>
          {/* septum wall — bends with slider */}
          <mesh position={[bend * 0.9, 2.8, 0.1]} rotation={[0, 0, -bend * 0.5]} castShadow>
            <boxGeometry args={[0.22, 3.2, 0.9]} />
            <meshStandardMaterial color={condition === "tumor" ? "#7c3aed" : "#e8b58e"} roughness={0.6} emissive={condition === "tumor" ? "#8b5cf6" : "#000000"} emissiveIntensity={condition === "tumor" ? 0.4 : 0} />
          </mesh>
          <Label text="SEPTUM" position={[bend * 0.9, 4.9, 0.3]} size={0.55} color="#fcd9b8" />
          {condition === "trauma" && (
            <group>
              <mesh position={[1.5, 3.4, 0.3]} rotation={[0, 0, 0.6]}>
                <boxGeometry args={[0.5, 0.18, 0.18]} />
                <meshStandardMaterial color="#f87171" emissive="#ef4444" emissiveIntensity={0.6} />
              </mesh>
              <Label text="FRACTURE" position={[1.5, 4.2, 0.3]} size={0.5} color="#f87171" />
            </group>
          )}
          {condition === "tumor" && (
            <Label text="TUMOR ON SEPTUM" position={[bend * 0.9, 1.2, 0.3]} size={0.5} color="#c4b5fd" />
          )}
          {/* airflow dots */}
          <group ref={flow}>{flowDots}</group>
          <Label text="LEFT" position={[-1.9, 1.1, 0.3]} size={0.5} color="#7dd3fc" />
          <Label text="RIGHT" position={[1.9, 1.1, 0.3]} size={0.5} color="#7dd3fc" />
        </group>
        <Label text="BEND THE SEPTUM — ONE SIDE BLOCKS" position={[0, 6.2, 0]} size={0.6} color="#93c5fd" />
        <Animator flow={flow} elapsed={elapsed} deviation={deviation} />
      </SimCanvas>
    </div>
  );
}
