"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "layer", label: "Layers placed", kind: "slider", min: 0, max: 3, step: 1, default: 2, unit: "" },
  { key: "cure", label: "Curing light", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Composite restorations: anterior and posterior, layering",
  blurb: "Tooth-coloured filling built layer by layer — each soft layer hardens under the blue curing light.",
};

const LAYERS = [
  { name: "Dentin shade (A3)", color: "#f5d78e" },
  { name: "Body shade (A2)", color: "#faf0d7" },
  { name: "Enamel shade (translucent)", color: "#fefce8" },
];

function Scene({ layer, cure }: { layer: number; cure: boolean }) {
  const lightBeam = useRef<THREE.Mesh>(null!);
  const wand = useRef<THREE.Group>(null!);
  const t = useRef(0);

  useFrame((_, delta) => {
    t.current += delta;
    if (lightBeam.current) {
      const m = lightBeam.current.material as THREE.MeshStandardMaterial;
      m.opacity = cure ? 0.4 + Math.sin(t.current * 4) * 0.1 : 0;
    }
    if (wand.current && cure) {
      wand.current.position.y = 2.6 + Math.sin(t.current * 1.5) * 0.15;
    }
  });

  return (
    <group>
      {/* tooth with box cavity */}
      <mesh position={[0, 0.6, 0]}>
        <cylinderGeometry args={[1.05, 1.25, 1.5, 20]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.25} />
      </mesh>
      <mesh position={[0, -0.9, 0]}>
        <coneGeometry args={[0.85, 1.5, 18]} />
        <meshStandardMaterial color="#e8dcc8" roughness={0.5} />
      </mesh>
      <mesh position={[0, 1.28, 0]}>
        <boxGeometry args={[1.0, 0.35, 1.0]} />
        <meshStandardMaterial color="#475569" roughness={0.9} />
      </mesh>

      {/* composite layers stacking */}
      {LAYERS.slice(0, layer).map((l, i) => (
        <mesh key={i} position={[0, 1.16 + i * 0.11, 0]}>
          <boxGeometry args={[0.96, 0.11, 0.96]} />
          <meshStandardMaterial color={l.color} roughness={0.35} emissive={cure ? l.color : "#000"} emissiveIntensity={cure ? 0.25 : 0} />
        </mesh>
      ))}
      {LAYERS.slice(0, layer).map((l, i) => (
        <Label key={i} text={l.name} position={[1.9, 1.16 + i * 0.11, 0]} size={0.36} color={l.color} />
      ))}
      {layer < 3 && <Label text="Next layer…" position={[-1.9, 1.16 + layer * 0.11, 0]} size={0.38} color="#94a3b8" />}

      {/* curing light wand */}
      <group ref={wand} position={[1.9, 2.6, 0.6]} rotation={[0, 0, 0.7]}>
        <mesh>
          <cylinderGeometry args={[0.22, 0.28, 1.4, 12]} />
          <meshStandardMaterial color="#1e3a8a" roughness={0.4} />
        </mesh>
        <mesh position={[0, -0.85, 0]}>
          <cylinderGeometry args={[0.3, 0.3, 0.25, 12]} />
          <meshStandardMaterial color="#3b82f6" emissive="#3b82f6" emissiveIntensity={cure ? 1.6 : 0.1} />
        </mesh>
      </group>
      {/* blue light beam */}
      <mesh ref={lightBeam} position={[0.75, 1.95, 0.3]} rotation={[0, 0, 0.7]}>
        <cylinderGeometry args={[0.32, 0.55, 1.1, 12, 1, true]} />
        <meshStandardMaterial color="#60a5fa" transparent opacity={0.4} roughness={0.2} side={THREE.DoubleSide} />
      </mesh>
      <Label text="Blue curing light (20s per layer)" position={[2.4, 3.4, 0.6]} size={0.4} color="#93c5fd" />

      <Label text={`${layer}/3 layers ${cure ? "· curing ✓" : "· not cured"}`} position={[0, -2.4, 0]} size={0.5} color={cure && layer === 3 ? "#86efac" : "#e2e8f0"} />
      <Label text="Incremental layering beats shrinkage" position={[0, -3.1, 0]} size={0.4} color="#94a3b8" />
    </group>
  );
}

export function Topic10446Sim(props: SimProps) {
  const layer = Number(props.layer ?? 2);
  const cure = String(props.cure ?? "on") === "on";
  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Layers", `${layer}/3`], ["Curing", cure ? "Blue light ON" : "Off"], ["Shade", "Matched to tooth"]]} />
      <SimCanvas cameraPosition={[0, 1.5, 9]} target={[0, 0.5, 0]}>
        <Scene layer={layer} cure={cure} />
      </SimCanvas>
    </div>
  );
}
