"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "focus", label: "Focus", kind: "select", min: 0, max: 0, step: 1, default: "cancer", options: ["normal", "cancer", "apoptosis"] },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Cancer vs Apoptosis",
  blurb: "A normal cell divides once, a cancer cell divides without stopping, and an apoptotic cell self-destructs neatly.",
};

function Animator({ root, norm, canc, apop, elapsed, speed, focus }: { root: RefObject<THREE.Group>; norm: RefObject<THREE.Group>; canc: RefObject<THREE.Group>; apop: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; focus: string }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const dim = (g: RefObject<THREE.Group>, name: string) => {
      if (g.current) g.current.children.forEach((m) => {
        const mt = (m as THREE.Mesh).material as THREE.MeshStandardMaterial;
        if (mt.transparent !== true) { mt.transparent = true; }
        mt.opacity += (((focus === "all" || focus === name) ? 1 : 0.25) - mt.opacity) * 0.1;
      });
    };
    dim(norm, "normal"); dim(canc, "cancer"); dim(apop, "apoptosis");
    if (norm.current) {
      const q = (t * 0.25) % 1;
      norm.current.children.forEach((m, i) => {
        m.position.x = -4 + (i === 0 ? -1 : 1) * Math.min(0.9, q * 1.4);
        const s = 1 - Math.min(0.35, q * 0.5);
        m.scale.setScalar(i < 2 ? s : 1);
      });
    }
    if (canc.current) {
      canc.current.children.forEach((m, i) => {
        const q = (t * 0.7 + i * 0.13) % 1;
        const a = (i / 7) * Math.PI * 2;
        m.position.set(0.5 + Math.cos(a) * q * 2.2, 1.8 + Math.sin(a * 2) * q * 0.9, Math.sin(a) * q * 2.2);
        m.scale.setScalar(Math.max(0.05, 1 - q * 0.55));
        m.rotation.x += delta * 2;
      });
    }
    if (apop.current) {
      const q = (t * 0.4) % 1;
      const main = apop.current.children[0];
      main.scale.setScalar(Math.max(0.15, 1 - q * 0.85));
      for (let i = 1; i < apop.current.children.length; i++) {
        const m = apop.current.children[i];
        const a = (i / 6) * Math.PI * 2;
        const r = Math.max(0, q - 0.35) * 2.4;
        m.position.set(4.5 + Math.cos(a) * (0.6 + r), 1.8 + Math.sin(a) * (0.4 + r * 0.6), Math.sin(a) * (0.6 + r));
        m.scale.setScalar(q > 0.35 ? 0.32 : 0.001);
      }
    }
  });
  return null;
}

export function Topic10082Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const focus = String(props.focus ?? "cancer");
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const norm = useRef<THREE.Group>(null!);
  const canc = useRef<THREE.Group>(null!);
  const apop = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Focus", focus],
          ["Cancer hallmark", "sustained proliferation"],
          ["Apoptosis", "programmed, tidy death"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 13]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <group ref={norm} position={[0, 0, 0]}>
            <mesh position={[-4, 1.8, 0]} castShadow><sphereGeometry args={[0.9, 22, 22]} /><meshStandardMaterial color="#4ade80" roughness={0.45} /></mesh>
            <mesh position={[-4, 1.8, 0]}><sphereGeometry args={[0.4, 16, 16]} /><meshStandardMaterial color="#166534" roughness={0.5} /></mesh>
          </group>
          <Label text="normal \u2014 divides once" position={[-4, 3.4, 0]} size={0.42} color="#4ade80" />
          <group ref={canc}>
            {Array.from({ length: 7 }).map((_, i) => (
              <mesh key={i} position={[0.5, 1.8, 0]} castShadow>
                <icosahedronGeometry args={[0.7, 1]} />
                <meshStandardMaterial color="#ef4444" emissive="#7f1d1d" emissiveIntensity={0.5} roughness={0.5} flatShading />
              </mesh>
            ))}
          </group>
          <Label text="cancer \u2014 divides endlessly" position={[0.5, 3.6, 0]} size={0.42} color="#f87171" />
          <group ref={apop}>
            <mesh position={[4.5, 1.8, 0]} castShadow><sphereGeometry args={[0.9, 22, 22]} /><meshStandardMaterial color="#facc15" roughness={0.45} /></mesh>
            {Array.from({ length: 6 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.3, 12, 12]} /><meshStandardMaterial color="#facc15" roughness={0.5} /></mesh>
            ))}
          </group>
          <Label text="apoptosis \u2014 tidy self-destruct" position={[4.5, 3.4, 0]} size={0.42} color="#fde047" />
        </group>
        <Animator root={root} norm={norm} canc={canc} apop={apop} elapsed={elapsed} speed={speed} focus={focus} />
      </SimCanvas>
    </div>
  );
}
