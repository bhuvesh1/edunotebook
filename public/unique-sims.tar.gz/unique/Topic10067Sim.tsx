"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "plaque", label: "Plaque buildup", kind: "slider", min: 0, max: 1, step: 0.05, default: 0.35 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Atherosclerosis: Plaque in Arteries",
  blurb: "Cholesterol plaque builds up inside an artery, narrowing the lumen and slowing red blood cell flow.",
};

function Animator({ root, rbc, plq, elapsed, speed, plaque }: { root: RefObject<THREE.Group>; rbc: RefObject<THREE.Group>; plq: RefObject<THREE.Group>; elapsed: RefObject<number>; speed: number; plaque: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    const v = 1.6 - plaque * 1.1;
    if (rbc.current) {
      rbc.current.children.forEach((m, i) => {
        const p = (t * v * 0.35 + i / 10) % 1;
        m.position.set(-5.5 + p * 11, 2 + Math.sin(i * 2.4) * (0.9 - plaque * 0.5), Math.cos(i * 1.7) * 0.5);
        m.rotation.y = t * 2 + i;
      });
    }
    if (plq.current) plq.current.scale.setScalar(0.15 + plaque);
  });
  return null;
}

export function Topic10067Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const plaque = Number(props.plaque ?? 0.35);
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const rbc = useRef<THREE.Group>(null!);
  const plq = useRef<THREE.Group>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stenosis", `${Math.round(plaque * 80)}%`],
          ["LDL cholesterol", plaque > 0.5 ? "high" : "normal"],
          ["Risk", plaque > 0.7 ? "heart attack / stroke" : "monitor"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 2.8, 11]} target={[0, 2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          <mesh position={[0, 2, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[1.6, 1.6, 12, 24, 1, true]} />
            <meshStandardMaterial color="#ef4444" transparent opacity={0.28} roughness={0.6} side={THREE.DoubleSide} />
          </mesh>
          <group ref={plq}>
            {[-1.6, -0.8, 0, 0.8, 1.6].map((x, i) => (
              <group key={i}>
                <mesh position={[x, 3.15, (i % 2) * 0.3 - 0.15]}>
                  <sphereGeometry args={[0.42, 14, 14]} /><meshStandardMaterial color="#facc15" roughness={0.7} />
                </mesh>
                <mesh position={[x + 0.4, 0.85, (i % 2) * -0.3 + 0.15]}>
                  <sphereGeometry args={[0.36, 14, 14]} /><meshStandardMaterial color="#eab308" roughness={0.7} />
                </mesh>
              </group>
            ))}
          </group>
          <group ref={rbc}>
            {Array.from({ length: 10 }).map((_, i) => (
              <mesh key={i} scale={[1, 0.45, 1]}>
                <sphereGeometry args={[0.32, 16, 16]} /><meshStandardMaterial color="#dc2626" roughness={0.5} />
              </mesh>
            ))}
          </group>
          <Label text="plaque (cholesterol)" position={[0, 4.1, 0]} color="#facc15" />
          <Label text="RBC" position={[-4.4, 2.9, 0]} size={0.45} color="#f87171" />
          <Label text="artery wall" position={[5.2, 3.2, 0]} size={0.42} color="#ef4444" />
        </group>
        <Animator root={root} rbc={rbc} plq={plq} elapsed={elapsed} speed={speed} plaque={plaque} />
      </SimCanvas>
    </div>
  );
}
