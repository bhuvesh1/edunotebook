"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "material", label: "Material", kind: "select", min: 0, max: 0, step: 1, default: "alginate", options: ["alginate", "silicone", "polyether"] },
  { key: "seat", label: "Seat the tray", kind: "slider", min: 0, max: 1, step: 0.01, default: 0.6, unit: "" },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Impression materials: alginate, elastomers",
  blurb: "Seat an impression tray over the teeth — the gooey material flows around every tooth, then sets into a perfect negative mold.",
};

const MATS: Record<string, { name: string; color: string; setColor: string; time: string }> = {
  alginate: { name: "Alginate", color: "#f9a8d4", setColor: "#f472b6", time: "~2 min" },
  silicone: { name: "Addition silicone", color: "#a5b4fc", setColor: "#818cf8", time: "~4 min" },
  polyether: { name: "Polyether", color: "#fcd34d", setColor: "#f59e0b", time: "~5 min" },
};

function ImpressionScene({ material, seat, speed, showLabels }: { material: string; seat: number; speed: number; showLabels: boolean }) {
  const tray = useRef<THREE.Group>(null!);
  const goo = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const cfg = MATS[material] ?? MATS.alginate;
  const set = Math.min(1, seat * 1.2); // setting progresses as tray seats

  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    if (tray.current) {
      tray.current.position.y = THREE.MathUtils.lerp(5.2, 1.55, seat);
      tray.current.position.y += Math.sin(elapsed.current * 2) * 0.03 * (seat > 0.02 && seat < 0.98 ? 1 : 0);
    }
    if (goo.current) {
      const m = goo.current.material as THREE.MeshStandardMaterial;
      m.color.lerpColors(new THREE.Color(cfg.color), new THREE.Color(cfg.setColor), set);
      m.roughness = THREE.MathUtils.lerp(0.15, 0.75, set);
    }
  });

  return (
    <group>
      {/* lower teeth arch */}
      {Array.from({ length: 7 }).map((_, i) => {
        const a = Math.PI - (i / 6) * Math.PI;
        const x = Math.cos(a) * 2.6;
        const z = -Math.sin(a) * 2.6 * 0.8 + 0.6;
        return (
          <mesh key={i} position={[x, 0.4, z]} castShadow>
            <boxGeometry args={[0.7, 0.9, 0.6]} />
            <meshStandardMaterial color="#fef9c3" roughness={0.25} />
          </mesh>
        );
      })}
      {/* gum base */}
      <mesh position={[0, -0.5, 0]} scale={[1, 0.4, 1]} castShadow>
        <torusGeometry args={[2.6, 1, 12, 32, Math.PI]} />
        <meshStandardMaterial color="#e88ca0" roughness={0.6} />
      </mesh>

      {/* impression tray + material */}
      <group ref={tray} position={[0, 5.2, 0]}>
        {/* tray: U-shaped shell */}
        <mesh scale={[1.1, 0.5, 1.1]} castShadow>
          <torusGeometry args={[2.7, 0.85, 12, 32, Math.PI]} />
          <meshStandardMaterial color="#94a3b8" metalness={0.7} roughness={0.35} />
        </mesh>
        <mesh position={[0, 1.1, 0]} castShadow>
          <cylinderGeometry args={[0.18, 0.18, 1.6, 10]} />
          <meshStandardMaterial color="#64748b" metalness={0.7} roughness={0.35} />
        </mesh>
        {/* gooey material filling the tray */}
        <mesh ref={goo} position={[0, -0.15, 0]} scale={[1.05, 0.55, 1.05]} castShadow>
          <torusGeometry args={[2.55, 0.75, 14, 36, Math.PI]} />
          <meshStandardMaterial color={cfg.color} roughness={0.15} />
        </mesh>
        {/* material oozing over tray edges as it seats */}
        {seat > 0.5 &&
          Array.from({ length: 8 }).map((_, i) => {
            const a = Math.PI - (i / 7) * Math.PI;
            return (
              <mesh key={i} position={[Math.cos(a) * 3.6, -0.5, -Math.sin(a) * 3.6 * 0.8 + 0.6]} scale={[1, 0.6 + seat, 1]}>
                <sphereGeometry args={[0.22, 10, 8]} />
                <meshStandardMaterial color={cfg.setColor} roughness={0.5} />
              </mesh>
            );
          })}
      </group>

      {showLabels && (
        <>
          <Text position={[0, 6.6, 0]} fontSize={0.44} color="#fef3c7">{cfg.name} — sets in {cfg.time}</Text>
          <Text position={[0, -2.6, 0]} fontSize={0.4} color="#e2e8f0" maxWidth={10}>
            {set < 0.4 ? "Flowing around every tooth…" : set < 0.9 ? "Gelling — hold still!" : "Set! Lift straight out → perfect negative"}
          </Text>
        </>
      )}
    </group>
  );
}

export function Topic10387Sim(props: SimProps) {
  const material = String(props.material ?? "alginate");
  const seat = Number(props.seat ?? 0.6);
  const speed = Number(props.speed ?? 1);
  const showLabels = String(props.detail ?? "on") === "on";
  const cfg = MATS[material] ?? MATS.alginate;

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Material", cfg.name],
          ["Set time", cfg.time],
          ["State", seat < 0.4 ? "flowing" : seat < 0.9 ? "gelling" : "set ✓"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4.5, 12]} target={[0, 1.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.4, 0]} receiveShadow>
          <planeGeometry args={[34, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <ImpressionScene material={material} seat={seat} speed={speed} showLabels={showLabels} />
      </SimCanvas>
    </div>
  );
}
