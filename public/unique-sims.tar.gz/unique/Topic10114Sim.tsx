// Antidepressants: serotonin crosses the synapse but a reuptake pump sucks it
// back — SSRIs block the pump so more serotonin lingers and mood lifts.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "dose", label: "Antidepressant (SSRI) dose", kind: "slider", min: 0, max: 100, step: 5, default: 55, unit: "%" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Antidepressants",
  blurb: "SSRIs block the serotonin reuptake pump — more serotonin lingers in the synapse and mood lifts.",
};

const N_SER = 16;

function Animator({ ser, pump, mood, elapsed, dose, setTick }: {
  ser: React.RefObject<(THREE.Mesh | null)[]>;
  pump: React.RefObject<THREE.Group>;
  mood: React.RefObject<THREE.Mesh>;
  elapsed: React.RefObject<number>;
  dose: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = dose / 100;
    const linger = 0.25 + k * 0.75; // fraction of serotonin staying in cleft
    ser.current.forEach((s, i) => {
      if (!s) return;
      const cyc = (t * 0.5 + i / N_SER) % 1;
      const recycled = ((i * 53) % 10) / 10 > linger;
      if (recycled && cyc > 0.6) {
        // sucked back up by the pump
        const f = (cyc - 0.6) / 0.4;
        s.position.set(-2.6, 1.9 + f * 1.4, 0.8);
        ((s as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = 1 - f;
      } else {
        // drifting in the cleft, lingering longer with drug
        const f = Math.min(1, cyc / (0.6 + linger * 0.4));
        s.position.set(-2.6 + f * 5.2, 1.9 + Math.sin(t * 2 + i * 2.4) * 0.35, Math.sin(i * 1.3) * 0.5);
        ((s as THREE.Mesh).material as THREE.MeshStandardMaterial).opacity = 1;
      }
      s.rotation.y = t * 2 + i;
    });
    if (pump.current) {
      // pump blocked -> stops spinning
      pump.current.rotation.z = t * (1 - k) * 6;
      (pump.current.children[0] as THREE.Mesh).material =
        (pump.current.children[0] as THREE.Mesh).material;
    }
    if (mood.current) {
      // mood sun: grey-blue when low, warm gold when lifted
      const m = mood.current.material as THREE.MeshStandardMaterial;
      m.color.setHSL(0.08 + k * 0.05, 0.5 + k * 0.5, 0.35 + k * 0.25);
      m.emissiveIntensity = 0.3 + k * 1.4;
      mood.current.position.y = 4.6 + Math.sin(t * 1.5) * 0.15;
    }
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(linger * 100)); }
  });
  return null;
}

export function Topic10114Sim(props: SimProps) {
  const dose = Number(props.dose ?? 55);
  const showLabels = String(props.detail ?? "on") === "on";
  const ser = useRef<(THREE.Mesh | null)[]>([]);
  const pump = useRef<THREE.Group>(null!);
  const mood = useRef<THREE.Mesh>(null!);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const k = dose / 100;
  const moodLabel = k < 0.3 ? "low mood" : k < 0.65 ? "lifting" : "bright";

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Serotonin in synapse", `${tick}%`],
          ["Reuptake pump", k > 0.6 ? "blocked" : k > 0.25 ? "slowing" : "active"],
          ["Mood", moodLabel],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[34, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* presynaptic neuron (left) */}
        <mesh position={[-3.6, 2.9, 0]} scale={[1.4, 1, 1]} castShadow>
          <sphereGeometry args={[0.9, 24, 18]} />
          <meshStandardMaterial color="#f59e0b" roughness={0.5} />
        </mesh>
        {showLabels && <Label text="sending neuron" position={[-3.6, 4.3, 0]} size={0.45} color="#fcd34d" />}

        {/* postsynaptic neuron (right) */}
        <mesh position={[3.6, 2.9, 0]} scale={[1.4, 1, 1]} castShadow>
          <sphereGeometry args={[0.9, 24, 18]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.5} />
        </mesh>
        {showLabels && <Label text="receiving neuron" position={[3.6, 4.3, 0]} size={0.45} color="#7dd3fc" />}

        {/* synaptic cleft */}
        <mesh position={[0, 1.9, 0]}>
          <boxGeometry args={[5.6, 1.4, 1.2]} />
          <meshStandardMaterial color="#1e293b" transparent opacity={0.4} />
        </mesh>
        {showLabels && <Label text="synapse" position={[0, 0.85, 0]} size={0.45} color="#94a3b8" />}

        {/* serotonin molecules */}
        {Array.from({ length: N_SER }).map((_, i) => (
          <mesh key={i} ref={(m) => { ser.current[i] = m; }}>
            <sphereGeometry args={[0.15, 12, 10]} />
            <meshStandardMaterial color="#22d3ee" emissive="#0891b2" emissiveIntensity={1} transparent />
          </mesh>
        ))}
        {showLabels && <Label text="serotonin" position={[0, 2.95, 0]} size={0.45} color="#67e8f9" />}

        {/* reuptake pump on the sending neuron */}
        <group ref={pump} position={[-2.6, 2.4, 0.8]}>
          <mesh>
            <torusGeometry args={[0.3, 0.12, 10, 18]} />
            <meshStandardMaterial
              color={k > 0.6 ? "#ef4444" : "#a855f7"}
              emissive={k > 0.6 ? "#7f1d1d" : "#6b21a8"}
              emissiveIntensity={0.9}
            />
          </mesh>
        </group>
        {showLabels && (
          <Label
            text={k > 0.6 ? "reuptake pump BLOCKED" : "reuptake pump"}
            position={[-2.6, 1.35, 1.2]}
            size={0.45}
            color={k > 0.6 ? "#fca5a5" : "#c4b5fd"}
          />
        )}

        {/* mood sun */}
        <mesh ref={mood} position={[0, 4.6, -2.5]}>
          <sphereGeometry args={[0.65, 20, 14]} />
          <meshStandardMaterial color="#78716c" emissive="#f59e0b" emissiveIntensity={0.5} />
        </mesh>
        {showLabels && <Label text={`mood: ${moodLabel}`} position={[0, 5.7, -2.5]} size={0.45} color="#fde68a" />}

        <Animator ser={ser} pump={pump} mood={mood} elapsed={elapsed} dose={dose} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
