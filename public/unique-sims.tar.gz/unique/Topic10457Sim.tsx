"use client";
// Bleaching of Discolored Teeth — interactive 3D model.

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label, Arrow } from "./_text";
import { Tooth, GumSlab, BoneBlock, Wire } from "./_dental";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "×" },
  { key: "strength", label: "Bleach strength", kind: "slider", min: 0.3, max: 1.5, step: 0.1, default: 1, unit: "×" },
];

export const UNIQUE_META = {
  title: "Bleaching of Discolored Teeth",
  blurb: "A stained yellow tooth gets bleaching gel — watch the shade lift from dark A4 toward bright B1.",
};

function Animator({
  group,
  elapsed,
  speed,
  p,
}: {
  group: React.RefObject<THREE.Group>;
  elapsed: React.RefObject<number>;
  speed: number;
  p: any;
}) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (!group.current) return;
    const g = (n: string): any => group.current!.getObjectByName(n);
    const T = 12;
    const ph = Math.min(1, (t % T) / (T * 0.65));
    const w = Math.min(1, ph * p.strength);
    const crown: any = g("bleach-crownMesh");
    if (crown) {
      const c = (crown.material as any).color;
      c.setRGB(0.85 + 0.13 * w, 0.72 + 0.24 * w, 0.42 + 0.52 * w);
    }
    const gel: any = g("gel");
    if (gel) gel.scale.setScalar(0.35 + 0.06 * Math.sin(t * 4));
    const marker: any = g("shademarker");
    if (marker) marker.position.x = -2.4 + w * 3.2;
    group.current.rotation.y = Math.sin(t * 0.25) * 0.25;
  });
  return null;
}

export function Topic10457Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const strength = Number(props.strength ?? 1);
  const group = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const p = { speed, strength };

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Stain", "Yellow discoloration"],
          ["Gel", "Carbamide peroxide"],
          ["Bleach strength", `${strength.toFixed(1)}×`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3.2, 10]} target={[0, 1.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
          <planeGeometry args={[44, 28]} />
          <meshStandardMaterial color="#0b1226" roughness={1} />
        </mesh>
        <group ref={group}>
          <Tooth position={[0, 1.2, 0]} scale={1.7} name="bleach" />
          <GumSlab position={[0, 0.2, 0]} scale={1.2} />
          <mesh name="gel" position={[0, 2.6, 0.3]}>
            <sphereGeometry args={[1, 12, 12]} />
            <meshStandardMaterial color="#e0f2fe" roughness={0.2} transparent opacity={0.85} />
          </mesh>
          <Label text="Bleaching gel" position={[2.3, 2.8, 0]} size={0.42} color="#bae6fd" />
          {[["A4", "#d9a441"], ["A2", "#e3b968"], ["B2", "#eed9a4"], ["B1", "#fbf3df"]].map((s, i) => (
            <mesh key={i} position={[-2.4 + i * 1.07, -0.9, 2.6]}>
              <boxGeometry args={[0.9, 0.5, 0.1]} />
              <meshStandardMaterial color={s[1]} roughness={0.5} />
            </mesh>
          ))}
          <mesh name="shademarker" position={[-2.4, -0.35, 2.6]}>
            <coneGeometry args={[0.12, 0.3, 4]} />
            <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.7} />
          </mesh>
          <Label text="Shade guide" position={[0, -1.5, 2.6]} size={0.42} />
        </group>
        <Animator group={group} elapsed={elapsed} speed={speed} p={p} />
      </SimCanvas>
    </div>
  );
}
