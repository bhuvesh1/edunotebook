"use client";

import { useRef, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "flow", label: "Electron flow", kind: "slider", min: 1, max: 8, step: 1, default: 4 },
  { key: "speed", label: "Animation speed", kind: "slider", min: 0, max: 2, step: 0.1, default: 1, unit: "\u00d7" },
];

export const UNIQUE_META = {
  title: "Electron Transport Chain",
  blurb: "Electrons flow through Complexes I-IV, protons are pumped across the membrane, and ATP synthase spins out ATP.",
};

const CX = [-4, -1.8, 0.6, 2.8];
const CC = ["#ef4444", "#f97316", "#eab308", "#22c55e"];

function Animator({ root, elec, prot, atps, head, elapsed, speed, flow }: { root: RefObject<THREE.Group>; elec: RefObject<THREE.Group>; prot: RefObject<THREE.Group>; atps: RefObject<THREE.Group>; head: RefObject<THREE.Mesh>; elapsed: RefObject<number>; speed: number; flow: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta * speed;
    const t = elapsed.current;
    if (elec.current) {
      elec.current.children.forEach((m, i) => {
        const p = (t * 0.1 * flow + i / flow) % 1;
        m.position.set(-5 + p * 9.4, 1.9 + Math.sin(p * Math.PI) * 0.35, 0);
      });
    }
    if (prot.current) {
      prot.current.children.forEach((m, i) => {
        const q = (t * 0.45 + i / 10) % 1;
        m.position.set(CX[i % 4], 0.8 + q * 2.4, 0.3);
      });
    }
    if (atps.current) {
      atps.current.children.forEach((m, i) => {
        const r = (t * 0.32 + i / 5) % 1;
        m.position.set(5.3 + r * 2.6, 2.9 + Math.sin(r * 6) * 0.35, 0);
      });
    }
    if (head.current) head.current.rotation.y = t * 5;
  });
  return null;
}

export function Topic10063Sim(props: SimProps) {
  const speed = Number(props.speed ?? 1);
  const flow = Math.round(Number(props.flow ?? 4));
  const root = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);
  const elec = useRef<THREE.Group>(null!);
  const prot = useRef<THREE.Group>(null!);
  const atps = useRef<THREE.Group>(null!);
  const head = useRef<THREE.Mesh>(null!);
  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["ATP / NADH", "\u2248 2.5"],
          ["Site", "inner mitochondrial membrane"],
          ["Final acceptor", "O\u2082 \u2192 H\u2082O"],
        ]}
      />
      <SimCanvas cameraPosition={[0, 3, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[30, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        <group ref={root}>
          {Array.from({ length: 13 }).map((_, i) => (
            <group key={i}>
              <mesh position={[-6 + i, 1.5, 0]}><sphereGeometry args={[0.16, 12, 12]} /><meshStandardMaterial color="#d9a05b" /></mesh>
              <mesh position={[-6 + i, 2.3, 0]}><sphereGeometry args={[0.16, 12, 12]} /><meshStandardMaterial color="#d9a05b" /></mesh>
            </group>
          ))}
          <mesh position={[0, 1.9, -0.15]}><boxGeometry args={[12.6, 0.5, 0.3]} /><meshStandardMaterial color="#b97c3f" roughness={0.8} /></mesh>
          {CX.map((x, i) => (
            <group key={i}>
              <mesh position={[x, 1.9, 0]} castShadow>
                <boxGeometry args={[0.9, 1.3, 0.9]} /><meshStandardMaterial color={CC[i]} roughness={0.5} />
              </mesh>
              <Label text={`Complex ${["I", "II", "III", "IV"][i]}`} position={[x, 3.1, 0]} size={0.4} color={CC[i]} />
            </group>
          ))}
          <mesh position={[4.6, 1.9, 0]}><cylinderGeometry args={[0.22, 0.22, 1.4, 12]} /><meshStandardMaterial color="#94a3b8" /></mesh>
          <mesh ref={head} position={[4.6, 2.95, 0]} castShadow>
            <sphereGeometry args={[0.55, 20, 20]} /><meshStandardMaterial color="#f472b6" roughness={0.4} />
          </mesh>
          <Label text="ATP synthase" position={[4.6, 3.9, 0]} size={0.42} color="#f472b6" />
          <group ref={elec}>
            {Array.from({ length: flow }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.14, 12, 12]} /><meshStandardMaterial color="#fde047" emissive="#facc15" emissiveIntensity={2} /></mesh>
            ))}
          </group>
          <group ref={prot}>
            {Array.from({ length: 10 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.12, 12, 12]} /><meshStandardMaterial color="#f8fafc" emissive="#e2e8f0" emissiveIntensity={0.8} /></mesh>
            ))}
          </group>
          <group ref={atps}>
            {Array.from({ length: 5 }).map((_, i) => (
              <mesh key={i}><sphereGeometry args={[0.2, 14, 14]} /><meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1.6} /></mesh>
            ))}
          </group>
          <Label text="e\u207b" position={[-6.4, 2.5, 0]} size={0.5} color="#fde047" />
          <Label text="H\u207a" position={[-6.4, 1.1, 0]} size={0.5} color="#f8fafc" />
          <Label text="ATP" position={[7.6, 3.4, 0]} size={0.45} color="#fbbf24" />
        </group>
        <Animator root={root} elec={elec} prot={prot} atps={atps} head={head} elapsed={elapsed} speed={speed} flow={flow} />
      </SimCanvas>
    </div>
  );
}
