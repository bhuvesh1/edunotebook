// Antitubercular drugs: inside the lung, a macrophage engulfs TB bacilli (red
// rods) — months of combination therapy shrink and clear them.
"use client";

import { useRef, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_labels";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "months", label: "Treatment duration", kind: "slider", min: 0, max: 9, step: 1, default: 4, unit: "mo" },
  { key: "detail", label: "Show labels", kind: "select", min: 0, max: 0, step: 1, default: "on", options: ["on", "off"] },
];

export const UNIQUE_META = {
  title: "Antitubercular drugs",
  blurb: "A macrophage engulfs TB bacilli in the lung — months of therapy shrink and clear them.",
};

const N_TB = 9;

function Animator({ tb, macro, drug, elapsed, months, setTick }: {
  tb: React.RefObject<(THREE.Group | null)[]>;
  macro: React.RefObject<THREE.Mesh>;
  drug: React.RefObject<(THREE.Mesh | null)[]>;
  elapsed: React.RefObject<number>;
  months: number;
  setTick: (n: number) => void;
}) {
  const last = useRef(0);
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const k = months / 9;
    tb.current.forEach((g, i) => {
      if (!g) return;
      // engulfed bacilli shrink as treatment progresses
      const s = Math.max(0.02, 1 - k * 0.95 - Math.max(0, Math.sin(t * 0.8 + i * 2)) * 0.05);
      g.scale.setScalar(s);
      g.visible = s > 0.05;
      g.rotation.z = Math.sin(t * 0.7 + i) * 0.4;
    });
    if (macro.current) {
      const pulse = 1 + Math.sin(t * 1.4) * 0.04;
      macro.current.scale.set(pulse, pulse, pulse);
    }
    drug.current.forEach((d, i) => {
      if (!d) return;
      const f = (t * 0.4 + i / 6) % 1;
      d.position.set(3.6 - f * 3.4, 3.4 - f * 1.6, 0.8 - f * 0.6);
      d.rotation.y = t * 3 + i;
    });
    if (elapsed.current - last.current > 0.3) { last.current = elapsed.current; setTick(Math.round(k * 100)); }
  });
  return null;
}

export function Topic10118Sim(props: SimProps) {
  const months = Number(props.months ?? 4);
  const showLabels = String(props.detail ?? "on") === "on";
  const tb = useRef<(THREE.Group | null)[]>([]);
  const macro = useRef<THREE.Mesh>(null!);
  const drug = useRef<(THREE.Mesh | null)[]>([]);
  const elapsed = useRef(0);
  const [tick, setTick] = useState(0);
  void tick;
  const cleared = Math.round((months / 9) * 100);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Treatment", `${months} months`],
          ["Bacilli cleared", `${cleared}%`],
        ]}
      />
      <SimCanvas cameraPosition={[0, 4, 12]} target={[0, 1.8, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* lungs */}
        {[-1.7, 1.7].map((x, i) => (
          <mesh key={i} position={[x, 2.1, -1]} scale={[0.9, 1.3, 0.7]} castShadow>
            <sphereGeometry args={[1, 20, 14]} />
            <meshStandardMaterial color="#f9a8d4" roughness={0.65} transparent opacity={0.85} />
          </mesh>
        ))}
        <mesh position={[0, 3.4, -1]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.3, 0.3, 2.2, 12]} />
          <meshStandardMaterial color="#f9a8d4" roughness={0.6} />
        </mesh>
        {showLabels && <Label text="lungs" position={[0, 5.2, -1]} color="#f9a8d4" />}

        {/* macrophage */}
        <mesh ref={macro} position={[0, 1.7, 0.4]} castShadow>
          <sphereGeometry args={[1.5, 24, 18]} />
          <meshStandardMaterial color="#fde68a" roughness={0.55} transparent opacity={0.55} />
        </mesh>
        {showLabels && <Label text="macrophage" position={[0, 3.6, 0.4]} color="#fef08a" />}

        {/* TB bacilli: red acid-fast rods inside */}
        {Array.from({ length: N_TB }).map((_, i) => {
          const ang = (i / N_TB) * Math.PI * 2;
          return (
            <group
              key={i}
              ref={(g) => { tb.current[i] = g; }}
              position={[Math.cos(ang) * 0.85, 1.7 + Math.sin(ang * 1.3) * 0.7, 0.4 + Math.sin(ang) * 0.6]}
              rotation={[0, 0, ang]}
            >
              <mesh castShadow>
                <capsuleGeometry args={[0.14, 0.7, 6, 12]} />
                <meshStandardMaterial color="#ef4444" emissive="#991b1b" emissiveIntensity={0.7} />
              </mesh>
            </group>
          );
        })}
        {showLabels && <Label text="M. tuberculosis (acid-fast rods)" position={[0, 0.1, 0.4]} size={0.45} color="#fca5a5" />}

        {/* anti-TB drug molecules raining in */}
        {Array.from({ length: 6 }).map((_, i) => (
          <mesh key={`d${i}`} ref={(m) => { drug.current[i] = m; }}>
            <octahedronGeometry args={[0.16]} />
            <meshStandardMaterial color="#4ade80" emissive="#16a34a" emissiveIntensity={1} />
          </mesh>
        ))}
        {showLabels && <Label text="anti-TB drugs (HRZE)" position={[3.8, 3.9, 0.6]} size={0.45} color="#86efac" />}

        <Animator tb={tb} macro={macro} drug={drug} elapsed={elapsed} months={months} setTick={setTick} />
      </SimCanvas>
    </div>
  );
}
