// app/components/sims/unique/Topic7107Sim.tsx
// Projectile on an inclined plane: a cannon at the foot of a ramp fires
// up the slope. The ball lands back on the ramp — the flag marks the
// range measured along the incline, which is shorter than on flat ground.

"use client";

import { useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "incline", label: "Incline angle", kind: "slider", min: 5, max: 40, step: 1, default: 20, unit: "°" },
  { key: "velocity", label: "Launch velocity", kind: "slider", min: 5, max: 14, step: 0.5, default: 10, unit: "m/s" },
];

export const UNIQUE_META = {
  title: "Projectiles on Inclined Planes",
  blurb: "Firing up a ramp — the ball lands back on the slope and the flag marks the incline range.",
};

const G = 9.8;
const THETA = (50 * Math.PI) / 180; // launch angle above horizontal
const TN = 64;
const RAMP_LEN = 11;

/** Numerically find when the trajectory meets the ramp surface. */
function landingTime(v0: number, phi: number) {
  const m = Math.tan(phi);
  let t = 0.01;
  for (; t < 10; t += 0.005) {
    const x = v0 * Math.cos(THETA) * t;
    const y = 0.45 + v0 * Math.sin(THETA) * t - 0.5 * G * t * t;
    if (y <= m * x + 0.15 && t > 0.05) break;
  }
  return t;
}

function Animator({
  ball, trail, trailGeo, v0, phi, T, bump,
}: {
  ball: RefObject<THREE.Mesh>;
  trail: RefObject<THREE.Line>;
  trailGeo: THREE.BufferGeometry;
  v0: number; phi: number; T: number;
  bump: () => void;
}) {
  const t = useRef(0);
  const n = useRef(0);
  useFrame((_, delta) => {
    t.current += delta;
    const cycle = T + 0.9;
    const ft = Math.min(t.current % cycle, T);
    const x = v0 * Math.cos(THETA) * ft;
    const y = 0.45 + v0 * Math.sin(THETA) * ft - 0.5 * G * ft * ft;
    const m = Math.tan(phi);
    if (ball.current) ball.current.position.set(x, Math.max(y, m * x + 0.45), 0);
    const pos = trailGeo.attributes.position as THREE.BufferAttribute;
    const k = Math.max(Math.floor((ft / T) * TN), 0);
    for (let i = 0; i < TN; i++) {
      const f = (i / (TN - 1)) * T;
      const px = v0 * Math.cos(THETA) * f;
      const py = 0.45 + v0 * Math.sin(THETA) * f - 0.5 * G * f * f;
      pos.setXYZ(i, px, Math.max(py, m * px + 0.45), 0);
    }
    pos.needsUpdate = true;
    if (trail.current) trail.current.geometry.setDrawRange(0, k);
    if (++n.current % 20 === 0) bump();
  });
  return null;
}

export function Topic7107Sim(props: SimProps) {
  const incline = Number(props.incline ?? 20);
  const v0 = Number(props.velocity ?? 10);
  const phi = (incline * Math.PI) / 180;
  const ball = useRef<THREE.Mesh>(null!);
  const trail = useRef<THREE.Line>(null!);
  const [, bump] = useState(0);

  const T = landingTime(v0, phi);
  const lx = v0 * Math.cos(THETA) * T;
  const inclineRange = lx / Math.cos(phi);

  const trailGeo = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(TN * 3), 3));
    return geo;
  }, []);

  return (
    <div className="relative h-full w-full">
      <SimReadout
        items={[
          ["Incline", `${incline}°`],
          ["Range on incline", `${inclineRange.toFixed(1)} m`],
          ["🚩 Flag", "landing point"],
        ]}
      />
      <SimCanvas cameraPosition={[1, 5.5, 15]} target={[2.5, 2.2, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[36, 24]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>
        {/* ramp */}
        <mesh position={[(RAMP_LEN / 2) * Math.cos(phi), ((RAMP_LEN / 2) * Math.sin(phi)) / 2 - 0.2, 0]}
          rotation={[0, 0, phi]} receiveShadow>
          <boxGeometry args={[RAMP_LEN, 0.4, 4]} />
          <meshStandardMaterial color="#a16207" roughness={0.85} />
        </mesh>

        {/* cannon at the foot of the ramp */}
        <group position={[0, 0.15, 0]}>
          <mesh position={[0, 0.45, 0]} castShadow>
            <boxGeometry args={[1.5, 0.9, 1.3]} />
            <meshStandardMaterial color="#57534e" roughness={0.7} />
          </mesh>
          <mesh position={[0.6, 1.1, 0]} rotation={[0, 0, THETA - Math.PI / 2]} castShadow>
            <cylinderGeometry args={[0.26, 0.32, 2, 18]} />
            <meshStandardMaterial color="#44403c" roughness={0.5} metalness={0.5} />
          </mesh>
        </group>

        <primitive object={new THREE.Line(trailGeo, new THREE.LineBasicMaterial({ color: "#fbbf24" }))} ref={trail} />

        {/* landing flag on the ramp */}
        <group position={[lx, lx * Math.tan(phi) + 0.15, 0]}>
          <mesh position={[0, 0.8, 0]}>
            <cylinderGeometry args={[0.05, 0.05, 1.6, 8]} />
            <meshStandardMaterial color="#94a3b8" roughness={0.6} />
          </mesh>
          <mesh position={[0.3, 1.35, 0]}>
            <boxGeometry args={[0.6, 0.4, 0.04]} />
            <meshStandardMaterial color="#22c55e" emissive="#15803d" emissiveIntensity={0.5} roughness={0.5} />
          </mesh>
        </group>

        <mesh ref={ball} position={[0, 0.45, 0]} castShadow>
          <sphereGeometry args={[0.3, 24, 24]} />
          <meshStandardMaterial color="#1f2937" roughness={0.35} metalness={0.5} />
        </mesh>

        <Animator ball={ball} trail={trail} trailGeo={trailGeo} v0={v0} phi={phi} T={T} bump={() => bump((v) => v + 1)} />
      </SimCanvas>
    </div>
  );
}
