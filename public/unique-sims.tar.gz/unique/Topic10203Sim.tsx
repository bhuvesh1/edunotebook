// Retinal vascular occlusions — a retinal artery branch gets plugged by a
// clot. Blood-flow dots stream in, jam up behind the blockage, and the
// starved downstream retina turns pale. Clot-size slider controls the damage.
"use client";

import { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { SimCanvas, SimReadout } from "../SimCanvas";
import { Label } from "./_text";
import type { ControlSpec } from "../../../../lib/simulations/registry";
import type { SimProps } from "../sim-props";

export const UNIQUE_CONTROLS: ControlSpec[] = [
  { key: "clot", label: "Clot size", kind: "slider", min: 0, max: 100, step: 5, default: 70, unit: "%" },
  { key: "vessel", label: "Blocked vessel", kind: "select", min: 0, max: 0, step: 1, default: "artery", options: ["artery", "vein"] },
];

export const UNIQUE_META = {
  title: "Retinal Vascular Occlusions",
  blurb: "A clot plugs a retinal vessel — blood piles up behind it while the far side starves and goes pale.",
};

function Animator({ flow, elapsed, clot }: { flow: React.RefObject<THREE.Group>; elapsed: React.RefObject<number>; clot: number }) {
  useFrame((_, delta) => {
    elapsed.current += delta;
    const t = elapsed.current;
    const blocked = clot / 100;
    if (flow.current) {
      flow.current.children.forEach((c, i) => {
        const m = c as THREE.Mesh;
        const speed = 1 - blocked * 0.92;
        // dots travel along the vessel; they stall at the clot (x=0)
        let x = m.userData.x0 + t * speed * 1.6;
        const lane = m.userData.lane;
        const wrap = 6.4;
        x = ((x + wrap) % (wrap * 2)) - wrap;
        const blockedAt = -0.15;
        if (x > blockedAt && blocked > 0.1) {
          // jam: dots pile up behind the clot
          const jam = blockedAt - ((m.userData.seed * blocked * 2.2) % (blocked * 2.4));
          x = Math.min(x, jam);
        }
        m.position.x = x;
        m.position.y = 0.28 + lane * 0.09;
        m.position.z = 0.62 + lane * 0.05;
      });
    }
  });
  return null;
}

export function Topic10203Sim(props: SimProps) {
  const clot = Number(props.clot ?? 70);
  const vessel = String(props.vessel ?? "artery");
  const flow = useRef<THREE.Group>(null!);
  const elapsed = useRef(0);

  const starved = clot > 55 ? "pale / dying" : clot > 25 ? "struggling" : "ok";
  const dots = Array.from({ length: 26 }).map((_, i) => ({ x0: -6.4 + i * 0.5, lane: (i % 3) - 1, seed: (i * 0.618) % 1 }));

  return (
    <div className="relative h-full w-full">
      <SimReadout items={[["Flow past clot", `${Math.round(100 - clot * 0.92)}%`], ["Downstream retina", starved], ["Type", vessel === "artery" ? "CRAO/BRAO (artery)" : "CRVO/BRVO (vein)"]]} />
      <SimCanvas cameraPosition={[0, 3.4, 9.5]} target={[0, 0.6, 0]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <planeGeometry args={[32, 20]} />
          <meshStandardMaterial color="#0f172a" roughness={1} />
        </mesh>

        {/* retina bed */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0.6]}>
          <planeGeometry args={[16, 7]} />
          <meshStandardMaterial color={clot > 55 ? "#7c2d12" : "#c2410c"} roughness={0.7} />
        </mesh>
        {/* downstream pale zone */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[3.4, 0.04, 0.6]}>
          <planeGeometry args={[7.2, 7]} />
          <meshStandardMaterial color="#e7e5e4" transparent opacity={clot > 25 ? Math.min(0.75, (clot - 25) / 100) : 0} roughness={0.8} />
        </mesh>

        {/* the vessel */}
        <mesh position={[0, 0.3, 0.62]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.34, 0.34, 13.4, 18]} />
          <meshStandardMaterial color={vessel === "artery" ? "#dc2626" : "#7c3aed"} roughness={0.45} transparent opacity={0.55} />
        </mesh>
        <Label text={vessel === "artery" ? "Retinal artery" : "Retinal vein"} position={[-4.6, 1.4, 0.6]} size={0.5} color={vessel === "artery" ? "#fca5a5" : "#c4b5fd"} />

        {/* the clot */}
        <mesh position={[0, 0.3, 0.62]} scale={[1, 1 + (clot / 100) * 0.7, 1 + (clot / 100) * 0.7]}>
          <sphereGeometry args={[0.42, 16, 14]} />
          <meshStandardMaterial color="#450a0a" roughness={0.9} emissive="#991b1b" emissiveIntensity={0.35} />
        </mesh>
        <Label text="CLOT" position={[0, 1.6, 0.62]} size={0.55} color="#fca5a5" />

        {/* blood flow dots */}
        <group ref={flow}>
          {dots.map((d, i) => (
            <mesh key={i} position={[d.x0, 0.28, 0.62]} userData={{ x0: d.x0, lane: d.lane, seed: d.seed }}>
              <sphereGeometry args={[0.11, 10, 10]} />
              <meshBasicMaterial color={vessel === "artery" ? "#f87171" : "#a78bfa"} />
            </mesh>
          ))}
        </group>

        <Label text="blood jams behind the clot" position={[-3.2, -0.9, 0.6]} size={0.45} color="#fca5a5" />
        <Label text={clot > 55 ? "downstream retina starving ⚠" : "downstream retina fed"} position={[3.4, -0.9, 0.6]} size={0.45} color={clot > 55 ? "#fca5a5" : "#86efac"} />
        <Animator flow={flow} elapsed={elapsed} clot={clot} />
      </SimCanvas>
    </div>
  );
}
